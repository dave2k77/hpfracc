"""Counterfactuals on the real solver via in-memory function replacement."""
from pathlib import Path
exec(Path('/home/davianc/.hermes/cache/scratch/num005_isolate.py').read_text().split("report={'head'")[0])
import inspect
OUT=Path(os.environ.get('NUM005_COUNTERFACTUAL_OUT','/home/davianc/.hermes/cache/scratch/num005_counterfactuals'))
OUT.mkdir(exist_ok=True)
report={'probe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'experiments':{},'callback':{}}
original_dot=pc._history_dot; original_weights=pc._stable_pece_weights; original_setup=pc._setup; original_newton=pc._newton_corrector

def dot_sum(w,h):
    return jnp.sum(w.reshape((-1,)+(1,)*(h.ndim-1))*h,axis=0)
def dot_highest(w,h):
    return jnp.tensordot(w,h,axes=([0],[0]),precision=jax.lax.Precision.HIGHEST)
def dot_kahan(w,h):
    p=w.reshape((-1,)+(1,)*(h.ndim-1))*h
    def step(c,v):
        s,e=c
        x=v-e
        t=s+x
        e=(t-s)-x
        return (t,e),None
    return jax.lax.scan(step,(jnp.zeros_like(h[0]),jnp.zeros_like(h[0])),p)[0][0]
def dot_neumaier(w,h):
    p=w.reshape((-1,)+(1,)*(h.ndim-1))*h
    def step(c,x):
        s,e=c
        t=s+x
        e=e+jnp.where(jnp.abs(s)>=jnp.abs(x),(s-t)+x,(x-t)+s)
        return (t,e),None
    (s,e),_=jax.lax.scan(step,(jnp.zeros_like(h[0]),jnp.zeros_like(h[0])),p)
    return s+e

def setup_round_ref(**kwargs):
    z=list(original_setup(**kwargs)); z[3]=jnp.asarray(S,jnp.float32); return tuple(z)
def weights_ref(step,ind,a,dtype):
    p,c=original_weights(step,ind,a,dtype)
    return p,jnp.asarray(W,np.float32)[step]

def run_case(name,dot=original_dot,wf=original_weights,setup=original_setup,newton=original_newton):
    pc._history_dot=dot; pc._stable_pece_weights=wf; pc._setup=setup; pc._newton_corrector=newton
    v,d=run(alpha,rate)
    assert v.dtype==jnp.float32
    report['experiments'][name]=summary(v,d)
    np.savez(OUT/(name+'.npz'),values=np.asarray(v),reported=np.asarray(d))
    print(name,report['experiments'][name],flush=True)
    pc._history_dot=original_dot; pc._stable_pece_weights=original_weights; pc._setup=original_setup; pc._newton_corrector=original_newton
    return np.asarray(v)

base=run_case('baseline')
run_case('dot_highest',dot=dot_highest)
run_case('dot_sum',dot=dot_sum)
run_case('dot_kahan',dot=dot_kahan)
run_case('dot_neumaier',dot=dot_neumaier)
run_case('scale_rounded_independent',setup=setup_round_ref)
run_case('coefficient_rounded_independent',wf=weights_ref)
run_case('coefficient_rounded_independent_dot_sum',wf=weights_ref,dot=dot_sum)
run_case('direct_weights',wf=pc._pece_weights)
run_case('newton_exact_linear',newton=lambda f,k,s,g,i:k/(1+s*rate))

# Return diagnostic arrays through debug callbacks, checking perturbation explicitly.
records=[]
def record(*xs):
    records.append([np.asarray(x).copy() for x in xs])
ns=dict(pc.__dict__); ns.update(jax=jax,record=record)
src=inspect.getsource(pc._simulate_implicit)
needle='        next_f = f_at(corrected)\n'
src=src.replace(needle,needle+'        jax.debug.callback(record, step, predictor_weights, corrector_weights, history, known, corrector_scale, corrected, ordered=True)\n')
exec(src,ns)
z=ns['_simulate_implicit'](model=model,ts=ts,initial_state=y0,params=rate,solver=pc.ImplicitPredictorCorrector(dt=dt,order=alpha,newton_iterations=iters,newton_rtol=rtol,newton_atol=atol,weight_evaluation='stable'))
v=np.asarray(z.latent_state); jax.effects_barrier()
report['callback']={'matches_public':bool(np.array_equal(v,base)),'max_state_diff':float(np.max(np.abs(v-base))),'summary':summary(v,z.solver_info.diagnostics['newton_scaled_residuals'])}
records.sort(key=lambda x:int(x[0])); np.savez(OUT/'callback.npz',**{name:np.stack([r[i] for r in records]) for i,name in enumerate(['step','pw','cw','history','known','scale','values'])})
print('callback',report['callback'],flush=True)
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print('REPORT',OUT/'report.json',flush=True)
