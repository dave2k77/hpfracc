"""Independent worst-step cross-checks without production imports of helpers."""
import os,json,hashlib,math
from pathlib import Path
import numpy as np
import jax
import jax.numpy as jnp
import mpmath as mp
assert not jax.config.x64_enabled
OUT=Path('/home/davianc/.hermes/cache/scratch/num005_crosscheck');OUT.mkdir(exist_ok=True)
raw=np.load('/home/davianc/.hermes/cache/scratch/num005_basis/raw.npz')
rep=json.loads(Path('/home/davianc/.hermes/cache/scratch/num005_basis/report.json').read_text())
w=raw['weights_basis'];h=raw['history_float32'];wr=raw['weights_reference'];k=rep['step'];s=rep['scale'];dr=rep['dot']
mp.mp.dps=80
a=mp.mpf('.5'); ss=mp.mpf(1)/16/mp.gamma(mp.mpf('2.5'))
# Independent high-precision panel integrals of linear interpolation basis.
wm=[]
for j in range(k):
    upper=mp.mpf(k-j);lower=upper-1
    left=(upper**(a+1)-lower**(a+1))/(a+1)-lower*(upper**a-lower**a)/a
    right=mp.mpf(0)
    if j>0:
        upper2=upper+1;lower2=upper
        right=upper2*(upper2**a-lower2**a)/a-(upper2**(a+1)-lower2**(a+1))/(a+1)
    wm.append(a*(a+1)*(left+right))
y=np.asarray(raw['original_values'],np.float64)[:,0]
Kmp=1+ss*sum(wm[j]*(-30*mp.mpf(float(y[j]))) for j in range(k))
Rmp=mp.mpf(float(y[k]))-Kmp-ss*(-30*mp.mpf(float(y[k])))
T=mp.mpf('1e-7')+mp.mpf('1e-5')*max(abs(mp.mpf(float(y[k]))),abs(Kmp))
# Sequential rounded products vs fused-products inferred from observed dot.
products=np.float32(w)*np.float32(h)
seq=np.float32(0)
for p in products: seq=np.float32(seq+p)
rev=np.float32(0)
for p in products[::-1]: rev=np.float32(rev+p)
# Isolate final known arithmetic: input dot is exactly the observed original one.
@jax.jit
def known_alternatives(d,c):
    return (1+c*d,1+jax.lax.optimization_barrier(c*d),c*(d+1/c))
knowns=known_alternatives(jnp.array(dr,jnp.float32),jnp.array(s,jnp.float32))
# Pure arithmetic frozen coefficients, no moment kernel influence.
@jax.jit
def frozen_dot(w,h):return jnp.tensordot(w,h,axes=([0],[0]))
@jax.jit
def frozen_sum(w,h):return jnp.sum(w*h)
dynamic_dot=float(frozen_dot(jnp.array(w,jnp.float32),jnp.array(h,jnp.float32)))
dynamic_sum=float(frozen_sum(jnp.array(w,jnp.float32),jnp.array(h,jnp.float32)))
report={'probe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mpmath_dps':80,'reference_coefficient_max_abs_error_vs_80digit':float(max(abs(mp.mpf(float(wr[j]))-wm[j]) for j in range(k))),'reference_scale_error_vs_80digit':float(abs(mp.mpf(rep['scale_reference'])-ss)),'residual_80digit':str(Rmp),'scaled_80digit':str(abs(Rmp)/T),'sequential_rounded_product_sum':float(seq),'reverse_sequential_rounded_product_sum':float(rev),'observed_fused_dot':dr,'dot_dynamic_buffer_operands':dynamic_dot,'sum_dynamic_buffer_operands':dynamic_sum,'final_known_variants':[float(x) for x in knowns],'known_reference_using_same_dot_and_scale_float64':1+s*dr,'newton_exact_runtime_root':rep['known']/(1+30*s),'working_dtype_assertions':[str(x.dtype) for x in knowns]}
print(json.dumps(report,indent=2))
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
