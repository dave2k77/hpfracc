"""Scratch-only NUM005 controlled CPU/GPU experiments; no source changes."""
import os,sys,json,hashlib,subprocess
from pathlib import Path
from math import gamma
import numpy as np
import jax
import jax.numpy as jnp
ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
sys.path.insert(0,str(ROOT))
from hpfracc.solvers import predictor_corrector as pc
from benchmarks.numerical.implicit_validation import quadrature_weights,independent_residuals
OUT=Path(os.environ.get('NUM005_OUT',str(Path(__file__).with_suffix(''))))
OUT.mkdir(exist_ok=True)
assert not jax.config.x64_enabled
n=257; dt=1/256; iters=8; rtol=1e-5; atol=1e-7
alpha=jnp.array(.5,jnp.float32); rate=jnp.array(30.,jnp.float32)
y0=jnp.ones(1,jnp.float32); ts=jnp.linspace(0.,1.,n,dtype=jnp.float32)
indices=jnp.arange(n)
def model(t,state,params,*,rng_key=None,inputs=None):
    return -params*state

def run(a,r,evaluation='stable'):
    z=pc.simulate(model=model,ts=ts,initial_state=y0,params=r,
         solver=pc.ImplicitPredictorCorrector(dt=dt,order=a,newton_iterations=iters,
         newton_rtol=rtol,newton_atol=atol,weight_evaluation=evaluation))
    return z.latent_state,z.solver_info.diagnostics['newton_scaled_residuals']

Q=quadrature_weights(n,.5)
S=dt**.5/gamma(2.5)
W=Q/S; W[np.diag_indices(n)]=0

def summary(v,d):
    v64=np.asarray(v,dtype=np.float64)
    res=independent_residuals('half_decay',np.asarray(ts,dtype=np.float64),v64,30.,.5,np.ones(1),rtol,atol)
    k=int(np.argmax(res))+1
    return dict(dtype=str(v.dtype),max_independent=float(max(res)),worst_step=k,reported_max=float(np.max(d)),value=float(v64[k,0]))

# Same algorithm cloned to expose actual arithmetic. Exact comparison is mandatory.
def trace_run(a,r,weight_fn=pc._stable_pece_weights,dot_fn=pc._history_dot,scale_override=None,known_fn=None,exact_newton=False):
    _,_,ps,cs,ind,h0=pc._setup(model=model,times=ts,solver=pc.ImplicitPredictorCorrector(dt=dt,order=a),y0=y0,params=r,rng_key=None,inputs=None)
    if scale_override is not None:
        cs=jnp.asarray(scale_override,jnp.float32)
    def step(h,k):
        pw,cw=weight_fn(k,ind,a,h0.dtype)
        pd=dot_fn(pw,h); cd=dot_fn(cw,h)
        pred=y0+ps*pd
        known=y0+cs*cd if known_fn is None else known_fn(y0,cs,cw,h)
        f=lambda y: -r*y
        corrected=known/(1+cs*r) if exact_newton else pc._newton_corrector(f,known,cs,pred,iters)
        nf=f(corrected)
        res=corrected-known-cs*nf
        tol=atol+rtol*jnp.maximum(jnp.abs(corrected),jnp.abs(known))
        return h.at[k].set(nf),(corrected,pd,cd,known,res,jnp.max(jnp.abs(res)/tol),cw,cs)
    _,z=jax.lax.scan(step,h0,jnp.arange(1,n))
    return (jnp.concatenate([y0[None],z[0]],axis=0),)+z[1:]

report={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'python':sys.version,'jax':jax.__version__,'devices':[str(d) for d in jax.devices()],'x64':bool(jax.config.x64_enabled),'sources':{},'baseline':{},'trace':{},'counterfactuals':{}}
for rel in ['src/hpfracc/solvers/predictor_corrector.py','src/hpfracc/solvers/_weights.py','src/hpfracc/ops/_quadrature.py','src/hpfracc/ops/_special.py','benchmarks/numerical/implicit_validation.py','benchmarks/numerical/scientific_acceptance.py']:
    report['sources'][rel]=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
report['probe_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
base={}
for ev in ['stable','direct']:
    for mode in ['eager','jit']:
        fun=lambda a,r:run(a,r,ev)
        if mode=='jit': fun=jax.jit(fun)
        v,d=fun(alpha,rate)
        assert v.dtype==jnp.float32
        if hasattr(d,'dtype'): assert d.dtype==jnp.float32
        d=np.asarray(d)
        key=ev+'_'+mode
        base[key]=(np.asarray(v),np.asarray(d))
        report['baseline'][key]=summary(v,d)
        print(key,report['baseline'][key],flush=True)
        np.savez(OUT/(key+'.npz'),values=np.asarray(v),reported=np.asarray(d))

for mode in ['eager','jit']:
    tf=trace_run if mode=='eager' else jax.jit(trace_run)
    traced=tf(alpha,rate)
    for x in traced: assert x.dtype==jnp.float32
    v,pd,cd,kn,res,scaled,cw,cs=[np.asarray(x) for x in traced]
    bv=base['stable_'+mode][0]
    out=summary(v,scaled)
    out['matches_public_bitwise']=bool(np.array_equal(v,bv))
    out['max_public_state_diff']=float(np.max(np.abs(v-bv)))
    k=out['worst_step']; y=np.asarray(v,dtype=np.float64)[:,0]; fq=np.asarray(np.float32(-30)*v[:,0],np.float64); fr=-30*y
    sr=float(cs[k-1]); wr=np.asarray(cw[k-1],np.float64); wref=W[k]
    dr=float(cd[k-1,0]); kr=float(kn[k-1,0]); yr=float(y[k])
    d_exact=float(wr@fq); d_rhs64=float(wr@fr); d_ref=float(wref@fr)
    Kref=1+S*d_ref
    tol=atol+rtol*max(abs(yr),abs(Kref))
    # Additive telescoping terms sum to the independent physical equation residual.
    components={
        'newton_runtime_equation_exact':yr-kr-sr*fq[k],
        'known_evaluation_rounding':kr-(1+sr*dr),
        'history_dot_product_and_reduction':sr*(dr-d_exact),
        'history_rhs_quantization':sr*(d_exact-d_rhs64),
        'coefficient_error':sr*(d_rhs64-d_ref),
        'gamma_scale_history':(sr-S)*d_ref,
        'gamma_scale_current':(sr-S)*fr[k],
        'current_rhs_quantization':sr*(fq[k]-fr[k]),
    }
    residual_ref=yr-Kref-S*fr[k]
    out.update(worst={'step':k,'y':yr,'known_runtime':kr,'known_reference':Kref,'dot_runtime':dr,'dot_exact_float32_operands':d_exact,'scale_runtime':sr,'scale_reference':S,'scale_rel_error':sr/S-1,'tolerance_reference':tol,'residual_reference':residual_ref,'component_sum':sum(components.values()),'components_absolute_signed':components,'components_scaled_signed':{c:v/tol for c,v in components.items()},'max_coefficient_rel_error':float(np.max(np.abs((wr[:k]-wref[:k])/wref[:k]))),'newton_exact_linear_root':kr/(1+30*sr),'newton_root_state_error':yr-kr/(1+30*sr)})
    assert abs(sum(components.values())-residual_ref)<1e-14
    report['trace'][mode]=out
    np.savez(OUT/('trace_'+mode+'.npz'),values=v,predictor_dot=pd,corrector_dot=cd,known=kn,residual=res,scaled=scaled,weights=cw,scale=cs)
    print('trace',mode,json.dumps(out),flush=True)

(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print('REPORT',OUT/'report.json',flush=True)
