"""Exact compiled public worst-step replay + basis-input coefficient isolation."""
from pathlib import Path
exec(Path('/home/davianc/.hermes/cache/scratch/num005_replay.py').read_text().split('report={}')[0])
OUT=Path('/home/davianc/.hermes/cache/scratch/num005_basis');OUT.mkdir(exist_ok=True)
f,_=make_step('dot'); executable=jax.jit(f).lower(step,h,alpha,rate,cs).compile()
z=executable(step,h,alpha,rate,cs)
yr,diag,kr,dr=[float(np.asarray(x).ravel()[0]) for x in z]
assert yr==float(v[k,0])
wr=np.zeros(n,np.float64)
for j in range(k):
    basis=np.zeros((n,1),np.float32);basis[j,0]=1
    out=executable(step,jnp.asarray(basis),alpha,rate,cs)
    wr[j]=float(out[3][0])
# Same executable replay with actual history again.
z2=executable(step,h,alpha,rate,cs)
assert all(np.array_equal(np.asarray(x),np.asarray(y)) for x,y in zip(z,z2))
# Compare basis coefficients with weight-only evaluation (instrumentation check).
fw,_=make_step('weights_only'); standalone=np.asarray(jax.jit(fw)(step,h,alpha,rate,cs),np.float64)
y=np.asarray(v,np.float64)[:,0];fq=np.asarray(history,np.float64)[:,0];fr=-30*y; fr[k:]=0
sr=float(cs); wref=W[k]; dexact=float(wr@fq); drhs64=float(wr@fr); dref=float(wref@fr)
Kref=1+S*dref;fcurr=-30*y[k];fqcurr=float(np.float32(-30)*v[k,0])
tol=atol+rtol*max(abs(yr),abs(Kref))
components={
 'newton_runtime_equation_exact':yr-kr-sr*fqcurr,
 'known_evaluation_rounding':kr-(1+sr*dr),
 'history_dot_product_and_reduction':sr*(dr-dexact),
 'history_rhs_quantization':sr*(dexact-drhs64),
 'coefficient_error':sr*(drhs64-dref),
 'gamma_scale_history':(sr-S)*dref,
 'gamma_scale_current':(sr-S)*fcurr,
 'current_rhs_quantization':sr*(fqcurr-fcurr)}
resref=yr-Kref-S*fcurr
assert abs(sum(components.values())-resref)<1e-14
# frozen-history counterfactual kernels preserve original coefficient evaluation.
from functools import partial

def simple_sum(w,h):return jnp.sum(w[:,None]*h,axis=0)
def kahan(w,h):
 def body(c,x):
    s,e=c; t=x-e; u=s+t; return (u,(u-s)-t),None
 return jax.lax.scan(body,(jnp.zeros_like(h[0]),jnp.zeros_like(h[0])),w[:,None]*h)[0][0]

def eval_dot(dot):
 @jax.jit
 def fn(k,h,a):
    pw,cw=pc._stable_pece_weights(k,indices,a,h.dtype)
    return dot(cw,h)
 return float(fn(step,h,alpha)[0])
report={'probe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'step':k,'same_public_state':yr==float(v[k,0]),'y':yr,'known':kr,'dot':dr,'scale':sr,'scale_reference':S,'tolerance':tol,'residual_reference':resref,'scaled_reference':resref/tol,'components_signed':components,'components_scaled_signed':{c:x/tol for c,x in components.items()},'component_sum':sum(components.values()),'dot_reference_float32_operands':dexact,'coefficient_max_relative_error':float(np.max(np.abs((wr[:k]-wref[:k])/wref[:k]))),'standalone_weight_diff_count':int(np.count_nonzero(wr!=standalone)),'standalone_weight_max_abs_diff':float(np.max(np.abs(wr-standalone))),'newton_state_error_vs_exact_runtime_root':yr-kr/(1+30*sr),'known_cancellation_factor':(1+abs(sr*dr))/abs(kr),'frozen_history_dots':{}}
for name,dot in [('default',pc._history_dot),('sum',simple_sum),('kahan',kahan)]:
 d=eval_dot(dot);report['frozen_history_dots'][name]={'value':d,'scaled_error_vs_basis_coefficients':sr*(d-dexact)/tol}
import math
products32=np.float32(wr)*np.asarray(history[:,0],np.float32)
product_sum64=math.fsum(float(x) for x in products32)
report['dot_rounding_split']={'rounded_products_sum_float64':product_sum64,'product_rounding_absolute':sr*(product_sum64-dexact),'accumulation_absolute':sr*(dr-product_sum64),'product_rounding_scaled':sr*(product_sum64-dexact)/tol,'accumulation_scaled':sr*(dr-product_sum64)/tol,'exact_products_fsum':math.fsum(float(w)*float(x) for w,x in zip(wr,fq))}
print(json.dumps(report,indent=2),flush=True)
np.savez(OUT/'raw.npz',weights_basis=wr,weights_standalone=standalone,weights_reference=wref,history_float32=fq,history_reference=fr,original_values=v)
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
