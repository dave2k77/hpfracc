"""Replay worst public step and compare output perturbations/HLO."""
from pathlib import Path
exec(Path('/home/davianc/.hermes/cache/scratch/num005_isolate.py').read_text().split("report={'head'")[0])
OUT=Path('/home/davianc/.hermes/cache/scratch/num005_replay');OUT.mkdir(exist_ok=True)
v=np.load('/home/davianc/.hermes/cache/scratch/num005_isolate/stable_eager.npz')['values']
k=209
history=np.zeros((n,1),np.float32);history[:k]=-np.float32(30)*v[:k]
h=jnp.asarray(history);step=jnp.array(k,jnp.int32)
# All four arrays are strong dynamic JIT inputs.
def make_step(output):
 def f(k,h,a,r,cs):
    pw,cw=pc._stable_pece_weights(k,indices,a,h.dtype)
    pd=pc._history_dot(pw,h); cd=pc._history_dot(cw,h)
    ps=cs*(a+1)
    pred=y0+ps*pd; known=y0+cs*cd
    f_at=lambda y:-r*y
    c=pc._newton_corrector(f_at,known,cs,pred,iters)
    nf=f_at(c);res=c-known-cs*nf
    tol=atol+rtol*jnp.maximum(jnp.abs(c),jnp.abs(known))
    sc=jnp.max(jnp.abs(res)/tol)
    if output=='known_only': return known
    if output=='public': return c,sc
    if output=='known': return c,sc,known
    if output=='dot': return c,sc,known,cd
    if output=='weights': return c,sc,known,cd,cw
    if output=='weights_only': return cw
 def go(*args):return jax.jit(f)(*args)
 return f,go
cs=jnp.asarray(S,jnp.float32)
report={}
for mode in ['public','known','dot','weights','known_only','weights_only']:
 f,go=make_step(mode);z=go(step,h,alpha,rate,cs)
 arr=[np.asarray(x) for x in (z if isinstance(z,tuple) else (z,))]
 np.savez(OUT/(mode+'.npz'),**{f'a{i}':x for i,x in enumerate(arr)})
 report[mode]=[x.tolist() if x.size<3 else {'shape':x.shape} for x in arr]
 if mode=='public':report[mode].append({'original_y':float(v[k,0]),'same_y':bool(arr[0][0]==v[k,0])})
 (OUT/(mode+'.hlo.txt')).write_text(jax.jit(f).lower(step,h,alpha,rate,cs).compile().as_text())
 print(mode,report[mode],flush=True)
# Full solver compiled HLO for comparison.
(OUT/'public_full.hlo.txt').write_text(jax.jit(run).lower(alpha,rate).compile().as_text())
(OUT/'trace_full.hlo.txt').write_text(jax.jit(trace_run).lower(alpha,rate).compile().as_text())
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
