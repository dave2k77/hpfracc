"""Solver validation report helpers."""
