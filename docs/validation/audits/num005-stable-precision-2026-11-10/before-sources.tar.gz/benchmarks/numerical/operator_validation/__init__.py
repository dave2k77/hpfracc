"""Operator validation report helpers."""

