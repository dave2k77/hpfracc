import pathlib,os,subprocess,time,json,shlex,xml.etree.ElementTree as ET
OUT=pathlib.Path(__file__).parent
ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
env=os.environ.copy()
env.update(UV_PROJECT_ENVIRONMENT=str(pathlib.Path.home()/'.local/share/hpfracc/venv-cuda13'),JAX_PLATFORMS='cuda,cpu',XLA_PYTHON_CLIENT_PREALLOCATE='false',PYTHONDONTWRITEBYTECODE='1',UV_CACHE_DIR=str(OUT/'uv-cache'),HYPOTHESIS_STORAGE_DIRECTORY=str(OUT/'hypothesis'),PYTHONPATH=str(OUT)+os.pathsep+str(ROOT),CUDA_CACHE_PATH=str(OUT/'cuda-driver-cache'))
runs=[]
for n,select in enumerate([['tests/unit/test_history_reduction_compatibility.py','-q'],['tests/unit/test_history_reduction_compatibility.py','-vv','-x'],['-q'],['tests/unit/test_history_reduction_compatibility.py','-q']],1):
    directory=OUT/('observed-'+str(n));directory.mkdir()
    e=env|{'NUM005_PROBE_OUT':str(directory)}
    cmd=['uv','run','--frozen','--no-sync','--extra','dev','--extra','cuda13','python','-m','pytest',*select,'-k','test_dynamic_float32_order_jit_stiff_decay_independent_residual','-p','precision_plugin','-p','no:cacheprovider','--basetemp',str(directory/'tmp'),'--junitxml',str(directory/'junit.xml')]
    start=time.time()
    with (directory/'stdout.log').open('wb') as log:
        p=subprocess.Popen(cmd,cwd=ROOT,env=e,stdout=log,stderr=subprocess.STDOUT)
        try:rc=p.wait(timeout=65)
        except subprocess.TimeoutExpired:p.kill();rc=p.wait()
    row={'command':shlex.join(cmd),'env_overrides':{k:e[k] for k in ['NUM005_PROBE_OUT','CUDA_CACHE_PATH','PYTHONPATH']},'exit_code':rc,'elapsed_seconds':time.time()-start,'pid':p.pid}
    if (directory/'junit.xml').exists():row['properties']=[x.attrib for x in ET.parse(directory/'junit.xml').iter('property')]
    if (directory/'precision-context.json').exists():row['observations']=[{k:v for k,v in x.items() if k in ['nodeid','maximum','stablehlo_sha256','optimized_hlo_sha256','states','same_executable_replay']} for x in json.loads((directory/'precision-context.json').read_text())]
    runs.append(row);(OUT/'repeat-observed.json').write_text(json.dumps(runs,indent=2));print(json.dumps(row,indent=2),flush=True)
