"""Read-only observation of the exact original target, after it executes."""
import pathlib, json, sys, hashlib, re, os
import pytest
OUT=pathlib.Path(os.environ.get('NUM005_PROBE_OUT', pathlib.Path(__file__).parent))
OUT.mkdir(parents=True, exist_ok=True)
TARGET='test_dynamic_float32_order_jit_stiff_decay_independent_residual'
rows=[]
def config_snapshot():
    import jax, jaxlib
    names=['jax_enable_x64','jax_default_matmul_precision','jax_default_dtype_bits','jax_numpy_dtype_promotion','jax_enable_compilation_cache','jax_compilation_cache_dir','jax_persistent_cache_min_compile_time_secs','jax_persistent_cache_enable_xla_caches','jax_compiler_enable_remat_pass','jax_optimization_level','jax_exec_time_optimization_effort','jax_memory_fitting_effort','jax_default_prng_impl','jax_disable_jit']
    return {'jax':jax.__version__,'jaxlib':jaxlib.__version__,'default_backend':jax.default_backend(),'devices':[str(x) for x in jax.devices()],'config':{k:jax.config.values.get(k,'<not registered>') for k in names},'environment':{k:os.environ.get(k) for k in ['JAX_ENABLE_X64','JAX_DEFAULT_MATMUL_PRECISION','JAX_COMPILATION_CACHE_DIR','JAX_ENABLE_COMPILATION_CACHE','JAX_PERSISTENT_CACHE_MIN_COMPILE_TIME_SECS','JAX_PLATFORMS','XLA_FLAGS','XLA_PYTHON_CLIENT_PREALLOCATE']}}
@pytest.hookimpl(hookwrapper=True)
def pytest_pyfunc_call(pyfuncitem):
    if TARGET not in pyfuncitem.name:
        yield
        return
    captured={}
    row={'nodeid':pyfuncitem.nodeid,'before':config_snapshot()}
    def profile(frame,event,arg):
        if event=='return' and frame.f_code.co_name==TARGET:
            captured.update(frame.f_locals)
    previous=sys.getprofile()
    sys.setprofile(profile)
    try: yield
    finally: sys.setprofile(previous)
    import jax, numpy as np
    row['after']=config_snapshot()
    if captured:
        for name in ['order','rate','states','times','initial']:
            value=captured[name]
            row[name]={'dtype':str(value.dtype),'weak_type':getattr(value,'weak_type',None),'shape':list(value.shape),'sha256':hashlib.sha256(np.asarray(value).tobytes()).hexdigest()}
        row['maximum']=captured['maximum']
        row['converged']=bool(captured['converged'])
        evaluation=captured['evaluation']
        np.savez(OUT/(evaluation+'-observed.npz'),states=np.asarray(captured['states']),times=np.asarray(captured['times']),residuals=captured['residuals'])
        # The numerical test has completed; lower its existing jitted function.
        with jax.enable_x64(False):
            assert captured['states'].dtype==captured['order'].dtype==np.dtype('float32')
            assert captured['states'][-1].sum().dtype==np.dtype('float32')
            lowered=captured['run'].lower(captured['order'])
            stablehlo=str(lowered.compiler_ir(dialect='stablehlo'))
            hlo=lowered.compile().as_text()
        (OUT/(evaluation+'-stablehlo.txt')).write_text(stablehlo)
        (OUT/(evaluation+'-optimized-hlo.txt')).write_text(hlo)
        row['stablehlo_float_types']=sorted(set(re.findall(r'\b(?:f16|bf16|f32|f64)\b',stablehlo)))
        row['optimized_hlo_float_types']=sorted(set(re.findall(r'\b(?:f16|bf16|f32|f64)\b',hlo)))
        assert row['stablehlo_float_types']==['f32'], row['stablehlo_float_types']
        assert row['optimized_hlo_float_types']==['f32'], row['optimized_hlo_float_types']
        row['stablehlo_sha256']=hashlib.sha256(stablehlo.encode()).hexdigest()
        row['optimized_hlo_sha256']=hashlib.sha256(hlo.encode()).hexdigest()
        row['optimized_dot_lines']=[x for x in hlo.splitlines() if re.search(r'\bdot\(',x)]
        row['cache_size']=captured['run']._cache_size()
        with jax.enable_x64(False):
            repeat_states,repeat_flags=zip(*(captured['run'](captured['order']) for _ in range(5)))
        row['same_executable_replay']=[{'states_sha256':hashlib.sha256(np.asarray(v).tobytes()).hexdigest(),'converged':bool(c)} for v,c in zip(repeat_states,repeat_flags)]
    rows.append(row)
    (OUT/'precision-context.json').write_text(json.dumps(rows,indent=2,default=str))
