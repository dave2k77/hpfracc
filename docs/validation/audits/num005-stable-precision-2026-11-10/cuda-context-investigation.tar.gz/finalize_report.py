import pathlib,json,hashlib,re,xml.etree.ElementTree as ET,difflib,datetime
ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=pathlib.Path(__file__).parent
BASE=ROOT/'docs/validation/audits/num005-stable-precision-2026-11-10'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((BASE/'suite-source-inputs.json').read_text())
current={p:sha(ROOT/p) for p in frozen['source_sha256']}
assert current==frozen['source_sha256']
assert sha(BASE/frozen['archive'])==frozen['archive_sha256']
historical={}
expected={'full-cuda.xml':'af51b6c2beb176f1cbc184a86953c54880f7a8ab7ff0be705429c2f8f6f2d758','compatibility/cuda.xml':'ee48009927556de193782ee4d0fa62d64752d1276060583e7c34144949321618','full-cpu.xml':'70dd839132c92921ac0486e5ace0f9016edcfaf8881ea20a02137857ff8b1a56','compatibility/cpu.xml':'10006e4a574cc3e6d9b52609b77aa22c58709d5716af157d2eed8b9fee03306e'}
for name,original in expected.items():
    p=BASE/name;assert sha(p)==original
    tree=ET.parse(p)
    historical[name]={'sha256':sha(p),'suites':[x.attrib for x in tree.iter('testsuite')],'properties':[x.attrib for x in tree.iter('property') if 'independent_scaled_residual' in x.get('name','')]}
runs=json.loads((OUT/'runs.json').read_text())['runs']+json.loads((OUT/'additional-runs.json').read_text())+json.loads((OUT/'repeat-observed.json').read_text())
xmls=[OUT/(n+'.xml') for n in ['target-file','full-collection','whole-file','verbose-original','precision-observed','cache-disabled']]+[OUT/f'observed-{n}'/'junit.xml' for n in range(1,5)]
assert len(runs)==len(xmls)==10
assert all(x['exit_code']==0 for x in runs)
cases=0
for path in xmls:
    tree=ET.parse(path);actual=len(list(tree.iter('testcase')))
    declared=sum(int(x.attrib['tests']) for x in tree.iter('testsuite'));assert actual==declared
    cases+=actual
    assert not list(tree.iter('failure')) and not list(tree.iter('error'))
    assert all(float(x.get('value'))<=1 for x in tree.iter('property') if 'independent_scaled_residual' in x.get('name',''))
comparisons={}
for e in ['stable','direct']:
    a=OUT/'observed-1';b=OUT/'observed-4'
    assert (a/(e+'-stablehlo.txt')).read_bytes()==(b/(e+'-stablehlo.txt')).read_bytes()
    ja=json.loads((a/'precision-context.json').read_text());jb=json.loads((b/'precision-context.json').read_text())
    x=next(t for t in ja if '['+e+']' in t['nodeid']);y=next(t for t in jb if '['+e+']' in t['nodeid'])
    assert x['before']==y['before'] and x['after']==y['after']
    assert x['stablehlo_float_types']==y['stablehlo_float_types']==['f32']
    assert x['optimized_hlo_float_types']==y['optimized_hlo_float_types']==['f32']
    assert not x['optimized_dot_lines'] and not y['optimized_dot_lines']
    assert all(v['states_sha256']==x['states']['sha256'] for v in x['same_executable_replay'])
    assert all(v['states_sha256']==y['states']['sha256'] for v in y['same_executable_replay'])
    left=(a/(e+'-optimized-hlo.txt')).read_text().splitlines();right=(b/(e+'-optimized-hlo.txt')).read_text().splitlines()
    differences=[(u,v) for u,v in zip(left,right) if u!=v]
    assert len(left)==len(right)
    assert all(('fingerprint_before_lhs' in u and 'fingerprint_before_lhs' in v) or ('fusion(' in u and 'fusion(' in v and '__triton' in u and 'native_emitter_backend_config' in v) for u,v in differences)
    comparisons[e]={'same_stablehlo':True,'same_whitelisted_config':True,'changed_hlo_lines':len(differences),'only_fingerprint_and_emitter_config_differ':True,'triton_residual':x['maximum'],'native_residual':y['maximum'],'triton_states_sha256':x['states']['sha256'],'native_states_sha256':y['states']['sha256'],'five_replays_per_executable_bitwise_stable':True,'stablehlo_sha256':x['stablehlo_sha256'],'triton_optimized_hlo_sha256':x['optimized_hlo_sha256'],'native_optimized_hlo_sha256':y['optimized_hlo_sha256']}
report={'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pytest_processes':len(runs),'test_executions':cases,'all_real_process_exit_codes_zero':True,'all_same_original_acceptance_criterion_pass':True,'current_frozen_source_count':len(current),'source_sha256':current,'historical_xml_unchanged':historical,'comparisons':comparisons,'state_comparison':json.loads((OUT/'state-comparison.json').read_text()),'interpretation':{'observed':'Both historical pairs reproduced without full-suite execution. Same target-only context produced both pairs. Same StableHLO/config, different optimized reduction emitter (Triton versus native).','supported_mechanism':'A compilation-path reduction lowering difference with float32 roundoff-level trajectory differences, not mixed precision or source drift.','unresolved':'Why the compiler selected different emitters; no claim of nondeterministic autotuning or timing/load cause. Original historical optimized executables were not saved.','numerical_defect':'No new acceptance-criterion violation demonstrated; exact cross-process/cross-context residual equality is invalid for these observations.','precision':'Strong float32 order/rate/states/objective; StableHLO and optimized HLO contain only f32 floating types, no f16/bf16/f64 and no dot op. Host independent residual widens states to float64.','probe_issue':'A separate optional DebugOptions introspection subprocess exited 139. Its exact command and exit are preserved in inspect-numerics-command.json; NumPy-only comparison retry exited 0. No pytest process failed.'}}
(OUT/'validation-report.json').write_text(json.dumps(report,indent=2))
artifacts={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file() and not any(c in str(p.relative_to(OUT)) for c in ['uv-cache/','cuda-driver-cache/','hypothesis/','__pycache__']) and p.suffix in ['.py','.json','.txt','.log','.xml','.npz'] and p.name!='artifact-sha256.json'}
(OUT/'artifact-sha256.json').write_text(json.dumps(artifacts,indent=2))
print(json.dumps({'pytest_processes':len(runs),'test_executions':cases,'frozen_sources_unchanged':len(current),'comparisons':comparisons,'report':str(OUT/'validation-report.json'),'artifacts':len(artifacts)},indent=2))
