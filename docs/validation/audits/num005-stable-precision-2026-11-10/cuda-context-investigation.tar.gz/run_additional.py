import pathlib,os,subprocess,time,json,shlex,xml.etree.ElementTree as ET
OUT=pathlib.Path(__file__).parent
ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
env=os.environ.copy()
env.update(UV_PROJECT_ENVIRONMENT=str(pathlib.Path.home()/'.local/share/hpfracc/venv-cuda13'),JAX_PLATFORMS='cuda,cpu',XLA_PYTHON_CLIENT_PREALLOCATE='false',PYTHONDONTWRITEBYTECODE='1',UV_CACHE_DIR=str(OUT/'uv-cache'),HYPOTHESIS_STORAGE_DIRECTORY=str(OUT/'hypothesis'))
file='tests/unit/test_history_reduction_compatibility.py'
target='test_dynamic_float32_order_jit_stiff_decay_independent_residual'
runs=[]
for name,selection,extra in [('verbose-original',[file,'-vv','-x'],{}),('precision-observed',[file,'-q','-k',target,'-p','precision_plugin'],{'PYTHONPATH':str(OUT)+os.pathsep+str(ROOT)}),('cache-disabled',[file,'-q','-k',target],{'JAX_ENABLE_COMPILATION_CACHE':'false'})]:
    e=env|extra
    cmd=['uv','run','--frozen','--no-sync','--extra','dev','--extra','cuda13','python','-m','pytest',*selection,'-p','no:cacheprovider','--basetemp',str(OUT/(name+'-tmp')),'--junitxml',str(OUT/(name+'.xml'))]
    started=time.time()
    with (OUT/(name+'.log')).open('wb') as log:
        p=subprocess.Popen(cmd,cwd=ROOT,env=e,stdout=log,stderr=subprocess.STDOUT)
        try: rc=p.wait(timeout=100)
        except subprocess.TimeoutExpired:
            p.terminate()
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:p.kill();p.wait()
            rc=p.returncode
    row={'name':name,'command':shlex.join(cmd),'extra_environment':extra,'exit_code':rc,'elapsed_seconds':time.time()-started,'pid':p.pid}
    xml=OUT/(name+'.xml')
    if xml.exists():
        t=ET.parse(xml)
        row['suites']=[x.attrib for x in t.iter('testsuite')]
        row['properties']=[x.attrib for x in t.iter('property')]
    runs.append(row)
    (OUT/'additional-runs.json').write_text(json.dumps(runs,indent=2))
    print(json.dumps(row,indent=2),flush=True)
