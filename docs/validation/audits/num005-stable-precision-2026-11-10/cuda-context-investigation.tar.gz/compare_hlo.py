import pathlib,difflib,json,re,hashlib
OUT=pathlib.Path(__file__).parent
result={}
for evaluation in ['stable','direct']:
    left=(OUT/'observed-1'/f'{evaluation}-optimized-hlo.txt').read_text()
    right=(OUT/'observed-4'/f'{evaluation}-optimized-hlo.txt').read_text()
    diff=list(difflib.unified_diff(left.splitlines(),right.splitlines(),fromfile='observed-1/'+evaluation,tofile='observed-4/'+evaluation,n=3))
    (OUT/(evaluation+'-hlo-diff.txt')).write_text('\n'.join(diff)+'\n')
    result[evaluation]={'diff_lines':len(diff),'diff':diff[:230]}
print(json.dumps(result,indent=2))
