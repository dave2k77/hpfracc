import os, sys, pathlib, subprocess, time, json, hashlib, shlex, xml.etree.ElementTree as ET
ROOT = pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = pathlib.Path(__file__).parent
TARGET = 'test_dynamic_float32_order_jit_stiff_decay_independent_residual'
FILE = 'tests/unit/test_history_reduction_compatibility.py'
env = os.environ.copy()
env.update(UV_PROJECT_ENVIRONMENT=str(pathlib.Path.home()/'.local/share/hpfracc/venv-cuda13'), JAX_PLATFORMS='cuda,cpu', XLA_PYTHON_CLIENT_PREALLOCATE='false', PYTHONDONTWRITEBYTECODE='1', UV_CACHE_DIR=str(OUT/'uv-cache'), HYPOTHESIS_STORAGE_DIRECTORY=str(OUT/'hypothesis'))
# Read-only source fingerprint before and after; all emitted files stay in scratch.
sources = ['src/hpfracc/solvers/predictor_corrector.py',FILE,'tests/conftest.py','src/hpfracc/solvers/_weights.py','benchmarks/numerical/implicit_validation.py','pyproject.toml','uv.lock']
def hashes():
    return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources if (ROOT/p).is_file()}
result={'source_sha256_before':hashes(),'runs':[]}
(OUT/'runs.json').write_text(json.dumps(result,indent=2))
for name, select in [('target-file',[FILE,'-k',TARGET]),('full-collection',['-k',TARGET]),('whole-file',[FILE])]:
    cmd=['uv','run','--frozen','--no-sync','--extra','dev','--extra','cuda13','python','-m','pytest','-q','-p','no:cacheprovider',*select,'--basetemp',str(OUT/(name+'-tmp')),'--junitxml',str(OUT/(name+'.xml'))]
    started=time.time()
    row={'name':name,'argv':cmd,'command':shlex.join(cmd),'explicit_environment':{k:env[k] for k in ('UV_PROJECT_ENVIRONMENT','JAX_PLATFORMS','XLA_PYTHON_CLIENT_PREALLOCATE','PYTHONDONTWRITEBYTECODE','UV_CACHE_DIR','HYPOTHESIS_STORAGE_DIRECTORY')},'started_unix':started}
    print('START',name,row['command'],flush=True)
    with (OUT/(name+'.log')).open('wb') as log:
        try:
            p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
            row['pid']=p.pid
            try: row['exit_code']=p.wait(timeout=105)
            except subprocess.TimeoutExpired:
                p.terminate()
                try: p.wait(timeout=10)
                except subprocess.TimeoutExpired: p.kill(); p.wait()
                row.update(exit_code=p.returncode,timed_out=True)
        except Exception as exc: row['launch_error']=repr(exc)
    row['elapsed_seconds']=time.time()-started
    xml=OUT/(name+'.xml')
    if xml.exists():
        tree=ET.parse(xml)
        row['suites']=[x.attrib for x in tree.iter('testsuite')]
        row['properties']=[x.attrib for x in tree.iter('property')]
        row['enumerated_tests']=len(list(tree.iter('testcase')))
        row['xml_sha256']=hashlib.sha256(xml.read_bytes()).hexdigest()
    print(json.dumps(row,indent=2),flush=True)
    result['runs'].append(row)
    result['source_sha256_after']=hashes()
    (OUT/'runs.json').write_text(json.dumps(result,indent=2))
print('COMPLETE',str(OUT/'runs.json'),flush=True)
