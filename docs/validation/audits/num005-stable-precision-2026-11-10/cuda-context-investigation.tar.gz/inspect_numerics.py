import pathlib,os,subprocess,json,shlex,time
OUT=pathlib.Path(__file__).parent
ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
env=os.environ.copy();env.update(UV_PROJECT_ENVIRONMENT=str(pathlib.Path.home()/'.local/share/hpfracc/venv-cuda13'),JAX_PLATFORMS='cuda,cpu',XLA_PYTHON_CLIENT_PREALLOCATE='false',PYTHONDONTWRITEBYTECODE='1',UV_CACHE_DIR=str(OUT/'uv-cache'),HYPOTHESIS_STORAGE_DIRECTORY=str(OUT/'hypothesis'),CUDA_CACHE_PATH=str(OUT/'cuda-driver-cache'))
cmd=['uv','run','--frozen','--no-sync','--extra','dev','--extra','cuda13','python','-c',"import numpy as np, pathlib, json; o=pathlib.Path('/home/davianc/.hermes/cache/scratch/num005-context-probe-20261111'); r={};\nfor e in ['stable','direct']:\n a=np.load(o/'observed-1'/f'{e}-observed.npz');b=np.load(o/'observed-4'/f'{e}-observed.npz');x=a['states'];y=b['states']; r[e]={'max_abs_state_difference':float(np.max(np.abs(x.astype(np.float64)-y.astype(np.float64)))),'different_state_count':int(np.count_nonzero(x!=y)),'max_ulp_difference':int(np.max(np.abs(x.view(np.int32).astype(np.int64)-y.view(np.int32).astype(np.int64)))),'times_equal':bool(np.array_equal(a['times'],b['times'])),'peak_residual_indices':[int(np.argmax(a['residuals'])+1),int(np.argmax(b['residuals'])+1)]};\nprint(json.dumps(r,indent=2)); (o/'state-comparison.json').write_text(json.dumps(r,indent=2))"]
start=time.time();p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=45)
print(p.stdout);print('EXIT_CODE',p.returncode)
(OUT/'inspect-state-numerics.log').write_text(p.stdout)
(OUT/'inspect-state-numerics-command.json').write_text(json.dumps({'command':shlex.join(cmd),'exit_code':p.returncode,'elapsed_seconds':time.time()-start},indent=2))
