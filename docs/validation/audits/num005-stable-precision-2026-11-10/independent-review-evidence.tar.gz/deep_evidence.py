import hashlib, io, json, pathlib, tarfile, difflib, math, subprocess
import numpy as np
from benchmarks.numerical.implicit_validation import independent_residuals
R=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
B=R/'docs/validation/audits/num005-stable-precision-2026-11-10'
def sha(b): return hashlib.sha256(b).hexdigest()
def archive(name):
    with tarfile.open(B/name,'r:gz') as tf:
        return {m.name:tf.extractfile(m).read() for m in tf if m.isfile()}
c=archive('cuda-context-investigation.tar.gz')
for obs in ('observed-1','observed-4'):
    for mode in ('stable','direct'):
        with np.load(io.BytesIO(c[f'{obs}/{mode}-observed.npz']),allow_pickle=False) as d:
            print('RAW_FIELDS',obs,mode,[(k,d[k].shape,str(d[k].dtype)) for k in d.files])
            states=d['states'].astype(np.float64); times=d['times']
            res=independent_residuals('half_decay',times,states,30.,.5,np.ones(1),1e-5,1e-7)
            print('HOST_CONTEXT_REPLAY',obs,mode,float(res.max()))
        assert c[f'observed-1/{mode}-stablehlo.txt']==c[f'observed-4/{mode}-stablehlo.txt']
for mode in ('stable','direct'):
    a=c[f'observed-1/{mode}-optimized-hlo.txt'].decode().splitlines()
    b=c[f'observed-4/{mode}-optimized-hlo.txt'].decode().splitlines()
    delta=list(difflib.unified_diff(a,b,n=0))
    print('OPTIMIZED_HLO_CHANGED_LINES',mode,len(delta))
    for line in delta:
        if line.startswith(('+','-')) and ('kind' in line or 'fingerprint' in line): print(line[:1800])
for name in ('additional-gates.json','examples.json'):
    records=json.loads((B/name).read_text())
    for rec in records:
        assert sha((B/rec['artifact']).read_bytes())==rec['sha256']
        assert rec['exit_code']==0
    print('ADDITIONAL_HASHES',name,len(records),'verified')
for name in ('red-regressions.json','green-regressions.json','installed-wheel-smoke.json','wheel-provenance.json'):
    print('RECORD',name,(B/name).read_text())
a=archive('independent-analysis.tar.gz')
for name in ('num005_basis.py','num005_crosscheck.py','num005_replay.py'):
    print('ARCHIVED_SOURCE',name,a[name].decode())
print('BASIS_NPZ_FIELDS')
with np.load(io.BytesIO(a['num005_basis/raw.npz']),allow_pickle=False) as d:
    print([(k,d[k].shape,str(d[k].dtype)) for k in d.files])
    r=json.loads(a['num005_basis/report.json'])
    assert math.isclose(math.fsum(r['components_signed'].values()),r['residual_reference'],rel_tol=1e-9)
    assert r['components_scaled_signed']['history_dot_product_and_reduction']>1
print('DECOMPOSITION_SUM_VERIFIED')
