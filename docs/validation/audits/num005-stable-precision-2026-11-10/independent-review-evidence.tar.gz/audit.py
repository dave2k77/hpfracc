import subprocess, hashlib, pathlib, json, re, tarfile, io, gzip, csv, collections, xml.etree.ElementTree as ET
ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
BASE=pathlib.Path('docs/validation/audits/num005-stable-precision-2026-11-10')
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(b): return hashlib.sha256(b).hexdigest()
def staged(p): return git('show', ':'+str(p))
names=git('diff','--cached','--name-only','-z').decode().split('\0')[:-1]
added=0; bad=[]; screening=[]; inventory=[]
patterns=[r'(api_key|secret|password|token|passwd)\s*=\s*[\'\"][^\'\"]{6,}[\'\"]',r'os\.system\(|subprocess.*shell=True',r'\beval\(|\bexec\(',r'pickle\.loads?\(',r'execute\(f\"|\.format\(.*SELECT|\.format\(.*INSERT']
for name in names:
    patch=git('diff','--cached','--no-ext-diff','--',name).decode()
    assert patch.startswith('diff --git ')
    b=staged(name)
    if b!=(ROOT/name).read_bytes(): bad.append(name)
    lines=[line[1:] for line in patch.splitlines() if line.startswith('+') and not line.startswith('+++')]
    added+=len(lines)
    for n,line in enumerate(lines):
        if any(re.search(p,line,re.I) for p in patterns): screening.append([name,n,line])
    inventory.append({'path':name,'bytes':len(b),'diff_sha256':sha(patch.encode())})
scan=json.loads(staged(BASE/'static-scan.json'))
excluded=git('diff','--cached','--no-ext-diff','--','.',':(exclude)'+str(BASE/'static-scan.json'))
candidates={}
for opts in ([],['--binary'],['--no-color'],['--binary','--no-color'],['--full-index'],['--unified=0'],['--no-renames'],['--no-prefix'],['--src-prefix=a/','--dst-prefix=b/']):
    d=git('diff','--cached','--no-ext-diff',*opts,'--','.',':(exclude)'+str(BASE/'static-scan.json'))
    candidates[' '.join(opts)]=sha(d)
print('SCAN_HASH_CANDIDATES',candidates,'recorded',scan['staged_diff_sha256'])
assert scan['staged_diff_sha256'] in candidates.values()
assert added-9==scan['added_text_lines_scanned']
assert len(names)-1==scan['staged_files_checked_byte_for_byte']
print('STAGED',json.dumps({'files':len(names),'added_lines':added,'worktree_mismatches':bad,'screening_findings':screening,'scan_diff_hash_verified':True}))
assert not bad
archives={}
for manifest_name,archive_name,source in [('before-checkpoint.json','before-sources.tar.gz','HEAD'),('suite-source-inputs.json','suite-sources.tar.gz',':'),('independent-analysis-manifest.json','independent-analysis.tar.gz',None),('cuda-context-investigation-manifest.json','cuda-context-investigation.tar.gz',None)]:
    m=json.loads(staged(BASE/manifest_name)); archive=staged(BASE/archive_name)
    assert sha(archive)==m['archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tf:
        contents={}
        for member in tf.getmembers():
            p=pathlib.PurePosixPath(member.name)
            assert not p.is_absolute() and '..' not in p.parts
            assert member.isfile() or member.isdir()
            if member.isfile():
                assert member.name not in contents
                contents[member.name]=tf.extractfile(member).read()
    expected=m['source_sha256'] if source else m['files']
    assert set(contents)==set(expected),(archive_name,set(contents)^set(expected))
    for path,rec in expected.items():
        checksum=rec['sha256'] if isinstance(rec,dict) else rec
        assert sha(contents[path])==checksum,(archive_name,path)
        if isinstance(rec,dict) and 'bytes' in rec: assert len(contents[path])==rec['bytes']
        if source:
            ref=('HEAD:'+path) if source=='HEAD' else (':'+path)
            assert sha(git('show',ref))==checksum,(archive_name,path,'source')
    archives[archive_name]=contents
    print('ARCHIVE',archive_name,len(contents),'all hashes/source bytes verified')
for name in ('compatibility-manifest.json',):
    m=json.loads(staged(BASE/name))
    for path,h in m['files'].items(): assert sha(staged(BASE/'compatibility'/path))==h
    assert sha(staged('tests/unit/test_history_reduction_compatibility.py'))==m['test_source_sha256']
for name in names:
    p=pathlib.Path(name)
    if p.suffix=='.xml' or name.endswith('.xml.gz'):
        b=staged(name)
        if name.endswith('.gz'): b=gzip.decompress(b)
        root=ET.fromstring(b)
        suites=[root] if root.tag=='testsuite' else root.findall('testsuite')
        print('XML',str(p.relative_to(BASE)),[{**{k:s.attrib.get(k) for k in ('tests','failures','errors','skipped')},'enumerated':len(s.findall('testcase')),'properties':{q.attrib['name']:q.attrib['value'] for q in s.findall('./properties/property')}} for s in suites])
    elif p.suffix=='.csv':
        rows=list(csv.DictReader(io.StringIO(staged(name).decode())))
        print('CSV',p.name,'rows',len(rows))
    elif p.suffix=='.json' and name.startswith(str(BASE)) and not p.name.startswith('scientific_acceptance_'):
        m=json.loads(staged(name))
        def compact(x):
            if isinstance(x,dict):
                return {k:(f'{len(v)} entries' if k in ('source_sha256','files') and isinstance(v,dict) else compact(v)) for k,v in x.items()}
            if isinstance(x,list): return [compact(v) for v in x]
            return x
        if p.name not in ('before-checkpoint.json','independent-analysis-manifest.json','cuda-context-investigation-manifest.json','suite-source-inputs.json','verification-before-citation-guard.json','verification.json','static-scan.json','compatibility-manifest.json'):
            print('JSON',str(p.relative_to(BASE)),json.dumps(compact(m)))
print('BASIS_REPORT',archives['independent-analysis.tar.gz']['num005_basis/report.json'].decode())
print('CROSSCHECK_REPORT',archives['independent-analysis.tar.gz']['num005_crosscheck/report.json'].decode())
print('CONTEXT_REPORT',archives['cuda-context-investigation.tar.gz']['validation-report.json'].decode())
print('CONTEXT_COMPARISON',archives['cuda-context-investigation.tar.gz']['state-comparison.json'].decode())
for backend in ('cpu','cuda'):
    p=pathlib.Path('/home/davianc/.hermes/cache/scratch/num005-independent-review')/(backend+'.xml')
    s=ET.fromstring(p.read_bytes()).find('testsuite')
    print('REVIEW_TEST_RESULT',backend,s.attrib,{q.attrib['name']:q.attrib['value'] for q in s.findall('./properties/property')})
pathlib.Path('/home/davianc/.hermes/cache/scratch/num005-independent-review/inventory.json').write_text(json.dumps(inventory,indent=2))
