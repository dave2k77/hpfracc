"""Private host mathematical tracer, not a numerical certificate or solver.

For D_C**alpha y = feedback*y, reconstruct Y(t) = initial. The real-arithmetic
Volterra defect has sup d = |feedback*initial|*T**alpha/Gamma(1+alpha). When
kappa = |feedback|*T**alpha/Gamma(1+alpha) < 1, contraction propagation gives
|y-Y| <= d/(1-kappa). Ordinary mpmath evaluation is NOT outward-rounded proof.
"""

from dataclasses import dataclass

import mpmath as mp


@dataclass(frozen=True, slots=True)
class FeedbackDiagnostic:
    status: str
    raw_defect: str
    kappa: str
    model_error_bound: str | None
    comparison_budget: str
    conditional_within_budget: bool
    arithmetic_verified: bool = False
    total_numerical_certified: bool = False


def constant_candidate_envelope(
    *, order, feedback, initial, horizon, atol, rtol=0
):
    """Evaluate a conditional affine-feedback model bound at 80 digits.

    Inputs are interpreted at their supplied/represented values. This is only
    the constant-candidate tracer; it does not certify an arbitrary trajectory,
    controller, stiff regime, nonlinear tube or working-precision computation.
    """
    with mp.workdps(80):
        alpha, strength, y0, time, absolute, relative = map(
            mp.mpf, (order, feedback, initial, horizon, atol, rtol)
        )
        if not all(mp.isfinite(v) for v in (
            alpha, strength, y0, time, absolute, relative
        )):
            raise ValueError("Finite real inputs are required")
        if not 0 < alpha < 1 or time <= 0 or absolute <= 0 or relative < 0:
            raise ValueError("Require 0<order<1, horizon>0, atol>0 and rtol>=0")
        scale = time**alpha / mp.gamma(1 + alpha)
        kappa = abs(strength) * scale
        defect = abs(strength * y0) * scale
        budget = (absolute + relative * abs(y0)) / (1 + relative)
        if kappa >= 1:
            return FeedbackDiagnostic(
                status="outside_contraction_scope",
                raw_defect=mp.nstr(defect, 70),
                kappa=mp.nstr(kappa, 70),
                model_error_bound=None,
                comparison_budget=mp.nstr(budget, 70),
                conditional_within_budget=False,
            )
        bound = defect / (1 - kappa)
        return FeedbackDiagnostic(
            status="conditional_exact_arithmetic_model",
            raw_defect=mp.nstr(defect, 70),
            kappa=mp.nstr(kappa, 70),
            model_error_bound=mp.nstr(bound, 70),
            comparison_budget=mp.nstr(budget, 70),
            conditional_within_budget=bool(bound <= budget),
        )
