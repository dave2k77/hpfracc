"""First A1 tracer: feedback must propagate a nonzero Volterra defect."""

import importlib
from pathlib import Path

import mpmath as mp
import pytest

from feedback_enclosure import constant_candidate_envelope


def test_constant_feedback_encloses_reference_and_keeps_precision_limit_visible():
    assert Path(__file__).with_name("feedback_enclosure.py").is_file(), (
        "Private feedback-propagation prototype is not implemented"
    )
    evaluate = importlib.import_module("feedback_enclosure").constant_candidate_envelope
    result = evaluate(order="0.5", feedback="0.25", initial="1", horizon="1",
                      atol="0.4")
    with mp.workdps(80):
        actual_error = mp.exp(mp.mpf(1) / 16) * mp.erfc(-mp.mpf(1) / 4) - 1
        assert mp.mpf(result.raw_defect) < actual_error
        assert actual_error < mp.mpf(result.model_error_bound) < mp.mpf("0.4")
        assert result.conditional_within_budget is True
        assert result.arithmetic_verified is False
        assert result.total_numerical_certified is False


@pytest.mark.parametrize("budget,expected", [("0.3", False), ("0.4", True)])
def test_budget_comparison_does_not_drop_feedback_propagation(budget, expected):
    result = constant_candidate_envelope(
        order="0.5", feedback="0.25", initial="1", horizon="1", atol=budget
    )
    with mp.workdps(80):
        assert mp.mpf(result.raw_defect) < mp.mpf("0.3")
        assert mp.mpf(result.model_error_bound) > mp.mpf("0.3")
    assert result.conditional_within_budget is expected
    assert not result.arithmetic_verified and not result.total_numerical_certified


def test_large_contraction_is_inapplicable_not_solver_instability():
    result = constant_candidate_envelope(
        order="0.5", feedback="1", initial="1", horizon="1", atol="1"
    )
    assert result.status == "outside_contraction_scope"
    assert result.model_error_bound is None
    assert result.conditional_within_budget is False
    assert result.total_numerical_certified is False


@pytest.mark.parametrize("feedback", ["0.25", "-0.25"])
def test_absolute_feedback_scaling_and_scoped_precision(feedback):
    with mp.workdps(37):
        before = mp.mp.dps
        small = constant_candidate_envelope(
            order="0.5", feedback=feedback, initial="1", horizon="1", atol="0.4"
        )
        large = constant_candidate_envelope(
            order="0.5", feedback=feedback, initial="2", horizon="1", atol="0.8"
        )
        assert mp.mp.dps == before
    with mp.workdps(80):
        assert small.kappa == large.kappa
        assert mp.almosteq(mp.mpf(large.model_error_bound),
                           2 * mp.mpf(small.model_error_bound), rel_eps=mp.mpf("1e-68"))
    assert small.conditional_within_budget is large.conditional_within_budget is True


@pytest.mark.parametrize("key,value", [
    ("order", "0"), ("order", "1"), ("order", "nan"),
    ("feedback", "inf"), ("initial", "nan"),
    ("horizon", "0"), ("atol", "0"), ("rtol", "-0.1"),
])
def test_invalid_inputs_cannot_produce_a_conditional_acceptance(key, value):
    values = dict(order="0.5", feedback="0.25", initial="1", horizon="1",
                  atol="0.4", rtol="0")
    values[key] = value
    with pytest.raises(ValueError):
        constant_candidate_envelope(**values)


def test_relative_budget_uses_a_conservative_reference_scale():
    result = constant_candidate_envelope(
        order="0.5", feedback="0.25", initial="1", horizon="1",
        atol="0.2", rtol="0.3",
    )
    with mp.workdps(80):
        expected = (mp.mpf("0.2") + mp.mpf("0.3")) / (1 + mp.mpf("0.3"))
        assert mp.almosteq(mp.mpf(result.comparison_budget), expected,
                           rel_eps=mp.mpf("1e-68"))
