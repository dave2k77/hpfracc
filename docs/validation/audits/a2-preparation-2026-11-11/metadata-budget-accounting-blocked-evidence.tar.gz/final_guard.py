"""Final fail-closed guards: no packet or protected input was edited."""
import hashlib,json,subprocess
from pathlib import Path
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');O=Path(__file__).parent
B=json.loads(Path('/home/davianc/.hermes/cache/scratch/a2-budget-revision-approved-20261112/baseline.json').read_text());I=json.loads((O/'initial-guards.json').read_text())
def h(b):return hashlib.sha256(b).hexdigest()
result={}
for group in ['numerical_inputs','protected_files','packet_before']:
 rows=[]
 for rel,desc in B[group].items():
  b=(R/rel).read_bytes();wanted=desc if type(desc) is str else desc['sha256'];assert h(b)==wanted,(group,rel)
  if type(desc) is dict:assert len(b)==desc['bytes']
  rows.append(dict(path=rel,bytes=len(b),sha256=h(b)))
 result[group]=rows
for rel in B['parent_status_paths']:
 b=(R/rel).read_bytes();assert h(b)==I[rel]['sha256'] and len(b)==I[rel]['bytes']
result['HEAD']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert result['HEAD']==B['repo_head']
result['index_sha256']=h((R/'.git/index').read_bytes());assert result['index_sha256']==B['git_index_sha256']
result['stage_entries_sha256']=h(subprocess.check_output(['git','ls-files','--stage'],cwd=R));assert result['stage_entries_sha256']==B['index_entries_sha256']
md=(R/'docs/developer/a2-compression-budget-protocol.md').read_bytes();hdr=b'## 4. Exact finite mathematical contract\n';m=hdr+md.split(hdr,1)[1].split(b'## 5.',1)[0]
assert len(m)==1699 and h(m)=='c6b59cae6d948222fdb9c5c0a6287491426864964207f45b747501b1970e1f9e'
result['mathematics']={'bytes':len(m),'sha256':h(m)}
result['parent_status_paths_unchanged']=True;result['repository_files_modified_by_this_attempt']=[]
result['current_caps']={k:json.loads((R/'docs/validation/audits/a2-preparation-2026-11-11/protocol.json').read_text())['caps'][k] for k in ['failure_index_bytes','json_nodes']}
result['all_guards_passed']=True
(O/'final-guards.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_guards_passed':True,'numerical_inputs':len(result['numerical_inputs']),'protected_files':len(result['protected_files']),'packet_files':len(result['packet_before']),'parent_status_paths_unchanged':True,'HEAD_index_stage_entries_unchanged':True,'mathematics':result['mathematics'],'current_caps':result['current_caps'],'repository_files_modified_by_this_attempt':[]},indent=2))
