import json
from pathlib import Path
A=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/docs/validation/audits/a2-preparation-2026-11-11')
f=json.loads((A/'fixtures.json').read_text());s=json.loads((A/'record-schemas.json').read_text())
c=next(x for x in f['cases'] if x['case_id']=='FIT-ramp-tau1-f32-GL')
print(json.dumps({'inventory_rules':f['preinventory_rules'],'real_inventory':f['real_worker_inventory'],'exact_inventory':f['exact_slot_inventory'],'slots_by_mode_branch':{str((mode,branch)): [z['quantity'] for z in c['required_evidence_slots'] if (z['mode'],z['branch'],z['candidate_index'])==(mode,branch,ci)] for mode,branch,ci in dict.fromkeys((z['mode'],z['branch'],z['candidate_index']) for z in c['required_evidence_slots']) if ci in [0,None]},'cross_mode_comparisons':[z for z in c['required_working_comparisons'] if z['mode'] not in ['eager','jit'] or 'eager_jit' in z['policy_id']],'checks':c['required_fit_identity_checks'][:16],'request_caps':s['$defs']['request']['properties']['caps'],'index_artifact':s['$defs']['index_artifact'],'defs':list(s['$defs'])},indent=2))
