"""Capture real scratch-only process attempts with immutable receipts."""
import json,os,subprocess,sys,time,hashlib
from pathlib import Path
O=Path(__file__).parent
name=sys.argv[1];cmd=sys.argv[2:];d=O/name;d.mkdir(exist_ok=False)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(O/'tmp'))
(O/'tmp').mkdir(exist_ok=True)
t=time.monotonic_ns()
with (d/'stdout.bin').open('wb') as out,(d/'stderr.bin').open('wb') as err:
 p=subprocess.run(cmd,cwd='/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc',env=env,stdout=out,stderr=err)
r={'command':cmd,'cwd':str(Path.cwd()),'exit':p.returncode,'elapsed_ns':time.monotonic_ns()-t,'label':'ACTUAL CHECKER PROCESS, not a numerical worker','streams':{k:{'bytes':len((d/k).read_bytes()),'sha256':hashlib.sha256((d/k).read_bytes()).hexdigest()} for k in ['stdout.bin','stderr.bin']}}
(d/'process.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
print((d/'stdout.bin').read_text(errors='replace')[-6000:]);print((d/'stderr.bin').read_text(errors='replace')[-6000:]);sys.exit(p.returncode)
