"""Read-only prerequisite discovery and fresh scope pins. No numerical imports."""
import hashlib,json,subprocess
from pathlib import Path
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
A=R/'docs/validation/audits/a2-preparation-2026-11-11'
O=Path(__file__).parent
B=json.loads(Path('/home/davianc/.hermes/cache/scratch/a2-budget-revision-approved-20261112/baseline.json').read_text())
def h(b): return hashlib.sha256(b).hexdigest()
checks={}
for group in ['numerical_inputs','protected_files','packet_before']:
 for name,d in B[group].items():
  b=(R/name).read_bytes(); want=d if isinstance(d,str) else d['sha256']; assert h(b)==want,(group,name)
 checks[group]=len(B[group])
assert h((R/'.git/index').read_bytes())==B['git_index_sha256']
assert h(subprocess.check_output(['git','ls-files','--stage'],cwd=R))==B['index_entries_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==B['repo_head']
checks.update(head=B['repo_head'],index_bytes=B['git_index_sha256'],index_entries=B['index_entries_sha256'])
checks['status_before']=subprocess.check_output(['git','status','--short'],cwd=R,text=True)
for name in B['parent_status_paths']:
 checks[name]={'sha256':h((R/name).read_bytes()),'bytes':len((R/name).read_bytes())}
(O/'initial-guards.json').write_text(json.dumps(checks,indent=2)+'\n')
S=json.loads((A/'record-schemas.json').read_text()); F=json.loads((A/'fixtures.json').read_text()); W=json.loads((A/'schema-control-fixtures.json').read_text())
summary={'guards':checks,'schema_top':{k:v for k,v in S.items() if k!='$defs'},'definitions':{k: {'keys':v.get('required'),'properties':v.get('properties')} for k,v in S['$defs'].items() if k in ['failure_index','index_slot','process','launch_receipt','supervisor_export','caps','metadata','phase_timing','artifact','binding_check','comparison','output_control','input_bundle']},'fixture_top':list(F),'case':next(x for x in F['cases'] if x['case_id']=='FIT-ramp-tau1-f32-GL'),'tau0':next(x for x in F['cases'] if x['case_id']=='FIT-ramp-tau0-f32-GL'),'witness_top':list(W),'bundle_summary':[{k:v for k,v in x.items() if k not in ['artifacts','initial_failure_index']} for x in W['bundles']]}
(O/'packet-filtered.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'guards':checks,'filtered':str(O/'packet-filtered.json'),'schema_keys':list(S),'fixture_keys':list(F),'witness_keys':list(W)},indent=2))
