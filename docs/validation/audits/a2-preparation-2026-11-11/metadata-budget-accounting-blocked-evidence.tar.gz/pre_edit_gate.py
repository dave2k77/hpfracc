"""Pre-edit gate: projected sizes are NOT valid linked export admission."""
import json
from pathlib import Path
O=Path(__file__).parent
x=json.loads((O/'accounted-before/sample-STATIC-METADATA-PROJECTION.json').read_text())
r=x['records'];idx=r['failure-index.json']
missing=[z['artifact']['path'] for z in idx['slots'] if z['artifact'] is not None and z['artifact']['path'] not in r]
proof={'passed':False,'gate':'VALID_LINKED_METADATA_EXPORT_BEFORE_ANY_PACKET_EDIT','missing_conditional_artifact_obligations':len(missing),'examples':missing[:8],'why_not_a_packet_defect':'This scratch projection intentionally contains no future fitted payloads. It is a type/disposition projection, not a linked valid selected export and cannot discharge the requested pre-edit gate.','snapshot_gap':'bytes_accounting currently sums only rendered metadata and the old index, not the conditional slot files, result copies, observation/binding records and run manifest. The separate 2 MiB ancillary allowance is not a computed closed export transaction.','tentative_caps_not_applied':{'failure_index_bytes':1048576,'json_nodes':65536},'tentative_bounds_not_accepted_as_valid_export_proof':True,'required_action':'Stop before repository edits; do not treat necessary lower-bound tests, shape-only node algebra or conditional file-size assignments as full semantic export admission. Preserve current packet, report blocker to parent for independent decision.','no_numerical_impossibility_claim':True,'implementation_authorized':False,'a2_acceptance_passed':False,'arithmetic_verified':False,'total_numerical_certified':False}
(O/'pre-edit-gate-failed.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
assert not missing, 'Pre-edit valid linked export gate fails: conditional artifacts are absent; no packet edit permitted'
