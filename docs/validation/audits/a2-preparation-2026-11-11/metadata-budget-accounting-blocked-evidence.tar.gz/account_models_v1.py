"""STATIC/HYPOTHETICAL METADATA PROJECTION, not worker/process/fitter output.
No fit arrays are constructed. Complete index artifacts denote CONDITIONAL
obligations on future actual immutable files, not observations/authentication.
"""
from audit_defs import *
import itertools,sys
from collections import Counter
D=Path(__file__).parent if 'Path' in globals() else pathlib.Path(__file__).parent
DEST=D/sys.argv[1];DEST.mkdir(exist_ok=False)
# Existing 64-byte ID, 32x256 printable-ASCII argv and signed-63-bit timing
# limits. Quotes/backslashes maximize canonical JSON escaping, not execution.
CMD=['\\"'*128]*32
ID='hyp-'+('x'*60)
T=(1<<63)-1
FIX=next(b for b in W['bundles'] if b['kind']=='full')['artifacts']
source_paths=['src/hpfracc/ops/_soe.py','src/hpfracc/ops/fractional.py','uv.lock','docs/developer/a2-compression-budget-protocol.md']
source_paths+= [z['repo_path'] for z in P['preparation_source_pin']['files'] if z['repo_path'] not in source_paths][:121]
SOURCES=[dict(repo_path=z,sha256=sha((R/z).read_bytes())) for z in source_paths]
assert len(SOURCES)==125 and len({z['repo_path'] for z in SOURCES})==125

def phase(a,b):return dict(status='observed',start_ns=a,end_ns=b,elapsed_ns=b-a,reason='none')
def receipts(q,ib,kind='normal'):
 bh=digest(ib); a={k:copy.deepcopy(FIX[k]) for k in ['records/process.json','records/launch.json','records/export.json','records/output-control.json']}
 pr=a['records/process.json'];la=a['records/launch.json'];ex=a['records/export.json'];oc=a['records/output-control.json']
 for x in [pr,la,ex]:
  x.update(run_id=ID,process_id=ID,case_id=q['case_id'],input_bundle_sha256=bh)
 for x in [pr,la]:x.update(request_id=q['request_id'],command=CMD[:])
 la.update(pid=2147483647,launch_monotonic_ns=T-200000000000,status='launched',barrier='held',sources=copy.deepcopy(SOURCES))
 pr.update(launch_receipt_sha256=digest(la),exit_code=0,termination='normal',elapsed_monotonic_ns=59999999999,watchdog_triggered=False,stdout_sha256='a'*64,stderr_sha256='b'*64,stdout_truncated=False,stderr_truncated=False,exit_confirmed=True,barrier='released',phases={'preflight':phase(T-400000000000,T-200000000001),'watchdog':phase(T-200000000000,T-140000000001),'grace':pending_phase(),'kill_to_exit':pending_phase()})
 if kind=='timeout':
  pr.update(exit_code=-9,termination='kill',watchdog_triggered=True,elapsed_monotonic_ns=61000000001)
  pr['phases'].update(watchdog=phase(T-200000000000,T-138999999999),grace=phase(T-140000000000,T-139000000000),kill_to_exit=phase(T-139000000000,T-138999999999))
 ex.update(process_sha256=digest(pr),failure_index_sha256='f'*64,failure_index_bytes=0,index_write=phase(T-100000000000,T-1),status='complete',reasons=['none'])
 oc.update(request_id=q['request_id'],root_token=ID)
 for path,x in a.items():ns['route'](path,x);ns['nested'](x)
 return a

def slot_state(z,winner,derivative):
 ci=z['candidate_index'];branch=z['branch'];k=z['quantity']
 # Base exact references (including analytic target) remain all-candidate.
 if ci is not None and branch not in ['base','exact'] and not derivative:return 'stage_not_used'
 if ci is not None and branch not in ['base','exact'] and ci!=winner:return 'unselected_candidate'
 if (k=='h' and branch in ['base','ad-base']) or (k=='direction' and (branch=='base' or branch.startswith('order-'))):return 'unused_quantity'
 return None

def profile(case,winners,large=True):
 q=expand(case);ib=inputbundle(case,q,True)
 ib['sources']=copy.deepcopy(SOURCES)
 # Input bundle retains exact scientific input and candidate specifications.
 schema(ib,S);nested(ib)
 rr=receipts(q,ib);pr=rr['records/process.json'];bh=digest(ib)
 old=initial_index(case,q,ib);old['process'].update(run_id=ID,process_id=ID,command=CMD[:])
 old['process']['phases']['preflight']=phase(T-400000000000,T-200000000001)
 schema(old,S)
 ix=copy.deepcopy(old);ix['process']=copy.deepcopy(pr)
 tau1=case['request']['tau']=={'num':'1','den':'1'}
 agree=winners[0]==winners[1] and winners[0] is not None
 derivative=tau1 and agree
 for z in ix['slots']:
  winner=winners[0] if z['mode'] not in ['eager','jit'] else winners[0 if z['mode']=='eager' else 1]
  reason=slot_state(z,winner,derivative)
  if reason:
   z.update(status='not_applicable',reason=reason,reasons=[reason],completed_shape=None,artifact=None)
  else:
   # Opaque conditional metadata descriptor: no payload or fit is manufactured.
   # 4096 is a hypothetical file-length assignment, NOT a runtime upper bound.
   z.update(status='complete',reason='none',reasons=['none'],completed_shape=z['expected_shape'][:],artifact=dict(path='arrays/'+z['slot_id']+'.json',bytes=4096,sha256='f'*64))
 for z,decl in zip(ix['comparisons'],case.get('required_working_comparisons',[])):
  applies=decl['scope']=='all_candidates' or decl['candidate_index'] is None or (derivative and decl['candidate_index']==winners[0])
  reason='singleton_fd_adjacency' if applies and z['a_slot_id'] is None else 'stage_not_used' if not derivative and decl['scope']!='all_candidates' and decl['candidate_index'] is not None else 'unselected_candidate'
  z.update(status='pass' if applies and z['a_slot_id'] else 'not_applicable',reasons=['none'] if applies and z['a_slot_id'] else [reason])
 for z in ix['binding_checks']:
  winner=winners[0 if z['mode']=='eager' else 1]
  applies=z['branch']=='base' or (derivative and z['candidate_index']==winner)
  z.update(status='pass' if applies else 'not_applicable',reasons=['none'] if applies else ['unselected_candidate' if derivative else 'stage_not_used'],observation_id=ID if applies else None,reference_observation_id=ID if applies else None)
 # A single ID may not refer to distinct invocations: retain full 64-char unique IDs.
 for i,z in enumerate(ix['binding_checks']):
  if z['status']=='pass':
   def oid(branch):
    prefix=f"hyp-{z['mode']}-{z['candidate_index']}-{branch}-"
    return prefix+'x'*(64-len(prefix))
   z['observation_id']=oid(z['branch']);z['reference_observation_id']=oid(z['reference_branch'])
 status='complete' if (tau1 and agree) or (not tau1 and winners==(None,None)) else 'indeterminate'
 ix.update(status=status,reasons=['none'] if status=='complete' else ['gate_contradiction'])
 # Both old and new indices charge actual serialized metadata; other emitted
 # numerical artifacts are represented by conditional allocation only.
 before=len(enc(ib))+len(enc(old))+sum(len(enc(v)) for k,v in rr.items() if k!='records/export.json')
 ix['bytes_accounting'].update(live_bytes=before,cumulative_written_bytes=before,reserved_final_transaction_bytes=0)
 ex=rr['records/export.json'];ex.update(failure_index_sha256=digest(ix),failure_index_bytes=len(enc(ix)))
 for x in [ix,old]:schema(x,S)
 # Validate projection semantics without pretending hashes authenticate missing
 # future payloads. Artifact content/readback remains explicitly conditional.
 inv=ib['required_slots'];assert len(inv)==len(ix['slots'])
 for z,t in zip(ix['slots'],inv):
  assert all(z[k]==v for k,v in t.items()) and z['expected_shape']==expect_shape(z,q)
  assert (z['candidate_id'] is None)==(z['candidate_index'] is None)
  assert z['reason']==z['reasons'][0]
  if z['status']=='complete':assert z['completed_shape']==z['expected_shape'] and z['artifact']['path']=='arrays/'+z['slot_id']+'.json'
  else:assert z['artifact'] is z['completed_shape'] is None and z['reason'] in S['x-disposition-table']['slot_inapplicable']['reasons']
 rows={z['slot_id']:z for z in ix['slots']}
 for z in ix['comparisons']:
  disposition(z)
  if z['status']=='pass':assert all(rows[z[k]]['status']=='complete' for k in ['a_slot_id','reference_slot_id'])
 for key,invkey in [('comparisons','required_comparisons'),('binding_checks','required_binding_checks')]:
  assert len(ix[key])==len(ib[invkey])
  for z,t in zip(ix[key],ib[invkey]):assert all(z[k]==v for k,v in t.items());disposition(z)
 assert ix['process']==pr and pr['launch_receipt_sha256']==digest(rr['records/launch.json'])
 assert ex['failure_index_sha256']==digest(ix) and ex['process_sha256']==digest(pr)
 assert pr['phases']['preflight']['end_ns']<pr['phases']['watchdog']['start_ns']<pr['phases']['watchdog']['end_ns']<=ex['index_write']['start_ns']
 for x in list(rr.values())+[old,ix]:schema(x,S)
 sizes={'input_bundle':len(enc(ib)),'initialized_index':len(enc(old)),'replacement_index':len(enc(ix)),**{k:len(enc(v)) for k,v in rr.items()}}
 transaction=sizes['initialized_index']+sizes['replacement_index']+sum(sizes[k] for k in rr)
 records={'input-bundle.json':ib,'initial_failure_index':old,'failure-index.json':ix,**rr}
 row={'case_id':case['case_id'],'winners':list(winners),'derivatives_active':derivative,'sizes':sizes,'transaction_bytes':transaction,'record_nodes':{k:tree(v)[0] for k,v in records.items()},'record_depth':{k:tree(v)[1] for k,v in records.items()},'slot_dispositions':dict(Counter((z['status']+':'+z['reason']) for z in ix['slots'])),'comparison_dispositions':dict(Counter(z['status']+':'+z['reasons'][0] for z in ix['comparisons'])),'binding_dispositions':dict(Counter(z['status']+':'+z['reasons'][0] for z in ix['binding_checks'])),'old_rejected_byte':transaction>P['caps']['failure_index_bytes'],'old_rejected_nodes':[k for k,v in records.items() if tree(v)[0]>P['caps']['json_nodes']],'conditional_array_allocation':sum(z['artifact']['bytes'] for z in ix['slots'] if z['artifact'])}
 return row,records

rows=[];sample=None
for case in F['cases']:
 if case['group']!='FIT-REAL':continue
 for winners in itertools.product([None,0,1,2],repeat=2):
  row,records=profile(case,winners);rows.append(row)
  if case['case_id']=='FIT-stacked-tau1-f32-GL' and winners==(0,0):sample=records
# Full worst field/cardinality allowances for timeout receipts too.
q=expand(next(c for c in F['cases'] if c['case_id']=='FIT-stacked-tau1-f32-GL'))
ib=inputbundle(next(c for c in F['cases'] if c['case_id']==q['case_id']),q,True);ib['sources']=SOURCES
rr=receipts(q,ib,'timeout')
summary={'label':__doc__,'profile_count':len(rows),'positive_agreement_profiles':sum(z['derivatives_active'] for z in rows),'case_count':32,'selected_configurations_each_mode':[8,2,4],'required_mode_agreement':F['real_worker_inventory']['base_candidates'],'max_transaction_bytes':max(z['transaction_bytes'] for z in rows),'max_record_nodes':max(v for z in rows for v in z['record_nodes'].values()),'max_record_depth':max(v for z in rows for v in z['record_depth'].values()),'max_input_bundle_bytes':max(z['sizes']['input_bundle'] for z in rows),'max_single_index_bytes':max(z['sizes']['replacement_index'] for z in rows),'timeout_receipts_sizes':{k:len(enc(v)) for k,v in rr.items()},'maximum_conditional_array_allocation':max(z['conditional_array_allocation'] for z in rows),'field_headroom':{'command_arguments':32,'each_command_printable_ascii_bytes':256,'each_command_serialized_escaped_content_bytes':512,'run_process_root_and_observation_ID_bytes':64,'source_entries':125,'source_paths':'actual 125 pinned paths; not invented paths','timings':'ordered genuine integer ns near signed-63-bit maximum; no observed execution','artifact_file_bytes_assignment':4096,'artifact_bytes_assignment_is_NOT_a_runtime_bound':True},'limits':['These are complete valid TYPE/DISPOSITION metadata PROJECTIONS, not full observed exports.','Future raw/exact artifact payload identities and file lengths are conditional obligations, NOT authenticated/fabricated fit arrays.','No universal numerical evidence-size/feasibility claim: preflight still refuses out-of-budget valid requests.','All mismatching mode outcomes preserve stop gate; derivatives are not run under disagreement.']}
for name,obj in [('profiles.json',rows),('summary.json',summary),('sample-STATIC-METADATA-PROJECTION.json',{'label':__doc__,'records':sample})]:
 (DEST/name).write_text(json.dumps(obj,indent=2)+'\n')
print(json.dumps(summary,indent=2))
