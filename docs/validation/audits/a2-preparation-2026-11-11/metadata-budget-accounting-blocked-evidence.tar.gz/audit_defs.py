"""Scratch loader: definitions-only from inspected, pinned stdlib audit."""
import ast,hashlib
from pathlib import Path
B=Path('/home/davianc/.hermes/cache/scratch/a2-independent-final-complete-l_bwads9/independent_audit_v2.py')
raw=B.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='a9c82c13bcd690d75ffb378ca8415bf9e44d2d1fd5172b32bbe6528e13a9a041'
parsed=ast.parse(raw);selected=[]
for n in parsed.body:
 if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.ClassDef)):selected.append(n)
 elif isinstance(n,ast.Assign):
  names={x.id for t in n.targets for x in ast.walk(t) if isinstance(x,ast.Name)}
  if names & {'R','A','O','F','P','S','W','CP'}:selected.append(n)
ns={'__file__':__file__,'__name__':'scratch_only_definitions'}
exec(compile(ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[])),str(B),'exec'),ns)
ns['root_samples']={}
globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
