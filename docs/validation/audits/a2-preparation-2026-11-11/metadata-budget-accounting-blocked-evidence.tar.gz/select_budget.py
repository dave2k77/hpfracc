"""Finalize BEFORE-edit accounting and select exactly two bounded metadata caps."""
from audit_defs import *
D=pathlib.Path(__file__).parent
rows=json.loads((D/'accounted-before/profiles.json').read_text());summary=json.loads((D/'accounted-before/summary.json').read_text())
# Independent counting identity against every REAL STATIC sample payload in the
# already-reviewed hypothetical bundles, never against invented future fits.
n=0
for b in W['bundles']:
 for sl in b['artifacts'].values():
  if sl.get('record_type')!='slot':continue
  payload=sl['raw_array'] or sl['exact_array']
  if payload is None:continue
  pred=15+len(payload['shape']) if 'raw_hex' in payload else 5+len(payload['shape'])+5*math.prod(payload['shape'])
  assert tree(payload)[0]==pred;n+=1
positive=[z for z in rows if z['derivatives_active']]
assert len(positive)==48 and len({z['case_id'] for z in positive})==16
assert all(z['symbolic_node_accounting']['result_nodes']>32768 and z['old_rejected_byte'] for z in positive if '-f32-' in z['case_id'])
assert max(z['symbolic_node_accounting']['result_nodes'] for z in rows)==51560
# Bound widening WITHOUT changing immutable field/cardinality caps. 32 argv
# entries and maximally escaped 256-char strings are ALREADY rendered.
# Source path padding applies once to launch (input is a separate reservation).
source_paths=['src/hpfracc/ops/_soe.py','src/hpfracc/ops/fractional.py','uv.lock','docs/developer/a2-compression-budget-protocol.md']
source_paths += [z['repo_path'] for z in P['preparation_source_pin']['files'] if z['repo_path'] not in source_paths][:121]
source_padding=sum(256-len(z) for z in source_paths)
components={'rendered_maximum':max(z['transaction_bytes'] for z in rows),'source_path_padding_to_125_times_256':source_padding,'artifact_length_decimal_padding_4_per_372_complete_slots':4*372,'phase_timing_exit_and_snapshot_integer_padding':2048,'bounded_preflight_receipt_and_metadata_padding':8192,'one_additional_true_cause_per_quantity_comparison_binding_row':(954+89+84)*32}
# Last component bounds one further true 29-char reason + comma/quotes; no
# permission to drop further causes. More causes must pass preflight or refuse.
upper=sum(components.values());chosen={'failure_index_bytes':1048576,'json_nodes':65536}
assert upper<chosen['failure_index_bytes']
node_extra=954+89+84+32 # one additional cause at every disposition plus result causes
assert 51560+node_extra<chosen['json_nodes']
remaining=16777216-262144-chosen['failure_index_bytes']
# Conditional illustrative full export partition, NOT a prediction. Values can
# exceed it: existing evidence_cap refusal, no omitted arrays or cap changes.
# 2x allocations cover standalone slot wrappers AND identical result copies.
partition={'input_reservation':262144,'whole_index_transaction_reservation':1048576,'slot_files_and_identical_result_payload_copy_allowance':2*summary['maximum_conditional_array_allocation'],'observations_producer_bindings_checks_run_manifest_logs_and_other_metadata_allowance':2097152}
assert sum(partition.values())<=16777216
result={'label':'STATIC/HYPOTHETICAL valid metadata-projection accounting ONLY; no actual worker/process/fitter arrays or execution. Complete artifact byte/hash fields are conditional future payload obligations, not observed files.','authorization_id':'a2-metadata-budget-revision-2026-11-12','authorization_sha256':sha((A/'metadata-budget-revision-authorization.json').read_bytes()),'old_caps':{'failure_index_bytes':524288,'json_nodes':32768},'proposed_exact_two_key_delta':chosen,'profile_count':len(rows),'positive_agreement_profiles':len(positive),'mode_rule':'Same selected ID/outcome required in eager and jit. Three agreeing configurations (8,2,4); disagreement stops before derivative work. 16 outcome pairs per case include none and all differing winners; no winner guessed.','input_max_bytes':summary['max_input_bundle_bytes'],'index_single_max_bytes':summary['max_single_index_bytes'],'transaction_rendered_max_bytes':summary['max_transaction_bytes'],'transaction_bounded_upper_components':components,'transaction_bounded_upper_bytes':upper,'transaction_headroom_after_upper':chosen['failure_index_bytes']-upper,'result_nodes_max_counting_keys':51560,'result_depth':9,'index_nodes_max_counting_keys':32714,'node_headroom_after_one_extra_cause_every_row':chosen['json_nodes']-(51560+node_extra),'symbolic_payload_count_verified_against_existing_samples':n,'symbolic_node_recipe':'raw payload =15+rank; exact payload=5+rank+5*product(shape); each reduced num/den object =5 nodes. Add full slot wrapper and frozen result/assessment nesting. Values lengths do not change nodes. No hypothetical future values generated.','remaining_results_reservation_bytes':remaining,'conditional_illustrative_total_partition':partition,'conditional_partition_unused_bytes':16777216-sum(partition.values()),'conditional_partition_not_universal':True,'headroom_scope':'Existing IDs<=64; printable ASCII<=256, command args<=32 with maximum escaping; source entries<=125, paths<=256; signed63 ns times; all fixed case/candidate/slot/check identities retained. Exact and raw file allowances are illustrative subsets, NOT new caps on allowed values or bounds on actual fit exports. More true causes, arbitrary valid inventories, optional index rewrites, rational lengths, whitespace and other files still require full actual preflight/cumulative accounting or bounded refusal.','positive_profiles':[{k:z[k] for k in ['case_id','winners','transaction_bytes','symbolic_node_accounting','slot_dispositions','comparison_dispositions','binding_dispositions']} for z in positive],'prior_792318_classification':'Conservative partly impossible all-complete template, not a necessary node lower bound or universal runtime byte bound. New counts account inactive and unused quantities.','old_refusal_correct_reasons':'All eight required f32 positive cases: index transaction bytes exceed524288 for every selected configuration; result payload cardinalities also exceed32768 even though corrected compact index alone fits32768. These are conditional valid completion-node cardinalities, not measured outputs.','cap_bytes_control':{'numeric_value_unchanged':786432,'new_input_plus_failure_reservations':262144+1048576,'available_result_allowance':786432-262144-1048576,'expected_status':'indeterminate','expected_reason':'evidence_cap','clarification':'zero OR negative available result allowance after immutable input reservation and revised failure reservation refuses before numerical work; this is not a passed future control'},'limits':['No proof of actual numerical attainability, real-fit arrays, exact-artifact byte lengths or working comparisons.','Metadata projections preserve conditional artifact obligations; they are not a fabricated complete observed export or operational replay.','Finite scientific/numerical domain, tolerances, all other caps and the 17 root formats/semantics are unchanged.','Uncontrolled valid requests can still exceed byte/node/total reservations: retain all reasons and bounded reservation_exceeded/evidence_cap indeterminate, never erase checks.','DRAFT pending independent review and separate owner freeze/implementation.'],'implementation_authorized':False,'a2_acceptance_passed':False,'arithmetic_verified':False,'total_numerical_certified':False}
(D/'budget-choice-before-edit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='positive_profiles'},indent=2))
# Locate directly dependent values only; normalized_bits=32768 is immutable.
for file in ['protocol.json','fixtures.json','record-schemas.json','schema-control-fixtures.json']:
 obj=json.loads((A/file).read_text());found=[]
 def visit(x,path=''):
  if isinstance(x,dict):
   for k,v in x.items():visit(v,path+'/'+k)
  elif isinstance(x,list):
   for i,v in enumerate(x):visit(v,path+'/'+str(i))
  elif (type(x) is int and x==524288) or (isinstance(x,str) and ('512' in x or '524288' in x or '32768' in x or '32,768' in x)):
   if 'raw_hex' not in path:found.append([path,x])
 visit(obj)
 (D/(file+'.budget-locations.json')).write_text(json.dumps(found,indent=2)+'\n')
