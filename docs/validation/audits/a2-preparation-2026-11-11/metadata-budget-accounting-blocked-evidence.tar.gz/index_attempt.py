"""Final reference index and readback of this BLOCKED scratch-only attempt."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
O=Path(__file__).parent
excluded={'evidence-index.json','evidence-index-verification.json','blocked-attempt-evidence.tar.gz'}
files={}
for p in sorted(O.rglob('*')):
 if p.is_file() and p.name not in excluded:
  assert not p.is_symlink()
  b=p.read_bytes();files[str(p.relative_to(O))]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
idx={'label':'Final scratch references and actual raw attempts; BLOCKED, no packet revision. Not an assertion of pre-run source capture.','files':files,'excluded':sorted(excluded)}
b=json.dumps(idx,indent=2).encode()+b'\n';(O/'evidence-index.json').write_bytes(b)
for name,d in files.items():
 raw=(O/name).read_bytes();assert len(raw)==d['bytes'] and hashlib.sha256(raw).hexdigest()==d['sha256']
with (O/'blocked-attempt-evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name in list(files)+['evidence-index.json']:
    data=(O/name).read_bytes();i=tarfile.TarInfo(name);i.size=len(data);i.mtime=0;i.mode=0o600;t.addfile(i,io.BytesIO(data))
with tarfile.open(O/'blocked-attempt-evidence.tar.gz') as t:
 members=t.getmembers();assert len(members)==len(files)+1
 for m in members:
  assert m.isfile() and not m.issym() and not m.islnk()
  data=t.extractfile(m).read();want=(O/m.name).read_bytes();assert data==want
ab=(O/'blocked-attempt-evidence.tar.gz').read_bytes()
v={'all_indexed_files_verified':True,'files':len(files),'archive_members_verified':len(members),'evidence_index':{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'archive':{'bytes':len(ab),'sha256':hashlib.sha256(ab).hexdigest()},'outcome':'BLOCKED_BEFORE_ANY_PACKET_EDIT','repository_modified_paths':[]}
(O/'evidence-index-verification.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps(v,indent=2))
