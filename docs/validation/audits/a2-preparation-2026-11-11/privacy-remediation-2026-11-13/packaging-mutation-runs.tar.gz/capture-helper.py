"""Deliberately broken copied helpers; never edit the reviewed working source."""
import hashlib
import json
import os
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/privacy-remediation-2026-11-13'
SOURCE = (WORK / 'sanitize_evidence.py').read_text()
TESTS = (WORK / 'test_sanitize_evidence.py').read_bytes()
MUTANTS = {
    'original-identity': [('digest(original_body) != hold["original_sha256"]', 'False')],
    'omission-identity': [('digest(source[name]) != row["sha256"]', 'False')],
    'retained-members': [('if descriptors(actual) != inventory["retained"]:', 'if False:')],
    'safe-member-path': [('            safe_name(member.name)', '            pass')],
    'bundle-allowlist': [('if {path.name for path in bundle.iterdir()} != {"inventory.json", DERIVATIVE}:', 'if False:')],
    'inventory-pin': [('if digest(raw_inventory) != inventory_sha256:', 'if False:')],
    'output-symlink': [('if any(p.is_symlink() for p in (output, *output.parents)):', 'if False:')],
    'no-overwrite': [('output.mkdir(mode=0o700, exist_ok=False)', 'output.mkdir(mode=0o700, exist_ok=True)'), ('(output / DERIVATIVE).open("xb")', '(output / DERIVATIVE).open("wb")'), ('(output / "inventory.json").open("xb")', '(output / "inventory.json").open("wb")')],
    'partition': [('if (len(names) != len(set(names))\n            or sorted(partition, key=lambda row: row["path"]) != original\n            or type(inventory["original_member_count"]) is not int\n            or len(original) != inventory["original_member_count"]):', 'if False:')],
    'historical-boundary': [('or inventory["historical_replay_closure_complete"] is not False', 'or False')],
}
summary = []
for label, substitutions in MUTANTS.items():
    run = WORK / 'mutation-runs' / label
    run.mkdir(parents=True, exist_ok=False)
    before = run / 'before'
    before.mkdir()
    mutant = SOURCE
    for old, new in substitutions:
        assert mutant.count(old) == 1, label
        mutant = mutant.replace(old, new)
    compile(mutant, 'synthetic-mutant.py', 'exec')
    (before / 'sanitize_evidence.py').write_text(mutant)
    (before / 'test_sanitize_evidence.py').write_bytes(TESTS)
    (before / 'pyproject.toml').write_bytes((ROOT / 'pyproject.toml').read_bytes())
    pins = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in before.iterdir()}
    cmd = ['uv', 'run', '--project', str(ROOT), '--frozen', '--no-sync', 'python', '-B', '-m', 'pytest', '-c', str(before / 'pyproject.toml'), str(before / 'test_sanitize_evidence.py'), '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(Path(os.environ['TMPDIR']) / ('hpfracc-privacy-mutant-' + label)), '--junitxml=' + str(run / 'raw.xml')]
    (run / 'plan.json').write_text(json.dumps({'label': 'SYNTHETIC DELIBERATELY INVALID HELPER', 'substitutions': substitutions, 'pins': pins, 'command': cmd}, indent=2) + '\n')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'), JAX_PLATFORMS='cpu')
    result = subprocess.run(cmd, cwd=before, env=env, capture_output=True, timeout=45)
    (run / 'stdout.raw').write_bytes(result.stdout)
    (run / 'stderr.raw').write_bytes(result.stderr)
    xml = ET.parse(run / 'raw.xml')
    assert all(hashlib.sha256((before / name).read_bytes()).hexdigest() == sha for name, sha in pins.items())
    receipt = {'mutant': label, 'actual_exit': result.returncode, 'tests': len(xml.findall('.//testcase')), 'failures': len(xml.findall('.//failure')), 'errors': len(xml.findall('.//error')), 'xml_sha256': hashlib.sha256((run / 'raw.xml').read_bytes()).hexdigest(), 'input_pins_unchanged': True}
    receipt['killed'] = receipt['actual_exit'] == 1 and receipt['failures'] > 0 and receipt['errors'] == 0
    (run / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    summary.append(receipt)
assert hashlib.sha256((WORK / 'sanitize_evidence.py').read_bytes()).hexdigest() == hashlib.sha256(SOURCE.encode()).hexdigest()
(WORK / 'mutation-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
assert all(row['killed'] for row in summary)
