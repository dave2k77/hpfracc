"""Finalize the allowed status delta and run current packaging/documentation QA."""
import difflib
import hashlib
import json
import os
import shutil
import stat
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
WORK = AUDIT / 'privacy-remediation-2026-11-13'
HERE = Path(__file__).parent
review = json.loads((WORK / 'review-inputs.json').read_text())
baseline = json.loads((WORK / 'baseline-inputs.json').read_text())
allowed = set(review['allowed_post_review_delta'])
combined = baseline['files'] | review['files']
actual_changed = set()
for name, expected in combined.items():
    body = (ROOT / name).read_bytes()
    actual = {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
    if actual != expected:
        actual_changed.add(name)
assert actual_changed == allowed
assert hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT)).hexdigest() == baseline['git_stage_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == baseline['head']
old = {}
with tarfile.open(WORK / 'pre-remediation-status.tar.gz','r:gz') as t:
    for member in t:
        old[member.name] = t.extractfile(member).read()
readme_name = str((WORK / 'README.md').relative_to(ROOT))
old[readme_name] = (HERE / 'reviewed-readme.md').read_bytes()
assert set(old) == allowed
changes, diff = {}, []
for name in sorted(allowed):
    before, after = old[name], (ROOT / name).read_bytes()
    assert hashlib.sha256(before).hexdigest() == combined[name]['sha256']
    changes[name] = {'before_sha256':hashlib.sha256(before).hexdigest(),
                     'after_sha256':hashlib.sha256(after).hexdigest(),
                     'scope':'Publication/progress wording only'}
    diff.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='reviewed/'+name,tofile='final/'+name))
(HERE / 'publication-status.patch').write_text(''.join(diff))
old_outcome = json.loads(old[str((AUDIT / 'single-trace-outcome.json').relative_to(ROOT))])
current = json.loads((AUDIT / 'single-trace-outcome.json').read_text())
old_keys_changed = {k for k,v in old_outcome.items() if current.get(k) != v}
assert old_keys_changed == {'status','latest_status_delta_record','next_boundary'}
assert current['sanitized_derivative_publication_ready'] is True
assert current['publication_ready'] is False and current['fixed_trace_increment_complete'] is False
for key in ['implementation_authorized','protocol_freeze_authorized','phase_a_complete',
            'a2_acceptance_passed','caps_changed','broader_accounting_proved','commit_or_push_performed']:
    assert current[key] is False
hold = json.loads((AUDIT / 'single-trace-privacy-hold.json').read_text())
p = Path(hold['private_original_path'])
assert hashlib.sha256(p.read_bytes()).hexdigest() == hold['original_sha256']
assert stat.S_IMODE(p.stat().st_mode) == 0o600
assert stat.S_IMODE(p.parent.stat().st_mode) == 0o700
assert not os.path.lexists(ROOT / hold['original_repository_path'])
qa = HERE / 'final-qa'
qa.mkdir()
before = qa / 'before'
before.mkdir()
for path in [WORK/'sanitize_evidence.py',WORK/'test_sanitize_evidence.py',ROOT/'pyproject.toml']:
    shutil.copyfile(path,before/path.name)
shutil.copytree(WORK / 'sanitized-bundle',before / 'bundle')
base = ['uv','run','--project',str(ROOT),'--frozen','--no-sync']
commands = [
    base + ['ruff','check','--no-cache','.'],
    base + ['python','-B','-m','pytest','-c',str(before/'pyproject.toml'),str(before/'test_sanitize_evidence.py'),'-q','-p','no:cacheprovider','--basetemp='+str(HERE/'packaging-runtime'),'--junitxml='+str(qa/'packaging.xml')],
    base + ['python','-B','-m','pytest','tests/unit/test_docs_consistency.py','-q','-p','no:cacheprovider','--basetemp='+str(HERE/'docs-runtime'),'--junitxml='+str(qa/'docs.xml')],
    base + ['mkdocs','build','--strict','--site-dir',str(HERE/'site')],
    ['git','diff','--check'],
    base + ['python','-B',str(before/'sanitize_evidence.py'),'verify','--bundle',str(before/'bundle'),'--inventory-sha256',hashlib.sha256((before/'bundle/inventory.json').read_bytes()).hexdigest()],
]
pins = {str(p.relative_to(before)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in before.rglob('*') if p.is_file()}
(qa/'plan.json').write_text(json.dumps({'commands':commands,'copied_inputs':pins},indent=2)+'\n')
receipts = []
env = dict(os.environ,PYTHONDONTWRITEBYTECODE='1',UV_PROJECT_ENVIRONMENT=str(ROOT/'.venv'),JAX_PLATFORMS='cpu')
for i,cmd in enumerate(commands):
    r = subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True)
    (qa/f'{i}-stdout.raw').write_bytes(r.stdout)
    (qa/f'{i}-stderr.raw').write_bytes(r.stderr)
    receipts.append({'command':cmd,'actual_exit':r.returncode})
    print(json.dumps({'command_index':i,'actual_exit':r.returncode}))
(qa/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
assert all(r['actual_exit']==0 for r in receipts)
counts = {}
for name in ['packaging','docs']:
    tree = ET.parse(qa/(name+'.xml'))
    cases = tree.findall('.//testcase')
    assert len(cases)==23 and not tree.findall('.//failure') and not tree.findall('.//error')
    counts[name] = len(cases)
assert all(hashlib.sha256((before/k).read_bytes()).hexdigest()==v['sha256'] for k,v in pins.items())
for name, expected in combined.items():
    if name not in allowed:
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected['sha256']
result = {'status':'Approved publication-only delta; post-update checks passed',
          'changes':changes,'changed_existing_outcome_keys':sorted(old_keys_changed),
          'unchanged_protected_files':len(combined)-len(allowed),'head_and_git_stage_unchanged':True,
          'private_original_hash_permissions_and_absence_verified':True,
          'qa_actual_exits':[r['actual_exit'] for r in receipts], 'fresh_test_counts':counts,
          'numerical_tests_rerun':False,'commit_or_push_performed':False,
          'final_qa_location':'parent-closure-evidence.tar.gz::final-qa/'}
(WORK/'final-status-delta.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'unchanged_protected_files':result['unchanged_protected_files'],'tests':counts},indent=2))
