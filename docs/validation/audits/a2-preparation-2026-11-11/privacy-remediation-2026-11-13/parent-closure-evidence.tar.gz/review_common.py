"""Independent STEP-1 review utilities; no repository writes or receipt copies."""
import hashlib
import io
import json
import os
import stat
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
CANDIDATE = AUDIT / 'privacy-remediation-2026-11-13'
EVIDENCE = Path(__file__).parent
REVIEW_PIN = 'f34ca4700bc76f6ed58b69a3e8abae2b1c2bf4299afd1b535d7af2a3f7288743'
ORIGINAL_PIN = '264cfcc67365499f19705b4aef5c2ba0163e5bc0e3cb23d53ae263ff590a02c2'
DERIVATIVE_PIN = '26b0c4b4ccf59e415c9631471e01713ab8b27feda9351b077f831c557b981ff2'
INVENTORY_PIN = '2164616b90e50bb961c3e45a9e1e15d6fc1b242a0c5c97ec53c258b32ea3e525'
PRIVATE = Path('/home/davianc/.local/share/hpfracc/private-audits/a2-single-trace-20261112/single-trace-independent-review-failed-evidence.tar.gz')

def sha(body):
    return hashlib.sha256(body).hexdigest()

def desc(body):
    return {'bytes': len(body), 'sha256': sha(body)}

def strict(body):
    def pairs(items):
        out = {}
        for k, v in items:
            if k in out:
                raise ValueError('duplicate JSON field')
            out[k] = v
        return out
    return json.loads(body, object_pairs_hook=pairs)

def put(name, data):
    path = EVIDENCE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(data)
    return str(path)

def record(name, data):
    return put(name, (json.dumps(data, indent=2, sort_keys=True) + '\n').encode())

def safe(name):
    assert name and not name.startswith('/') and '\\' not in name
    assert all(p not in ('', '.', '..') for p in name.split('/'))
    assert all(32 <= ord(c) <= 126 for c in name)

def members(body):
    out, headers = {}, {}
    with tarfile.open(fileobj=io.BytesIO(body), mode='r:*') as t:
        for m in t:
            safe(m.name)
            assert m.isfile() and m.name not in out
            assert m.size >= 0
            out[m.name] = t.extractfile(m).read()
            assert len(out[m.name]) == m.size
            headers[m.name] = {'mode': m.mode, 'uid': m.uid, 'gid': m.gid,
                               'mtime': m.mtime, 'uname': m.uname, 'gname': m.gname,
                               'type': m.type.decode('ascii'), 'pax_headers': m.pax_headers}
    return out, headers

def guarded_files():
    raw = (CANDIDATE / 'review-inputs.json').read_bytes()
    assert sha(raw) == REVIEW_PIN
    review = strict(raw)
    baseline = strict((CANDIDATE / 'baseline-inputs.json').read_bytes())
    assert len(review['files']) == 36 and len(baseline['files']) == 189
    result = {}
    for manifest_name, manifest in [('review', review), ('baseline', baseline)]:
        checked = {}
        for name, expected in manifest['files'].items():
            safe(name)
            p = ROOT / name
            assert not p.is_symlink() and p.is_file(), name
            actual = desc(p.read_bytes())
            assert actual == expected, name
            checked[name] = actual
        result[manifest_name] = {'files': checked, 'count': len(checked)}
    stage = subprocess.run(['git', 'ls-files', '--stage', '-z'], cwd=ROOT, capture_output=True)
    assert stage.returncode == 0 and not stage.stderr
    assert sha(stage.stdout) == baseline['git_stage_sha256']
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, capture_output=True)
    assert head.returncode == 0 and head.stdout.decode().strip() == baseline['head']
    candidate_names = {str(p.relative_to(ROOT)) for p in CANDIDATE.rglob('*') if p.is_file()}
    expected_names = set(review['files']) | {str((CANDIDATE / 'review-inputs.json').relative_to(ROOT))}
    assert candidate_names == expected_names
    result.update(review_manifest=desc(raw), candidate_files=len(candidate_names),
                  git_stage_sha256=sha(stage.stdout), head=baseline['head'])
    return result

def private_identity():
    hold = strict((AUDIT / 'single-trace-privacy-hold.json').read_bytes())
    assert hold['private_original_path'] == str(PRIVATE)
    assert not PRIVATE.is_symlink() and not PRIVATE.parent.is_symlink()
    assert stat.S_IMODE(PRIVATE.stat().st_mode) == 0o600
    assert stat.S_IMODE(PRIVATE.parent.stat().st_mode) == 0o700
    assert not os.path.lexists(ROOT / hold['original_repository_path'])
    b = PRIVATE.read_bytes()
    assert sha(b) == ORIGINAL_PIN == hold['original_sha256']
    assert len(b) == hold['original_bytes']
    return hold, b

def environment():
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu',
               UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'), UV_NO_CACHE='1', UV_OFFLINE='1')
    return env

def run_capture(label, command, cwd, inputs=None):
    plan = {'command': command, 'cwd': str(cwd), 'input_files': inputs or {},
            'environment_overrides': {k: environment()[k] for k in
                ['PYTHONDONTWRITEBYTECODE','JAX_PLATFORMS','UV_PROJECT_ENVIRONMENT','UV_NO_CACHE','UV_OFFLINE']}}
    record(label + '/plan.json', plan)
    result = subprocess.run(command, cwd=cwd, env=environment(), capture_output=True)
    put(label + '/stdout.raw', result.stdout)
    put(label + '/stderr.raw', result.stderr)
    record(label + '/exit.json', {'actual_exit': result.returncode,
                                  'stdout': desc(result.stdout), 'stderr': desc(result.stderr)})
    return result

if __name__ == '__main__':
    record('initial-protected-check.json', guarded_files())
    for name in ['review-inputs.json', 'baseline-inputs.json', 'authorization.json']:
        put('reviewed/' + name, (CANDIDATE / name).read_bytes())
    print(json.dumps({'protected_candidate_files': 36, 'protected_baseline_files': 189,
                      'review_manifest_sha256': REVIEW_PIN, 'passed': True}))
