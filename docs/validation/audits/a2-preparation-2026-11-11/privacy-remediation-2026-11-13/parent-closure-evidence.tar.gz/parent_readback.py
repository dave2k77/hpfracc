"""Parent readback of the exact independent-review proof; no repository writes."""
import hashlib
import json
import shutil
import sys
from pathlib import Path

REVIEW = Path('/home/davianc/.hermes/cache/scratch/hpfracc-privacy-independent-review-hSV5uUVW')
HERE = Path(__file__).parent
INDEX_PIN = 'f3db67b4be4a70adec984f57c03d8ae5de081cc483c20cc76f1c9c6b1d4a72a6'
raw = (REVIEW / 'evidence-index.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == INDEX_PIN
index = json.loads(raw)
assert index['file_count'] == len(index['files']) == 198
assert index['self_excluded_explicitly'] == 'evidence-index.json'
for name, expected in index['files'].items():
    assert name and not name.startswith('/') and '..' not in Path(name).parts
    path = REVIEW / name
    assert path.is_file() and not path.is_symlink()
    body = path.read_bytes()
    assert {'bytes':len(body), 'sha256':hashlib.sha256(body).hexdigest()} == expected
verdict = json.loads((REVIEW / 'verdict.json').read_text())
assert verdict['passed'] is True and not verdict['security_concerns'] and not verdict['logic_errors']
assert verdict['reviewed_manifest_sha256'] == index['reviewed_manifest_sha256']
for name in ['review_common.py','verify_proof.py']:
    shutil.copyfile(REVIEW / name, HERE / name)
sys.path.insert(0,str(HERE))
import review_common
import verify_proof
protected = review_common.guarded_files()
verify_proof.EVIDENCE = REVIEW
privacy = verify_proof.scan_paths(sorted(index['files']) + ['evidence-index.json'])
assert not privacy['privacy_findings']
(HERE / 'review-proof-privacy-readback.json').write_text(json.dumps(privacy,indent=2) + '\n')
controls = json.loads((REVIEW / 'independent-controls.json').read_text())
assert controls['control_count'] == len(controls['controls']) == 16
assert all(row['actual_exit'] != 0 and row['expected_guard_observed'] for row in controls['controls'])
for row in controls['controls']:
    label = 'controls/' + row['control']
    result = json.loads((REVIEW / label / 'exit.json').read_text())
    assert result['actual_exit'] == row['actual_exit']
    assert row['expected_guard'].encode() in (REVIEW / label / 'stderr.raw').read_bytes()
result = {'status':'Independent review accepted after parent readback',
          'review_index_sha256': INDEX_PIN, 'indexed_files_verified': len(index['files']),
          'all_reviewed_inputs_unchanged': True,
          'protected_baseline_files': protected['baseline']['count'],
          'protected_candidate_files': protected['review']['count'],
          'review_proof_privacy_findings': len(privacy['privacy_findings']),
          'review_proof_recursive_bodies': privacy['visited_bodies'],
          'cli_tamper_controls_bound_to_exits':len(controls['controls']),
          'verdict_sha256':hashlib.sha256((REVIEW / 'verdict.json').read_bytes()).hexdigest()}
(HERE / 'parent-review-readback.json').write_text(json.dumps(result,indent=2) + '\n')
print(json.dumps(result,indent=2))
