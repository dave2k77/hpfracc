"""Scan the review's explicitly generated proof, not unrelated scratch files."""
import base64
import gzip
import io
import json
import re
import tarfile
from review_common import (EVIDENCE, PRIVATE, desc, guarded_files, members,
                           private_identity, record, strict)

SENSITIVE = {'chatid','messageid','userid','phone','phonenumber','emailaddress','email',
             'username','firstname','lastname','recipientid','destinationid','accesstoken',
             'refreshtoken','bottoken','apikey','apitoken','password','passwd','secret',
             'authorization','cookie','privatekey'}
def fields(obj):
    out = set()
    if isinstance(obj, dict):
        for k,v in obj.items():
            if re.sub('[^a-z0-9]','',k.lower()) in SENSITIVE and isinstance(v,(str,int,float)) and not isinstance(v,bool) and v != '':
                out.add(k)
            out |= fields(v)
    elif isinstance(obj,list):
        for v in obj:
            out |= fields(v)
    return out

def scan_paths(names):
    hold, raw_private = private_identity()
    original, _ = members(raw_private)
    receipts, tokens = [], set()
    for item in hold['structured_json_identifier_scan'][PRIVATE.name]:
        b = original[item['path']]
        receipts.append(b)
        d = strict(b)
        token = str(d['chat_id']).encode()
        tokens.update([token,base64.b64encode(token)])
    del original, raw_private
    patterns = [re.compile(x) for x in [rb'gh[pousr]_[A-Za-z0-9]{20,}',
        rb'github_pat_[A-Za-z0-9_]{40,}',rb'sk-[A-Za-z0-9_-]{24,}',
        rb'[0-9]{8,12}:[A-Za-z0-9_-]{30,}',rb'AKIA[0-9A-Z]{16}',
        rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']]
    findings, identities = [], {}
    counter = {'visited_bodies':0,'expanded_bytes':0,'synthetic_nonregular_entries':0}
    def scan(label,b,depth=0):
        counter['visited_bodies'] += 1
        counter['expanded_bytes'] += len(b)
        assert depth <= 20 and len(b) <= 128 * 1024**2 and counter['expanded_bytes'] <= 4 * 1024**3
        reasons = []
        if any(t in b or t in label.encode() for t in tokens):
            reasons.append('known-private-token')
        if any(r in b for r in receipts):
            reasons.append('private-receipt-body')
        if any(p.search(b) for p in patterns):
            reasons.append('credential-pattern')
        if reasons:
            findings.append({'path':label,'reasons':reasons})
        if b.startswith(b'\x1f\x8b'):
            with gzip.GzipFile(fileobj=io.BytesIO(b)) as z:
                value = z.read(128 * 1024**2 + 1)
            scan(label+'::gzip',value,depth+1)
        elif len(b) >= 512 and b[257:262] == b'ustar':
            # The allowlisted deliberate tamper fixtures contain unsafe names,
            # duplicates and a symlink. Read regular bodies only, never extract.
            with tarfile.open(fileobj=io.BytesIO(b),mode='r:') as t:
                for m in t:
                    if m.isfile():
                        scan(label+'::'+m.name,t.extractfile(m).read(),depth+1)
                    else:
                        assert label.startswith('controls/symlink-tar-member/')
                        counter['synthetic_nonregular_entries'] += 1
        else:
            try:
                obj = json.loads(b)
            except (ValueError,UnicodeError):
                obj = None
            found = fields(obj)
            if found:
                findings.append({'path':label,'field_names':sorted(found),'reasons':['sensitive-parsed-fields']})
    for name in names:
        p = EVIDENCE / name
        assert p.is_file() and not p.is_symlink()
        b = p.read_bytes()
        identities[name] = desc(b)
        scan(name,b)
    return {'input_files':identities,'input_file_count':len(identities),**counter,
            'privacy_findings':findings,'no_private_values_disclosed':True,
            'scope':'Explicit proof allowlist only, recursively scanned; runtime pytest fixtures excluded.'}

if __name__ == '__main__':
    allowlist = strict((EVIDENCE / 'proof-allowlist.json').read_bytes())
    pending = {'proof-run/stdout.raw','proof-run/stderr.raw','proof-run/exit.json'}
    names = sorted((set(allowlist['files']) | {'proof-allowlist.json'}) - pending)
    result = scan_paths(names)
    assert guarded_files() == strict((EVIDENCE / 'initial-protected-check.json').read_bytes())
    result['protected_inputs_unchanged'] = True
    result['pending_capture_files_scanned_at_seal'] = sorted(pending)
    record('proof-verification.json',result)
    print(json.dumps({'proof_files_scanned':result['input_file_count'],
        'privacy_findings':len(result['privacy_findings']), 'protected_inputs_unchanged':True}))
    assert not result['privacy_findings']
