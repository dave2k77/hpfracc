"""Capture one packaging test run from an explicit, copied input allowlist."""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
work = root / 'docs/validation/audits/a2-preparation-2026-11-11/privacy-remediation-2026-11-13'
run = work / 'test-runs' / sys.argv[1]
run.mkdir(parents=True, exist_ok=False)
before = run / 'before'
before.mkdir()
files = [work / 'test_sanitize_evidence.py', root / 'pyproject.toml']
helper = work / 'sanitize_evidence.py'
if helper.exists():
    files.append(helper)
pins = {}
for path in files:
    body = path.read_bytes()
    shutil.copyfile(path, before / path.name)
    pins[path.name] = {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
cmd = ['uv', 'run', '--project', str(root), '--frozen', '--no-sync', 'python', '-B', '-m', 'pytest', '-c', str(before / 'pyproject.toml'), str(before / 'test_sanitize_evidence.py'), '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(Path(os.environ['TMPDIR']) / ('hpfracc-privacy-' + sys.argv[1])), '--junitxml=' + str(run / 'raw.xml')]
(run / 'plan.json').write_text(json.dumps({'input_files': pins, 'command': cmd, 'cwd': str(before)}, indent=2) + '\n')
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu', UV_PROJECT_ENVIRONMENT=str(root / '.venv'))
result = subprocess.run(cmd, cwd=before, env=env, capture_output=True)
(run / 'stdout.raw').write_bytes(result.stdout)
(run / 'stderr.raw').write_bytes(result.stderr)
assert all(hashlib.sha256((before / name).read_bytes()).hexdigest() == pin['sha256'] for name, pin in pins.items())
xml = ET.parse(run / 'raw.xml')
cases = xml.findall('.//testcase')
receipt = {'actual_exit': result.returncode, 'tests': len(cases), 'failures': len(xml.findall('.//failure')), 'errors': len(xml.findall('.//error')), 'skipped': len(xml.findall('.//skipped')), 'inputs_unchanged': True, 'xml_sha256': hashlib.sha256((run / 'raw.xml').read_bytes()).hexdigest()}
(run / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
print(result.stdout.decode()[-5000:])
print(result.stderr.decode()[-1000:])
sys.exit(result.returncode)
