"""Packaging controls use synthetic data, never private receipt contents."""
import hashlib
import importlib.util
import io
import json
import tarfile
from pathlib import Path

import pytest


def load_helper():
    path = Path(__file__).with_name("sanitize_evidence.py")
    assert path.is_file(), "new packaging helper is absent"
    spec = importlib.util.spec_from_file_location("sanitize_evidence", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def archive(path, bodies):
    with tarfile.open(path, "w:gz") as out:
        for name, body in bodies:
            entry = tarfile.TarInfo(name)
            entry.size = len(body)
            out.addfile(entry, io.BytesIO(body))


def setup_case(tmp_path):
    # These are explicitly synthetic controls, not copied worker observations.
    bodies = [
        ("assessment.json", b'{"passed":false}\n'),
        ("source/check.py", b"assert 2 == 2\n"),
        ("run/telegram-vertical-progress.json", b'{"chat_id":"SYNTHETIC"}\n'),
    ]
    original = tmp_path / "original.tar.gz"
    archive(original, bodies)
    removed = bodies[-1]
    hold = {
        "original_repository_path": "audit/original.tar.gz",
        "original_bytes": original.stat().st_size,
        "original_sha256": hashlib.sha256(original.read_bytes()).hexdigest(),
        "structured_json_identifier_scan": {
            "original.tar.gz": [{
                "path": removed[0],
                "bytes": len(removed[1]),
                "sha256": hashlib.sha256(removed[1]).hexdigest(),
            }]
        },
    }
    return original, hold, bodies


def test_derivative_preserves_nonprivate_bodies_and_labels_omissions(tmp_path):
    helper = load_helper()
    original, hold, bodies = setup_case(tmp_path)
    before = original.read_bytes()
    bundle = tmp_path / "bundle"
    helper.build(original, hold, bundle)
    manifest_bytes = (bundle / "inventory.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    assert manifest["historical_replay_closure_complete"] is False
    assert manifest["original_sha256"] == hold["original_sha256"]
    assert manifest["original_member_count"] == len(bodies)
    assert manifest["omitted"] == hold["structured_json_identifier_scan"]["original.tar.gz"]
    with tarfile.open(bundle / manifest["derivative_name"], "r:gz") as out:
        actual = {m.name: out.extractfile(m).read() for m in out.getmembers()}
    assert actual == dict(bodies[:-1])
    assert original.read_bytes() == before
    assert helper.verify(bundle, hashlib.sha256(manifest_bytes).hexdigest())["verified"]


def test_verify_refuses_extra_bundle_files(tmp_path):
    helper = load_helper()
    original, hold, _ = setup_case(tmp_path)
    bundle = tmp_path / "bundle"
    helper.build(original, hold, bundle)
    pin = hashlib.sha256((bundle / "inventory.json").read_bytes()).hexdigest()
    (bundle / "unrelated-receipt.json").write_bytes(b"SYNTHETIC EXTRA FILE")
    with pytest.raises(ValueError, match="bundle file allowlist"):
        helper.verify(bundle, pin)
