"""Read-only input verification; copy approved audit bytes to own scratch."""
from pathlib import Path
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
SOURCE = Path('/home/davianc/.hermes/cache/scratch/a2-single-trace-20261112')
REPO = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
PACKET = REPO / 'docs/validation/audits/a2-preparation-2026-11-11'
def sha(b): return hashlib.sha256(b).hexdigest()
def load(p): return json.loads(p.read_bytes())
def put(n,v): (HERE/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def verify():
    manifest_raw=(SOURCE/'review-manifest.json').read_bytes()
    assert sha(manifest_raw)=='266772753264b13e0788628c62c196400fa6515ceca5c1555713edff228e3ac9'
    m=json.loads(manifest_raw)
    idxraw=(SOURCE/'evidence-index.json').read_bytes()
    assert sha(idxraw)==m['artifact_index_sha256']=='be5a1ba950860abbf66b849fdc5a057c75b6bafbe064ea21635e26a60633aa07'
    idx=json.loads(idxraw)
    assert idx['files']==m['artifact_files']
    for base, entries in [(SOURCE,m['artifact_files']),(REPO,m['repo_files'])]:
        for name,meta in entries.items():
            p=base/name
            assert not p.is_symlink(),p
            raw=p.read_bytes()
            assert len(raw)==meta['bytes'] and sha(raw)==meta['sha256'],p
    assert sha((REPO/'.git/index').read_bytes())==m['index_sha256']
    assert sha(subprocess.check_output(['git','ls-files','--stage'],cwd=REPO))==m['stage_sha256']
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()==m['head']
    baseline=load(SOURCE/'baseline.json')
    return {'artifact_files':len(m['artifact_files']),'artifact_bytes':sum(x['bytes'] for x in m['artifact_files'].values()),'protected_repo_files':len(m['repo_files']),'numerical_files':len(baseline['numerical_inputs']),'packet_files':len(baseline['packet_before']),'historical_files':len(baseline['history']),'head':m['head'],'git_index_sha256':m['index_sha256'],'stage_sha256':m['stage_sha256'],'review_manifest_sha256':sha(manifest_raw),'author_evidence_index_sha256':sha(idxraw)}
if __name__=='__main__':
    pins=verify(); put('initial-pins.json',pins)
    dest=HERE/'copied';dest.mkdir()
    for name in ['a2_trace.py','test_a2_trace.py','authority.json','record-schemas.json','protocol.json','trace.json']:
        (dest/name).write_bytes((SOURCE/name).read_bytes())
    for name in ['review-manifest.json','evidence-index.json','methodology.md','single-trace-authorization.json']:
        base=PACKET if name=='single-trace-authorization.json' else SOURCE
        (HERE/name).write_bytes((base/name).read_bytes())
    a=load(dest/'authority.json')
    f=load(PACKET/'fixtures.json'); s=load(PACKET/'schema-control-fixtures.json'); p=load(PACKET/'packet-manifest.json')
    print(json.dumps(pins,indent=2))
    print('AUTHORITY_KEYS', list(a));print('FIXTURE_KEYS',list(f)); print('SCHEMA_FIXTURE_KEYS',list(s));print('PACKET',json.dumps(p,indent=2))
    print('AUTHORITY_SMALL',json.dumps({k:v for k,v in a.items() if k!='bundle'},indent=2))
    print('SCHEMA_SAMPLE', json.dumps(s,indent=2)[:9000])
