"""Fixed-case vertical audit tests; all trace process fields are hypothetical."""
import importlib.util
from pathlib import Path

HERE = Path(__file__).resolve().parent


def module():
    path = HERE / 'a2_trace.py'
    assert path.is_file(), 'the fixed-case semantic/ledger audit is absent'
    spec = importlib.util.spec_from_file_location('a2_fixed_trace', path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def test_one_trace_has_independently_closed_ledger():
    audit = module()
    trace = audit.make_trace()
    report = audit.verify_trace(trace)
    assert report['case_id'] == 'REF-PASS-f64-GL'
    assert report['slot_count'] == 22
    assert report['ledger'] == trace['ledger']
    assert report['ledger']['cumulative_written_bytes'] >= report['ledger']['peak_live_bytes']
    assert report['ledger']['peak_live_bytes'] <= 16777216
    assert report['ledger']['index_transaction_bytes'] <= 524288
    assert report['implementation_authorized'] is False
    assert report['a2_acceptance_passed'] is False
