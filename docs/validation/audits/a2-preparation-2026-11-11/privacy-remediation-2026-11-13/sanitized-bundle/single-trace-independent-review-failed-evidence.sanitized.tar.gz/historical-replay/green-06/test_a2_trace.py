"""Fixed-case vertical audit tests; all trace process fields are hypothetical."""
import copy
import importlib.util
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent


def module():
    path = HERE / 'a2_trace.py'
    assert path.is_file(), 'the fixed-case semantic/ledger audit is absent'
    spec = importlib.util.spec_from_file_location('a2_fixed_trace', path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def test_one_trace_has_independently_closed_ledger():
    audit = module()
    trace = audit.make_trace()
    report = audit.verify_trace(trace)
    assert report['case_id'] == 'REF-PASS-f64-GL'
    assert report['slot_count'] == 22
    assert report['ledger'] == trace['ledger']
    assert report['ledger']['cumulative_written_bytes'] >= report['ledger']['peak_live_bytes']
    assert report['ledger']['peak_live_bytes'] <= 16777216
    assert report['ledger']['index_transaction_bytes'] <= 524288
    assert report['implementation_authorized'] is False
    assert report['a2_acceptance_passed'] is False


@pytest.mark.parametrize('component', [
    'logs/stdout.bin', 'run-manifest.json', 'INITIAL_INDEX', 'failure-index.json',
])
def test_omitted_charge_with_recomputed_totals_is_rejected(component):
    audit = module()
    trace = audit.make_trace()
    claimed = trace['ledger']
    assert claimed['terms'][component] > 0
    claimed['terms'][component] = 0
    terms = claimed['terms']
    claimed['cumulative_written_bytes'] = sum(terms.values())
    claimed['final_live_bytes'] = sum(v for k, v in terms.items() if k != 'INITIAL_INDEX')
    claimed['peak_live_bytes'] = max(
        claimed['final_live_bytes'],
        claimed['final_live_bytes'] + terms['INITIAL_INDEX']
        - terms['records/export.json'] - terms['run-manifest.json'],
    )
    claimed['index_transaction_bytes'] = sum(terms[p] for p in [
        'INITIAL_INDEX', 'failure-index.json', 'records/process.json',
        'records/export.json', 'records/output-control.json',
    ])
    claimed['old_index_bytes_charged'] = terms['INITIAL_INDEX']
    claimed['temporary_bytes_charged'] = terms['failure-index.json']
    assert component in claimed['terms']
    with pytest.raises(ValueError, match='ledger claim'):
        audit.verify_trace(trace)


@pytest.mark.parametrize('fault', ['unknown', 'wrong-winner', 'exit-unconfirmed'])
def test_invalid_success_is_rejected_after_outer_hashes_are_rebuilt(fault):
    audit = module()

    def mutate(records):
        if fault == 'unknown':
            records['result.json']['assessments'][0].update(status='unknown', qualifies=None)
        elif fault == 'wrong-winner':
            records['result.json']['selected_id'] = 'bad1-f64-GL'
        else:
            records['records/process.json'].update(exit_confirmed=False, exit_code=None)

    trace = audit.make_trace(mutate)
    assert trace['records']['result.json']['status'] == 'selected'
    assert trace['ledger'] == audit.replay_ledger(trace)
    with pytest.raises(ValueError, match='completion|selection'):
        audit.verify_trace(trace)


@pytest.mark.parametrize('fault', ['descriptor-shape', 'mode', 'alpha', 'slot-shape'])
def test_inner_binding_fault_is_rejected_with_valid_outer_hashes(fault):
    audit = module()

    def mutate(records):
        binding = records['records/binding-host-0.json']
        if fault == 'descriptor-shape':
            binding['returned'][0]['descriptor']['shape'] = [1, 3]
        elif fault == 'mode':
            binding['mode'] = 'jit'
            binding['producer']['mode'] = 'jit'
        elif fault == 'alpha':
            binding['alpha'] = copy.deepcopy(binding['dt'])
        else:
            records['arrays/S-0-g_hat.json']['exact_array']['shape'] = [1, 3]

    trace = audit.make_trace(mutate)
    assert trace['ledger'] == audit.replay_ledger(trace)
    with pytest.raises(ValueError, match='binding|shape'):
        audit.verify_trace(trace)


@pytest.mark.parametrize('sid', ['S-X-D', 'S-0-D_hat', 'S-1-analytic_input_gradient', 'S-0-B'])
def test_false_exact_payload_is_rejected_even_after_descriptor_rebinding(sid):
    audit = module()

    def mutate(records):
        payload = records['arrays/' + sid + '.json']['exact_array']
        if sid == 'S-0-B':
            payload['values'][1] = {'num': '3', 'den': '8'}
        else:
            payload['values'][0] = {'num': '3', 'den': '1'}
        for binding in records.values():
            if binding.get('record_type') == 'producer_binding':
                for returned in binding['returned']:
                    if returned['slot_id'] == sid:
                        returned['descriptor']['payload_sha256'] = audit.digest(audit.canonical(payload))

    trace = audit.make_trace(mutate)
    audit.check_completion(trace['records'])
    audit.check_links(trace)
    assert trace['ledger'] == audit.replay_ledger(trace)
    with pytest.raises(ValueError, match='exact identity'):
        audit.verify_trace(trace)


def test_inconsistent_conditional_phase_is_rejected_after_resigning():
    audit = module()

    def mutate(records):
        records['records/process.json']['phases']['watchdog']['elapsed_ns'] = 99

    trace = audit.make_trace(mutate)
    audit.check_links(trace)
    assert trace['ledger'] == audit.replay_ledger(trace)
    with pytest.raises(ValueError, match='phase'):
        audit.verify_trace(trace)


def test_digest_valid_publication_before_its_binding_is_rejected():
    audit = module()
    trace = audit.make_trace()
    events = trace['events']
    slot = next(i for i, e in enumerate(events) if e.get('body') == 'arrays/S-0-g_hat.json')
    binding = next(i for i, e in enumerate(events) if e.get('body') == 'records/binding-host-0.json')
    events[slot], events[binding] = events[binding], events[slot]
    assert trace['ledger'] == audit.replay_ledger(trace)
    with pytest.raises(ValueError, match='publication order'):
        audit.verify_trace(trace)
