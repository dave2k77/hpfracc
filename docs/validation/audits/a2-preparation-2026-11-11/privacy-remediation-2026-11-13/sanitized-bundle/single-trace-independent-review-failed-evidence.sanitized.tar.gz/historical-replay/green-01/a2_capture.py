"""Capture exact audit sources and child exits before every vertical test run."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')


def capture(label, args):
    out = HERE / label
    out.mkdir(exist_ok=False)
    sources = out / 'before'
    sources.mkdir()
    manifest = {}
    for path in sorted(HERE.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json'):
            raw = path.read_bytes()
            (sources / path.name).write_bytes(raw)
            manifest[path.name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    (out / 'source-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    command = ['uv', 'run', '--frozen', '--no-sync', 'python', '-B', '-m', 'pytest',
               str(HERE / 'test_a2_trace.py'), '-q', '-p', 'no:cacheprovider',
               '--basetemp=' + str(out / 'pytest-temp'), '--junitxml=' + str(out / 'raw.xml'), *args]
    (out / 'plan.json').write_text(json.dumps({'command': command, 'scope': 'fixed hypothetical trace audit only'}, indent=2) + '\n')
    result = subprocess.run(command, cwd=REPO, capture_output=True)
    (out / 'stdout.raw').write_bytes(result.stdout)
    (out / 'stderr.raw').write_bytes(result.stderr)
    receipt = {'command': command, 'child_exit': result.returncode,
               'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
               'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
    (out / 'process.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(result.stdout.decode(), result.stderr.decode())
    print(json.dumps(receipt))
    return result.returncode


if __name__ == '__main__':
    raise SystemExit(capture(sys.argv[1], sys.argv[2:]))
