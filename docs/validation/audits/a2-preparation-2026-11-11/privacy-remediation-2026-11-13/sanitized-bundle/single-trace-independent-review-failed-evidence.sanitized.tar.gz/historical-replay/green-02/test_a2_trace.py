"""Fixed-case vertical audit tests; all trace process fields are hypothetical."""
import copy
import importlib.util
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent


def module():
    path = HERE / 'a2_trace.py'
    assert path.is_file(), 'the fixed-case semantic/ledger audit is absent'
    spec = importlib.util.spec_from_file_location('a2_fixed_trace', path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def test_one_trace_has_independently_closed_ledger():
    audit = module()
    trace = audit.make_trace()
    report = audit.verify_trace(trace)
    assert report['case_id'] == 'REF-PASS-f64-GL'
    assert report['slot_count'] == 22
    assert report['ledger'] == trace['ledger']
    assert report['ledger']['cumulative_written_bytes'] >= report['ledger']['peak_live_bytes']
    assert report['ledger']['peak_live_bytes'] <= 16777216
    assert report['ledger']['index_transaction_bytes'] <= 524288
    assert report['implementation_authorized'] is False
    assert report['a2_acceptance_passed'] is False


@pytest.mark.parametrize('component', [
    'logs/stdout.bin', 'run-manifest.json', 'INITIAL_INDEX', 'failure-index.json',
])
def test_omitted_charge_with_recomputed_totals_is_rejected(component):
    audit = module()
    trace = audit.make_trace()
    claimed = trace['ledger']
    assert claimed['terms'][component] > 0
    claimed['terms'][component] = 0
    terms = claimed['terms']
    claimed['cumulative_written_bytes'] = sum(terms.values())
    claimed['final_live_bytes'] = sum(v for k, v in terms.items() if k != 'INITIAL_INDEX')
    claimed['peak_live_bytes'] = max(
        claimed['final_live_bytes'],
        claimed['final_live_bytes'] + terms['INITIAL_INDEX']
        - terms['records/export.json'] - terms['run-manifest.json'],
    )
    claimed['index_transaction_bytes'] = sum(terms[p] for p in [
        'INITIAL_INDEX', 'failure-index.json', 'records/process.json',
        'records/export.json', 'records/output-control.json',
    ])
    claimed['old_index_bytes_charged'] = terms['INITIAL_INDEX']
    claimed['temporary_bytes_charged'] = terms['failure-index.json']
    assert component in claimed['terms']
    with pytest.raises(ValueError, match='ledger claim'):
        audit.verify_trace(trace)
