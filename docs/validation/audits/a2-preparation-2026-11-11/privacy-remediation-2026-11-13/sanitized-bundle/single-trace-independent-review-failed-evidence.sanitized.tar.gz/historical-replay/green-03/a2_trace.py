"""ONE fixed STATIC/HYPOTHETICAL metadata trace, not an operational validator.

No JAX, fitter, numerical worker or general selector. Runtime/ownership fields
are illustrative conditions inherited from a labelled frozen witness, not observed
execution/security evidence. This audit cannot validate FIT-REAL or another case.
"""
import copy
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re

HERE = Path(__file__).resolve().parent
CASE = 'REF-PASS-f64-GL'
AUTHORITY = json.loads((HERE / 'authority.json').read_text())
SCHEMA = json.loads((HERE / 'record-schemas.json').read_text())
CAPS = json.loads((HERE / 'protocol.json').read_text())['caps']
STDOUT = b'STATIC HYPOTHETICAL STDOUT; NOT A WORKER RUN\n'
STDERR = b'STATIC HYPOTHETICAL STDERR; NOT A WORKER RUN\n'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('ascii')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def schema_check(value, rule):
    if '$ref' in rule:
        return schema_check(value, SCHEMA['$defs'][rule['$ref'].rsplit('/', 1)[-1]])
    for keyword in ('anyOf', 'oneOf'):
        if keyword in rule:
            matches = 0
            for branch in rule[keyword]:
                try:
                    schema_check(value, branch)
                except ValueError:
                    continue
                matches += 1
            need(matches == 1 if keyword == 'oneOf' else matches >= 1,
                 'schema ' + keyword)
    if 'enum' in rule:
        need(any(type(value) is type(x) and value == x for x in rule['enum']), 'schema enum/type')
    if 'type' in rule:
        types = {'object': dict, 'array': list, 'string': str,
                 'integer': int, 'boolean': bool, 'null': type(None)}
        need(type(value) is types[rule['type']], 'schema canonical type')
    if isinstance(value, dict) and 'properties' in rule:
        need(set(rule['required']) <= set(value), 'schema required keys')
        need(rule.get('additionalProperties') is False and set(value) <= set(rule['properties']),
             'schema closed keys')
        for key, item in value.items():
            schema_check(item, rule['properties'][key])
    if isinstance(value, list):
        need(rule.get('minItems', 0) <= len(value) <= rule.get('maxItems', 10**9), 'schema item count')
        if 'items' in rule:
            for item in value:
                schema_check(item, rule['items'])
    if type(value) is str:
        need(rule.get('minLength', 0) <= len(value) <= rule.get('maxLength', 10**9), 'schema string length')
        if 'pattern' in rule:
            need(re.fullmatch(rule['pattern'], value) is not None, 'schema string pattern')
    if type(value) is int:
        need(rule.get('minimum', -10**30) <= value <= rule.get('maximum', 10**30), 'schema integer range')


def metrics(value):
    if isinstance(value, dict):
        parts = [metrics(x) for x in value.values()]
        return 1 + len(value) + sum(x[0] for x in parts), 1 + max([1] + [x[1] for x in parts])
    if isinstance(value, list):
        parts = [metrics(x) for x in value]
        return 1 + sum(x[0] for x in parts), 1 + max([0] + [x[1] for x in parts])
    return 1, 1


def safe_path(path):
    need(type(path) is str and path and '\\' not in path and ':' not in path,
         'unsafe lexical path')
    p = PurePosixPath(path)
    need(not p.is_absolute() and p.as_posix() == path and
         all(x not in ('', '.', '..') for x in path.split('/')), 'unsafe lexical path')


def raw_files(trace):
    result = {path: canonical(value) for path, value in trace['records'].items()}
    for path, encoded in trace['logs'].items():
        need(path in ('logs/stdout.bin', 'logs/stderr.bin'), 'unexpected log')
        result[path] = bytes.fromhex(encoded)
    return result


def make_trace(mutate=None):
    """Relink a copy of one existing witness and close its exact byte snapshots."""
    original = AUTHORITY['bundle']
    need(original['declared_case_id'] == CASE, 'wrong fixed authority')
    records = copy.deepcopy(original['artifacts'])
    initial = copy.deepcopy(original['initial_failure_index'])
    if mutate is not None:
        mutate(records)
    launch = records['records/launch.json']
    launch['barrier'] = 'held'
    launch_hash = digest(canonical(launch))
    for value in records.values():
        if value.get('record_type') == 'producer_binding':
            value['launch_receipt_sha256'] = launch_hash
            binding_hash = digest(canonical(value))
            for returned in value['returned']:
                records['arrays/' + returned['slot_id'] + '.json']['producer_binding_sha256'] = binding_hash
    result = records['result.json']
    result['shared_slots'] = [copy.deepcopy(records['arrays/' + s['slot_id'] + '.json'])
                              for s in result['shared_slots']]
    for assessment in result['assessments']:
        assessment['slots'] = [copy.deepcopy(records['arrays/' + s['slot_id'] + '.json'])
                                for s in assessment['slots']]
    index = records['failure-index.json']
    for row in index['slots']:
        raw = canonical(records['arrays/' + row['slot_id'] + '.json'])
        row['artifact'] = {'path': 'arrays/' + row['slot_id'] + '.json',
                           'bytes': len(raw), 'sha256': digest(raw)}
    process = records['records/process.json']
    process['launch_receipt_sha256'] = launch_hash
    process['stdout_sha256'] = digest(STDOUT)
    process['stderr_sha256'] = digest(STDERR)
    index['process'] = copy.deepcopy(process)
    input_size = len(canonical(records['input-bundle.json']))
    initial['bytes_accounting'] = {'live_bytes': input_size,
                                   'cumulative_written_bytes': input_size,
                                   'reserved_final_transaction_bytes': CAPS['failure_index_bytes']}
    initial_size = len(canonical(initial))
    prefix = []
    for path in records:
        if path == 'result.json':
            break
        prefix.append(path)
    result['evidence_bytes'] = initial_size + sum(len(canonical(records[p])) for p in prefix)
    logs = {'logs/stdout.bin': STDOUT.hex(), 'logs/stderr.bin': STDERR.hex()}
    before_index = list(prefix) + ['result.json', 'records/process.json', 'records/output-control.json']
    before_size = initial_size + sum(len(canonical(records[p])) for p in before_index) + len(STDOUT) + len(STDERR)
    index['bytes_accounting'] = {'live_bytes': before_size,
                                'cumulative_written_bytes': before_size,
                                'reserved_final_transaction_bytes': CAPS['failure_index_bytes']}
    export = records['records/export.json']
    export['process_sha256'] = digest(canonical(process))
    export['failure_index_sha256'] = digest(canonical(index))
    export['failure_index_bytes'] = len(canonical(index))
    manifest = records['run-manifest.json']
    manifest['files'] = [
        {'path': p, 'bytes': len(canonical(v)), 'sha256': digest(canonical(v))}
        for p, v in records.items() if p != 'run-manifest.json'
    ] + [{'path': p, 'bytes': len(bytes.fromhex(v)), 'sha256': digest(bytes.fromhex(v))}
         for p, v in logs.items()]
    trace = {'label': AUTHORITY['label'], 'case_id': CASE, 'records': records,
             'initial_index': initial, 'logs': logs, 'events': []}
    for path in records:
        if path == 'records/process.json':
            for log in logs:
                trace['events'].append({'op': 'write', 'path': log, 'body': log})
        if path == 'failure-index.json':
            trace['events'].append({'op': 'write', 'path': 'tmp/index-final.part', 'body': path})
            trace['events'].append({'op': 'replace', 'source': 'tmp/index-final.part', 'target': path})
        else:
            trace['events'].append({'op': 'write', 'path': path, 'body': path})
        if path == 'input-bundle.json':
            trace['events'].append({'op': 'write', 'path': 'failure-index.json', 'body': 'INITIAL_INDEX'})
    files = raw_files(trace)
    terms = {p: len(data) for p, data in files.items()}
    terms['INITIAL_INDEX'] = initial_size
    final_live = sum(len(data) for data in files.values())
    peak = max(final_live, final_live + initial_size - len(files['records/export.json']) - len(files['run-manifest.json']))
    transaction = initial_size + len(files['failure-index.json']) + sum(
        len(files[p]) for p in ['records/process.json', 'records/export.json', 'records/output-control.json'])
    trace['ledger'] = {'terms': terms, 'cumulative_written_bytes': sum(terms.values()),
                       'final_live_bytes': final_live, 'peak_live_bytes': peak,
                       'index_transaction_bytes': transaction,
                       'temporary_bytes_charged': len(files['failure-index.json']),
                       'old_index_bytes_charged': initial_size}
    return trace


def replay_ledger(trace):
    """Independent state-map replay: do not consume builder totals or its sums."""
    bodies = raw_files(trace)
    bodies['INITIAL_INDEX'] = canonical(trace['initial_index'])
    live = {}
    terms = {}
    cumulative = peak = 0
    snapshots = {}
    for event in trace['events']:
        if event['op'] == 'write':
            need(set(event) == {'op', 'path', 'body'}, 'journal write fields')
            path, body = event['path'], event['body']
            safe_path(path)
            need(path not in live and body in bodies and body not in terms, 'journal duplicate/missing write')
            if body == 'result.json' or body == 'failure-index.json' or body == 'INITIAL_INDEX':
                snapshots[body] = {'live_bytes': sum(len(x) for x in live.values()),
                                   'cumulative_written_bytes': cumulative}
            data = bodies[body]
            live[path] = data
            cumulative += len(data)
            terms[body] = len(data)
        else:
            need(event == {'op': 'replace', 'source': 'tmp/index-final.part', 'target': 'failure-index.json'},
                 'journal replace fields')
            need(live.get('failure-index.json') == bodies['INITIAL_INDEX'] and
                 live.get('tmp/index-final.part') == bodies['failure-index.json'], 'atomic old/new coexistence')
            live['failure-index.json'] = live.pop('tmp/index-final.part')
        peak = max(peak, sum(len(x) for x in live.values()))
        need(cumulative <= CAPS['evidence_bytes'] and peak <= CAPS['evidence_bytes'], 'whole byte cap')
    final = raw_files(trace)
    need(live == final, 'journal final files differ from all emitted bytes')
    need(set(terms) == set(bodies), 'journal did not charge every body')
    records = trace['records']
    need(records['result.json']['evidence_bytes'] == snapshots['result.json']['live_bytes'], 'result pre-write snapshot')
    for body, record in [('INITIAL_INDEX', trace['initial_index']), ('failure-index.json', records['failure-index.json'])]:
        expected = snapshots[body] | {'reserved_final_transaction_bytes': CAPS['failure_index_bytes']}
        need(record['bytes_accounting'] == expected, 'index pre-write snapshot')
    transaction = len(bodies['INITIAL_INDEX']) + len(final['failure-index.json'])
    for path in ['records/process.json', 'records/export.json', 'records/output-control.json']:
        transaction += len(final[path])
    need(transaction <= CAPS['failure_index_bytes'], 'index transaction cap')
    return {'terms': terms, 'cumulative_written_bytes': cumulative,
            'final_live_bytes': sum(len(x) for x in live.values()), 'peak_live_bytes': peak,
            'index_transaction_bytes': transaction,
            'temporary_bytes_charged': len(final['failure-index.json']),
            'old_index_bytes_charged': len(bodies['INITIAL_INDEX'])}


def rational(value):
    schema_check(value, SCHEMA['$defs']['rat'])
    numerator, denominator = int(value['num'], 16), int(value['den'], 16)
    need(math.gcd(abs(numerator), denominator) == 1 and
         max(abs(numerator).bit_length(), denominator.bit_length()) <= CAPS['normalized_bits'],
         'canonical reduced rational')
    need(numerator != 0 or denominator == 1, 'canonical zero')
    return Fraction(numerator, denominator)


def check_completion(records):
    request = records['input-bundle.json']['request']
    result = records['result.json']
    process = records['records/process.json']
    need(process['termination'] == 'normal' and process['exit_confirmed'] is True and
         process['exit_code'] == 0 and not process['watchdog_triggered'],
         'completion requires a confirmed normal conditional exit')
    need(result['status'] == 'selected' and len(result['assessments']) == len(request['candidates']),
         'selection fixed-case complete assessment inventory')
    qualifiers = []
    for i, (candidate, assessment) in enumerate(zip(request['candidates'], result['assessments'], strict=True)):
        need(assessment['candidate_id'] == candidate['stable_id'] and assessment['candidate_index'] == i,
             'selection supplied occurrence identity')
        need(assessment['status'] in ('known_qualifying', 'known_rejected_by_bound'),
             'selection cannot succeed with unknown assessments')
        bounds = records['arrays/S-' + str(i) + '-B.json']['exact_array']
        qualifies = all(rational(x) <= rational(request['tau']) for x in bounds['values'])
        need(assessment['qualifies'] is qualifies and
             assessment['status'] == ('known_qualifying' if qualifies else 'known_rejected_by_bound'),
             'selection qualification must follow every exact bound')
        if qualifies:
            qualifiers.append((candidate['configuration']['pole_count'], candidate['stable_id']))
    need(qualifiers and result['selected_id'] == min(qualifiers)[1],
         'selection must be minimum known qualifying supplied candidate')


def verify_trace(trace):
    need(trace['case_id'] == CASE and trace['label'] == AUTHORITY['label'], 'fixed hypothetical scope')
    records = trace['records']
    need(set(records) == set(AUTHORITY['bundle']['artifacts']), 'fixed record inventory')
    for path, value in records.items():
        safe_path(path)
        schema_check(value, SCHEMA)
        nodes, depth = metrics(value)
        need(nodes <= CAPS['json_nodes'] and depth <= CAPS['json_depth'], 'per-record parse bounds')
    schema_check(trace['initial_index'], SCHEMA['$defs']['failure_index'])
    slots = [v for v in records.values() if v['record_type'] == 'slot']
    need(len(slots) == 22, 'fixed slot inventory')
    check_completion(records)
    ledger = replay_ledger(trace)
    need(trace['ledger'] == ledger, 'ledger claim differs from independent byte replay')
    return {'case_id': CASE, 'slot_count': len(slots), 'ledger': ledger,
            'implementation_authorized': False, 'a2_acceptance_passed': False}
