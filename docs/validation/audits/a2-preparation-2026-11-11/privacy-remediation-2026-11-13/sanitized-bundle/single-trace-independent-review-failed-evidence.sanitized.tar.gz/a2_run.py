"""Run a scoped command with exact pre-run sources and actual child exit."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from a2_review_setup import HERE, REPO, sha

def run(label, command, snapshots=None):
    out=HERE/label;out.mkdir(exist_ok=False)
    sources=out/'before';sources.mkdir()
    entries={}
    for p in snapshots or []:
        raw=p.read_bytes();(sources/p.name).write_bytes(raw)
        entries[p.name]={'bytes':len(raw),'sha256':sha(raw)}
    (out/'source-manifest.json').write_text(json.dumps(entries,indent=2)+'\n')
    plan={'command':command,'cwd':str(REPO),'scope':'independent fixed static trace only'}
    (out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    result=subprocess.run(command,cwd=REPO,capture_output=True,timeout=120)
    (out/'stdout.raw').write_bytes(result.stdout);(out/'stderr.raw').write_bytes(result.stderr)
    receipt=plan|{'child_exit':result.returncode,'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr)}
    (out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(label,'exit',result.returncode,result.stdout.decode(),result.stderr.decode())
    return receipt
if __name__=='__main__':
    copied=HERE/'copied'
    label=sys.argv[1]
    command=['uv','run','--frozen','--no-sync','python','-B','-m','pytest',str(copied/'test_a2_trace.py'),'-q','-p','no:cacheprovider','--basetemp='+str(HERE/label/'temp'),'--junitxml='+str(HERE/label/'raw.xml')]
    receipt=run(label,command,list(copied.iterdir()))
    assert receipt['child_exit']==0
    tree=ET.parse(HERE/label/'raw.xml');assert len(tree.findall('.//testcase'))==20
    assert not tree.findall('.//failure') and not tree.findall('.//error')
