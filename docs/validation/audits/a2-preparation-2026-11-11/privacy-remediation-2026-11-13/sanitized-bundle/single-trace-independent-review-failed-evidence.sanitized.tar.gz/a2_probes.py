"""Decisive fixed-target probes: no author source writes or repairs."""
from pathlib import Path
import copy
import importlib.util
import json
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('a2_reviewed',HERE/'copied/a2_trace.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
results=[]
for field,value in [('binding_id','host-1'),('invocation_id','inv-host-1'),('observation_id','obs-host-1')]:
    def mutate(records): records['records/binding-host-0.json'][field]=value
    t=a.make_trace(mutate)
    a.check_links(t);assert t['ledger']==a.replay_ledger(t)
    try:
        a.verify_trace(t);outcome='ACCEPTED'
    except Exception as e:outcome=type(e).__name__+': '+str(e)
    row={'field':field,'new_value':value,'target':'records/binding-host-0.json','outcome':outcome,'all_outer_links_and_ledger_valid':True}
    results.append(row)
    (HERE/('probe-'+field+'.json')).write_text(json.dumps(t,indent=2)+'\n')
(HERE/'probe-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
