"""Audit retained TDD receipts and replay exact snapshots in own scratch."""
from pathlib import Path
import ast
import json
import shutil
import xml.etree.ElementTree as ET
from a2_review_setup import HERE,SOURCE,REPO,sha,load,put,verify
from a2_run import run

def identities(tree):return [(x.get('name'),x.get('classname')) for x in tree.findall('.//testcase')]
def stats(path):
    tree=ET.parse(path);cases=tree.findall('.//testcase')
    counts={'tests':len(cases),'failures':len(tree.findall('.//failure')),'errors':len(tree.findall('.//error')),'skipped':len(tree.findall('.//skipped'))}
    headers=tree.findall('.//testsuite')
    for key in counts:assert sum(int(h.get(key,0)) for h in headers)==counts[key]
    return tree,counts

def command(test,out,args=None):
    return ['uv','run','--frozen','--no-sync','python','-B','-m','pytest',str(test),'-q','-p','no:cacheprovider','--basetemp='+str(out/'temp'),'--junitxml='+str(out/'raw.xml'),*(args or [])]

if __name__=='__main__':
    report=[]
    for i in range(1,8):
        pair={}
        for color in ['red','green']:
            label=f'{color}-{i:02d}';orig=SOURCE/label
            manifest=load(orig/'source-manifest.json');assert set(manifest)=={p.name for p in (orig/'before').iterdir() if p.is_file()}
            for name,meta in manifest.items():
                raw=(orig/'before'/name).read_bytes();assert sha(raw)==meta['sha256'] and len(raw)==meta['bytes']
            plan=load(orig/'plan.json');receipt=load(orig/'process.json');assert plan['command']==receipt['command']
            assert receipt['stdout_sha256']==sha((orig/'stdout.raw').read_bytes()) and receipt['stderr_sha256']==sha((orig/'stderr.raw').read_bytes())
            tree,counts=stats(orig/'raw.xml');assert counts['errors']==counts['skipped']==0
            assert receipt['child_exit']==(1 if color=='red' else 0)
            assert counts['failures']==(counts['tests'] if color=='red' else 0)
            failures=tree.findall('.//failure')
            assert all(('audit is absent' in f.get('message','') if i==1 else 'DID NOT RAISE' in f.get('message','')) for f in failures)
            replay=HERE/'historical-replay'/label;replay.mkdir(parents=True)
            for name in manifest:(replay/name).write_bytes((orig/'before'/name).read_bytes())
            # Inspect only executed sources; no writes, process or numerical imports.
            for filename in ['test_a2_trace.py','a2_trace.py']:
                p=replay/filename
                if not p.exists():continue
                parsed=ast.parse(p.read_text())
                imports=[n.module.split('.')[0] for n in ast.walk(parsed) if isinstance(n,ast.ImportFrom)]+[a.name.split('.')[0] for n in ast.walk(parsed) if isinstance(n,ast.Import) for a in n.names]
                assert set(imports)<={'copy','importlib','pathlib','pytest','fractions','hashlib','json','math','re','struct'}
                for n in ast.walk(parsed):
                    if isinstance(n,ast.Attribute):assert n.attr not in ['write_text','write_bytes','unlink','rmdir','mkdir','remove','replace','rename','system']
            out=HERE/('replay-'+label)
            # Preserve the original -k selection without using original output paths.
            cmd=plan['command'];args=cmd[cmd.index('-k'):] if '-k' in cmd else []
            rec=run('replay-'+label,command(replay/'test_a2_trace.py',out,args),list(replay.iterdir()))
            current,current_counts=stats(out/'raw.xml')
            assert rec['child_exit']==receipt['child_exit'] and current_counts==counts
            assert [x[0] for x in identities(current)]==[x[0] for x in identities(tree)]
            pair[color]={'original':counts,'replay':current_counts,'original_exit':receipt['child_exit'],'actual_replay_exit':rec['child_exit'],'test_names':[x[0] for x in identities(tree)],'source_files':len(manifest)}
        assert set(pair['red']['test_names'])<=set(pair['green']['test_names'])
        assert (SOURCE/f'red-{i:02d}/before/test_a2_trace.py').read_bytes()==(SOURCE/f'green-{i:02d}/before/test_a2_trace.py').read_bytes()
        report.append({'stage':i}|pair)
    missing=HERE/'missing-input-copy';missing.mkdir()
    for name in ['a2_trace.py','test_a2_trace.py','authority.json','record-schemas.json']:(missing/name).write_bytes((HERE/'copied'/name).read_bytes())
    out=HERE/'missing-input-control'
    rec=run('missing-input-control',command(missing/'test_a2_trace.py',out,['-k','test_one_trace_has_independently_closed_ledger']),list(missing.iterdir()))
    tree,counts=stats(out/'raw.xml');assert rec['child_exit']==1 and counts=={'tests':1,'failures':1,'errors':0,'skipped':0}
    assert 'protocol.json' in tree.find('.//failure').text and 'FileNotFoundError' in tree.find('.//failure').text
    isolated=SOURCE/'isolated';archived,counts_archived=stats(isolated/'raw.xml');missing_archived,missing_counts=stats(isolated/'missing-raw.xml')
    assert load(isolated/'process.json')['child_exit']==0 and counts_archived=={'tests':20,'failures':0,'errors':0,'skipped':0}
    assert load(isolated/'missing-process.json')['child_exit']==1 and missing_counts['tests']==missing_counts['failures']==1 and missing_counts['errors']==0
    put('tdd-independent-replay.json',{'stages':report,'missing_input_control':counts,'historical_isolated':counts_archived,'historical_missing_input':missing_counts,'limits':['Capture source archives and raw exits are self-consistent, and exact copied snapshots reproduce the recorded outcomes.','The capture helper writes snapshots before subprocess.run, but executes live HERE sources rather than archived before/ bytes; no contemporaneous read-back or OS attestation proves absence of between-capture/run changes.','The first RED is one collected module-absence failure; later end-to-end assertions were not reached at that RED. Nineteen later RED cases fail because expected semantic/arithmetic rejection was absent.','No historical Git index identity is inferred from these source captures.']})
    put('post-replay-pins.json',verify())
    print(json.dumps({'stages':len(report),'red_reproduced':sum(x['red']['replay']['tests'] for x in report),'final_green':report[-1]['green']['replay'],'missing_input':counts},indent=2))
