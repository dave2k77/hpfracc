"""Finalize a fail-closed independent assessment; preserve exact proof pins."""
from pathlib import Path
import json
import xml.etree.ElementTree as ET
from a2_review_setup import HERE,verify,put,sha,load

def xml_counts(path):
    tree=ET.parse(path);cases=tree.findall('.//testcase');fail=tree.findall('.//failure');errors=tree.findall('.//error');skip=tree.findall('.//skipped')
    return {'tests':len(cases),'passed':len(cases)-len(fail)-len(errors)-len(skip),'failed':len(fail),'errors':len(errors),'skipped':len(skip)}
def metadata(p):
    b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b)}
def verify_index(index):
    for path,expected in index['files'].items():
        p=HERE/path;assert not p.is_symlink();assert metadata(p)==expected,path

if __name__=='__main__':
    pins=verify();assert pins==load(HERE/'initial-pins.json');put('final-protected-pins.json',pins)
    positive=load(HERE/'independent-positive-proof.json');tdd=load(HERE/'tdd-independent-replay.json')
    focused=xml_counts(HERE/'focused-tests/raw.xml');targeted=xml_counts(HERE/'targeted-negative-tests/raw.xml')
    assert focused=={'tests':20,'passed':20,'failed':0,'errors':0,'skipped':0}
    assert targeted=={'tests':23,'passed':22,'failed':1,'errors':0,'skipped':0}
    assert load(HERE/'focused-tests/process.json')['child_exit']==0
    assert load(HERE/'targeted-negative-tests/process.json')['child_exit']==1
    assert load(HERE/'minimal-reproduction/process.json')['child_exit']==1
    red_count=sum(x['red']['replay']['tests'] for x in tdd['stages']);assert red_count==20
    excluded={'proof-index.json','proof-index-verification.json','assessment.json','assessment.md','final-pins.json'}
    files={}
    for p in sorted(HERE.rglob('*')):
        assert not p.is_symlink(),p
        if p.is_file() and p.relative_to(HERE).as_posix() not in excluded:files[p.relative_to(HERE).as_posix()]=metadata(p)
    index={'scope':'Independent ONE fixed static trace review, rejected for one routing predicate gap; no production or protocol authority','files':files,'excluded_exact_paths':sorted(excluded),'summary_binding':'assessment.json/md and this index are bound by final-pins.json, excluding that final receipt from self-hashing','review_manifest_sha256':pins['review_manifest_sha256']}
    put('proof-index.json',index);verify_index(index)
    index_sha=sha((HERE/'proof-index.json').read_bytes())
    verification={'index_sha256':index_sha,'files_verified':len(files),'bytes_verified':sum(x['bytes'] for x in files.values()),'verification_passed':True,'meaning':'Integrity of preserved reviewer evidence, NOT scoped semantic acceptance'}
    put('proof-index-verification.json',verification)
    paths={
      'assessment_json':str(HERE/'assessment.json'),
      'assessment_markdown':str(HERE/'assessment.md'),
      'independent_positive_executable':str(HERE/'a2_independent_proof.py'),
      'independent_positive_report':str(HERE/'independent-positive-proof.json'),
      'materialized_files':str(HERE/'materialized'),
      'materialization_timeline':str(HERE/'materialization-timeline.json'),
      'exact_arithmetic':str(HERE/'independent-exact-arithmetic.json'),
      'all_record_shape_route_size_table':str(HERE/'independent-record-table.json'),
      'focused_xml':str(HERE/'focused-tests/raw.xml'),
      'targeted_test_source':str(HERE/'test_a2_independent_negatives.py'),
      'targeted_xml':str(HERE/'targeted-negative-tests/raw.xml'),
      'targeted_actual_child_exit':str(HERE/'targeted-negative-tests/process.json'),
      'minimal_reproduction':str(HERE/'a2_minimal_reproduction.py'),
      'minimal_receipt':str(HERE/'minimal-reproduction-receipt.json'),
      'minimal_raw_stdout':str(HERE/'minimal-reproduction/stdout.raw'),
      'minimal_raw_stderr':str(HERE/'minimal-reproduction/stderr.raw'),
      'minimal_actual_child_exit':str(HERE/'minimal-reproduction/process.json'),
      'fully_rebound_counterexample':str(HERE/'targeted-fixtures/binding-route-mismatch.json'),
      'tdd_report':str(HERE/'tdd-independent-replay.json'),
      'all_14_snapshot_replays':'replay-red-01..07 and replay-green-01..07 under '+str(HERE),
      'missing_artifact_xml':str(HERE/'missing-input-control/raw.xml'),
      'final_root_source_index_pins':str(HERE/'final-protected-pins.json'),
      'proof_index':str(HERE/'proof-index.json'),
      'proof_index_verification':str(HERE/'proof-index-verification.json'),
      'final_pins':str(HERE/'final-pins.json')}
    assessment={
      'passed':False,
      'security_concerns':[],
      'logic_errors':[{
        'id':'FIXED-TRACE-ROUTING-01',
        'severity':'blocking_for_requested_scoped_acceptance',
        'finding':'verify_trace accepts records/binding-host-0.json with binding_id=host-1, violating the frozen records/binding-{binding_id}.json route and duplicating the other retained binding ID.',
        'source_locations':['a2_trace.py:516-524 validates lexical paths and the root schema, but not x-artifact-routing','a2_trace.py:338-365 checks mode, occurrence, descriptors and binding digests without checking binding_id against the artifact filename'],
        'authority':['record-schemas.json#/x-artifact-routing/records~1binding-{binding_id}.json','schema-control-contract.md:233-240 explicitly freezes exact path-to-definition mappings'],
        'minimal_reproduction':'t = a.make_trace(lambda r: r["records/binding-host-0.json"].update(binding_id="host-1")); a.verify_trace(t) returns success.',
        'masking_controls':'All outer manifest/index/export/binding digests and byte snapshots are rebuilt, independently checked, and the independently replayed ledger still agrees. Mode/source/occurrence/data are unchanged.',
        'actual_evidence':'targeted-negative-tests: 22 passed, 1 FAILED (DID NOT RAISE), actual child exit 1. Standalone minimal-reproduction accepts the malformed trace then exits 1 on the required route assertion.',
        'scope':'The already approved fixed case only. No different case, broad projection, cap revision, runtime/security implementation or repair was attempted.',
        'repair_performed':False}],
      'suggestions':[
        'Stop at this preserved fixed-target finding; parent/owner decides any further authorization. Do not infer approval for another broad accounting attempt or implementation.',
        'If correction is separately authorized, bind each emitted path to its frozen routing identity and retain the fully re-signed counterexample as a regression, then re-review exact changed bytes.',
        'Keep the first RED qualified as a collected module-absence failure with downstream end-to-end assertions not reached. Nineteen later cases reproduce actual missing rejections.',
        'The capture helper snapshots before subprocess.run but executes the live HERE files, not the snapshot. Preserve the source-capture limitation; matching portable replay is not historical OS/process attestation.',
        'Exploratory duplicate invocation_id/observation_id probes also accept (probe-results.json). They are not counted as separate blockers here because this fixed slice contains no dependent observation records and no independently established uniqueness predicate was assumed.'],
      'summary':'REJECTED for one concrete fixed-target artifact-route/identity gap despite successful independent exact-payload and byte-accounting verification and reproduction of all 20 supplied tests.',
      'verified_counts':{
        'fixed_cases':1,'supplied_candidates':2,'json_records':positive['records'],'exact_slots':positive['slots'],'final_files':positive['files'],'raw_logs':2,'index_generations':2,'journal_events':positive['journal_events'],'charged_writes':positive['writes'],'max_record_nodes':positive['max_record_nodes'],'max_record_depth':positive['max_record_depth'],
        'supplied_focused_tests':focused,'reviewer_targeted_tests':targeted,'historical_vertical_stages':len(tdd['stages']),'reproduced_red_cases':red_count,'first_red_module_absence_cases':1,'later_red_missing_rejection_cases':red_count-1,'final_historical_green_tests':tdd['stages'][-1]['green']['replay']['tests'],'controlled_missing_artifact_failures':tdd['missing_input_control']['failures'],
        'frozen_author_files_verified':pins['artifact_files'],'frozen_author_bytes_verified':pins['artifact_bytes'],'protected_repo_union_files':pins['protected_repo_files'],'protected_numerical_files':pins['numerical_files'],'protected_packet_files':pins['packet_files'],'protected_historical_files':pins['historical_files'],'reviewer_proof_files_indexed':len(files)},
      'verified_bytes':{k:v for k,v in positive['ledger'].items() if k!='terms'}|{'run_manifest_own_length':positive['ledger']['terms']['run-manifest.json'],'stdout':positive['ledger']['terms']['logs/stdout.bin'],'stderr':positive['ledger']['terms']['logs/stderr.bin'],'index_initial':positive['ledger']['terms']['INITIAL_INDEX'],'index_final_staging':positive['ledger']['terms']['failure-index.json'],'process':positive['ledger']['terms']['records/process.json'],'export':positive['ledger']['terms']['records/export.json'],'output_control':positive['ledger']['terms']['records/output-control.json']},
      'verified_scope':{
        'authority_slice_equals_frozen_actual_fixtures':True,'preserved_positive_artifact_equals_current_frozen_builder':True,'all_36_positive_record_schemas_routes_and_sizes_independently_checked':True,'all_22_positive_slot_payloads_and_links_independently_derived':True,'positive_publication_phase_and_completion_relationships_checked':True,'positive_ledger_independently_materialized_and_stat_recounted':True,'selection_winner':positive['qualification_winner'],'tau_exact':'3/16','bad1_bound':['0','1/4','1/4'],'good2_bound':['0','0','0'],
        'actual_packet_sha256':positive['actual_packet_sha256'],'hypothetical_packet_digest':positive['hypothetical_packet_digest'],'hypothetical_digest_is_actual_packet':False,'process_timing_ownership_counter_fields_are_hypothetical':True,'actual_worker_execution_proved':False,'watchdog_security_and_operation_budget_proved':False,'universal_or_all_case_accounting_proved':False,'caps_changed':False,'numerical_source_or_data_changed':False,'author_root_or_index_changed':False,'parent_tasks_closed':False},
      'proof_paths':paths,'index_sha256':index_sha,'reviewed_manifest_sha256':pins['review_manifest_sha256'],'reviewed_author_evidence_index_sha256':pins['author_evidence_index_sha256'],'git_index_sha256':pins['git_index_sha256'],'head':pins['head'],
      'implementation_authorized':False,'protocol_freeze_authorized':False,'a2_acceptance_passed':False,'broader_accounting_proved':False}
    assert not assessment['passed'] and assessment['logic_errors'] and not assessment['security_concerns']
    put('assessment.json',assessment)
    md=f'''# Independent fixed-trace review: REJECTED

Exactly one fixed STATIC/HYPOTHETICAL `REF-PASS-f64-GL` trace was reviewed.
No author/root/index changes, repairs, bulk-case expansion, cap change, numerical
worker, JAX/fitter/application/AD execution, staging, commit or push occurred.
All implementation/protocol-freeze/A2/broader-accounting authority flags remain false.
Parent owns task/status closure; none is marked closed here.

## Blocking fixed-target finding

`verify_trace` accepts `records/binding-host-0.json` after changing only its
`binding_id` from `host-0` to `host-1` and rebuilding the outer links and ledger.
The frozen `x-artifact-routing` requires `records/binding-{{binding_id}}.json`;
`schema-control-contract.md:233-240` explicitly requires those exact mappings.
The accepted artifact therefore has the wrong route and duplicates the retained
other binding's ID. Source `a2_trace.py:516-524` checks lexical safety and the root
schema rather than the route identity; `338-365` omits this binding ID relation.

Minimal reproduction: `{assessment['logic_errors'][0]['minimal_reproduction']}`

The negative retains correct source/mode/occurrence/payload identities. All outer
manifest/index/export/binding hashes and the recomputed byte ledger pass separate
checks. The standalone reproduction records acceptance, then **actually exits 1**
on the route assertion. The reviewer test run has **22 passed / 1 failed** (actual
child exit 1; failing test: `test_binding_filename_must_match_its_declared_binding_id`).
This is a fixed-target gap, not a request to implement a general operational parser.
No repair or alternate model was attempted.

## Independently verified positive evidence

- All **20 supplied focused tests pass** in the copied sandbox (actual child exit 0).
- All seven archived RED/GREEN snapshot pairs replay with original exact selections,
  identities and exits: RED counts 1/4/3/4/4/2/2, final GREEN 20. First RED is
  collected module absence, not reached semantic assertions; the other 19 are
  actual missing-rejection failures. The controlled missing `protocol.json`
  produces one collected failure and actual child exit 1.
- Frozen input authority equals the actual root fixtures and selected static witness.
  The illustrative repeated-`1` digest is **not** the actual packet digest
  `{positive['actual_packet_sha256']}`.
- All **36 JSON records**, **22 exact payloads**, standalone/inline copies,
  input/alpha/dt/source/occurrence/mode/shape/returned-descriptor relationships,
  digest DAG, initialized/final inventories and conditional phase/publication/
  completion relationships hold for the preserved positive artifact.
- Decode the supplied raw float64 input as `[1,1,1]`, alpha `1/2`, dt `1/4`.
  Independently recur GL weights `[1,-1/2,-1/8]`, prefix `[1,1/2,3/8]` and
  direct output `[2,1,3/4]`. Recompute every candidate's fitted weights, residual,
  matrix/output, component error/bound and mean-square analytic input gradient.
  `bad1` has bound `[0,1/4,1/4]`, exceeding tau `3/16`; `a-good2` has zero
  bounds and is the sole qualifying minimum supplied rank. This uses stdlib
  Fraction on already-provided N=3 payloads, not a library numerical oracle.
- Materialize all 39 writes and the one atomic replacement from the stored journal
  into a new reviewer directory; stat-recount live bytes after every event.
  **Cumulative {positive['ledger']['cumulative_written_bytes']}; final live
  {positive['ledger']['final_live_bytes']}; peak {positive['ledger']['peak_live_bytes']};
  old/new index transaction {positive['ledger']['index_transaction_bytes']} bytes.**
  The manifest's own {positive['ledger']['terms']['run-manifest.json']} bytes, both
  45-byte raw logs, 7457-byte initial index, 9676-byte final staging index, process,
  export and output-control are included. Atomic replacement retains the staging
  inode and writes no second copy; the old write remains cumulative, not final live.
  Snapshots are independently checked as pre-write values, not final totals.
- Reviewer controls reject eight real omitted charges with every total recomputed,
  selected-with-unknown (either occurrence), wrong winner, same-source wrong mode/
  descriptor, wrong dt/source/occurrence/case, re-bound false exact gradient, reversed
  phase, journal omission and reordering. These are the same fixed case, not new cases.
- Positive record maximum is {positive['max_record_nodes']} nodes / depth
  {positive['max_record_depth']}. These finite measurements do not establish any
  general cap sufficiency or universal/all-case byte bound.

## Evidence and scope limits

All hypothetical command/PID/time/ownership/counter fields remain representability
examples; no worker, security/no-follow mechanism, watchdog, operation/bit budget,
FIT-REAL or AD/FD result is proved. One static schedule is not a runtime/cap theorem.
The capture helper archives before spawning, but runs live HERE sources instead of
archived copies; exact portable replay supports consistency, not historical OS
attestation or a guarantee against between-snapshot/run edits.

Exploratory invocation/observation ID-collision acceptances are preserved but not
scored as separate defects without assuming an additional uniqueness requirement.

Final guards reverified **{pins['artifact_files']} author files /
{pins['artifact_bytes']} bytes**, the frozen manifest, 170 protected repository-union
files (125 numerical, 9 packet, 44 history groups with overlap), HEAD and exact Git
index/stage pins. Authorized parent status/new archive writes are not misclassified
as changes to protected bytes. Only this reviewer's unique scratch tree was written.

## Proof handles

- `a2_independent_proof.py`, `independent-positive-proof.json`,
  `independent-record-table.json`, `independent-exact-arithmetic.json`,
  `materialization-timeline.json`, `materialized/`.
- `test_a2_independent_negatives.py`, `targeted-negative-tests/raw.xml`,
  `targeted-negative-tests/process.json`, `targeted-fixtures/binding-route-mismatch.json`.
- `a2_minimal_reproduction.py`, `minimal-reproduction-receipt.json`,
  `minimal-reproduction/` raw stdout/stderr and actual child-exit receipt.
- `tdd-independent-replay.json`, `replay-red-01..07/`, `replay-green-01..07/`,
  `missing-input-control/`: raw XML, actual exits, exact new pre-run source captures.
- `final-protected-pins.json`, `proof-index.json`, `proof-index-verification.json`,
  `assessment.json`, `final-pins.json`.

Proof-index SHA-256: `{index_sha}`. It excludes its own file, index verification,
assessment JSON/Markdown and final receipt to avoid self-reference. Their exact
hashes/sizes are separately bound by `final-pins.json` and the tool readback.
'''
    (HERE/'assessment.md').write_text(md)
    # Re-read exact authored assessment targets; no result is claimed from write alone.
    parsed=load(HERE/'assessment.json');assert parsed==assessment
    assert (HERE/'assessment.md').read_text()==md
    verify_index(load(HERE/'proof-index.json'))
    assert verify()==pins
    final={'passed':False,'proof_index':metadata(HERE/'proof-index.json'),'proof_index_verification':metadata(HERE/'proof-index-verification.json'),'assessment_json':metadata(HERE/'assessment.json'),'assessment_markdown':metadata(HERE/'assessment.md'),'reviewed_manifest_sha256':pins['review_manifest_sha256'],'author_evidence_index_sha256':pins['author_evidence_index_sha256'],'source_sha256':metadata(HERE/'copied/a2_trace.py')['sha256'],'git_index_sha256':pins['git_index_sha256'],'head':pins['head'],'all_protected_pins_reverified':True,'proof_files_verified':len(files),'proof_bytes_verified':verification['bytes_verified'],'implementation_authorized':False,'protocol_freeze_authorized':False,'a2_acceptance_passed':False,'broader_accounting_proved':False}
    put('final-pins.json',final);assert load(HERE/'final-pins.json')==final
    print(json.dumps(final|{'final_pins_sha256':sha((HERE/'final-pins.json').read_bytes()),'assessment_path':str(HERE/'assessment.json')},indent=2))
