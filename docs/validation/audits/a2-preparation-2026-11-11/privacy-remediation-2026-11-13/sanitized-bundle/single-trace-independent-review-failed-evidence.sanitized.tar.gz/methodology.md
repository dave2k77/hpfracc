# One fixed conditional metadata trace

Scope: selected-REF-PASS-f64-GL, copied from the frozen, explicitly labelled
STATIC/HYPOTHETICAL witness. Exactly one three-sample case, two supplied synthetic
candidates and 22 exact slots. No additional request case, FIT-REAL branch, fitter,
JAX application/AD, operational validator, selector or numerical worker is built
or executed. No metadata/nonmetadata cap, case, check, tolerance or format changes.

The hypothetical command, PID, clock intervals, output-ownership statements and
operation/bit statistics are representability fields inherited from a static
witness, NOT observed process/security/counter evidence. The prototype checks
metadata relationships and the finite supplied exact payload identities; it does
not certify a runtime arithmetic budget, a watchdog implementation or a filesystem
security mechanism. The external packet digest of repeated `1` characters remains
explicitly hypothetical, not the current packet's digest or an approved freeze.
All implementation/scientific/A2/arithmetic certification flags remain false.

The builder and checker use different byte-accounting mechanisms:

  Builder: final canonical artifact lengths plus the overwritten initial index;
  closed-form cumulative, final-live and coexistence-peak equations.

  Checker: replay a byte-valued filesystem state map, exclusive writes and one
  atomic replacement, increment cumulative writes, recount live bytes after each
  event, compare final files and independent per-body charges to the claims.

Every chosen emitted JSON copy, both nonempty illustrative logs, manifest's own
canonical bytes, initial index, final-index staging and old/new coexistence are
charged. Renaming the staging inode is not a second data write. The old initial
index stops being live only on the conditional atomic replacement; its write
remains in the cumulative total. No unbounded update schedule is claimed.

Initial/final byte snapshots refer to BEFORE each record's own write. The final
index/process/export/manifest form an acyclic digest chain. All 22 standalone
slots and result inline copies agree; returned exact descriptors hash payloads,
not wrappers. Field presence is not used as a comparison or selection predicate.

The fixed-case checker independently evaluates the already supplied static N=3
identities using stdlib Fraction, without the library's numerical functions:
signed/prefix equality, fitted signed/increment/residual outputs, every component
bound, analytic input gradient, qualification and minimum supplied rank. This is
finite preparation arithmetic, not production fitting or measured worker results.

Tests were added as vertical RED/GREEN steps. Invalid-success and inner-binding
controls rebuild outer hashes and byte snapshots before rejection; false exact
payloads also recompute their returned descriptor hashes. The four omission
controls retain component names and recompute all totals after dropping an actual
positive charge. These test equation correspondence, not merely named membership.

Only this fixed selected branch is accepted. No claim is made about other schema
roots, unsupported-case exports, FIT-REAL outcomes, perturbation/AD semantics,
dynamic refusal, all 560 cases, universal resource sufficiency, real execution,
continuous/roundoff error, peak memory, A2 acceptance or Phase A closure.

Independent review is required before reporting this fixed-case increment as
approved. The earlier failed broad models and their verdicts remain unchanged.
