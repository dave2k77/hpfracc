"""Reviewer controls of the SAME fixed trace; includes one blocking RED."""
import copy
import importlib.util
import json
from pathlib import Path
import pytest
from a2_independent_proof import enc,sha
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('a2_reviewed',HERE/'copied/a2_trace.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
OUT=HERE/'targeted-fixtures'
OUT.mkdir(exist_ok=True)

def ledger_of(t):
    bodies={p:enc(v) for p,v in t['records'].items()}|{p:bytes.fromhex(v) for p,v in t['logs'].items()}|{'INITIAL_INDEX':enc(t['initial_index'])}
    state={};terms={};cumulative=peak=0
    for event in t['events']:
        if event['op']=='write':
            state[event['path']]=bodies[event['body']];terms[event['body']]=len(bodies[event['body']]);cumulative+=len(bodies[event['body']])
        else:state[event['target']]=state.pop(event['source'])
        peak=max(peak,sum(map(len,state.values())))
    return {'terms':terms,'cumulative_written_bytes':cumulative,'final_live_bytes':sum(map(len,state.values())),'peak_live_bytes':peak,'index_transaction_bytes':sum(len(bodies[p]) for p in ['INITIAL_INDEX','failure-index.json','records/process.json','records/export.json','records/output-control.json']),'temporary_bytes_charged':len(bodies['failure-index.json']),'old_index_bytes_charged':len(bodies['INITIAL_INDEX'])}

def outer(t):
    records=t['records'];files={p:enc(v) for p,v in records.items()}|{p:bytes.fromhex(v) for p,v in t['logs'].items()}
    assert {e['path']:(e['bytes'],e['sha256']) for e in records['run-manifest.json']['files']}=={p:(len(b),sha(b)) for p,b in files.items() if p!='run-manifest.json'}
    assert records['records/export.json']['failure_index_sha256']==sha(files['failure-index.json'])
    assert records['records/export.json']['process_sha256']==sha(files['records/process.json'])
    for b in records.values():
        if b['record_type']=='producer_binding':
            for returned in b['returned']:assert records['arrays/'+returned['slot_id']+'.json']['producer_binding_sha256']==sha(enc(b))

def preserve(name,t):
    (OUT/(name+'.json')).write_text(json.dumps(t,indent=2)+'\n')
    outer(t)

@pytest.mark.parametrize('component',['logs/stdout.bin','logs/stderr.bin','run-manifest.json','INITIAL_INDEX','failure-index.json','records/export.json','records/output-control.json','arrays/S-1-D_hat.json'])
def test_omitted_positive_charge_with_all_totals_recomputed(component):
    t=a.make_trace();assert t['ledger']==ledger_of(t)
    claimed=t['ledger'];terms=claimed['terms'];assert terms[component]>0;terms[component]=0
    claimed.update(cumulative_written_bytes=sum(terms.values()),final_live_bytes=sum(v for k,v in terms.items() if k!='INITIAL_INDEX'))
    claimed.update(peak_live_bytes=max(claimed['final_live_bytes'],claimed['final_live_bytes']+terms['INITIAL_INDEX']-terms['records/export.json']-terms['run-manifest.json']),index_transaction_bytes=sum(terms[p] for p in ['INITIAL_INDEX','failure-index.json','records/process.json','records/export.json','records/output-control.json']),temporary_bytes_charged=terms['failure-index.json'],old_index_bytes_charged=terms['INITIAL_INDEX'])
    preserve('charge-'+component.replace('/','_'),t)
    with pytest.raises(ValueError,match='ledger claim'):a.verify_trace(t)

@pytest.mark.parametrize('fault',['unknown-unselected','unknown-selected','wrong-winner','same-source-wrong-mode','same-source-wrong-descriptor','wrong-dt','wrong-source','wrong-occurrence','wrong-slot-case','rebound-false-gradient','phase-reversed'])
def test_inner_semantic_negative_after_rebinding(fault):
    def mutate(records):
        b=records['records/binding-host-0.json']
        if fault.startswith('unknown-'):
            i=0 if fault=='unknown-unselected' else 1
            records['result.json']['assessments'][i].update(status='unknown',qualifies=None)
        elif fault=='wrong-winner':records['result.json']['selected_id']='bad1-f64-GL'
        elif fault=='same-source-wrong-mode':b['mode']='jit'
        elif fault=='same-source-wrong-descriptor':b['returned'][0]['descriptor']['values_count']=2
        elif fault=='wrong-dt':b['dt']=copy.deepcopy(b['alpha'])
        elif fault=='wrong-source':b['sources'][0]['sha256']='0'*64
        elif fault=='wrong-occurrence':b.update(candidate_index=1,candidate_id='a-good2-f64-GL')
        elif fault=='wrong-slot-case':records['arrays/S-0-g_hat.json']['case_id']='other-case'
        elif fault=='rebound-false-gradient':
            sid='S-1-analytic_input_gradient';payload=records['arrays/'+sid+'.json']['exact_array'];payload['values'][0]={'num':'3','den':'1'}
            for record in records.values():
                if record['record_type']=='producer_binding':
                    for ret in record['returned']:
                        if ret['slot_id']==sid:ret['descriptor']['payload_sha256']=sha(enc(payload))
        else:records['records/process.json']['phases']['preflight'].update(start_ns=11,end_ns=1)
    t=a.make_trace(mutate);preserve(fault,t);assert t['ledger']==ledger_of(t)
    with pytest.raises(ValueError,match='binding|selection|identity|phase'):a.verify_trace(t)

@pytest.mark.parametrize('fault',['omit-log-write','slot-before-binding','export-before-index-replace'])
def test_journal_omission_or_reordering(fault):
    t=a.make_trace();events=t['events']
    if fault=='omit-log-write':events[:]=[e for e in events if e.get('body')!='logs/stdout.bin']
    elif fault=='slot-before-binding':
        i=next(i for i,e in enumerate(events) if e.get('body')=='arrays/S-0-g_hat.json');j=next(i for i,e in enumerate(events) if e.get('body')=='records/binding-host-0.json');events[i],events[j]=events[j],events[i]
    else:
        i=next(i for i,e in enumerate(events) if e['op']=='replace');j=next(i for i,e in enumerate(events) if e.get('body')=='records/export.json');events[i],events[j]=events[j],events[i]
    # Rebuild the claimed ledger from the altered journal: no stale summary trap.
    t['ledger']=ledger_of(t);preserve(fault,t)
    with pytest.raises((ValueError,KeyError)):a.verify_trace(t)

def test_binding_filename_must_match_its_declared_binding_id():
    def mutate(records):records['records/binding-host-0.json']['binding_id']='host-1'
    t=a.make_trace(mutate);preserve('binding-route-mismatch',t);assert t['ledger']==ledger_of(t)
    assert t['records']['records/binding-host-0.json']['binding_id']=='host-1'
    assert t['records']['records/binding-host-1.json']['binding_id']=='host-1'
    # x-artifact-routing freezes records/binding-{binding_id}.json.
    # This is expected to reject; frozen implementation currently ACCEPTS it.
    with pytest.raises(ValueError):a.verify_trace(t)
