"""Independent finite proof over preserved JSON, not the author's builder.

Only fixed N=3 static fixture arithmetic and byte materialization. No JAX,
production numerical calls, runtime counters, worker or security certification.
"""
from pathlib import Path
from fractions import Fraction as F
import copy
import hashlib
import json
import math
import os
import re
import struct

HERE=Path(__file__).resolve().parent
REPO=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
PACKET=REPO/'docs/validation/audits/a2-preparation-2026-11-11'
COPIED=HERE/'copied'
CASE='REF-PASS-f64-GL'
def load(p):return json.loads(p.read_bytes())
def enc(x):return json.dumps(x,ensure_ascii=True,allow_nan=False,sort_keys=True,separators=(',',':')).encode('ascii')
def sha(x):return hashlib.sha256(x).hexdigest()
def put(n,x):(HERE/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def eq(a,b):
    assert type(a)==type(b),(type(a),type(b))
    if type(a)==dict:
        assert a.keys()==b.keys(),(a.keys(),b.keys())
        for k in a:eq(a[k],b[k])
    elif type(a) in (list,tuple):
        assert len(a)==len(b),(len(a),len(b))
        for x,y in zip(a,b,strict=True):eq(x,y)
    else:assert a==b,(a,b)
def rat(x):
    n,d=int(x['num'],16),int(x['den'],16)
    assert d>0 and math.gcd(abs(n),d)==1
    return F(n,d)
def raw(x):
    b=bytes.fromhex(x['raw_hex']);assert sha(b)==x['sha256']
    assert x['dtype']=='float64' and x['layout']=='C' and x['byte_order']=='little'
    assert len(b)==x['nbytes']==math.prod(x['shape'])*8
    values=struct.unpack('<'+'d'*(len(b)//8),b)
    assert all(math.isfinite(x) for x in values)
    return [F.from_float(v) for v in values]
def desc(x):return {k:v for k,v in x.items() if k!='raw_hex'}

# A separate interpreter of the frozen, bounded schema vocabulary.
def validate(v,s,defs):
    if '$ref' in s:
        return validate(v,defs[s['$ref'].split('/')[-1]],defs)
    for alt in ('oneOf','anyOf'):
        if alt in s:
            count=0
            for r in s[alt]:
                try:validate(v,r,defs);count+=1
                except AssertionError:pass
            assert count==1 if alt=='oneOf' else count>0
    if 'enum' in s:assert any(type(v)==type(x) and v==x for x in s['enum'])
    if 'type' in s:assert type(v)=={'object':dict,'array':list,'string':str,'integer':int,'boolean':bool,'null':type(None)}[s['type']]
    if type(v)==dict and 'properties' in s:
        assert set(s.get('required',[]))<=set(v)
        if not s.get('additionalProperties',True):assert set(v)<=set(s['properties'])
        for k,x in v.items():validate(x,s['properties'][k],defs)
    if type(v)==list:
        assert s.get('minItems',0)<=len(v)<=s.get('maxItems',10**9)
        if 'items' in s:
            for x in v:validate(x,s['items'],defs)
    if type(v)==str:
        assert s.get('minLength',0)<=len(v)<=s.get('maxLength',10**9)
        if 'pattern' in s:assert re.fullmatch(s['pattern'],v)
    if type(v)==int:assert s.get('minimum',-10**30)<=v<=s.get('maximum',10**30)

def tree_metrics(v):
    stack=[(v,1)];nodes=depth=0
    while stack:
        item,d=stack.pop();nodes+=1;depth=max(depth,d)
        if type(item)==dict:
            stack += [(k,d+1) for k in item]
            stack += [(x,d+1) for x in item.values()]
        elif type(item)==list:stack += [(x,d+1) for x in item]
    return nodes,depth

def main():
    t=load(COPIED/'trace.json');a=load(COPIED/'authority.json')
    fixtures=load(PACKET/'fixtures.json');witnesses=load(PACKET/'schema-control-fixtures.json')
    case=next(c for c in fixtures['cases'] if c['case_id']==CASE)
    bundle=next(b for b in witnesses['bundles'] if b['witness_id']=='selected-'+CASE)
    eq(a['case'],case);eq(a['bundle'],bundle);eq(a['working_scalars'],fixtures['working_scalars'])
    eq(a['label'],witnesses['label']);eq(a['packet_digest'],witnesses['hypothetical_external_packet_sha256'])
    packetraw=(PACKET/'packet-manifest.json').read_bytes();packet=load(PACKET/'packet-manifest.json')
    assert a['packet_digest']!=sha(packetraw)
    for row in packet['files']:
        b=(REPO/row['repo_path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
    for name in ['protocol.json','record-schemas.json']:assert (COPIED/name).read_bytes()==(PACKET/name).read_bytes()
    r=t['records'];inp=r['input-bundle.json'];q=inp['request'];schema=load(COPIED/'record-schemas.json');caps=load(COPIED/'protocol.json')['caps']
    eq(t['case_id'],CASE);eq(t['label'],a['label']);eq(set_as_list(r),set_as_list(bundle['artifacts']))
    expected=copy.deepcopy(case['request']);expected.pop('caps_ref');expected['caps']=caps
    expected['input']=fixtures['arrays'][expected.pop('input_ref')]
    expected['candidates']=[]
    for cid in expected.pop('candidate_refs'):
        c=copy.deepcopy(fixtures['candidates'][cid]);c['rhos']=fixtures['arrays'][c.pop('rhos_ref')];c['coefficients']=fixtures['arrays'][c.pop('coefficients_ref')];c['record_type']='candidate';expected['candidates'].append(c)
    # Remaining metadata is explicitly hypothetical, never the actual packet digest.
    expected.update(record_type='request',request_id=CASE,case_id=CASE,policy_id=fixtures['protocol_id'],packet_manifest_sha256=a['packet_digest'])
    eq(q,expected);eq(r['records/request.json'],q)
    eq(q['caps'],caps)
    eq(inp['sources'],bundle['artifacts']['input-bundle.json']['sources'])
    for source in inp['sources']:assert sha((REPO/source['repo_path']).read_bytes())==source['sha256']
    assert inp['raw_request_utf8_hex']=='' and inp['raw_request_sha256']==sha(enc(q))
    route_definitions={};table={}
    for path,v in r.items():
        assert not path.startswith('/') and '..' not in path.split('/') and '\\' not in path
        if path.startswith('arrays/'):
            assert path=='arrays/'+v['slot_id']+'.json';ref='#/$defs/slot'
        elif v['record_type']=='producer_binding':
            assert path=='records/binding-'+v['binding_id']+'.json';ref='#/$defs/producer_binding'
        elif v['record_type']=='candidate':
            index=int(path.removeprefix('records/candidate-').removesuffix('.json'));eq(v,q['candidates'][index]);ref='#/$defs/supplied_candidate'
        else:ref=schema['x-artifact-routing'][path]
        validate(v,schema['$defs'][ref.split('/')[-1]],schema['$defs'])
        nodes,depth=tree_metrics(v)
        assert nodes<=caps['json_nodes'] and depth<=caps['json_depth']
        table[path]={'bytes':len(enc(v)),'sha256':sha(enc(v)),'nodes':nodes,'depth':depth,'route':ref}
        route_definitions[path]=ref
    validate(t['initial_index'],schema['$defs']['failure_index'],schema['$defs'])
    assert len(r)==36
    eq(table,{p:meta|{'route':route_definitions[p]} for p,meta in load(Path('/home/davianc/.hermes/cache/scratch/a2-single-trace-20261112/record-sizes.json')).items()})
    launch=r['records/launch.json'];process=r['records/process.json'];result=r['result.json'];index=r['failure-index.json'];export=r['records/export.json']
    for v in r.values():
        for field in ['case_id','request_id']:
            if field in v:eq(v[field],CASE)
        for field in ['run_id','process_id']:
            if field in v:eq(v[field],launch[field])
        if 'packet_manifest_sha256' in v:eq(v['packet_manifest_sha256'],a['packet_digest'])
        if 'input_bundle_sha256' in v:eq(v['input_bundle_sha256'],sha(enc(inp)))
        if 'policy_id' in v:eq(v['policy_id'],q['policy_id'])
    assert launch['status']=='launched' and launch['barrier']=='held'
    eq(launch['sources'],inp['sources']);eq(process['command'],launch['command']);eq(process['launch_receipt_sha256'],sha(enc(launch)))
    assert process['termination']=='normal' and process['exit_code']==0 and process['exit_confirmed'] is True and process['watchdog_triggered'] is False and process['barrier']=='released'
    for key in ['preflight','watchdog']:
        ph=process['phases'][key];assert ph['status']=='observed' and ph['reason']=='none' and ph['start_ns']<=ph['end_ns'] and ph['elapsed_ns']==ph['end_ns']-ph['start_ns']
    assert process['phases']['preflight']['end_ns']<=launch['launch_monotonic_ns']==process['phases']['watchdog']['start_ns']
    assert process['elapsed_monotonic_ns']==process['phases']['watchdog']['elapsed_ns']
    for key in ['grace','kill_to_exit']:eq(process['phases'][key],{'status':'not_applicable','start_ns':None,'end_ns':None,'elapsed_ns':None,'reason':'stage_not_used'})
    ph=export['index_write'];assert ph['status']=='observed' and ph['reason']=='none' and process['phases']['watchdog']['end_ns']<=ph['start_ns']<=ph['end_ns'] and ph['elapsed_ns']==ph['end_ns']-ph['start_ns']
    eq(index['process'],process);eq(export['process_sha256'],sha(enc(process)));eq(export['failure_index_sha256'],sha(enc(index)));eq(export['failure_index_bytes'],len(enc(index)))
    assert index['status']==export['status']=='complete' and index['reasons']==export['reasons']==['none']
    for flag in ['arithmetic_verified','total_numerical_certified','a2_acceptance_passed','implementation_authorized']:assert result[flag] is False
    control=r['records/output-control.json'];assert control['status']=='safe' and control['reasons']==['none']
    for key in ['fresh_private_root','subdirs_private','nofollow_verified','regular_owned_single_link','containment_verified']:assert control[key] is True
    slots=[s for s in r.values() if s['record_type']=='slot'];assert len(slots)==22
    ids=[c['stable_id'] for c in q['candidates']];occ=[{'candidate_index':i,'candidate_id':cid} for i,cid in enumerate(ids)]
    eq(inp['candidate_ids'],ids);eq(index['candidate_ids'],ids);eq(inp['candidate_occurrences'],occ);eq(index['candidate_occurrences'],occ)
    eq(inp['required_comparisons'],[]);eq(inp['required_binding_checks'],[]);eq(index['comparisons'],[]);eq(index['binding_checks'],[])
    expected_inventory=[];shared=[];candidate_slots={0:[],1:[]};payloads={}
    for template in case['required_evidence_slots']:
        sid=template['slot_id'];s=r['arrays/'+sid+'.json'];i=template['candidate_index']
        identity={k:template[k] for k in ['slot_id','candidate_index','mode','branch','quantity']};identity['candidate_id']=None if i is None else ids[i]
        for k,v in identity.items():eq(s[k],v)
        expected_inventory.append(identity)
        assert s['status']=='complete' and s['reason']=='none' and s['reasons']==['none'] and s['raw_array'] is None
        payload=s['exact_array'];shape=[] if s['quantity']=='epsilon' else [3,3] if s['quantity']=='L_hat' else [3]
        eq(payload['shape'],shape);assert len(payload['values'])==math.prod(shape)
        payloads[sid]=[rat(x) for x in payload['values']]
        (shared if i is None else candidate_slots[i]).append(s)
    eq(inp['required_slots'],expected_inventory);eq(result['shared_slots'],shared)
    assert len(result['assessments'])==2
    for i,assessment in enumerate(result['assessments']):eq(assessment['slots'],candidate_slots[i])
    for suffix,i in [('X',None),('0',0),('1',1)]:
        b=r['records/binding-host-'+suffix+'.json'];expect_slots=shared if i is None else candidate_slots[i]
        assert b['mode']==('shared' if i is None else 'synthetic') and b['branch']=='base' and b['candidate_index']==i and b['candidate_id']==(None if i is None else ids[i])
        context=bundle['artifacts']['records/binding-host-X.json'] if i is None else q['candidates'][i]
        eq(b['configuration'],context['configuration']);eq(b['producer'],context['producer']);eq(b['sources'],inp['sources']);eq(b['launch_receipt_sha256'],sha(enc(launch)))
        eq(b['input'],desc(q['input']));eq(b['alpha'],desc(fixtures['working_scalars']['float64']['alpha']));eq(b['dt'],desc(fixtures['working_scalars']['float64']['dt']));assert b['h'] is None and b['direction'] is None
        returned=[]
        for s in expect_slots:
            payload=s['exact_array'];returned.append({'slot_id':s['slot_id'],'quantity':s['quantity'],'descriptor':{'shape':payload['shape'],'values_count':len(payload['values']),'payload_sha256':sha(enc(payload))}})
            eq(s['producer_binding_sha256'],sha(enc(b)))
        eq(b['returned'],returned)
    for row,identity in zip(index['slots'],expected_inventory,strict=True):
        s=r['arrays/'+identity['slot_id']+'.json']
        for k,v in identity.items():eq(row[k],v)
        assert row['status']=='complete' and row['reason']=='none' and row['reasons']==['none']
        eq(row['expected_shape'],s['exact_array']['shape']);eq(row['completed_shape'],row['expected_shape']);eq(row['artifact'],{'path':'arrays/'+s['slot_id']+'.json','bytes':len(enc(s)),'sha256':sha(enc(s))})
    eq({k:v for k,v in t['initial_index'].items() if k!='bytes_accounting'},{k:v for k,v in bundle['initial_failure_index'].items() if k!='bytes_accounting'})
    # Derive weights by GL recurrence from decoded alpha, not stored constants.
    alpha=raw(fixtures['working_scalars']['float64']['alpha'])[0];dt=raw(fixtures['working_scalars']['float64']['dt'])[0]
    assert alpha==rat(q['alpha'])==F(1,2) and dt==rat(q['dt'])==F(1,4)
    scale=F(1,math.isqrt(dt.numerator))/F(1,math.isqrt(dt.denominator));assert scale==2
    x=raw(q['input']);w=[F(1)]
    for k in range(1,3):w.append(w[-1]*(F(k-1)-alpha)/k)
    g=[sum(w[:k+1]) for k in range(3)];v=[x[0]]+[x[k]-x[k-1] for k in range(1,3)]
    direct=[scale*sum(w[k]*x[n-k] for k in range(n+1)) for n in range(3)]
    for key,value in {'w':w,'g':g,'v':v,'D':direct}.items():eq(payloads['S-X-'+key],value)
    arithmetic={};qualifiers=[]
    for i,c in enumerate(q['candidates']):
        rho=raw(c['rhos']);coef=raw(c['coefficients']);assert len(rho)==len(coef)==c['configuration']['pole_count'] and all(z>=0 for z in coef) and all(0<z<=1 for z in rho)
        gh=[F(1)]+[sum(cc*rr**(k-1) for cc,rr in zip(coef,rho,strict=True)) for k in range(1,3)]
        residual=[gh[k]-g[k] for k in range(3)];epsilon=max(map(abs,residual));wh=[gh[0]]+[gh[k]-gh[k-1] for k in range(1,3)]
        matrix=[[scale*wh[n-j] if j<=n else F(0) for j in range(3)] for n in range(3)]
        out=[sum(matrix[n][j]*x[j] for j in range(3)) for n in range(3)]
        assert out==[scale*sum(gh[k]*v[n-k] for k in range(n+1)) for n in range(3)]
        assert [out[k]-direct[k] for k in range(3)]==[scale*sum(residual[k]*v[n-k] for k in range(n+1)) for n in range(3)]
        error=[abs(out[k]-direct[k]) for k in range(3)]
        # r[0]=0: residual tail multiplies v[0:n].
        bound=[scale*epsilon*sum(abs(v[j]) for j in range(n)) for n in range(3)]
        assert all(error[k]<=bound[k] for k in range(3))
        # Differentiate mean(D_hat**2) coordinate-wise.
        gradient=[sum(F(2,3)*out[n]*matrix[n][j] for n in range(3)) for j in range(3)]
        quantities={'g_hat':gh,'residual':residual,'epsilon':[epsilon],'signed_fitted_weights':wh,'L_hat':sum(matrix,[]),'D_hat':out,'error':error,'B':bound,'analytic_input_gradient':gradient}
        for k,value in quantities.items():eq(payloads[f'S-{i}-{k}'],value)
        qualifies=all(z<=rat(q['tau']) for z in bound);assessment=result['assessments'][i]
        assert assessment['candidate_index']==i and assessment['candidate_id']==ids[i] and assessment['qualifies'] is qualifies and assessment['status']==('known_qualifying' if qualifies else 'known_rejected_by_bound') and assessment['reasons']==['none']
        if qualifies:qualifiers.append((c['configuration']['pole_count'],ids[i].encode('ascii')))
        arithmetic[ids[i]]={k:list(map(str,value)) for k,value in quantities.items()}|{'qualifies':qualifies}
    assert result['status']=='selected' and result['reasons']==['none'] and result['selected_id']==min(qualifiers)[1].decode('ascii')
    # Materialize each scheduled body into a fresh owned reviewer sandbox.
    bodies={p:enc(v) for p,v in r.items()}|{p:bytes.fromhex(v) for p,v in t['logs'].items()};bodies['INITIAL_INDEX']=enc(t['initial_index'])
    root=HERE/'materialized';root.mkdir(exist_ok=False);timeline=[];cumulative=peak=0;terms={};snapshots={};positions={}
    for step,event in enumerate(t['events']):
        if event['op']=='write':
            name=event['body'];positions[name]=step;target=root/event['path'];target.parent.mkdir(exist_ok=True,parents=True)
            live_before=sum(p.stat().st_size for p in root.rglob('*') if p.is_file())
            snapshots[name]={'live_bytes':live_before,'cumulative_written_bytes':cumulative}
            with target.open('xb') as handle:written=handle.write(bodies[name]);assert written==len(bodies[name])
            assert name not in terms;terms[name]=target.stat().st_size;cumulative+=written
        else:
            assert event=={'op':'replace','source':'tmp/index-final.part','target':'failure-index.json'}
            staging=root/event['source'];target=root/event['target'];assert target.read_bytes()==bodies['INITIAL_INDEX'] and staging.read_bytes()==bodies['failure-index.json'];inode=staging.stat().st_ino;os.replace(staging,target);assert target.stat().st_ino==inode
        sizes={p.relative_to(root).as_posix():p.stat().st_size for p in root.rglob('*') if p.is_file()};live=sum(sizes.values());peak=max(peak,live)
        timeline.append({'step':step,'event':event,'live_bytes':live,'cumulative_written_bytes':cumulative,'files':sizes})
    actual={p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file()}
    eq({p:sha(b) for p,b in actual.items()},{p:sha(b) for p,b in bodies.items() if p!='INITIAL_INDEX'})
    assert set(terms)==set(bodies) and len(actual)==38
    manifest=r['run-manifest.json'];eq({e['path']:(e['bytes'],e['sha256']) for e in manifest['files']},{p:(len(b),sha(b)) for p,b in actual.items() if p!='run-manifest.json'})
    assert len(manifest['files'])==37 and manifest['self_hash_excluded'] is True and terms['run-manifest.json']==len(enc(manifest))
    for stream in ['stdout','stderr']:
        b=actual['logs/'+stream+'.bin'];assert len(b)<=caps[stream+'_bytes'] and sha(b)==process[stream+'_sha256'] and process[stream+'_truncated'] is False
    assert result['evidence_bytes']==snapshots['result.json']['live_bytes']
    for key,record in [('INITIAL_INDEX',t['initial_index']),('failure-index.json',index)]:eq(record['bytes_accounting'],snapshots[key]|{'reserved_final_transaction_bytes':caps['failure_index_bytes']})
    transaction=sum(len(bodies[p]) for p in ['INITIAL_INDEX','failure-index.json','records/process.json','records/export.json','records/output-control.json'])
    ledger={'terms':terms,'cumulative_written_bytes':cumulative,'final_live_bytes':sum(map(len,actual.values())),'peak_live_bytes':peak,'index_transaction_bytes':transaction,'temporary_bytes_charged':len(bodies['failure-index.json']),'old_index_bytes_charged':len(bodies['INITIAL_INDEX'])}
    eq(ledger,t['ledger']);assert cumulative<=caps['evidence_bytes'] and peak<=caps['evidence_bytes'] and transaction<=caps['failure_index_bytes']
    assert positions['input-bundle.json']==0 and positions['INITIAL_INDEX']==1 and positions['records/launch.json']==2
    for path,b in r.items():
        if b['record_type']=='producer_binding':
            assert positions['records/launch.json']<positions[path]
            for returned in b['returned']:assert positions[path]<positions['arrays/'+returned['slot_id']+'.json']<positions['result.json']
    assert positions['result.json']<positions['records/process.json']<positions['failure-index.json']
    assert max(positions['logs/stdout.bin'],positions['logs/stderr.bin'])<positions['records/process.json']
    assert positions['records/output-control.json']<positions['failure-index.json']
    replacement=next(i for i,e in enumerate(t['events']) if e['op']=='replace')
    assert positions['failure-index.json']<replacement<positions['records/export.json']<positions['run-manifest.json']==len(t['events'])-1
    put('independent-record-table.json',table);put('materialization-timeline.json',timeline);put('independent-exact-arithmetic.json',arithmetic)
    report={'case_id':CASE,'records':len(r),'slots':len(slots),'files':len(actual),'journal_events':len(t['events']),'writes':len(terms),'index_generations':2,'max_record_nodes':max(x['nodes'] for x in table.values()),'max_record_depth':max(x['depth'] for x in table.values()),'ledger':ledger,'actual_packet_sha256':sha(packetraw),'hypothetical_packet_digest':a['packet_digest'],'authority_frozen_slice_verified':True,'qualification_winner':result['selected_id'],'scope':'Finite STATIC fixed-case relationships and actual reviewer byte-materialization only; not worker/security/counter/runtime evidence'}
    put('independent-positive-proof.json',report);print(json.dumps(report,indent=2))
def set_as_list(x):return sorted(x)
if __name__=='__main__':main()
