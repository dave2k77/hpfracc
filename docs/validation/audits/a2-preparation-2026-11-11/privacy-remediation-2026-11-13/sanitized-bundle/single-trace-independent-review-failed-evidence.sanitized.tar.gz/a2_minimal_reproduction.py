"""Minimal fixed-target routing counterexample. Expected real exit: 1.

All files read from this reviewer's verified copy. Nothing is repaired.
"""
import importlib.util
import json
from pathlib import Path
from a2_independent_proof import enc,load,sha
from test_a2_independent_negatives import outer,ledger_of
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('a2_frozen',HERE/'copied/a2_trace.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
positive=load(HERE/'copied/trace.json')
assert enc(a.make_trace())==enc(positive)
a.verify_trace(positive)
def mutate(records):
    records['records/binding-host-0.json']['binding_id']='host-1'
t=a.make_trace(mutate)
outer(t)
assert t['ledger']==ledger_of(t)
assert t['records']['records/binding-host-0.json']['sources']==positive['records']['records/binding-host-0.json']['sources']
# Every schema, exact-array, phase, linkage and ledger predicate accepts this.
accepted=a.verify_trace(t)
actual='records/binding-host-0.json'
required='records/binding-'+t['records'][actual]['binding_id']+'.json'
receipt={'frozen_positive_artifact_verified':True,'frozen_builder_equals_preserved_artifact':True,'changed_field':'records/binding-host-0.json#/binding_id','old_value':'host-0','new_value':'host-1','all_outer_checksums_rebuilt_and_independently_checked':True,'independent_byte_ledger_agrees':True,'actual_path':actual,'normatively_required_path':required,'actual_checker_accepted':True,'reference':'record-schemas.json#/x-artifact-routing and schema-control-contract.md lines 233-240','source_sha256':sha((HERE/'copied/a2_trace.py').read_bytes()),'implementation_authorized':False,'protocol_freeze_authorized':False,'a2_acceptance_passed':False,'broader_accounting_proved':False}
(HERE/'minimal-reproduction-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
assert actual==required,'Frozen audit accepted a binding artifact whose path contradicts its declared binding_id'
