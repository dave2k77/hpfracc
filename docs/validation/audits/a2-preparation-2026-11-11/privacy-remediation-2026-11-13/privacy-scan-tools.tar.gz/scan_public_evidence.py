"""Read-only bounded discovery; never emit identifier values or raw bodies."""
import gzip
import hashlib
import io
import json
import re
import sys
import tarfile
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
HOLD = json.loads((AUDIT / 'single-trace-privacy-hold.json').read_text())
PRIVATE = Path(HOLD['private_original_path'])
assert hashlib.sha256(PRIVATE.read_bytes()).hexdigest() == HOLD['original_sha256']
SENSITIVE = {'chat_id', 'message_id', 'user_id', 'phone_number', 'access_token', 'bot_token', 'api_key', 'password'}
findings = []
visited = 0
expanded = 0
chat_tokens = set()
with tarfile.open(PRIVATE, 'r:gz') as archive:
    for item in HOLD['structured_json_identifier_scan'][PRIVATE.name]:
        raw = archive.extractfile(item['path']).read()
        assert hashlib.sha256(raw).hexdigest() == item['sha256']
        data = json.loads(raw)
        def collect(obj):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    if key == 'chat_id' and isinstance(value, (str, int)):
                        chat_tokens.add(str(value).encode())
                    collect(value)
            elif isinstance(obj, list):
                for value in obj:
                    collect(value)
        collect(data)

def fields(obj):
    out = set()
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key in SENSITIVE and isinstance(value, (str, int)) and value not in ('', False):
                out.add(key)
            out.update(fields(value))
    elif isinstance(obj, list):
        for value in obj:
            out.update(fields(value))
    return out

def scan(label, body, depth=0):
    global visited, expanded
    visited += 1
    expanded += len(body)
    assert depth < 12 and expanded < 512 * 1024 * 1024
    if body.startswith(b'\x1f\x8b'):
        unpacked = gzip.decompress(body)
        scan(label + '::gzip', unpacked, depth + 1)
        return
    if len(body) > 262 and body[257:262] == b'ustar':
        with tarfile.open(fileobj=io.BytesIO(body), mode='r:') as archive:
            for member in archive.getmembers():
                if member.isfile():
                    scan(label + '::' + member.name, archive.extractfile(member).read(), depth + 1)
                else:
                    findings.append({'path': label + '::' + member.name, 'kind': 'nonregular'})
        return
    reasons = []
    if any(token in body for token in chat_tokens):
        reasons.append('known-private-chat-identifier')
    try:
        data = json.loads(body)
    except (ValueError, UnicodeError):
        data = None
    keys = sorted(fields(data))
    if keys:
        reasons.append('structured-identifier-fields')
    if re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9]{24,}|[0-9]{8,12}:[A-Za-z0-9_-]{30,})', body):
        reasons.append('credential-shaped-token')
    if reasons:
        findings.append({'path': label, 'reasons': reasons, 'field_names': keys})

manifest = json.loads(Path(sys.argv[1]).read_text())
for name, expected in manifest['files'].items():
    path = ROOT / name
    assert not path.is_symlink()
    body = path.read_bytes()
    assert len(body) == expected['bytes']
    assert hashlib.sha256(body).hexdigest() == expected['sha256']
    scan(name, body)
scan('PRIVATE_ORIGINAL', PRIVATE.read_bytes())
public_findings = [row for row in findings if not row['path'].startswith('PRIVATE_ORIGINAL::')]
expected_private = HOLD['structured_json_identifier_scan'][PRIVATE.name]
expected_paths = {'PRIVATE_ORIGINAL::gzip::' + row['path'] for row in expected_private}
actual_paths = {row['path'] for row in findings if row['path'].startswith('PRIVATE_ORIGINAL::')}
record = {'visited_bodies': visited, 'expanded_bytes': expanded,
          'input_manifest_sha256': hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest(),
          'public_input_files': len(manifest['files']), 'findings': findings,
          'public_findings': public_findings, 'private_control_matches_exact_hold': actual_paths == expected_paths,
          'values_disclosed': False,
          'limits': 'Bounded structured fields, observed chat token and selected credential patterns; not universal secret detection.'}
print(json.dumps(record, indent=2))
assert not public_findings and actual_paths == expected_paths
