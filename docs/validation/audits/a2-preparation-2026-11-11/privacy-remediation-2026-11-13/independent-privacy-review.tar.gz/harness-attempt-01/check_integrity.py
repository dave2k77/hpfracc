"""Independent in-memory archive, member mapping and captured-run validation."""
import ast
import difflib
import json
import xml.etree.ElementTree as ET
from review_common import (AUDIT, CANDIDATE, DERIVATIVE_PIN, INVENTORY_PIN,
    PRIVATE, ROOT, desc, members, private_identity, put, record, sha, strict)

hold, original = private_identity()
source, _ = members(original)
inventory_raw = (CANDIDATE / 'sanitized-bundle/inventory.json').read_bytes()
assert sha(inventory_raw) == INVENTORY_PIN
inv = strict(inventory_raw)
derivative_path = CANDIDATE / 'sanitized-bundle' / inv['derivative_name']
derivative = derivative_path.read_bytes()
assert sha(derivative) == DERIVATIVE_PIN != sha(original)
assert derivative_path.name != PRIVATE.name
assert derivative[3] == 0 and derivative[4:8] == b'\0' * 4
retained, headers = members(derivative)
assert len(source) == 457 and len(retained) == 449
omissions = hold['structured_json_identifier_scan'][PRIVATE.name]
assert len(omissions) == 8 and len({r['path'] for r in omissions}) == 8
omitted = {r['path']: {'bytes': r['bytes'], 'sha256': r['sha256']} for r in omissions}
assert set(source) == set(retained) | set(omitted)
assert not set(retained) & set(omitted)
rows = []
for name, body in source.items():
    actual = desc(body)
    if name in retained:
        assert body == retained[name]
        assert headers[name] == {'mode': 0o644, 'uid': 0, 'gid': 0, 'mtime': 0,
                                 'uname': '', 'gname': '', 'type': '0', 'pax_headers': {}}
    else:
        assert actual == omitted[name]
    rows.append({'path': name, **actual,
                 'disposition': 'retained-byte-identical' if name in retained else 'omitted-exact-hold-entry'})
def descriptors(data):
    return [{'path': k, **desc(v)} for k, v in sorted(data.items())]
assert inv['original_members'] == descriptors(source)
assert inv['retained'] == descriptors(retained)
assert inv['omitted'] == [{'path': k, **v} for k,v in sorted(omitted.items())]
assert inv['original_member_count'] == len(source)
assert inv['original_bytes'] == len(original) and inv['original_sha256'] == sha(original)
assert inv['derivative_bytes'] == len(derivative) and inv['derivative_sha256'] == sha(derivative)
assert inv['historical_replay_closure_complete'] is False
assert inv['historical_manifests_are_authoritative_for_derivative'] is False
assert inv['privacy_scan_is_separate'] is True
historical_references = [name for name, body in retained.items()
                        if any(r['path'].encode() in body or r['sha256'].encode() in body for r in omissions)]
record('original-derivative-mapping.json', {
    'original_identity': desc(original), 'private_original_file_mode': '0600',
    'private_original_parent_mode': '0700', 'old_repository_path_absent': True,
    'derivative_identity': desc(derivative), 'inventory_identity': desc(inventory_raw),
    'original_members': len(source), 'retained_members': len(retained), 'omitted_members': len(omitted),
    'mapping': sorted(rows, key=lambda r:r['path']),
    'all_retained_headers_normalized': True, 'gzip_timestamp_zero_and_no_optional_headers': True,
    'historical_reference_paths_preserved': sorted(historical_references),
    'no_filesystem_extraction': True, 'private_receipt_bodies_not_copied': True})
# Drop private bodies before processing any public capture records.
del original, source

def xml_counts(body):
    root = ET.fromstring(body)
    cases = root.findall('.//testcase')
    counts = {'tests': len(cases), 'failures': len(root.findall('.//failure')),
              'errors': len(root.findall('.//error')), 'skipped': len(root.findall('.//skipped'))}
    suites = root.findall('.//testsuite')
    for key,value in counts.items():
        assert sum(int(s.get(key, '0')) for s in suites) == value
    ids = [(c.get('classname'), c.get('name')) for c in cases]
    assert len(ids) == len(set(ids))
    return root, counts, ids

all_runs = {}
archive_results = []
mutant_diffs = []
current_helper = (CANDIDATE / 'sanitize_evidence.py').read_bytes()
current_tests = (CANDIDATE / 'test_sanitize_evidence.py').read_bytes()
current_config = (ROOT / 'pyproject.toml').read_bytes()
for archive_name, expected_count in [('packaging-test-runs', 56), ('packaging-mutation-runs', 81)]:
    index = strict((CANDIDATE / (archive_name + '-index.json')).read_bytes())
    body = (CANDIDATE / index['archive']).read_bytes()
    assert sha(body) == index['archive_sha256']
    files, _ = members(body)
    assert len(files) == index['members_verified'] == len(index['members']) == expected_count
    assert {k: desc(v) for k, v in files.items()} == index['members']
    assert all('telegram' not in k.lower() for k in files)
    run_names = sorted({n.split('/')[0] for n in files if n.endswith('/plan.json')})
    records = {}
    for run in run_names:
        prefix = run + '/'
        plan = strict(files[prefix + 'plan.json'])
        receipt = strict(files[prefix + 'receipt.json'])
        before = {n.removeprefix(prefix + 'before/'): b for n,b in files.items() if n.startswith(prefix + 'before/')}
        assert set(before) <= {'pyproject.toml', 'sanitize_evidence.py', 'test_sanitize_evidence.py'}
        assert {k: desc(v) for k,v in before.items()} == plan['input_files']
        assert before['pyproject.toml'] == current_config
        xml = files[prefix + 'raw.xml']
        root, counts, ids = xml_counts(xml)
        assert receipt['xml_sha256'] == sha(xml)
        assert all(receipt[k] == v for k,v in counts.items())
        assert receipt.get('inputs_unchanged', receipt.get('input_pins_unchanged')) is True
        command = plan['command']
        assert command[0] == 'uv' and '--frozen' in command and '--no-sync' in command
        assert any(x.endswith('/before/test_sanitize_evidence.py') for x in command)
        assert any(x == 'no:cacheprovider' for x in command)
        assert any(x.startswith('--basetemp=/home/davianc/.hermes/cache/scratch/') for x in command)
        assert plan['cwd'].endswith('/before')
        observed_exit = receipt['actual_exit']
        assert type(observed_exit) is int
        if counts['failures'] or counts['errors']:
            assert observed_exit != 0
        else:
            assert observed_exit == 0
        failed = [c.get('name') for c in root.findall('.//testcase') if c.find('failure') is not None or c.find('error') is not None]
        if run == 'red-01':
            assert 'sanitize_evidence.py' not in before
            assert b'new packaging helper is absent' in xml
            assert counts['failures'] == 1
        if run == 'red-02':
            assert b'DID NOT RAISE' in xml
            assert failed == ['test_verify_refuses_extra_bundle_files']
        if run == 'reviewed-controls':
            assert before['sanitize_evidence.py'] == current_helper
            assert before['test_sanitize_evidence.py'] == current_tests
            assert counts == {'tests':23, 'failures':0, 'errors':0, 'skipped':0}
        if archive_name == 'packaging-mutation-runs':
            assert before['test_sanitize_evidence.py'] == current_tests
            assert before['sanitize_evidence.py'] != current_helper
            assert counts['tests'] == 23 and counts['failures'] > 0 and counts['errors'] == 0
            ast.parse(before['sanitize_evidence.py'])
            mutant_diffs.extend(difflib.unified_diff(current_helper.decode().splitlines(True),
                before['sanitize_evidence.py'].decode().splitlines(True), fromfile='reviewed-helper', tofile=run))
        records[run] = {'counts': counts, 'actual_exit': observed_exit, 'xml_sha256': sha(xml),
                        'test_identities': ids, 'failed_test_names': failed, 'input_files': plan['input_files']}
    all_runs[archive_name] = records
    archive_results.append({'archive': archive_name, 'identity': desc(body), 'verified_members': len(files),
                            'runs': records})
summary = strict((CANDIDATE / 'mutation-summary.json').read_bytes())
mutants = all_runs['packaging-mutation-runs']
assert len(summary) == len(mutants) == 10
for r in summary:
    actual = mutants[r['mutant']]
    assert r['actual_exit'] == actual['actual_exit'] and r['xml_sha256'] == actual['xml_sha256']
    assert all(r[k] == actual['counts'][k] for k in ('tests','failures','errors'))
    assert r['killed'] is True
record('captured-runs-verification.json', {'archives': archive_results,
    'mutation_guards_killed': len(mutants),
    'limits': 'Archived process records are consistency evidence, not historical OS/process attestation.'})
put('captured-mutant-diffs.patch', ''.join(mutant_diffs).encode())
plans = strict((CANDIDATE / 'pre-review-qa/plan.json').read_bytes())
receipts = strict((CANDIDATE / 'pre-review-qa/receipts.json').read_bytes())
assert len(plans) == len(receipts) == 5
for cmd, result in zip(plans, receipts, strict=True):
    assert cmd == result['command'] and result['actual_exit'] == 0
_, counts, ids = xml_counts((CANDIDATE / 'pre-review-qa/docs.xml').read_bytes())
assert counts == {'tests':23, 'failures':0, 'errors':0, 'skipped':0}
record('pre-review-qa-verification.json', {'recorded_commands': len(plans),
    'all_recorded_exits_zero': True, 'docs_counts': counts, 'docs_test_identities': ids,
    'limits': 'No numerical tests, rejected historical scripts, or docs build executed by this record check.'})
print(json.dumps({'mapping': [457, 449, 8], 'capture_archive_members': [56,81],
                  'packaging_tests':23, 'mutants_killed':10, 'passed':True}))
