"""Independent bounded privacy scan. Never print/copy private bodies or values."""
import base64
import gzip
import io
import json
import re
import sys
import tarfile
import zipfile
from collections import Counter
from review_common import (CANDIDATE, EVIDENCE, PRIVATE, ROOT, desc, members,
                           private_identity, record, safe, sha, strict)

SENSITIVE = {'chatid','messageid','userid','phone','phonenumber','emailaddress',
             'email','username','firstname','lastname','recipientid','destinationid',
             'accesstoken','refreshtoken','bottoken','apikey','apitoken','password',
             'passwd','secret','authorization','cookie','privatekey'}
def norm(s):
    return re.sub('[^a-z0-9]', '', s.lower())

def fields(obj, trail=()):
    out = []
    if isinstance(obj, dict):
        for k,v in obj.items():
            if ((norm(k) in SENSITIVE or (norm(k) == 'id' and trail and norm(trail[-1]) in {'chat','user','recipient','from'}))
                    and isinstance(v, (str,int,float)) and not isinstance(v,bool) and v != ''):
                out.append((k, v))
            out.extend(fields(v, trail + (k,)))
    elif isinstance(obj, list):
        for v in obj:
            out.extend(fields(v, trail))
    elif isinstance(obj, str) and obj.strip().startswith(('{','[')):
        try:
            data = json.loads(obj)
        except (ValueError, UnicodeError):
            pass
        else:
            out.extend(fields(data, trail))
    return out

hold, private_body = private_identity()
private_files, _ = members(private_body)
omissions = hold['structured_json_identifier_scan'][PRIVATE.name]
known = set()
receipt_bodies = []
private_schemas = []
for item in omissions:
    b = private_files[item['path']]
    assert desc(b) == {'bytes':item['bytes'],'sha256':item['sha256']}
    data = strict(b)
    fs = fields(data)
    for k, value in fs:
        # Message identifiers can be short generic integers; check their parsed
        # field presence, not arbitrary substring occurrences in scientific data.
        if norm(k) != 'messageid':
            token = str(value).encode()
            if len(token) >= 6:
                known.update([token, base64.b64encode(token)])
    receipt_bodies.append(b)
    private_schemas.append({'path':item['path'], 'sensitive_field_names': sorted({k for k,_ in fs}),
                            'all_top_level_field_names': sorted(data), 'identity':desc(b)})
assert known
patterns = [re.compile(x) for x in [
    rb'gh[pousr]_[A-Za-z0-9]{20,}', rb'github_pat_[A-Za-z0-9_]{40,}',
    rb'sk-[A-Za-z0-9_-]{24,}', rb'[0-9]{8,12}:[A-Za-z0-9_-]{30,}',
    rb'AKIA[0-9A-Z]{16}', rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']]

class Scanner:
    def __init__(self):
        self.rows = []
        self.findings = []
        self.container_matches = []
        self.expanded_bytes = 0
        self.formats = Counter()
    def scan(self, label, b, depth=0):
        self.expanded_bytes += len(b)
        assert depth <= 20 and self.expanded_bytes < 1024**3
        assert len(b) <= 128 * 1024**2
        row = {'path':label, **desc(b)}
        self.rows.append(row)
        known_hit = any(t in b or t in label.encode() for t in known)
        full_receipt_hit = any(r in b for r in receipt_bodies)
        if b.startswith(b'\x1f\x8b'):
            row['kind'] = 'gzip'
            self.formats['gzip'] += 1
            if known_hit or full_receipt_hit:
                self.container_matches.append(label)
            with gzip.GzipFile(fileobj=io.BytesIO(b)) as z:
                unzipped = z.read(128 * 1024**2 + 1)
            assert len(unzipped) <= 128 * 1024**2
            self.scan(label + '::gzip', unzipped, depth+1)
            return
        if len(b) >= 512 and b[257:262] == b'ustar':
            row['kind'] = 'tar'
            self.formats['tar'] += 1
            if known_hit or full_receipt_hit:
                self.container_matches.append(label)
            files, _ = members(b)
            for name, value in files.items():
                self.scan(label + '::' + name, value, depth+1)
            return
        if b.startswith(b'PK\x03\x04'):
            row['kind'] = 'zip'
            self.formats['zip'] += 1
            with zipfile.ZipFile(io.BytesIO(b)) as z:
                names = set()
                for m in z.infolist():
                    safe(m.filename)
                    assert m.filename not in names and not m.is_dir()
                    names.add(m.filename)
                    assert m.file_size < 128 * 1024**2
                    self.scan(label + '::' + m.filename, z.read(m), depth+1)
            return
        row['kind'] = 'leaf'
        self.formats['leaf'] += 1
        reasons = []
        if known_hit:
            reasons.append('known-private-token-or-base64')
        if full_receipt_hit:
            reasons.append('exact-private-receipt-body')
        try:
            obj = json.loads(b)
        except (ValueError,UnicodeError):
            obj = None
        actual_fields = fields(obj)
        if actual_fields:
            reasons.append('sensitive-parsed-fields')
        if any(p.search(b) for p in patterns):
            reasons.append('credential-pattern')
        if reasons:
            self.findings.append({'path':label,'reasons':reasons,
                                   'field_names':sorted({k for k,_ in actual_fields}), **desc(b)})

original_scan = Scanner()
original_scan.scan('PRIVATE_ORIGINAL', private_body)
expected_private = {'PRIVATE_ORIGINAL::gzip::'+r['path'] for r in omissions}
assert {r['path'] for r in original_scan.findings} == expected_private
assert len(original_scan.findings) == 8
# Never persist private scan bodies: only paths, field names, counts and digests.
record('private-positive-control.json', {'private_identity':desc(private_body),
    'schema_metadata':private_schemas, 'findings':original_scan.findings,
    'exact_hold_paths':True,'positive_control_members':8,'values_disclosed':False})
del private_files, private_body

public_manifest = strict((CANDIDATE / 'privacy-scan-inputs.json').read_bytes())
assert len(public_manifest['files']) == 95
closure = dict(public_manifest['files'])
for p in CANDIDATE.rglob('*'):
    if p.is_file():
        assert not p.is_symlink()
        name = str(p.relative_to(ROOT))
        d = desc(p.read_bytes())
        if name in closure:
            assert closure[name] == d
        closure[name] = d
scan = Scanner()
for name, expected in sorted(closure.items()):
    safe(name)
    b = (ROOT / name).read_bytes()
    assert desc(b) == expected
    scan.scan(name,b)
report = {'input_files':closure, 'original_scan_manifest_files':95,
    'public_input_file_count':len(closure),
    'additional_candidate_paths':sorted(set(closure)-set(public_manifest['files'])),
    'visited_bodies':len(scan.rows),'expanded_bytes':scan.expanded_bytes,
    'formats':dict(scan.formats),'public_findings':scan.findings,
    'container_token_matches':scan.container_matches,
    'positive_control_members':8,'values_disclosed':False,
    'limits':'Explicit public closure plus every candidate file; gzip/tar/zip recursion; parsed field-name and observed non-message token/base64 matching plus selected credential patterns. Not universal secret detection; short message IDs are checked through field presence, not ambiguous numeric substring matches.'}
record('independent-privacy-scan.json',report)
record('independent-privacy-body-index.json',{'bodies':scan.rows,'count':len(scan.rows)})
print(json.dumps({'public_input_files':len(closure),'visited_bodies':len(scan.rows),
                  'public_findings':len(scan.findings),'container_token_matches':len(scan.container_matches),
                  'positive_control_members':8}))
assert not scan.findings and not scan.container_matches
