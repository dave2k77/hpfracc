"""Finish bounded review records; exhaustive explicit proof allowlist, no broad copy."""
import json
from review_common import (CANDIDATE, EVIDENCE, PRIVATE, REVIEW_PIN, ROOT,
    desc, guarded_files, private_identity, record, run_capture, strict)

inputs_after = guarded_files()
assert inputs_after == strict((EVIDENCE / 'initial-protected-check.json').read_bytes())
record('final-protected-check.json', inputs_after)
hold, b = private_identity()
record('final-private-identity.json', {'identity':desc(b),'file_mode':'0600','parent_mode':'0700',
        'old_repository_path_absent':True,'unchanged':True})
del b

packaging = strict((EVIDENCE / 'packaging-v2/result.json').read_bytes())
captured = strict((EVIDENCE / 'captured-runs-verification.json').read_bytes())
ids = packaging['test_identities']
assert ids == captured['archives'][0]['runs']['reviewed-controls']['test_identities']
assert all(r['test_identities'] == ids for r in captured['archives'][1]['runs'].values())
privacy = strict((EVIDENCE / 'independent-privacy-scan.json').read_bytes())
controls = strict((EVIDENCE / 'independent-controls.json').read_bytes())
assert not privacy['public_findings'] and not privacy['container_token_matches']
assert controls['control_count'] == 16 and controls['all_rejected_by_expected_guard']
assert packaging['actual_exit'] == 0
assert packaging['counts'] == {'tests':23,'failures':0,'errors':0,'skipped':0}
assert captured['mutation_guards_killed'] == 10
for phase in ['integrity-run-v3','privacy-run','controls-run','portable']:
    assert strict((EVIDENCE / phase / 'exit.json').read_bytes())['actual_exit'] == 0

portable = EVIDENCE / 'portable'
result = run_capture('scoped-ruff', ['uv','run','--project',str(portable),'--frozen','--no-sync',
    str(ROOT / '.venv/bin/ruff'),'check','--no-cache','--config',str(portable / 'pyproject.toml'),
    str(EVIDENCE / 'packaging-v2/before/sanitize_evidence.py'),
    str(EVIDENCE / 'packaging-v2/before/test_sanitize_evidence.py')],portable)
assert result.returncode == 0
result = run_capture('whitespace', ['git','diff','--check'], ROOT)
assert result.returncode == 0
result = run_capture('cpu-interpreter', ['uv','run','--project',str(portable),'--frozen','--no-sync',
    str(ROOT / '.venv/bin/python'),'-B','-c',
    'import json,sys; print(json.dumps({"executable":sys.executable,"version":sys.version,"prefix":sys.prefix}))'], portable)
assert result.returncode == 0
assert json.loads(result.stdout)['prefix'] == str(ROOT / '.venv')

record('source-review.json', {
    'scope':'STEP 1 fixed-task packaging/privacy only; not implementation or numerical/scientific approval',
    'helper':desc((CANDIDATE / 'sanitize_evidence.py').read_bytes()),
    'tests':desc((CANDIDATE / 'test_sanitize_evidence.py').read_bytes()),
    'reviewed_properties':[
        'No archive filesystem extraction, shell execution, dynamic execution of archive bodies, or network behavior in the packaging helper.',
        'Pinned input/omission descriptors; regular safe unique members; output no-overwrite; existing symlink path refusal; exact bundle file allowlist.',
        'External inventory pin required. Synthetic re-pinning controls separately reach member, partition, canonical count, JSON duplicate-key, and historical-boundary predicates.',
        'Original mapping independently reconstructed from private original; every retained body unchanged and every omission exactly matches hold.',
        'Independent canonical reconstruction exactly equals actual derivative, including deterministic gzip and normalized tar headers.',
        'Historical manifests/verdicts are retained unchanged; current README explicitly disclaims replay completeness and supersedes the old private-receipts-excluded assertion.',
        'Archived test/mutation indices are exhaustive, XML counts and identities match receipts; mutations reconstruct exactly from recorded substitutions; only declared helper/test/config snapshots are captured.',
        'All currently reviewed candidate files and explicit public evidence closure recursively scanned; eight private positive-control members match exact hold, no extra sensitive parsed fields detected.'
    ],
    'security_concerns':[], 'logic_errors':[],
    'tdd_distinction':{'red_01':'module absence only','red_02':'behavioral extra-file acceptance',
                       'later_controls':'mutation evidence, not claimed test-first'},
    'historical_process_record_limit':'Consistency and byte identity checked; no independent attestation of historical OS process execution.',
    'harness_attempts':[
        {'record':'integrity-run/exit.json','issue':'Reviewer initially assumed test and mutant plans used the same descriptor schema; mutant plans instead use SHA-only pins. Snapshot and failure preserved.'},
        {'record':'integrity-run-v2/exit.json','issue':'Reviewer initially expected a skipped counter in mutant receipts; XML independently shows zero, while receipts omit that counter. Snapshot and failure preserved.'},
        {'record':'packaging/exit.json','issue':'Reviewer omitted creation of the basetemp parent; all 23 tests had setup errors. Raw XML/outputs preserved; same copied candidate tests pass after creating the scratch parent.'}
    ],
    'candidate_repaired_or_modified':False
})

limitations = [
    'STEP 1 packaging/privacy review only; no numerical, fixed-checker, resource-limit, broader A2 accounting, scientific, protocol-freeze, commit/push or release approval.',
    'Privacy coverage is the explicit 100-file public closure and recursive archive bodies with bounded parsed fields, observed token/base64 and selected credential patterns; it is not universal secret detection or clearance for later changed files.',
    'Historical manifests and failed verdicts remain unchanged and may reference omitted receipts; the derivative intentionally lacks complete historical replay closure.',
    'Portable verification relies on an externally trusted inventory hash and owner-controlled nonconcurrent paths, not hostile concurrent-filesystem safety or authentication after replacing both inventory and trust pin.',
    'Archived test-run records were checked for byte, source, XML, count and exit consistency, not independently attested historical OS/process execution. New copied packaging, CLI and tamper checks were actually executed.',
    'Reviewer harness setup/schema errors are preserved separately from successful reruns; no candidate source or evidence was repaired.'
]
verdict = {'passed':True,'security_concerns':[],'logic_errors':[],'limitations':limitations,
    'reviewed_manifest_sha256':REVIEW_PIN,
    'evidence_directory':str(EVIDENCE),'verdict_path':str(EVIDENCE / 'verdict.json'),
    'evidence_index_path':str(EVIDENCE / 'evidence-index.json'),
    'verified':{'protected_candidate_files':36,'protected_baseline_files':189,
        'private_original_members':457,'retained_unchanged_members':449,'exact_omissions':8,
        'packaging_tests_passed':23,'archived_mutants_killed':10,'new_cli_tamper_rejections':16,
        'public_input_files':privacy['public_input_file_count'],'public_recursive_bodies':privacy['visited_bodies'],
        'public_privacy_findings':0,'private_positive_control_members':8,
        'portable_actual_bundle_cli_exit':0,'source_and_stage_unchanged':True},
    'allowed_post_review_parent_delta':strict((CANDIDATE / 'review-inputs.json').read_bytes())['allowed_post_review_delta'],
    'post_review_constraints':'Publication/progress wording only in named paths; separately indexed review/final-QA records. No protected source/evidence changes.'}
record('verdict.json',verdict)

# Only named outputs of this review are eligible for publication. Never copy or
# index unrelated scratch JSON or walk the runtime fixture subtree into proof.
files = [
    'review_common.py','check_integrity.py','execute_checks.py','check_privacy.py','check_controls.py',
    'finish_review.py','verify_proof.py','seal_index.py',
    'initial-protected-check.json','final-protected-check.json','final-private-identity.json',
    'reviewed/review-inputs.json','reviewed/baseline-inputs.json','reviewed/authorization.json',
    'original-derivative-mapping.json','original-derivative-mapping-v2.json','original-derivative-mapping-v3.json',
    'captured-runs-verification.json','captured-mutant-diffs.patch','pre-review-qa-verification.json',
    'private-positive-control.json','independent-privacy-scan.json','independent-privacy-body-index.json',
    'independent-controls.json','source-review.json','verdict.json',
    'harness-attempt-01/check_integrity.py','harness-attempt-01/execute_checks.py',
    'harness-attempt-02/check_integrity.py','harness-attempt-02/execute_checks.py',
]
for phase in ['integrity-run','integrity-run-v2','integrity-run-v3','privacy-run','controls-run',
              'packaging','packaging-v2','portable','scoped-ruff','whitespace','cpu-interpreter',
              'finish-run','proof-run']:
    files.extend(phase + '/' + n for n in ['plan.json','stdout.raw','stderr.raw','exit.json'])
for phase in ['packaging','packaging-v2']:
    files.extend(phase + '/before/' + n for n in ['sanitize_evidence.py','test_sanitize_evidence.py','pyproject.toml','uv.lock'])
    files.extend(phase + '/' + n for n in ['raw.xml','result.json'])
files.extend('portable/' + n for n in ['sanitize_evidence.py','pyproject.toml','uv.lock'])
files.extend('portable/bundle/' + n for n in ['inventory.json','single-trace-independent-review-failed-evidence.sanitized.tar.gz'])
files.extend(controls['explicit_proof_files'])
assert len(files) == len(set(files))
record('proof-allowlist.json', {'files':sorted(files),
    'add_at_finalization':['proof-allowlist.json','proof-verification.json','evidence-index.json'],
    'excluded_subtrees':{'runtime/':'Synthetic pytest runtime fixtures only; not publication evidence.'},
    'self_exclusion':'The final evidence-index.json excludes itself explicitly.'})
print(json.dumps({'passed':True,'proof_allowlist_files':len(files),'verdict_path':str(EVIDENCE/'verdict.json')}))
