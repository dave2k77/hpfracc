"""Run only the copied packaging helper/tests, no historical numerical scripts."""
import json
import sys
import xml.etree.ElementTree as ET
from review_common import (CANDIDATE, EVIDENCE, INVENTORY_PIN, ROOT,
                           desc, put, record, run_capture)

phase = sys.argv[1]
if phase == 'integrity':
    result = run_capture('integrity-run-v3', [sys.executable, '-B', str(EVIDENCE / 'check_integrity.py')], EVIDENCE)
    print(json.dumps({'phase': phase, 'actual_exit': result.returncode}))
    raise SystemExit(result.returncode)
if phase == 'packaging':
    before = EVIDENCE / 'packaging-v2/before'
    paths = [(CANDIDATE / n, n) for n in ['sanitize_evidence.py','test_sanitize_evidence.py']]
    paths += [(ROOT / n, n) for n in ['pyproject.toml','uv.lock']]
    pins = {}
    for source, name in paths:
        data = source.read_bytes()
        put('packaging-v2/before/' + name, data)
        pins[name] = desc(data)
    command = ['uv','run','--project',str(before),'--frozen','--no-sync',str(ROOT / '.venv/bin/python'),
               '-B','-m','pytest','-c',str(before / 'pyproject.toml'),
               str(before / 'test_sanitize_evidence.py'), '-q','-p','no:cacheprovider',
               '--basetemp=' + str(EVIDENCE / 'runtime/pytest'),
               '--junitxml=' + str(EVIDENCE / 'packaging-v2/raw.xml')]
    result = run_capture('packaging-v2', command, before, pins)
    assert all(desc((before / name).read_bytes()) == pin for name,pin in pins.items())
    root = ET.parse(EVIDENCE / 'packaging-v2/raw.xml').getroot()
    cases = root.findall('.//testcase')
    counts = {'tests':len(cases),'failures':len(root.findall('.//failure')),
              'errors':len(root.findall('.//error')),'skipped':len(root.findall('.//skipped'))}
    record('packaging-v2/result.json', {'actual_exit':result.returncode, 'counts':counts,
            'inputs_unchanged':True,'test_identities':[(c.get('classname'),c.get('name')) for c in cases]})
    assert result.returncode == 0 and counts == {'tests':23,'failures':0,'errors':0,'skipped':0}
    # Only this explicit public bundle and helper/config closure are copied.
    for name in ['inventory.json','single-trace-independent-review-failed-evidence.sanitized.tar.gz']:
        put('portable/bundle/' + name, (CANDIDATE / 'sanitized-bundle' / name).read_bytes())
    for name in ['sanitize_evidence.py','pyproject.toml','uv.lock']:
        put('portable/' + name, (before / name).read_bytes())
    portable = EVIDENCE / 'portable'
    command = ['uv','run','--project',str(portable),'--frozen','--no-sync',str(ROOT / '.venv/bin/python'),
               '-B',str(portable / 'sanitize_evidence.py'),'verify','--bundle',str(portable / 'bundle'),
               '--inventory-sha256',INVENTORY_PIN]
    result = run_capture('portable', command, portable)
    assert result.returncode == 0
    assert json.loads(result.stdout) == {'verified':True,'retained_members':449,'omitted_members':8}
    print(json.dumps({'phase':phase,'packaging_tests':counts,'portable_actual_exit':result.returncode}))
