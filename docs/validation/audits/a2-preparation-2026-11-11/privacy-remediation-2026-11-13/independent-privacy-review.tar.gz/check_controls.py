"""Independent actual-bundle CLI tamper probes; no original receipt body is used."""
import copy
import gzip
import io
import json
import tarfile
from review_common import (EVIDENCE, INVENTORY_PIN, ROOT, desc, members, put,
                           record, run_capture, sha, strict)

portable = EVIDENCE / 'portable'
archive_name = 'single-trace-independent-review-failed-evidence.sanitized.tar.gz'
archive = (portable / 'bundle' / archive_name).read_bytes()
raw_inventory = (portable / 'bundle/inventory.json').read_bytes()
base = strict(raw_inventory)
actual, _ = members(archive)
rows = list(sorted(actual.items()))
assert len(rows) == 449

def independent_pack(rows, special=None):
    stream = io.BytesIO()
    with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.USTAR_FORMAT) as t:
            for name,b in rows:
                m = tarfile.TarInfo(name)
                m.size = len(b)
                m.mode = 0o644
                t.addfile(m, io.BytesIO(b))
            if special:
                m = tarfile.TarInfo(special[0])
                m.type = special[1]
                m.linkname = 'not-followed'
                t.addfile(m)
    return stream.getvalue()
assert independent_pack(rows) == archive

controls = [
    ('missing-retained','retained member mismatch'),
    ('changed-retained','retained member mismatch'),
    ('extra-member','retained member mismatch'),
    ('reintroduced-omitted-path-synthetic','retained member mismatch'),
    ('resigned-retained-descriptor','original-to-derivative partition mismatch'),
    ('missing-omission','original-to-derivative partition mismatch'),
    ('count-float-lookalike','original-to-derivative partition mismatch'),
    ('duplicate-partition-path','original-to-derivative partition mismatch'),
    ('unsafe-traversal','unsafe archive member name'),
    ('duplicate-tar-member','nonregular or duplicate archive member'),
    ('symlink-tar-member','nonregular or duplicate archive member'),
    ('duplicate-json-key','duplicate JSON key'),
    ('historical-authority-claim','historical boundary mismatch'),
    ('extra-bundle-file','bundle file allowlist mismatch'),
    ('changed-inventory-original-trust-pin','inventory identity mismatch'),
    ('archive-checksum-only','derivative archive identity mismatch'),
]
proofs = []
explicit_files = []
for name, expected in controls:
    inv = copy.deepcopy(base)
    changed_rows = list(rows)
    out = archive
    special = None
    body_change = False
    if name == 'missing-retained':
        changed_rows.pop()
        body_change = True
    elif name in ('changed-retained','resigned-retained-descriptor'):
        changed_rows[0] = (changed_rows[0][0], changed_rows[0][1] + b'\nSYNTHETIC REVIEW TAMPER\n')
        body_change = True
        if name == 'resigned-retained-descriptor':
            inv['retained'][0] = {'path':changed_rows[0][0], **desc(changed_rows[0][1])}
    elif name == 'extra-member':
        changed_rows.append(('SYNTHETIC-UNEXPECTED.txt', b'SYNTHETIC TAMPER'))
        body_change = True
    elif name == 'reintroduced-omitted-path-synthetic':
        changed_rows.append((inv['omitted'][0]['path'], b'SYNTHETIC, NOT A PRIVATE RECEIPT'))
        body_change = True
    elif name == 'missing-omission':
        inv['omitted'].pop()
    elif name == 'count-float-lookalike':
        inv['original_member_count'] = float(inv['original_member_count'])
    elif name == 'duplicate-partition-path':
        inv['omitted'].append(copy.deepcopy(inv['retained'][0]))
    elif name == 'unsafe-traversal':
        changed_rows.append(('../SYNTHETIC-ESCAPE',b'SYNTHETIC'))
        body_change = True
    elif name == 'duplicate-tar-member':
        changed_rows.append(rows[0])
        body_change = True
    elif name == 'symlink-tar-member':
        special = ('SYNTHETIC-LINK',tarfile.SYMTYPE)
        body_change = True
    elif name == 'historical-authority-claim':
        inv['historical_manifests_are_authoritative_for_derivative'] = True
    elif name == 'changed-inventory-original-trust-pin':
        inv['status'] += ' SYNTHETIC ALTERATION'
    elif name == 'archive-checksum-only':
        out = archive + b'\0'
    if body_change:
        out = independent_pack(changed_rows,special)
        assert out != archive
        inv['derivative_sha256'] = sha(out)
        inv['derivative_bytes'] = len(out)
    raw = (json.dumps(inv,indent=2) + '\n').encode()
    if name == 'duplicate-json-key':
        raw = raw.replace(b'{',b'{"schema":"DUPLICATE-SYNTHETIC",',1)
        assert raw.count(b'"schema":') == 2
    bundle_rel = 'controls/' + name + '/bundle'
    put(bundle_rel + '/' + archive_name,out)
    put(bundle_rel + '/inventory.json',raw)
    explicit_files.extend([bundle_rel + '/' + archive_name,bundle_rel + '/inventory.json'])
    if name == 'extra-bundle-file':
        put(bundle_rel + '/SYNTHETIC-EXTRA.txt',b'SYNTHETIC')
        explicit_files.append(bundle_rel + '/SYNTHETIC-EXTRA.txt')
    pin = INVENTORY_PIN if name == 'changed-inventory-original-trust-pin' else sha(raw)
    cmd = ['uv','run','--project',str(portable),'--frozen','--no-sync',str(ROOT / '.venv/bin/python'),
           '-B',str(portable / 'sanitize_evidence.py'),'verify','--bundle',str(EVIDENCE / bundle_rel),
           '--inventory-sha256',pin]
    label = 'controls/' + name
    input_pins = {'archive':desc(out),'inventory':desc(raw),'supplied_inventory_pin':pin,
                  'expected_guard':expected,'archive_outer_hash_recomputed':body_change}
    result = run_capture(label,cmd,portable,input_pins)
    explicit_files.extend([label + '/' + x for x in ['plan.json','stdout.raw','stderr.raw','exit.json']])
    passed = result.returncode != 0 and expected.encode() in result.stderr
    proofs.append({'control':name,'expected_guard':expected,'actual_exit':result.returncode,
                   'expected_guard_observed':passed,'archive_outer_hash_recomputed':body_change})
record('independent-controls.json', {'controls':proofs,'control_count':len(proofs),
    'all_rejected_by_expected_guard':all(r['expected_guard_observed'] for r in proofs),
    'explicit_proof_files':explicit_files,
    'trust_boundary':'Recomputed inventory pins are synthetic semantic probes, not authentication. Original trust pin is retained in the separate inventory-integrity control.',
    'omitted_member_probe':'Synthetic replacement bytes at an omitted path; no private receipt body was read or copied by this script.'})
print(json.dumps({'controls':len(proofs),'expected_rejections':sum(r['expected_guard_observed'] for r in proofs)}))
assert all(r['expected_guard_observed'] for r in proofs)
