# FINAL independent A2 preparation review

## Decision

**Not freeze-ready.** The repaired schema/status/provenance/security interlocks are internally coherent on the inspected packet and bounded independent witnesses. The mandatory positive FIT-REAL programme is not runnable under the current whole-index transaction representation/reservation. Correctly encoded `reservation_exceeded/indeterminate` is a safe refusal, **not fulfillment of a required positive gate**.

`contract_consistency_passed=true` denotes consistency of the closed record/control/interlock specification, including truthful refusal. It does not denote satisfiability of every required positive outcome under the current resource architecture. `passed=false` and `freeze_ready=false` are the overall preparation decision. Owner freeze, implementation authority, A2/scientific acceptance, memory/AD/GPU validation remain absent.

## Reviewed identity and write boundary

- Repository: `/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc`.
- HEAD: `a3951bde6a633f22ee2c1e006ea78c62421f599b`.
- Protocol SHA-256: `f1a62214e8636f4e8f4862c0824f40e0fe546e5430eee9f8ce6740ae3e5cca03`.
- Review manifest: `/home/davianc/.hermes/cache/scratch/a2-final-review-cycle2/review-input-manifest.json`, SHA-256 `55c9d3b42cd7507c8533125d5bae4974b4981a3c271328e72896a72105e822b4`.
- Actual nine-file packet inspected: the protocol Markdown, six original support/manifest files and two schema-control files. All 19 frozen repository files, 125 numerical inputs, complete Git-index bytes, newline-delimited stage-entry digest, and HEAD are protected. Initial successful check is `initial-pincheck-corrected-recipe.json`; final check is separately recorded after this verdict.
- Only new files under this review's scratch directory were written. No repository/index/profile/skill modification, implementation, product tests, JAX import/fitting/application/AD, numerical benchmark, full/GPU job, commit or push was performed.

## Explicit prior-blocker disposition

| Prior blocker | FINAL disposition and independently checked basis |
| --- | --- |
| DECISION-01 | Resolved at specification level. Request invalidity/unsupported domain, authenticated local ineligibility and unavailable provenance are distinct. Combined local L1 incompatibility + missing producer remains unknown with both reasons. |
| DECISION-02 | Resolved. ID-free ordered configuration/producer/raw-descriptor tuple is explicit; volatile invocation/receipt identities remain separate. Original identity controls and raw byte identities preserved; no signed-zero, pole-order or mathematical-equivalence normalization. |
| DECISION-03 | Resolved. Unknown higher/lower rank mandates indeterminate by exhaustive policy, not a false impossibility theorem about minimum inference. |
| B1 | Resolved as an input/gate definition. All 560 cases, nonzero real-fit signals, supplied (8,2,4) order, tau budgets and preserve-and-stop gates are closed. **Resource blocker below still prevents fulfilling eight positive obligations.** |
| B2 | Resolved as an empirical comparison contract. All 20 policy records/FD bytes unchanged; shape-safe observed/reference direction, exact input-gradient target, fixed q/fit, order refitting, dynamic order and differentiated dt scaling remain explicit. No measured comparison pass is inferred. |
| B3 | Resolved as a closed specification. Strict bool/int/float/enum/JSON/rational/raw-array predicates, typed roots and separate canonical invocation binding are defined. Root acceptance alone is not the required semantic replay. |
| B4 | Accounting/unknown/partial/timeout specification resolved. Shared/cross-check/analytic arithmetic, transient/GCD limitations, live+cumulative bytes and complete unfinished check retention are explicit. **Readiness remains blocked by the independently demonstrated fixed reservation inadequacy.** |
| MATH-REREVIEW-01 | Resolved. Candidate-free full observation/configuration/producer variants have null candidate ID/index; all 64 future full-output/exact-D bindings rechecked. The complete hypothetical full variant uses the actual pinned fractional.py API, not fitter attribution. |
| MATH-REREVIEW-02 | Resolved. One typed disposition table permits true known-ineligible reasons; primary/all-reason agreement and null-vs-one-payload rules checked. |
| MATH-REREVIEW-03 | Resolved. Transport dimensions through 1024 preserve unsupported [18]/[18,18] metadata without changing N<=17 numerical support. |
| V-S01 | Resolved as a future security invariant, not enforcement evidence. Fresh euid-owned 0700 root/subdirectories, handle-relative no-follow/exclusive creation/readback, regular/single-link/inode/device/containment checks, no adoption or foreign cleanup, immutable no-overwrite arrays versus owned atomic index replacement, and charged partial/temporary/coexisting writes are explicit. |
| V-B3-01 | Resolved together with MATH-REREVIEW-01; full history has a truthful disjoint producer/configuration, no invented poles/fitting iterations/t_max or candidate. |
| V-B4-02 | Resolved together with MATH-REREVIEW-03; initialized/final unsupported indices retain all true expected shapes. |
| V-B1-03 | Resolved. Reference mutations run before dereference; expanded/evidence replacements require existing targets. Occurrences are independently cloned. Four empty-list controls retain only four shared slots; duplicate invalid occurrences keep indices and duplicate IDs without coercion. |
| V-B4-04 | Resolved. Typed launch, process, phase and later export records represent preflight/watchdog/grace/kill-to-confirmed-exit and index-write timing. Held zero-watchdog barrier, unavailable timings, confirmed-exit linkage and no recursive write measurement are explicit. Synchronized process-copy tampering is rejected by timing/barrier semantics. |
| V-B3-05 | Resolved. Standalone record_type=slot is a root variant; every emitted JSON artifact has a closed route. Raw logs/owned staging are explicit bounded non-JSON exceptions, not hidden artifacts. |
| V-B3-06 | Resolved. Exact canonical producer-binding UTF-8/SHA recipe and separate invocation/receipt/input/source/case/mode/branch/actual-payload relationships form an acyclic DAG. Fifteen non-no-op semantic mutants with refreshed outer digests are rejected; this demonstrates consistency predicates, not execution authentication. |

No retained exploit claim or new blocking interlock contradiction was established. No prior finding is relabeled as an implementation or numerical success.

## Independent executable evidence

`attempt2/process.json` records exit **0** for the scratch-only independent stdlib audit. Its result includes:

- 560 cases / 840 raw descriptors / 160 candidate specs; 24,336 slots / 1,312 comparisons / 1,056 fit checks / 64 full bindings; maximum 954 slots/case.
- All 544 prior case IDs, requests/budgets/stop gates, all 832 prior raw descriptors and all prior parser/identity/shortcut controls preserved. Twelve future actual-fit specs still have no observed rhos/coefficients.
- 17 linked hypothetical bundles, 38 additional status witnesses and every one of the 17 root variants; full typed status/termination coverage. Initial/final inventories include every unfinished comparison and binding check.
- Eight new (1,1)/(3,1) exact rank-preserving controls independently checked, including exact fixed-fit quadratic directional FD/gradient equalities; eight combined precedence controls checked.
- Unchanged 1,699-byte finite-math section, SHA-256 `c6b59cae6d948222fdb9c5c0a6287491426864964207f45b747501b1970e1f9e`; exact policy/FD/domain/cap preservation. Prior giant Fraction schedules were not rerun.
- `_SOEFit`, `_fit_soe`, `_apply_soe`, full-history GL and RL delegation inspected without imports. The 400 projected updates, exact head/increments, grid and absent alpha/dt/t_max dataclass fields agree with declarations. The private future fit->apply->scale composition is not falsely presented as an already instrumented public wrapper. Full-history dt is fixed; the existing public `_validate_dt` uses float(dt), so future JIT integration must keep that fixed scalar concrete/captured rather than assume dynamic-dt support. The contract requires dynamic alpha, not dynamic dt.

`supplemental-run3/process.json` records exit **0**. It independently rejects all 12 packet semantic recipes plus three extra producer-mode/full-alias/full-entrypoint swaps, after refreshing outer artifact/index/export/manifest digests and redundant receipt copies. Fourteen additional bool/float/rational negatives are rejected. The 64 future full bindings are rechecked by alias/dtype/configuration/case/nullable identity. The 66-, 74-, 124- and 82-member historical/preservation sets have verified member hashes/sizes; no archive links are followed or recreated.

These checks exercise static/hypothetical encodings and finite exact controls only. They are not actual subprocess/worker/fitter observations, portable operational replay, security enforcement or scientific acceptance.

## R-FINAL-RESOURCE-01 — mandatory positive cases cannot launch

Independently reconstructed all 560 input/index templates and exactly reproduced:

- Maximum input capture: **183,673 bytes**, below 262,144.
- Maximum single all-complete-descriptor index: **446,741 bytes**, below 524,288.
- Maximum initial+new-index+8,192-byte receipt allowance: **792,318 bytes**, above the whole-transaction reservation of 524,288.
- Maximum all-complete metadata nodes: **36,687** counting object keys, depth **7**.
- The refused obligations are ramp/step/alternating/stacked, float32, tau=1, each GL and RL: exactly eight cases, all listed in executable proof.

### Conservative assumptions versus unavoidable requirements

The all-complete template is **not a realizable success state**: it completes mutually exclusive nonselected AD/FD branches and quantities whose correct disposition is not_applicable. The 36,687 node result is therefore a conservative upper-template prediction, **not an unavoidable node lower bound**. Selected-only illustrative models shrink the index/node counts; their unused-quantity/process assumptions do not constitute measured or minimal valid runtime exports. No node-cap/hardware/numerical infeasibility theorem follows.

However, this does **not** remove the byte blocker. The current closed failure index requires the full fixed inventory, all comparison/binding rows and candidate occurrences in both the initialized and replacement generation. Atomic replacement explicitly charges old/new coexistence; cumulative accounting charges both writes. Independent deliberately *under-counted* index skeletons retain every mandatory fixed key/ID/row but erase the process interior, choose shorter reasons/statuses and empty completed shapes, and omit receipts. These are expressly labeled **NOT valid output records**, only serialization lower bounds. Even **two such smaller-than-valid skeletons require 614,748–617,184 bytes** across the eight cases, already above 524,288. This proof is independent of which candidate wins, actual array values, timing, 8,192 allowance, or whether unused/nonselected branches complete.

Thus the present duplicated-full-inventory, whole-index-transaction policy genuinely cannot admit those required positive obligations under its unchanged reservation. That is a **schema/serialization/resource-design admission failure**, not measured fit failure, numerical unattainability, hardware or peak-memory infeasibility. Safe bounded indeterminate export is coherent but cannot be counted as the positive gate.

## Owner decision required; no further automatic repair

Both automatic correction cycles are exhausted. Parent must pause and obtain an explicit owner decision. Alternatives, none authorized or applied here:

1. Keep the current draft unfrozen and stop. This preserves all scientific/resource criteria and acknowledges the blocked positive programme.
2. Authorize a separately scoped specification redesign retaining every case/check/cap: e.g. an immutable full inventory plus smaller referential progress/descriptor generations. This could avoid duplicating all rows, but changes closed schemas/routing/replay and needs new independent review; merely marking unused slots correctly cannot defeat the byte lower bound.
3. Explicitly authorize a resource-cap revision, with minimally valid selected/unselected and worst-case process/receipt/node accounting. More allowance costs storage/control headroom and still proves neither numerical attainability nor memory/runtime feasibility. The current 792,318 number is not a universal runtime bound to adopt blindly.
4. Explicitly accept a failure-only diagnostic preparation stage while keeping positive FIT-REAL/A2 gates open. This changes the immediate deliverable and is not completion of the present positive programme or permission to implement.

No cap relaxation, omitted check, case substitution, favorable signal, retuned FD/tolerance, unauthorized third repair, or implementation is permissible under the present instructions.

## Harness-only issues preserved

The initial pin probe used NUL-delimited stage entries while the frozen manifest uses newline-delimited `git ls-files --stage`; all file/HEAD/index-byte identities already matched, and the corrected recipe passes. The first audit incorrectly applied a success-record integer-token parser to the fixture container's intentional negative 3.0 mutation; its exit-1 raw receipt is preserved, then a distinct new audit version handles fixture containers separately. The first supplemental run lacked its own root-sample bookkeeping dictionary; its exit-1 receipt is preserved. Corrected scratch-only runs pass. These were review harness mistakes, not packet defects, and no repository repair was made.
