"""Index this review's new scratch proofs and verify exact readback."""
import hashlib
import json
from pathlib import Path
import stat

O=Path('/home/davianc/.hermes/cache/scratch/a2-independent-final-complete-l_bwads9')
excluded={'evidence-index.json','evidence-index-verification.json'}
h=lambda b:hashlib.sha256(b).hexdigest()
files={}
for p in sorted(O.rglob('*')):
    info=p.lstat()
    assert not stat.S_ISLNK(info.st_mode), p
    if not stat.S_ISREG(info.st_mode):continue
    rel=p.relative_to(O).as_posix()
    if rel in excluded:continue
    data=p.read_bytes()
    files[rel]={'absolute_path':str(p),'bytes':len(data),'sha256':h(data)}
index=dict(label='Independent readonly FINAL A2 review evidence; STATIC/HYPOTHETICAL, not numerical execution',root=str(O),files=files,file_count=len(files),excluded_self_referential_or_later_receipts=sorted(excluded),review_manifest_sha256='55c9d3b42cd7507c8533125d5bae4974b4981a3c271328e72896a72105e822b4',reviewed_protocol_sha256='f1a62214e8636f4e8f4862c0824f40e0fe546e5430eee9f8ce6740ae3e5cca03')
p=O/'evidence-index.json'
assert not p.exists()
p.write_text(json.dumps(index,indent=2)+'\n')
# Read exact written index; verify each declared target without following links.
loaded=json.loads(p.read_text())
assert len(loaded['files'])==loaded['file_count']
for rel,meta in loaded['files'].items():
    target=O/rel
    assert target.is_file() and not target.is_symlink()
    data=target.read_bytes()
    assert len(data)==meta['bytes'] and h(data)==meta['sha256']
for folder in ['attempt2','supplemental-run3','final-pincheck-run']:
    receipt=json.loads((O/folder/'process.json').read_text())
    assert receipt['exit_code']==0
    script=Path(receipt['command'][-1])
    assert h(script.read_bytes())==receipt['script_sha256']
    assert h((O/folder/'stdout.raw').read_bytes())==receipt['stdout_sha256']
    assert h((O/folder/'stderr.raw').read_bytes())==receipt['stderr_sha256']
verdict=json.loads((O/'verdict.json').read_text())
assert verdict['passed'] is False and verdict['freeze_ready'] is False
assert json.loads((O/'final-pin-check.json').read_text())['passed'] is True
for handle in verdict['evidence_paths']:
    if Path(handle).name not in excluded:assert Path(handle).is_file(),handle
verification=dict(passed=True,verified_files=len(files),indexed_bytes=sum(v['bytes'] for v in files.values()),index_sha256=h(p.read_bytes()),index_bytes=p.stat().st_size,successful_command_receipts_verified=['attempt2/process.json','supplemental-run3/process.json','final-pincheck-run/process.json'],final_protected_pin_check_passed=True,verdict_passed=False,freeze_ready=False,self_exclusions=sorted(excluded),limitations='The index and this later verification receipt are explicitly excluded from their own file set; their bytes are bound by this tool execution, not a claimed self-hash. No repository input was written.')
vp=O/'evidence-index-verification.json'
assert not vp.exists()
vp.write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps(verification,indent=2))
