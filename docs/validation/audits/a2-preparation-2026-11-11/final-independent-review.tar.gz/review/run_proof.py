"""Execute a new scratch-only audit copy with raw command/exit receipts."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
BASE=Path(__file__).parent
source=BASE/sys.argv[1]
out=BASE/sys.argv[2]
out.mkdir(exist_ok=False)
script=out/source.name
shutil.copyfile(source,script)
cmd=['uv','run','--frozen','python',str(script)]
t=time.monotonic_ns()
p=subprocess.run(cmd,cwd='/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc',env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True)
(out/'stdout.raw').write_bytes(p.stdout)
(out/'stderr.raw').write_bytes(p.stderr)
h=lambda b:hashlib.sha256(b).hexdigest()
rec=dict(command=cmd,cwd='/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc',exit_code=p.returncode,elapsed_monotonic_ns=time.monotonic_ns()-t,script_sha256=h(script.read_bytes()),stdout_sha256=h(p.stdout),stderr_sha256=h(p.stderr))
(out/'process.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec))
print(p.stdout.decode())
print(p.stderr.decode())
sys.exit(p.returncode)
