"""Independent finite tamper/resource checks; no worker or product implementation."""
import ast
import copy
import hashlib
import json
from pathlib import Path

BASE=Path('/home/davianc/.hermes/cache/scratch/a2-independent-final-complete-l_bwads9')
source=(BASE/'independent_audit_v2.py').read_bytes()
assert hashlib.sha256(source).hexdigest()=='a9c82c13bcd690d75ffb378ca8415bf9e44d2d1fd5172b32bbe6528e13a9a041'
parsed=ast.parse(source)
# Load only our reviewed scratch function definitions/imports/constants. Do NOT
# execute the first audit's top-level work or import an implementer checker.
selected=[]
for n in parsed.body:
    if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.ClassDef)):
        selected.append(n)
    elif isinstance(n,ast.Assign):
        names={x.id for t in n.targets for x in ast.walk(t) if isinstance(x,ast.Name)}
        if names & {'R','A','O','F','P','S','W','CP'}:
            selected.append(n)
ns={'__file__':__file__,'__name__':'independent_finite_helper_definitions'}
exec(compile(ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[])),str(BASE/'independent_audit_v2.py'),'exec'),ns)
ns['root_samples']={}
for key in ['W','F','P','S','enc','digest','schema','nested','route','binding_links','require','Invalid','replace','tree','out','desc']:
    globals()[key]=ns[key]
# Read-only original linked bundles must pass before any mutation.
for b in W['bundles']:
    binding_links(b)

def refresh(b,old_binding=None,new_binding=None):
    a=b['artifacts']
    if old_binding is not None:
        for obj in ns['walk'](a):
            if type(obj) is dict and obj.get('producer_binding_sha256')==old_binding:
                obj['producer_binding_sha256']=new_binding
    for row in a['failure-index.json']['slots']:
        if row['artifact']:
            artifact=row['artifact']; obj=a[artifact['path']]
            artifact.update(bytes=len(enc(obj)),sha256=digest(obj))
    # Snapshot before the final index serialization (not a self measurement).
    before=sum(len(enc(v)) for k,v in a.items() if k not in ['failure-index.json','records/export.json','run-manifest.json'])+len(enc(b['initial_failure_index']))
    a['failure-index.json']['bytes_accounting'].update(live_bytes=before,cumulative_written_bytes=before)
    ex=a['records/export.json']
    ex.update(process_sha256=digest(a['records/process.json']),failure_index_sha256=digest(a['failure-index.json']),failure_index_bytes=len(enc(a['failure-index.json'])))
    a['run-manifest.json']['files']=[dict(path=k,bytes=len(enc(v)),sha256=digest(v)) for k,v in a.items() if k!='run-manifest.json']

def extra_links(b):
    a=b['artifacts'];ib=a['input-bundle.json'];q=ib['request'] or json.loads(bytes.fromhex(ib['raw_request_utf8_hex']))
    for obj in a.values():
        if obj.get('record_type')=='producer_binding':
            require(obj['producer']['mode']==obj['mode'],'producer mode agrees with actual invocation')
            if obj['configuration'].get('history')=='full':
                require(obj['configuration']['operator']==q['operator'],'full alias agrees with request')
                expected='hpfracc.ops.fractional.'+('grunwald_letnikov' if q['operator']=='GL' else 'riemann_liouville')
                require(obj['producer']['entrypoint']==expected,'full alias agrees with actual source entrypoint')
    for item in a['run-manifest.json']['files']:
        require(item['sha256']==digest(a[item['path']]) and item['bytes']==len(enc(a[item['path']])),'outer fresh digest')

results=[]
controls=copy.deepcopy(W['tamper_controls'])+[
    dict(id='producer-mode-swap',target='binding/producer/mode',replacement='jit'),
    dict(id='full-alias-swap',target='binding/configuration/operator',replacement='RL'),
    dict(id='full-entrypoint-swap',target='binding/producer/entrypoint',replacement='hpfracc.ops.fractional.riemann_liouville'),
]
for ctl in controls:
    name=ctl['id'];category,*path=ctl['target'].split('/')
    kind='barrier' if name=='zero-barrier-released' else 'timeout' if name=='grace-not-recorded' else 'knownbad' if name=='none-for-knownbad' else 'full'
    original=next(b for b in W['bundles'] if b['declared_case_id']=='FIT-ramp-tau0-f64-GL') if name=='missing-check' else next(b for b in W['bundles'] if b['kind']==kind)
    b=copy.deepcopy(original);a=b['artifacts']
    if category=='binding':obj=next(x for x in a.values() if x.get('record_type')=='producer_binding' and x['binding_id']=='full')
    elif category=='observation':obj=next(x for x in a.values() if x.get('record_type')=='observation')
    elif category=='index':obj=a['failure-index.json']
    elif category=='process':obj=a['records/process.json']
    elif category=='output':obj=a['records/output-control.json']
    elif category=='slot':obj=next(z for z in a['result.json']['assessments'][0]['slots'] if z['status']=='not_applicable')
    else:raise AssertionError(category)
    before=digest(obj)
    replace(obj,path,ctl['replacement'])
    # Refresh redundant copies of the same receipt/context too, so a stale
    # embedded process/observation cannot mask the intended semantic defect.
    if category=='process':
        a['failure-index.json']['process']=copy.deepcopy(obj)
    if name in ['producer-mode-swap','full-alias-swap','full-entrypoint-swap']:
        for other in a.values():
            if other.get('record_type')=='observation' and other['observation_id']==obj['observation_id']:
                other['producer']=copy.deepcopy(obj['producer'])
                other['configuration']=copy.deepcopy(obj['configuration'])
    require(digest(obj)!=before,'non-no-op one-field mutant')
    refresh(b,before if category=='binding' else None,digest(obj) if category=='binding' else None)
    # Every copied outer artifact checksum must be valid BEFORE semantic checking.
    for z in a['run-manifest.json']['files']:
        require(z['sha256']==digest(a[z['path']]) and z['bytes']==len(enc(a[z['path']])),'outer checksums genuinely refreshed')
    rejection=None
    try:
        for key,x in a.items():route(key,x);nested(x)
        binding_links(b);extra_links(b)
    except Invalid as e:rejection=str(e)
    require(rejection is not None,'semantic mutant escaped '+name)
    results.append(dict(id=name,changed=True,outer_digests_refreshed=True,rejection=rejection))
# Additional strong canonical-type/noncanonical rational probes.
canonical=[]
for rt,field,val in [('process','exit_code',1.0),('process','elapsed_monotonic_ns',True),('process','watchdog_triggered',0),('result','implementation_authorized',0),('result','a2_acceptance_passed',0)]:
    x=copy.deepcopy(next(v for b in W['bundles'] for v in b['artifacts'].values() if v.get('record_type')==rt));x[field]=val
    try:schema(x,S)
    except Invalid:canonical.append(rt+'.'+field+':rejected')
    else:raise AssertionError('canonical coercion accepted')
for val in [{'num':'-0','den':'1'},{'num':'01','den':'1'},{'num':'1','den':'02'},{'num':'2','den':'4'},{'num':'0','den':'2'},{'num':'A','den':'1'},{'num':'0x1','den':'1'},{'num':'+1','den':'1'},{'num':'1','den':'0'}]:
    try:ns['rat'](val)
    except Invalid:canonical.append(str(val)+':rejected')
    else:raise AssertionError('noncanonical rational accepted')
# Every candidate-free future binding, including both aliases, exact metadata,
# own mode and truthful null runtime context; no arrays supplied for real fits.
for x in W['future_full_bindings']:
    case=next(c for c in F['cases'] if c['case_id']==x['case_id']);q=case['request'];ob=x['observation'];co=x['comparison']
    require(ob['case_id']==co['case_id']==x['case_id'],'full case link')
    require(ob['configuration']['operator']==q['operator'] and ob['configuration']['n']==F['arrays'][q['input_ref']]['shape'][0] and ob['configuration']['alpha']==q['alpha'] and ob['configuration']['dt']==q['dt'],'full actual configuration variant')
    require(ob['candidate_id'] is ob['candidate_index'] is co['candidate_id'] is co['candidate_index'] is None,'all full candidate nulls')
    require(ob['status']=='not_evaluated' and ob['producer'] is None and ob['producer_binding_sha256'] is None,'unobserved full runtime absent')
    require(co['policy_id']==F['arrays'][q['input_ref']]['dtype']+'-forward_full_exact','full own dtype policy')

sizes=json.loads((BASE/'attempt2/resource-templates-independent.json').read_text())
refusals=[x for x in sizes if x['transaction_upper_bytes']>524288 or x['complete_nodes']>32768]
require(len(refusals)==8,'eight refused obligations')
resource=[]
for x in refusals:
    # The lower object intentionally violates semantic status/payload rules to
    # undercount valid index records. Fixed IDs, keys and complete inventory
    # remain. Every omitted process field and every shortened value can only
    # make this LOWER than a valid serialization. Two such records already fail.
    lower=2*x['lower_index_bytes']
    require(lower>524288,'branch-independent lower bound still over reservation')
    resource.append(dict(case_id=x['case_id'],two_index_serialization_lower_bound=lower,reservation=524288,lower_bound_is_NOT_a_valid_output_or_measured_run=True,illustrative_selected_only_templates_NOT_minimal_NOT_runtime=x['selection_compatible_templates']))
summary=dict(label='INDEPENDENT STATIC TAMPER AND SERIALIZATION PROOF; no execution authentication or numerical feasibility',baseline_bundles_passed=17,semantic_mutants=results,canonical_extra_negatives=canonical,full_bindings_rechecked=64,resource_branch_independent_lower_bounds=resource,allcomplete_node_count_classification='CONSERVATIVE upper template: mutually exclusive unselected branches incorrectly all called complete; not an unavoidable node lower bound',byte_failure_classification='Even two deliberately undercounted full-inventory index records exceed 512KiB with no process interiors or receipts; cannot be explained away solely by unselected branches',important_limits=['Selection-compatible templates contain descriptor/status metadata only, not actual fitted arrays or runtime receipts.','Node counts of these models are not universal or minimal; inactive/unused quantities and actual process fields affect them.','No cap change, omitted checks, case substitution, further repair or implementation authorized.'])
# Verify the earlier 74-member planning preservation without extraction.
import tarfile
legacy=json.loads((ns['A']/'corrected-draft-planning-preservation.json').read_text())
summary['earlier_planning_preservation_keys']=list(legacy)
archive=ns['A']/legacy.get('archive','corrected-draft-planning-evidence.tar.gz')
with tarfile.open(archive) as t:
    members={z.name:z for z in t.getmembers() if z.isfile()}
    assert set(members)==set(legacy['files'])
    for name,meta in legacy['files'].items():
        data=t.extractfile(members[name]).read()
        assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
summary['earlier_planning_preservation_members_verified']=len(members)
ns['out']('supplemental-proof.json',summary)
print(json.dumps(dict(baseline_bundles_passed=17,semantic_mutants_rejected=len(results),extra_canonical_controls=len(canonical),full_bindings=64,lower_bound_range=[min(z['two_index_serialization_lower_bound'] for z in resource),max(z['two_index_serialization_lower_bound'] for z in resource)]),indent=2))
