"""Read-only bounded final preparation audit, stdlib only.
Not a product selector/validator/worker and not numerical acceptance.
Only writes new evidence adjacent to this script. No helper imports.
"""
import ast
import copy
import hashlib
import json
import math
import os
import pathlib
import re
import struct
import subprocess
import tarfile
from collections import Counter
from fractions import Fraction

R = pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
A = R / 'docs/validation/audits/a2-preparation-2026-11-11'
O = pathlib.Path(__file__).parent

def enc(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()
def sha(b):
    return hashlib.sha256(b).hexdigest()
def digest(x):
    return sha(enc(x))
def out(name, value):
    path = O / name
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n')
def unique(pairs):
    if len(pairs) != len({k for k, _ in pairs}):
        raise ValueError('duplicate JSON key')
    return dict(pairs)
def badnumber(x):
    raise ValueError('noninteger/nonfinite JSON token ' + x)
def load(b):
    return json.loads(b, object_pairs_hook=unique, parse_float=badnumber, parse_constant=badnumber)
F, P, S, W, CP = [load((A / n).read_bytes()) for n in ['fixtures.json', 'protocol.json', 'record-schemas.json', 'schema-control-fixtures.json', 'comparison-policies.json']]
class Invalid(ValueError):
    pass
def require(ok, msg):
    if not ok:
        raise Invalid(msg)

def schema(x, spec, loc='$'):
    # Only implements the finite vocabulary actually present in this packet.
    if '$ref' in spec:
        schema(x, S['$defs'][spec['$ref'].split('/')[-1]], loc)
    for kind in ['anyOf', 'oneOf']:
        if kind in spec:
            success = 0
            for child in spec[kind]:
                try:
                    schema(x, child, loc)
                    success += 1
                except Invalid:
                    pass
            require(success == 1 if kind == 'oneOf' else success > 0, loc + ':' + kind)
    if 'enum' in spec:
        require(any(type(x) is type(y) and x == y for y in spec['enum']), loc + ':enum')
    typ = spec.get('type')
    if typ:
        require(type(x) is {'object': dict, 'array': list, 'string': str, 'integer': int, 'boolean': bool, 'null': type(None)}[typ], loc + ':type')
    if typ == 'object':
        require(set(spec.get('required', [])) <= set(x), loc + ':required')
        require(spec.get('additionalProperties') is not False or set(x) <= set(spec['properties']), loc + ':extra')
        for k, v in x.items():
            schema(v, spec['properties'][k], loc + '/' + k)
    elif typ == 'array':
        require(spec.get('minItems', 0) <= len(x) <= spec.get('maxItems', 10**9), loc + ':length')
        for i, v in enumerate(x):
            schema(v, spec['items'], loc + '/' + str(i))
    elif typ == 'string':
        require(x.isascii(), loc + ':ascii')
        require(spec.get('minLength', 0) <= len(x) <= spec.get('maxLength', 10**9), loc + ':length')
        if 'pattern' in spec:
            require(re.fullmatch(spec['pattern'], x) is not None, loc + ':pattern')
    elif typ == 'integer':
        require(spec.get('minimum', -10**100) <= x <= spec.get('maximum', 10**100), loc + ':range')

def rat(x, tau=False):
    schema(x, S['$defs']['rat'])
    n, d = x['num'], x['den']
    require(len(n.lstrip('-')) <= 8192 and len(d) <= 8192, 'rational predecode length')
    a, b = int(n, 16), int(d, 16)
    require(b > 0 and math.gcd(abs(a), b) == 1 and (a != 0 or b == 1), 'reduced rational')
    require(max(abs(a).bit_length(), b.bit_length()) <= (256 if tau else 32768), 'rational bits')
    require(not tau or a >= 0, 'nonnegative tau')
    return Fraction(a, b)
def raw(x):
    schema(x, S['$defs']['raw_array'])
    b = bytes.fromhex(x['raw_hex'])
    require(len(b) == x['nbytes'] == math.prod(x['shape']) * {'float32':4, 'float64':8, 'complex64':8, 'complex128':16}[x['dtype']], 'raw length/shape')
    require(sha(b) == x['sha256'], 'raw hash')
    return b
def decode(x):
    b = raw(x)
    require(x['dtype'] in ['float32', 'float64'], 'real decode')
    fmt = ('<' if x['byte_order'] == 'little' else '>') + ('f' if x['dtype'] == 'float32' else 'd')
    return [Fraction(v[0]) for v in struct.iter_unpack(fmt, b)]
def desc(x):
    if 'raw_hex' in x:
        return {k:v for k,v in x.items() if k != 'raw_hex'}
    return {'shape': x['shape'], 'values_count': len(x['values']), 'payload_sha256': digest(x)}
def walk(x):
    yield x
    if type(x) is dict:
        for y in x.values():
            yield from walk(y)
    elif type(x) is list:
        for y in x:
            yield from walk(y)
def tree(x):
    if type(x) is dict:
        c = [tree(y) for y in x.values()]
        return 1 + len(x) + sum(y[0] for y in c), 1 + max([y[1] for y in c] or [0])
    if type(x) is list:
        c = [tree(y) for y in x]
        return 1 + sum(y[0] for y in c), 1 + max([y[1] for y in c] or [0])
    return 1, 1

def disposition(x):
    r = x['reasons']
    require(r and len(set(r)) == len(r) and ('none' not in r or r == ['none']), 'unique/exclusive reasons')
    if 'reason' in x:
        require(x['reason'] == r[0], 'primary reason')
    st = x['status']
    if x.get('record_type') == 'slot':
        payloads = sum(x[k] is not None for k in ['raw_array','exact_array'])
        if st in ['complete','partial']:
            require(payloads == 1 and x['producer_binding_sha256'] is not None, 'complete/partial payload binding')
            require((r == ['none']) == (st == 'complete'), 'completion reason')
        else:
            require(payloads == 0 and x['producer_binding_sha256'] is None and r != ['none'], 'pending no payload')
            if st == 'not_applicable':
                require(all(v in S['x-disposition-table']['slot_inapplicable']['reasons'] for v in r), 'typed not_applicable')
    if x.get('record_type') in ['comparison','binding_check']:
        require((r == ['none']) == (st == 'pass'), 'check pass iff no reason')

def replace(root, keys, value):
    target = root
    for key in keys[:-1]:
        key = int(key) if type(target) is list else key
        require(key in target if type(target) is dict else 0 <= key < len(target), 'existing intermediate mutation target')
        target = target[key]
    last = int(keys[-1]) if type(target) is list else keys[-1]
    require(last in target if type(target) is dict else 0 <= last < len(target), 'existing final mutation target')
    target[last] = copy.deepcopy(value)

def expand(case):
    q = copy.deepcopy(case['request'])
    for m in case['mutations']:
        if m['stage'] == 'references':
            require(m['replace'].startswith('request/'), 'reference mutation owner')
            replace(q, m['replace'].split('/')[1:], m['value'])
    refs = q.pop('candidate_refs')
    q['input'] = copy.deepcopy(F['arrays'][q.pop('input_ref')])
    require(q.pop('caps_ref') == 'protocol.json#/caps', 'caps ref')
    q['caps'] = copy.deepcopy(P['caps'])
    q['candidates'] = []
    for ref in refs:
        c = copy.deepcopy(F['candidates'][ref])
        c['record_type'] = 'candidate_spec' if 'producer_call' in c else 'candidate'
        for key in ['rhos','coefficients']:
            ar = c.pop(key + '_ref')
            c[key] = None if ar is None else copy.deepcopy(F['arrays'][ar])
        q['candidates'].append(c)
    q.update(record_type='request', request_id=case['case_id'], case_id=case['case_id'], policy_id=P['protocol_id'], packet_manifest_sha256='1'*64)
    for m in case['mutations']:
        if m['stage'] == 'expanded':
            keys = m['replace'].split('/')
            target = q if keys[0] == 'request' else q['candidates'][int(keys[0].split(':')[1])]
            replace(target, keys[1:], m['value'])
        elif m['stage'] == 'evidence':
            require(m['replace'] in [z['path'] for z in case['evidence_mutation_cells']], 'predeclared evidence mutation cell')
    ctl = case['resource_control']
    if ctl and ctl.get('override_cap') is not None:
        q['caps'][ctl['override_cap']] = ctl['value']
    return q

def inventory(case, q):
    return [dict(slot_id=z['slot_id'], candidate_id=None if z['candidate_index'] is None else q['candidates'][z['candidate_index']]['stable_id'], candidate_index=z['candidate_index'], mode=z['mode'], branch=z['branch'], quantity=z['quantity']) for z in case['required_evidence_slots']]
def expect_shape(z,q):
    kind = z['quantity']; n = q['input']['shape'][0]
    if kind in ['input','v','D','D_hat','error','B','analytic_input_gradient','output','full_output','input_AD','direction']:
        return q['input']['shape'][:]
    if kind in ['w','g','g_hat','residual','signed_fitted_weights']:
        return [n]
    if kind == 'L_hat':
        return [n,n]
    if kind in ['rhos','coefficients','zero_pattern']:
        return [q['candidates'][z['candidate_index']]['configuration']['pole_count']]
    return []
def cmp_records(case,q):
    return [dict(record_type='comparison', comparison_id=z['comparison_id'], case_id=q['case_id'], candidate_id=None if z['candidate_index'] is None else q['candidates'][z['candidate_index']]['stable_id'], candidate_index=z['candidate_index'], policy_id=z['policy_id'], a_slot_id=z['a_slot_id'], reference_slot_id=z['reference_slot_id'], status='not_evaluated', reasons=['not_evaluated']) for z in case.get('required_working_comparisons',[])]
def check_records(case,q):
    return [dict(record_type='binding_check',case_id=q['case_id'],candidate_id=q['candidates'][z['candidate_index']]['stable_id'],candidate_index=z['candidate_index'],mode=z['mode'],branch=z['branch'],reference_branch=z['reference_branch'],observation_id=None,reference_observation_id=None,comparison=z['comparison'],status='not_evaluated',reasons=['not_evaluated'],check_id=z['check_id']) for z in case.get('required_fit_identity_checks',[])]
def pending_phase():
    return dict(status='not_applicable',start_ns=None,end_ns=None,elapsed_ns=None,reason='stage_not_used')
def process(q,bh):
    return dict(record_type='process',run_id='hyp-run',process_id='hyp-process',case_id=q['case_id'],request_id=q['request_id'],input_bundle_sha256=bh,launch_receipt_sha256=None,command=['HYPOTHETICAL-NOT-EXECUTED'],exit_code=None,termination='not_launched',elapsed_monotonic_ns=None,watchdog_triggered=False,stdout_sha256=None,stderr_sha256=None,stdout_truncated=False,stderr_truncated=False,exit_confirmed=False,barrier='not_launched',phases=dict(preflight=dict(status='observed',start_ns=1,end_ns=11,elapsed_ns=10,reason='none'),watchdog=pending_phase(),grace=pending_phase(),kill_to_exit=pending_phase()))
def inputbundle(case,q,valid):
    inv=inventory(case,q); cm=cmp_records(case,q); ck=check_records(case,q)
    return dict(record_type='input_bundle',request=copy.deepcopy(q) if valid else None,sources=[dict(repo_path=z,sha256=sha((R/z).read_bytes())) for z in ['src/hpfracc/ops/_soe.py','src/hpfracc/ops/fractional.py','uv.lock','docs/developer/a2-compression-budget-protocol.md']],required_slots=inv,raw_request_utf8_hex='' if valid else enc(q).hex(),raw_request_sha256=digest(q),candidate_ids=[x['stable_id'] for x in q['candidates']],candidate_occurrences=[dict(candidate_index=i,candidate_id=x['stable_id']) for i,x in enumerate(q['candidates'])],required_comparisons=[{k:x[k] for k in ['comparison_id','candidate_id','candidate_index','policy_id','a_slot_id','reference_slot_id']} for x in cm],required_binding_checks=[{k:x[k] for k in ['check_id','candidate_id','candidate_index','mode','branch','reference_branch','comparison']} for x in ck])
def initial_index(case,q,ib):
    bh=digest(ib)
    return dict(record_type='failure_index',request_id=q['request_id'],input_bundle_sha256=bh,candidate_ids=ib['candidate_ids'][:],candidate_occurrences=copy.deepcopy(ib['candidate_occurrences']),slots=[dict(**z,status='not_evaluated',reason='not_evaluated',reasons=['not_evaluated'],expected_shape=expect_shape(z,q),completed_shape=None,artifact=None) for z in ib['required_slots']],status='not_evaluated',reasons=['not_evaluated'],process=process(q,bh),comparisons=cmp_records(case,q),binding_checks=check_records(case,q),bytes_accounting=dict(live_bytes=0,cumulative_written_bytes=0,reserved_final_transaction_bytes=0))

# Preservation readback: never extract or recreate links.
archives=[]; historical={}
for pn in ['initial-contract-reviews-preservation.json','corrected-contract-reviews-failed-preservation.json','final-preparation-correction-preservation.json']:
    d=load((A/pn).read_bytes())
    an=d.get('archive','initial-contract-reviews-failed.tar.gz')
    ab=(A/an).read_bytes()
    require(sha(ab)==d.get('archive_identity',{}).get('sha256',d.get('archive_sha256')), 'preservation archive digest')
    with tarfile.open(A/an) as t:
        members={m.name:m for m in t.getmembers() if m.isfile()}
        require(len(members)==len(d['files']), 'archive declared total')
        require(set(members)==set(d['files']), 'archive declared members')
        for key, v in d['files'].items():
            bb=t.extractfile(members[key]).read()
            require(len(bb)==v['bytes'] and sha(bb)==v['sha256'], 'archived member '+key)
            if key.endswith('verdict.json'):
                historical[an+':'+key]=load(bb)
            if an=='corrected-contract-reviews-failed.tar.gz' and key.endswith('/fixtures.json') and key.startswith('reviewed-repo/'):
                oldf=load(bb)
            if an=='final-preparation-correction-evidence.tar.gz' and key.startswith('correction/before/'):
                historical[key]=bb
    archives.append(dict(archive=an,sha256=sha(ab),members=len(members),all_regular_data=True))
out('archive-verification.json',archives)
for name,v in historical.items():
    if name.endswith('verdict.json'):
        require(v['passed'] is False, 'historical failure remains failed')
# Actual packet manifest, no self hash.
manifest=load((A/'packet-manifest.json').read_bytes())
for z in manifest['files']:
    bb=(R/z['repo_path']).read_bytes()
    require(len(bb)==z['bytes'] and sha(bb)==z['sha256'],'packet manifest file')
require(not any(z['repo_path'].endswith('/packet-manifest.json') for z in manifest['files']),'no manifest self edge')
# Inventory/authentication/current-vs-rejected preservation.
for x in F['arrays'].values(): raw(x)
require(all(F['arrays'][k]==v for k,v in oldf['arrays'].items()),'old raw descriptors preserved')
require([x['case_id'] for x in F['cases'][:544]]==[x['case_id'] for x in oldf['cases']],'old case IDs preserved')
for a,b in zip(oldf['cases'],F['cases']):
    require(a['request']==b['request'] and a['expected']==b['expected'],'old requests/budgets/stop gates preserved')
    require(a['mutations']==[{k:v for k,v in x.items() if k!='stage'} for x in b['mutations']],'only mutation stages changed')
for k in ['parse_controls','identity_controls','shortcut_controls']:
    require(F[k]==oldf[k], 'old controls '+k)
require((A/'comparison-policies.json').read_bytes()==historical['correction/before/comparison-policies.json'],'exact comparison policy bytes unchanged')
priorp=load(historical['correction/before/protocol.json'])
require(P['caps']==priorp['caps'] and P['domain']==priorp['domain'],'caps and domain unchanged')
mathhead=b'## 4. Exact finite mathematical contract\n'
def section(b): return mathhead+b.split(mathhead,1)[1].split(b'## 5.',1)[0]
mb=section((R/'docs/developer/a2-compression-budget-protocol.md').read_bytes())
require(mb==section(historical['correction/before/a2-compression-budget-protocol.md']),'math bytes unchanged')

counts=dict(cases=len(F['cases']),arrays=len(F['arrays']),candidate_specs=len(F['candidates']),groups=dict(Counter(x['group'] for x in F['cases'])),slots=sum(len(x['required_evidence_slots']) for x in F['cases']),comparisons=sum(len(x.get('required_working_comparisons',[])) for x in F['cases']),fitchecks=sum(len(x.get('required_fit_identity_checks',[])) for x in F['cases']),fullbindings=sum(len(x.get('required_full_observations',[])) for x in F['cases']),maxslots=max(len(x['required_evidence_slots']) for x in F['cases']))
require((counts['cases'],counts['slots'],counts['comparisons'],counts['fitchecks'],counts['fullbindings'])==(560,24336,1312,1056,64),'independent totals')
future=[v for v in F['candidates'].values() if 'producer_call' in v]
require(len(future)==12 and all(v['rhos_ref'] is v['coefficients_ref'] is None for v in future),'unobserved real arrays absent')
policies={z['policy_id']:z for z in CP['policies']}
sizes=[]; expansions=[]; new_proofs=[]
for case in F['cases']:
    q=expand(case)
    valid=True
    try:
        schema(q,S['$defs']['request'])
        for x in walk(q):
            if type(x) is dict and set(x)=={'num','den'}: rat(x)
            if type(x) is dict and 'raw_hex' in x: raw(x)
    except (Invalid,ValueError): valid=False
    ib=inputbundle(case,q,valid); ix=initial_index(case,q,ib)
    schema(ib,S);schema(ix,S)
    inv=ib['required_slots']; ids={z['slot_id'] for z in inv}
    require(len(ids)==len(inv),'unique slots')
    require({z['candidate_index'] for z in inv if z['candidate_index'] is not None}==set(range(len(q['candidates']))),'all occurrences retain inventory')
    for z in case.get('required_working_comparisons',[]):
        require(z['policy_id'] in policies,'comparison policy exists')
        require((z['a_slot_id'] is None)==(z['reference_slot_id'] is None),'null operands paired')
        if z['a_slot_id'] is not None:
            require(z['a_slot_id'] in ids and z['reference_slot_id'] in ids,'comparison exact slots exist')
    if 'empty-' in case['case_id']:
        require(not q['candidates'] and len(inv)==4,'empty no stale slots')
    if 'duplicate' in case['case_id'] and len(q['candidates'])==2 and q['candidates'][0]['stable_id']==q['candidates'][1]['stable_id']:
        require(q['candidates'][0] is not q['candidates'][1],'separate occurrences')
    initial_len=len(enc(ix)); maxix=copy.deepcopy(ix)
    for z in maxix['slots']:
        z.update(status='complete',reason='none',reasons=['none'],completed_shape=z['expected_shape'][:],artifact=dict(path='arrays/'+z['slot_id']+'.json',bytes=16777216,sha256='f'*64))
    maxix.update(status='complete',reasons=['none'])
    for z in maxix['comparisons']+maxix['binding_checks']:
        z.update(status='unknown',reasons=['incomplete_evidence'])
    # Minimal serialization LOWER BOUND, deliberately NOT a valid output record:
    # Keep mandatory full fixed inventory/keys, choose shortest enum/reason and
    # smallest nullable payload representation. Drop process interior entirely.
    lower=copy.deepcopy(ix);lower.update(status='complete',reasons=['none'],process={})
    for z in lower['slots']:
        z.update(status='unknown',reason='none',reasons=['none'],completed_shape=[],artifact=None)
    for z in lower['comparisons']+lower['binding_checks']:
        z.update(status='pass',reasons=['none'])
    info=dict(case_id=case['case_id'],input_bytes=len(enc(ib)),initial_bytes=initial_len,all_complete_bytes=len(enc(maxix)),transaction_upper_bytes=initial_len+len(enc(maxix))+8192,pending_nodes=tree(ix)[0],complete_nodes=tree(maxix)[0],depth=max(tree(ib)[1],tree(ix)[1],tree(maxix)[1]),lower_index_bytes=len(enc(lower)),initial_plus_lower_no_receipts=initial_len+len(enc(lower)))
    # Selection-compatible templates: only one selected candidate (same in both
    # modes); all unselected branches retained as N/A, never deleted.
    if case['group']=='FIT-REAL' and '-tau1-' in case['case_id']:
        feasible=[]
        for selected in range(3):
            model=copy.deepcopy(ix)
            for z in model['slots']:
                ci=z['candidate_index']; b=z['branch']; k=z['quantity']
                active=ci is None or b=='base' or b=='exact' or ci==selected
                unused=(k=='h' and b in ['base','ad-base']) or (k=='direction' and b=='base')
                if active and not unused:
                    z.update(status='complete',reason='none',reasons=['none'],completed_shape=z['expected_shape'][:],artifact=dict(path='arrays/'+z['slot_id']+'.json',bytes=16777216,sha256='f'*64))
                else:
                    reason='unused_quantity' if unused else 'unselected_candidate'
                    z.update(status='not_applicable',reason=reason,reasons=[reason])
            for z,decl in zip(model['comparisons'],case.get('required_working_comparisons',[])):
                applies=decl['candidate_index'] is None or decl['candidate_index']==selected or decl['scope']=='all_candidates'
                z.update(status='pass' if applies and z['a_slot_id'] else 'not_applicable',reasons=['none'] if applies and z['a_slot_id'] else ['unselected_candidate' if not applies else 'singleton_fd_adjacency'])
            for z in model['binding_checks']:
                applies=z['branch']=='base' or z['candidate_index']==selected
                z.update(status='pass' if applies else 'not_applicable',reasons=['none'] if applies else ['unselected_candidate'])
                if applies:
                    z['observation_id']=z['mode']+'-'+str(z['candidate_index'])+'-'+z['branch']
                    z['reference_observation_id']=z['mode']+'-'+str(z['candidate_index'])+'-base'
            model.update(status='complete',reasons=['none'])
            schema(model,S)
            feasible.append(dict(selected_index=selected,index_bytes=len(enc(model)),nodes=tree(model)[0],initial_plus_final_no_receipts=initial_len+len(enc(model)),complete_slots=sum(z['status']=='complete' for z in model['slots']),not_applicable_slots=sum(z['status']=='not_applicable' for z in model['slots'])))
        info['selection_compatible_templates']=feasible
        if case['case_id']=='FIT-ramp-tau1-f32-GL':
            out('resource-original-initial.json',ix);out('resource-lower-bound-NOT-VALID-RECORD.json',lower);out('resource-allcomplete-UPPER-NOT-EXECUTION.json',maxix);out('resource-selection-compatible-DESCRIPTORS-ONLY.json',model)
    sizes.append(info)
    expansions.append(dict(case_id=case['case_id'],canonical=valid,candidates=len(q['candidates']),slots=len(inv),comparisons=len(ix['comparisons']),fitchecks=len(ix['binding_checks'])))
    if case['case_id'].startswith('RANK2'):
        # New exact rank-two controls, fixed-fit quadratic gradient/central FD.
        x=decode(q['input']);n=q['input']['shape'][0];require(q['input']['shape']==[n,1],'rank two preserved')
        c=q['candidates'][0];rho=decode(c['rhos']);coef=decode(c['coefficients'])
        g=[Fraction(math.comb(2*k,k),4**k) for k in range(n)]
        gh=[Fraction(1)]+[sum(a*b**(k-1) for a,b in zip(coef,rho)) for k in range(1,n)]
        wh=[gh[0]]+[gh[i]-gh[i-1] for i in range(1,n)]
        L=[[2*wh[i-j] if j<=i else Fraction(0) for j in range(n)] for i in range(n)]
        def objective(xx):
            yy=[sum(row[j]*xx[j] for j in range(n)) for row in L]
            return sum(z*z for z in yy)/n
        yy=[sum(row[j]*x[j] for j in range(n)) for row in L]
        grad=[2*sum(L[i][j]*yy[i] for i in range(n))/n for j in range(n)]
        direction=[Fraction(i+1,n+1) for i in range(n)];h=Fraction(1,128)
        fd=(objective([a+h*b for a,b in zip(x,direction)])-objective([a-h*b for a,b in zip(x,direction)]))/(2*h)
        require(fd==sum(a*b for a,b in zip(grad,direction)),'new rank quadratic FD exact')
        eps=max(abs(a-b) for a,b in zip(g,gh));v=[x[0]]+[x[i]-x[i-1] for i in range(1,n)]
        B=[2*eps*sum(abs(vv) for vv in v[:i]) for i in range(n)]
        require(eps==rat(case['expected']['planning_epsilon']) and max(B)==rat(case['expected']['planning_max_B']),'new exact controls')
        new_proofs.append(dict(case_id=case['case_id'],shape=q['input']['shape'],epsilon=str(eps),max_B=str(max(B)),gradient=[str(v) for v in grad],exact_FD=str(fd),quadratic_identity=True))
    elif case['case_id'].startswith('COMBINED'):
        if 'duplicate-' in case['case_id']:
            require(q['candidates'][0]==q['candidates'][1],'duplicate actual full content')
            require(case['expected']['all_reasons']==['duplicate_id','duplicate_content'],'duplicate all causes')
        else:
            require(q['candidates'][0]['producer'] is None and q['candidates'][0]['configuration']['kernel']=='l1','combined actual two faults')
            require(case['expected']['all_reasons']==['missing_producer_binding','configuration_mismatch'] and case['expected']['request_status']=='indeterminate','missing provenance dominates')
        new_proofs.append(dict(case_id=case['case_id'],all_reasons=case['expected']['all_reasons'],request_status=case['expected']['request_status']))
out('all-case-expansion.json',expansions);out('resource-templates-independent.json',sizes);out('new-controls-exact-proofs.json',new_proofs)

# Independent root/routing/type/format checking and all nested canonical payloads.
root_samples={};status_seen={};structural=[];linked=[];contradictions=[]
def route(path,x):
    matches=[]
    for pattern,definition in S['x-artifact-routing'].items():
        parts=re.split(r'(\{[^}]+\})',pattern)
        patternrx=''.join('[A-Za-z0-9][A-Za-z0-9._-]{0,63}' if z.startswith('{') else re.escape(z) for z in parts)
        if re.fullmatch(patternrx,path):matches.append(definition)
    require(len(matches)==1 and matches[0].startswith('#/'),'JSON root route '+path)
    schema(x,{'$ref':matches[0]});schema(x,S)
    root_samples.setdefault(x['record_type'],copy.deepcopy(x))

def nested(x):
    for z in walk(x):
        if type(z) is not dict:continue
        if set(z)=={'num','den'}:rat(z)
        if 'raw_hex' in z:raw(z)
        if set(z)=={'shape','values'}:require(math.prod(z['shape'])==len(z['values']),'exact cardinality')
        if z.get('record_type') in ['slot','comparison','binding_check']:disposition(z)
        if 'candidate_index' in z and 'candidate_id' in z:
            require((z['candidate_index'] is None)==(z['candidate_id'] is None),'occurrence null pair')
def timing(x):
    if x['status']=='observed':
        require(type(x['start_ns']) is int and type(x['end_ns']) is int and x['end_ns']>=x['start_ns'] and x['elapsed_ns']==x['end_ns']-x['start_ns'] and x['reason']=='none','observed phase arithmetic')
    else:require(x['start_ns'] is x['end_ns'] is x['elapsed_ns'] is None and x['reason']!='none','unavailable phase null')

def binding_links(b):
    a=b['artifacts'];ib=a['input-bundle.json'];pr=a['records/process.json'];idx=a['failure-index.json'];la=a['records/launch.json'];ex=a['records/export.json'];res=a['result.json']
    q=ib['request'] or load(bytes.fromhex(ib['raw_request_utf8_hex']))
    require(digest(q)==ib['raw_request_sha256'],'raw request link')
    bh=digest(ib);lh=digest(la)
    for z in [pr,idx,la,res,ex]:require(z['input_bundle_sha256']==bh,'input bundle link')
    require(pr==idx['process'],'index exact final process')
    for k in ['run_id','process_id','case_id','request_id','command']:require(pr[k]==la[k],'process launch '+k)
    require(pr['launch_receipt_sha256']==(lh if la['status']=='launched' else None),'launch hash')
    occurrences=[dict(candidate_index=i,candidate_id=c['stable_id']) for i,c in enumerate(q['candidates'])]
    require(ib['candidate_occurrences']==idx['candidate_occurrences']==occurrences,'exact occurrence list')
    require(ib['candidate_ids']==idx['candidate_ids']==[c['stable_id'] for c in q['candidates']],'exact supplied IDs')
    require(len(idx['slots'])==len(ib['required_slots']) and {z['slot_id'] for z in idx['slots']}=={z['slot_id'] for z in ib['required_slots']},'all slot inventory')
    for z in idx['slots']:
        if z['status'] in ['complete','partial']:
            ar=z['artifact']; require(ar is not None and ar['path'] in a,'slot immutable artifact')
            sl=a[ar['path']];require(ar['bytes']==len(enc(sl)) and ar['sha256']==digest(sl),'slot artifact hash')
            require(z['status']==sl['status'] and z['reasons']==sl['reasons'],'index slot status agreement')
            pp=sl['raw_array'] or sl['exact_array'];require(z['completed_shape']==pp['shape'],'completed payload shape')
            if z['status']=='complete':require(z['expected_shape']==pp['shape'],'complete shape')
            else:require(len(pp['shape'])==len(z['expected_shape']) and 0<pp['shape'][0]<z['expected_shape'][0] and pp['shape'][1:]==z['expected_shape'][1:],'proper partial shape')
    for key,invkey in [('comparisons','required_comparisons'),('binding_checks','required_binding_checks')]:
        require(len(idx[key])==len(ib[invkey]),'all check dispositions '+key)
        for z,t in zip(idx[key],ib[invkey]):require(all(z[k]==v for k,v in t.items()),'check inventory links '+key)
    bindings={digest(z):z for z in a.values() if z.get('record_type')=='producer_binding'}
    for bhash,z in bindings.items():
        require(z['input_bundle_sha256']==bh and z['launch_receipt_sha256']==lh,'producer launch/input link')
        for k in ['run_id','process_id','case_id','request_id']:require(z[k]==pr[k],'producer invocation '+k)
        require(z['policy_id']==q['policy_id'] and z['packet_manifest_sha256']==q['packet_manifest_sha256'],'binding packet/policy')
        require(z['input']==desc(q['input']),'actual base input')
        require(z['alpha']==desc(F['working_scalars'][q['input']['dtype']]['alpha']) and z['dt']==desc(F['working_scalars'][q['input']['dtype']]['dt']),'actual base scalars')
        require(z['sources']==ib['sources'] and z['producer']['source'] in ib['sources'],'actual source list')
        for src in z['sources']:require(sha((R/src['repo_path']).read_bytes())==src['sha256'],'source raw identity')
        require(z['configuration']['n']==q['input']['shape'][0] and z['configuration']['alpha']==q['alpha'] and z['configuration']['dt']==q['dt'],'binding configuration')
        for returned in z['returned']:
            sl=a['arrays/'+returned['slot_id']+'.json'];pp=sl['raw_array'] or sl['exact_array']
            require(returned['descriptor']==desc(pp) and sl['producer_binding_sha256']==bhash,'returned payload binding')
            for k in ['case_id','candidate_id','candidate_index','mode','branch']:require(sl[k]==z[k],'returned branch '+k)
        if z['configuration'].get('history')=='full':
            require(z['candidate_id'] is z['candidate_index'] is None,'full candidate free')
            require(z['producer']['source']['repo_path']=='src/hpfracc/ops/fractional.py' and z['producer']['kind']=='actual_full_history','truthful full producer')
    for z in a.values():
        if z.get('record_type')=='observation' and z['producer_binding_sha256'] is not None:
            bz=bindings[z['producer_binding_sha256']]
            for k in ['run_id','process_id','invocation_id','observation_id','case_id','candidate_id','candidate_index','input_bundle_sha256','launch_receipt_sha256','configuration','producer','mode','branch']:require(z[k]==bz[k],'observation binding '+k)
            for sl in z['slots']:require(sl==a['arrays/'+sl['slot_id']+'.json'],'observation exact slot copy')
    allslots=res['shared_slots']+[z for c in res['assessments'] for z in c['slots']]
    require(Counter(z['slot_id'] for z in allslots)==Counter(z['slot_id'] for z in idx['slots']),'result complete slot inventory')
    for z in allslots:
        if z['status'] in ['complete','partial']:require(z==a['arrays/'+z['slot_id']+'.json'],'result exact slot copy')
    for ph in pr['phases'].values():timing(ph)
    if pr['exit_confirmed']:
        wd=pr['phases']['watchdog'];require(wd['status']=='observed' and wd['elapsed_ns']==pr['elapsed_monotonic_ns'] and pr['exit_code'] is not None,'confirmed process')
        require(pr['phases']['preflight']['end_ns']<=wd['start_ns'],'preflight before launch')
    if pr['watchdog_triggered']:
        require(pr['phases']['grace']['status']=='observed','grace present')
        require(pr['phases']['grace']['start_ns']-pr['phases']['watchdog']['start_ns']>=q['caps']['wall_seconds']*10**9,'watchdog trigger boundary')
        if q['caps']['wall_seconds']==0:require(pr['barrier']=='held' and not bindings,'zero barrier never released')
    if pr['termination']=='kill':
        require(pr['phases']['kill_to_exit']['start_ns']==pr['phases']['grace']['end_ns'] and pr['phases']['kill_to_exit']['end_ns']==pr['phases']['watchdog']['end_ns'],'kill-through-exit')
    require(ex['process_sha256']==digest(pr) and ex['failure_index_sha256']==digest(idx) and ex['failure_index_bytes']==len(enc(idx)),'later immutable export links')
    timing(ex['index_write'])
    require(ex['index_write']['status']!='observed' or not pr['exit_confirmed'] or ex['index_write']['start_ns']>=pr['phases']['watchdog']['end_ns'],'export after exit')
    m=a['run-manifest.json'];require({z['path'] for z in m['files']}==set(a)-{'run-manifest.json'},'manifest complete no self')
    for z in m['files']:require(z['sha256']==digest(a[z['path']]) and z['bytes']==len(enc(a[z['path']])),'outer manifest valid')
    security=a['records/output-control.json']
    if security['status']=='safe':require(all(security[k] is True for k in ['fresh_private_root','subdirs_private','nofollow_verified','regular_owned_single_link','containment_verified']),'safe ownership invariants')
    old=b['initial_failure_index']
    require(len(old['slots'])==len(idx['slots']) and len(old['comparisons'])==len(idx['comparisons']) and len(old['binding_checks'])==len(idx['binding_checks']),'initial all dispositions')
    # DAG: every hash here is a dependency on an earlier immutable object.
    graph={k:set() for k in a}
    byhash={digest(v):k for k,v in a.items()}
    hashfields={'input_bundle_sha256','launch_receipt_sha256','producer_binding_sha256','failure_index_sha256','process_sha256'}
    for path,z in a.items():
        for obj in walk(z):
            if type(obj) is dict:
                for k,v in obj.items():
                    if k in hashfields and type(v) is str and v in byhash:
                        graph[path].add(byhash[v])
        if path=='run-manifest.json':graph[path].update(set(a)-{path})
    seen=set();active=set()
    def visit(k):
        require(k not in active,'acyclic DAG')
        if k in seen:return
        active.add(k)
        for dep in graph[k]:visit(dep)
        active.remove(k);seen.add(k)
    for k in graph:visit(k)
    return dict(kind=b['kind'],case_id=q['case_id'],artifacts=len(a),DAG_nodes=len(seen),status=res['status'])

for b in W['bundles']:
    for path,x in b['artifacts'].items():route(path,x);nested(x)
    try:linked.append(binding_links(b))
    except Invalid as e:contradictions.append(dict(bundle=b['witness_id'],error=str(e)))
for z in W['status_matrix']:
    if 'route' in z:route(z['route'],z['record'])
    else:schema(z['record'],S['$defs'][z['definition']]);timing(z['record'])
    nested(z['record'])
for z in W['future_full_bindings']:
    obs=z['observation'];cmp=z['comparison'];schema(obs,S);schema(cmp,S);nested(obs);nested(cmp)
    case=next(c for c in F['cases'] if c['case_id']==z['case_id']);decl=next(y for y in case['required_full_observations'] if y['mode']==obs['mode'])
    require(obs['candidate_id'] is obs['candidate_index'] is obs['producer'] is obs['producer_binding_sha256'] is None,'64 future full absent not fabricated')
    require(obs['slots'][0]['slot_id']==decl['slot_id']==cmp['a_slot_id'] and cmp['reference_slot_id']=='S-X-D','64 exact full comparison links')
    require(obs['configuration']['history']=='full' and obs['configuration']['operator']==case['request']['operator'],'64 full configuration')
for root in S['oneOf']:
    definition=root['$ref'].split('/')[-1]
    require(definition in root_samples,'every schema root '+definition)
for name,x in root_samples.items():
    for kind in ['missing','extra','bool_numeric']:
        y=copy.deepcopy(x)
        if kind=='missing':del y['record_type']
        elif kind=='extra':y['undeclared']=None
        else:
            if name!='process':continue
            y['exit_code']=True
        try:schema(y,S)
        except Invalid:structural.append(name+':'+kind)
        else:raise Invalid('structural mutant escaped '+name+kind)
# All status/termination enums, recursively matched to each closed definition.
for name,definition in S['$defs'].items():
    for field in ['status','termination','artifact_status']:
        prop=definition.get('properties',{}).get(field,{})
        if 'enum' not in prop:continue
        observed=set()
        for x in walk(W):
            if type(x) is dict and set(x)==set(definition.get('required',[])):
                try:schema(x,definition)
                except Invalid:continue
                observed.add(x[field])
        require(observed==set(prop['enum']),'all status variants '+name+field)
        status_seen[name+'.'+field]=sorted(observed)
out('independent-linked-witnesses.json',dict(linked=linked,contradictions=contradictions,root_variants=sorted(root_samples),status_coverage=status_seen,structural_negatives=structural))
# Frozen parser controls, including strict rational grammar and bool/int rejection.
parser=[]
for ctl in F['parse_controls']:
    bb=bytes.fromhex(ctl['raw_utf8_hex']);require(sha(bb)==ctl['sha256'],'parser bytes')
    rejected=False
    try:
        v=load(bb)
        if ctl['expected']=='reject_integer_type':require(type(v['n']) is int,'strict int')
        if ctl['expected']=='reject_boolean_type':require(type(v['exact_head']) is bool,'strict bool')
        for x in walk(v):
            if type(x) is dict and set(x)=={'num','den'}:rat(x)
    except (Invalid,ValueError):rejected=True
    require(rejected,'parser negative '+ctl['case_id']);parser.append(ctl['case_id'])
# Trace APIs with AST, never import hpfracc or JAX.
soetree=ast.parse((R/'src/hpfracc/ops/_soe.py').read_text())
functions={n.name:n for n in soetree.body if isinstance(n,ast.FunctionDef)}
fit=functions['_fit_soe'];apply=functions['_apply_soe'];cl=next(n for n in soetree.body if isinstance(n,ast.ClassDef) and n.name=='_SOEFit')
require([n.target.id for n in cl.body if isinstance(n,ast.AnnAssign)]==['rhos','coefficients','n','kernel','method','exact_head'],'actual fit dataclass fields')
require([x.arg for x in fit.args.args]==['alpha','n'] and [x.arg for x in fit.args.kwonlyargs]==['n_poles','t_max','kernel','method'],'actual _fit_soe signature')
frac=ast.parse((R/'src/hpfracc/ops/fractional.py').read_text());pub={x.name:x for x in frac.body if isinstance(x,ast.FunctionDef)}
for fn in ['grunwald_letnikov','riemann_liouville']:
    require(fn in pub,'full public entrypoint exists')
    require({'dt','order','history'} <= {x.arg for x in pub[fn].args.kwonlyargs},'actual full API kwargs')
summary=dict(label='INDEPENDENT STATIC/HYPOTHETICAL AUDIT; no real worker/fitting/AD/process/GPU observation',counts=counts,archives=archives,math_bytes=len(mb),math_sha256=sha(mb),prior_controls_preserved=True,policy_bytes_unchanged=True,new_exact_rank_controls=len([x for x in new_proofs if 'gradient' in x]),combined_controls=len([x for x in new_proofs if 'all_reasons' in x]),linked_bundles=len(linked),witness_contradictions=contradictions,root_variants=len(root_samples),typed_status_records=len(W['status_matrix']),parser_controls_rejected=len(parser),resource_input_max=max(z['input_bytes'] for z in sizes),resource_complete_max=max(z['all_complete_bytes'] for z in sizes),resource_transaction_max=max(z['transaction_upper_bytes'] for z in sizes),nodes_max=max(z['complete_nodes'] for z in sizes),refusing_templates=[z['case_id'] for z in sizes if z['transaction_upper_bytes']>524288 or z['complete_nodes']>32768],actual_source_signatures_checked=True)
out('independent-summary.json',summary)
print(json.dumps(summary,indent=2))
require(not contradictions,'linked witnesses contain contradictions')
