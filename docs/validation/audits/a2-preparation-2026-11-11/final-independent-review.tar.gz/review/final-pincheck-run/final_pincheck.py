"""Final protected-byte pin check; read-only repository, new scratch receipt."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
O=Path('/home/davianc/.hermes/cache/scratch/a2-independent-final-complete-l_bwads9')
M=Path('/home/davianc/.hermes/cache/scratch/a2-final-review-cycle2/review-input-manifest.json')
h=lambda x:hashlib.sha256(x).hexdigest()
m=json.loads(M.read_text())
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
cmd=lambda *args:subprocess.check_output(['git',*args],cwd=R,env=env)
files={}
for p,info in m['immutable_repository_files'].items():
    data=(R/p).read_bytes()
    files[p]={'bytes':len(data),'sha256':h(data),'matched':len(data)==info['bytes'] and h(data)==info['sha256']}
nums={p:h((R/p).read_bytes())==v for p,v in m['protected_numerical_inputs'].items()}
status=cmd('status','--porcelain=v1').decode()
initial=json.loads((O/'initial-pincheck-corrected-recipe.json').read_text())
record=dict(manifest_sha256=h(M.read_bytes()),files=files,numerical_inputs=nums,head=cmd('rev-parse','HEAD').decode().strip(),index_sha256=h((R/'.git/index').read_bytes()),index_entries_sha256=h(cmd('ls-files','--stage')),index_entries_recipe='git ls-files --stage, newline-delimited frozen recipe',status=status,status_unchanged=status==initial['status'],repository_profile_skill_writes_authorized=[],a2_acceptance_passed=False,implementation_authorized=False)
record['passed']=all(v['matched'] for v in files.values()) and all(nums.values()) and record['head']==m['repo_head'] and record['index_sha256']==m['protected_git_index_sha256'] and record['index_entries_sha256']==m['protected_index_entries_sha256'] and record['manifest_sha256']=='55c9d3b42cd7507c8533125d5bae4974b4981a3c271328e72896a72105e822b4' and record['status_unchanged']
record['verified_file_count']=len(files)
record['verified_numerical_input_count']=len(nums)
p=O/'final-pin-check.json'
assert not p.exists()
p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['files','numerical_inputs']},indent=2))
assert record['passed']
