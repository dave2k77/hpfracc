"""Archive final failed-readiness review before owner-directed changes."""
from __future__ import annotations

import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
SOURCE = Path('/home/davianc/.hermes/cache/scratch/a2-independent-final-complete-l_bwads9')
HERE = Path('/home/davianc/.hermes/cache/scratch/a2-final-review-cycle2')


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def ident(raw: bytes) -> dict:
    return {'sha256': sha(raw), 'bytes': len(raw)}


manifest_path = HERE / 'review-input-manifest.json'
manifest = json.loads(manifest_path.read_text())
assert sha(manifest_path.read_bytes()) == '55c9d3b42cd7507c8533125d5bae4974b4981a3c271328e72896a72105e822b4'
for name, expected in manifest['immutable_repository_files'].items():
    assert ident((ROOT / name).read_bytes()) == expected, name
for name, expected in manifest['protected_numerical_inputs'].items():
    assert sha((ROOT / name).read_bytes()) == expected, name
assert sha((ROOT / '.git/index').read_bytes()) == manifest['protected_git_index_sha256']
assert sha(subprocess.check_output(['git', 'ls-files', '--stage'], cwd=ROOT)) == manifest['protected_index_entries_sha256']
index_path = SOURCE / 'evidence-index.json'
index = json.loads(index_path.read_text())
assert len(index['files']) == 51
entries = {}
for name, expected in index['files'].items():
    relative = Path(name)
    assert not relative.is_absolute() and '..' not in relative.parts
    path = SOURCE / relative
    assert path.is_file() and not path.is_symlink(), name
    raw = path.read_bytes()
    assert ident(raw) == {'sha256': expected['sha256'], 'bytes': expected['bytes']}, name
    entries['review/' + name] = raw
for name in ['evidence-index.json', 'evidence-index-verification.json', 'verdict.json', 'review.md']:
    entries['review/' + name] = (SOURCE / name).read_bytes()
verdict_raw = (SOURCE / 'verdict.json').read_bytes()
verdict = json.loads(verdict_raw)
assert verdict['passed'] is False and verdict['freeze_ready'] is False
assert verdict['contract_consistency_passed'] is True
assert not verdict['logic_errors'] and not verdict['security_concerns']
assert len(verdict['resource_blockers']) == 1
assert verdict['reviewed_protocol_sha256'] == manifest['reviewed_protocol_sha256']
assert verdict['review_manifest_sha256'] == sha(manifest_path.read_bytes())
assert verdict['implementation_authorized'] is False and verdict['a2_acceptance_passed'] is False
supplement = json.loads((SOURCE / 'supplemental-run3/supplemental-proof.json').read_text())
bounds = supplement['resource_branch_independent_lower_bounds']
assert len(bounds) == 8
values = [row['two_index_serialization_lower_bound'] for row in bounds]
assert (min(values), max(values)) == (614748, 617184)
assert all(row['two_index_serialization_lower_bound'] > row['reservation'] == 524288 for row in bounds)
assert len(supplement['semantic_mutants']) == 15
assert all(row['changed'] is True and row['outer_digests_refreshed'] is True and row['rejection'] for row in supplement['semantic_mutants'])

# Keep exact reviewed packet/status bytes, without nesting older tar bundles.
for name in manifest['immutable_repository_files']:
    path = ROOT / name
    if path.name.endswith('.tar.gz') or path.name.endswith('preservation.json'):
        continue
    entries['reviewed-repo/' + name] = path.read_bytes()
entries['review-input-manifest.json'] = manifest_path.read_bytes()
entries['parent/preserve_final_review.py'] = Path(__file__).read_bytes()
archive_path = AUDIT / 'final-independent-review.tar.gz'
assert not archive_path.exists()
with archive_path.open('wb') as out:
    with gzip.GzipFile(filename='', fileobj=out, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(entries.items()):
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(raw)
                archive.addfile(info, io.BytesIO(raw))
with tarfile.open(archive_path, 'r:gz') as archive:
    members = {member.name: member for member in archive.getmembers()}
    assert set(members) == set(entries)
    for name, raw in entries.items():
        assert archive.extractfile(members[name]).read() == raw, name
verdict_target = AUDIT / 'final-independent-review.json'
assert not verdict_target.exists()
verdict_target.write_bytes(verdict_raw)
record = {
    'scope': 'Final independent preparation review: consistency pass, freeze readiness FAIL',
    'passed': False, 'contract_consistency_passed': True, 'freeze_ready': False,
    'archive': archive_path.name, 'archive_identity': ident(archive_path.read_bytes()),
    'files': {name: ident(raw) for name, raw in sorted(entries.items())},
    'indexed_review_artifacts_verified': 51,
    'verdict_sha256': sha(verdict_raw), 'index_sha256': sha(index_path.read_bytes()),
    'reviewed_protocol_sha256': manifest['reviewed_protocol_sha256'],
    'review_manifest_sha256': sha(manifest_path.read_bytes()),
    'resource_blocker': 'R-FINAL-RESOURCE-01',
    'correction_cycles_remaining': 0, 'owner_decision_required': True,
    'implementation_authorized': False, 'a2_acceptance_passed': False,
}
record_path = AUDIT / 'final-independent-review-preservation.json'
assert not record_path.exists()
record_path.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
summary = {
    'indexed_review_artifacts_verified': 51, 'archive_members_verified': len(entries),
    'verdict_sha256': sha(verdict_raw), 'index_sha256': sha(index_path.read_bytes()),
    'archive_identity': record['archive_identity'],
    'reviewed_packet_and_status_files_unchanged_before_preservation': 19,
    'numeric_inputs_unchanged': len(manifest['protected_numerical_inputs']),
    'git_index_unchanged': True, 'contract_consistency_passed': True,
    'freeze_ready': False, 'resource_blocker': 'R-FINAL-RESOURCE-01',
    'affected_case_count': len(bounds), 'lower_bound_min_bytes': min(values),
    'lower_bound_max_bytes': max(values), 'reservation_bytes': 524288,
    'semantic_mutants_verified': len(supplement['semantic_mutants']),
    'owner_decision_required': True, 'implementation_authorized': False,
}
(HERE / 'final-review-parent-preservation.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, sort_keys=True))
