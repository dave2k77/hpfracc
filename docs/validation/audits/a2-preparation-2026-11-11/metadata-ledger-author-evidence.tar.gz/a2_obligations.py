"""Fail-closed independent predicates over the AUTHOR'S symbolic draft.
This is self-verification, not independent review. Do not repair on failure.
"""
from a2_model import Graph,F,Term,digest,check
from a2_capture import ROOT,dump

def unresolved(g):
    problems=[]
    bindings=[(p,b)for p,b in g.records.items()if b['record_type']=='producer_binding'and b['producer']['kind']=='actual_fitter']
    bases={(b['mode'],b['candidate_index']):b for _,b in bindings if b['branch']=='base'}
    for path,b in bindings:
        branch=b['branch'];base=bases.get((b['mode'],b['candidate_index']))
        if branch=='ad-base' or branch.startswith('input-'):
            required=['alpha','dt']+(['input']if branch=='ad-base'else [])
            for field in required:
                if base and b[field]!=base[field]:problems.append({'record':path,'obligation':'same-mode-actual-'+field+'-identity','observed_draft':'distinct unrelated symbolic descriptors','reference':base['binding_id']})
        if branch.startswith('order-') and b['configuration']['alpha']==g.q['alpha']:
            problems.append({'record':path,'obligation':'actual-perturbed-alpha-equals-configuration-alpha','observed_draft':'configuration still base order, no checked perturbation equality'})
    process=g.records['records/process.json']
    complete=any(r['status']=='complete'for r in g.rows)
    if complete and process['termination']=='normal'and not process['exit_confirmed']:
        problems.append({'record':'records/process.json','obligation':'positive-normal-completion-has-confirmed-exit-or-constrained-observation','observed_draft':'normal with exit_confirmed=false, exit_code=null; no conditional confirmed-exit term'})
    oc=g.records['records/output-control.json']
    if complete and (oc['status']!='safe' or not all(oc[k]for k in ('fresh_private_root','subdirs_private','nofollow_verified','regular_owned_single_link','containment_verified'))):
        problems.append({'record':'records/output-control.json','obligation':'emitted-evidence-has-valid-hypothetical-safe-owned-schedule','observed_draft':'unavailable/unsafe and false checks, without a conditional ownership proof'})
    # Future pass statuses must remain obligations, not assertions inferred from operand presence.
    for p,b in [('failure-index.json/comparison/'+c['comparison_id'],c)for c in g.comparisons]+[('failure-index.json/binding/'+c['check_id'],c)for c in g.binding_checks]:
        if b['status']=='pass':problems.append({'record':p,'obligation':'pass-conditioned-on-declared-numerical-or-identity-predicate','observed_draft':'pass inferred from complete operands/existing observation, no predicate term in model'})
    return problems

if __name__=='__main__':
    case=next(c for c in F['cases']if c['case_id']=='FIT-stacked-tau1-f32-GL')
    g=Graph(case,{'tag':'agree0','winners':(0,0),'fault':None})
    issues=unresolved(g)
    dump(ROOT/'checked-open-obligations.json',{'case_id':case['case_id'],'profile':'conditional-agree0','unresolved_count':len(issues),'unresolved':issues,'scope':'Defects in this scratch author model, NOT a discovered packet defect or need for physical JAX observations.'})
    print('checked unresolved semantic obligations:',len(issues))
    check(not issues,'STOP: finite metadata proof NOT closed; no cap selection or writer restart')
