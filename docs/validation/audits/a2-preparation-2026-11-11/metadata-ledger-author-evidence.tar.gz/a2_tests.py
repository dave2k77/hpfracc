"""Accounting regression: not a numerical/worker test. Baseline uses immutable archive."""
import json
from pathlib import Path
import sys
import tarfile
import unittest
from a2_capture import REPO, ROOT

MODE=sys.argv.pop(1) if len(sys.argv)>1 else 'baseline'

def subject():
    if MODE=='baseline':
        with tarfile.open(REPO/'docs/validation/audits/a2-preparation-2026-11-11/metadata-budget-accounting-blocked-evidence.tar.gz') as archive:
            old=json.load(archive.extractfile('accounted-before/sample-STATIC-METADATA-PROJECTION.json'))['records']
        slots=old['failure-index.json']['slots']
        missing=[r['artifact']['path'] for r in slots if r['artifact'] and r['artifact']['path'] not in old]
        return {'missing_links':missing,'inline_copy_obligations_closed':'result.json' in old and all(not r['artifact'] or r['artifact']['path'] in old for r in slots),'ledger_components_closed':all(k in old for k in ('result.json','run-manifest.json','logs/stdout.bin','logs/stderr.bin')),'symbolic_constraints_closed':all(not r['artifact'] or r['artifact']['path'] in old for r in slots)}
    from a2_model import regression_subject
    return regression_subject()

class AccountingRegression(unittest.TestCase):
    def test_all_conditional_artifacts_have_payload_and_binding_terms(self):
        self.assertEqual(subject()['missing_links'],[])
    def test_required_inline_copies_are_present(self):
        self.assertTrue(subject()['inline_copy_obligations_closed'])
    def test_manifest_logs_and_final_transaction_are_charged(self):
        self.assertTrue(subject()['ledger_components_closed'])
    def test_descriptors_have_checked_symbolic_size_and_identity_constraints(self):
        self.assertTrue(subject()['symbolic_constraints_closed'])

if __name__=='__main__':unittest.main(verbosity=2)
