"""Meaningful negative controls of the frozen draft. Survivors remain BLOCKERS.
In-memory copied symbolic graphs, not actual fits or observed worker exports.
"""
import copy
import json
import unittest
from a2_model import Graph,F,W,metrics,enc,sha,check
from a2_capture import ROOT,dump

CASE=next(c for c in F['cases']if c['case_id']=='FIT-stacked-tau1-f32-GL')
SPEC={'tag':'agree0','winners':(0,0),'fault':None}
RESULTS=[]

def probe(name,mutate):
    g=Graph(CASE,SPEC)
    mutate(g)
    caught=False;error=None
    try:g.audit()
    except AssertionError as exc:caught=True;error=str(exc)
    RESULTS.append({'control':name,'caught':caught,'error':error,'scope':'symbolic metadata mutation; not numerical validation'})
    return caught

def omit_charge(component):
    def mutate(g):
        original=g.ledger
        def altered():
            ledger=original()
            if component=='OLD_INDEX':omitted=ledger['components'][component]['lower']
            elif component=='uncommitted_temp':omitted=128
            elif component=='stdout_raw':omitted=16384
            else:omitted=ledger['components'][component]['lower']
            ledger['cumulative']['lower']-=omitted
            ledger['cumulative']['upper']-=omitted
            ledger['live_sufficient']['lower']-=omitted
            ledger['live_sufficient']['upper']-=omitted
            # Keep named component: a name-presence gate MUST NOT substitute for sum verification.
            return ledger
        g.ledger=altered
    return mutate

class Mutants(unittest.TestCase):
    def test_missing_link(self):
        self.assertTrue(probe('missing-link',lambda g:g.records.pop(next(k for k in g.records if k.startswith('arrays/')))))
    def test_mismatched_descriptor(self):
        def mutate(g):
            b=next(v for v in g.records.values()if v['record_type']=='producer_binding')
            b['returned'][0]['descriptor']['shape']=[1024]
        self.assertTrue(probe('mismatched-descriptor',mutate))
    def test_omitted_inline_copy(self):
        self.assertTrue(probe('omitted-inline-copy',lambda g:g.records['result.json']['shared_slots'].pop()))
    def test_uncharged_manifest(self):self.assertTrue(probe('uncharged-manifest',omit_charge('run-manifest.json')))
    def test_uncharged_temp(self):self.assertTrue(probe('uncharged-temp',omit_charge('uncommitted_temp')))
    def test_uncharged_old_index(self):self.assertTrue(probe('uncharged-old-index',omit_charge('OLD_INDEX')))
    def test_uncharged_log(self):self.assertTrue(probe('uncharged-log',omit_charge('stdout_raw')))
    def test_dropped_reason(self):
        self.assertTrue(probe('dropped-reason',lambda g:g.records['failure-index.json']['slots'][0].update(reasons=['watchdog'])))
    def test_unsupported_shape_retention(self):
        c=next(c for c in F['cases']if c['case_id']=='REQUEST-N18-f32-GL')
        g=Graph(c,{'tag':'declared','winners':(None,None),'fault':None})
        row=next(r for r in g.records['failure-index.json']['slots']if r['quantity']=='D')
        check(row['expected_shape']==[18],'control really starts N18')
        row['expected_shape']=[17]
        caught=False
        try:g.audit()
        except AssertionError:caught=True
        RESULTS.append({'control':'unsupported-shape-truncation','caught':caught,'changed_from':[18],'changed_to':[17]})
        self.assertTrue(caught)
    def test_sum_versus_per_record_nodes(self):
        counts=[20000,20000]
        correct=all(n<=32768 for n in counts)
        mutant=sum(counts)<=32768
        check(correct and not mutant,'control separates sum/per-record')
        RESULTS.append({'control':'sum-vs-per-record-node-rule','caught':correct!=mutant,'scope':'isolated rule arithmetic, NOT a copied full-model mutant'})
        self.assertNotEqual(correct,mutant)
    def test_static_descriptor_outer_hash_recomputed(self):
        # Existing labelled STATIC/HYPOTHETICAL sample, not a future fitter observation.
        b=copy.deepcopy(next(b for b in W['bundles']if b['kind']=='full'))
        artifacts=b['artifacts']
        path=next(p for p,v in artifacts.items()if v.get('record_type')=='producer_binding')
        binding=artifacts[path]
        returned=binding['returned'][0];sid=returned['slot_id']
        original=copy.deepcopy(returned['descriptor']);returned['descriptor']['shape']=[1024]
        check(returned['descriptor']!=original,'nonnoop descriptor mutation')
        oldhash=sha(enc(next(x for p,x in next(b for b in W['bundles']if b['kind']=='full')['artifacts'].items()if p==path)))
        newhash=sha(enc(binding));check(oldhash!=newhash,'inner hash recomputed')
        # Rebind every matching wrapper to the changed binding; then regenerate outer file hashes.
        def rebind(x):
            if isinstance(x,dict):
                for k,v in x.items():
                    if k=='producer_binding_sha256'and v==oldhash:x[k]=newhash
                    else:rebind(v)
            elif isinstance(x,list):
                for v in x:rebind(v)
        rebind(artifacts)
        manifest=artifacts['run-manifest.json']
        manifest['files']=[{'path':p,'bytes':len(enc(v)),'sha256':sha(enc(v))}for p,v in artifacts.items()if p!='run-manifest.json']
        check(all(e['sha256']==sha(enc(artifacts[e['path']]))for e in manifest['files']),'outer hash manifest recomputed')
        slot=artifacts['arrays/'+sid+'.json'];payload=slot['raw_array']or slot['exact_array']
        expectedshape=payload['shape']
        caught=returned['descriptor']['shape']!=expectedshape
        dump(ROOT/'static-descriptor-outer-recomputed-control.json',{'label':'existing frozen STATIC/HYPOTHETICAL witness copied in memory; NOT runtime observation','changed_binding_path':path,'old_binding_sha256':oldhash,'new_binding_sha256':newhash,'outer_manifest':manifest,'inner_expected_shape':expectedshape,'inner_changed_shape':returned['descriptor']['shape'],'semantic_rejected':caught,'limits':'Outer manifest consistency proves hashes were recomputed. This narrow control does not claim all downstream original witness semantics survived resigning.'})
        RESULTS.append({'control':'descriptor-mismatch-outerhash-recomputed','caught':caught,'scope':'narrow real static canonical descriptor predicate; not future numerical data'})
        self.assertTrue(caught)

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Mutants)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    dump(ROOT/'mutants-results.json',{'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'controls':RESULTS,'survivors':[r['control']for r in RESULTS if not r['caught']]})
    raise SystemExit(0 if result.wasSuccessful()else 1)
