"""Scratch-only constrained symbolic metadata algebra, never a run-record exporter.
All Term/RatVector values denote unobserved future data, not fabricated arrays.
No JAX import, fitting, reference arithmetic, selection or worker execution.
"""
from collections import Counter, defaultdict
from dataclasses import dataclass
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
from a2_capture import ROOT, REPO, dump

AUDIT=REPO/'docs/validation/audits/a2-preparation-2026-11-11'
F=json.loads((AUDIT/'fixtures.json').read_text())
P=json.loads((AUDIT/'protocol.json').read_text())
S=json.loads((AUDIT/'record-schemas.json').read_text())
W=json.loads((AUDIT/'schema-control-fixtures.json').read_text())
POL=json.loads((AUDIT/'comparison-policies.json').read_text())
POLICY=P['protocol_id']
PACKET=hashlib.sha256((AUDIT/'packet-manifest.json').read_bytes()).hexdigest()
SOURCES=P['preparation_source_pin']['files']
assert len(SOURCES)==125
DEFS=S['$defs']

def enc(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def sha(x):return hashlib.sha256(x).hexdigest()

def check(test,message):
    if not test:raise AssertionError(message)

@dataclass(frozen=True)
class Term:
    kind:str
    ref:str
    low:int
    high:int
    domain:str

@dataclass(frozen=True)
class RatVector:
    key:str
    count:int

@dataclass
class Size:
    constant:int
    coefficients:Counter
    limits:dict
    def __add__(self,other):
        if isinstance(other,int):other=Size(other,Counter(),{})
        limits=self.limits|other.limits
        for key in self.limits.keys()&other.limits.keys():
            limits[key]=(max(self.limits[key][0],other.limits[key][0]),min(self.limits[key][1],other.limits[key][1]))
            check(limits[key][0]<=limits[key][1],f'parameter conflict {key}')
        coeff=Counter(self.coefficients)
        coeff.update(other.coefficients)
        return Size(self.constant+other.constant,coeff,limits)
    def times(self,k):return Size(self.constant*k,Counter({a:b*k for a,b in self.coefficients.items()}),self.limits.copy())
    def bound(self,upper=False):return self.constant+sum(v*self.limits[k][int(upper)] for k,v in self.coefficients.items())
    def table(self):return {'constant':self.constant,'coefficients':dict(self.coefficients),'limits':self.limits,'lower':self.bound(),'upper':self.bound(True)}

def metrics(x):
    """Nodes include keys. Depth counts root as 1, matching prior audits."""
    if isinstance(x,Term):
        check(0<=x.low<=x.high,'bad term interval')
        if x.kind in ('digest','hex','string','ratnum','ratden'):
            key='encoded_length:'+x.kind+':'+x.ref
            escaped_high=2*x.high if x.kind=='string' else x.high
            return Size(2,Counter({key:1}),{key:(x.low,escaped_high)}),1,1
        check(x.kind=='integer','unsupported symbolic kind')
        return Size(0,Counter({'digits:'+x.ref:1}),{'digits:'+x.ref:(len(str(x.low)),len(str(x.high)))}),1,1
    if isinstance(x,RatVector):
        n=x.count
        check(0<=n<=289,'exact cardinality')
        # Each canonical rational has two keys, two string values and object root.
        base=len(enc({'num':'','den':''}))
        size=Size(2+max(0,n-1)+n*base,Counter({x.key:1}) if n else Counter(),{x.key:(2*n,(8193+8192)*n)} if n else {})
        return size,1+5*n,3 if n else 1
    if isinstance(x,dict):
        parts=[metrics(v) for v in x.values()]
        size=Size(2+max(0,len(x)-1)+sum(len(enc(k))+1 for k in x),Counter(),{})
        for a,_,_ in parts:size=size+a
        return size,1+len(x)+sum(b for _,b,_ in parts),1+max([1]+[c for _,_,c in parts])
    if isinstance(x,list):
        parts=[metrics(v) for v in x]
        size=Size(2+max(0,len(x)-1),Counter(),{})
        for a,_,_ in parts:size=size+a
        return size,1+sum(b for _,b,_ in parts),1+max([0]+[c for _,_,c in parts])
    return Size(len(enc(x)),Counter(),{}),1,1

def annotation(x):
    if isinstance(x,Term):return {'SYMBOL':x.ref,'kind':x.kind,'length_or_value_range':[x.low,x.high],'constraint':x.domain}
    if isinstance(x,RatVector):return {'SYMBOLIC_RATIONAL_VECTOR':x.key,'count':x.count,'constraint':'canonical reduced rationals with normalized bits<=32768; sum num/den ASCII lengths; no numerical values supplied'}
    if isinstance(x,dict):return {k:annotation(v) for k,v in x.items()}
    if isinstance(x,list):return [annotation(v) for v in x]
    return x

def schema(x,schema,path='root'):
    """Static structural interpreter, not numerical or operational replay."""
    if '$ref' in schema:return globals()['schema'](x,DEFS[schema['$ref'].split('/')[-1]],path)
    for union in ('oneOf','anyOf'):
        if union in schema:
            ok=0
            for variant in schema[union]:
                try:globals()['schema'](x,variant,path);ok+=1
                except AssertionError:pass
            check(ok==1 if union=='oneOf' else ok>=1,path+' '+union)
            return
    if isinstance(x,Term):
        check(x.domain!='',path+' unconstrained symbol')
        if x.kind=='integer':check(schema.get('type')=='integer',path+' symbolic integer type')
        else:check(schema.get('type')=='string',path+' symbolic string type')
        if x.kind=='digest':check(x.low==x.high==64 and schema.get('maxLength')==64,path+' digest length')
        elif x.kind in ('hex','string','ratnum','ratden'):
            check(x.high<=schema.get('maxLength',256),path+' symbol string bound')
        if x.kind=='integer':check(x.low>=schema.get('minimum',x.low) and x.high<=schema.get('maximum',x.high),path+' integer bound')
        return
    if isinstance(x,RatVector):
        check(schema.get('type')=='array' and schema['items'].get('$ref')=='#/$defs/rat',path+' rational vector type')
        check(schema.get('minItems',0)<=x.count<=schema['maxItems'],path+' vector cardinality')
        return
    if 'enum' in schema:check(any(type(x) is type(v) and x==v for v in schema['enum']),path+' enum')
    typ=schema.get('type')
    if typ=='object':
        check(type(x)is dict,path+' object')
        check(set(x)==set(schema['required']),path+' keys '+str(set(x)^set(schema['required'])))
        for k,v in x.items():globals()['schema'](v,schema['properties'][k],path+'/'+k)
    elif typ=='array':
        check(type(x)is list,path+' list')
        check(schema.get('minItems',0)<=len(x)<=schema.get('maxItems',10**8),path+' items')
        for i,v in enumerate(x):globals()['schema'](v,schema['items'],path+f'/{i}')
    elif typ=='string':
        check(type(x)is str and x.isascii(),path+' string')
        check(schema.get('minLength',0)<=len(x)<=schema.get('maxLength',10**8),path+' length')
        if 'pattern'in schema:check(re.fullmatch(schema['pattern'],x)is not None,path+' pattern')
    elif typ=='integer':check(type(x)is int and schema.get('minimum',x)<=x<=schema.get('maximum',x),path+' integer')
    elif typ=='boolean':check(type(x)is bool,path+' boolean')
    elif typ=='null':check(x is None,path+' null')

def replace(root,path,value):
    keys=path.split('/')
    target=root
    for k in keys[:-1]:target=target[int(k)] if isinstance(target,list) else target[k]
    last=int(keys[-1]) if isinstance(target,list) else keys[-1]
    check(last in range(len(target)) if isinstance(target,list) else last in target,'replace existing only')
    target[last]=copy.deepcopy(value)

def expand(case):
    q=copy.deepcopy(case['request'])
    for m in case['mutations']:
        if m['stage']=='references':replace(q,m['replace'].removeprefix('request/'),m['value'])
    q['input']=copy.deepcopy(F['arrays'][q.pop('input_ref')])
    q['caps']=copy.deepcopy(P['caps']);q.pop('caps_ref')
    q['candidates']=[]
    for ref in q.pop('candidate_refs'):
        c=copy.deepcopy(F['candidates'][ref]);future='producer_call'in c
        c['record_type']='candidate_spec'if future else 'candidate'
        for k in ('rhos','coefficients'):
            ref=c.pop(k+'_ref');c[k]=None if ref is None else copy.deepcopy(F['arrays'][ref])
        q['candidates'].append(c)
    q.update(record_type='request',request_id=case['case_id'],case_id=case['case_id'],policy_id=POLICY,packet_manifest_sha256=PACKET)
    for m in case['mutations']:
        if m['stage']=='expanded':
            first,*rest=m['replace'].split('/')
            root=q if first=='request' else q['candidates'][int(first.split(':')[1])]
            replace(root,'/'.join(rest),m['value'])
        elif m['stage']=='evidence':
            check(m['replace'].startswith('evidence/candidate:') and m['value']is None,'declared evidence mutation')
    ctrl=case.get('resource_control')
    if ctrl and ctrl.get('override_cap'):q['caps'][ctrl['override_cap']]=ctrl['value']
    check(len({id(c)for c in q['candidates']})==len(q['candidates']),'independent clones')
    return q

def inventory(case,q):
    rows=[]
    for row in case['required_evidence_slots']:
        ci=row['candidate_index'];check(ci is None or 0<=ci<len(q['candidates']),'slot occurrence')
        rows.append({k:row[k]for k in ('slot_id','mode','branch','quantity','candidate_index')}|{'candidate_id':None if ci is None else q['candidates'][ci]['stable_id']})
    check(len({r['slot_id']for r in rows})==len(rows),'unique slots')
    if case['group']!='FIT-REAL':check(len(rows)==4+9*len(q['candidates']),'post mutation inventory')
    return rows

def shape(row,q):
    sh=q['input']['shape'];n=sh[0];k=row['quantity'];ci=row['candidate_index']
    if k in ('w','g','g_hat','residual','signed_fitted_weights'):return [n]
    if k=='L_hat':return [n,n]
    if k in ('rhos','coefficients','zero_pattern'):return [q['candidates'][ci]['configuration']['pole_count']]
    if k in ('epsilon','alpha','dt','h','objective','order_AD','directional_AD','input_FD','order_FD'):return []
    return sh[:]

def raw_descriptor(payload):return {k:v for k,v in payload.items()if k!='raw_hex'}

def digest(ref):return Term('digest',ref,64,64,'SHA256 of canonical referenced record, or raw decoded bytes for raw refs; expression, NOT observed digest')
def sint(ref,maximum=16777216):return Term('integer',ref,0,maximum,'genuine integer bounded by declared schema; runtime value not observed')
def ordinary(ref,maxlen=256):return Term('string',ref,0,maxlen,'ASCII; canonical JSON escaped content <=2*ASCII length')

def raw_symbol(key,sh,dtype):
    n=math.prod(sh)*{'float32':4,'float64':8}[dtype]
    check(n<=4096,'raw cap')
    return {'dtype':dtype,'shape':sh[:],'byte_order':'little','layout':'C','nbytes':n,'raw_hex':Term('hex','raw:'+key,2*n,2*n,'lowercase hex of exactly nbytes future actual raw bytes; finite where required'),'sha256':digest('raw:'+key)}

# Cause sets below come from declarations/mutations, never an inferred fit result.
def profile_specs(case):
    if case['group']=='FIT-REAL':
        for e,j in itertools.product([None,0,1,2],repeat=2):
            yield {'tag':f'modes-{e}-{j}','winners':(e,j),'fault':None}
        for fault in ('missing','knownbad','partial','ops','bits','bytes','timeout','startup','refusal','invalid','unconfirmed'):
            yield {'tag':fault,'winners':(None,None),'fault':fault}
    else:yield {'tag':'declared','winners':(None,None),'fault':None}

def dispositions(case,q,inv,spec):
    fit=case['group']=='FIT-REAL';fault=spec['fault'];winners=spec['winners']
    tau1=q['tau']=={'num':'1','den':'1'}
    derivative=fit and tau1 and winners[0] is not None and winners[0]==winners[1] and fault is None
    expected=case['expected'];global_reasons=expected.get('all_reasons',[expected['reason']])
    if global_reasons==['not_evaluated'] and fit:global_reasons=['none']
    # Duplicated provided references make BOTH duplicate ID and content observable.
    ids=[c['stable_id']for c in q['candidates']]
    if len(ids)!=len(set(ids)):
        global_reasons=list(dict.fromkeys(['duplicate_id','duplicate_content']+[r for r in global_reasons if r!='none']))
    cause={'missing':'missing_raw_artifact','knownbad':'malformed_fit','partial':'incomplete_evidence','ops':'primitive_cap','bits':'normalized_bit_cap','bytes':'evidence_cap','timeout':'watchdog','startup':'watchdog','refusal':'reservation_exceeded','invalid':'invalid_type','unconfirmed':'exit_unconfirmed'}
    if fault:global_reasons=[cause[fault]]
    elif fit and not ((tau1 and derivative)or(not tau1 and winners==(None,None))):global_reasons=['gate_contradiction']
    mutated={int(m['replace'].split('/')[0].split(':')[1])for m in case['mutations']if m['replace'].startswith('candidate:')}
    rows=[]
    for r in inv:
        ci=r['candidate_index'];b=r['branch'];k=r['quantity'];status='complete';reasons=['none']
        if fault in ('ops','bits','bytes','timeout','startup','refusal','invalid','unconfirmed'):
            status='unknown';reasons=global_reasons[:]
        elif fault=='missing' and ci==0:status='unknown';reasons=global_reasons[:]
        elif fault=='knownbad' and ci==0:status='not_applicable';reasons=['malformed_fit']
        elif not fit and expected['request_status']in ('invalid_request','indeterminate'):
            # Fault checkpoint allows the committed first candidate; missing/corrupt isolates occurrence.
            rc=case.get('resource_control')or{}
            if rc.get('fault_checkpoint') and ci in (None,0):pass
            elif expected.get('mutated_candidate_status')=='unknown' and ci not in mutated and ci is not None:pass
            elif expected.get('mutated_candidate_status')=='unknown' and ci is None:pass
            else:status='unknown';reasons=global_reasons[:]
        elif not fit and expected.get('mutated_candidate_status')=='known_ineligible' and ci in mutated:
            status='not_applicable';reasons=global_reasons[:]
        if fit and status=='complete':
            winner=winners[0 if r['mode']!='jit'else 1]
            nonbase=ci is not None and b not in ('base','exact')
            if nonbase and not derivative:status='not_applicable';reasons=['stage_not_used']
            elif nonbase and ci!=winner:status='not_applicable';reasons=['unselected_candidate']
            elif (k=='h'and b in ('base','ad-base'))or(k=='direction'and(b=='base'or b.startswith('order-'))):status='not_applicable';reasons=['unused_quantity']
        if fault=='partial' and r['slot_id']=='S-X-D':status='partial';reasons=['incomplete_evidence']
        rows.append(r|{'status':status,'reason':reasons[0],'reasons':reasons})
    # Combined unavailable+incompatible remains unknown with BOTH causes.
    check(all(r['reason']==r['reasons'][0]for r in rows),'primary reason')
    return rows,global_reasons,derivative

class Graph:
    def __init__(self,case,spec):
        self.case=case;self.spec=spec;self.q=expand(case);self.inv=inventory(case,self.q)
        self.rows,self.causes,self.derivative=dispositions(case,self.q,self.inv,spec)
        self.records={};self.payloads={};self.links=[];self.guards=[]
        self.build()
    def put(self,path,obj,definition):
        check(path not in self.records,'immutable artifact no rewrite')
        schema(obj,DEFS[definition],path)
        self.records[path]=obj
        return digest('record:'+path)
    def need(self,condition,label):
        self.guards.append(label)
        check(condition,label)
    def link(self,source,target,kind):self.links.append({'source':source,'target':target,'kind':kind})
    def build(self):
        q=self.q;case=self.case;fit=case['group']=='FIT-REAL';dtype=q['input']['dtype']
        occurrences=[{'candidate_index':i,'candidate_id':c['stable_id']}for i,c in enumerate(q['candidates'])]
        comparisons=[]
        for c in case.get('required_working_comparisons',[]):
            ci=c['candidate_index']
            comparisons.append({k:c[k]for k in ('comparison_id','policy_id','a_slot_id','reference_slot_id','candidate_index')}|{'candidate_id':None if ci is None else occurrences[ci]['candidate_id']})
        bindings=[]
        for b in case.get('required_fit_identity_checks',[]):
            ci=b['candidate_index'];bindings.append({k:b[k]for k in ('check_id','mode','branch','reference_branch','comparison','candidate_index')}|{'candidate_id':occurrences[ci]['candidate_id']})
        # Captures that cannot be canonical records use raw bytes, never repaired fields.
        try:schema(q,DEFS['request']);canonical=True
        except AssertionError:canonical=False
        if len({o['candidate_id']for o in occurrences})!=len(occurrences):canonical=False
        ib={'record_type':'input_bundle','request':q if canonical else None,'sources':copy.deepcopy(SOURCES),'required_slots':self.inv,'raw_request_utf8_hex':''if canonical else enc(q).hex(),'raw_request_sha256':sha(enc(q)),'candidate_ids':[o['candidate_id']for o in occurrences],'candidate_occurrences':occurrences,'required_comparisons':comparisons,'required_binding_checks':bindings}
        ih=self.put('input-bundle.json',ib,'input_bundle')
        # No copies of request/candidate standalone optional routes are required by chosen schedule.
        common={'run_id':'symbolic-run','process_id':'symbolic-process','case_id':q['case_id'],'request_id':q['request_id'],'input_bundle_sha256':ih}
        cmd=['HYPOTHETICAL-NOT-EXECUTED']
        refusal=self.spec['fault']in ('refusal','invalid')
        launch={'record_type':'launch_receipt',**common,'command':cmd,'pid':None if refusal else Term('integer','pid',1,2147483647,'future actual PID if launched'),'launch_monotonic_ns':None if refusal else sint('launch_ns',9223372036854775807),'status':'not_launched'if refusal else 'launched','barrier':'held','sources':copy.deepcopy(SOURCES)}
        lh=self.put('records/launch.json',launch,'launch_receipt')
        self.link('records/launch.json','input-bundle.json','input digest')
        slots={};groups=defaultdict(list)
        exactquant=set(F['real_worker_inventory']['per_base_candidate_exact_slots'])
        for row in self.rows:
            r=copy.deepcopy(row);sid=r['slot_id'];status=r['status'];sh=shape(r,q)
            r.update(record_type='slot',case_id=q['case_id'],raw_array=None,exact_array=None,producer_binding_sha256=None)
            if status in ('complete','partial'):
                actual=sh[:]
                if status=='partial':
                    self.need(len(sh)>0 and sh[0]>1,'partial has proper time prefix');actual[0]=1
                exact=r['mode']in ('shared','synthetic')or r['quantity']in exactquant or r['quantity']=='zero_pattern'
                payload={'shape':actual,'values':RatVector('rational_digits:'+sid,math.prod(actual))}if exact else raw_symbol(sid,actual,dtype)
                # For successful fixed-fit input branches, the raw fit expression is SAME-mode base.
                if not exact and r['quantity']in ('rhos','coefficients')and (r['branch']=='ad-base'or r['branch'].startswith('input-')):
                    payload=raw_symbol(f"{r['mode']}-{r['candidate_index']}-base-{r['quantity']}",actual,dtype)
                r['exact_array'if exact else 'raw_array']=payload
                self.payloads[sid]=payload
                key=(r['mode'],r['candidate_index'],r['branch'], 'host'if exact else 'worker')
                groups[key].append(sid)
            slots[sid]=r
        self.slots=slots
        for key,sids in groups.items():
            mode,ci,branch,kind=key
            gid=f'{mode}-{ci if ci is not None else "X"}-{branch}-{kind}'
            self.need(len(gid)<=64 and len(sids)<=64,'binding ID/cardinality')
            oid=f'{mode}-{ci if ci is not None else "X"}-{branch}'
            if ci is None and kind=='worker':oid=next(f['observation_id']for f in case['required_full_observations']if f['mode']==mode)
            cfg=copy.deepcopy(q['candidates'][ci]['configuration'])if ci is not None else {'history':'full'if kind=='worker'else 'host_exact','operator':q['operator'],'n':q['input']['shape'][0],'alpha':q['alpha'],'dt':q['dt'],'grid':q['grid'],'lower_terminal':q['lower_terminal'],'prehistory':q['prehistory']}
            if ci is None and kind=='worker':cfg['kernel']='gl_signed'
            source=next(s for s in SOURCES if s['repo_path']==('src/hpfracc/ops/_soe.py'if kind=='worker'and ci is not None else 'src/hpfracc/ops/fractional.py'))
            if kind=='host':producer={'kind':'host_exact','entrypoint':'HYPOTHETICAL-independent-exact','source':source,'policy_id':POLICY,'backend':'host','mode':mode}
            else:
                producer={'kind':'actual_fitter'if ci is not None else 'actual_full_history','entrypoint':'hpfracc.ops._soe._fit_soe'if ci is not None else 'hpfracc.ops.fractional.'+('grunwald_letnikov'if q['operator']=='GL'else 'riemann_liouville'),'source':source,'lock_sha256':next(s['sha256']for s in SOURCES if s['repo_path']=='uv.lock'),'policy_id':POLICY,'backend':'cpu','working_dtype':dtype,'x64':dtype=='float64','jax_version':ordinary('JAX-version'),'device_class':ordinary('device-class'),'mode':mode}
                if ci is not None:producer.update(iterations=400,rate_grid=P['future_real_fitter']['rate_grid'])
            # Descriptors are expressions referring to the same raw/exact payload object.
            def descriptor(sid):
                payload=self.payloads[sid]
                return {'shape':payload['shape'],'values_count':payload['values'].count,'payload_sha256':digest('payload:'+sid)}if 'values'in payload else raw_descriptor(payload)
            input_sid=next((s for s in sids if slots[s]['quantity']=='input'),None)
            alpha_sid=next((s for s in sids if slots[s]['quantity']=='alpha'),None)
            dt_sid=next((s for s in sids if slots[s]['quantity']=='dt'),None)
            h_sid=next((s for s in sids if slots[s]['quantity']=='h'),None)
            direction_sid=next((s for s in sids if slots[s]['quantity']=='direction'),None)
            inputs=descriptor(input_sid)if input_sid else raw_descriptor(q['input'])
            scalars=F['working_scalars']['float32'if dtype=='float32'else 'float64']
            alpha=descriptor(alpha_sid)if alpha_sid else raw_descriptor(scalars['alpha'])
            dt=descriptor(dt_sid)if dt_sid else raw_descriptor(scalars['dt'])
            binding={'record_type':'producer_binding','binding_id':gid,**common,'invocation_id':gid,'observation_id':oid,'candidate_id':None if ci is None else occurrences[ci]['candidate_id'],'candidate_index':ci,'packet_manifest_sha256':PACKET,'launch_receipt_sha256':lh,'policy_id':POLICY,'mode':mode,'branch':branch,'configuration':cfg,'producer':producer,'sources':copy.deepcopy(SOURCES),'input':inputs,'alpha':alpha,'dt':dt,'h':descriptor(h_sid)if h_sid else None,'direction':descriptor(direction_sid)if direction_sid else None,'returned':[{'slot_id':s,'quantity':slots[s]['quantity'],'descriptor':descriptor(s)}for s in sids]}
            bpath=f'records/binding-{gid}.json';bh=self.put(bpath,binding,'producer_binding');self.link(bpath,'records/launch.json','launch digest')
            self.link(bpath,'input-bundle.json','input digest')
            for sid in sids:
                slots[sid]['producer_binding_sha256']=bh
                self.link(bpath,'payload:'+sid,'returned descriptor')
                self.link('arrays/'+sid+'.json',bpath,'binding digest')
            if kind=='worker':
                obs={'record_type':'observation','observation_id':oid,'case_id':q['case_id'],'candidate_id':binding['candidate_id'],'candidate_index':ci,'policy_id':POLICY,'producer':producer,'configuration':cfg,'mode':mode,'branch':branch,'input_bundle_sha256':ih,'base_observation_id':None if branch=='base'else f'{mode}-{ci}-base','slots':[slots[s]for s in sids],'status':'complete'if all(slots[s]['status']=='complete'for s in sids)else 'unknown','reasons':['none']if all(slots[s]['status']=='complete'for s in sids)else ['incomplete_evidence'],'run_id':common['run_id'],'process_id':common['process_id'],'invocation_id':gid,'launch_receipt_sha256':lh,'producer_binding_sha256':bh}
                opath='records/observation-'+oid+'.json';self.put(opath,obs,'observation');self.link(opath,bpath,'producer binding')
        indexrows=[]
        for row in self.rows:
            sid=row['slot_id'];slot=slots[sid];sh=shape(row,q)
            artifact=None;completed=None
            if sid in self.payloads:
                path='arrays/'+sid+'.json';self.put(path,slot,'slot');completed=self.payloads[sid]['shape']
                sz=metrics(slot)[0];artifact={'path':path,'bytes':Term('integer','length:'+path,sz.bound(),min(16777216,sz.bound(True)),'actual canonical slot wrapper length; equality to corresponding size expression required'),'sha256':digest('record:'+path)}
                self.link('failure-index.json',path,'artifact exact length/digest')
            indexrows.append(row|{'expected_shape':sh,'completed_shape':completed,'artifact':artifact})
        byid={r['slot_id']:r for r in self.rows}
        checks=[];comps=[]
        for row in comparisons:
            c=row|{'record_type':'comparison','case_id':q['case_id'],'status':'unknown','reasons':['incomplete_evidence']}
            a,r=c['a_slot_id'],c['reference_slot_id']
            if a is None and r is None:c.update(status='not_applicable',reasons=['singleton_fd_adjacency'])
            elif all(byid[s]['status']=='complete'for s in (a,r)):c.update(status='pass',reasons=['none'])
            elif any(byid[s]['status']=='not_applicable'for s in (a,r)):
                cause=next(byid[s]['reason']for s in (a,r)if byid[s]['status']=='not_applicable');c.update(status='not_applicable',reasons=[cause])
            comps.append(c)
        observation_paths={v['observation_id']:k for k,v in self.records.items()if isinstance(v,dict)and v.get('record_type')=='observation'}
        for row in bindings:
            ci=row['candidate_index'];mode=row['mode'];b=row['branch'];rb=row['reference_branch'];oid=f'{mode}-{ci}-{b}';base=f'{mode}-{ci}-{rb}'
            applies=oid in observation_paths and base in observation_paths
            c=row|{'record_type':'binding_check','case_id':q['case_id'],'observation_id':oid if applies else None,'reference_observation_id':base if applies else None,'status':'pass'if applies else 'not_applicable','reasons':['none']if applies else ['unselected_candidate'if self.derivative else 'stage_not_used']}
            if applies:
                self.link('failure-index.json',observation_paths[oid],'fit binding observation')
                self.link('failure-index.json',observation_paths[base],'fit binding base observation')
            checks.append(c)
        self.comparisons=comps;self.binding_checks=checks
        # Worker/process fields are constrained symbols or explicitly unavailable, never measured here.
        phase={'status':'unavailable','start_ns':None,'end_ns':None,'elapsed_ns':None,'reason':'timing_unavailable'}
        process={'record_type':'process',**common,'launch_receipt_sha256':None if refusal else lh,'command':cmd,'exit_code':None,'termination':'not_launched'if refusal else 'kill'if self.spec['fault']in ('timeout','startup','unconfirmed')else 'normal','elapsed_monotonic_ns':None,'watchdog_triggered':self.spec['fault']in ('timeout','startup'),'stdout_sha256':digest('log:stdout'),'stderr_sha256':digest('log:stderr'),'stdout_truncated':False,'stderr_truncated':False,'exit_confirmed':False,'barrier':'not_launched'if refusal else 'held'if self.spec['fault']=='startup'else 'released','phases':{k:copy.deepcopy(phase)for k in ('preflight','watchdog','grace','kill_to_exit')}}
        ph=self.put('records/process.json',process,'process');self.link('records/process.json','logs/stdout.bin','log digest');self.link('records/process.json','logs/stderr.bin','log digest')
        result={'record_type':'result','case_id':q['case_id'],'request_id':q['request_id'],'input_bundle_sha256':ih,'packet_manifest_sha256':PACKET,'status':'indeterminate','selected_id':None,'reasons':self.causes if self.causes!=['none']else ['incomplete_evidence'],'assessments':[{'candidate_id':o['candidate_id'],'candidate_index':o['candidate_index'],'status':'unknown','reasons':['incomplete_evidence'],'qualifies':None,'slots':[s for s in slots.values()if s['candidate_index']==o['candidate_index']]}for o in occurrences],'shared_slots':[s for s in slots.values()if s['candidate_index']is None],'primitive_count':sint('primitive_count',100000),'max_normalized_bits':sint('max_bits',32768),'evidence_bytes':sint('before_result'),'arithmetic_verified':False,'total_numerical_certified':False,'a2_acceptance_passed':False,'implementation_authorized':False}
        self.put('result.json',result,'result')
        index={'record_type':'failure_index','request_id':q['request_id'],'input_bundle_sha256':ih,'candidate_ids':[o['candidate_id']for o in occurrences],'candidate_occurrences':occurrences,'slots':indexrows,'comparisons':comps,'binding_checks':checks,'status':'indeterminate','reasons':result['reasons'],'process':process,'bytes_accounting':{'live_bytes':sint('before_index_live'),'cumulative_written_bytes':sint('before_index_cumulative'),'reserved_final_transaction_bytes':sint('final_reservation',524288)}}
        self.put('failure-index.json',index,'failure_index')
        self.old=copy.deepcopy(index)
        self.old['status']='not_evaluated';self.old['reasons']=['not_evaluated']
        for r in self.old['slots']:r.update(status='not_evaluated',reason='not_evaluated',reasons=['not_evaluated'],completed_shape=None,artifact=None)
        for r in self.old['comparisons']:r.update(status='not_evaluated',reasons=['not_evaluated'])
        for r in self.old['binding_checks']:r.update(status='not_evaluated',reasons=['not_evaluated'],observation_id=None,reference_observation_id=None)
        self.old['process']=copy.deepcopy(process);self.old['process'].update(termination='not_launched',launch_receipt_sha256=None,barrier='not_launched')
        schema(self.old,DEFS['failure_index'],'initial index')
        export={'record_type':'supervisor_export','run_id':common['run_id'],'process_id':common['process_id'],'case_id':q['case_id'],'input_bundle_sha256':ih,'process_sha256':ph,'failure_index_sha256':digest('record:failure-index.json'),'failure_index_bytes':Term('integer','length:failure-index.json',metrics(index)[0].bound(),min(524288,metrics(index)[0].bound(True)),'canonical index length; current per-file schema constraint'),'index_write':phase,'status':'indeterminate','reasons':['timing_unavailable']}
        self.put('records/export.json',export,'supervisor_export');self.link('records/export.json','failure-index.json','index digest and actual bytes');self.link('records/export.json','records/process.json','process digest')
        output={'record_type':'output_control','request_id':q['request_id'],'root_token':'symbolic-root','status':'unavailable','fresh_private_root':False,'subdirs_private':False,'nofollow_verified':False,'regular_owned_single_link':False,'containment_verified':False,'reasons':['unsafe_output_target']}
        self.put('records/output-control.json',output,'output_control')
        self.logs={k:Term('hex','log:'+k,0,16384,'raw stream bytes (not JSON or hex encoded); actual log hash binds decoded stream')for k in ('stdout','stderr')}
        manifest={'record_type':'run_manifest','run_id':common['run_id'],'case_id':q['case_id'],'files':[{'path':k,'bytes':sint('length:'+k),'sha256':digest('record:'+k)}for k in self.records]+[{'path':'logs/'+k+'.bin','bytes':sint('log_length:'+k,16384),'sha256':digest('log:'+k)}for k in self.logs],'self_hash_excluded':True}
        self.put('run-manifest.json',manifest,'run_manifest')
    def audit(self):
        available=set(self.records)|{'payload:'+k for k in self.payloads}|{'logs/'+k+'.bin'for k in self.logs}
        missing=[l for l in self.links if l['target']not in available]
        self.need(not missing,'all linked artifact/payload terms exist')
        # Inline copy equality, not just presence of paths.
        result=self.records['result.json'];inline=result['shared_slots']+sum([a['slots']for a in result['assessments']],[])
        self.need(Counter(s['slot_id']for s in inline)==Counter(s['slot_id']for s in self.rows),'all result inline slots exactly once')
        for slot in inline:self.need(slot==self.slots[slot['slot_id']],'result inline equals canonical slot '+slot['slot_id'])
        for path,b in self.records.items():
            if b['record_type']=='producer_binding':
                self.need(b['case_id']==self.q['case_id'] and b['input_bundle_sha256']==digest('record:input-bundle.json'),'binding case and input')
                self.need(b['launch_receipt_sha256']==digest('record:records/launch.json'),'binding launch')
                self.need(b['producer']['source']in b['sources'],'binding actual pinned source')
                for r in b['returned']:
                    sid=r['slot_id'];payload=self.payloads[sid]
                    expected={'shape':payload['shape'],'values_count':payload['values'].count,'payload_sha256':digest('payload:'+sid)}if 'values'in payload else raw_descriptor(payload)
                    self.need(r['descriptor']==expected,'exact descriptor equality '+sid)
                    s=self.slots[sid];self.need((s['mode'],s['branch'],s['candidate_index'],s['candidate_id'])==(b['mode'],b['branch'],b['candidate_index'],b['candidate_id']),'binding occurrence/mode/branch '+sid)
            elif b['record_type']=='observation':
                for s in b['slots']:self.need(s==self.slots[s['slot_id']],'observation inline equality')
                if b['configuration'].get('history')=='full':self.need(b['candidate_index']is None and b['candidate_id']is None and b['producer']['source']['repo_path']=='src/hpfracc/ops/fractional.py','candidate free full source')
        # Every inline and index cause retains the exact declared causality.
        indexed=self.records['failure-index.json']['slots']
        for r,s in zip(indexed,self.rows):self.need(r['reasons']==s['reasons'] and r['reason']==s['reason'],'retained causes '+s['slot_id'])
        self.need(set(self.records['run-manifest.json']['files'][i]['path']for i in range(len(self.records['run-manifest.json']['files'])))==set(self.records)-{'run-manifest.json'}|{'logs/'+k+'.bin'for k in self.logs},'manifest enumerates exact chosen artifacts/logs')
        ledger=self.ledger()
        self.need(ledger['final_reservation']>0,'nonzero computed final reservation')
        return {'missing_links':missing,'inline_copy_obligations_closed':len(inline)==len(self.rows),'ledger_components_closed':set(ledger['components'])==set(self.records)|{'OLD_INDEX','stdout_raw','stderr_raw','uncommitted_temp'},'symbolic_constraints_closed':len(self.guards)>len(self.rows),'record_count':len(self.records),'links':len(self.links),'guards':len(self.guards),'ledger':ledger}
    def ledger(self):
        sizes={k:metrics(v)[0]for k,v in self.records.items()};old=metrics(self.old)[0]
        # Chosen finite schedule: initial index + one replacement AFTER EACH
        # immutable array commit (as required), plus final post-process update.
        commits=len(self.payloads)
        # Pending generations have row-specific descriptors as prefix grows.
        gens=[old];progress_size=old
        final=self.records['failure-index.json']
        finalrows={r['slot_id']:r for r in final['slots']}
        oldrows={r['slot_id']:r for r in self.old['slots']}
        for row in self.rows:
            sid=row['slot_id']
            if sid in self.payloads:
                a=metrics(finalrows[sid])[0];b=metrics(oldrows[sid])[0]
                check(not b.coefficients,'old slot size is constant')
                progress_size=progress_size+a+(-b.constant)
                gens.append(progress_size)
        gens.append(sizes['failure-index.json'])
        # No byte double write for rename/link publication: staging file is same inode.
        # Temp parameter is ONLY uncommitted bytes at interruption, not counted arrays twice.
        temporary=Size(0,Counter({'uncommitted_temp':1}),{'uncommitted_temp':(0,16777216)})
        logsize=Size(0,Counter({'stdout_raw':1,'stderr_raw':1}),{'stdout_raw':(0,16384),'stderr_raw':(0,16384)})
        written=Size(0,Counter(),{})
        for path,size in sizes.items():
            if path!='failure-index.json':written=written+size
        for gen in gens:written=written+gen
        written=written+temporary+logsize
        # Live peak <= retained immutable final artifacts + final/new max index +
        # preceding max index + interrupted temp; also <= cumulative always.
        immutable=Size(0,Counter(),{})
        for path,size in sizes.items():
            if path!='failure-index.json':immutable=immutable+size
        maxgen=max(gens,key=lambda x:x.bound(True))
        live=immutable+maxgen.times(2)+temporary+logsize
        # Final reservation includes final index, process/export/manifest and bounded failure.
        reserve=sizes['failure-index.json']+sizes['records/process.json']+sizes['records/export.json']+sizes['run-manifest.json']
        transaction=old+sizes['failure-index.json']+sizes['records/process.json']+sizes['records/export.json']+sizes['records/launch.json']+sizes['records/output-control.json']
        components={k:sz.table()for k,sz in sizes.items()}
        components.update(OLD_INDEX=old.table(),stdout_raw={'limit':16384},stderr_raw={'limit':16384},uncommitted_temp=temporary.table())
        return {'components':components,'index_generations':len(gens),'array_commits':commits,'index_generation_sum':sum(g.bound()for g in gens),'index_generation_upper_sum':sum(g.bound(True)for g in gens),'cumulative':written.table(),'live_sufficient':live.table(),'index_transaction':transaction.table(),'final_reservation':reserve.bound(True),'limits':{'live':16777216,'cumulative':16777216,'index':524288},'scope':'symbolic sufficient upper; generations follow after-each-array contract; no numerical or process validity claim'}

def regression_subject():
    case=next(c for c in F['cases']if c['case_id']=='FIT-stacked-tau1-f32-GL')
    return Graph(case,{'tag':'agree0','winners':(0,0),'fault':None}).audit()

if __name__=='__main__':
    subject=regression_subject()
    dump(ROOT/'model-first-proof.json',subject)
    print(json.dumps({k:v for k,v in subject.items()if k!='ledger'},indent=2))
