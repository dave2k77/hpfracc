"""Stdlib capture only; all writes confined beside this source."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')
def h(data):
    return hashlib.sha256(data).hexdigest()
def guard():
    baseline = json.loads(Path('/home/davianc/.hermes/cache/scratch/a2-ledger-continuation-20261112/baseline.json').read_text())
    result = {'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()}
    result['git_index_sha256'] = h((REPO / '.git/index').read_bytes())
    result['index_entries_sha256'] = h(subprocess.check_output(['git','ls-files','--stage'],cwd=REPO))
    for key in ('packet_before','immutable_history','numerical_inputs'):
        result[key] = {}
        for rel, expected in baseline[key].items():
            raw=(REPO/rel).read_bytes()
            actual={'bytes':len(raw),'sha256':h(raw)} if isinstance(expected,dict) else h(raw)
            result[key][rel]=actual
            assert actual==expected,(key,rel)
    for key in ('head','git_index_sha256','index_entries_sha256'):
        assert baseline[key]==result[key],key
    return result

def run(label, command):
    out=ROOT/label
    out.mkdir(exist_ok=False)
    snapshots=out/'pre_run_sources'
    snapshots.mkdir()
    sources={}
    for path in sorted(ROOT.glob('a2_*.py')):
        raw=path.read_bytes()
        (snapshots/path.name).write_bytes(raw)
        sources[path.name]={'bytes':len(raw),'sha256':h(raw)}
    dump(out/'pre_run.json',{'command':command,'cwd':str(REPO),'sources':sources,'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        try:
            completed=subprocess.run(command,cwd=REPO,stdout=stdout,stderr=stderr,timeout=240,check=False)
            exit_code=completed.returncode
            error=None
        except Exception as exc:
            exit_code=None
            error=repr(exc)
    dump(out/'process.json',{'command':command,'cwd':str(REPO),'started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit':exit_code,'launch_error':error,'streams':{n:{'bytes':(out/n).stat().st_size,'sha256':h((out/n).read_bytes())} for n in ('stdout.txt','stderr.txt')}})
    print(json.dumps({'label':label,'actual_exit':exit_code,'launch_error':error}))
    print((out/'stdout.txt').read_text()[-12000:])
    print((out/'stderr.txt').read_text()[-12000:])
    return exit_code

if __name__=='__main__':
    if sys.argv[1]=='guard':
        dump(ROOT/sys.argv[2],guard())
        print('project guards matched baseline: 9 packet,125 numerical,21 history,HEAD,index')
    else:
        run(sys.argv[1],sys.argv[2:])
