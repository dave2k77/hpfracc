"""Hash/size index with explicit non-self-referential capture exclusions."""
import json
from pathlib import Path
import sys
from a2_capture import ROOT,dump,h,guard

EXACT={'evidence-index.json','evidence-index-verification.json'}
DIRS={'index_build','index_verify'}

def files():
    output={}
    for path in sorted(ROOT.rglob('*')):
        rel=path.relative_to(ROOT)
        if rel.parts[0]in DIRS or str(rel)in EXACT:continue
        if path.is_symlink():raise AssertionError('unexpected symlink '+str(rel))
        if path.is_file():
            raw=path.read_bytes();output[str(rel)]={'bytes':len(raw),'sha256':h(raw)}
    return output

if __name__=='__main__':
    if sys.argv[1]=='build':
        index={'files':files(),'self_hash_excluded':True,'excluded_exact_files':sorted(EXACT),'excluded_capture_directories':sorted(DIRS),'scope':'frozen failed-author-attempt evidence; no independent approval'}
        dump(ROOT/'evidence-index.json',index)
        print(json.dumps({'indexed_files':len(index['files']),'indexed_bytes':sum(v['bytes']for v in index['files'].values()),'index_sha256':h((ROOT/'evidence-index.json').read_bytes()),'index_bytes':(ROOT/'evidence-index.json').stat().st_size}))
    else:
        index=json.loads((ROOT/'evidence-index.json').read_text());actual=files()
        assert actual==index['files'],'hash/size/member mismatch'
        before=json.loads((ROOT/'project-guards-before.json').read_text())
        after=json.loads((ROOT/'project-guards-after.json').read_text())
        assert before==after==guard(),'project protected inputs changed'
        proof=json.loads((ROOT/'proof.json').read_text())
        assert proof['outcome']=='BLOCKED_STOPPED_NO_BUDGET_PROPOSAL'
        assert proof['budget_proposal']is None and proof['complete_metadata_accounting_proved']is False
        check={'verified':True,'verified_files':len(actual),'verified_bytes':sum(v['bytes']for v in actual.values()),'exact_membership_verified':True,'index_sha256':h((ROOT/'evidence-index.json').read_bytes()),'index_bytes':(ROOT/'evidence-index.json').stat().st_size,'project_guards_verified':True,'proof_outcome':proof['outcome'],'exclusions':{'files':sorted(EXACT),'directories':sorted(DIRS)},'limitations':'Artifact integrity of a failed proof, not correctness, scientific acceptance or independent review.'}
        dump(ROOT/'evidence-index-verification.json',check)
        print(json.dumps(check,indent=2))
