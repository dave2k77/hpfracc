"""Read all normative definitions and usages; emit bounded review text."""
import json
from pathlib import Path
import tarfile
from a2_capture import ROOT,REPO,dump
A=REPO/'docs/validation/audits/a2-preparation-2026-11-11'
objects={p:json.loads((A/p).read_text()) for p in ('protocol.json','fixtures.json','comparison-policies.json','record-schemas.json','schema-control-fixtures.json','packet-manifest.json')}
lines=[]
def show(label,x):
    lines.append('\n### '+label+'\n'+json.dumps(x,indent=2))
for name,obj in objects.items():
    show(name+' top keys',{k:(len(v) if isinstance(v,(list,dict,str)) else v) for k,v in obj.items()})
s=objects['record-schemas.json']
for k,v in s.items():
    if k!='$defs': show('schema '+k,v)
for k,v in s['$defs'].items(): show('$defs/'+k,v)
f=objects['fixtures.json']
for k,v in f.items():
    if isinstance(v,list): show('fixtures '+k, v[:2])
    elif isinstance(v,dict): show('fixtures '+k,{key:(val if not isinstance(val,(list,dict)) else str(val)[:800]) for key,val in list(v.items())[:4]})
    else:show('fixtures '+k,v)
for k,v in objects['protocol.json'].items():
    if 'source' not in k and 'pin' not in k:show('protocol '+k,v)
show('comparison policies',objects['comparison-policies.json'])
w=objects['schema-control-fixtures.json']
for k,v in w.items():
    if isinstance(v,list):show('witness '+k,v[:1])
    else:show('witness '+k,v)
(ROOT/'discovery.txt').write_text('\n'.join(lines))
for name in ('metadata-budget-accounting-blocked-evidence.tar.gz','metadata-budget-accounting-assessment-proofs.tar.gz','final-preparation-correction-evidence.tar.gz','final-independent-review.tar.gz'):
    with tarfile.open(A/name) as t:
        members=t.getmembers()
        dump(ROOT/(name+'.members.json'),[{'name':m.name,'bytes':m.size,'isfile':m.isfile()} for m in members])
        targets=[m for m in members if m.isfile() and (m.name.endswith('account_models.py') or m.name.endswith('pre_edit_gate.py') or m.name.endswith('models-proof.json'))]
        for i,m in enumerate(targets):
            (ROOT/(name+f'.member{i}.txt')).write_bytes(t.extractfile(m).read())
print('read JSON completely; discovery lines',len(('\n'.join(lines)).splitlines()))
print('definitions',list(s['$defs']))
print('fixtures keys',list(f))
