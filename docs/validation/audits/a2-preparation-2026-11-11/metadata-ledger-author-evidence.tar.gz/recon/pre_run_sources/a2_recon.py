"""Bounded data reconnaissance, no worker import or execution."""
import json
from collections import Counter
from a2_capture import ROOT,REPO,dump
A=REPO/'docs/validation/audits/a2-preparation-2026-11-11'
f=json.loads((A/'fixtures.json').read_text());w=json.loads((A/'schema-control-fixtures.json').read_text());p=json.loads((A/'protocol.json').read_text())
out={'real_inventory':f['real_worker_inventory'],'counts':f['counts'],'resource_accounting':p['resource_accounting'],'candidates':list(f['candidates'].items())[:2],'future_candidate':[(k,v) for k,v in f['candidates'].items() if v.get('rhos_ref') is None][:1],'groups':dict(Counter(c['group'] for c in f['cases'])),'expected_variants':{},'mutations':[],'resource_controls':[],'sample_fit':next(c for c in f['cases'] if c['case_id']=='FIT-stacked-tau1-f32-GL'),'witness_summary':[]}
for c in f['cases']:
    out['expected_variants'].setdefault(json.dumps(c['expected'],sort_keys=True),c['case_id'])
    if c['mutations'] and c['case_id'].endswith('f32-GL'):out['mutations'].append({'case_id':c['case_id'],'mutations':c['mutations'],'expected':c['expected']})
    if c.get('resource_control') and c['case_id'].endswith('f32-GL'):out['resource_controls'].append({'case_id':c['case_id'],'resource_control':c['resource_control'],'expected':c['expected']})
for b in w['bundles']:
    out['witness_summary'].append({k:(list(v) if k=='artifacts' else v) for k,v in b.items() if k!='artifacts'}|{'artifacts':list(b['artifacts'])})
dump(ROOT/'recon.json',out)
print(json.dumps({k:v for k,v in out.items() if k not in ('sample_fit','expected_variants')},indent=2))
