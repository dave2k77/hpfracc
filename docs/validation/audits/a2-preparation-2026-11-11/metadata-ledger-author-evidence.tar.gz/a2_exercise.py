"""Exercise frozen symbolic draft; preserve all model failures without repair."""
from collections import Counter
import json
import sys
from a2_model import F,Graph,profile_specs,metrics,annotation,inventory,expand
from a2_capture import ROOT,dump
from a2_obligations import unresolved

start,stop=map(int,sys.argv[1:3])
plans=[(c,s)for c in F['cases']for s in profile_specs(c)]
checkrows=[]
output=ROOT/f'coverage-{start}-{stop}.jsonl'
if output.exists():raise FileExistsError(output)
with output.open('w')as stream:
    for number,(case,spec)in enumerate(plans[start:stop],start):
        q=expand(case);inv=inventory(case,q)
        row={'ordinal':number,'case_id':case['case_id'],'group':case['group'],'profile':spec,'inventories':{'slots':len(inv),'comparisons':len(case.get('required_working_comparisons',[])),'binding_checks':len(case.get('required_fit_identity_checks',[])),'full_observations':len(case.get('required_full_observations',[]))},'label':'CONDITIONAL SYMBOLIC DRAFT, not valid full export or numerical observation'}
        try:
            graph=Graph(case,spec);check=graph.audit();ledger=check['ledger']
            recordmetrics={k:{'nodes':metrics(v)[1],'depth':metrics(v)[2],'bytes_lower':metrics(v)[0].bound(),'bytes_upper':metrics(v)[0].bound(True)}for k,v in graph.records.items()}
            row.update(record_count=len(graph.records),payload_count=len(graph.payloads),links=len(graph.links),structural_missing_links=check['missing_links'],slot_dispositions=dict(Counter(r['status']+':'+r['reason']for r in graph.rows)),record_node_max=max(v['nodes']for v in recordmetrics.values()),record_depth_max=max(v['depth']for v in recordmetrics.values()),index_transaction=ledger['index_transaction'],cumulative_lower=ledger['cumulative']['lower'],cumulative_upper=ledger['cumulative']['upper'],live_sufficient_lower=ledger['live_sufficient']['lower'],live_sufficient_upper=ledger['live_sufficient']['upper'],index_generations=ledger['index_generations'],final_reservation=ledger['final_reservation'],open_semantic_obligations=len(unresolved(graph)),model_structural_exit=0)
            # The full symbolic table is retained once for every record type of the representative,
            # not mistaken for coverage of other profiles; coverage rows retain their own computed maxima.
            if case['case_id']=='FIT-stacked-tau1-f32-GL'and spec['winners']==(0,0)and spec['fault']is None:
                dump(ROOT/'representative-symbolic-records.json',{'label':row['label'],'records':annotation(graph.records),'initial_index':annotation(graph.old)})
                dump(ROOT/'representative-record-sizes.json',recordmetrics)
                dump(ROOT/'representative-link-table.json',graph.links)
                dump(ROOT/'representative-ledger.json',ledger)
                dump(ROOT/'representative-open-obligations.json',unresolved(graph))
        except Exception as exc:
            row.update(model_structural_exit=1,error_type=type(exc).__name__,error=str(exc))
        # The exhaustive coverage table does not repeat thousands of affine terms per index.
        if isinstance(row.get('index_transaction'),dict):
            tr=row['index_transaction'];row['index_transaction']={k:tr[k]for k in ('lower','upper')}
        stream.write(json.dumps(row,sort_keys=True)+'\n');stream.flush()
        checkrows.append(row)
print(json.dumps({'range':[start,stop],'planned_profiles':len(plans),'exercised':len(checkrows),'model_structural_successes':sum(r['model_structural_exit']==0 for r in checkrows),'model_structural_errors':sum(r['model_structural_exit']!=0 for r in checkrows),'zero_open_semantics':sum(r.get('open_semantic_obligations')==0 for r in checkrows),'table':output.name}))
