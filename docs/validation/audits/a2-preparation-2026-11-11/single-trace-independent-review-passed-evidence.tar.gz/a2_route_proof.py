"""Independent re-signing and copied-source mutation for ONE frozen route gap.

Only static N=3 provided data. No operational/parser/worker implementation.
"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json

from a2_independent_proof import validate

HERE = Path(__file__).resolve().parent
GUARD = "        need(binding['binding_id'] == 'host-' + suffix, 'binding path-to-ID')\n"

def enc(v):
    return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')

def sha(b):
    return hashlib.sha256(b).hexdigest()

def load(p):
    return json.loads(p.read_bytes())

def save(name, v):
    (HERE / name).write_text(json.dumps(v, indent=2, sort_keys=True) + '\n')

def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

def bodies(t):
    return {p: enc(v) for p, v in t['records'].items()} | {p: bytes.fromhex(v) for p, v in t['logs'].items()}

def state_ledger(t):
    raw = bodies(t) | {'INITIAL_INDEX': enc(t['initial_index'])}
    state, terms, snapshots = {}, {}, {}
    cumulative = peak = 0
    for e in t['events']:
        if e['op'] == 'write':
            name = e['body']
            assert e['path'] not in state and name not in terms
            snapshots[name] = {'live_bytes': sum(map(len, state.values())), 'cumulative_written_bytes': cumulative}
            state[e['path']] = raw[name]
            terms[name] = len(raw[name])
            cumulative += len(raw[name])
        else:
            assert state[e['target']] == raw['INITIAL_INDEX']
            state[e['target']] = state.pop(e['source'])
        peak = max(peak, sum(map(len, state.values())))
    assert state == bodies(t) and set(terms) == set(raw)
    tx = ['INITIAL_INDEX', 'failure-index.json', 'records/process.json', 'records/export.json', 'records/output-control.json']
    return {'terms': terms, 'cumulative_written_bytes': cumulative, 'final_live_bytes': sum(map(len, state.values())),
            'peak_live_bytes': peak, 'index_transaction_bytes': sum(len(raw[p]) for p in tx),
            'temporary_bytes_charged': len(raw['failure-index.json']), 'old_index_bytes_charged': len(raw['INITIAL_INDEX'])}, snapshots

def independent_resign(base, suffix, replacement):
    # Start from preserved positive JSON, not a.make_trace(mutate).
    t = copy.deepcopy(base)
    r = t['records']
    path = 'records/binding-host-' + suffix + '.json'
    r[path]['binding_id'] = replacement
    for b in r.values():
        if b['record_type'] == 'producer_binding':
            for ret in b['returned']:
                r['arrays/' + ret['slot_id'] + '.json']['producer_binding_sha256'] = sha(enc(b))
    result = r['result.json']
    for s in result['shared_slots']:
        s.update(copy.deepcopy(r['arrays/' + s['slot_id'] + '.json']))
    for a in result['assessments']:
        for s in a['slots']:
            s.update(copy.deepcopy(r['arrays/' + s['slot_id'] + '.json']))
    index = r['failure-index.json']
    for row in index['slots']:
        p = 'arrays/' + row['slot_id'] + '.json'
        raw = enc(r[p])
        row['artifact'] = {'path': p, 'bytes': len(raw), 'sha256': sha(raw)}
    state = {}
    cumulative = 0
    for e in t['events']:
        if e['op'] == 'write':
            body = e['body']
            if body == 'result.json':
                result['evidence_bytes'] = sum(map(len, state.values()))
            if body in ('INITIAL_INDEX', 'failure-index.json'):
                record = t['initial_index'] if body == 'INITIAL_INDEX' else index
                record['bytes_accounting'] = {'live_bytes': sum(map(len, state.values())),
                    'cumulative_written_bytes': cumulative,
                    'reserved_final_transaction_bytes': index['bytes_accounting']['reserved_final_transaction_bytes']}
            if body == 'records/export.json':
                r[body].update(failure_index_sha256=sha(enc(index)), failure_index_bytes=len(enc(index)),
                               process_sha256=sha(enc(r['records/process.json'])))
            if body == 'run-manifest.json':
                r[body]['files'] = [{'path': p, 'bytes': len(raw), 'sha256': sha(raw)}
                                   for p, raw in bodies(t).items() if p != body]
            raw = enc(t['initial_index']) if body == 'INITIAL_INDEX' else bodies(t)[body]
            state[e['path']] = raw
            cumulative += len(raw)
        else:
            state[e['target']] = state.pop(e['source'])
    t['ledger'], _ = state_ledger(t)
    return t

def preconditions(t, base, suffix, wrong):
    r = t['records']
    path = 'records/binding-host-' + suffix + '.json'
    expected = copy.deepcopy(base['records'][path])
    expected['binding_id'] = wrong
    assert r[path] == expected
    for p, value in r.items():
        validate(value, schema, schema['$defs'])
        if value['record_type'] == 'producer_binding' and p != path:
            assert value == base['records'][p]
        if value['record_type'] == 'slot':
            original = base['records'][p]
            for field in ('slot_id', 'case_id', 'candidate_index', 'candidate_id', 'mode', 'branch', 'quantity', 'exact_array'):
                assert value[field] == original[field]
    for b in r.values():
        if b['record_type'] == 'producer_binding':
            for ret in b['returned']:
                s = r['arrays/' + ret['slot_id'] + '.json']
                assert s['producer_binding_sha256'] == sha(enc(b))
                assert ret['descriptor']['payload_sha256'] == sha(enc(s['exact_array']))
    inline = r['result.json']['shared_slots'] + [s for a in r['result.json']['assessments'] for s in a['slots']]
    assert len(inline) == 22
    for s in inline:
        assert s == r['arrays/' + s['slot_id'] + '.json']
    for row in r['failure-index.json']['slots']:
        p = 'arrays/' + row['slot_id'] + '.json'
        assert row['artifact'] == {'path': p, 'bytes': len(enc(r[p])), 'sha256': sha(enc(r[p]))}
    assert r['failure-index.json']['process'] == r['records/process.json']
    assert r['records/export.json']['process_sha256'] == sha(enc(r['records/process.json']))
    assert r['records/export.json']['failure_index_sha256'] == sha(enc(r['failure-index.json']))
    assert r['records/export.json']['failure_index_bytes'] == len(enc(r['failure-index.json']))
    raw = bodies(t)
    assert {x['path']: (x['bytes'], x['sha256']) for x in r['run-manifest.json']['files']} == {
        p: (len(b), sha(b)) for p, b in raw.items() if p != 'run-manifest.json'}
    ledger, snapshots = state_ledger(t)
    assert ledger == t['ledger']
    assert r['result.json']['evidence_bytes'] == snapshots['result.json']['live_bytes']
    for name, record in [('INITIAL_INDEX', t['initial_index']), ('failure-index.json', r['failure-index.json'])]:
        assert {k: record['bytes_accounting'][k] for k in snapshots[name]} == snapshots[name]
    # Exact rejected checker, and also its exact one-line-deletion mutant,
    # must reach end-to-end success. This rules out *any* masking rejection.
    assert old.verify_trace(t) == mutant.verify_trace(t)
    fixed.check_completion(r)
    fixed.check_fixed_exact_payloads(r)
    fixed.check_lifecycle(t)
    assert fixed.replay_ledger(t) == ledger

old = module(HERE / 'rejected/a2_trace.py', 'rejected_fixed')
fixed = module(HERE / 'candidate/a2_trace.py', 'corrected_fixed')
schema = load(HERE / 'candidate/record-schemas.json')
base = load(HERE / 'candidate/trace.json')
new_source = (HERE / 'candidate/a2_trace.py').read_text()
assert new_source.count(GUARD) == 1
removed = new_source.replace(GUARD, '', 1).encode()
assert removed == (HERE / 'rejected/a2_trace.py').read_bytes()
mutation_dir = HERE / 'guard-removed'
mutation_dir.mkdir()
(mutation_dir / 'a2_trace.py').write_bytes(removed)
for name in ['authority.json', 'record-schemas.json', 'protocol.json']:
    (mutation_dir / name).write_bytes((HERE / 'candidate' / name).read_bytes())
mutant = module(mutation_dir / 'a2_trace.py', 'guard_removed_fixed')
assert enc(fixed.make_trace()) == enc(old.make_trace()) == enc(base)
assert bodies(fixed.make_trace()) == bodies(old.make_trace()) == bodies(base)
assert fixed.verify_trace(base) == old.verify_trace(base)
results = []
for kind in ['duplicate', 'fresh']:
    for suffix in ['X', '0', '1']:
        wrong = ('host-0' if suffix == '1' else 'host-1') if kind == 'duplicate' else 'host-fresh'
        t = independent_resign(base, suffix, wrong)
        original_ids = [v['binding_id'] for v in base['records'].values() if v['record_type'] == 'producer_binding']
        assert (wrong in original_ids) is (kind == 'duplicate')
        preconditions(t, base, suffix, wrong)
        name = kind + '-' + suffix + '.json'
        save(name, t)
        try:
            fixed.verify_trace(t)
        except ValueError as error:
            assert str(error) == 'binding path-to-ID', str(error)
            reason = str(error)
        else:
            raise AssertionError('fully re-signed frozen route violation accepted')
        if kind == 'duplicate' and suffix == '0':
            minimal = load(HERE / 'original-minimal-counterexample.json')
            assert enc(t) == enc(minimal)
            assert fixed.replay_ledger(minimal) == minimal['ledger']
        results.append({'kind': kind, 'suffix': suffix, 'replacement': wrong, 'canonical_mutant_sha256': sha(enc(t)),
            'fixture': name, 'schema_and_all_resigned_links_and_payloads_checked': True,
            'exact_rejected_source_accepts': True, 'guard_removed_source_accepts': True,
            'corrected_rejects_reason': reason, 'same_as_original_minimal_counterexample': kind == 'duplicate' and suffix == '0'})
report = {'fixed_cases': 1, 'independent_route_negatives': len(results), 'results': results,
          'copied_mutation_is_exact_rejected_source': True, 'guard_removed_sha256': sha(removed),
          'canonical_positive_trace': {'bytes': len(enc(base)), 'sha256': sha(enc(base))},
          'all_38_positive_artifact_bytes_unchanged': bodies(fixed.make_trace()) == bodies(old.make_trace()),
          'positive_ledger': base['ledger'], 'implementation_authorized': False,
          'protocol_freeze_authorized': False, 'a2_acceptance_passed': False, 'broader_accounting_proved': False,
          'scope': 'Necessity/sufficiency for the reported fixed path/ID gap only, not a general validator proof'}
save('route-proof.json', report)
print(json.dumps(report, indent=2, sort_keys=True))
