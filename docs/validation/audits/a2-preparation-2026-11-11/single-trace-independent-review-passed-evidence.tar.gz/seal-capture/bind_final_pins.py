"""Read back sealed evidence and bind the actual completed seal receipt."""
from pathlib import Path
import hashlib
import json
import os
import stat

W = Path('/home/davianc/.hermes/cache/scratch/a2-routing-independent-review-Lnvtx4VN')

def pin(p, kind='regular_file'):
    mode = p.lstat().st_mode
    if kind == 'symlink_readlink_utf8':
        assert stat.S_ISLNK(mode)
        raw = os.readlink(p).encode('utf-8')
    else:
        assert stat.S_ISREG(mode)
        raw = p.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def load(p):
    return json.loads(p.read_bytes())

index = load(W / 'proof-index.json')
verification = load(W / 'proof-index-verification.json')
assert pin(W / 'proof-index.json')['sha256'] == verification['index_sha256']
assert verification['verified'] is True
count = total = 0
for name, expected in index['files'].items():
    assert pin(W / name, expected['kind']) == {k: expected[k] for k in ('bytes', 'sha256')}
    count += 1
    total += expected['bytes']
assert count == verification['files_verified'] == index['files_count']
assert total == verification['bytes_verified'] == index['total_indexed_bytes']
assessment = load(W / 'assessment.json')
assert assessment['passed'] and assessment['logic_errors'] == assessment['security_concerns'] == []
seal_plan = load(W / 'seal-capture/plan.json')
seal = load(W / 'seal-capture/process.json')
assert seal['actual_child_exit'] == 0 and seal['source_unchanged'] is True
assert seal['command'] == seal_plan['command']
for n, expected in seal_plan['executed_source_snapshots'].items():
    assert pin(W / 'seal-capture/before' / n) == expected
for name in ['stdout', 'stderr']:
    assert pin(W / 'seal-capture' / (name + '.raw')) == seal[name]
seal_stdout = json.loads((W / 'seal-capture/stdout.raw').read_bytes())
assert seal_stdout == verification
final = {
    'passed': True, 'security_concerns': [], 'logic_errors': [],
    'review_directory': str(W), 'index_sha256': verification['index_sha256'],
    'proof_index': pin(W / 'proof-index.json'),
    'proof_index_verification': pin(W / 'proof-index-verification.json'),
    'assessment_json': pin(W / 'assessment.json'), 'assessment_markdown': pin(W / 'assessment.md'),
    'proof_files_verified': count, 'proof_bytes_verified': total, 'kind_counts': verification['kind_counts'],
    'source_manifest_sha256': verification['source_manifest_sha256'],
    'seal_actual_child_exit': seal['actual_child_exit'],
    'seal_capture_pins': {name: pin(W / 'seal-capture' / name) for name in
        ['plan.json', 'process.json', 'stdout.raw', 'stderr.raw', 'before/seal_review.py', 'before/review_pins.py']},
    'final_binding_executable': {'path': str(Path(__file__).resolve()), **pin(Path(__file__).resolve())},
    'exclusions': 'Index excludes its own final index/verification/pins, UV cache and seal-capture/. The completed seal capture and this binding executable are separately pinned here; final binding raw output/receipt is excluded to avoid a self-referential capture hash. All substantive assessment, tests, independent proofs and their raw outputs are indexed.',
    'implementation_authorized': False, 'protocol_freeze_authorized': False,
    'a2_acceptance_passed': False, 'broader_accounting_proved': False,
    'parent_tasks_remain_open': True, 'parent_readback_and_archive_still_required': True,
}
for flag in ['implementation_authorized', 'protocol_freeze_authorized', 'a2_acceptance_passed', 'broader_accounting_proved']:
    assert final[flag] is False
assert not (W / 'final-pins.json').exists()
(W / 'final-pins.json').write_text(json.dumps(final, indent=2, sort_keys=True) + '\n')
print(json.dumps(final, indent=2, sort_keys=True))
