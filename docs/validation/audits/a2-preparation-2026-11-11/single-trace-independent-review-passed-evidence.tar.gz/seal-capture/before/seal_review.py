"""Seal all reviewer proof files, without following symbolic links or self-hashing."""
from pathlib import Path
import hashlib
import json
import os
import stat

from review_pins import check

W = Path('/home/davianc/.hermes/cache/scratch/a2-routing-independent-review-Lnvtx4VN')
EXCLUDED_FILES = {'proof-index.json', 'proof-index-verification.json', 'final-pins.json'}
EXCLUDED_DIRS = {'uv-cache', 'seal-capture'}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def data(p, kind):
    mode = p.lstat().st_mode
    if kind == 'symlink_readlink_utf8':
        assert stat.S_ISLNK(mode)
        return os.readlink(p).encode('utf-8')
    assert stat.S_ISREG(mode), str(p)
    return p.read_bytes()

def pin(p, kind='regular_file'):
    b = data(p, kind)
    return {'kind': kind, 'bytes': len(b), 'sha256': sha(b)}

def save(path, v):
    assert not path.exists()
    path.write_text(json.dumps(v, indent=2, sort_keys=True) + '\n')

protected = check()
assert protected == json.loads((W / 'pins-start/before/pins.json').read_bytes())
assert protected == json.loads((W / 'pins-final/before/pins.json').read_bytes())
assessment = json.loads((W / 'assessment.json').read_bytes())
assert assessment['passed'] is True and assessment['security_concerns'] == assessment['logic_errors'] == []
for flag in ['implementation_authorized', 'protocol_freeze_authorized', 'a2_acceptance_passed', 'broader_accounting_proved']:
    assert assessment[flag] is False
files = {}
for directory, dirnames, filenames in os.walk(W, followlinks=False):
    base = Path(directory)
    if base == W:
        dirnames[:] = [name for name in dirnames if name not in EXCLUDED_DIRS]
    for name in list(dirnames):
        path = base / name
        if path.is_symlink():
            files[path.relative_to(W).as_posix()] = pin(path, 'symlink_readlink_utf8')
            dirnames.remove(name)
    for name in filenames:
        path = base / name
        relative = path.relative_to(W).as_posix()
        if relative in EXCLUDED_FILES:
            continue
        kind = 'symlink_readlink_utf8' if path.is_symlink() else 'regular_file'
        files[relative] = pin(path, kind)
files = dict(sorted(files.items()))
assert 'assessment.json' in files and 'assessment.md' in files
index = {'scope': 'Only this unique independent-review scratch proof tree; static one-case re-review, not numerical/operational approval',
         'review_manifest_sha256': protected['manifest']['sha256'],
         'excluded_exact_files': sorted(EXCLUDED_FILES), 'excluded_top_level_directories': sorted(EXCLUDED_DIRS),
         'exclusions_reason': 'UV cache is not evidence. The final seal execution capture is bound separately by final-pins.json after actual child completion. Index/verification/final-pins avoid self-referential hashing.',
         'files': files, 'files_count': len(files), 'total_indexed_bytes': sum(x['bytes'] for x in files.values()),
         'kind_counts': {kind: sum(x['kind'] == kind for x in files.values()) for kind in sorted({x['kind'] for x in files.values()})},
         'implementation_authorized': False, 'protocol_freeze_authorized': False,
         'a2_acceptance_passed': False, 'broader_accounting_proved': False}
save(W / 'proof-index.json', index)
raw_index = (W / 'proof-index.json').read_bytes()
readback = json.loads(raw_index)
verified_bytes = 0
for name, expected in readback['files'].items():
    assert pin(W / name, expected['kind']) == expected, name
    verified_bytes += expected['bytes']
assert len(readback['files']) == index['files_count']
assert verified_bytes == index['total_indexed_bytes']
verification = {'verified': True, 'index_sha256': sha(raw_index), 'files_verified': len(files),
                'bytes_verified': verified_bytes, 'kind_counts': index['kind_counts'],
                'assessment_included_in_index': True, 'declared_protected_state_reverified_at_seal': True,
                'source_manifest_sha256': protected['manifest']['sha256'],
                'implementation_authorized': False, 'protocol_freeze_authorized': False,
                'a2_acceptance_passed': False, 'broader_accounting_proved': False}
save(W / 'proof-index-verification.json', verification)
print(json.dumps(verification, indent=2, sort_keys=True))
