"""Assemble a scoped independent verdict from the actual fresh proof outputs."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
W = Path('/home/davianc/.hermes/cache/scratch/a2-routing-independent-review-Lnvtx4VN')

def load(p):
    return json.loads(p.read_bytes())

def enc(v):
    return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')

def pin(p):
    assert not p.is_symlink()
    raw = p.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

start = load(W / 'pins-start/before/pins.json')
end = load(W / 'pins-final/before/pins.json')
assert start == end
positive = load(W / 'independent-positive/before/independent-positive-proof.json')
route = load(W / 'independent-resigned-route-proof/before/route-proof.json')
minimal = load(W / 'preserved-minimal-direct/before/preserved-minimal-proof.json')
receipts = load(W / 'receipt-check/before/receipt-verification.json')
portable = load(W / 'portable-positive/before/replay-report.json')
old_trace = load(W / 'inputs/rejected/trace.json')
new_trace = load(W / 'inputs/candidate/trace.json')
assert enc(old_trace) == enc(new_trace)
raw = {p: enc(v) for p, v in new_trace['records'].items()} | {p: bytes.fromhex(v) for p, v in new_trace['logs'].items()}
materialized = W / 'independent-positive/before/materialized'
actual = {p.relative_to(materialized).as_posix(): p.read_bytes() for p in materialized.rglob('*') if p.is_file()}
assert actual == raw
assert positive['ledger'] == route['positive_ledger'] == new_trace['ledger'] == portable['ledger']
assert portable['canonical_positive_trace'] == route['canonical_positive_trace']
assert route['independent_route_negatives'] == 6
assert all(r['corrected_rejects_reason'] == 'binding path-to-ID' and r['exact_rejected_source_accepts'] and r['guard_removed_source_accepts'] for r in route['results'])
assert minimal['corrected_rejects_exact_reason'] == 'binding path-to-ID' and minimal['premature_schema_or_hash_rejection'] is False
assert route['all_38_positive_artifact_bytes_unchanged'] and route['copied_mutation_is_exact_rejected_source']
for phase, expected in [('pins-start', 0), ('reproduced-26-green', 0), ('reproduced-26-red', 1),
                        ('isolated-26-green', 0), ('portable-positive', 0), ('missing-artifact', 1),
                        ('independent-positive', 0), ('prior-23-negatives-corrected', 0),
                        ('independent-resigned-route-proof', 0), ('preserved-minimal-direct', 0),
                        ('receipt-check', 0), ('scoped-new-files-lint', 0), ('pins-final', 0)]:
    process = load(W / phase / 'process.json')
    assert process['actual_child_exit'] == expected and process['source_unchanged']
    assert process['stdout'] == pin(W / phase / 'stdout.raw')
    assert process['stderr'] == pin(W / phase / 'stderr.raw')
paths = {
    'assessment_json': str(W / 'assessment.json'),
    'assessment_markdown': str(W / 'assessment.md'),
    'proof_index': str(W / 'proof-index.json'),
    'proof_index_verification': str(W / 'proof-index-verification.json'),
    'final_pins': str(W / 'final-pins.json'),
    'protected_before': str(W / 'pins-start/before/pins.json'),
    'protected_after': str(W / 'pins-final/before/pins.json'),
    'copy_receipts': str(W / 'copy-receipts.json'),
    'route_executable': str(W / 'independent-resigned-route-proof/before/a2_route_proof.py'),
    'route_proof': str(W / 'independent-resigned-route-proof/before/route-proof.json'),
    'preserved_minimal_executable': str(W / 'preserved-minimal-direct/before/preserved_minimal_proof.py'),
    'preserved_minimal_proof': str(W / 'preserved-minimal-direct/before/preserved-minimal-proof.json'),
    'independent_positive_executable': str(W / 'independent-positive/before/a2_independent_proof.py'),
    'independent_positive_proof': str(W / 'independent-positive/before/independent-positive-proof.json'),
    'exact_arithmetic': str(W / 'independent-positive/before/independent-exact-arithmetic.json'),
    'record_table': str(W / 'independent-positive/before/independent-record-table.json'),
    'physical_materialization_timeline': str(W / 'independent-positive/before/materialization-timeline.json'),
    'physical_materialized_files': str(materialized),
    'receipts_executable': str(W / 'receipt-check/before/review_receipts.py'),
    'receipt_verification': str(W / 'receipt-check/before/receipt-verification.json'),
    'green_26': str(W / 'reproduced-26-green'),
    'red_26': str(W / 'reproduced-26-red'),
    'isolated_26': str(W / 'isolated-26-green'),
    'prior_negatives_23_now_green': str(W / 'prior-23-negatives-corrected'),
    'portable_positive': str(W / 'portable-positive'),
    'missing_artifact': str(W / 'missing-artifact'),
    'scoped_lint': str(W / 'scoped-new-files-lint'),
    'raw_output_convention': 'Every listed execution directory contains plan.json, process.json, stdout.raw and stderr.raw; pytest executions also contain raw.xml.',
}
counts = {k: positive[k] for k in ['records', 'slots', 'files', 'journal_events', 'writes', 'index_generations', 'max_record_nodes', 'max_record_depth']}
counts.update(fixed_cases=1, samples=3, supplied_synthetic_candidates=2, raw_logs=len(new_trace['logs']),
              corrected_tests=receipts['reviewer_new_executions']['reproduced-26-green']['selection']['counts'],
              rejected_source_tests=receipts['reviewer_new_executions']['reproduced-26-red']['selection']['counts'],
              isolated_tests=receipts['reviewer_new_executions']['isolated-26-green']['selection']['counts'],
              prior_review_negatives_now_green=receipts['reviewer_new_executions']['prior-23-negatives-corrected']['selection']['counts'],
              independent_resigned_route_controls=6, preserved_original_minimal_replay=1,
              route_controls_are_same_one_case_not_six_cases=True,
              no_aggregate_test_total_over_repeats_or_control_families=True,
              protected_repo_union=start['repo_union'], protected_numeric=start['numerical'],
              protected_packet=start['packet'], protected_history=start['history'],
              original_author_index=start['author'], original_rejected_review_index=start['prior_review'],
              corrector_index=start['corrector'],
              original_failed_archive_members=[x['members'] for x in start['archives'][:2]],
              correction_archive_members=start['archives'][2]['members'])
bytes_ = {k: v for k, v in positive['ledger'].items() if k != 'terms'}
bytes_.update(run_manifest_own_length=len(raw['run-manifest.json']), stdout=len(raw['logs/stdout.bin']),
              stderr=len(raw['logs/stderr.bin']), export=len(raw['records/export.json']),
              process=len(raw['records/process.json']), output_control=len(raw['records/output-control.json']),
              canonical_positive_container=route['canonical_positive_trace'],
              pretty_preserved_positive_file=pin(W / 'inputs/candidate/trace.json'),
              canonical_container_is_not_one_workers_export=True)
assessment = {
    'passed': True, 'security_concerns': [], 'logic_errors': [],
    'summary': 'Scoped PASS: the one-line frozen path/ID guard closes FIXED-TRACE-ROUTING-01; all 26 tests pass, six independently re-signed route violations reject for that exact relation, and the one positive trace, all 38 artifact bodies and finite byte ledger are unchanged.',
    'implementation_authorized': False, 'protocol_freeze_authorized': False,
    'a2_acceptance_passed': False, 'broader_accounting_proved': False,
    'parent_tasks_remain_open': True, 'remaining_correction_cycles': 0,
    'verified_counts': counts, 'verified_bytes': bytes_, 'proof_paths': paths,
    'reviewed_pins': {
        'manifest': start['manifest'], 'head': start['head'], 'git_index_sha256': start['git_index_sha256'],
        'git_stage_newline_sha256': start['git_stage_newline_sha256'],
        'rejected_source': pin(W / 'inputs/rejected/a2_trace.py'),
        'corrected_source': pin(W / 'inputs/candidate/a2_trace.py'),
        'original_author_index_sha256': 'be5a1ba950860abbf66b849fdc5a057c75b6bafbe064ea21635e26a60633aa07',
        'original_rejected_review_index_sha256': 'ea1cf140c393c5426e328833bff087ba52c37b0fcf297fd9ae83dd75ffe3d4d9',
        'original_rejected_assessment_sha256': '2c52c108aa98c89cdb882e4194c75898fc4d3f7f4bd474dc5cc1a7b04fc4055a',
        'corrector_index_sha256': '09ab4947385b7f1c7ed59a6f8c474804af9ea3313fd2439415f07de45f8d8681',
        'correction_archive_sha256': start['archives'][2]['archive_pin']['sha256'],
    },
    'verified_scope': {
        'target': 'ONE STATIC/HYPOTHETICAL selected-REF-PASS-f64-GL, N=3, two supplied synthetic candidates, 22 exact slots',
        'fixed_route_authority': 'record-schemas.json x-artifact-routing and schema-control-contract.md:233-240',
        'source_delta': 'Exactly one guard line in the existing X/0/1 binding loop; no existing test, authority, schema, protocol, or positive trace byte changed.',
        'necessity_sufficiency': 'Removing only this line in a reviewer copy is byte-identical to the rejected source, accepts all six independently resigned route mutants, and preserves positive acceptance. Corrected source rejects all six with exactly binding path-to-ID.',
        'positive_semantics': 'Inspected and freshly executed the verified prior independent proof (no audit-module import): authoritative frozen fixtures/request construction, all record schemas/routes, source/config/mode/occurrence links, shapes and copies, completion/selection, phase arithmetic/publication DAG, all 22 Fraction payload identities, and physical write/replace/stat replay.',
        'original_minimal': minimal,
        'actual_packet_sha256': positive['actual_packet_sha256'],
        'hypothetical_packet_digest': positive['hypothetical_packet_digest'],
        'actual_packet_digest_is_hypothetical_digest': False,
        'all_38_artifact_bytes_and_ledger_unchanged': True,
        'protected_source_index_and_declared_immutable_subset_unchanged': True,
        'entire_git_status_or_directory_membership_asserted_unchanged': False,
        'scope_expanded_or_caps_schema_math_tolerance_domain_dependencies_core_api_changed': False,
        'new_repository_writes_by_reviewer': False,
        'actual_worker_security_counter_or_scientific_observations_proved': False,
        'general_reference_worker_fitter_selector_or_operational_parser_implemented': False,
        'universal_resource_admission_eight_RED_blocker': 'Remains open; not re-run, relabelled or resolved by this finite proof.',
        'isolation': 'Copied source/data with portable Python open-hook; not an OS sandbox/security attestation.',
        'lint': 'Fresh E4/E7/E9/F check of only the corrector new portable helper and six-parameter test; exit 0. No whole-repository lint/docs/full/GPU claim.',
    },
    'capture_limits': {
        'corrector_audit_runs': 'Actual commands execute before/ source snapshots, whose pins/raw exits/XML identity sets were independently checked; RED is six DID NOT RAISE behavioral failures, not collection errors.',
        'first_two_guard_attempts': receipts['setup_capture_limits'],
        'original_author_helper': receipts['original_author_capture_limitation'],
        'historical_process_receipts': 'Preserved normalized subprocess receipts plus independently reproduced outcomes, not newly authenticated historical OS observations.',
        'archived_mutable_status_members': 'Two historical parent status bodies authenticated by the frozen rejected-author archive, not compared to today\'s explicitly mutable status docs.',
        'symlinks': 'All three corrector symlinks verified as readlink UTF-8, not followed/recreated; archive regular-data representation map verified.',
    },
    'suggestions': [
        'Parent must read back and archive this verdict, proof index and final pins before claiming this scoped review passed.',
        'Keep original rejection and setup/capture limits intact; this success does not close A2, authorize implementation/freeze, or prove broader accounting.',
        'No further correction cycle is available; preserve and stop/ask the owner if subsequent protected-input or acceptance checks fail.',
    ],
    'files_created': 'Only this new unique reviewer scratch tree; no repository or other evidence tree changed.',
    'proof_index_binding': 'proof-index.json and final-pins.json are created after this assessment; no self-referential index hash is embedded here.',
}
assert assessment['passed'] and not assessment['security_concerns'] and not assessment['logic_errors']
for key in ['implementation_authorized', 'protocol_freeze_authorized', 'a2_acceptance_passed', 'broader_accounting_proved']:
    assert assessment[key] is False
for filename, data in [('assessment.json', json.dumps(assessment, indent=2, sort_keys=True) + '\n')]:
    target = W / filename
    assert not target.exists()
    target.write_text(data)
md = f"""# Independent corrected fixed-trace re-review — scoped PASS

- **No security concerns or logic errors found in the approved scope.**
- Exactly ONE `STATIC/HYPOTHETICAL selected-REF-PASS-f64-GL` witness: N=3,
  two provided synthetic candidates and all 22 exact slots. No repair performed.
- `implementation_authorized: false`, `protocol_freeze_authorized: false`,
  `a2_acceptance_passed: false`, `broader_accounting_proved: false`.
  Parent tasks and the universal/resource-admission blocker remain open.

## Routing finding closed, original rejection preserved

The sole source delta is the 78-byte guard line in the existing X/0/1 loop:
`need(binding['binding_id'] == 'host-' + suffix, 'binding path-to-ID')`.
This enforces the frozen `records/binding-{{binding_id}}.json` relation rather
than adding an ID-uniqueness requirement or broadening the route allowlist.
All original tests, authority/schema/protocol and positive trace bytes match.

The independent executable starts with preserved positive JSON, mutates each
existing shared/candidate binding to a duplicate **and** fresh wrong ID, and
independently re-signs bindings, standalone/inline slots, index, export, manifest
and byte snapshots. All six full-schema/link/payload/ledger controls pass the
exact rejected checker and its one-line-deletion mutant. Each is rejected by the
corrected checker with exactly `binding path-to-ID`. No hash/schema masking.
The direct preserved original minimal counterexample (SHA
`{minimal['preserved_file_sha256']}`) also now rejects for that exact relation.
Removing only the guard yields byte-identical rejected source. Thus the line is
necessary/sufficient for this reported fixed-route gap, not a universal verifier
or operational security proof. Original rejected verdict remains rejected.

## Actual executions and count boundaries

| Execution | Actual child exit | Parsed outcome |
|---|---:|---|
| Corrected original + six route parameters | 0 | 26 passed, 0 errors |
| Exact rejected source, same selection | 1 | 20 passed, 6 DID NOT RAISE, 0 errors |
| Isolated corrected source/data | 0 | Same 26 passed |
| Prior independent negative selection, corrected source | 0 | 23 passed |
| Portable positive materialization | 0 | Preserved/rebuilt bytes and ledger equal |
| Missing preserved trace control | 1 | Required-artifact FileNotFoundError |
| Independent authoritative positive proof | 0 | 36 records / 22 exact slots / 38 physical artifacts |
| Independent resigned route + guard-deletion proof | 0 | Six expected route rejections, old/mutant acceptance |
| Direct preserved minimal-counterexample proof | 0 | Exact route rejection |
| Historical receipt/snapshot checks | 0 | Corrector RED/GREEN/isolated/missing and parent readbacks agree |
| Scoped new-helper/test lint E4/E7/E9/F | 0 | Passed, not whole-repository lint |
| Protected pins before / after | 0 / 0 | Exact declared immutable state equal |

These are repeated verification selections/control families, **not summed into
an inflated test, case or numerical-suite total**. The six route controls are
mutations of one case, not six scientific cases. Commands, source snapshots,
raw stdout/stderr, actual child exits and pytest XML are retained per execution.

## Finite positive proof and byte accounting

The inspected, hash-verified prior independent proof was copied and freshly
executed against actual frozen fixture bodies. It independently constructs the
request, validates all schemas/routes/shapes, links/inline copies/completion,
qualification and fixed winner, phase arithmetic and publication order, derives
all 22 exact payloads with stdlib Fraction, and physically writes every scheduled
body, replacing the final index and recounting actual filesystem sizes.
It does not import the audited helper or run a numerical worker/fitter/JAX/AD/FD.
The resulting materialized bodies were independently compared byte-for-byte to
the preserved trace. All 38 emitted bodies and all ledger terms are unchanged.

| Quantity | Verified bytes |
|---|---:|
| Cumulative produced writes | {bytes_['cumulative_written_bytes']} |
| Final live files | {bytes_['final_live_bytes']} |
| Peak old/new coexistence | {bytes_['peak_live_bytes']} |
| Index transaction | {bytes_['index_transaction_bytes']} |
| Old index | {bytes_['old_index_bytes_charged']} |
| Final staging/index | {bytes_['temporary_bytes_charged']} |
| Manifest own serialized body | {bytes_['run_manifest_own_length']} |
| stdout / stderr | {bytes_['stdout']} / {bytes_['stderr']} |

There are 39 charged writes, 40 events, two index generations, maximum
1204 JSON nodes and depth 9 in the 36 emitted JSON records. The canonical trace
container is {route['canonical_positive_trace']['bytes']} bytes, SHA
`{route['canonical_positive_trace']['sha256']}`; it wraps journal/ledger and is
**not one worker's export bytes**. This proves one finite hypothetical schedule,
not all-case/resource admission, runtime watchdogs, operation/bit counts or safety.

## Frozen evidence and capture qualifications

- Verified manifest SHA `{start['manifest']['sha256']}`, HEAD, full Git index and
  newline stage-entry pins; all 170 protected Root-union files, including the
  overlapping 125 numeric / 9 packet / 44 history inventories.
- Verified all 210 original-author files (5,388,615 bytes), 452 rejected-review
  proof files (15,627,201 bytes), and 235 corrector entries (6,356,655 bytes:
  232 regular files plus three readlink-UTF8 representations).
- Read back all 220 / 457 / 238 frozen archive members. Three archived links
  remain explicitly mapped regular UTF-8 data. Two old mutable status bodies
  are bound by the frozen failed archive, not today's status docs.
- Corrector current runs execute their recorded pre-run snapshots. Historical
  six RED failures, all GREEN results, actual exits, raw hashes, exact identities,
  source pins and order were checked; fresh reproduction agrees.
- The two initial guard representation mistakes remain setup failures, not
  numerical/trace REDs or protected drift. Their first receipts are transcriptions
  and post-failure source, not pre-run/raw attestation. Later captured reproductions
  are separate. The original author helper's snapshot/live-execution limitation
  remains disclosed; no historical OS attestation is invented.
- Process/PID/command/clock/ownership/counter fields within the trace remain
  inherited **STATIC/HYPOTHETICAL**, not observations of these review processes.
  The repeated-one packet digest remains illustrative, distinct from actual
  frozen packet SHA `{positive['actual_packet_sha256']}`.
- Portable Python open-hook replay is not an OS sandbox/security attestation.
  No entire Git-status/directory-membership immutability claim was made; allowed
  parent status/new evidence writes remain allowed.

## Delivery

Only `{W}` was written. No protected source/data/test/contract, repository,
profile, credential or skill was changed. No implementation, freeze, A2 or
broader-accounting approval follows. Parent must read back/archive this verdict,
its proof index and final pins before publishing the scoped result. Remaining
correction cycles: zero; any later acceptance failure requires preserve/stop.

See `assessment.json` for exact proof paths and counts. `proof-index.json` and
`final-pins.json` are sealed after these assessments to avoid self-hashing.
"""
assert not (W / 'assessment.md').exists()
(W / 'assessment.md').write_text(md)
print(json.dumps({'passed': True, 'security_concerns': [], 'logic_errors': [],
                  'assessment_json': str(W / 'assessment.json'), 'assessment_json_pin': pin(W / 'assessment.json'),
                  'assessment_markdown': str(W / 'assessment.md'), 'assessment_markdown_pin': pin(W / 'assessment.md'),
                  'verified_counts': counts, 'verified_bytes': bytes_}, indent=2, sort_keys=True))
