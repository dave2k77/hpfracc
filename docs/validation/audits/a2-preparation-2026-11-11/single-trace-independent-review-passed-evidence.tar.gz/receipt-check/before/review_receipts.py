"""Check exact raw child/XML/snapshot receipts without promoting static fields."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
C = Path('/home/davianc/.hermes/cache/scratch/a2-routing-corrector-tcyfzwif')
P = Path('/home/davianc/.hermes/cache/scratch/a2-independent-fixed-review-kgblph4j')
W = Path('/home/davianc/.hermes/cache/scratch/a2-routing-independent-review-Lnvtx4VN')
PARENT = Path('/home/davianc/.hermes/cache/scratch/a2-routing-parent-5fnrmmf8')
REPO = '/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc'

def load(p):
    return json.loads(p.read_bytes())

def pin(p):
    assert not p.is_symlink()
    b = p.read_bytes()
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def xml_result(path):
    root = ET.parse(path).getroot()
    cases = list(root.iter('testcase'))
    counts = {'tests': len(cases), 'failures': sum(c.find('failure') is not None for c in cases),
              'errors': sum(c.find('error') is not None for c in cases), 'skipped': sum(c.find('skipped') is not None for c in cases)}
    counts['passed'] = counts['tests'] - sum(counts[k] for k in ('failures', 'errors', 'skipped'))
    suites = list(root.iter('testsuite'))
    assert len(suites) == 1
    for k in ('tests', 'failures', 'errors', 'skipped'):
        assert int(suites[0].get(k)) == counts[k]
    ids = [(c.get('classname'), c.get('name')) for c in cases]
    assert len(set(ids)) == len(ids)
    failures = [{'identity': ids[i], 'message': c.find('failure').get('message'), 'body': c.find('failure').text}
                for i, c in enumerate(cases) if c.find('failure') is not None]
    return {'counts': counts, 'test_identities': ids, 'failures': failures, 'xml_pin': pin(path)}

def receipt(base, name, expected_exit, expected_counts=None):
    target = base / name
    plan = load(target / 'plan.json')
    process = load(target / 'process.json')
    assert process['actual_child_exit'] == expected_exit
    assert process['command'] == plan['command']
    prefix = ['uv', 'run', '--project', REPO, '--frozen', '--no-sync', 'python', '-B']
    assert process['command'][:len(prefix)] == prefix
    assert plan['cwd'] == str(target / 'before')
    assert process['start_monotonic_ns'] <= process['end_monotonic_ns']
    for stream in ['stdout', 'stderr']:
        assert process[stream] == pin(target / (stream + '.raw'))
    for name_, expected in plan['executed_source_snapshots'].items():
        assert pin(target / 'before' / name_) == expected
    assert any(x.startswith(str(target / 'before') + '/') and x.endswith('.py') for x in process['command'])
    if '-m' in process['command'] and 'pytest' in process['command']:
        assert '-p' in process['command'] and 'no:cacheprovider' in process['command']
        assert process['command'][process['command'].index('--basetemp') + 1] == str(target / 'pytest-temp')
        parsed = xml_result(target / 'raw.xml')
        assert parsed['counts'] == expected_counts
        if 'counts' in process:
            assert parsed['counts'] == process['counts']
            recorded = [(c['classname'], c['name']) for c in process['testcases']]
            assert recorded == [tuple(x) for x in parsed['test_identities']]
        if expected_counts['failures']:
            assert all('DID NOT RAISE' in f['message'] for f in parsed['failures'])
            assert all(f['identity'][0] == 'test_a2_routing' for f in parsed['failures'])
        assert pin(target / 'stderr.raw')['bytes'] == 0
    else:
        parsed = None
    return {'directory': str(target), 'actual_child_exit': expected_exit, 'raw_and_snapshot_bindings_verified': True,
            'executed_snapshot_not_live_source': True, 'selection': parsed}

G = {'tests': 26, 'passed': 26, 'failures': 0, 'errors': 0, 'skipped': 0}
R = {'tests': 26, 'passed': 20, 'failures': 6, 'errors': 0, 'skipped': 0}
old = {}
for name, exit_, counts in [('red-routing', 1, R), ('green-routing', 0, G), ('isolated-tests', 0, G),
                             ('isolated-replay', 0, None), ('missing-artifact', 1, None)]:
    old[name] = receipt(C, name, exit_, counts)
assert old['red-routing']['selection']['test_identities'] == old['green-routing']['selection']['test_identities'] == old['isolated-tests']['selection']['test_identities']
assert load(C / 'red-routing/process.json')['end_monotonic_ns'] < load(C / 'green-routing/process.json')['start_monotonic_ns']
for name in ['red-routing', 'green-routing', 'isolated-tests']:
    expected = '48742703d81152398f7879875d1e7f4f35d5b011cdb8950cb3cbda7b6fa8c48a' if name == 'red-routing' else '4b28a7dfc4587dd6d6bfb63cdb5ea5362b0f5cf5ab3c1c9d31fe211465dfbd4e'
    assert pin(C / name / 'before/a2_trace.py')['sha256'] == expected
assert not (C / 'missing-artifact/before/trace.json').exists()
assert b'required preserved positive artifact is missing' in (C / 'missing-artifact/stderr.raw').read_bytes()
original_portable = json.loads((C / 'isolated-replay/stdout.raw').read_bytes())
assert original_portable == load(C / 'isolated-replay/before/replay-report.json')
assert (C / 'protected-before.json').read_bytes() == (C / 'protected-after.json').read_bytes()
setup = []
for i in ['01', '02']:
    transcribed = load(C / ('guard-attempt-' + i) / 'tool-result.json')
    assert transcribed['exit_code'] == 1 and 'no pre-run' in transcribed['kind']
    p = load(C / ('guard-failure-reproduction-' + i) / 'process.json')
    assert p['actual_child_exit'] == 1
    for stream in ['stdout', 'stderr']:
        assert p[stream] == pin(C / ('guard-failure-reproduction-' + i) / (stream + '.raw'))
    setup.append({'attempt': i, 'initial_original_capture': 'tool-result transcription and post-failure source only, NOT pre-run/raw attestation',
                  'later_reproduction_actual_exit': 1, 'classification': 'guard metadata representation failure, not trace/numerical RED or protected drift'})
assert "git('ls-files', '--stage', '-z')" in (C / 'guard-attempt-02/a2_corrector_guard.py').read_text()
new = {}
for name, exit_, counts in [('reproduced-26-red', 1, R), ('reproduced-26-green', 0, G), ('isolated-26-green', 0, G),
                            ('portable-positive', 0, None), ('missing-artifact', 1, None),
                            ('prior-23-negatives-corrected', 0, {'tests': 23, 'passed': 23, 'failures': 0, 'errors': 0, 'skipped': 0})]:
    new[name] = receipt(W, name, exit_, counts)
assert new['reproduced-26-red']['selection']['test_identities'] == old['red-routing']['selection']['test_identities']
assert new['reproduced-26-green']['selection']['test_identities'] == old['green-routing']['selection']['test_identities']
parent = {'tests': receipt(PARENT, 'parent-tests', 0, G), 'portable': receipt(PARENT, 'parent-portable', 0)}
prior = xml_result(P / 'targeted-negative-tests/raw.xml')
assert prior['counts'] == {'tests': 23, 'passed': 22, 'failures': 1, 'errors': 0, 'skipped': 0}
assert load(P / 'targeted-negative-tests/process.json')['child_exit'] == 1
assert prior['failures'][0]['identity'][1] == 'test_binding_filename_must_match_its_declared_binding_id'
report = {'corrector_historical_receipts': old, 'reviewer_new_executions': new, 'parent_receipts': parent,
          'prior_original_rejection_preserved': prior, 'setup_capture_limits': setup,
          'current_run_26_unique_pytest_identities': len(new['reproduced-26-green']['selection']['test_identities']),
          'no_summing_repeated_runs_or_mutation_controls_as_numerical_cases': True,
          'original_author_capture_limitation': 'First author helper copied before execution but ran live HERE sources; independently replayed source is not historical OS attestation.',
          'isolation_limit': 'Local snapshot replay and portable Python open-hook only; NOT an OS sandbox or security attestation.',
          'implementation_authorized': False, 'protocol_freeze_authorized': False,
          'a2_acceptance_passed': False, 'broader_accounting_proved': False}
(HERE / 'receipt-verification.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'historical': {k: v['actual_child_exit'] for k, v in old.items()},
                  'reviewer': {k: v['actual_child_exit'] for k, v in new.items()},
                  'verified_current_26_unique_pytest_identities': report['current_run_26_unique_pytest_identities'],
                  'setup_capture_limits': setup}, indent=2, sort_keys=True))
