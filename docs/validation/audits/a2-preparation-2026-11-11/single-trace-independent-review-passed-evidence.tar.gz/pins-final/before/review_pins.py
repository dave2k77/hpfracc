"""Read-only verification of the explicit frozen review inputs; writes here only."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import stat
import subprocess
import sys
import tarfile

HERE = Path(__file__).resolve().parent
REPO = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
SCRATCH = Path('/home/davianc/.hermes/cache/scratch')
AUTHOR = SCRATCH / 'a2-single-trace-20261112'
PRIOR = SCRATCH / 'a2-independent-fixed-review-kgblph4j'
CORRECTOR = SCRATCH / 'a2-routing-corrector-tcyfzwif'
ROOT = REPO / 'docs/validation/audits/a2-preparation-2026-11-11'
MANIFEST = SCRATCH / 'a2-routing-parent-5fnrmmf8/routing-review-manifest.json'
MANIFEST_SHA = '05fd9b428c379e7d6b59db004b8fcc04bc6cec45e76aab2298ab68ff425749c3'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def load(p):
    return json.loads(p.read_bytes())

def content(p, kind='regular_file'):
    mode = p.lstat().st_mode
    if kind == 'symlink_readlink_utf8':
        assert stat.S_ISLNK(mode), str(p)
        return os.readlink(p).encode('utf-8')
    assert stat.S_ISREG(mode), str(p)
    return p.read_bytes()

def pin(p, kind='regular_file'):
    b = content(p, kind)
    return {'bytes': len(b), 'sha256': sha(b)}

def verify_files(base, rows):
    total = 0
    kinds = {}
    for name, expected in rows.items():
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        kind = expected.get('kind', 'regular_file') if isinstance(expected, dict) else 'regular_file'
        actual = pin(base / name, kind)
        assert (actual['sha256'] == expected if isinstance(expected, str) else
                actual == {k: expected[k] for k in ('bytes', 'sha256')}), str(base / name)
        total += actual['bytes']
        kinds[kind] = kinds.get(kind, 0) + 1
    return {'files': len(rows), 'bytes': total, 'kinds': kinds}

def checked(p, digest):
    assert pin(p)['sha256'] == digest, str(p)
    return load(p)

def check_archives():
    preservation = load(ROOT / 'single-trace-failed-review-preservation.json')
    correction = load(ROOT / 'single-trace-routing-correction-preservation.json')
    specs = [(x, AUTHOR if 'rejected-author' in x['path'] else PRIOR) for x in preservation['archives']]
    specs.append((correction['archive'], CORRECTOR))
    out = []
    for spec, base in specs:
        path = REPO / spec['path']
        assert pin(path) == {k: spec[k] for k in ('bytes', 'sha256')}
        mappings = {}
        with tarfile.open(path, 'r:gz') as tf:
            members = tf.getmembers()
            assert len(members) == spec['members_verified']
            assert len({m.name for m in members}) == len(members)
            if base == CORRECTOR:
                raw = tf.extractfile('archive-representations.json').read()
                mappings = json.loads(raw)
            verified = []
            for member in members:
                assert member.isfile() and not member.issym() and not member.islnk()
                assert not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
                raw = tf.extractfile(member).read()
                assert len(raw) == member.size
                if member.name == 'archive-representations.json':
                    continue
                archived_only = member.name.startswith('parent-pre-status/')
                if archived_only:
                    # Historical status bytes are bound by the frozen archive,
                    # not today's explicitly mutable parent status paths.
                    expected = raw
                elif member.name == 'parent-preservation-source.py':
                    expected = content(base / 'a2_preserve_failed_review.py')
                elif member.name in mappings:
                    expected = content(base / member.name, 'symlink_readlink_utf8')
                else:
                    expected = content(base / member.name)
                assert raw == expected, member.name
                verified.append({'member': member.name, 'bytes': len(raw), 'sha256': sha(raw),
                                 'historical_status_bound_by_frozen_archive_only': archived_only})
        out.append({'path': str(path), 'members': len(members),
                    'verified_against_live_sources': sum(not x['historical_status_bound_by_frozen_archive_only'] for x in verified),
                    'historical_status_members_bound_by_frozen_archive_only': sum(x['historical_status_bound_by_frozen_archive_only'] for x in verified),
                    'archive_pin': pin(path), 'representation_map': mappings, 'members_readback': verified})
    return out

def check():
    m = checked(MANIFEST, MANIFEST_SHA)
    ai = checked(AUTHOR / 'evidence-index.json', m['artifact_index_sha256'])
    am = checked(AUTHOR / 'review-manifest.json', '266772753264b13e0788628c62c196400fa6515ceca5c1555713edff228e3ac9')
    pi = checked(PRIOR / 'proof-index.json', 'ea1cf140c393c5426e328833bff087ba52c37b0fcf297fd9ae83dd75ffe3d4d9')
    pa = checked(PRIOR / 'assessment.json', m['prior_rejected_assessment_sha256'])
    ci = checked(CORRECTOR / 'proof-index.json', m['correction_index_sha256'])
    assert pa['passed'] is False and len(pa['logic_errors']) == 1
    assert am['artifact_files'] == ai['files']
    assert m['correction_files'] == ci['files']
    result = {'manifest': pin(MANIFEST), 'repo_union': verify_files(REPO, m['repo_files']),
              'author': verify_files(AUTHOR, ai['files']), 'manifest_original_artifact_subset': verify_files(AUTHOR, m['artifact_files']),
              'prior_review': verify_files(PRIOR, pi['files']), 'corrector': verify_files(CORRECTOR, ci['files'])}
    baseline = load(AUTHOR / 'baseline.json')
    for label, key in [('numerical', 'numerical_inputs'), ('packet', 'packet_before'), ('history', 'history')]:
        result[label] = verify_files(REPO, baseline[key])
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    def git(*args):
        return subprocess.check_output(['git', '-C', str(REPO), *args], env=env)
    result['head'] = git('rev-parse', 'HEAD').decode().strip()
    index_path = Path(git('rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
    result['git_index_sha256'] = sha(content(index_path))
    result['git_stage_newline_sha256'] = sha(git('ls-files', '--stage'))
    assert result['head'] == m['head']
    assert result['git_index_sha256'] == m['index_sha256']
    assert result['git_stage_newline_sha256'] == m['stage_sha256']
    result['extra_pins'] = load(CORRECTOR / 'correction-report.json')['protected_extra_pins']
    for path, expected in result['extra_pins'].items():
        assert pin(Path(path)) == expected, path
    assert pin(CORRECTOR / 'correction-report.json')['sha256'] == m['correction_report_sha256']
    assert (ROOT / 'single-trace-routing-correction-report.json').read_bytes() == content(CORRECTOR / 'correction-report.json')
    old = content(AUTHOR / 'a2_trace.py')
    new = content(CORRECTOR / 'candidate/a2_trace.py')
    line = b"        need(binding['binding_id'] == 'host-' + suffix, 'binding path-to-ID')\n"
    assert new.count(line) == 1 and new.replace(line, b'', 1) == old
    result['exact_one_line_guard_delta'] = True
    for name in ['authority.json', 'protocol.json', 'record-schemas.json', 'trace.json', 'test_a2_trace.py', 'methodology.md', 'self-check.json']:
        assert content(AUTHOR / name) == content(CORRECTOR / 'candidate' / name), name
    result['original_data_and_tests_unchanged'] = True
    result['archives'] = check_archives()
    result['entire_git_status_or_directory_membership_asserted_unchanged'] = False
    result['allowed_parent_status_paths'] = m['allowed_parent_status_paths']
    return result

if __name__ == '__main__':
    result = check()
    target = HERE / sys.argv[1]
    assert target.parent == HERE and not target.exists()
    target.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('archives', 'extra_pins')}, sort_keys=True))
