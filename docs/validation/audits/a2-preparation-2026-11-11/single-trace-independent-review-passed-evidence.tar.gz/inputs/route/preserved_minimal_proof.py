"""Direct replay of the preserved first-review minimal counterexample bytes."""
from pathlib import Path
import hashlib
import importlib.util
import json

from a2_independent_proof import validate

HERE = Path(__file__).resolve().parent

def module(directory, name):
    spec = importlib.util.spec_from_file_location(name, HERE / directory / 'a2_trace.py')
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

raw = (HERE / 'original-minimal-counterexample.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'ca98c968ab4a46ecc4e07baf9071308606fc569aee8138f2184a87ce36e7117e'
t = json.loads(raw)
old = module('rejected', 'minimal_rejected')
fixed = module('candidate', 'minimal_corrected')
schema = json.loads((HERE / 'candidate/record-schemas.json').read_bytes())
for record in t['records'].values():
    validate(record, schema, schema['$defs'])
accepted_by_exact_rejected_source = old.verify_trace(t)
assert accepted_by_exact_rejected_source['slot_count'] == 22
assert fixed.replay_ledger(t) == t['ledger']
assert t['records']['records/binding-host-0.json']['binding_id'] == 'host-1'
try:
    fixed.verify_trace(t)
except ValueError as error:
    assert str(error) == 'binding path-to-ID', str(error)
else:
    raise AssertionError('preserved minimal counterexample still accepted')
report = {'preserved_file_bytes': len(raw), 'preserved_file_sha256': hashlib.sha256(raw).hexdigest(),
          'all_record_schemas_independently_checked': True,
          'exact_rejected_source_accepts_end_to_end': True,
          'corrected_rejects_exact_reason': 'binding path-to-ID',
          'premature_schema_or_hash_rejection': False,
          'implementation_authorized': False, 'protocol_freeze_authorized': False,
          'a2_acceptance_passed': False, 'broader_accounting_proved': False}
(HERE / 'preserved-minimal-proof.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps(report, indent=2, sort_keys=True))
