"""Preserve failed ledger author and independent advisory without changing them."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
HERE = Path(__file__).resolve().parent
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
SOURCES = [
    ('author', Path('/home/davianc/.hermes/cache/scratch/a2_ledger_proof_20261112_d72ac91b'), 180),
    ('advisory', Path('/home/davianc/.hermes/cache/scratch/a2_obligation_TomeBgNo'), 201),
]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def preserve(label, source, expected_count):
    index_raw = (source / 'evidence-index.json').read_bytes()
    index = json.loads(index_raw)
    entries = index['files']
    if isinstance(entries, list):
        entries = {x['path']: x for x in entries}
    assert len(entries) == expected_count
    indexed_bytes = 0
    for name, metadata in entries.items():
        path = source / name
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        assert path.is_file() and not path.is_symlink(), name
        raw = path.read_bytes()
        assert len(raw) == metadata['bytes'] and sha(raw) == metadata['sha256'], name
        indexed_bytes += len(raw)
    files = {}
    for path in sorted(source.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_dir():
            continue
        assert path.is_file(), path
        raw = path.read_bytes()
        assert not re.search(rb'(?:ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,})', raw), path
        files[path.relative_to(source).as_posix()] = raw
    assert set(entries) <= set(files)
    destination = AUDIT / ('metadata-ledger-' + label + '-evidence.tar.gz')
    assert not destination.exists()
    with destination.open('wb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, raw in files.items():
                    info = tarfile.TarInfo(name)
                    info.mode = 0o644
                    info.size = len(raw)
                    archive.addfile(info, io.BytesIO(raw))
    with tarfile.open(destination, 'r:gz') as archive:
        members = {x.name: x for x in archive.getmembers()}
        assert set(members) == set(files)
        for name, raw in files.items():
            assert archive.extractfile(members[name]).read() == raw, name
    record = {
        'label': label,
        'scope': 'Failed scratch ledger author' if label == 'author' else 'Read-only advisory design; not review/approval of author',
        'indexed_files_verified': len(entries), 'indexed_bytes_verified': indexed_bytes,
        'original_index_sha256': sha(index_raw),
        'archive': destination.name, 'archive_sha256': sha(destination.read_bytes()),
        'archive_bytes': destination.stat().st_size, 'archive_members_verified': len(members),
        'additional_capture_files': sorted(set(files) - set(entries)),
        'files': {name: {'sha256': sha(raw), 'bytes': len(raw), 'originally_indexed': name in entries}
                  for name, raw in files.items()},
        'new_budget_applied': False, 'budget_revision_justified': False,
        'implementation_authorized': False, 'a2_acceptance_passed': False,
    }
    target = AUDIT / ('metadata-ledger-' + label + '-preservation.json')
    assert not target.exists()
    target.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    if label == 'author':
        for src, dst in [('proof.json', 'metadata-ledger-author-outcome.json'),
                         ('methodology.md', 'metadata-ledger-author-methodology.md')]:
            target = AUDIT / dst
            assert not target.exists()
            target.write_bytes(files[src])
    else:
        target = AUDIT / 'metadata-ledger-advisory-methodology.md'
        assert not target.exists()
        target.write_bytes(files['findings-methodology.md'])
    print(json.dumps({key: record[key] for key in [
        'label', 'indexed_files_verified', 'indexed_bytes_verified',
        'original_index_sha256', 'archive_members_verified', 'archive_sha256',
    ]}))
    return record


def guard():
    baseline = json.loads((HERE / 'baseline.json').read_text())
    for name, expected in baseline['numerical_inputs'].items():
        assert sha((ROOT / name).read_bytes()) == expected, name
    for key in ['packet_before', 'immutable_history']:
        for name, metadata in baseline[key].items():
            raw = (ROOT / name).read_bytes()
            assert sha(raw) == metadata['sha256'] and len(raw) == metadata['bytes'], name
    assert sha((ROOT / '.git/index').read_bytes()) == baseline['git_index_sha256']
    assert sha(subprocess.check_output(['git', 'ls-files', '--stage'], cwd=ROOT)) == baseline['index_entries_sha256']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == baseline['head']
    return {'packet_files': 9, 'numerical_inputs': 125, 'history_files': 21,
            'index_and_head_unchanged': True}


if __name__ == '__main__':
    before = guard()
    records = [preserve(*item) for item in SOURCES]
    after = guard()
    assert before == after
    receipt = {'guard_before': before, 'guard_after': after,
               'new_budget_applied': False, 'independent_author_assessment': 'not yet performed'}
    (HERE / 'parent-preservation-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))
