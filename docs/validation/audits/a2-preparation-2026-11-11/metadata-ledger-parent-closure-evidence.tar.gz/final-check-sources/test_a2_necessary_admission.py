"""Portable necessary byte controls; passing does NOT prove export feasibility."""
import json
import os
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent
PACKET = Path(os.environ['HPFRACC_A2_PACKET_DIR'])
BOUNDS = json.loads((ROOT / 'necessary-lower-bounds-before.json').read_text())[
    'resource_branch_independent_lower_bounds'
]


@pytest.mark.parametrize('row', BOUNDS, ids=[row['case_id'] for row in BOUNDS])
def test_required_positive_case_clears_necessary_index_byte_lower_bound(row):
    reservation = json.loads((PACKET / 'protocol.json').read_text())['caps'][
        'failure_index_bytes'
    ]
    assert row['lower_bound_is_NOT_a_valid_output_or_measured_run'] is True
    assert row['two_index_serialization_lower_bound'] <= reservation, (
        f"{row['case_id']}: even a deliberately undercounted pair needs "
        f"{row['two_index_serialization_lower_bound']} bytes; "
        f"reservation is {reservation}; this is not a numerical failure."
    )
