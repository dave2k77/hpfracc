"""Necessary static byte-admission controls, NOT numerical/worker tests."""
import json
from pathlib import Path

import pytest

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
PROOF = Path('/home/davianc/.hermes/cache/scratch/a2-independent-final-complete-l_bwads9/supplemental-run3/supplemental-proof.json')
BOUNDS = json.loads(PROOF.read_text())['resource_branch_independent_lower_bounds']


@pytest.mark.parametrize('row', BOUNDS, ids=[row['case_id'] for row in BOUNDS])
def test_required_positive_case_clears_necessary_index_byte_lower_bound(row):
    """Passing this necessary condition alone is NOT valid export feasibility."""
    reservation = json.loads((AUDIT / 'protocol.json').read_text())['caps']['failure_index_bytes']
    assert row['lower_bound_is_NOT_a_valid_output_or_measured_run'] is True
    assert row['two_index_serialization_lower_bound'] <= reservation, (
        f"{row['case_id']}: even a deliberately undercounted pair of index records "
        f"needs {row['two_index_serialization_lower_bound']} bytes; "
        f"metadata reservation is {reservation}. This is not a numerical failure."
    )
