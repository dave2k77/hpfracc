"""Capture the resumed metadata-only baseline and actual check exits."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = Path(__file__).resolve().parent
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
OLD = Path('/home/davianc/.hermes/cache/scratch/a2-budget-revision-approved-20261112')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def capture():
    prior = json.loads((OLD / 'baseline.json').read_text())
    numerical = prior['numerical_inputs']
    assert len(numerical) == 125
    for name, expected in numerical.items():
        assert digest((ROOT / name).read_bytes()) == expected, name
    for name, metadata in prior['packet_before'].items():
        raw = (ROOT / name).read_bytes()
        assert digest(raw) == metadata['sha256'] and len(raw) == metadata['bytes'], name
    for name, metadata in prior['protected_files'].items():
        assert digest((ROOT / name).read_bytes()) == metadata['sha256'], name
    packet = {}
    for name in prior['packet_before']:
        raw = (ROOT / name).read_bytes()
        saved = OUT / 'before' / name
        saved.parent.mkdir(parents=True, exist_ok=True)
        assert not saved.exists()
        saved.write_bytes(raw)
        packet[name] = {'sha256': digest(raw), 'bytes': len(raw)}
    immutable = {}
    for p in sorted(AUDIT.iterdir()):
        assert p.is_file() and not p.is_symlink()
        name = p.relative_to(ROOT).as_posix()
        if name not in packet:
            raw = p.read_bytes()
            immutable[name] = {'sha256': digest(raw), 'bytes': len(raw)}
    index = (ROOT / '.git/index').read_bytes()
    stage = subprocess.check_output(['git', 'ls-files', '--stage'], cwd=ROOT)
    assert digest(index) == prior['git_index_sha256']
    assert digest(stage) == prior['index_entries_sha256']
    tests = (OLD / 'test_metadata_admission.py').read_bytes()
    proof = Path('/home/davianc/.hermes/cache/scratch/a2-independent-final-complete-l_bwads9/supplemental-run3/supplemental-proof.json')
    for target, raw in [('necessary-admission-test-before.py', tests), ('necessary-lower-bounds-before.json', proof.read_bytes())]:
        (OUT / target).write_bytes(raw)
    metadata = {
        'observed_at_utc': datetime.now(timezone.utc).isoformat(),
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
        'git_index_sha256': digest(index), 'index_entries_sha256': digest(stage),
        'packet_before': packet, 'numerical_inputs': numerical,
        'immutable_history': immutable,
        'parent_status_paths': ['docs/developer/phase-a-completion.md', 'docs/developer/bug-resolution-tracker.md'],
        'scope': 'One resumed metadata-ledger completion/revision cycle. Scratch-only proof authors; parent-only packet metadata edits AFTER sufficient accounting. No numerical implementation/freeze. No profile/config/credential inspection or global-profile equality assertion.',
    }
    (OUT / 'baseline.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'baseline_packet_files': len(packet), 'numerical_inputs': len(numerical), 'immutable_history_files': len(immutable), 'index_unchanged': True}))


def run(name, command):
    start = time.monotonic_ns()
    result = subprocess.run(command, cwd=ROOT, capture_output=True)
    (OUT / (name + '.stdout.raw')).write_bytes(result.stdout)
    (OUT / (name + '.stderr.raw')).write_bytes(result.stderr)
    metadata = {'command': command, 'exit_code': result.returncode,
                'elapsed_monotonic_ns': time.monotonic_ns() - start,
                'stdout_sha256': digest(result.stdout), 'stderr_sha256': digest(result.stderr)}
    (OUT / (name + '.process.json')).write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps({'name': name, **metadata}))
    return name, result.returncode


if __name__ == '__main__':
    capture()
    commands = {
        'baseline-necessary-red': ['uv', 'run', '--frozen', '--no-sync', 'python', '-B', '-m', 'pytest', str(OLD / 'test_metadata_admission.py'), '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(OUT / 'necessary-red-temp'), '--junitxml=' + str(OUT / 'baseline-necessary-red.xml')],
        'baseline-ruff': ['uv', 'run', '--frozen', 'ruff', 'check', '.'],
        'baseline-docs-tests': ['uv', 'run', '--frozen', 'python', '-B', '-m', 'pytest', 'tests/unit/test_docs_consistency.py', '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(OUT / 'docs-test-temp'), '--junitxml=' + str(OUT / 'baseline-docs-tests.xml')],
        'baseline-strict-docs': ['uv', 'run', '--frozen', 'mkdocs', 'build', '--strict', '--site-dir', str(OUT / 'baseline-site')],
        'baseline-whitespace': ['git', 'diff', '--check'],
    }
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = [pool.submit(run, name, command) for name, command in commands.items()]
        results = dict(f.result() for f in futures)
    assert results['baseline-necessary-red'] == 1
    assert all(code == 0 for name, code in results.items() if name != 'baseline-necessary-red')
