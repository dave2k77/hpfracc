"""Archive the final independent failed-ledger assessment and verify its inputs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
HERE = Path(__file__).resolve().parent
SOURCE = Path('/home/davianc/.hermes/cache/scratch/a2_ledger_assessment_20261112_c4f26a91')
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def guards():
    raw = (HERE / 'ledger-assessment-inputs.json').read_bytes()
    assert sha(raw) == '329b3305c6d6096bb780ea01a5afff60f45c1f318e123026093083b9c8cdf005'
    manifest = json.loads(raw)
    groups = [(ROOT, manifest['repo_files'])]
    groups += [(Path(base), files) for base, files in manifest['child_files'].items()]
    result = {}
    for base, entries in groups:
        for name, metadata in entries.items():
            path = base / name
            assert path.is_file() and not path.is_symlink(), name
            data = path.read_bytes()
            assert len(data) == metadata['bytes'] and sha(data) == metadata['sha256'], name
        result[str(base)] = len(entries)
    assert sha((ROOT / '.git/index').read_bytes()) == manifest['git_index_sha256']
    assert sha(subprocess.check_output(['git', 'ls-files', '--stage'], cwd=ROOT)) == manifest['index_entries_sha256']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == manifest['head']
    return result


if __name__ == '__main__':
    before = guards()
    index_raw = (SOURCE / 'evidence-index.json').read_bytes()
    assert sha(index_raw) == '7cada78b03e393659f946e9aae65d479f27d4bbebea689a007e7f4df0cbb0028'
    entries = json.loads(index_raw)['files']
    assert len(entries) == 102
    size = 0
    for name, metadata in entries.items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        path = SOURCE / name
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        assert len(data) == metadata['bytes'] and sha(data) == metadata['sha256'], name
        size += len(data)
    assert size == 1654964
    files = {}
    for path in sorted(SOURCE.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_dir():
            continue
        assert path.is_file()
        files[path.relative_to(SOURCE).as_posix()] = path.read_bytes()
    assessment = json.loads(files['assessment.json'])
    assert assessment['overall_passed'] is False
    assert assessment['accounting_complete'] is False
    assert assessment['cap_revision_justified'] is False
    assert assessment['stop_correct'] is True
    assert assessment['actual_replay_exits']['author-copy/semantic-replay'] == 1
    assert assessment['actual_replay_exits']['author-copy/mutants-replay'] == 1
    archive_path = AUDIT / 'metadata-ledger-independent-assessment-evidence.tar.gz'
    assert not archive_path.exists()
    with archive_path.open('wb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, data in files.items():
                    info = tarfile.TarInfo(name)
                    info.mode = 0o644
                    info.size = len(data)
                    archive.addfile(info, io.BytesIO(data))
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = {x.name: x for x in archive.getmembers()}
        assert set(members) == set(files)
        for name, data in files.items():
            assert archive.extractfile(members[name]).read() == data
    for name in ['assessment.json', 'assessment.md']:
        target = AUDIT / ('metadata-ledger-independent-' + name)
        assert not target.exists()
        target.write_bytes(files[name])
    after = guards()
    assert before == after
    record = {
        'scope': 'Independent failed-ledger assessment; no cap change or implementation approval',
        'indexed_files_verified': 102, 'indexed_bytes_verified': size,
        'index_sha256': sha(index_raw), 'archive': archive_path.name,
        'archive_sha256': sha(archive_path.read_bytes()),
        'archive_members_verified': len(members),
        'assessment_sha256': sha(files['assessment.json']),
        'extra_capture_files_preserved': sorted(set(files) - set(entries)),
        'files': {name: {'sha256': sha(data), 'bytes': len(data), 'originally_indexed': name in entries}
                  for name, data in files.items()},
        'protected_groups_verified': after,
        'overall_passed': False, 'accounting_complete': False,
        'new_budget_applied': False, 'cap_revision_justified': False,
        'protocol_freeze_authorized': False, 'implementation_authorized': False,
        'a2_acceptance_passed': False,
    }
    target = AUDIT / 'metadata-ledger-independent-assessment-preservation.json'
    assert not target.exists()
    target.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: record[key] for key in [
        'indexed_files_verified', 'indexed_bytes_verified', 'index_sha256',
        'archive_members_verified', 'archive_sha256', 'assessment_sha256',
        'protected_groups_verified', 'overall_passed', 'accounting_complete',
        'new_budget_applied',
    ]}))
