import hashlib,json,pathlib
O=pathlib.Path(__file__).resolve().parent
files={}
for p in sorted(O.rglob('*')):
 if p.is_file() and p.name!='evidence-index.json':
  assert not p.is_symlink()
  b=p.read_bytes();files[p.relative_to(O).as_posix()]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
v={'scope':'Independent corrected-A2 preparation contract review only; no implementation/scientific acceptance','base_directory':str(O),'self_hash_excluded':True,'files':files,'file_count':len(files),'total_indexed_bytes':sum(x['bytes'] for x in files.values())}
(O/'evidence-index.json').write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
print(json.dumps({'file_count':len(files),'total_indexed_bytes':v['total_indexed_bytes'],'index_sha256':hashlib.sha256((O/'evidence-index.json').read_bytes()).hexdigest()},indent=2))
