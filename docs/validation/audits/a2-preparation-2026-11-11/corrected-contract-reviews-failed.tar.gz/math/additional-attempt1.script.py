"""Independent static interlock and bounded extremes, never calls HPFRACC/JAX."""
import ast, collections, copy, hashlib, itertools, json, math, pathlib, struct, tarfile, time
from fractions import Fraction as F
ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=pathlib.Path(__file__).resolve().parent
AUD=ROOT/'docs/validation/audits/a2-preparation-2026-11-11'
ns={'__file__':__file__}
tree=ast.parse((OUT/'independent_proofs.py').read_text())
keep=[]
for node in tree.body:
 if isinstance(node,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.ClassDef)):keep.append(node)
 elif isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['ROOT','OUT','AUD'] for t in node.targets):keep.append(node)
exec(compile(ast.Module(body=keep,type_ignores=[]),'scratch-proof-definitions','exec'),ns)
proof=ns['proof'];Arithmetic=ns['Arithmetic'];Limit=ns['Limit'];decode=ns['decode'];rat=ns['rat'];enc=ns['enc'];save=ns['save'];H=ns['H']
f=json.loads((AUD/'fixtures.json').read_text());p=json.loads((AUD/'protocol.json').read_text());s=json.loads((AUD/'record-schemas.json').read_text());pol=json.loads((AUD/'comparison-policies.json').read_text());ns.update(f=f,p=p)
identity=ns['identity'];expand=ns['expand']

# Verify preserved history without extraction or executing archived scripts.
archives=[]
for an,pn in [('initial-contract-reviews-failed.tar.gz','initial-contract-reviews-preservation.json'),('corrected-draft-planning-evidence.tar.gz','corrected-draft-planning-preservation.json')]:
 rec=json.loads((AUD/pn).read_text());decl=rec['files'];raw=(AUD/an).read_bytes(); assert H(raw)==rec.get('archive_sha256',rec.get('archive_identity',{}).get('sha256'))
 with tarfile.open(AUD/an,'r:gz') as t:
  members=t.getmembers();assert len({m.name for m in members})==len(members);assert all(m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts for m in members)
  assert set(decl)=={m.name for m in members}
  for m in members:
   b=t.extractfile(m).read();assert {'bytes':len(b),'sha256':H(b)}==decl[m.name],m.name
  if an.startswith('initial'):
   old=t.extractfile('math/reviewed-protocol.raw.md').read();now=(ROOT/'docs/developer/a2-compression-budget-protocol.md').read_bytes()
   def sec(b):return b[b.index(b'## 4.'):b.index(b'## 5.')]
   assert sec(old)==sec(now)
   math_identity={'bytes':len(sec(now)),'sha256':H(sec(now))}
 archives.append({'archive':an,'members_verified':len(members),'bytes':len(raw),'sha256':H(raw),'executed':False})
save('archive-and-unchanged-math.json',{'archives':archives,'exact_math_section':math_identity})

# Concrete parser controls, including every frozen raw control.
parse=[]
def reject_constant(x):raise ValueError('nonfinite')
def pairs(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('duplicate')
  d[k]=v
 return d
for c in f['parse_controls']:
 b=bytes.fromhex(c['raw_utf8_hex']);assert H(b)==c['sha256'];out=None
 try:
  v=json.loads(b,object_pairs_hook=pairs,parse_constant=reject_constant)
  if 'n' in v and type(v['n']) is not int:out='reject_integer_type'
  elif 'exact_head' in v and type(v['exact_head']) is not bool:out='reject_boolean_type'
  else:
   try:rat(v)
   except (AssertionError,ValueError):out='reject_rational'
 except ValueError as e:out='reject_duplicate_key' if str(e)=='duplicate' else 'reject_nonfinite_json'
 assert out==c['expected'];parse.append({'case_id':c['case_id'],'actual':out,'raw_sha256':H(b)})
save('parser-controls.json',parse)

# Byte identity is deliberately finer than mathematical equivalence.
base=expand(next(c for c in f['cases'] if c['case_id']=='REF-FAIL-f64-GL'))[1][0]
left=copy.deepcopy(base);right=copy.deepcopy(base)
for c,hexstr in [(left,'0000000000000000'),(right,'0000000000000080')]:
 c['coefficients']['raw_hex']=hexstr;c['coefficients']['sha256']=H(bytes.fromhex(hexstr))
assert decode(left['coefficients'])==decode(right['coefficients'])==[F(0)] and identity(left)!=identity(right)
c2=ns['expand'](next(c for c in f['cases'] if c['case_id']=='REF-PASS-f64-GL'))[1][1];perm=copy.deepcopy(c2)
for key in ['rhos','coefficients']:
 a=perm[key];b=bytes.fromhex(a['raw_hex']);width=8; b=b[width:]+b[:width];a['raw_hex']=b.hex();a['sha256']=H(b)
assert identity(c2)!=identity(perm)
renamed=copy.deepcopy(c2);renamed['stable_id']='renamed';assert identity(c2)==identity(renamed)
c3=copy.deepcopy(f['candidates']['good3-f64-GL'])
for key in ['rhos','coefficients']:c3[key]=f['arrays'][c3[key+'_ref']]
assert identity(c2)!=identity(c3)
def kernel(c,n):return [F(1)]+[sum((a*(r**(k-1)) for a,r in zip(decode(c['coefficients']),decode(c['rhos']))),F(0)) for k in range(1,n)]
assert kernel(c2,17)==kernel(perm,17)==kernel(c3,17)
identity_proof={'signed_zero_equal_rational_distinct_key':True,'simultaneous_pole_permutation_equal_kernel_distinct_key':True,'zero_coefficient_equivalent_kernel_distinct_key':True,'renamed_same_key':True,'configuration_fields':p['identity']['configuration_fields'],'producer_fields':p['identity']['producer_fields'],'excluded':p['identity']['excluded_fields'],'semantic_judgment':'Complete candidate/configuration/producer observation identity, not minimal equivalent-kernel identity. t_max and dt intentionally distinguish supplied scientific configuration even though t_max has no scaled_tail influence and dt is not fitted. Source/lock/policy/mode/dtype/backend/version influence authenticity and execution class; receipt IDs/timing/location do not. Display ID excluded; source/binding unavailable cannot manufacture a key.'}
save('identity-controls.json',identity_proof)

# Both request-global invalidity and exhaustive higher/lower-unknown gates.
decisions=[]
for suffix in ['f32-GL','f32-RL','f64-GL','f64-RL']:
 perms=[c for c in f['cases'] if c['group']=='REF-RANK' and c['case_id'].startswith('RANK-') and c['case_id'].endswith(suffix)]
 assert len(perms)==24 and len({tuple(c['request']['candidate_refs']) for c in perms})==24
 assert all(c['expected']['selected_id']=='a-good2-'+suffix for c in perms)
 for k in ['higher','lower']:
  c=next(c for c in f['cases'] if c['case_id']=='EDGE-unknown-'+k+'-'+suffix);r,cs=expand(c)
  unknown=[z for z in cs if z['artifact_status']=='missing'][0];known=[z for z in cs if z['artifact_status']=='provided'][0]
  ur=(unknown['configuration']['pole_count'],unknown['stable_id']);kr=(known['configuration']['pole_count'],known['stable_id'])
  assert (ur>kr)==(k=='higher');assert c['expected']['request_status']=='indeterminate'
  decisions.append({'case_id':c['case_id'],'known_rank':kr,'unknown_rank':ur,'can_unknown_displace_known_minimum':k=='lower','policy_outcome':'indeterminate'})
 # Explicit new mixed-failure thought experiments, not added repo fixtures.
 c=next(c for c in f['cases'] if c['case_id']=='REQUEST-duplicate-id-'+suffix);r,cs=expand(c)
 assert cs[0]['stable_id']==cs[1]['stable_id'] and identity(cs[0])==identity(cs[1]);decisions.append({'case_id':c['case_id'],'observable_reasons':['duplicate_id','duplicate_content'],'global_disposition':'invalid_request','note':'expected.reason names one reason, not exclusive all-reasons inventory'})
save('precedence-and-rank.json',decisions)

# Enumerate all supported rank-1 shapes additionally to packet rank-2 grid.
shapes=[]
for n in range(1,18):
 A=Arithmetic();x=[F((-1)**j*(j+1),16) for j in range(n)];shared,res=proof(x,n,1,[([F(1,2)],[F(1,2)])],F(1),A)
 shapes.append({'shape':[n],'primitives':A.n,'max_bits':A.maxbits,'epsilon':enc(res[0]['epsilon'])})
for dtype in ['float32','float64']:
 for op in ['GL','RL']:
  grid=[c for c in f['cases'] if c['group']=='EXACT-GRID' and c['request']['operator']==op and f['arrays'][c['request']['input_ref']]['dtype']==dtype]
  assert {tuple(f['arrays'][c['request']['input_ref']]['shape']) for c in grid}=={(n,m) for n in range(1,18) for m in range(1,4)}
save('all-supported-shape-proofs.json',{'scalar_extra_cases':shapes,'rank2_full_grid_each_dtype_alias':True,'features_independent':True})

# Compare all working policy references structurally, not guessed placeholders.
issues=[];mapping=[]
policies={q['policy_id']:q for q in pol['policies']}
for c in f['cases']:
 slots=c['required_evidence_slots'];lookup={a['slot_id']:a for a in slots};assert len(lookup)==len(slots)
 comps=c.get('required_working_comparisons',[]);assert len({a['comparison_id'] for a in comps})==len(comps)
 for a in comps:
  po=policies[a['policy_id']];ids=[a['a_slot_id'],a['reference_slot_id']]
  if None in ids:assert all(x is None for x in ids) and 'adjacent' in a['policy_id'] and 'float64' in a['policy_id'];continue
  assert all(i in lookup for i in ids),(c['case_id'],a)
  aa,rr=[lookup[i] for i in ids]
  if 'input_grad_analytic' in a['policy_id']:assert aa['quantity']=='input_AD' and aa['branch']=='ad-base' and rr['quantity']=='analytic_input_gradient' and aa['mode']==rr['mode']
  if 'forward_recursive_exact' in a['policy_id']:assert aa['quantity']=='output' and rr['quantity']=='D_hat' and aa['mode']==rr['mode']
  if 'forward_full_exact' in a['policy_id']:assert aa['quantity']=='full_output' and rr['quantity']=='D' and aa['candidate_index'] is None
  if 'adjacent' in a['policy_id']:assert aa['quantity']==rr['quantity'] and aa['mode']==rr['mode']
  mapping.append({'case_id':c['case_id'],'comparison_id':a['comparison_id'],'a':ids[0],'reference':ids[1],'policy_id':a['policy_id']})
 # Predeclared output observation cannot represent the required null candidate.
 if c['group']=='FIT-REAL':
  full=[a for a in slots if a['quantity']=='full_output'];assert len(full)==2 and all(a['candidate_index'] is None for a in full)
  assert s['$defs']['observation']['properties']['candidate_id']['type']=='string'
 # Unsupported input dimensions cannot be represented in required failure-index expected shapes.
 if any(u['replace']=='request/input' and u['value']['shape'][0]>17 for u in c['mutations']):
  n=c['mutations'][0]['value']['shape'][0];assert n>s['$defs']['index_slot']['properties']['expected_shape']['items']['maximum'];issues.append({'case_id':c['case_id'],'required_expected_shape':[n],'schema_max_dimension':17})
save('working-comparison-bindings.json',mapping)
save('schema-interlock-counterexamples.json',{'full_output_observation':{'required_candidate_id':None,'schema_type':'string','schema_pointer':'/$defs/observation/properties/candidate_id','schema_lines':[922,926],'contract':'packet-notes.md:54-56; null candidate full observations required','affected_case_count':32},'unsupported_failure_index_shape':issues})

# Endpoint sufficiency and actual cancellation are distinct from evidence completeness.
x=[F(1),F(-1),F(1)];A=Arithmetic();sh,rr=proof(x,3,1,[([F(1,2)],[F(1,2)])],F(1,4),A)
assert rr[0]['B'][-1][0]==F(3,4)
# Nonmonotone actual error: same one-pole residual and x=(1,0,0,0) gives cancellation at an intermediate row.
A=Arithmetic();sh,cancel=proof([F(1),F(0),F(0),F(0)],4,1,[([F(1,2)],[F(1,2)])],F(2),A)
error=[abs(z[0]) for z in cancel[0]['error']];assert error[3]<error[2]
save('bound-shortcuts-and-cancellation.json',enc({'changed_signal':rr[0],'cancellation_signal':[F(1),F(0),F(0),F(0)],'actual_absolute_errors':error,'bounds':cancel[0]['B'],'conclusion':'Final B sufficient for threshold because each feature B is nondecreasing; every row still required as evidence. Actual errors can cancel and decrease.'}))

# Strong represented-extreme schedules, fixed finite list; bounded, no universal feasibility claim.
maximum=F((1<<53)-1)*(F(2)**971);tiny=F(1,1<<1074);nearone=F((1<<53)-1,1<<53)
schedules=[
 ('all-subnormal-rho', [F((-1)**j,8) for j in range(51)], [([tiny]*8,[maximum]*8)]*8),
 ('near-one-large-coefficients', [maximum if j%2==0 else -maximum for j in range(51)], [([nearone]*8,[maximum]*8)]*8),
 ('mixed-exponents', [tiny if j%3==0 else maximum if j%3==1 else -maximum for j in range(51)], [([tiny,nearone,F(1),F(1,2),F(1,4),F(1,8),F(3,4),F(7,8)],[tiny,maximum,F(0),F(1,4),maximum,tiny,F(1),F(0)])]*8)
]
ext=[]
for name,x,cs in schedules:
 A=Arithmetic();start=time.monotonic_ns();result=None
 try:sh,z=proof(x,17,3,cs,F(1),A);result='completed_scoped_schedule'
 except Limit as e:result=str(e)
 ext.append({'schedule':name,'n':17,'m':3,'candidates':8,'poles_each':8,'outcome':result,'primitives_attempted_completed':A.n,'max_normalized_bits_seen':A.maxbits,'primitive_categories':dict(A.categories),'wall_ns':time.monotonic_ns()-start,'coverage':'shared w/g/binomial checks/signed-prefix output; each kernel/recursive/signed/residual crosscheck/B/comparisons; analytic L transpose gradient; extra exact rational-direction quadratic FD when reached; no hidden powers/dots','scope':'only this concrete host Fraction schedule, not entire working branch inventory or universal resource guarantee'})
 # Avoid repeated expensive giant products after one bit-cap failure; next schedules independent.
save('bounded-extreme-schedules.json',ext)
summary={'archives':archives,'canonical_parser_controls_passed':len(parse),'identity_controls_passed':4,'rank_permutations_verified':96,'comparison_operand_pairs_verified':len(mapping),'full_output_observation_schema_conflict':True,'unsupported_shape_index_conflicts':len(issues),'extra_scalar_shape_proofs':len(shapes),'extreme_schedules':ext,'no_jax_or_hpfracc_numerical_execution':True}
save('additional-summary.json',summary);print(json.dumps(summary,indent=2))
