import json,pathlib,runpy
O=pathlib.Path(__file__).resolve().parent
runpy.run_path(str(O/'pins.py'))['pins']('after')
a=json.loads((O/'pins-after.json').read_text());b=json.loads((O/'pins-before.json').read_text());assert a==b
v={'passed':True,'head':a['head'],'branch':a['branch'],'repository_files_verified_unchanged':a['repo_files_verified'],'protected_numerical_hashes_verified_unchanged':a['source_files_verified'],'index_entries_sha256':a['index_entries_sha256'],'index_file_sha256':a['index_file_sha256'],'head_index_status_and_inputs_identical_before_after':True,'review_manifest_sha256':a['review_manifest_sha256'],'protocol_sha256':a['files']['docs/developer/a2-compression-budget-protocol.md']['sha256'],'packet_manifest_sha256':a['files']['docs/validation/audits/a2-preparation-2026-11-11/packet-manifest.json']['sha256'],'staged_diff_empty':a['staged_diff']==''}
(O/'final-pin-check.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
