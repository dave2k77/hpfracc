import hashlib,json,pathlib,subprocess,sys
ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=pathlib.Path(__file__).resolve().parent
MP=pathlib.Path('/home/davianc/.hermes/cache/scratch/a2-corrected-review-20261111/review-input-manifest.json')
def H(b):return hashlib.sha256(b).hexdigest()
def run(*a):return subprocess.check_output(a,cwd=ROOT)
def pins(label):
 raw=MP.read_bytes(); m=json.loads(raw); assert H(raw)=='b87572830abd1f52e43ce08d6194e8c6b8ffcdfb9b956a0d5ff09a56390d8d95'
 files={}
 for n,e in m['immutable_repository_files'].items():
  b=(ROOT/n).read_bytes(); x={'bytes':len(b),'sha256':H(b)}; assert x==e,(n,x,e); files[n]=x
 src={}
 for n,e in m['protected_numerical_inputs'].items():
  b=(ROOT/n).read_bytes(); assert H(b)==e,n;src[n]={'bytes':len(b),'sha256':H(b)}
 idx=run('git','ls-files','--stage'); assert H(idx)==m['protected_index_entries_sha256']
 head=run('git','rev-parse','HEAD').decode().strip();assert head==m['repo_head']
 s={'review_manifest_sha256':H(raw),'head':head,'branch':run('git','branch','--show-current').decode().strip(),'index_entries_sha256':H(idx),'index_file_sha256':H((ROOT/'.git/index').read_bytes()),'repo_files_verified':len(files),'source_files_verified':len(src),'files':files,'sources':src,'status':run('git','status','--porcelain=v1').decode(),'staged_diff':run('git','diff','--cached','--raw').decode()}
 if label=='after':
  pre=json.loads((OUT/'pins-before.json').read_text());assert pre==s
 (OUT/('pins-'+label+'.json')).write_text(json.dumps(s,indent=2)+'\n')
 print(json.dumps({k:v for k,v in s.items() if k not in ['files','sources','status']},indent=2))
if __name__=='__main__':pins(sys.argv[1])
