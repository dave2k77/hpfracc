"""READONLY repository, bounded stdlib preparation proofs, not a future worker."""
import collections, copy, hashlib, itertools, json, math, pathlib, re, struct, time
from fractions import Fraction as F
ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=pathlib.Path(__file__).resolve().parent
AUD=ROOT/'docs/validation/audits/a2-preparation-2026-11-11'
def H(b):return hashlib.sha256(b).hexdigest()
def save(n,v): (OUT/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def rat(v):
 assert type(v) is dict and set(v)=={'num','den'}
 assert type(v['num']) is str and re.fullmatch(r'0|-?[1-9a-f][0-9a-f]*',v['num'])
 assert type(v['den']) is str and re.fullmatch(r'[1-9a-f][0-9a-f]*',v['den'])
 a,b=int(v['num'],16),int(v['den'],16);assert math.gcd(a,b)==1
 return F(a,b)
def enc(v):
 if isinstance(v,F):return {'num':('-' if v<0 else '')+format(abs(v.numerator),'x'),'den':format(v.denominator,'x')}
 if isinstance(v,list):return [enc(a) for a in v]
 if isinstance(v,dict):return {k:enc(a) for k,a in v.items()}
 return v

def decode(a,shape_check=True):
 b=bytes.fromhex(a['raw_hex']);assert len(b)==a['nbytes'] and H(b)==a['sha256']
 sz={'float32':4,'float64':8,'complex64':8,'complex128':16}[a['dtype']]
 if shape_check:assert math.prod(a['shape']) * sz==len(b)
 realwidth=4 if a['dtype'] in ['float32','complex64'] else 8
 fracbits,expbits,bias=(23,8,127) if realwidth==4 else (52,11,1023)
 v=[]
 for i in range(0,len(b),realwidth):
  q=int.from_bytes(b[i:i+realwidth],a['byte_order']); sig=-1 if q>>(realwidth*8-1) else 1
  e=(q>>fracbits)&((1<<expbits)-1); mant=q&((1<<fracbits)-1)
  if e==(1<<expbits)-1:v.append('nonfinite');continue
  if e:mant+=(1<<fracbits);power=e-bias-fracbits
  else:power=1-bias-fracbits
  v.append(sig*F(mant)*(F(2)**power))
 return v

f=json.loads((AUD/'fixtures.json').read_text());p=json.loads((AUD/'protocol.json').read_text());schema=json.loads((AUD/'record-schemas.json').read_text());pol=json.loads((AUD/'comparison-policies.json').read_text())
manifest=json.loads((AUD/'packet-manifest.json').read_text())
for e in manifest['files']:
 b=(ROOT/e['repo_path']).read_bytes();assert len(b)==e['bytes'] and H(b)==e['sha256']
assert len({c['case_id'] for c in f['cases']})==544
counts={'cases':len(f['cases']),'arrays':len(f['arrays']),'candidate_specs':len(f['candidates']),'parse_controls':len(f['parse_controls']),'groups':dict(sorted(collections.Counter(c['group'] for c in f['cases']).items())),'identity_controls':len(f['identity_controls']),'required_evidence_slots':sum(len(c['required_evidence_slots']) for c in f['cases']),'max_slots_per_case':max(len(c['required_evidence_slots']) for c in f['cases']),'working_comparison_slots':sum(len(c.get('required_working_comparisons',[])) for c in f['cases']),'future_real_candidate_specs':sum('producer_call' in a for a in f['candidates'].values()),'fit_identity_check_slots':sum(len(c.get('required_fit_identity_checks',[])) for c in f['cases'])}
assert counts==f['counts']==manifest['closed_planning_counts'];save('counts.json',counts)
for name,a in f['arrays'].items():decode(a)
for scalars in f['working_scalars'].values():
 for a in scalars.values():decode(a)
for steps in pol['FD_steps'].values():
 for a in steps:decode(a)

# Individual proof arithmetic counts every add/sub/mul/div/abs/comparison.
class Limit(Exception):pass
class Arithmetic:
 def __init__(self,cap=100000,bits=32768):self.n=0;self.cap=cap;self.bits=bits;self.maxbits=0;self.categories=collections.Counter()
 def chk(self,v):
  v=F(v);z=max(v.numerator.bit_length(),v.denominator.bit_length());self.maxbits=max(self.maxbits,z)
  if z>self.bits:raise Limit('normalized_bit_cap')
  return v
 def op(self,k,*args):
  if self.n+1>self.cap:raise Limit('primitive_cap')
  v=[self.chk(a) for a in args];self.n+=1;self.categories[k]+=1
  if k=='add':r=v[0]+v[1]
  elif k=='sub':r=v[0]-v[1]
  elif k=='mul':r=v[0]*v[1]
  elif k=='div':r=v[0]/v[1]
  elif k=='abs':r=abs(v[0])
  elif k=='eq':return v[0]==v[1]
  elif k=='le':return v[0]<=v[1]
  else:raise AssertionError(k)
  return self.chk(r)
 def sum(self,vs):
  r=F(0)
  for v in vs:r=self.op('add',r,v)
  return r

def proof(x,n,m,cs,tau,A):
 add=lambda a,b:A.op('add',a,b);sub=lambda a,b:A.op('sub',a,b);mul=lambda a,b:A.op('mul',a,b);div=lambda a,b:A.op('div',a,b);ab=lambda a:A.op('abs',a);eq=lambda a,b:A.op('eq',a,b);le=lambda a,b:A.op('le',a,b)
 # independent binomial construction using explicitly charged products, not math.comb.
 w=[F(1)];g=[F(1)]; binom=F(1);fourpower=F(1)
 for k in range(1,n):
  w.append(div(mul(w[-1],sub(k-1,F(1,2))),k));g.append(div(mul(g[-1],sub(k,F(1,2))),k))
  # C(2k,k) recurrence, all integer arithmetic expressed as charged rationals.
  a=sub(mul(2,k),1);binom=div(mul(mul(2,a),binom),k);fourpower=mul(4,fourpower)
  assert eq(g[-1],div(binom,fourpower))
  assert eq(g[-1],A.sum(w))
 v=[x[j] if j<m else sub(x[j],x[j-m]) for j in range(n*m)]
 D=[[mul(2,A.sum(mul(w[k],x[(i-k)*m+l]) for k in range(i+1))) for l in range(m)] for i in range(n)]
 for i in range(n):
  for l in range(m):assert eq(D[i][l],mul(2,A.sum(mul(g[k],v[(i-k)*m+l]) for k in range(i+1))))
 shared={'w':w,'g':g,'v':v,'D':D};results=[]
 for rho,c in cs:
  gh=[F(1)]; powers=[F(1)]*len(c)
  for k in range(1,n):
   gh.append(A.sum(mul(cp,rp) for cp,rp in zip(c,powers)))
   if k<n-1:powers=[mul(a,b) for a,b in zip(powers,rho)]
  residual=[sub(a,b) for a,b in zip(gh,g)]; eps=F(0)
  for z in residual:
   z=ab(z)
   if not le(z,eps):eps=z
  wh=[gh[0]]+[sub(gh[k],gh[k-1]) for k in range(1,n)]
  L=[[mul(2,wh[i-j]) if j<=i else F(0) for j in range(n)] for i in range(n)]
  Dh=[[mul(2,A.sum(mul(gh[k],v[(i-k)*m+l]) for k in range(i+1))) for l in range(m)] for i in range(n)]
  err=[];B=[];history=[[F(0)]*m for _ in c]
  for i in range(n):
   erow=[];brow=[]
   for l in range(m):
    assert eq(Dh[i][l],A.sum(mul(L[i][j],x[j*m+l]) for j in range(i+1)))
    # independent implementation of source current-head recurrence with previous history
    rec=mul(2,add(v[i*m+l],A.sum(mul(cp,history[q][l]) for q,cp in enumerate(c))))
    assert eq(Dh[i][l],rec)
    for q,r in enumerate(rho):history[q][l]=add(mul(r,history[q][l]),v[i*m+l])
    e=sub(Dh[i][l],D[i][l]);assert eq(e,mul(2,A.sum(mul(residual[k],v[(i-k)*m+l]) for k in range(i+1))))
    b=mul(mul(2,eps),A.sum(ab(v[j*m+l]) for j in range(i))) if i else F(0)
    assert le(ab(e),b);erow.append(e);brow.append(b)
   err.append(erow);B.append(brow)
  G=[[mul(div(2,n*m),A.sum(mul(L[i][j],Dh[i][l]) for i in range(j,n))) for l in range(m)] for j in range(n)]
  qualifies=all([le(b,tau) for row in B for b in row]);assert qualifies==all([le(b,tau) for b in B[-1]])
  # For fixed L exact quadratic central FD for a rational direction (NOT future cos q).
  q=[F((-1)**j*(j+1),n*m+1) for j in range(n*m)];h=F(1,128)
  def obj(z):
   y=[A.sum(mul(L[i][j],z[j*m+l]) for j in range(i+1)) for i in range(n) for l in range(m)]
   return div(A.sum(mul(a,a) for a in y),n*m)
  plus=[add(a,mul(h,b)) for a,b in zip(x,q)];minus=[sub(a,mul(h,b)) for a,b in zip(x,q)]
  fd=div(sub(obj(plus),obj(minus)),mul(2,h));direction=A.sum(mul(G[j][l],q[j*m+l]) for j in range(n) for l in range(m));assert eq(fd,direction)
  results.append({'g_hat':gh,'residual':residual,'epsilon':eps,'signed_fitted_weights':wh,'L_hat':L,'D_hat':Dh,'error':err,'B':B,'analytic_input_gradient':G,'qualifies':qualifies,'quadratic_rational_direction':q,'h':h,'central_FD':fd,'gradient_dot_direction':direction})
 return shared,results

def expand(case):
 r=copy.deepcopy(case['request']);r['input']=copy.deepcopy(f['arrays'][r['input_ref']]);cs=[]
 for ref in r['candidate_refs']:
  c=copy.deepcopy(f['candidates'][ref]);
  for k in ['rhos','coefficients']:
   c[k]=copy.deepcopy(f['arrays'][c[k+'_ref']]) if c[k+'_ref'] is not None else None
  cs.append(c)
 for u in case['mutations']:
  scope,*keys=u['replace'].split('/')
  if scope=='evidence':continue
  if scope=='request':t=r
  else:t=cs[int(scope.split(':')[1])]
  for key in keys[:-1]:t=t[key]
  t[keys[-1]]=copy.deepcopy(u['value'])
 if r['candidate_refs']!=case['request']['candidate_refs']:
  cs=[]
  for ref in r['candidate_refs']:
   c=copy.deepcopy(f['candidates'][ref]);c['rhos']=copy.deepcopy(f['arrays'][c['rhos_ref']]);c['coefficients']=copy.deepcopy(f['arrays'][c['coefficients_ref']]);cs.append(c)
 return r,cs

def identity(c):
 return json.dumps([c['configuration'],c['producer']]+[{k:c[a][k] for k in p['identity']['array_descriptor_fields']} for a in ['rhos','coefficients']],sort_keys=True,separators=(',',':'))
rows=[];raw=[];mismatches=[];total_assess=0;out_components=0;grad_components=0;pure=0
for case in f['cases']:
 r,cs=expand(case);row={'case_id':case['case_id'],'group':case['group']}; reason='none';status=None;selected=None
 # Fixture-specific planning decision; not a released selector/validator.
 try:t=rat(r['tau']);assert t>=0
 except (AssertionError,ValueError,TypeError):status='invalid_request';reason='invalid_tau'
 if not cs:status='invalid_request';reason='empty_candidates'
 ids=[c['stable_id'] for c in cs]
 if len(set(ids))!=len(ids):status='invalid_request';reason='duplicate_id'
 keys=[]
 for c in cs:
  if c.get('producer') and c['artifact_status']=='provided' and c['rhos'] is not None:
   keys.append(identity(c))
 if len(keys)!=len(set(keys)):status='invalid_request';reason='duplicate_content'
 if case['group']=='FIT-REAL':
  assert all(c['rhos'] is None and c['coefficients'] is None and 'producer_call' in c for c in cs)
  row.update(proof_role='future_only_no_arrays_or_outcome_claim',required_gate=case['expected']);rows.append(row);continue
 if status is None:
  sh=r['input']['shape'];n=sh[0];m=sh[1] if len(sh)==2 else 1
  unsupported=(r['operator'] not in ['GL','RL'] or rat(r['alpha'])!=F(1,2) or rat(r['dt'])!=F(1,4) or r['grid']!='uniform' or n>17 or m>3 or r['input']['dtype'].startswith('complex') or len(cs)>8 or t.numerator.bit_length()>256 or t.denominator.bit_length()>256)
  if unsupported:status='indeterminate';reason='unsupported_reference'
 assessments=[];mathcs=[];eligible_indices=[]
 if status is None:
  for ci,c in enumerate(cs):
   conf=c['configuration'];why=None;ast=None
   if c['artifact_status']!='provided':ast='unknown';why='missing_raw_artifact' if c['artifact_status']=='missing' else 'corrupt_raw_artifact'
   elif type(conf['n']) is not int or type(conf['pole_count']) is not int or type(conf['exact_head']) is not bool:ast='known_ineligible';why='invalid_type'
   elif conf['pole_count']>8:ast='unknown';why='unsupported_reference'
   elif any(conf[k]!=v for k,v in {'n':n,'kernel':'gl_prefix','method':'scaled_tail','exact_head':True,'alpha':r['alpha'],'dt':r['dt']}.items()):ast='known_ineligible';why='configuration_mismatch'
   elif any(c[k]['shape']!=[conf['pole_count']] for k in ['rhos','coefficients']):ast='known_ineligible';why='malformed_fit'
   else:
    rho=decode(c['rhos']);coef=decode(c['coefficients'])
    if any(type(a) is str for a in rho+coef):ast='known_ineligible';why='nonfinite_fit'
    elif any(a<0 for a in coef):ast='known_ineligible';why='negative_coefficient'
    elif any(a<=0 or a>1 for a in rho):ast='known_ineligible';why='invalid_rho'
    else:mathcs.append((rho,coef));eligible_indices.append(ci)
   assessments.append({'candidate_id':c['stable_id'],'status':ast,'reason':why})
  A=Arithmetic();shared,res=proof(decode(r['input']),n,m,mathcs,t,A)
  if not case['mutations'] and not case['resource_control']:pure+=1
  for ci,rr in zip(eligible_indices,res):
   assessments[ci].update(status='known_qualifying' if rr['qualifies'] else 'known_rejected_by_bound',reason='none');total_assess+=1;out_components+=n*m;grad_components+=n*m
  if any(a['status']=='unknown' for a in assessments):status='indeterminate';reason=next(a['reason'] for a in assessments if a['status']=='unknown')
  else:
   win=[(cs[i]['configuration']['pole_count'],cs[i]['stable_id']) for i in eligible_indices if assessments[i]['status']=='known_qualifying']
   status='selected' if win else 'no_supplied_candidate_meets_bound';selected=min(win)[1] if win else None
   if any(a['reason']!='none' for a in assessments):reason=next(a['reason'] for a in assessments if a['reason']!='none')
  # Evidence/resource controls are logical gates, not executed supervisor/fitter outcomes.
  if any(u['replace'].startswith('evidence/') for u in case['mutations']):status='indeterminate';selected=None;reason='incomplete_evidence'
  ctrl=case['resource_control']
  if ctrl:
   status='indeterminate';selected=None
   if ctrl.get('override_cap')=='rational_primitives':
    try:Arithmetic(cap=0).op('add',0,1)
    except Limit as e:reason=str(e)
   elif ctrl.get('override_cap')=='normalized_bits':
    try:Arithmetic(bits=1).op('div',1,2)
    except Limit as e:reason=str(e)
   elif ctrl.get('override_cap')=='evidence_bytes':assert ctrl['value']==p['caps']['input_bundle_bytes']+p['caps']['failure_index_bytes'];reason='evidence_cap'
   elif ctrl.get('override_cap')=='wall_seconds':reason='watchdog'
   else:assert ctrl['fault_checkpoint']=='after_candidate_index_0_commit_before_candidate_index_1';reason=ctrl['injected_reason'];assert res[0]['qualifies']
  row.update(assessments=assessments,primitives=A.n,max_normalized_bits=A.maxbits)
  raw.append(enc({'case_id':case['case_id'],'shared':shared,'eligible_candidate_indices':eligible_indices,'proofs':res,'operation_count':A.n,'categories':dict(A.categories),'max_bits':A.maxbits,'role':'stdlib exact synthetic planning; includes independent recurrence and rational-direction quadratic FD; not JAX evidence'}))
 row.update(computed_status=status,computed_selected_id=selected,computed_reason=reason)
 expect=case['expected'];row['expected_matches']=status==expect['request_status'] and selected==expect.get('selected_id') and reason==expect['reason']
 if expect.get('mutated_candidate_status'):row['expected_matches'] &= assessments[0]['status']==expect['mutated_candidate_status']
 if not row['expected_matches']:mismatches.append(row)
 rows.append(row)
save('all-544-case-outcomes.json',rows);save('synthetic-exact-raw.json',raw);save('expectation-mismatches.json',mismatches)
summary={'counts':counts,'cases_with_fraction_proofs':len(raw),'unmutated_uncontrolled_synthetic_cases':pure,'eligible_synthetic_candidate_proofs':total_assess,'output_components_crosschecked':out_components,'analytic_gradient_components':grad_components,'exact_quadratic_rational_direction_FD_equalities':total_assess,'future_only_cases':sum(c['group']=='FIT-REAL' for c in f['cases']),'expected_mismatches':len(mismatches),'max_fixture_schedule_operations':max(r.get('primitives',0) for r in rows),'no_jax_import_or_fit':True}
save('proof-summary.json',summary);print(json.dumps(summary,indent=2));print('MISMATCH',json.dumps(mismatches,indent=2)[:12000])
