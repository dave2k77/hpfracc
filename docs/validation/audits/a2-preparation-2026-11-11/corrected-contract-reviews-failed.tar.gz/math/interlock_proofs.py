"""Concrete contradictory constraints, not a general validator implementation."""
import json,pathlib
R=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc'); O=pathlib.Path(__file__).resolve().parent;A=R/'docs/validation/audits/a2-preparation-2026-11-11'
f=json.loads((A/'fixtures.json').read_text());s=json.loads((A/'record-schemas.json').read_text())
# A required full-output observation has no candidate, as distinct from slot-only storage.
full=[]
for c in f['cases']:
 for q in c['required_evidence_slots']:
  if q['quantity']=='full_output':
   assert q['candidate_index'] is None
   full.append({'case_id':c['case_id'],'slot_id':q['slot_id'],'mode':q['mode']})
assert len(full)==64
assert s['$defs']['observation']['properties']['candidate_id']['type']=='string'
# The exact malformed-fit slot reason required by fixtures is disallowed by the canonical predicate.
required=f['exact_slot_inventory']['for_known_ineligible']; canonical=s['x-canonical-parse-predicate'][5]
assert 'not_applicable with reason malformed_fit/configuration_mismatch' in required
assert 'not_applicable has null payload and explicit reason not_evaluated' in canonical
counterexample={'status':'not_applicable','raw_array':None,'exact_array':None,'reason':'malformed_fit'}
assert counterexample['reason']!='not_evaluated'
# Every supported/unsupported preinventory has input-shaped expectations. No N18 exception is specified.
unsupported=[]
for c in f['cases']:
 for u in c['mutations']:
  if u['replace']=='request/input' and u['value']['shape'][0]==18:
   assert c['expected']['request_status']=='indeterminate';assert c['expected']['reason']=='unsupported_reference'
   assert s['$defs']['index_slot']['properties']['expected_shape']['items']['maximum']==17
   unsupported.append({'case_id':c['case_id'],'B_expected_shape':[18],'N_lag_array_expected_shape':[18],'canonical_index_max_dimension':17})
assert len(unsupported)==4
r={'contract_passed':False,'full_observation_conflict':{'affected_observation_count':len(full),'affected_case_count':len({a['case_id'] for a in full}),'schema_pointer':'/$defs/observation/properties/candidate_id','expected':None,'actual_schema_type':'string','examples':full[:2]},'not_applicable_reason_conflict':{'fixture_key':'/exact_slot_inventory/for_known_ineligible','fixture_requirement':required,'schema_key':'/x-canonical-parse-predicate/5','schema_requirement':canonical,'concrete_slot_fragment':counterexample},'unsupported_failure_index_shapes':unsupported}
(O/'contract-interlocks-raw.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
