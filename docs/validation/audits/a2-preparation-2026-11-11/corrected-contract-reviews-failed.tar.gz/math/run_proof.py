import hashlib,json,os,pathlib,subprocess,sys,time
OUT=pathlib.Path(__file__).resolve().parent
script=OUT/sys.argv[1];label=sys.argv[2]
assert script.parent==OUT and script.is_file()
start=time.monotonic_ns()
r=subprocess.run([sys.executable,str(script)],cwd='/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc',env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0'},capture_output=True)
for k,b in [('stdout',r.stdout),('stderr',r.stderr)]: (OUT/(label+'.'+k+'.raw')).write_bytes(b)
receipt={'argv':[sys.executable,str(script)],'exit_code':r.returncode,'elapsed_monotonic_ns':time.monotonic_ns()-start,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'stdout_bytes':len(r.stdout),'stderr_bytes':len(r.stderr),'scope':'readonly repository stdlib preparation review; no fitter/JAX/AD/benchmark'}
(OUT/(label+'.process.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2));print(r.stdout.decode()[-8000:]);print(r.stderr.decode()[-4000:]);sys.exit(r.returncode)
