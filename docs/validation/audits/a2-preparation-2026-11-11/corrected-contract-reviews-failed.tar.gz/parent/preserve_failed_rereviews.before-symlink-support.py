"""Preserve rejected preparation bytes and both independent re-reviews."""
from __future__ import annotations

import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
HERE = Path(__file__).parent
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def identity(raw: bytes) -> dict:
    return {'sha256': sha(raw), 'bytes': len(raw)}


manifest_path = HERE / 'review-input-manifest.json'
manifest = json.loads(manifest_path.read_text())
assert sha(manifest_path.read_bytes()) == 'b87572830abd1f52e43ce08d6194e8c6b8ffcdfb9b956a0d5ff09a56390d8d95'
for name, expected in manifest['immutable_repository_files'].items():
    assert identity((ROOT / name).read_bytes()) == expected, name
for name, expected in manifest['protected_numerical_inputs'].items():
    assert sha((ROOT / name).read_bytes()) == expected, name
assert sha(subprocess.check_output(['git', 'ls-files', '--stage'], cwd=ROOT)) == manifest['protected_index_entries_sha256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == manifest['repo_head']

entries = {}
reviews = {}
for label, directory, count, verdict_name in [
    ('math', Path('/home/davianc/.hermes/cache/scratch/a2-math-independent-corrected-t2gfcgtl'), 60, 'verdict.json'),
    ('validation', Path('/home/davianc/.hermes/cache/scratch/a2-validation-schema-review-20261111'), 34, 'review-verdict.json'),
]:
    index_path = directory / 'evidence-index.json'
    index = json.loads(index_path.read_text())
    assert len(index['files']) == count
    for name, expected in index['files'].items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        path = directory / relative
        assert path.is_file() and not path.is_symlink(), path
        raw = path.read_bytes()
        assert identity(raw) == {'sha256': expected['sha256'], 'bytes': expected['bytes']}, path
        entries[label + '/' + name] = raw
    entries[label + '/evidence-index.json'] = index_path.read_bytes()
    for extra in ['evidence-index-verification.json', verdict_name]:
        if (directory / extra).is_file():
            entries[label + '/' + extra] = (directory / extra).read_bytes()
    verdict = json.loads((directory / verdict_name).read_text())
    assert verdict['passed'] is False
    assert verdict['reviewed_protocol_sha256'] == manifest['protocol_sha256']
    assert verdict['review_manifest_sha256'] == sha(manifest_path.read_bytes())
    reviews[label] = {
        'passed': False, 'indexed_files_verified': count,
        'verdict_sha256': sha((directory / verdict_name).read_bytes()),
        'index_sha256': sha(index_path.read_bytes()),
        'blocker_ids': [row['id'] for row in verdict['security_concerns'] + verdict['logic_errors']],
    }

# Preserve actual rejected packet/status bytes, not copies of nested old tars.
for name in manifest['immutable_repository_files']:
    path = ROOT / name
    if path.name in ['initial-contract-reviews-failed.tar.gz', 'initial-contract-reviews-preservation.json',
                     'corrected-draft-planning-evidence.tar.gz', 'corrected-draft-planning-preservation.json']:
        continue
    entries['reviewed-repo/' + name] = path.read_bytes()
entries['review-input-manifest.json'] = manifest_path.read_bytes()
for name in ['parent-preflight.json', 'parent-quality.json', 'parent-planning.process.json',
             'parent-planning.stdout.raw', 'parent-planning.stderr.raw', 'docs-tests.xml',
             'docs-tests.process.json', 'docs-tests.stdout.raw', 'docs-tests.stderr.raw',
             'strict-docs.process.json', 'strict-docs.stdout.raw', 'strict-docs.stderr.raw',
             'ruff.process.json', 'ruff.stdout.raw', 'ruff.stderr.raw']:
    entries['parent/' + name] = (HERE / name).read_bytes()
entries['parent/preserve_failed_rereviews.py'] = Path(__file__).read_bytes()
archive_path = AUDIT / 'corrected-contract-reviews-failed.tar.gz'
assert not archive_path.exists(), archive_path
with archive_path.open('wb') as raw_out:
    with gzip.GzipFile(filename='', fileobj=raw_out, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(entries.items()):
                item = tarfile.TarInfo(name)
                item.size = len(raw)
                item.mode = 0o644
                archive.addfile(item, io.BytesIO(raw))
with tarfile.open(archive_path, 'r:gz') as archive:
    members = {member.name: member for member in archive.getmembers()}
    assert set(members) == set(entries)
    for name, raw in entries.items():
        assert archive.extractfile(members[name]).read() == raw, name
record = {
    'scope': 'Rejected corrected A2 preparation contract; not a numerical implementation failure',
    'passed': False, 'implementation_authorized': False, 'a2_acceptance_passed': False,
    'reviewed_protocol_sha256': manifest['protocol_sha256'],
    'review_manifest_sha256': sha(manifest_path.read_bytes()),
    'archive': archive_path.name, 'archive_identity': identity(archive_path.read_bytes()),
    'reviews': reviews, 'files': {name: identity(raw) for name, raw in sorted(entries.items())},
    'protected_numerical_inputs_verified': len(manifest['protected_numerical_inputs']),
    'protected_repository_files_verified': len(manifest['immutable_repository_files']),
    'git_index_entries_unchanged': True,
}
record_path = AUDIT / 'corrected-contract-reviews-failed-preservation.json'
assert not record_path.exists()
record_path.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: record[key] for key in ['scope', 'archive_identity', 'reviews', 'protected_numerical_inputs_verified', 'protected_repository_files_verified']}, sort_keys=True))
print('ARCHIVE_MEMBERS_VERIFIED', len(entries))
