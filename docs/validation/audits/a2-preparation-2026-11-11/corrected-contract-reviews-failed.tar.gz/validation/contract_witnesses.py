"""Static contract contradiction and policy-size proofs; no worker execution."""
import ast
from fractions import Fraction
import hashlib
import json
import os
import pathlib
import re
import struct

ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=pathlib.Path(__file__).parent
A=ROOT/'docs/validation/audits/a2-preparation-2026-11-11'
s=json.loads((A/'record-schemas.json').read_bytes())
p=json.loads((A/'comparison-policies.json').read_bytes())
D=s['$defs']

# A lexical artifact path alone does not imply a rooted owned output target.
# This is a scratch-only counterexample, not an exploit of nonexistent code.
box=OUT/'path-ownership-witness'
request_root=box/'request-root'
other=box/'outside-request-root'
request_root.mkdir(parents=True,exist_ok=True)
other.mkdir(exist_ok=True)
link=request_root/'arrays'
if not link.is_symlink():link.symlink_to(other,target_is_directory=True)
rel='arrays/S-X-w.json'
resolved=(request_root/rel).resolve()
path_witness={
    'label':'scratch-only lexical-path counterexample; no target file opened or written',
    'relative_path':rel,
    'matches_frozen_artifact_path_regex':re.fullmatch(D['index_artifact']['properties']['path']['pattern'],rel) is not None,
    'symlink':str(link),'symlink_target':os.readlink(link),
    'resolved_target':str(resolved),'resolved_under_request_root':resolved.is_relative_to(request_root.resolve()),
}
assert path_witness['matches_frozen_artifact_path_regex'] and not path_witness['resolved_under_request_root']

# Counterexamples are type/shape predicates only, not fabricated observation data.
witnesses={
 'full_reference':{
     'schema_pointer':'/$defs/observation/properties/candidate_id',
     'schema':D['observation']['properties']['candidate_id'],
     'required_semantic_value':None,
     'required_value_has_schema_type':type(None) is str,
     'full_method_available': 'full' in D['configuration']['properties']['method']['enum'],
     'producer_kinds':D['producer']['properties']['kind']['enum'],
 },
 'unsupported_shape':{
     'schema_pointer':'/$defs/index_slot/properties/expected_shape/items/maximum',
     'N18_expected_shape':[18],
     'maximum':D['index_slot']['properties']['expected_shape']['items']['maximum'],
     'encodable':18<=D['index_slot']['properties']['expected_shape']['items']['maximum'],
 },
 'timing':{
     'schema_pointer':'/$defs/process',
     'all_fields':list(D['process']['properties']),
     'closed':D['process']['additionalProperties'] is False,
     'unrepresentable_additional_fields':['preflight_elapsed_ns','grace_elapsed_ns','kill_to_confirmed_exit_ns','failure_index_write_elapsed_ns'],
     'phase_record_schema_declared':any('phase' in k or 'timing' in k for k in D),
 },
 'standalone_slot':{
     'schema_root_alternatives':[x['$ref'] for x in s['oneOf']],
     'slot_root_branch_present':{'$ref':'#/$defs/slot'} in s['oneOf'],
     'every_root_alternative_requires_record_type':all('record_type' in D[x['$ref'].rsplit('/',1)[1]]['required'] for x in s['oneOf']),
     'slot_has_no_record_type_and_forbids_extra':'record_type' not in D['slot']['properties'] and D['slot']['additionalProperties'] is False,
 },
 'execution_provenance':{
     'observation_keys':list(D['observation']['properties']),
     'process_keys':list(D['process']['properties']),
     'slot_binding_hash_payload_schema_defined':any('producer_binding' in k for k in D),
     'explicit_observation_process_or_run_key':any('process' in k or 'run' in k for k in D['observation']['properties']),
 },
}

expected={
 'forward_recursive_exact':{'float32':('0.00002','0.00002'),'float64':('0.0000000001','0.0000000006')},
 'forward_full_exact':{'float32':('0.00002','0.00002'),'float64':('0.0000000001','0.0000000006')},
 'forward_eager_jit':{'float32':('0.00002','0.00002'),'float64':('0.0000000001','0.0000000006')},
 'input_grad_analytic':{'float32':('0.00002','0.00002'),'float64':('0.0000002','0.00000002')},
 'input_grad_eager_jit':{'float32':('0.00002','0.00002'),'float64':('0.0000002','0.00000002')},
 'order_grad_eager_jit':{'float32':('0.00002','0.00002'),'float64':('0.0000002','0.00000002')},
 'input_FD_AD':{'float32':('0.002','0.0002'),'float64':('0.000002','0.0000002')},
 'input_FD_adjacent':{'float32':('0.002','0.0002'),'float64':('0.000002','0.0000002')},
 'order_FD_AD':{'float32':('0.005','0.0005'),'float64':('0.00002','0.000002')},
 'order_FD_adjacent':{'float32':('0.005','0.0005'),'float64':('0.00002','0.000002')},
}
policy_proofs=[]
for policy in p['policies']:
    dtype,name=policy['policy_id'].split('-',1)
    values=[Fraction(int(policy[k]['num'],16),int(policy[k]['den'],16)) for k in ('rtol','atol')]
    eq=values==[Fraction(v) for v in expected[name][dtype]]
    assert eq
    policy_proofs.append({'policy_id':policy['policy_id'],'rtol_exact':str(values[0]),'atol_exact':str(values[1]),'matches_document_table':eq})
step_proofs=[]
for dtype,steps in p['FD_steps'].items():
    vals=[struct.unpack('<f' if dtype=='float32' else '<d',bytes.fromhex(a['raw_hex']))[0] for a in steps]
    eq=(vals==[1/128,1/256,1/512] if dtype=='float32' else vals==[float('1e-5')])
    assert eq
    step_proofs.append({'dtype':dtype,'decoded_step_float_hex':[v.hex() for v in vals],'matches_declared_steps':eq})

module=ast.parse((ROOT/'src/hpfracc/ops/_soe.py').read_text())
fit_class=next(x for x in module.body if isinstance(x,ast.ClassDef) and x.name=='_SOEFit')
fit_fn=next(x for x in module.body if isinstance(x,ast.FunctionDef) and x.name=='_fit_soe')
source={'SOEFit_fields':[x.target.id for x in fit_class.body if isinstance(x,ast.AnnAssign)],'fit_positional_args':[x.arg for x in fit_fn.args.args],'fit_keyword_args':[x.arg for x in fit_fn.args.kwonlyargs],'note':'AST only; no package/JAX import or numerical calls'}
assert source['SOEFit_fields']==['rhos','coefficients','n','kernel','method','exact_head']
assert 'dt' not in source['fit_positional_args']+source['fit_keyword_args']

result={'label':'Static schema/type/path/policy proofs only; contract readiness can fail despite proof execution exit 0','schema_witnesses':witnesses,'path_ownership_counterexample':path_witness,'all_20_document_policy_values_match':True,'policies':policy_proofs,'FD_step_encodings':step_proofs,'source_AST':source}
(OUT/'contract-contradictions.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2))
