"""Final read-only source pincheck and own scratch-proof hash-size readback."""
import hashlib
import json
import os
import pathlib
import subprocess

ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=pathlib.Path(__file__).parent
MANIFEST=pathlib.Path('/home/davianc/.hermes/cache/scratch/a2-corrected-review-20261111/review-input-manifest.json')
EXPECTED_MANIFEST='b87572830abd1f52e43ce08d6194e8c6b8ffcdfb9b956a0d5ff09a56390d8d95'

def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
mb=MANIFEST.read_bytes(); m=json.loads(mb)
before=json.loads((OUT/'pin-before.json').read_bytes())
files={}
for name,expected in m['immutable_repository_files'].items():
    raw=(ROOT/name).read_bytes()
    observed={'bytes':len(raw),'sha256':sha(raw)}
    files[name]={'expected':expected,'observed':observed,'matches':observed==expected,'matches_initial_observation':observed['bytes']==before['file_pins'][name]['actual_bytes'] and observed['sha256']==before['file_pins'][name]['actual_sha256']}
numerical={name:{'expected_sha256':expected,'observed_sha256':sha((ROOT/name).read_bytes())} for name,expected in m['protected_numerical_inputs'].items()}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
index=subprocess.check_output(['git','ls-files','--stage'],cwd=ROOT)
(OUT/'index-after.raw').write_bytes(index)
full_index_matches=sha(index)==m['protected_index_entries_sha256'] and index==(OUT/'index-before.raw').read_bytes()
# The first exploratory pin call additionally recorded a 125-path NUL-delimited
# subset. That is intentionally NOT the manifest's complete newline index.
subset=subprocess.check_output(['git','ls-files','--stage','-z','--',*sorted(m['protected_numerical_inputs'])],cwd=ROOT)
pin={'manifest_sha256':sha(mb),'manifest_matches':sha(mb)==EXPECTED_MANIFEST,'head':head,'head_matches':head==m['repo_head']==before['head'],'complete_index_sha256':sha(index),'complete_index_expected_sha256':m['protected_index_entries_sha256'],'complete_index_before_after_matches':full_index_matches,'initial_subset_index_encoding_note':'pin-before.json index_sha256 is the 125-path --stage -z subset, NOT the complete git ls-files --stage identity; complete index-before.raw was captured separately before packet proof execution','initial_subset_index_before_after_matches':sha(subset)==before['index_sha256'],'immutable_files_count':len(files),'immutable_files_all_match':all(v['matches'] and v['matches_initial_observation'] for v in files.values()),'numerical_files_count':len(numerical),'numerical_files_all_match':all(v['expected_sha256']==v['observed_sha256'] and before['numerical_pins'][name] for name,v in numerical.items()),'file_details':files,'numerical_details':numerical,'a2_acceptance_passed':False,'implementation_authorized':False}
pin['passed']=all(pin[k] for k in ('manifest_matches','head_matches','complete_index_before_after_matches','initial_subset_index_before_after_matches','immutable_files_all_match','numerical_files_all_match'))
save('final-pincheck.json',pin)
assert pin['passed'],pin
verdict=json.loads((OUT/'review-verdict.json').read_bytes())
assert type(verdict['passed']) is bool and verdict['passed'] is False
assert verdict['logic_errors'] and verdict['security_concerns']
assert verdict['a2_acceptance_passed'] is False and verdict['implementation_authorized'] is False
assert verdict['review_manifest_sha256']==sha(mb)
assert verdict['reviewed_protocol_sha256']==m['protocol_sha256']
for name in ('packet-proof.process.json','supplemental.process.json','contract-witnesses.process.json'):
    proc=json.loads((OUT/name).read_bytes())
    assert proc['exit_code']==0 and proc['confirmed_exit'] is True
for name in ('packet-proof.json','supplemental-proof.json'):
    proof=json.loads((OUT/name).read_bytes())
    assert not proof.get('check_failures',proof.get('errors'))

# This external index deliberately excludes itself and its own readback record.
excluded={'evidence-index.json','evidence-index-verification.json'}
entries={}
for base,dirs,names in os.walk(OUT,followlinks=False):
    bp=pathlib.Path(base)
    for name in list(dirs):
        target=bp/name
        if target.is_symlink():
            b=os.readlink(target).encode()
            entries[str(target.relative_to(OUT))]={'kind':'symlink_target_utf8','bytes':len(b),'sha256':sha(b)}
            dirs.remove(name)
    for name in names:
        target=bp/name;rel=str(target.relative_to(OUT))
        if rel in excluded:continue
        if target.is_symlink():b=os.readlink(target).encode();kind='symlink_target_utf8'
        else:b=target.read_bytes();kind='regular_file'
        entries[rel]={'kind':kind,'bytes':len(b),'sha256':sha(b)}
index_record={'purpose':'Own static-review proof hash/size index; not a worker/scientific certificate','base_directory':str(OUT),'excluded_records':sorted(excluded),'files':dict(sorted(entries.items())),'entry_count':len(entries)}
save('evidence-index.json',index_record)
readback=json.loads((OUT/'evidence-index.json').read_bytes())
assert readback==index_record
verified={}
for rel,expected in readback['files'].items():
    target=OUT/rel
    b=os.readlink(target).encode() if expected['kind']=='symlink_target_utf8' else target.read_bytes()
    verified[rel]={'matches':len(b)==expected['bytes'] and sha(b)==expected['sha256'],'bytes':len(b),'sha256':sha(b)}
assert all(x['matches'] for x in verified.values())
verification={'evidence_index_sha256':sha((OUT/'evidence-index.json').read_bytes()),'evidence_index_bytes':len((OUT/'evidence-index.json').read_bytes()),'verified_entry_count':len(verified),'all_indexed_hashes_sizes_match':True,'final_pincheck_passed':pin['passed'],'verdict_sha256':sha((OUT/'review-verdict.json').read_bytes()),'verdict_passed':verdict['passed'],'self_reference_exclusion':'This verification record and evidence-index.json are excluded from the indexed files. Their observed bytes/digests are reported by actual finalizer output.','verified_entries':verified}
save('evidence-index-verification.json',verification)
assert json.loads((OUT/'evidence-index-verification.json').read_bytes())==verification
for path in verdict['evidence_paths']:assert pathlib.Path(path).is_file(),path
print(json.dumps({k:v for k,v in verification.items() if k!='verified_entries'},indent=2))
print(json.dumps({'final_verification_record_sha256':sha((OUT/'evidence-index-verification.json').read_bytes()),'final_verification_record_bytes':len((OUT/'evidence-index-verification.json').read_bytes()),'final_pin_counts':{'immutable_files':len(files),'numerical_files':len(numerical)},'head':head,'complete_index_sha256':sha(index)},indent=2))
