"""Bounded read-only preparation proofs, not a worker/validator/selector.

Uses only Python stdlib. Outputs template metadata, never observations.
"""
import collections
import copy
from fractions import Fraction
import hashlib
import json
import math
import pathlib
import re
import struct
import subprocess
import tarfile

ROOT = pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = pathlib.Path(__file__).parent
A = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'

def digest(b):
    return hashlib.sha256(b).hexdigest()

def pairs(items):
    out = {}
    for key, val in items:
        if key in out:
            raise ValueError('duplicate key')
        out[key] = val
    return out

def load(name):
    return json.loads((A / name).read_bytes(), object_pairs_hook=pairs)

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def compact(value):
    return json.dumps(value, separators=(',', ':'), ensure_ascii=True).encode('ascii')

f = load('fixtures.json')
p = load('protocol.json')
s = load('record-schemas.json')
cp = load('comparison-policies.json')
D = s['$defs']
errors = []
checks = collections.Counter()

def require(ok, key, info):
    checks[key] += 1
    if not ok:
        errors.append({'key': key, 'info': info})

# Verify every packet raw descriptor, including scalar/FD/mutation controls.
def raw(descriptor, where):
    b = bytes.fromhex(descriptor['raw_hex'])
    dtype = descriptor['dtype']
    size = {'float32':4, 'float64':8, 'complex64':8, 'complex128':16}[dtype]
    require(len(b) == descriptor['nbytes'] == math.prod(descriptor['shape']) * size, 'raw_length_shape', where)
    require(digest(b) == descriptor['sha256'], 'raw_sha256', where)
    require(descriptor['byte_order'] in ('little', 'big') and descriptor['layout'] == 'C', 'raw_layout', where)
    require(len(b) <= 4096 and len(descriptor['shape']) <= 2, 'raw_decode_bounds', where)
    return b

for name, a in f['arrays'].items():
    raw(a, 'arrays/' + name)
for dtype, scalars in f['working_scalars'].items():
    for key, a in scalars.items():
        raw(a, 'working_scalars/' + dtype + '/' + key)
for dtype, steps in cp['FD_steps'].items():
    for i, a in enumerate(steps):
        raw(a, 'FD_steps/' + dtype + '/' + str(i))
for case in f['cases']:
    for i, mut in enumerate(case['mutations']):
        val = mut['value']
        if type(val) is dict and 'raw_hex' in val:
            raw(val, case['case_id'] + '/mutations/' + str(i))

# Frozen rationals are checked as strings before conversion. Negative/type
# controls are intentionally recorded, not coerced or admitted as valid inputs.
rational_inventory = []
def walk(value, path):
    if isinstance(value, dict):
        if set(value) == {'num', 'den'}:
            n, d = value['num'], value['den']
            canonical = (type(n) is str and type(d) is str
                         and len(n) <= 8193 and len(d) <= 8192
                         and re.fullmatch(r'(0|-?[1-9a-f][0-9a-f]*)', n) is not None
                         and re.fullmatch(r'[1-9a-f][0-9a-f]*', d) is not None)
            if canonical:
                ni, di = int(n,16), int(d,16)
                canonical = math.gcd(abs(ni),di) == 1 and (ni != 0 or di == 1)
            rational_inventory.append({'path':path, 'canonical':canonical})
        else:
            for k, v in value.items():
                walk(v, path + '/' + k)
    elif isinstance(value, list):
        for i, v in enumerate(value):
            walk(v, path + '/' + str(i))
walk(f, 'fixtures')
walk(cp, 'comparison-policies')
walk(p, 'protocol')
require(all(x['canonical'] or '/mutations/' in x['path'] for x in rational_inventory), 'canonical_declared_rationals_except_negative_controls', '')

policies = {x['policy_id']: x for x in cp['policies']}
require(len(policies) == 20, 'policy_identity_count', len(policies))
rows = []
missing_expanded_mutation_targets = []
shape_conflicts = []
null_full_observations = []
working_policy_counts = collections.Counter()
fit_check_count = 0
case_ids = set()
for ci, case in enumerate(f['cases']):
    cid = case['case_id']
    require(cid not in case_ids, 'unique_case_id', cid)
    case_ids.add(cid)
    req = case['request']
    require(req['input_ref'] in f['arrays'], 'input_ref', cid)
    refs = req['candidate_refs']
    require(all(x in f['candidates'] for x in refs), 'candidate_refs', cid)
    ids = [f['candidates'][x]['stable_id'] for x in refs]
    slots = case['required_evidence_slots']
    byid = {x['slot_id']:x for x in slots}
    require(len(slots) == len(byid), 'unique_slot_id', cid)
    require(all(x['initial_status'] == 'not_evaluated' for x in slots), 'initial_slot_status', cid)
    for x in slots:
        idx = x['candidate_index']
        require(idx is None or type(idx) is int and 0 <= idx < len(refs), 'slot_candidate_index', [cid,x['slot_id']])
        require(x['quantity'] in D['slot']['properties']['quantity']['enum'], 'slot_quantity_enum', [cid,x['slot_id']])
        require(x['mode'] in D['slot']['properties']['mode']['enum'], 'slot_mode_enum', [cid,x['slot_id']])
        require(re.fullmatch(D['id']['pattern'], x['slot_id']) is not None, 'slot_id_grammar', [cid,x['slot_id']])
    comps = case.get('required_working_comparisons', [])
    require(len({x['comparison_id'] for x in comps}) == len(comps), 'comparison_id_unique', cid)
    for comp in comps:
        require(comp['policy_id'] in policies, 'comparison_policy_ref', [cid,comp['comparison_id']])
        working_policy_counts[comp['policy_id']] += 1
        for name in ('a_slot_id','reference_slot_id'):
            ref = comp[name]
            require(ref is None or ref in byid, 'comparison_operand_ref', [cid,comp['comparison_id'],name,ref])
        if comp['a_slot_id'] is None or comp['reference_slot_id'] is None:
            require(comp['policy_id'].endswith('_FD_adjacent') and 'f64' in cid, 'only_f64_adjacency_has_null_refs', [cid,comp['comparison_id']])
        elif 'forward_full_exact' in comp['policy_id']:
            require(comp['candidate_index'] is None and byid[comp['a_slot_id']]['candidate_index'] is None, 'full_is_candidate_free', cid)
        else:
            require(all(byid[comp[k]]['candidate_index'] == comp['candidate_index'] for k in ('a_slot_id','reference_slot_id')), 'comparison_candidate_binding', [cid,comp['comparison_id']])
    fitchecks = case.get('required_fit_identity_checks', [])
    fit_check_count += len(fitchecks)
    check_keys = [(x['mode'],x['candidate_index'],x['branch'],x['reference_branch'],x['comparison']) for x in fitchecks]
    require(len(check_keys) == len(set(check_keys)), 'unique_fit_checks', cid)
    for x in fitchecks:
        require(x['comparison'] in D['binding_check']['properties']['comparison']['enum'], 'fit_check_enum', [cid,x])
        for branch in (x['branch'], x['reference_branch']):
            for quantity in ('rhos','coefficients','input','alpha','dt'):
                require(any(y['mode'] == x['mode'] and y['candidate_index'] == x['candidate_index'] and y['branch'] == branch and y['quantity'] == quantity for y in slots), 'fit_check_branch_quantity_binding', [cid,x,branch,quantity])
    if case['group'] == 'FIT-REAL':
        a = f['arrays'][req['input_ref']]
        b = bytes.fromhex(a['raw_hex'])
        vals = struct.unpack('<' + ('f' if a['dtype']=='float32' else 'd') * (len(b)//(4 if a['dtype']=='float32' else 8)), b)
        require(any(v != 0 for v in vals) and a['shape'] in ([17],[17,3]), 'fit_real_nonzero_n17_shape', cid)
        require([f['candidates'][x]['configuration']['pole_count'] for x in refs] == [8,2,4], 'fit_real_pole_order', cid)
        require(req['tau'] in ({'num':'0','den':'1'},{'num':'1','den':'1'}), 'fit_real_tau0_tau1', cid)
        require(case['expectation_role']=='future_observation_stop_gate_not_observed_attainability', 'fit_real_no_attainability', cid)
        require({(x['mode'],x['candidate_index']) for x in slots if x['branch']=='base' and x['quantity']=='rhos'} == {(m,i) for m in ('eager','jit') for i in range(3)}, 'each_mode_each_base_fit', cid)
        fulls = [x for x in slots if x['quantity']=='full_output']
        null_full_observations += [{'case_id':cid,'slot_id':x['slot_id'],'candidate_id':None} for x in fulls]
        step_count = len(cp['FD_steps'][a['dtype']])
        if req['tau']['num']=='1':
            for mode in ('eager','jit'):
                for idx in range(3):
                    for kind in ('input','order'):
                        for h in range(step_count):
                            require(any(x['candidate_index']==idx and x['mode']==mode and x['policy_id']==a['dtype']+'-'+kind+'_FD_AD' and x['branch']==kind+'-h'+str(h) for x in comps), 'all_declared_FD_steps', [cid,mode,idx,kind,h])
                        for h in range(step_count-1):
                            require(any(x['candidate_index']==idx and x['mode']==mode and x['policy_id']==a['dtype']+'-'+kind+'_FD_adjacent' and x['a_slot_id']==f'{mode}-{idx}-{kind}-h{h+1}-FD' and x['reference_slot_id']==f'{mode}-{idx}-{kind}-h{h}-FD' for x in comps), 'all_adjacent_reference_direction', [cid,mode,idx,kind,h])
            # Real-worker descriptive branch list omits ad-base even though exact
            # case inventory correctly includes it; retain this inconsistency.
    # Check declared mutation ordering literally: expanded canonical request has
    # candidates, never candidate_refs. Record pointers that cannot then apply.
    for mut in case['mutations']:
        if mut['replace'] == 'request/candidate_refs':
            missing_expanded_mutation_targets.append({'case_id':cid,'pointer':mut['replace'],'value':mut['value']})
    input_shape = f['arrays'][req['input_ref']]['shape']
    for mut in case['mutations']:
        if mut['replace'] == 'request/input' and isinstance(mut['value'],dict):
            input_shape = mut['value']['shape']
    if any(v > D['index_slot']['properties']['expected_shape']['items']['maximum'] for v in input_shape):
        shape_conflicts.append({'case_id':cid,'input_shape':input_shape,'unencodable_slots':[x['slot_id'] for x in slots if x['quantity'] in ('v','D','D_hat','B','analytic_input_gradient','L_hat','w','g')]})
    rows.append({'case_index':ci,'case_id':cid,'group':case['group'],'slots':len(slots),'comparisons':len(comps),'fit_checks':len(fitchecks),'input_shape_after_mutations':input_shape,'candidate_ids_before_mutations':ids})

require(len(rows)==544, 'case_count', len(rows))
require(sum(x['slots'] for x in rows)==24128, 'slot_count', '')
require(sum(x['comparisons'] for x in rows)==1312, 'working_comparison_count', '')
require(fit_check_count==1056, 'fit_identity_check_count', fit_check_count)
require(max(x['slots'] for x in rows)==954, 'max_slots', '')

# Source/configuration pin checks for every declared candidate; future actual
# candidates explicitly have no observed arrays or fabricated runtime producer.
future = []
source_bindings = []
for name,cand in f['candidates'].items():
    prod = cand.get('producer', cand.get('producer_call'))
    src = prod['source']
    require(digest((ROOT/src['repo_path']).read_bytes())==src['sha256'], 'candidate_source_binding', name)
    require(prod['lock_sha256']==digest((ROOT/'uv.lock').read_bytes()), 'candidate_lock_binding', name)
    if 'producer_call' in cand:
        future.append(name)
        require(cand['rhos_ref'] is None and cand['coefficients_ref'] is None and cand['artifact_status']=='not_evaluated', 'future_fit_has_no_arrays', name)
    else:
        require(prod['policy_id']==p['protocol_id'], 'synthetic_policy_binding', name)
        require(cand['rhos_ref'] in f['arrays'] and cand['coefficients_ref'] in f['arrays'], 'synthetic_candidate_array_refs', name)
    source_bindings.append({'name':name,'source':src})
require(len(future)==12, 'future_candidate_count', len(future))

# Independently form the exact ID-free descriptor tuple in the four declared
# identity controls. This is identity arithmetic only, not selection.
def identity(name, rho=None, coef=None):
    cand=f['candidates'][name]
    arrays=[rho or f['arrays'][cand['rhos_ref']],coef or f['arrays'][cand['coefficients_ref']]]
    return compact([cand['configuration'],cand['producer'],*[{k:a[k] for k in p['identity']['array_descriptor_fields']} for a in arrays]])
identity_witnesses=[]
for ctrl in f['identity_controls']:
    if ctrl['case_id']=='IDENTITY-signed-zero':
        base=copy.deepcopy(f['arrays'][f['candidates'][ctrl['base_candidate_ref']]['coefficients_ref']])
        args=[]
        for h in (ctrl['left_hex'],ctrl['right_hex']):
            a=base|{'raw_hex':h,'sha256':digest(bytes.fromhex(h))}
            args.append(identity(ctrl['base_candidate_ref'],coef=a))
        eq=args[0]==args[1]
    elif ctrl['case_id']=='IDENTITY-pole-permutation':
        name=ctrl['candidate_ref']; cand=f['candidates'][name]; args=[]
        for field in ('rhos_ref','coefficients_ref'):
            a=copy.deepcopy(f['arrays'][cand[field]])
            b=bytes.fromhex(a['raw_hex']); size=8
            a['raw_hex']=b''.join(b[i*size:(i+1)*size] for i in ctrl['permutation']).hex()
            a['sha256']=digest(bytes.fromhex(a['raw_hex'])); args.append(a)
        eq=identity(name)==identity(name,rho=args[0],coef=args[1])
    else:
        eq=identity(ctrl['candidate_refs'][0])==identity(ctrl['candidate_refs'][1])
    identity_witnesses.append({'case_id':ctrl['case_id'],'equal_id_free_tuple':eq})
require([x['equal_id_free_tuple'] for x in identity_witnesses]==[False,False,False,True], 'all_identity_controls', identity_witnesses)

# Bounded compact metadata templates. Digests below are explicit size-only
# placeholders, not hashes or observations. No complete numerical arrays exist.
def shape_for(case, slot):
    shape=f['arrays'][case['request']['input_ref']]['shape']
    for m in case['mutations']:
        if m['replace']=='request/input' and isinstance(m['value'],dict): shape=m['value']['shape']
    n=shape[0]
    q=slot['quantity']
    if q in ('w','g','g_hat','residual','signed_fitted_weights'): return [n]
    if q=='L_hat':return [n,n]
    if q in ('epsilon','alpha','dt','h','objective','order_AD','directional_AD','input_FD','order_FD'):return []
    if q in ('rhos','coefficients','zero_pattern'):
        ref=case['request']['candidate_refs'][slot['candidate_index']]
        return [f['candidates'][ref]['configuration']['pole_count']]
    return shape

process={'record_type':'process','run_id':'size-template-only','command':['not-executed'], 'exit_code':None,'termination':'not_launched','elapsed_monotonic_ns':None,'watchdog_triggered':False,'stdout_sha256':None,'stderr_sha256':None,'stdout_truncated':False,'stderr_truncated':False}
templates=[]
for case in f['cases']:
    candidate_ids=[f['candidates'][x]['stable_id'] for x in case['request']['candidate_refs']]
    idx=[]; inventory=[]; worst=[]
    for slot in case['required_evidence_slots']:
        entry={k:slot[k] for k in ('slot_id','mode','branch','quantity')}
        entry['candidate_id']=None if slot['candidate_index'] is None else candidate_ids[slot['candidate_index']]
        inventory.append(entry)
        row=entry|{'status':'not_evaluated','reason':'not_evaluated','expected_shape':shape_for(case,slot),'completed_shape':None,'artifact':None}
        idx.append(row)
        worst.append(row|{'status':'complete','reason':'none','completed_shape':row['expected_shape'],'artifact':{'path':'arrays/'+slot['slot_id']+'.json','bytes':16777216,'sha256':'0'*64}})
    record={'record_type':'failure_index','request_id':case['case_id'],'input_bundle_sha256':'0'*64,'candidate_ids':candidate_ids,'slots':idx,'status':'not_evaluated','reasons':['not_evaluated'],'process':process}
    size0=len(compact(record)); record['slots']=worst; size1=len(compact(record))
    templates.append({'case_id':case['case_id'],'slots':len(idx),'inventory_compact_bytes':len(compact(inventory)),'initial_failure_index_bytes':size0,'all_complete_descriptor_template_bytes':size1,'fits_512KiB':max(size0,size1)<=524288})
max_template=max(templates,key=lambda x:x['all_complete_descriptor_template_bytes'])
# Semantic representation witnesses directly against the frozen clauses.
representation={
    'full_observations_candidate_id_required_type':D['observation']['properties']['candidate_id'],
    'full_observations_declared_null_count':len(null_full_observations),
    'null_full_observation_examples':null_full_observations[:4],
    'standalone_slot_is_root_alternative':any(x['$ref']=='#/$defs/slot' for x in s['oneOf']),
    'slot_requires_record_type':'record_type' in D['slot']['properties'],
    'index_shape_maximum':D['index_slot']['properties']['expected_shape']['items']['maximum'],
    'unsupported_N18_unencodable_shapes':shape_conflicts,
    'expanded_candidate_refs_mutation_targets_absent':missing_expanded_mutation_targets,
    'process_fields':list(D['process']['properties']),
    'process_accepts_separate_preflight_grace_kill_timing_fields':D['process']['additionalProperties'],
    'observation_has_run_or_process_reference':any('run' in k or 'process' in k for k in D['observation']['properties']),
    'binding_payload_schema_declared':any('producer_binding' in k for k in D),
    'real_worker_descriptive_branch_lists':f['real_worker_inventory']['branches'],
    'ad_base_present_in_exact_cases':any(x['branch']=='ad-base' for ca in f['cases'] for x in ca['required_evidence_slots']),
}
# Verify both archives against preservation manifests without extracting or
# executing any member. Store actual full member hash-size index for readback.
archive_proofs={}
for archive in ('initial-contract-reviews-failed.tar.gz','corrected-draft-planning-evidence.tar.gz'):
    with tarfile.open(A/archive) as t:
        index={m.name:{'bytes':m.size,'sha256':digest(t.extractfile(m).read())} for m in t.getmembers() if m.isfile()}
    archive_proofs[archive]={'sha256':digest((A/archive).read_bytes()),'members':index,'member_count':len(index)}

result={'scope':'Purestdlib static packet/read-only identity and bounded metadata proofs; no JAX or numerical worker; no validator/selector implementation', 'counts':{'cases':len(rows),'evidence_slots':sum(x['slots'] for x in rows),'working_comparisons':sum(x['comparisons'] for x in rows),'fit_checks':fit_check_count,'max_slots':max(x['slots'] for x in rows),'future_specs_without_arrays':len(future)},'checks':dict(checks),'check_failures':errors,'policy_comparison_counts':dict(working_policy_counts),'identity_controls':identity_witnesses,'representation_witnesses':representation,'max_compact_size_only_template':max_template,'templates_over_512KiB':sum(not x['fits_512KiB'] for x in templates),'rational_records_examined':len(rational_inventory),'noncanonical_rational_negative_control_count':sum(not x['canonical'] for x in rational_inventory)}
dump('packet-proof.json',result)
dump('case-binding-proof.json',rows)
dump('bounded-index-templates.json',templates)
dump('archive-member-proof.json',archive_proofs)
print(json.dumps({k:v for k,v in result.items() if k not in ('representation_witnesses','checks')},indent=2))
print('CHECK_FAILURES',len(errors))
print('REPRESENTATION_WITNESSES',json.dumps(representation,indent=2))
assert not errors, errors[:10]
