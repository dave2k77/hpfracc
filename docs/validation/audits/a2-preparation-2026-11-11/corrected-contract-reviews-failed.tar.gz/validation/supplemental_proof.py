"""Additional bounded static witnesses; not an implementation or observation."""
import collections
import hashlib
import json
import math
import pathlib
import re
import struct
import tarfile

ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=pathlib.Path(__file__).parent
A=ROOT/'docs/validation/audits/a2-preparation-2026-11-11'
f=json.loads((A/'fixtures.json').read_bytes())
p=json.loads((A/'protocol.json').read_bytes())
s=json.loads((A/'record-schemas.json').read_bytes())
c=json.loads((A/'comparison-policies.json').read_bytes())
checks=collections.Counter()
errors=[]
def check(ok,name,context):
    checks[name]+=1
    if not ok:errors.append({'check':name,'context':context})
def sha(b):return hashlib.sha256(b).hexdigest()
def compact(v):return json.dumps(v,separators=(',',':')).encode('ascii')

# Every policy operand/reference pair resolves to the right quantity and mode,
# not merely to any existing slot. Every returned-fit branch has its own check.
quantity_pairs={
 'forward_recursive_exact':('output','D_hat'),
 'forward_full_exact':('full_output','D'),
 'forward_eager_jit':('output','output'),
 'input_grad_analytic':('input_AD','analytic_input_gradient'),
 'input_grad_eager_jit':('input_AD','input_AD'),
 'order_grad_eager_jit':('order_AD','order_AD'),
 'input_FD_AD':('directional_AD','input_FD'),
 'input_FD_adjacent':('input_FD','input_FD'),
 'order_FD_AD':('order_AD','order_FD'),
 'order_FD_adjacent':('order_FD','order_FD'),
}
mode_branch_counts={}
input_templates=[]
full_observations=[]
for case in f['cases']:
    cid=case['case_id']; slots={x['slot_id']:x for x in case['required_evidence_slots']}
    dtype=f['arrays'][case['request']['input_ref']]['dtype']
    for cmp in case.get('required_working_comparisons',[]):
        if cmp['a_slot_id'] is None:continue
        dt,policy=cmp['policy_id'].split('-',1)
        a,r=(slots[cmp[x]] for x in ('a_slot_id','reference_slot_id'))
        check(dt==dtype,'policy_dtype_matches_input',[cid,cmp['comparison_id']])
        check((a['quantity'],r['quantity'])==quantity_pairs[policy],'policy_operand_quantities',[cid,cmp['comparison_id']])
        if 'eager_jit' in policy:
            check(a['mode']=='jit' and r['mode']=='eager','cross_mode_operand_direction',[cid,cmp['comparison_id']])
        else:
            check(a['mode']==cmp['mode'] and r['mode'] in (cmp['mode'],'shared'),'same_mode_reference',[cid,cmp['comparison_id']])
        if 'grad' in policy or policy.endswith('_FD_AD'):
            check(a['branch']=='ad-base','AD_comes_from_ad_base',[cid,cmp['comparison_id']])
    if case['group']!='FIT-REAL':continue
    branches={(x['mode'],x['candidate_index'],x['branch']) for x in slots.values() if x['quantity']=='rhos'}
    bindings={(x['mode'],x['candidate_index'],x['branch']) for x in case['required_fit_identity_checks']}
    check(branches==bindings,'every_actual_fit_branch_has_check',cid)
    mode_branch_counts[cid]={'actual_fit_branches':len(branches),'fit_checks':len(bindings)}
    for mode,idx,branch in branches:
        quantities={x['quantity'] for x in slots.values() if (x['mode'],x['candidate_index'],x['branch'])==(mode,idx,branch)}
        check(set(f['real_worker_inventory']['each_branch_required_quantities'])<=quantities,'every_branch_aux_quantity', [cid,mode,idx,branch])
    # Input capture size-only template: raw declaration contains ONLY provided
    # spec data; null canonical request explicitly avoids inventing runtime context.
    request=case['request']|{'input':f['arrays'][case['request']['input_ref']], 'candidates':[f['candidates'][x] for x in case['request']['candidate_refs']]}
    request={k:v for k,v in request.items() if k not in ('input_ref','candidate_refs','caps_ref')}
    raw=compact(request)
    inventory=[]
    ids=[f['candidates'][x]['stable_id'] for x in case['request']['candidate_refs']]
    for x in slots.values():
        inventory.append({k:x[k] for k in ('slot_id','mode','branch','quantity')}|{'candidate_id':None if x['candidate_index'] is None else ids[x['candidate_index']]})
    bundle={'record_type':'input_bundle','request':None,'sources':[{'repo_path':'src/hpfracc/ops/_soe.py','sha256':sha((ROOT/'src/hpfracc/ops/_soe.py').read_bytes())}], 'required_slots':inventory,'raw_request_utf8_hex':raw.hex(),'raw_request_sha256':sha(raw),'candidate_ids':ids}
    input_templates.append({'case_id':cid,'label':'bounded size-only future-spec raw capture, no runtime producer/arrays invented','raw_spec_request_bytes':len(raw),'input_bundle_compact_bytes':len(compact(bundle)),'fits_256KiB':len(compact(bundle))<=262144})
    for x in slots.values():
        if x['quantity']=='full_output':
            full_observations.append({'case_id':cid,'slot':x['slot_id'],'declared_candidate_id':None,'observation_candidate_id_schema_type':s['$defs']['observation']['properties']['candidate_id']['type']})

# Execute only tiny parser-control predicates, not the future bounded decoder.
parser_witness=[]
for control in f['parse_controls']:
    raw=bytes.fromhex(control['raw_utf8_hex'])
    assert len(raw)<1024
    check(sha(raw)==control['sha256'],'parse_control_raw_hash',control['case_id'])
    err=None
    def hook(items):
        d={}
        for k,v in items:
            if k in d:raise ValueError('reject_duplicate_key')
            d[k]=v
        return d
    def nonfinite(token):raise ValueError('reject_nonfinite_json')
    try:
        v=json.loads(raw,object_pairs_hook=hook,parse_constant=nonfinite)
        if 'n' in v and type(v['n']) is not int:err='reject_integer_type'
        elif 'exact_head' in v and type(v['exact_head']) is not bool:err='reject_boolean_type'
        elif set(v)=={'num','den'}:
            n,d=v['num'],v['den']
            ok=re.fullmatch(r'(0|-?[1-9a-f][0-9a-f]*)',n) and re.fullmatch(r'[1-9a-f][0-9a-f]*',d)
            if ok:
                ni,di=int(n,16),int(d,16)
                ok=math.gcd(abs(ni),di)==1 and (ni!=0 or di==1)
            if not ok:err='reject_rational'
    except ValueError as exc:err=str(exc)
    check(err==control['expected'],'parse_control_expected_disposition',control['case_id'])
    parser_witness.append({'case_id':control['case_id'],'actual_tiny_control_predicate':err,'expected':control['expected']})

# Check the archival index against every archived byte, never executing code.
archives=[]
for aname,pname in [('initial-contract-reviews-failed.tar.gz','initial-contract-reviews-preservation.json'),('corrected-draft-planning-evidence.tar.gz','corrected-draft-planning-preservation.json')]:
    preservation=json.loads((A/pname).read_bytes())
    expected=preservation['files']
    with tarfile.open(A/aname) as t:
        actual={m.name:{'bytes':m.size,'sha256':sha(t.extractfile(m).read())} for m in t.getmembers() if m.isfile()}
    check(actual==expected,'all_preserved_archive_members',aname)
    archives.append({'archive':aname,'members':len(actual),'all_expected_hashes_and_sizes_match':actual==expected})

# Structural witnesses; applying ordered replace after ref expansion cannot
# reach candidate_refs, and root schema does not include the standalone slot.
mutation_witnesses=[]
for case in f['cases']:
    for m in case['mutations']:
        if m['replace']!='request/candidate_refs':continue
        expanded={k:v for k,v in case['request'].items() if k not in ('input_ref','candidate_refs','caps_ref')}
        expanded['input']=f['arrays'][case['request']['input_ref']]
        expanded['candidates']=[f['candidates'][ref] for ref in case['request']['candidate_refs']]
        expanded['caps']=p['caps']
        mutation_witnesses.append({'case_id':case['case_id'],'ordered_replace_pointer':m['replace'],'exists_after_declared_expansion':'candidate_refs' in expanded,'canonical_candidates_remain':len(expanded['candidates'])})

result={'scope':'Static proofs and size-only templates, no observations/fit/app/AD/selector or bounded decoder implementation','checks':dict(checks),'errors':errors,'parser_controls':parser_witness,'archives':archives,'mode_branch_counts':mode_branch_counts,'all_actual_branches_source_aux_bound':not errors,'full_observation_null_type_conflicts':full_observations,'mutation_order_witnesses':mutation_witnesses,'max_input_capture_size_only_template':max(input_templates,key=lambda x:x['input_bundle_compact_bytes']),'all_input_templates_fit':all(x['fits_256KiB'] for x in input_templates),'transient_integer_bits':{'normalized_operand_cap':32768,'unreduced_product_maximum_bits':32768*2,'scope':'simple product upper bound, not GCD/wall/peak-memory guarantee'}}
(OUT/'supplemental-proof.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
(OUT/'input-size-templates.json').write_text(json.dumps(input_templates,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('mode_branch_counts','full_observation_null_type_conflicts')},indent=2))
assert not errors, errors
