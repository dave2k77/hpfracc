"""Read-only packet introspection; no numerical worker or implementation."""
import collections
import hashlib
import json
import pathlib
import subprocess
import tarfile

ROOT = pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = pathlib.Path(__file__).parent
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'

def load(name):
    return json.loads((AUDIT / name).read_bytes())

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')

f = load('fixtures.json')
p = load('protocol.json')
s = load('record-schemas.json')
c = load('comparison-policies.json')
with tarfile.open(AUDIT / 'initial-contract-reviews-failed.tar.gz') as t:
    verdicts = {n: json.loads(t.extractfile(n).read()) for n in ('math/verdict.json', 'validation/review-verdict.json')}
save('initial-failed-verdicts.json', verdicts)
summary = {
    'counts_declared': f['counts'],
    'groups': dict(collections.Counter(x['group'] for x in f['cases'])),
    'case_keys': sorted(set().union(*(set(x) for x in f['cases']))),
    'slot_count': sum(len(x['required_evidence_slots']) for x in f['cases']),
    'case_summaries': [
        {k: v for k, v in x.items() if k not in ('required_evidence_slots', 'working_comparison_slots', 'fit_binding_checks')}
        | {'slots': len(x['required_evidence_slots']),
           'working_comparison_slots': x.get('working_comparison_slots', []),
           'fit_binding_checks': x.get('fit_binding_checks', [])}
        for x in f['cases']
    ],
    'exact_slot_inventory': f['exact_slot_inventory'],
    'real_worker_inventory': f['real_worker_inventory'],
    'parse_controls': f['parse_controls'],
    'identity_controls': f['identity_controls'],
    'shortcut_controls': f['shortcut_controls'],
}
save('packet-introspection.json', summary)
firsts = {}
for case in f['cases']:
    firsts.setdefault(case['group'], case)
save('representative-cases.json', firsts)
index_bytes = subprocess.check_output(['git', 'ls-files', '--stage'], cwd=ROOT)
(OUT / 'index-before.raw').write_bytes(index_bytes)
print('FULL_INDEX_SHA256', hashlib.sha256(index_bytes).hexdigest())
print('COUNTS', json.dumps(summary['counts_declared'], sort_keys=True))
print('CASE_KEYS', summary['case_keys'])
print('REAL_WORKER_INVENTORY', json.dumps(f['real_worker_inventory'], indent=2))
print('PARSE_CONTROLS', json.dumps(f['parse_controls'], indent=2))
print('IDENTITY_CONTROLS', json.dumps(f['identity_controls'], indent=2))
print('INITIAL_FAILURES', json.dumps({k: {n:v.get(n) for n in ('passed','security_concerns','logic_errors','summary')} for k,v in verdicts.items()}, indent=2))
print('SCHEMA_REQUIRED', json.dumps({k: v.get('required') for k,v in s['$defs'].items() if 'required' in v}, indent=2))
print('FIRST_REAL_NONINVENTORY', json.dumps({k:v for k,v in firsts['FIT-REAL'].items() if k != 'required_evidence_slots'},indent=2))
