"""Canonical-type controls for the added fixed local authority only.

This does not claim an arbitrary-authority endpoint. It probes the new helper's
promised full pinned case/scalar/witness identity with copied, type-only changes.
No implementation or fixture is repaired.
"""
import copy
import json
from independent_probe import audit, enc, OUT, save, sha
from frozen_case import authenticate

baseline=copy.deepcopy(audit.AUTHORITY)
base_trace=audit.make_trace();audit.verify_trace(base_trace)
checks={}
mutations=[('case-unknown-occurrence-bool', ['case','required_evidence_slots',13,'candidate_index'],True),('case-known-occurrence-bool',['case','required_evidence_slots',4,'candidate_index'],False),('scalar-alpha-nbytes-float',['working_scalars','float64','alpha','nbytes'],8.0)]
for name,path,replacement in mutations:
    changed=copy.deepcopy(baseline);target=changed
    for k in path[:-1]:target=target[k]
    old=target[path[-1]]
    assert old==replacement and type(old) is not type(replacement),(path,old)
    target[path[-1]]=replacement
    assert enc(changed)!=enc(baseline)
    assert changed==baseline  # Demonstrate precisely Python's cross-type equality.
    audit.AUTHORITY=changed
    entry={'path':path,'original_type':type(old).__name__,'replacement_type':type(replacement).__name__,'canonical_bytes_differ':True,'original_canonical_sha256':sha(enc(baseline)),'changed_canonical_sha256':sha(enc(changed))}
    save(name+'-authority.json',changed)
    try:
        entry['authenticate_return']=authenticate(changed)
        trace=audit.make_trace();entry['verifier_return']=audit.verify_trace(trace)
        entry['accepted']=True
        entry['emitted_trace_byte_identical_to_original']=enc(trace)==enc(base_trace)
        save(name+'-trace.json',trace)
    except Exception as exc:
        entry.update(accepted=False,exception=type(exc).__name__,message=str(exc))
    checks[name]=entry
    save('canonical-type-outcomes.json',checks)
    audit.AUTHORITY=copy.deepcopy(baseline)
# Report tested violation honestly rather than fabricating an expected exception.
blocking=[name for name,value in checks.items() if value['accepted']]
save('blocking-finding.json',{'finding_id':'CAP-AUTH-TYPE-01','blocking':bool(blocking),'accepted_noncanonical_controls':blocking,'source':'frozen_case.py:37-43','contract':'Canonical typed full fixed-case/witness/scalar identity; schema-control-contract canonical paragraph and DECISION-01','impact':'Python structural == treats bool/int and float/int as equal. The new helper accepts type-altered copies of internally pinned case/scalars, and make_trace plus verify_trace also accept them. Emitted original trace remains unchanged; this is an authentication/type-boundary defect, not wrong known arithmetic or an observed worker result.','scope':'Only the promised local frozen-case authentication; no arbitrary-authority service or hostile-filesystem security claim.','action':'Preserve and stop; no candidate/source/criteria repair authorized or performed.'})
print(json.dumps({'controls':len(checks),'accepted_noncanonical_controls':blocking,'preserve_and_stop':bool(blocking)}))
raise SystemExit(2 if blocking else 0)
