"""Independent fixed-case controls and byte-state replay, not worker evidence."""
import copy
from fractions import Fraction as F
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
OUT = HERE.parent / 'artifacts'
OUT.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('review_checker', HERE / 'a2_trace.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)

def enc(v):
    return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()

def sha(v):
    return hashlib.sha256(v).hexdigest()

def save(n, v):
    (OUT / n).write_bytes(enc(v))

def rat(v):
    return F(int(v['num'], 16), int(v['den'], 16))

def raw64(d):
    b = bytes.fromhex(d['raw_hex'])
    assert d['dtype'] == 'float64' and d['byte_order'] == 'little'
    assert len(b) == d['nbytes'] == math.prod(d['shape']) * 8
    assert sha(b) == d['sha256']
    result = []
    for offset in range(0, len(b), 8):
        bits = int.from_bytes(b[offset:offset+8], 'little')
        sign, exponent, mantissa = bits >> 63, (bits >> 52) & 2047, bits & ((1 << 52) - 1)
        assert exponent != 2047
        significand = mantissa + ((1 << 52) if exponent else 0)
        power = (exponent if exponent else 1) - 1023 - 52
        result.append((-1 if sign else 1) * F(significand) * F(2) ** power)
    return result

def math_check(t):
    r = t['records']; req = r['input-bundle.json']['request']
    scalars = audit.AUTHORITY['working_scalars']['float64']
    alpha, dt = raw64(scalars['alpha'])[0], raw64(scalars['dt'])[0]
    assert alpha == rat(req['alpha']) == F(1, 2)
    assert dt == rat(req['dt']) == F(1, 4)
    scale = F(math.isqrt(dt.denominator), math.isqrt(dt.numerator))
    assert scale * scale * dt == 1
    x = raw64(req['input']); n = len(x); assert n == 3
    w = [F(1)]
    for k in range(1, n): w.append(w[-1] * (k - 1 - alpha) / k)
    g = [sum(w[:i+1]) for i in range(n)]
    v = [x[0]] + [x[i] - x[i-1] for i in range(1, n)]
    direct = [scale * sum(w[i-j] * x[j] for j in range(i+1)) for i in range(n)]
    c0 = req['candidates'][0]
    c, rho = raw64(c0['coefficients']), raw64(c0['rhos'])
    fitted = [F(1)] + [sum(cj*rj**(i-1) for cj, rj in zip(c, rho, strict=True)) for i in range(1, n)]
    residual = [fitted[i]-g[i] for i in range(n)]
    eps = max(map(abs, residual)); weights = [fitted[0]] + [fitted[i]-fitted[i-1] for i in range(1, n)]
    L = [[scale*weights[i-j] if i >= j else F(0) for j in range(n)] for i in range(n)]
    y = [sum(a*b for a,b in zip(row,x,strict=True)) for row in L]
    error = [abs(a-b) for a,b in zip(y,direct,strict=True)]
    B = [scale*eps*sum(abs(vj) for vj in v[:i]) for i in range(n)]
    grad = [F(2,n)*sum(L[i][j]*y[i] for i in range(n)) for j in range(n)]
    assert y == [scale*sum(fitted[i-j]*v[j] for j in range(i+1)) for i in range(n)]
    assert [y[i]-direct[i] for i in range(n)] == [scale*sum(residual[i-j]*v[j] for j in range(i+1)) for i in range(n)]
    values = {'S-X-w': w, 'S-X-g': g, 'S-X-v': v, 'S-X-D': direct, 'S-0-g_hat': fitted, 'S-0-residual': residual, 'S-0-signed_fitted_weights': weights, 'S-0-L_hat': sum(L, []), 'S-0-D_hat': y, 'S-0-error': error, 'S-0-B': B, 'S-0-epsilon': [eps], 'S-0-analytic_input_gradient': grad}
    for sid, vs in values.items():
        payload = r['arrays/'+sid+'.json']['exact_array']
        assert [rat(a) for a in payload['values']] == vs
        assert payload['shape'] == ([] if sid.endswith('epsilon') else [3,3] if sid.endswith('L_hat') else [3])
    unknown = r['result.json']['assessments'][1]
    assert len(unknown['slots']) == 9 and unknown['qualifies'] is None
    for s in unknown['slots']:
        assert s['status'] == 'unknown' and s['reasons'] == ['primitive_cap']
        assert all(s[k] is None for k in ['exact_array','raw_array','producer_binding_sha256'])
        assert 'arrays/'+s['slot_id']+'.json' not in r
    assert r['records/candidate-1.json'] == req['candidates'][1]
    assert 'records/binding-host-1.json' not in r
    # No coefficients/poles of candidate 1 are decoded or used in arithmetic.
    result = {k: list(map(str, vs)) for k,vs in values.items()}
    parent = json.loads((HERE/'parent-frozen-reference.json').read_bytes())
    assert result == parent['known_exact_slots']
    return {'known_slots': result, 'slot_count': len(result), 'unknown_slots': 9, 'epsilon': str(eps), 'B': list(map(str,B)), 'tau': str(rat(req['tau'])), 'qualifies': all(b <= rat(req['tau']) for b in B), 'unavailable_candidate_arithmetic': False, 'method': 'Direct IEEE-754 bit decomposition, rational GL recurrence and independent matrix gradient'}

def bodies(t):
    return {p: enc(v) for p,v in t['records'].items()} | {p: bytes.fromhex(v) for p,v in t['logs'].items()}

def state_replay(t, physical=None, reseal=False):
    r=t['records']; live={}; charges={}; cumulative=peak=0; states=[]; snapshots={}
    if physical is not None: physical.mkdir(exist_ok=False)
    for e in t['events']:
        if e['op']=='write':
            p,b=e['path'],e['body']; assert p not in live and b not in charges
            snapshot={'live_bytes':sum(map(len, live.values())), 'cumulative_written_bytes':cumulative}
            if b in ['INITIAL_INDEX','failure-index.json','result.json']:
                snapshots[b]=snapshot
                if reseal:
                    if b=='result.json': r[b]['evidence_bytes']=snapshot['live_bytes']
                    else: (t['initial_index'] if b=='INITIAL_INDEX' else r[b])['bytes_accounting']=snapshot | {'reserved_final_transaction_bytes':audit.CAPS['failure_index_bytes']}
            if reseal and b=='records/export.json':
                r[b].update(process_sha256=sha(enc(r['records/process.json'])), failure_index_sha256=sha(enc(r['failure-index.json'])), failure_index_bytes=len(enc(r['failure-index.json'])))
            if reseal and b=='run-manifest.json':
                r[b]['files']=[{'path':p,'bytes':len(v),'sha256':sha(v)} for p,v in bodies(t).items() if p!='run-manifest.json']
            raw=enc(t['initial_index']) if b=='INITIAL_INDEX' else bodies(t)[b]
            live[p]=raw; charges[b]=len(raw); cumulative+=len(raw)
            if physical is not None:
                target=physical/p; target.parent.mkdir(parents=True,exist_ok=True)
                with target.open('xb') as f: assert f.write(raw)==len(raw)
        else:
            assert e=={'op':'replace','source':'tmp/index-final.part','target':'failure-index.json'}
            assert live['failure-index.json']==enc(t['initial_index'])
            live['failure-index.json']=live.pop('tmp/index-final.part')
            if physical is not None: (physical/'tmp/index-final.part').replace(physical/'failure-index.json')
        total=sum(map(len,live.values())); peak=max(peak,total)
        if physical is not None:
            assert all((physical/p).read_bytes()==v for p,v in live.items())
            assert sum((physical/p).stat().st_size for p in live)==total
        states.append({'event':e,'live_bytes':total,'cumulative_written_bytes':cumulative})
    final=bodies(t); assert live==final
    assert set(charges)==set(final)|{'INITIAL_INDEX'}
    assert r['result.json']['evidence_bytes']==snapshots['result.json']['live_bytes']
    for b in ['INITIAL_INDEX','failure-index.json']:
        assert (t['initial_index'] if b=='INITIAL_INDEX' else r[b])['bytes_accounting']==snapshots[b]|{'reserved_final_transaction_bytes':audit.CAPS['failure_index_bytes']}
    ledger={'terms':charges,'final_live_bytes':sum(map(len,live.values())),'peak_live_bytes':peak,'cumulative_written_bytes':cumulative,'index_transaction_bytes':sum(charges[p] for p in ['INITIAL_INDEX','failure-index.json','records/process.json','records/export.json','records/output-control.json']),'old_index_bytes_charged':charges['INITIAL_INDEX'],'temporary_bytes_charged':charges['failure-index.json']}
    return {'ledger':ledger,'states':states,'snapshots':snapshots,'final_bodies':{p:{'bytes':len(v),'sha256':sha(v)} for p,v in live.items()}}

def reseal(t):
    r=t['records']; req=r['input-bundle.json']; req['raw_request_sha256']=sha(enc(req['request']))
    for v in r.values():
        if 'input_bundle_sha256' in v: v['input_bundle_sha256']=sha(enc(req))
    launch=sha(enc(r['records/launch.json']))
    for v in r.values():
        if v.get('record_type')!='producer_binding': continue
        v['launch_receipt_sha256']=launch
        for item in v['returned']:
            slot=r.get('arrays/'+item['slot_id']+'.json')
            if slot and slot['exact_array'] is not None:
                item['descriptor']['payload_sha256']=sha(enc(slot['exact_array']))
        for item in v['returned']:
            slot=r.get('arrays/'+item['slot_id']+'.json')
            if slot: slot['producer_binding_sha256']=sha(enc(v))
    for group in [r['result.json']['shared_slots']]+[a['slots'] for a in r['result.json']['assessments']]:
        for i,s in enumerate(group):
            path='arrays/'+s['slot_id']+'.json'
            if s['candidate_index']!=1 and path in r: group[i]=copy.deepcopy(r[path])
    process=r['records/process.json']; process['launch_receipt_sha256']=launch
    for stream in ['stdout','stderr']: process[stream+'_sha256']=sha(bytes.fromhex(t['logs']['logs/'+stream+'.bin']))
    idx=r['failure-index.json']; idx['process']=copy.deepcopy(process)
    for row in idx['slots']:
        p='arrays/'+row['slot_id']+'.json'
        if row['candidate_index']!=1 and p in r:
            raw=enc(r[p]); row['artifact']={'path':p,'bytes':len(raw),'sha256':sha(raw)}
    t['ledger']=state_replay(t,reseal=True)['ledger']

def outcome(t):
    try: return {'accepted':True,'report':audit.verify_trace(t)}
    except Exception as exc: return {'accepted':False,'exception':type(exc).__name__,'message':str(exc)}

def inventory_trace():
    t=audit.make_trace(); r=t['records']; path='records/candidate-2.json'
    # Same candidate schema, fresh route; no slot or host-1 binding introduced.
    before={}
    for p,v in r.items():
        if p=='result.json': before[path]=copy.deepcopy(r['records/candidate-1.json'])
        before[p]=v
    t['records']=before
    pos=next(i for i,e in enumerate(t['events']) if e.get('body')=='result.json')
    t['events'].insert(pos,{'op':'write','path':path,'body':path})
    reseal(t)
    for v in t['records'].values(): audit.schema_check(v,audit.SCHEMA)
    audit.check_links(t); audit.check_completion(t['records']); audit.check_fixed_exact_payloads(t['records']); audit.check_lifecycle(t)
    assert audit.replay_ledger(t)==t['ledger']
    return t

def main():
    mode=sys.argv[1]; base=audit.make_trace(); assert outcome(base)['accepted']
    if mode=='inventory-mutant':
        t=inventory_trace(); save('extra-supplied-candidate.json',t); result=outcome(t); save('inventory-mutant-outcome.json',result)
        assert result['accepted'],result
        print('Isolated inventory mutant accepts clean same-schema extra candidate record')
        return
    save('baseline.json',base)
    physical=state_replay(base,OUT/'physical-bodies')
    assert physical['ledger']==base['ledger']
    save('physical.json',physical); save('exact.json',math_check(base))
    t=inventory_trace(); result=outcome(t); save('extra-supplied-candidate.json',t); save('inventory-original-outcome.json',result)
    assert not result['accepted'] and result['message']=='fixed record inventory',result
    outcomes={'inventory-extra-supplied':result}
    def test(name, edit, target, schema=True, links=False):
        t=copy.deepcopy(base); edit(t); reseal(t)
        if schema:
            for v in t['records'].values(): audit.schema_check(v,audit.SCHEMA)
        if links: audit.check_links(t)
        assert audit.replay_ledger(t)==t['ledger']
        save('control-'+name+'.json',t); got=outcome(t); outcomes[name]=got
        assert not got['accepted'] and got['exception']=='ValueError' and target in got['message'],(name,got)
    test('selected-after-unknown',lambda t:t['records']['result.json'].update(status='selected',selected_id='a-good2-f64-GL'),'exhaustive known')
    test('no-qualifier-after-unknown',lambda t:t['records']['result.json'].update(status='no_supplied_candidate_meets_bound'),'exhaustive known')
    test('unknown-qualifies-true',lambda t:t['records']['result.json']['assessments'][1].update(qualifies=True),'unknown assessment')
    test('unknown-relabel',lambda t:t['records']['result.json']['assessments'][1].update(status='known_rejected_by_bound',qualifies=False),'unknown assessment')
    test('unknown-nonnull-payload',lambda t:t['records']['result.json']['assessments'][1]['slots'][0].update(exact_array=copy.deepcopy(t['records']['arrays/S-0-g_hat.json']['exact_array'])),'unavailable null')
    test('unknown-binding',lambda t:t['records']['result.json']['assessments'][1]['slots'][0].update(producer_binding_sha256='a'*64),'unavailable null')
    test('unknown-occurrence',lambda t:t['records']['result.json']['assessments'][1]['slots'][0].update(candidate_index=0),'slot occurrence')
    test('unknown-index-completed',lambda t:t['records']['failure-index.json']['slots'][13].update(completed_shape=[3]),'unknown index')
    test('missing-index',lambda t:t['records']['failure-index.json']['slots'].pop(),'index complete slot count')
    test('unknown-mode',lambda t:t['records']['result.json']['assessments'][1]['slots'][0].update(mode='jit'),'slot occurrence')
    test('unknown-reason',lambda t:t['records']['result.json']['assessments'][1]['slots'][0].update(reason='watchdog',reasons=['watchdog']),'unavailable null')
    test('supplied-copy-change',lambda t:t['records']['records/candidate-1.json']['configuration'].update(pole_count=3),'candidate copy')
    for sid in ['S-0-B','S-0-analytic_input_gradient']:
        def edit(t):
            t['records']['arrays/'+sid+'.json']['exact_array']['values'][1]={'num':'1','den':'2'}
            if sid=='S-0-B':t['records']['result.json']['assessments'][0].update(status='known_rejected_by_bound',qualifies=False)
        test('false-'+sid,edit,'exact identity '+sid,links=True)
    for wrong in ['host-fresh','host-X']:
        test('route-'+wrong,lambda t:t['records']['records/binding-host-0.json'].update(binding_id=wrong),'path-to-ID')
    test('false-exit',lambda t:t['records']['records/process.json'].update(exit_code=4),'confirmed normal',links=True)
    test('phase-duration',lambda t:t['records']['records/process.json']['phases']['watchdog'].update(elapsed_ns=999),'phase ordered',links=True)
    def reorder(t):
        ev=t['events']; a=next(i for i,e in enumerate(ev) if e.get('body')=='arrays/S-0-g_hat.json'); b=next(i for i,e in enumerate(ev) if e.get('body')=='records/binding-host-0.json'); ev[a],ev[b]=ev[b],ev[a]
    test('publication-order',reorder,'publication order',links=True)
    for field in ['primitive_count','max_normalized_bits']:
        test(field,lambda t:t['records']['result.json'].update({field:1}),'hypothetical boundary')
    for field in ['implementation_authorized','a2_acceptance_passed','arithmetic_verified','total_numerical_certified']:
        test(field,lambda t:t['records']['result.json'].update({field:True}),'hypothetical boundary',schema=False)
    save('controls-outcomes.json',outcomes)
    print(json.dumps({'independent_controls':len(outcomes),'all_target_refusals':True,'physical_ledger':physical['ledger'],'exact_known_slots':13}))

if __name__=='__main__':main()
