"""Verify and preserve a rejected review; reproduce, but never repair, its finding."""
import hashlib
import importlib.util
import io
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
REVIEW = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-after-independent-20261113')
PARENT = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-after-parent-20261113')
HERE = Path(__file__).parent
PIN = '3868fac2293dbef9049ad9bc1fd3b75a4e586472287e4a70e73b304c5162d895'


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def archive(path, source, entries):
    with tarfile.open(path, 'x:gz') as out:
        for name, expected in sorted(entries.items()):
            body = (source / name).read_bytes()
            assert ident(body) == expected
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(body), 0o644
            out.addfile(member, io.BytesIO(body))
    with tarfile.open(path, 'r:gz') as check:
        members = check.getmembers()
        assert len(members) == len(entries)
        assert {m.name for m in members} == set(entries)
        for member in members:
            assert member.isfile() and ident(check.extractfile(member).read()) == entries[member.name]
    return {'archive': path.name, **ident(path.read_bytes()), 'members_verified': len(entries)}


raw = (REVIEW / 'evidence-index.json').read_bytes()
assert ident(raw)['sha256'] == PIN
index = json.loads(raw)
assert index['file_count'] == len(index['files']) == 532
for name, expected in index['files'].items():
    assert not name.startswith('/') and all(p not in ('', '.', '..') for p in name.split('/'))
    path = REVIEW / name
    assert path.is_file() and not path.is_symlink()
    assert ident(path.read_bytes()) == expected
verdict = json.loads((REVIEW / 'verdict.json').read_text())
assert verdict['review_completed'] is True and verdict['passed'] is False
assert verdict['finding']['finding_id'] == 'CAP-AUTH-TYPE-01' and verdict['finding']['blocking']
assert verdict['repair_performed'] is False and len(verdict['logic_errors']) == 1
review_raw = (WORK / 'review-inputs.json').read_bytes()
assert ident(review_raw)['sha256'] == 'fd3dbc7d4b6d8f4cdf4dbb66c8f081509bc3a3e97195d8a0d61eaf4028bc9e4e'
frozen = json.loads(review_raw)
assert all(ident((ROOT / n).read_bytes()) == p for n, p in frozen['files'].items())
baseline = json.loads((WORK / 'baseline-inputs.json').read_text())
protected = {n: p for n, p in baseline['files'].items() if n not in baseline['allowed_status_delta']}
assert len(protected) == 901 and all(ident((ROOT / n).read_bytes()) == p for n, p in protected.items())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == baseline['head']
assert ident(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT))['sha256'] == baseline['git_stage_sha256']
report = json.loads((REVIEW / 'review-report.json').read_text())
counts = {}
for name, expected in report['regressions'].items():
    run = REVIEW / 'runs' / name
    body = (run / 'raw.xml').read_bytes()
    assert ident(body) == expected['xml']
    tree = ET.fromstring(body)
    cases = tree.findall('.//testcase')
    assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
    assert [c.attrib['classname'] + '::' + c.attrib['name'] for c in cases] == expected['exact_test_identities']
    assert len(cases) == expected['count']
    receipt = json.loads((run / 'receipt.json').read_text())
    assert receipt['actual_child_exit'] == expected['exit'] == 0
    assert all(receipt['unchanged_inputs'].values())
    counts[name] = len(cases)
assert sum(counts.values()) == 126
assert report['math']['known_slots'] == json.loads((WORK / 'parent-frozen-reference.json').read_text())['known_exact_slots']
assert report['ledger'] == json.loads((WORK / 'author-result.json').read_text())['physical_bytes']
original_extra = (REVIEW / 'runs/independent-controls/artifacts/extra-supplied-candidate.json').read_bytes()
assert original_extra == (REVIEW / 'runs/inventory-mutant/artifacts/extra-supplied-candidate.json').read_bytes()
assert report['inventory_gap']['original_refusal']['message'] == 'fixed record inventory'
assert report['inventory_gap']['isolated_mutant_accepted'] is True
# Copy the literal proof inputs, never alter the rejected implementation or original probe.
original_plan = json.loads((REVIEW / 'runs/canonical-type-controls/plan.json').read_text())
original_receipt = json.loads((REVIEW / 'runs/canonical-type-controls/receipt.json').read_text())
assert original_receipt['actual_child_exit'] == 2 and all(original_receipt['unchanged_inputs'].values())
before = HERE / 'probe/before'
before.mkdir(parents=True, exist_ok=False)
copies = {}
for name, expected in original_plan['inputs'].items():
    body = (REVIEW / 'runs/canonical-type-controls/before' / name).read_bytes()
    pin = {k: expected[k] for k in ['bytes', 'sha256']}
    assert ident(body) == pin
    path = before / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(body)
    copies[name] = pin
command = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync', 'python', '-B', 'type_probe.py']
save(HERE / 'probe/plan.json', {'argv': command, 'cwd': str(before), 'inputs': copies,
                              'expected_detection_exit': 2, 'repair_performed': False})
process = subprocess.run(command, cwd=before, capture_output=True,
    env=dict(os.environ, UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'),
             PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu'))
(HERE / 'probe/stdout.raw').write_bytes(process.stdout)
(HERE / 'probe/stderr.raw').write_bytes(process.stderr)
save(HERE / 'probe/receipt.json', {'actual_child_exit': process.returncode,
    'stdout': ident(process.stdout), 'stderr': ident(process.stderr),
    'meaning': 'Exit 2 confirms a blocking counterexample, not a successful candidate check.'})
assert process.returncode == 2
assert all(ident((before / n).read_bytes()) == p for n, p in copies.items())
checks = json.loads((HERE / 'probe/artifacts/canonical-type-outcomes.json').read_text())
original_checks = json.loads((REVIEW / 'runs/canonical-type-controls/artifacts/canonical-type-outcomes.json').read_text())
assert json.dumps(checks, sort_keys=True) == json.dumps(original_checks, sort_keys=True)
assert len(checks) == 3
assert all(v['accepted'] and v['canonical_bytes_differ'] and v['emitted_trace_byte_identical_to_original'] for v in checks.values())
# Reuse the inspected bounded scanner; every file is explicit, not ambient scratch.
scanner_raw = (PARENT / 'privacy_security.py').read_bytes()
assert ident(scanner_raw) == json.loads((WORK / 'parent-replay.json').read_text())['files']['privacy_security.py']
(HERE / 'privacy_security.py').write_bytes(scanner_raw)
spec = importlib.util.spec_from_file_location('parent_scanner', HERE / 'privacy_security.py')
scanner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scanner)
review_entries = index['files'] | {'evidence-index.json': ident(raw)}
privacy = scanner.scan(REVIEW, list(review_entries), [])
save(HERE / 'review-privacy.json', privacy)
assert privacy['passed']
preserved = archive(WORK / 'independent-review-rejected-evidence.tar.gz', REVIEW, review_entries)
with (WORK / 'independent-review-verdict.json').open('xb') as stream:
    stream.write((REVIEW / 'verdict.json').read_bytes())
preserved.update({'review_completed': True, 'passed': False, 'finding_id': 'CAP-AUTH-TYPE-01',
    'indexed_files_verified': len(index['files']), 'index_sha256': PIN,
    'independent_positive_tests_verified': counts,
    'parent_counterexample_actual_exit': process.returncode,
    'accepted_type_only_mutations_reproduced': len(checks),
    'protected_baseline_files_unchanged': len(protected),
    'review_files_unchanged_at_readback': len(frozen['files']),
    'bounded_privacy_findings': privacy['findings'], 'candidate_repaired': False})
save(WORK / 'independent-review-preservation.json', preserved)
status_names = frozen['allowed_post_review_status_delta']
old = HERE / 'reviewed-status'
old.mkdir()
status_entries = {}
for name in status_names:
    body = (ROOT / name).read_bytes()
    assert ident(body) == frozen['files'][name]
    path = old / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(body)
    status_entries[name] = ident(body)
status_report = archive(WORK / 'reviewed-status-before-rejection.tar.gz', old, status_entries)
status_report['files'] = status_entries
save(WORK / 'reviewed-status-before-rejection.json', status_report)
parent_names = ['preserve_failed_review.py', 'privacy_security.py', 'review-privacy.json',
                'probe/plan.json', 'probe/receipt.json', 'probe/stdout.raw', 'probe/stderr.raw',
                'probe/artifacts/canonical-type-outcomes.json', 'probe/artifacts/blocking-finding.json']
parent_names += ['probe/before/' + n for n in copies]
parent_names += ['probe/artifacts/' + name + suffix for name in checks for suffix in ['-authority.json', '-trace.json']]
assert len(parent_names) == len(set(parent_names))
parent_privacy = scanner.scan(HERE, parent_names, [Path('preserve_failed_review.py')])
save(HERE / 'parent-privacy.json', parent_privacy)
assert parent_privacy['passed']
parent_names.append('parent-privacy.json')
parent_entries = {n: ident((HERE / n).read_bytes()) for n in parent_names}
parent_archive = archive(WORK / 'parent-rejection-readback-evidence.tar.gz', HERE, parent_entries)
parent_archive.update({'files': parent_entries, 'candidate_passed': False,
    'blocking_finding_reproduced': 'CAP-AUTH-TYPE-01', 'actual_probe_exit': 2,
    'accepted_type_mutations': len(checks), 'source_repaired': False})
save(WORK / 'parent-rejection-readback.json', parent_archive)
print(json.dumps({'review_indexed_files_verified': len(index['files']),
    'review_archive_members_verified': len(review_entries), 'parent_probe_actual_exit': process.returncode,
    'accepted_type_mutations_confirmed': len(checks), 'positive_tests_verified': sum(counts.values()),
    'preserved_failed_review_sha256': preserved['sha256'], 'source_repaired': False}, indent=2))
