"""Finish rejected-proof preservation with bounded streamed archive scanning."""
import gzip
import hashlib
import io
import json
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

from privacy_security import scan_body

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
REVIEW = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-after-independent-20261113')
HERE = Path(__file__).parent
INDEX_PIN = '3868fac2293dbef9049ad9bc1fd3b75a4e586472287e4a70e73b304c5162d895'


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def streamed_scan(source, entries):
    findings = []
    count = expanded = 0

    def body_scan(raw, name, depth=0):
        nonlocal count, expanded
        count += 1
        expanded += len(raw)
        assert len(raw) <= 100_000_000 and depth <= 8 and expanded <= 2_000_000_000
        if raw.startswith(b'\x1f\x8b') or raw[257:262] == b'ustar':
            try:
                archive = tarfile.open(fileobj=io.BytesIO(raw), mode='r:*')
            except tarfile.ReadError:
                with gzip.GzipFile(fileobj=io.BytesIO(raw)) as stream:
                    decoded = stream.read(100_000_001)
                body_scan(decoded, name + '::gzip', depth + 1)
            else:
                with archive:
                    seen = set()
                    for member in archive:
                        assert member.isfile() and member.size <= 100_000_000
                        assert not member.name.startswith('/') and '\\' not in member.name
                        assert all(p not in ('', '.', '..') for p in member.name.split('/'))
                        assert member.name not in seen
                        seen.add(member.name)
                        value = archive.extractfile(member).read()
                        assert len(value) == member.size
                        body_scan(value, name + '::' + member.name, depth + 1)
        else:
            assert not raw.startswith(b'PK\x03\x04'), 'Unscoped zip container'
            findings.extend(scan_body(raw, name, depth))

    for name, expected in entries.items():
        raw = (source / name).read_bytes()
        assert ident(raw) == expected
        body_scan(raw, name)
    # This small synthetic structured-field control is not private data.
    assert scan_body(json.dumps({'chat_id': 'SYNTHETIC_ONLY'}).encode(), 'positive')
    return {'root_files': len(entries), 'expanded_bodies_including_containers': count,
            'expanded_bytes_including_containers': expanded, 'findings': findings,
            'limits': {'body_bytes': 100_000_000, 'depth': 8, 'aggregate_bytes': 2_000_000_000},
            'scope': 'Explicit pinned regular members; bounded patterns/fields, not private-identity matching or universal privacy clearance',
            'positive_control_passed': True}


def archive(path, source, entries):
    with tarfile.open(path, 'x:gz') as out:
        for name, expected in sorted(entries.items()):
            body = (source / name).read_bytes()
            assert ident(body) == expected
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(body), 0o644
            out.addfile(member, io.BytesIO(body))
    with tarfile.open(path, 'r:gz') as check:
        members = check.getmembers()
        assert len(members) == len(entries)
        assert {m.name for m in members} == set(entries)
        assert all(m.isfile() and ident(check.extractfile(m).read()) == entries[m.name] for m in members)
    return {'archive': path.name, **ident(path.read_bytes()), 'members_verified': len(entries)}


raw = (REVIEW / 'evidence-index.json').read_bytes()
assert ident(raw)['sha256'] == INDEX_PIN
index = json.loads(raw)
assert len(index['files']) == index['file_count'] == 532
entries = index['files'] | {'evidence-index.json': ident(raw)}
for name, expected in entries.items():
    assert ident((REVIEW / name).read_bytes()) == expected
frozen = json.loads((WORK / 'review-inputs.json').read_text())
assert all(ident((ROOT / n).read_bytes()) == p for n, p in frozen['files'].items())
verdict = json.loads((REVIEW / 'verdict.json').read_text())
assert verdict['review_completed'] and not verdict['passed'] and not verdict['repair_performed']
receipt = json.loads((HERE / 'probe/receipt.json').read_text())
assert receipt['actual_child_exit'] == 2
checks = json.loads((HERE / 'probe/artifacts/canonical-type-outcomes.json').read_text())
assert len(checks) == 3 and all(v['accepted'] and v['canonical_bytes_differ'] for v in checks.values())
assert (HERE / 'probe/artifacts/canonical-type-outcomes.json').read_bytes() == (REVIEW / 'runs/canonical-type-controls/artifacts/canonical-type-outcomes.json').read_bytes()
plan = json.loads((HERE / 'probe/plan.json').read_text())
assert all(ident((HERE / 'probe/before' / n).read_bytes()) == p for n, p in plan['inputs'].items())
privacy = streamed_scan(REVIEW, entries)
save(HERE / 'review-privacy-streamed.json', privacy)
assert not privacy['findings']
preserved = archive(WORK / 'independent-review-rejected-evidence.tar.gz', REVIEW, entries)
with (WORK / 'independent-review-verdict.json').open('xb') as stream:
    stream.write((REVIEW / 'verdict.json').read_bytes())
counts = {}
report = json.loads((REVIEW / 'review-report.json').read_text())
for name, value in report['regressions'].items():
    xml = (REVIEW / 'runs' / name / 'raw.xml').read_bytes()
    assert ident(xml) == value['xml']
    tree = ET.fromstring(xml)
    assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
    cases = tree.findall('.//testcase')
    assert len(cases) == value['count']
    counts[name] = len(cases)
preserved.update({'review_completed': True, 'passed': False, 'finding_id': 'CAP-AUTH-TYPE-01',
    'indexed_files_verified': 532, 'index_sha256': INDEX_PIN,
    'independent_positive_tests_verified': counts,
    'parent_counterexample_actual_exit': 2, 'accepted_type_only_mutations_reproduced': 3,
    'protected_baseline_files_unchanged': 901, 'review_files_unchanged_at_readback': 17,
    'bounded_privacy_findings': privacy['findings'], 'candidate_repaired': False,
    'parent_harness_failure_preserved': 'Initial whole-container scan exceeded its administrative per-body limit; streamed scan completed without changing scanner or numerical caps.'})
save(WORK / 'independent-review-preservation.json', preserved)
status_root = HERE / 'reviewed-status'
status_root.mkdir()
status_entries = {}
for name in frozen['allowed_post_review_status_delta']:
    body = (ROOT / name).read_bytes()
    assert ident(body) == frozen['files'][name]
    path = status_root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(body)
    status_entries[name] = ident(body)
status = archive(WORK / 'reviewed-status-before-rejection.tar.gz', status_root, status_entries)
status['files'] = status_entries
save(WORK / 'reviewed-status-before-rejection.json', status)
names = ['preserve_failed_review.py', 'finish_preservation.py', 'preservation-harness-attempt.json',
         'privacy_security.py', 'review-privacy-streamed.json', 'probe/plan.json',
         'probe/receipt.json', 'probe/stdout.raw', 'probe/stderr.raw',
         'probe/artifacts/canonical-type-outcomes.json', 'probe/artifacts/blocking-finding.json']
names += ['probe/before/' + n for n in plan['inputs']]
names += ['probe/artifacts/' + name + suffix for name in checks for suffix in ['-authority.json', '-trace.json']]
assert len(names) == len(set(names))
parent_entries = {n: ident((HERE / n).read_bytes()) for n in names}
parent_privacy = streamed_scan(HERE, parent_entries)
save(HERE / 'parent-privacy.json', parent_privacy)
assert not parent_privacy['findings']
parent_entries['parent-privacy.json'] = ident((HERE / 'parent-privacy.json').read_bytes())
parent_archive = archive(WORK / 'parent-rejection-readback-evidence.tar.gz', HERE, parent_entries)
parent_archive.update({'files': parent_entries, 'candidate_passed': False,
    'blocking_finding_reproduced': 'CAP-AUTH-TYPE-01', 'actual_probe_exit': 2,
    'accepted_type_mutations': 3, 'source_repaired': False})
save(WORK / 'parent-rejection-readback.json', parent_archive)
print(json.dumps({'indexed_review_files_verified': 532, 'review_archive_members': len(entries),
    'parent_counterexample_probe_exit': 2, 'accepted_noncanonical_controls': len(checks),
    'review_privacy_findings': len(privacy['findings']), 'parent_archive_members': len(parent_entries),
    'failed_review_archive_sha256': preserved['sha256'], 'source_repaired': False}, indent=2))
