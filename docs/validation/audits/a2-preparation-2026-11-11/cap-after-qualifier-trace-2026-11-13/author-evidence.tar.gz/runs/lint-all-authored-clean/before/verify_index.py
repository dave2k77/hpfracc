"""Verify an explicit proof index and refuse unpinned/missing/changed bodies."""

import hashlib
import json
import sys
from pathlib import Path


def main():
    index_path = Path(sys.argv[1]).resolve()
    root = index_path.parent
    raw_index = index_path.read_bytes()
    index = json.loads(raw_index)
    assert index['file_count'] == len(index['files'])
    assert 'evidence-index.json' not in index['files']
    for name, pin in index['files'].items():
        path = Path(name)
        assert not path.is_absolute() and '..' not in path.parts
        target = root / path
        assert not any(p.is_symlink() for p in [target, *target.parents])
        raw = target.read_bytes()
        assert {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} == pin
    print(json.dumps({'verified_files': len(index['files']),
                      'index_sha256': hashlib.sha256(raw_index).hexdigest(),
                      'passed': True, 'independent_review': False}))


if __name__ == '__main__':
    main()
