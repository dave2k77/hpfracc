"""Third-case end-to-end tracer; STATIC/HYPOTHETICAL, no worker runs."""

import importlib.util
import json
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent


def module():
    spec = importlib.util.spec_from_file_location('cap_after', HERE / 'a2_trace.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    return audit


def test_after_qualifier_preserves_known_and_unknown_with_closed_bytes():
    audit = module()
    trace = audit.make_trace()
    report = audit.verify_trace(trace)
    records = trace['records']
    result = records['result.json']
    index = records['failure-index.json']
    assert report['case_id'] == 'CAP-after-qualifier-f64-GL'
    assert report['slot_count'] == report['required_slot_count'] == 22
    assert report['complete_slot_count'] == 13
    assert report['unknown_slot_count'] == 9
    assert len(records) == 26 and len(audit.raw_files(trace)) == 28
    assert result['status'] == index['status'] == 'indeterminate'
    assert result['selected_id'] is None
    assert result['reasons'] == index['reasons'] == ['primitive_cap']
    known, unknown = result['assessments']
    assert known['status'] == 'known_qualifying' and known['qualifies'] is True
    assert known['candidate_id'] == 'a-good2-f64-GL'
    assert unknown['candidate_id'] == 'bad1-f64-GL'
    assert unknown['status'] == 'unknown' and unknown['qualifies'] is None
    assert unknown['reasons'] == ['primitive_cap']
    assert len(unknown['slots']) == 9 and len(index['slots']) == 22
    for slot in unknown['slots']:
        assert slot['candidate_index'] == 1 and slot['status'] == 'unknown'
        assert slot['reason'] == 'primitive_cap'
        assert slot['reasons'] == ['primitive_cap']
        assert all(slot[k] is None for k in [
            'raw_array', 'exact_array', 'producer_binding_sha256'
        ])
        assert 'arrays/' + slot['slot_id'] + '.json' not in records
    for row in index['slots'][13:]:
        assert row['artifact'] is None and row['completed_shape'] is None
        assert row['expected_shape'] == (
            [] if row['quantity'] == 'epsilon'
            else [3, 3] if row['quantity'] == 'L_hat' else [3]
        )
    assert 'records/binding-host-1.json' not in records
    assert records['records/candidate-1.json'] == (
        records['input-bundle.json']['request']['candidates'][1]
    )
    reference = json.loads((HERE / 'parent-frozen-reference.json').read_bytes())
    for sid, values in reference['known_exact_slots'].items():
        payload = records['arrays/' + sid + '.json']['exact_array']
        actual = [Fraction(int(v['num'], 16), int(v['den'], 16))
                  for v in payload['values']]
        assert actual == list(map(Fraction, values)), sid
    assert result['primitive_count'] == result['max_normalized_bits'] == 0
    for key in ['implementation_authorized', 'a2_acceptance_passed',
                'arithmetic_verified', 'total_numerical_certified']:
        assert result[key] is False
    assert records['records/process.json']['termination'] == 'normal'
    assert records['records/process.json']['exit_code'] == 0
    assert report['ledger'] == trace['ledger'] == audit.replay_ledger(trace)
    assert set(trace['ledger']['terms']) == set(audit.raw_files(trace)) | {
        'INITIAL_INDEX'
    }
    output = HERE.parent / 'artifacts'
    output.mkdir(exist_ok=True)
    (output / 'trace.json').write_bytes(audit.canonical(trace))
    (output / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
