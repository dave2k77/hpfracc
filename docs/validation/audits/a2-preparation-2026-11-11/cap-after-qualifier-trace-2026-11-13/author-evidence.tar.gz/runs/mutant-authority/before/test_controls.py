"""Posthoc re-signed semantic and accounting controls; not TDD claims."""

import copy
import json
from pathlib import Path

import pytest

from test_cap_after import module

HERE = Path(__file__).resolve().parent


def preserve(trace, name):
    dest = HERE.parent / 'artifacts/controls'
    dest.mkdir(parents=True, exist_ok=True)
    (dest / (name + '.json')).write_text(json.dumps(trace, indent=2) + '\n')


def recalculate(terms):
    final = sum(v for k, v in terms.items() if k != 'INITIAL_INDEX')
    return {
        'terms': terms, 'final_live_bytes': final,
        'cumulative_written_bytes': sum(terms.values()),
        'peak_live_bytes': max(final, final + terms['INITIAL_INDEX']
                              - terms['records/export.json']
                              - terms['run-manifest.json']),
        'index_transaction_bytes': sum(terms[p] for p in [
            'INITIAL_INDEX', 'failure-index.json', 'records/process.json',
            'records/export.json', 'records/output-control.json'
        ]),
        'old_index_bytes_charged': terms['INITIAL_INDEX'],
        'temporary_bytes_charged': terms['failure-index.json'],
    }


def seal(audit, trace):
    """Re-sign metadata/descriptor links, not semantic dispositions or shapes."""
    records = trace['records']
    def sha(value):
        return audit.digest(audit.canonical(value))
    for binding in records.values():
        if binding['record_type'] != 'producer_binding':
            continue
        binding['launch_receipt_sha256'] = sha(records['records/launch.json'])
        for returned in binding['returned']:
            slot = records.get('arrays/' + returned['slot_id'] + '.json')
            if slot is not None and slot['exact_array'] is not None:
                returned['descriptor']['payload_sha256'] = sha(slot['exact_array'])
        for returned in binding['returned']:
            slot = records.get('arrays/' + returned['slot_id'] + '.json')
            if slot is not None:
                slot['producer_binding_sha256'] = sha(binding)
    result = records['result.json']
    for slots in [result['shared_slots']] + [a['slots'] for a in result['assessments']]:
        for i, slot in enumerate(slots):
            path = 'arrays/' + slot['slot_id'] + '.json'
            if slot['candidate_index'] != 1 and path in records:
                slots[i] = copy.deepcopy(records[path])
    index = records['failure-index.json']
    process = records['records/process.json']
    process['launch_receipt_sha256'] = sha(records['records/launch.json'])
    index['process'] = copy.deepcopy(process)
    for row in index['slots']:
        path = 'arrays/' + row['slot_id'] + '.json'
        if row['candidate_index'] != 1 and path in records:
            raw = audit.canonical(records[path])
            row['artifact'] = {'path': path, 'bytes': len(raw),
                               'sha256': audit.digest(raw)}
    initial = trace['initial_index']
    size = len(audit.canonical(records['input-bundle.json']))
    initial['bytes_accounting'].update(live_bytes=size, cumulative_written_bytes=size)
    initial_size = len(audit.canonical(initial))
    prefix = list(records)[:list(records).index('result.json')]
    result['evidence_bytes'] = initial_size + sum(
        len(audit.canonical(records[p])) for p in prefix
    )
    before_index = prefix + ['result.json', 'records/process.json',
                             'records/output-control.json']
    size = initial_size + sum(len(audit.canonical(records[p])) for p in before_index)
    size += sum(len(bytes.fromhex(x)) for x in trace['logs'].values())
    index['bytes_accounting'].update(live_bytes=size, cumulative_written_bytes=size)
    export = records['records/export.json']
    export.update(process_sha256=sha(process), failure_index_sha256=sha(index),
                  failure_index_bytes=len(audit.canonical(index)))
    files = audit.raw_files(trace)
    records['run-manifest.json']['files'] = [
        {'path': p, 'bytes': len(raw), 'sha256': audit.digest(raw)}
        for p, raw in files.items() if p != 'run-manifest.json'
    ]
    terms = {p: len(raw) for p, raw in audit.raw_files(trace).items()}
    terms['INITIAL_INDEX'] = initial_size
    trace['ledger'] = recalculate(terms)
    actual = audit.raw_files(trace)
    assert {x['path']: (x['bytes'], x['sha256'])
            for x in records['run-manifest.json']['files']} == {
                p: (len(raw), audit.digest(raw)) for p, raw in actual.items()
                if p != 'run-manifest.json'
            }


def refusal(audit, trace, name, match):
    preserve(trace, name)
    with pytest.raises(ValueError, match=match):
        audit.verify_trace(trace)


@pytest.mark.parametrize('fault', [
    'selected-known', 'no-qualifier', 'minimum-unknown', 'ineligible', 'rejected',
    'qualifying', 'missing-assessment', 'qualifies', 'assessment-reason',
    'assessment-occurrence', 'missing-slot', 'missing-index', 'slot-reason',
    'slot-mode', 'slot-occurrence', 'slot-exact', 'slot-raw', 'slot-binding',
    'index-reason', 'index-mode', 'index-occurrence', 'index-shape',
    'index-completed', 'index-artifact', 'index-complete', 'index-none',
    'unknown-array', 'unknown-host', 'known-disappears', 'known-null',
    'known-shape', 'known-corruption', 'supplied-copy',
])
def test_unknown_and_known_refusals(fault):
    audit = module()
    trace = audit.make_trace()
    records = trace['records']
    result = records['result.json']
    unknown = result['assessments'][1]
    slot = unknown['slots'][0]
    row = records['failure-index.json']['slots'][13]
    if fault in ['selected-known', 'no-qualifier', 'minimum-unknown']:
        result.update(status='no_supplied_candidate_meets_bound' if fault ==
                      'no-qualifier' else 'selected', selected_id=None if fault ==
                      'no-qualifier' else 'a-good2-f64-GL' if fault ==
                      'selected-known' else 'bad1-f64-GL')
    elif fault in ['ineligible', 'rejected', 'qualifying']:
        unknown['status'] = {'ineligible': 'known_ineligible',
                             'rejected': 'known_rejected_by_bound',
                             'qualifying': 'known_qualifying'}[fault]
    elif fault == 'missing-assessment':
        result['assessments'].pop()
    elif fault == 'qualifies':
        unknown['qualifies'] = False
    elif fault == 'assessment-reason':
        unknown['reasons'] = ['none']
    elif fault == 'assessment-occurrence':
        unknown['candidate_index'] = 0
    elif fault == 'missing-slot':
        unknown['slots'].pop()
    elif fault == 'missing-index':
        records['failure-index.json']['slots'].pop()
    elif fault.startswith('slot-'):
        key, value = {
            'slot-reason': ('reason', 'not_evaluated'),
            'slot-mode': ('mode', 'jit'),
            'slot-occurrence': ('candidate_index', 0),
            'slot-exact': ('exact_array', {'shape': [3], 'values': [
                {'num': '0', 'den': '1'}] * 3}),
            'slot-raw': ('raw_array', records['input-bundle.json']['request']['input']),
            'slot-binding': ('producer_binding_sha256', '0' * 64),
        }[fault]
        slot[key] = copy.deepcopy(value)
    elif fault.startswith('index-'):
        key, value = {
            'index-reason': ('reason', 'not_evaluated'),
            'index-mode': ('mode', 'jit'),
            'index-occurrence': ('candidate_index', 0),
            'index-shape': ('expected_shape', [1, 3]),
            'index-completed': ('completed_shape', [3]),
            'index-artifact': ('artifact', {'path': 'arrays/S-1-g_hat.json',
                                          'bytes': 1, 'sha256': '0' * 64}),
            'index-complete': ('status', 'complete'),
            'index-none': ('reasons', ['none']),
        }[fault]
        if fault in ['index-complete', 'index-none']:
            records['failure-index.json'][key] = value
        else:
            row[key] = value
    elif fault == 'unknown-array':
        records['arrays/S-1-g_hat.json'] = copy.deepcopy(slot)
    elif fault == 'unknown-host':
        binding = copy.deepcopy(records['records/binding-host-0.json'])
        binding.update(binding_id='host-1', candidate_index=1,
                       candidate_id='bad1-f64-GL', returned=[])
        records['records/binding-host-1.json'] = binding
    elif fault == 'known-disappears':
        del records['arrays/S-0-B.json']
    elif fault == 'known-null':
        records['arrays/S-0-B.json']['exact_array'] = None
    elif fault == 'known-shape':
        records['arrays/S-0-B.json']['exact_array']['shape'] = [1, 3]
    elif fault == 'known-corruption':
        records['arrays/S-0-D_hat.json']['exact_array']['values'][0]['num'] = '3'
    else:
        records['records/candidate-1.json']['configuration']['pole_count'] = 2
    seal(audit, trace)
    refusal(audit, trace, fault, 'selection|binding|fixed record|exact identity')


@pytest.mark.parametrize('sid', ['S-0-B', 'S-0-analytic_input_gradient'])
def test_false_known_math_after_descriptor_and_outer_resigning(sid):
    audit = module()
    trace = audit.make_trace()
    records = trace['records']
    records['arrays/' + sid + '.json']['exact_array']['values'][1] = {
        'num': '1', 'den': '2'
    }
    if sid == 'S-0-B':
        records['result.json']['assessments'][0].update(
            status='known_rejected_by_bound', qualifies=False
        )
    seal(audit, trace)
    audit.check_links(trace)
    audit.check_completion(records)
    assert audit.replay_ledger(trace) == trace['ledger']
    refusal(audit, trace, 'false-' + sid, 'exact identity ' + sid)


@pytest.mark.parametrize('suffix', ['X', '0'])
@pytest.mark.parametrize('kind', ['fresh', 'colliding'])
def test_route_identity(suffix, kind):
    audit = module()
    trace = audit.make_trace()
    path = 'records/binding-host-' + suffix + '.json'
    replacement = 'host-fresh' if kind == 'fresh' else (
        'host-X' if suffix == '0' else 'host-0'
    )
    trace['records'][path]['binding_id'] = replacement
    seal(audit, trace)
    assert audit.replay_ledger(trace) == trace['ledger']
    refusal(audit, trace, 'route-' + suffix + '-' + kind, 'binding path-to-ID')


@pytest.mark.parametrize('fault', ['exit', 'unconfirmed', 'kill', 'phase', 'order'])
def test_process_lifecycle(fault):
    audit = module()
    trace = audit.make_trace()
    process = trace['records']['records/process.json']
    if fault == 'exit':
        process['exit_code'] = 1
    elif fault == 'unconfirmed':
        process.update(exit_confirmed=False, exit_code=None)
    elif fault == 'kill':
        process['termination'] = 'killed'
    elif fault == 'phase':
        process['phases']['watchdog']['elapsed_ns'] += 1
    else:
        events = trace['events']
        a = next(i for i, e in enumerate(events)
                 if e.get('body') == 'records/binding-host-0.json')
        b = next(i for i, e in enumerate(events)
                 if e.get('body') == 'arrays/S-0-g_hat.json')
        events[a], events[b] = events[b], events[a]
    seal(audit, trace)
    assert audit.replay_ledger(trace) == trace['ledger']
    refusal(audit, trace, fault, 'completion|phase|publication order|schema')


@pytest.mark.parametrize('component', [
    'logs/stdout.bin', 'logs/stderr.bin', 'run-manifest.json', 'INITIAL_INDEX',
    'failure-index.json', 'records/candidate-1.json', 'inline-unknown',
])
def test_real_charge_omission_with_recomputed_summaries(component):
    audit = module()
    trace = audit.make_trace()
    terms = trace['ledger']['terms']
    if component == 'inline-unknown':
        original = trace['records']['result.json']
        smaller = copy.deepcopy(original)
        smaller['assessments'][1]['slots'] = []
        removed = len(audit.canonical(original)) - len(audit.canonical(smaller))
        assert removed > 0
        terms['result.json'] -= removed
    else:
        assert terms[component] > 0
        terms[component] = 0
    trace['ledger'] = recalculate(terms)
    audit.check_links(trace)
    audit.check_completion(trace['records'])
    audit.check_fixed_exact_payloads(trace['records'])
    audit.check_lifecycle(trace)
    refusal(audit, trace, 'charge-' + component.replace('/', '-'), 'ledger claim')


@pytest.mark.parametrize('field', ['case', 'checkpoint', 'witness', 'expected'])
def test_frozen_authority_cannot_be_redefined(field):
    audit = module()
    if field == 'case':
        audit.AUTHORITY['case']['request']['candidate_refs'].reverse()
    elif field == 'checkpoint':
        audit.AUTHORITY['case']['resource_control']['fault_checkpoint'] = 'other'
    elif field == 'witness':
        audit.AUTHORITY['bundle']['artifacts']['result.json']['status'] = 'selected'
    else:
        audit.AUTHORITY['case']['expected']['request_status'] = 'selected'
    preserve(audit.AUTHORITY, 'authority-' + field)
    with pytest.raises(ValueError, match='frozen authority'):
        audit.make_trace()
