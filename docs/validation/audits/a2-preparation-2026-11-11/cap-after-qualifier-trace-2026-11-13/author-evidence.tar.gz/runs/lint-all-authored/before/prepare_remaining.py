"""Prepare remaining exact-source test, scoped source lint, and audit lint jobs."""

import json
from pathlib import Path

from jobs import FROZEN, HERE, OLD, ROOT, job, meta, third
from prepare_final_runs import refresh
from proof_scope import CANDIDATE_FILES, ROOT_FILES


def main():
    third('controls-complete', ['test_cap_after.py', 'test_controls.py'])
    refresh('mutant-byte-ledger-final', 'mutant-byte-ledger-complete')
    helpers = {n: HERE / n for n in ROOT_FILES if n.endswith('.py')}
    helpers |= {'candidate/' + n: HERE / 'candidate' / n for n in CANDIDATE_FILES
                if n.endswith('.py') and n != 'a2_trace.py'}
    helpers['pyproject.toml'] = FROZEN / 'inputs/pyproject.toml'
    job('lint-all-authored', helpers,
        command=['-m', 'ruff', 'check', '--no-cache', '--output-format=json']
        + [n for n in helpers if n.endswith('.py')])
    pins = json.loads((FROZEN / 'baseline-inputs.json').read_bytes())['files']
    repo_sources = {n: ROOT / n for n in pins if Path(n).suffix == '.py'}
    repo_sources['pyproject.toml'] = ROOT / 'pyproject.toml'
    for name, path in repo_sources.items():
        assert meta(path) == pins[name], name
    job('lint-repository', repo_sources,
        command=['-m', 'ruff', 'check', '--no-cache', '--output-format=json']
        + [n for n in repo_sources if n.endswith('.py')])
    job('lint-inherited-capture', {
        'run_snapshot.py': OLD / 'tools/run_snapshot.py',
        'pyproject.toml': FROZEN / 'inputs/pyproject.toml',
    }, command=['-m', 'ruff', 'check', '--no-cache', '--output-format=json',
                'run_snapshot.py'])


if __name__ == '__main__':
    main()
