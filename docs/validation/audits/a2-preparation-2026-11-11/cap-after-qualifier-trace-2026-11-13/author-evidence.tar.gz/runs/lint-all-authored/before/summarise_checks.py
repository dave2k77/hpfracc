"""Reduce captured results without altering raw evidence."""

import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent


def lint(name):
    run = HERE / 'runs' / name
    findings = json.loads((run / 'stdout.bin').read_bytes())
    summaries = []
    for f in findings:
        path = Path(f['filename'])
        lines = path.read_text().splitlines()
        summaries.append({'file': path.name, 'rule': f['code'],
                          'row': f['location']['row'],
                          'context': lines[f['location']['row'] - 1].strip(),
                          'message': f['message']})
    return summaries


def main():
    baseline = lint('lint-baseline')
    candidate = lint('lint-candidate')
    old = Counter((f['file'], f['rule'], f['context']) for f in baseline)
    new = Counter((f['file'], f['rule'], f['context']) for f in candidate)
    delta = {'baseline_findings': len(baseline), 'candidate_findings': len(candidate),
             'introduced_by_rule_context': list((new - old).elements()),
             'removed_by_rule_context': list((old - new).elements()),
             'new_helpers': lint('lint-new')}
    (HERE / 'lint-delta-first.json').write_text(json.dumps(delta, indent=2) + '\n')
    print(json.dumps(delta, indent=2))
    physical = json.loads((HERE / 'runs/physical-replay/artifacts/independent-report.json')
                          .read_bytes())
    print(json.dumps({'physical_ledger': physical['physical']['ledger'],
                      'max_nodes': physical['physical']['max_parse_nodes'],
                      'max_depth': physical['physical']['max_parse_depth']}))
    for name in ['read-guard-control', 'missing-authority.json',
                 'missing-record-schemas.json', 'missing-protocol.json',
                 'missing-trace.json']:
        text = (HERE / 'runs' / name / 'stderr.bin').read_text()
        print(name, text.splitlines()[-1])


if __name__ == '__main__':
    main()
