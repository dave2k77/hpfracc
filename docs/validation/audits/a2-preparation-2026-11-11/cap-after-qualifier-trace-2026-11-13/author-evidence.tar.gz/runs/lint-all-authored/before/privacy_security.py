"""Bounded, recursive, explicit-proof privacy and authored-source security scan."""

import ast
import gzip
import io
import json
import re
import tarfile
import zipfile
from pathlib import Path

SENSITIVE = {
    'chat_id', 'message_id', 'recipient_id', 'bot_token', 'api_key',
    'password', 'access_token', 'refresh_token', 'private_key',
}
TOKEN_PATTERNS = [
    re.compile(rb'\b[0-9]{7,}:[A-Za-z0-9_-]{30,}\b'),
    re.compile(rb'\bAKIA[A-Z0-9]{16}\b'),
    re.compile(rb'-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----'),
]


def scan_body(raw, name, depth=0):
    if depth > 8 or len(raw) > 100_000_000:
        raise ValueError('privacy scanner resource limit; incomplete scan')
    found = []
    for i, pattern in enumerate(TOKEN_PATTERNS):
        if pattern.search(raw):
            found.append({'path': name, 'rule': 'credential-pattern-' + str(i)})
    if raw.startswith(b'\x1f\x8b'):
        return found + scan_body(gzip.decompress(raw), name + '!gzip', depth + 1)
    if raw.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            for member in archive.infolist():
                if not member.is_dir():
                    found += scan_body(archive.read(member),
                                       name + '!' + member.filename, depth + 1)
        return found
    if len(raw) > 262 and raw[257:262] == b'ustar':
        with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as archive:
            for member in archive:
                if member.isfile():
                    found += scan_body(archive.extractfile(member).read(),
                                       name + '!' + member.name, depth + 1)
                elif not member.isdir():
                    found.append({'path': name, 'rule': 'nonregular-archive-member'})
        return found
    try:
        value = json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        return found
    pending = [(value, '$')]
    while pending:
        value, location = pending.pop()
        if isinstance(value, dict):
            for key, child in value.items():
                if key.lower() in SENSITIVE and child is not None:
                    found.append({'path': name, 'field': location + '.' + key,
                                  'rule': 'sensitive-field'})
                pending.append((child, location + '.' + key))
        elif isinstance(value, list):
            pending.extend((child, location + '[]') for child in value)
    return found


def security(path):
    tree = ast.parse(path.read_bytes())
    findings = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = (node.func.id if isinstance(node.func, ast.Name) else
                node.func.attr if isinstance(node.func, ast.Attribute) else '')
        forbidden = name in {'eval', 'exec', 'system'}
        forbidden |= any(k.arg == 'shell' and isinstance(k.value, ast.Constant)
                         and k.value.value is True for k in node.keywords)
        forbidden |= (name in {'load', 'loads'} and
                      isinstance(node.func, ast.Attribute) and
                      isinstance(node.func.value, ast.Name) and
                      node.func.value.id == 'pickle')
        if forbidden:
            findings.append({'file': path.name, 'line': node.lineno,
                             'rule': 'unsafe-call-or-shell'})
    return findings


def scan(root, files, authored):
    findings = []
    bytes_scanned = 0
    for name in files:
        raw = (root / name).read_bytes()
        bytes_scanned += len(raw)
        findings.extend(scan_body(raw, str(name)))
        if any(x in str(name).lower() for x in [
            'telegram-receipt', 'delivery-receipt', 'message-receipt'
        ]):
            findings.append({'path': str(name), 'rule': 'messaging-receipt-path'})
    control = json.dumps({'chat_id': 'SYNTHETIC_NOT_REAL'}).encode()
    memory = io.BytesIO()
    with tarfile.open(fileobj=memory, mode='w') as archive:
        info = tarfile.TarInfo('synthetic.json')
        info.size = len(control)
        archive.addfile(info, io.BytesIO(control))
    positive = scan_body(gzip.compress(memory.getvalue()), 'synthetic-memory-control')
    assert any(f.get('rule') == 'sensitive-field' for f in positive)
    security_findings = [f for p in authored for f in security(root / p)]
    return {
        'scope': 'Explicit owned proof allowlist; no profile/session/receipt-store reads',
        'file_count': len(files), 'bytes_scanned': bytes_scanned,
        'findings': findings, 'security_findings': security_findings,
        'positive_control': {'synthetic_only': True, 'recursive_gzip_tar_detected': True},
        'passed': not findings and not security_findings,
        'limitations': [
            'Pattern/structured-field scan is not universal privacy assurance.',
            'Raw local process provenance retains absolute paths and hostnames.',
            'Python imports of explicitly copied local modules are intentional.',
            'Scanner resource bounds are not numerical protocol caps.',
            'No messaging receipt was an input or generated output.',
        ],
    }
