"""Explicit input/generated-output closure; never ingest ambient scratch."""

import json
from pathlib import Path

ROOT_FILES = [
    'bootstrap.py', 'capture.py', 'jobs.py', 'derive.py', 'run_jobs.py',
    'prepare_replay.py', 'prepare_checks.py', 'summarise_checks.py',
    'prepare_mutants.py', 'prepare_final_runs.py', 'inspect_captures.py',
    'proof_scope.py', 'privacy_security.py', 'assemble_final.py',
    'prepare_remaining.py', 'verify_index.py',
    'copied-inputs.json', 'protection-before.json', 'authority-derivation.json',
    'lint-delta-first.json', 'mutant-source-pin.json', 'mutants-plan.json',
    'mutants-results.json', 'result.json', 'source.diff', 'protection-after.json',
    'lint-delta.json', 'privacy-security.json', 'generated-allowlist.json',
]
CANDIDATE_FILES = [
    'a2_trace.py', 'authority.json', 'protocol.json', 'record-schemas.json',
    'pyproject.toml', 'frozen_case.py', 'test_cap_after.py', 'test_controls.py',
    'test_old_equality.py', 'verify_cap.py',
]
BASE_RUNS = [
    'baseline-positive', 'baseline-negative', 'red-01', 'green-01',
    'regression-01-positive', 'regression-01-negative', 'boundary-red',
    'controls-01', 'regression-02-positive', 'regression-02-negative',
    'physical-replay', 'read-guard-control', 'missing-authority.json',
    'missing-record-schemas.json', 'missing-protocol.json', 'missing-trace.json',
    'negative-equality', 'lint-baseline', 'lint-candidate', 'lint-new',
    'controls-final', 'regression-final-positive', 'regression-final-negative',
    'physical-replay-final', 'negative-equality-final', 'lint-candidate-final',
    'lint-new-final', 'controls-complete', 'mutant-byte-ledger-complete',
    'lint-all-authored', 'lint-repository', 'lint-inherited-capture',
]
CONTROL_STEMS = set('''
selected-known no-qualifier minimum-unknown ineligible rejected qualifying
missing-assessment missing-preinventory qualifies assessment-reason
assessment-occurrence missing-slot missing-index slot-reason slot-mode
slot-occurrence slot-exact slot-raw slot-binding slot-status index-reason
index-mode index-occurrence index-shape index-completed index-artifact
index-complete index-none unknown-array unknown-host known-disappears known-null
known-shape known-corruption supplied-copy unknown forged-qualifies
forged-assessment-status forged-result-status forged-selected-id exit-unconfirmed
exit-nonzero index-inventory preinventory descriptor-shape slot-shape mode alpha
false-qualifying-bound phase publication exit unconfirmed kill order
'''.split())
CONTROL_STEMS |= {'route-' + suffix + '-' + kind for suffix in ['X', '0']
                  for kind in ['fresh', 'colliding']}
CONTROL_STEMS |= {'false-exact-' + sid for sid in [
    'S-X-D', 'S-0-D_hat', 'S-0-analytic_input_gradient', 'S-0-B']}
CONTROL_STEMS |= {'false-' + sid for sid in ['S-0-B', 'S-0-analytic_input_gradient']}
CONTROL_STEMS |= {'authority-' + field for field in [
    'case', 'checkpoint', 'witness', 'expected']}
CHARGES = ['logs/stdout.bin', 'logs/stderr.bin', 'run-manifest.json', 'INITIAL_INDEX',
           'failure-index.json', 'records/candidate-1.json', 'inline-unknown',
           'inline-index-unknown', 'inline-input-unknown']
CONTROL_STEMS |= {prefix + name.replace('/', '-') for prefix in [
    'charge-', 'missing-charge-'] for name in CHARGES}
ARTIFACT_FILES = {
    'trace.json', 'verification.json', 'positive-trace.json',
    'positive-equality.json', 'negative-equality.json', 'independent-report.json',
} | {'boundary-' + field + '.json' for field in [
    'implementation_authorized', 'a2_acceptance_passed', 'arithmetic_verified',
    'total_numerical_certified', 'primitive_count', 'max_normalized_bits']}
EXCLUDED_PARTS = {'runtime', '__pycache__', '.pytest_cache', '.ruff_cache', 'build'}


def run_names(root):
    mutants = json.loads((root / 'mutants-plan.json').read_bytes())
    return BASE_RUNS + ['mutant-' + m['name'] + suffix for m in mutants
                       for suffix in ['', '-final']]


def scope(root):
    allowed = {Path(n) for n in ROOT_FILES}
    pins = json.loads((root / 'copied-inputs.json').read_bytes())
    allowed |= {Path('frozen') / n for n in pins}
    allowed |= {Path('frozen') / n for n in [
        'authorization.json', 'preflight.json', 'baseline-inputs.json',
        'parent-frozen-reference.json']}
    allowed |= {Path('candidate') / n for n in CANDIDATE_FILES}
    mutants = json.loads((root / 'mutants-plan.json').read_bytes())
    allowed |= {Path('mutants') / m['name'] / 'a2_trace.py' for m in mutants}
    for name in run_names(root):
        job = Path('jobs') / (name + '.json')
        if not (root / job).exists():
            continue
        allowed.add(job)
        plan = json.loads((root / job).read_bytes())
        run = Path('runs') / name
        allowed |= {run / 'before' / n for n in plan['inputs']}
        allowed |= {run / n for n in [
            'entrypoint.py', 'job.json', 'started.json', 'stdout.bin', 'stderr.bin',
            'raw.xml', 'result.json']}
        artifact = run / 'artifacts'
        allowed |= {artifact / n for n in ARTIFACT_FILES}
        allowed |= {artifact / 'controls' / (s + '.json') for s in CONTROL_STEMS}
        report = root / artifact / 'independent-report.json'
        if report.exists():
            data = json.loads(report.read_bytes())
            allowed |= {artifact / 'bodies' / n for n in data['physical']['final_files']}
    existing = {p for p in allowed if (root / p).is_file()}
    # Traversal is confined to this newly owned proof directory and excludes runtime.
    observed = set()
    pending = [root]
    while pending:
        directory = pending.pop()
        for path in directory.iterdir():
            assert not path.is_symlink(), 'unexpected symlink in proof closure'
            if path.is_dir():
                if path.name not in EXCLUDED_PARTS:
                    pending.append(path)
            elif path.name != 'evidence-index.json':
                observed.add(path.relative_to(root))
    assert observed == existing, sorted(map(str, observed - existing))
    return sorted(existing, key=str)
