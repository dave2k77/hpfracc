"""Assemble author self-verification from actual captured exits and pinned bytes."""

import difflib
import hashlib
import json
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

from bootstrap import protection
from privacy_security import scan
from proof_scope import CANDIDATE_FILES, ROOT_FILES, run_names, scope

HERE = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_bytes())


def meta(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(name, value):
    path = HERE / name
    assert not path.exists(), name
    path.write_text(json.dumps(value, indent=2) + '\n')


def lint_rows(name):
    rows = load(HERE / 'runs' / name / 'stdout.bin')
    result = []
    for row in rows:
        source = Path(row['filename']).read_text().splitlines()
        result.append((Path(row['filename']).name, row['code'],
                       source[row['location']['row'] - 1].strip()))
    return Counter(result)


def main():
    runs = {}
    for name in run_names(HERE):
        path = HERE / 'runs' / name
        if not (path / 'result.json').is_file():
            continue
        result = load(path / 'result.json')
        job = load(path / 'job.json')
        assert result['source_hashes_unchanged']
        for n, spec in job['inputs'].items():
            assert meta(path / 'before' / n) == spec['pin']
        runs[name] = {
            'actual_child_exit': result['actual_child_exit'],
            'junit': result.get('junit'),
            'checker': job['inputs'].get('a2_trace.py', {}).get('pin'),
            'source_hashes_rechecked': True,
        }
    required_green = [
        'baseline-positive', 'baseline-negative', 'green-01', 'controls-complete',
        'regression-final-positive', 'regression-final-negative',
        'negative-equality-final', 'physical-replay-final', 'lint-all-authored',
        'lint-repository',
    ]
    assert all(runs[n]['actual_child_exit'] == 0 for n in required_green)
    checker_pin = meta(HERE / 'candidate/a2_trace.py')
    for name in ['controls-complete', 'regression-final-positive',
                 'regression-final-negative', 'negative-equality-final',
                 'physical-replay-final']:
        assert runs[name]['checker'] == checker_pin
    baseline_ids = []
    final_ids = []
    for suffix in ['positive', 'negative']:
        for destination, prefix in [(baseline_ids, 'baseline-'),
                                    (final_ids, 'regression-final-')]:
            junit = runs[prefix + suffix]['junit']
            assert not any(junit[k] for k in ['failures', 'errors', 'skipped'])
            destination.extend((x['classname'], x['name']) for x in junit['identities'])
    assert sorted(baseline_ids) == sorted(final_ids)
    assert len(final_ids) == len(set(final_ids)) == 59
    old = lint_rows('lint-baseline')
    new = lint_rows('lint-candidate-final')
    lint = {'baseline_findings': sum(old.values()),
            'candidate_findings': sum(new.values()),
            'introduced_rule_context': list((new - old).elements()),
            'removed_rule_context': list((old - new).elements()),
            'all_authored_helpers_exit': runs['lint-all-authored']['actual_child_exit'],
            'repository_lint_exit': runs['lint-repository']['actual_child_exit'],
            'inherited_capture_helper_exit':
                runs['lint-inherited-capture']['actual_child_exit'],
            'baseline_and_candidate_ruff_child_exits': [
                runs['lint-baseline']['actual_child_exit'],
                runs['lint-candidate-final']['actual_child_exit']],
            'limitation': 'Inherited archived checker/tests remain lint-failing; '
                          'repository lint is a separate actual command.'}
    assert not lint['introduced_rule_context']
    save('lint-delta.json', lint)
    baseline = (HERE / 'frozen/previous-author/final/a2_trace.py').read_text()
    diffs = [''.join(difflib.unified_diff(
        baseline.splitlines(True), (HERE / 'candidate/a2_trace.py').read_text()
        .splitlines(True), fromfile='reviewed/a2_trace.py', tofile='candidate/a2_trace.py'
    ))]
    for name in CANDIDATE_FILES:
        if name.endswith('.py') and name != 'a2_trace.py':
            diffs.append(''.join(difflib.unified_diff(
                [], (HERE / 'candidate' / name).read_text().splitlines(True),
                fromfile='/dev/null', tofile='candidate/' + name)))
    (HERE / 'source.diff').write_text(''.join(diffs))
    after = protection()
    assert after['passed'] and after['immutable_count'] == 901
    save('protection-after.json', after)
    physical = load(HERE / 'runs/physical-replay-final/artifacts/independent-report.json')
    parent = load(HERE / 'frozen/parent-frozen-reference.json')
    assert physical['exact']['slots'] == parent['known_exact_slots']
    assert physical['exact']['unavailable_candidate_arithmetic_performed'] is False
    positive = load(HERE / 'runs/regression-final-positive/artifacts/positive-equality.json')
    negative = load(HERE / 'runs/negative-equality-final/artifacts/negative-equality.json')
    assert positive['emitted_bodies_compared'] == 38
    assert negative['emitted_bodies_compared'] == 27
    red = ET.parse(HERE / 'runs/red-01/raw.xml').getroot().find('.//failure')
    assert red.get('message') == 'ValueError: wrong fixed authority'
    mutants = load(HERE / 'mutants-results.json')
    extra = load(HERE / 'runs/mutant-byte-ledger-complete/result.json')
    assert extra['actual_child_exit'] == 1 and extra['junit']['failures'] == 9
    for name in ['authority.json', 'record-schemas.json', 'protocol.json', 'trace.json']:
        run = HERE / 'runs' / ('missing-' + name)
        assert load(run / 'result.json')['actual_child_exit'] != 0
        assert name in (run / 'stderr.bin').read_text()
        assert 'FileNotFoundError' in (run / 'stderr.bin').read_text()
    files = scope(HERE)
    authored = [Path(n) for n in ROOT_FILES if n.endswith('.py')] + [
        Path('candidate') / n for n in CANDIDATE_FILES if n.endswith('.py')]
    privacy = scan(HERE, files, authored)
    save('privacy-security.json', privacy)
    assert privacy['passed'], privacy['findings']
    result = {
        'passed': True, 'role': 'author implementation and self-verification',
        'independent_approval': False, 'independent_review_pending': True,
        'case_id': 'CAP-after-qualifier-f64-GL', 'repository_writes': False,
        'implementation_authorized': False, 'a2_acceptance_passed': False,
        'total_numerical_certified': False, 'worker_fitter_ad_execution': False,
        'protocol_frozen': False, 'phase_closed': False, 'commit_push': False,
        'checkpoint': 'after_candidate_index_0_commit_before_candidate_index_1',
        'checkpoint_role': 'declared cooperative STATIC/HYPOTHETICAL primitive_cap '
                           'fault, not an OS kill or measured cap exhaustion',
        'outcome': {'status': 'indeterminate', 'selected_id': None,
                    'reasons': ['primitive_cap'], 'required_slots': 22,
                    'complete_slots': 13, 'unknown_slots': 9, 'json_records': 26,
                    'raw_logs': 2, 'process_exit': 'hypothetical normal confirmed 0'},
        'tdd': {
            'red': 'runs/red-01', 'red_child_exit': runs['red-01']['actual_child_exit'],
            'red_cause': red.get('message'), 'first_green': 'runs/green-01',
            'final_green': 'runs/controls-complete',
            'boundary_red': 'runs/boundary-red',
            'boundary_red_limit': 'Four flag controls already refused by schema; '
                                  'their RED was diagnostic-message mismatch, not '
                                  'missing refusal. The two nonzero counter controls '
                                  'were missing semantic refusals.',
            'defensive_controls': 'posthoc/mutation evidence, not TDD',
        },
        'regressions': {'prior_selections': len(final_ids),
                        'unchanged_original_trace_routing': 26,
                        'unchanged_nonqualifier_semantics': 31,
                        'unchanged_derivation_equality': 2,
                        'positive_bodies': 38, 'negative_bodies': 27,
                        'both_canonical_traces_equal': True},
        'final_new_selection': runs['controls-complete']['junit'],
        'checker': checker_pin, 'exact_math': physical['exact'],
        'physical_bytes': physical['physical']['ledger'],
        'parse_maxima': {k: physical['physical'][k] for k in [
            'max_parse_nodes', 'max_parse_depth']},
        'mutations': mutants, 'additional_charge_mutant_failures': 9,
        'lint': lint, 'privacy_scan_passed': privacy['passed'],
        'protected_files_verified_before_after': 901,
        'git_head': after['head'], 'git_stage_sha256': after['git_stage_sha256'],
        'runs': runs, 'blockers': [],
        'limitations': [
            'Fresh independent review is pending; no approval or phase closure claimed.',
            'One named finite static schedule only; not runtime, peakRAM, primitive '
            'or bit-counter measurement, security enforcement, or whole-packet admission.',
            'Eight FIT-REAL admission blockers remain open; numerical criteria/caps unchanged.',
            'Inherited archived checker/test Ruff findings remain (108 baseline, '
            '106 candidate); no introduced rule/context findings. The inherited '
            'capture helper has one E501. Repository lint is reported separately.',
            'Ten meaningful guard mutants killed; one inventory-guard mutant '
            'survived because a separate unavailable-binding guard still rejects it. '
            'Its initial schema-masked attempt is inconclusive and preserved.',
            'The initial nonqualifier regression failed only its expected diagnostic '
            'message; preserved before adding an earlier assessment-count guard.',
            'Initial kill-control spelling exercised schema only; corrected to '
            'schema-valid kill and rerun through the completion guard.',
            'Portable Python read auditing is not OS attestation or a hostile-filesystem sandbox.',
            'Privacy scan is bounded; raw hostnames and local paths remain in process evidence.',
        ],
        'paths': {'trace': str(HERE / 'runs/controls-complete/artifacts/trace.json'),
                  'physical_report': str(HERE / 'runs/physical-replay-final/artifacts'
                                         / 'independent-report.json'),
                  'authority_derivation': str(HERE / 'authority-derivation.json'),
                  'source_diff': str(HERE / 'source.diff'),
                  'proof': str(HERE), 'index': str(HERE / 'evidence-index.json')},
    }
    save('result.json', result)
    save('generated-allowlist.json', {
        'files': [str(p) for p in scope(HERE)] + ['generated-allowlist.json'],
        'excluded': ['evidence-index.json itself', 'runtime/cache/build trees'],
        'role': 'explicit inputs plus validated generated-output routes only',
    })
    files = scope(HERE)
    final_scan = scan(HERE, files, authored)
    assert final_scan['passed']
    index = {'file_count': len(files), 'files': {str(p): meta(HERE / p) for p in files},
             'excluded': ['self index', 'runtime/cache/build trees'],
             'final_recursive_scan': {'files': len(files), 'passed': True},
             'review_role': 'author self-verification; independent review pending'}
    save('evidence-index.json', index)
    assert scope(HERE) == files
    assert all(meta(HERE / p) == index['files'][str(p)] for p in files)
    print(json.dumps({'passed': True, 'indexed_files': len(files),
                      'result': str(HERE / 'result.json'),
                      'index': str(HERE / 'evidence-index.json'),
                      'index_sha256': meta(HERE / 'evidence-index.json')['sha256']}))


if __name__ == '__main__':
    main()
