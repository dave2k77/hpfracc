"""Inspect selected captured diagnostics; report mutations from real failures."""

import json
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    for name in ['lint-candidate-final', 'lint-new-final']:
        rows = json.loads((HERE / 'runs' / name / 'stdout.bin').read_bytes())
        print(name, len(rows))
        if name == 'lint-new-final':
            print(json.dumps([{'file': Path(r['filename']).name, 'code': r['code'],
                               'row': r['location']['row'], 'message': r['message']}
                              for r in rows], indent=2))
    reports = []
    plan = json.loads((HERE / 'mutants-plan.json').read_bytes())
    for item in plan:
        run = HERE / 'runs' / ('mutant-' + item['name'] + '-final')
        result = json.loads((run / 'result.json').read_bytes())
        failures = ET.parse(run / 'raw.xml').getroot().findall('.//failure')
        messages = [f.get('message') for f in failures]
        status = ('survived' if result['actual_child_exit'] == 0 else
                  'killed' if messages and all('DID NOT RAISE' in m for m in messages)
                  and result['junit']['errors'] == 0 else 'inconclusive')
        reports.append({'mutant': item['name'], 'outcome': status,
                        'actual_child_exit': result['actual_child_exit'],
                        'failure_messages': messages})
    report = {'mutants': reports, 'counts': dict(Counter(r['outcome'] for r in reports)),
              'initial_inventory_defense_attempt':
                  'inconclusive: schema-invalid empty returned list caused regex failure; '
                  'preserved; final corrected structural control survived because '
                  'the independent unavailable-binding guard still refuses it'}
    target = HERE / 'mutants-results.json'
    assert not target.exists()
    target.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
