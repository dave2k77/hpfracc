"""Three named STATIC/HYPOTHETICAL cases, one trusted local authority per run.

No JAX, fitter, numerical worker or general selector. Runtime/ownership fields
are illustrative conditions inherited from a labelled frozen witness, not observed
execution/security evidence. The two REF cases and CAP-after-qualifier are admitted.
This audit cannot validate FIT-REAL, arbitrary fixtures or production execution.
"""
import copy
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import struct

HERE = Path(__file__).resolve().parent
AUTHORITY = json.loads((HERE / 'authority.json').read_text())
CASE = AUTHORITY['case']['case_id']
SCHEMA = json.loads((HERE / 'record-schemas.json').read_text())
CAPS = json.loads((HERE / 'protocol.json').read_text())['caps']
STDOUT = b'STATIC HYPOTHETICAL STDOUT; NOT A WORKER RUN\n'
STDERR = b'STATIC HYPOTHETICAL STDERR; NOT A WORKER RUN\n'
ADMITTED = ('REF-PASS-f64-GL', 'REF-FAIL-f64-GL', 'CAP-after-qualifier-f64-GL')


def unavailable(index):
    """Only the frozen cooperative checkpoint, never a generic resource mode."""
    return CASE == 'CAP-after-qualifier-f64-GL' and index == 1


def authenticate_added_case():
    if CASE == 'CAP-after-qualifier-f64-GL':
        from frozen_case import authenticate

        authenticate(AUTHORITY)


def need(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('ascii')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def schema_check(value, rule):
    if '$ref' in rule:
        return schema_check(value, SCHEMA['$defs'][rule['$ref'].rsplit('/', 1)[-1]])
    for keyword in ('anyOf', 'oneOf'):
        if keyword in rule:
            matches = 0
            for branch in rule[keyword]:
                try:
                    schema_check(value, branch)
                except ValueError:
                    continue
                matches += 1
            need(matches == 1 if keyword == 'oneOf' else matches >= 1,
                 'schema ' + keyword)
    if 'enum' in rule:
        need(any(type(value) is type(x) and value == x for x in rule['enum']), 'schema enum/type')
    if 'type' in rule:
        types = {'object': dict, 'array': list, 'string': str,
                 'integer': int, 'boolean': bool, 'null': type(None)}
        need(type(value) is types[rule['type']], 'schema canonical type')
    if isinstance(value, dict) and 'properties' in rule:
        need(set(rule['required']) <= set(value), 'schema required keys')
        need(rule.get('additionalProperties') is False and set(value) <= set(rule['properties']),
             'schema closed keys')
        for key, item in value.items():
            schema_check(item, rule['properties'][key])
    if isinstance(value, list):
        need(rule.get('minItems', 0) <= len(value) <= rule.get('maxItems', 10**9), 'schema item count')
        if 'items' in rule:
            for item in value:
                schema_check(item, rule['items'])
    if type(value) is str:
        need(rule.get('minLength', 0) <= len(value) <= rule.get('maxLength', 10**9), 'schema string length')
        if 'pattern' in rule:
            need(re.fullmatch(rule['pattern'], value) is not None, 'schema string pattern')
    if type(value) is int:
        need(rule.get('minimum', -10**30) <= value <= rule.get('maximum', 10**30), 'schema integer range')


def metrics(value):
    if isinstance(value, dict):
        parts = [metrics(x) for x in value.values()]
        return 1 + len(value) + sum(x[0] for x in parts), 1 + max([1] + [x[1] for x in parts])
    if isinstance(value, list):
        parts = [metrics(x) for x in value]
        return 1 + sum(x[0] for x in parts), 1 + max([0] + [x[1] for x in parts])
    return 1, 1


def safe_path(path):
    need(type(path) is str and path and '\\' not in path and ':' not in path,
         'unsafe lexical path')
    p = PurePosixPath(path)
    need(not p.is_absolute() and p.as_posix() == path and
         all(x not in ('', '.', '..') for x in path.split('/')), 'unsafe lexical path')


def raw_files(trace):
    result = {path: canonical(value) for path, value in trace['records'].items()}
    for path, encoded in trace['logs'].items():
        need(path in ('logs/stdout.bin', 'logs/stderr.bin'), 'unexpected log')
        result[path] = bytes.fromhex(encoded)
    return result


def make_trace(mutate=None):
    """Relink a copy of one existing witness and close its exact byte snapshots."""
    original = AUTHORITY['bundle']
    need(CASE in ADMITTED and
         original['declared_case_id'] == CASE, 'wrong fixed authority')
    authenticate_added_case()
    records = copy.deepcopy(original['artifacts'])
    initial = copy.deepcopy(original['initial_failure_index'])
    if mutate is not None:
        mutate(records)
    launch = records['records/launch.json']
    launch['barrier'] = 'held'
    launch_hash = digest(canonical(launch))
    for value in records.values():
        if value.get('record_type') == 'producer_binding':
            value['launch_receipt_sha256'] = launch_hash
            binding_hash = digest(canonical(value))
            for returned in value['returned']:
                records['arrays/' + returned['slot_id'] + '.json']['producer_binding_sha256'] = binding_hash
    result = records['result.json']
    result['shared_slots'] = [copy.deepcopy(records['arrays/' + s['slot_id'] + '.json'])
                              for s in result['shared_slots']]
    for assessment in result['assessments']:
        assessment['slots'] = [copy.deepcopy(
            records.get('arrays/' + s['slot_id'] + '.json', s)
        ) for s in assessment['slots']]
    index = records['failure-index.json']
    for row in index['slots']:
        if 'arrays/' + row['slot_id'] + '.json' not in records:
            continue
        raw = canonical(records['arrays/' + row['slot_id'] + '.json'])
        row['artifact'] = {'path': 'arrays/' + row['slot_id'] + '.json',
                           'bytes': len(raw), 'sha256': digest(raw)}
    process = records['records/process.json']
    process['launch_receipt_sha256'] = launch_hash
    process['stdout_sha256'] = digest(STDOUT)
    process['stderr_sha256'] = digest(STDERR)
    index['process'] = copy.deepcopy(process)
    input_size = len(canonical(records['input-bundle.json']))
    initial['bytes_accounting'] = {'live_bytes': input_size,
                                   'cumulative_written_bytes': input_size,
                                   'reserved_final_transaction_bytes': CAPS['failure_index_bytes']}
    initial_size = len(canonical(initial))
    prefix = []
    for path in records:
        if path == 'result.json':
            break
        prefix.append(path)
    result['evidence_bytes'] = initial_size + sum(len(canonical(records[p])) for p in prefix)
    logs = {'logs/stdout.bin': STDOUT.hex(), 'logs/stderr.bin': STDERR.hex()}
    before_index = list(prefix) + ['result.json', 'records/process.json', 'records/output-control.json']
    before_size = initial_size + sum(len(canonical(records[p])) for p in before_index) + len(STDOUT) + len(STDERR)
    index['bytes_accounting'] = {'live_bytes': before_size,
                                'cumulative_written_bytes': before_size,
                                'reserved_final_transaction_bytes': CAPS['failure_index_bytes']}
    export = records['records/export.json']
    export['process_sha256'] = digest(canonical(process))
    export['failure_index_sha256'] = digest(canonical(index))
    export['failure_index_bytes'] = len(canonical(index))
    manifest = records['run-manifest.json']
    manifest['files'] = [
        {'path': p, 'bytes': len(canonical(v)), 'sha256': digest(canonical(v))}
        for p, v in records.items() if p != 'run-manifest.json'
    ] + [{'path': p, 'bytes': len(bytes.fromhex(v)), 'sha256': digest(bytes.fromhex(v))}
         for p, v in logs.items()]
    trace = {'label': AUTHORITY['label'], 'case_id': CASE, 'records': records,
             'initial_index': initial, 'logs': logs, 'events': []}
    for path in records:
        if path == 'records/process.json':
            for log in logs:
                trace['events'].append({'op': 'write', 'path': log, 'body': log})
        if path == 'failure-index.json':
            trace['events'].append({'op': 'write', 'path': 'tmp/index-final.part', 'body': path})
            trace['events'].append({'op': 'replace', 'source': 'tmp/index-final.part', 'target': path})
        else:
            trace['events'].append({'op': 'write', 'path': path, 'body': path})
        if path == 'input-bundle.json':
            trace['events'].append({'op': 'write', 'path': 'failure-index.json', 'body': 'INITIAL_INDEX'})
    files = raw_files(trace)
    terms = {p: len(data) for p, data in files.items()}
    terms['INITIAL_INDEX'] = initial_size
    final_live = sum(len(data) for data in files.values())
    peak = max(final_live, final_live + initial_size - len(files['records/export.json']) - len(files['run-manifest.json']))
    transaction = initial_size + len(files['failure-index.json']) + sum(
        len(files[p]) for p in ['records/process.json', 'records/export.json', 'records/output-control.json'])
    trace['ledger'] = {'terms': terms, 'cumulative_written_bytes': sum(terms.values()),
                       'final_live_bytes': final_live, 'peak_live_bytes': peak,
                       'index_transaction_bytes': transaction,
                       'temporary_bytes_charged': len(files['failure-index.json']),
                       'old_index_bytes_charged': initial_size}
    return trace


def replay_ledger(trace):
    """Independent state-map replay: do not consume builder totals or its sums."""
    bodies = raw_files(trace)
    bodies['INITIAL_INDEX'] = canonical(trace['initial_index'])
    live = {}
    terms = {}
    cumulative = peak = 0
    snapshots = {}
    for event in trace['events']:
        if event['op'] == 'write':
            need(set(event) == {'op', 'path', 'body'}, 'journal write fields')
            path, body = event['path'], event['body']
            safe_path(path)
            need(path not in live and body in bodies and body not in terms, 'journal duplicate/missing write')
            if body == 'result.json' or body == 'failure-index.json' or body == 'INITIAL_INDEX':
                snapshots[body] = {'live_bytes': sum(len(x) for x in live.values()),
                                   'cumulative_written_bytes': cumulative}
            data = bodies[body]
            live[path] = data
            cumulative += len(data)
            terms[body] = len(data)
        else:
            need(event == {'op': 'replace', 'source': 'tmp/index-final.part', 'target': 'failure-index.json'},
                 'journal replace fields')
            need(live.get('failure-index.json') == bodies['INITIAL_INDEX'] and
                 live.get('tmp/index-final.part') == bodies['failure-index.json'], 'atomic old/new coexistence')
            live['failure-index.json'] = live.pop('tmp/index-final.part')
        peak = max(peak, sum(len(x) for x in live.values()))
        need(cumulative <= CAPS['evidence_bytes'] and peak <= CAPS['evidence_bytes'], 'whole byte cap')
    final = raw_files(trace)
    need(live == final, 'journal final files differ from all emitted bytes')
    need(set(terms) == set(bodies), 'journal did not charge every body')
    records = trace['records']
    need(records['result.json']['evidence_bytes'] == snapshots['result.json']['live_bytes'], 'result pre-write snapshot')
    for body, record in [('INITIAL_INDEX', trace['initial_index']), ('failure-index.json', records['failure-index.json'])]:
        expected = snapshots[body] | {'reserved_final_transaction_bytes': CAPS['failure_index_bytes']}
        need(record['bytes_accounting'] == expected, 'index pre-write snapshot')
    transaction = len(bodies['INITIAL_INDEX']) + len(final['failure-index.json'])
    for path in ['records/process.json', 'records/export.json', 'records/output-control.json']:
        transaction += len(final[path])
    need(transaction <= CAPS['failure_index_bytes'], 'index transaction cap')
    return {'terms': terms, 'cumulative_written_bytes': cumulative,
            'final_live_bytes': sum(len(x) for x in live.values()), 'peak_live_bytes': peak,
            'index_transaction_bytes': transaction,
            'temporary_bytes_charged': len(final['failure-index.json']),
            'old_index_bytes_charged': len(bodies['INITIAL_INDEX'])}


def rational(value):
    schema_check(value, SCHEMA['$defs']['rat'])
    numerator, denominator = int(value['num'], 16), int(value['den'], 16)
    need(math.gcd(abs(numerator), denominator) == 1 and
         max(abs(numerator).bit_length(), denominator.bit_length()) <= CAPS['normalized_bits'],
         'canonical reduced rational')
    need(numerator != 0 or denominator == 1, 'canonical zero')
    return Fraction(numerator, denominator)


def check_completion(records):
    request = records['input-bundle.json']['request']
    result = records['result.json']
    process = records['records/process.json']
    need(process['termination'] == 'normal' and process['exit_confirmed'] is True and
         process['exit_code'] == 0 and not process['watchdog_triggered'],
         'completion requires a confirmed normal conditional exit')
    need(len(result['assessments']) == len(request['candidates']),
         'selection fixed-case complete assessment inventory')
    qualifiers = []
    unknown = False
    for i, (candidate, assessment) in enumerate(zip(request['candidates'], result['assessments'], strict=True)):
        need(assessment['candidate_id'] == candidate['stable_id'] and assessment['candidate_index'] == i,
             'selection supplied occurrence identity')
        if unavailable(i):
            need(assessment['status'] == 'unknown' and assessment['qualifies'] is None
                 and assessment['reasons'] == ['primitive_cap'],
                 'selection frozen checkpoint unknown assessment')
            unknown = True
            continue
        need(assessment['status'] in ('known_qualifying', 'known_rejected_by_bound') and
             assessment['reasons'] == ['none'],
             'selection cannot succeed with unknown assessments')
        bounds = records['arrays/S-' + str(i) + '-B.json']['exact_array']
        qualifies = all(rational(x) <= rational(request['tau']) for x in bounds['values'])
        need(assessment['qualifies'] is qualifies and
             assessment['status'] == ('known_qualifying' if qualifies else 'known_rejected_by_bound'),
             'selection qualification must follow every exact bound')
        if qualifies:
            qualifiers.append((candidate['configuration']['pole_count'], candidate['stable_id']))
    expected_status = 'selected' if qualifiers else 'no_supplied_candidate_meets_bound'
    expected_id = min(qualifiers)[1] if qualifiers else None
    expected_reasons = ['none']
    if unknown:
        expected_status, expected_id = 'indeterminate', None
        expected_reasons = ['primitive_cap']
    need(result['status'] == expected_status and result['selected_id'] == expected_id,
         'selection must follow exhaustive known qualification')
    need(result['reasons'] == expected_reasons, 'selection exhaustive reasons')


def raw_descriptor(value):
    return {k: v for k, v in value.items() if k != 'raw_hex'}


def check_links(trace):
    records = trace['records']
    bundle = records['input-bundle.json']
    request = bundle['request']
    need(request == AUTHORITY['bundle']['artifacts']['input-bundle.json']['request'],
         'binding fixed-case authenticated request')
    need(bundle['sources'] == AUTHORITY['bundle']['artifacts']['input-bundle.json']['sources'],
         'binding frozen source inventory')
    need(records['records/request.json'] == request, 'binding request copy')
    need(bundle['raw_request_utf8_hex'] == '' and
         bundle['raw_request_sha256'] == digest(canonical(request)), 'binding complete raw request capture')
    input_hash = digest(canonical(bundle))
    launch = records['records/launch.json']
    launch_hash = digest(canonical(launch))
    process = records['records/process.json']
    for value in records.values():
        for field in ('case_id', 'request_id'):
            if field in value:
                need(value[field] == CASE, 'binding case identity')
        if 'input_bundle_sha256' in value:
            need(value['input_bundle_sha256'] == input_hash, 'binding input digest')
        if 'packet_manifest_sha256' in value:
            need(value['packet_manifest_sha256'] == AUTHORITY['packet_digest'], 'binding hypothetical packet identity')
        if 'policy_id' in value:
            need(value['policy_id'] == request['policy_id'], 'binding policy identity')
        for field in ('run_id', 'process_id'):
            if field in value:
                need(value[field] == launch[field], 'binding process/run identity')
    need(launch['status'] == 'launched' and launch['sources'] == bundle['sources'] and
         process['launch_receipt_sha256'] == launch_hash and process['command'] == launch['command'],
         'binding launch/process source and command')
    expected_inventory = []
    by_id = {}
    result = records['result.json']
    need(len(result['assessments']) == len(request['candidates']),
         'selection fixed-case complete assessment inventory')
    inline = result['shared_slots'] + [
        s for a in result['assessments'] for s in a['slots']
    ]
    need(len(inline) == len(AUTHORITY['case']['required_evidence_slots']) and
         len({s['slot_id'] for s in inline}) == len(inline),
         'binding complete inline inventory')
    inline_by_id = {s['slot_id']: s for s in inline}
    for item in AUTHORITY['case']['required_evidence_slots']:
        sid = item['slot_id']
        path = 'arrays/' + sid + '.json'
        need(sid in inline_by_id, 'binding required inline slot')
        slot = inline_by_id[sid] if unavailable(item['candidate_index']) else records.get(path)
        need(slot is not None, 'binding missing known slot')
        expected = {k: item[k] for k in ['slot_id', 'candidate_index', 'mode', 'branch', 'quantity']}
        i = expected['candidate_index']
        expected['candidate_id'] = None if i is None else request['candidates'][i]['stable_id']
        expected_inventory.append(expected)
        need(all(slot[k] == v for k, v in expected.items()), 'binding slot occurrence/mode/branch')
        need(slot['case_id'] == CASE, 'binding inline case identity')
        by_id[sid] = slot
        if unavailable(i):
            need(slot['status'] == 'unknown' and slot['reason'] == 'primitive_cap'
                 and slot['reasons'] == ['primitive_cap']
                 and all(slot[k] is None for k in [
                     'raw_array', 'exact_array', 'producer_binding_sha256'
                 ]) and path not in records, 'binding unavailable null disposition')
            continue
        need(slot['status'] == 'complete' and slot['reasons'] == ['none'] and
             slot['reason'] == 'none' and slot['raw_array'] is None, 'binding complete exact slot')
        payload = slot['exact_array']
        shape = [] if item['quantity'] == 'epsilon' else ([3, 3] if item['quantity'] == 'L_hat' else [3])
        need(payload is not None and payload['shape'] == shape and
             len(payload['values']) == math.prod(shape), 'binding authoritative slot shape/cardinality')
        for number in payload['values']:
            rational(number)
        by_id[sid] = slot
    need(bundle['required_slots'] == expected_inventory, 'binding exact preinventory')
    ids = [c['stable_id'] for c in request['candidates']]
    occurrences = [{'candidate_index': i, 'candidate_id': c} for i, c in enumerate(ids)]
    need(bundle['candidate_ids'] == ids and bundle['candidate_occurrences'] == occurrences and
         bundle['required_comparisons'] == [] and bundle['required_binding_checks'] == [],
         'binding fixed supplied/invocation inventory')
    scalar = AUTHORITY['working_scalars']['float64']
    for suffix, i in [('X', None)] + [(str(i), i) for i in range(len(ids))]:
        if i is not None:
            need(records.get('records/candidate-' + str(i) + '.json') == request['candidates'][i],
                 'binding candidate copy')
        if unavailable(i):
            need('records/binding-host-' + suffix + '.json' not in records,
                 'binding unavailable producer must remain absent')
            continue
        binding = records['records/binding-host-' + suffix + '.json']
        need(binding['binding_id'] == 'host-' + suffix, 'binding path-to-ID')
        expected_slots = [s for s in by_id.values() if s['candidate_index'] == i]
        mode = 'shared' if i is None else 'synthetic'
        need(binding['mode'] == mode and binding['branch'] == 'base' and
             binding['candidate_index'] == i and
             binding['candidate_id'] == (None if i is None else ids[i]), 'binding mode/occurrence')
        template = AUTHORITY['bundle']['artifacts']['records/binding-host-X.json']
        config = template['configuration'] if i is None else request['candidates'][i]['configuration']
        producer = template['producer'] if i is None else request['candidates'][i]['producer']
        need(binding['configuration'] == config and binding['producer'] == producer,
             'binding source configuration/producer')
        need(binding['sources'] == bundle['sources'] and binding['launch_receipt_sha256'] == launch_hash,
             'binding launch/source links')
        need(binding['input'] == raw_descriptor(request['input']) and
             binding['alpha'] == raw_descriptor(scalar['alpha']) and
             binding['dt'] == raw_descriptor(scalar['dt']) and
             binding['h'] is None and binding['direction'] is None,
             'binding actual input/alpha/dt descriptors')
        returned = []
        for slot in expected_slots:
            payload = slot['exact_array']
            returned.append({'slot_id': slot['slot_id'], 'quantity': slot['quantity'],
                             'descriptor': {'shape': payload['shape'], 'values_count': len(payload['values']),
                                            'payload_sha256': digest(canonical(payload))}})
            need(slot['producer_binding_sha256'] == digest(canonical(binding)), 'binding slot digest')
        need(binding['returned'] == returned, 'binding exact returned descriptors')

    result = records['result.json']
    need(result['shared_slots'] == [s for s in by_id.values() if s['candidate_index'] is None],
         'binding result shared inline copies')
    for i, assessment in enumerate(result['assessments']):
        need(assessment['slots'] == [s for s in by_id.values() if s['candidate_index'] == i],
             'binding result candidate inline copies')
    index = records['failure-index.json']
    has_unknown = any(s['status'] == 'unknown' for s in by_id.values())
    need(index['candidate_ids'] == ids and index['candidate_occurrences'] == occurrences and
         index['status'] == ('indeterminate' if has_unknown else 'complete') and
         index['reasons'] == (['primitive_cap'] if has_unknown else ['none']) and
         index['process'] == process and index['comparisons'] == [] and index['binding_checks'] == [],
         'binding final index completion/copies')
    need(len(index['slots']) == len(expected_inventory), 'binding index complete slot count')
    for row, expected in zip(index['slots'], expected_inventory, strict=True):
        slot = by_id[expected['slot_id']]
        if unavailable(expected['candidate_index']):
            shape = ([] if expected['quantity'] == 'epsilon' else
                     [3, 3] if expected['quantity'] == 'L_hat' else [3])
            need(all(row[k] == v for k, v in expected.items()) and
                 row['status'] == 'unknown' and row['reason'] == 'primitive_cap' and
                 row['reasons'] == ['primitive_cap'] and row['expected_shape'] == shape
                 and row['completed_shape'] is None and row['artifact'] is None,
                 'binding unknown index null shape/artifact')
            continue
        raw = canonical(slot)
        need(all(row[k] == v for k, v in expected.items()) and row['status'] == 'complete' and
             row['reason'] == 'none' and row['reasons'] == ['none'] and
             row['expected_shape'] == slot['exact_array']['shape'] and
             row['completed_shape'] == row['expected_shape'] and
             row['artifact'] == {'path': 'arrays/' + slot['slot_id'] + '.json',
                                 'bytes': len(raw), 'sha256': digest(raw)}, 'binding index slot shape/artifact')
    initial = trace['initial_index']
    initial_template = AUTHORITY['bundle']['initial_failure_index']
    need({k: v for k, v in initial.items() if k != 'bytes_accounting'} ==
         {k: v for k, v in initial_template.items() if k != 'bytes_accounting'},
         'binding initialized exhaustive inventory')
    export = records['records/export.json']
    need(export['status'] == 'complete' and export['reasons'] == ['none'] and
         export['process_sha256'] == digest(canonical(process)) and
         export['failure_index_sha256'] == digest(canonical(index)) and
         export['failure_index_bytes'] == len(canonical(index)), 'binding later export receipt')
    files = raw_files(trace)
    manifest = records['run-manifest.json']
    entries = manifest['files']
    need(len(entries) == len(files) - 1 and len({x['path'] for x in entries}) == len(entries),
         'binding unique manifest inventory')
    need({x['path']: (x['bytes'], x['sha256']) for x in entries} ==
         {p: (len(raw), digest(raw)) for p, raw in files.items() if p != 'run-manifest.json'},
         'binding manifest lengths/digests')
    for stream in ('stdout', 'stderr'):
        raw = files['logs/' + stream + '.bin']
        need(len(raw) <= CAPS[stream + '_bytes'] and process[stream + '_sha256'] == digest(raw) and
             process[stream + '_truncated'] is False, 'binding raw bounded logs')
    control = records['records/output-control.json']
    need(control['status'] == 'safe' and control['reasons'] == ['none'] and all(
        control[k] is True for k in ['fresh_private_root', 'subdirs_private', 'nofollow_verified',
                                     'regular_owned_single_link', 'containment_verified']),
         'binding conditional safe-output context')


def check_fixed_exact_payloads(records):
    """Read-only exact identities for this N=3 supplied static case ONLY.

    Not a general reference worker, fitter or execution/counter certification.
    Static process/counter fields are illustrative, not observations of this check.
    """
    request = records['input-bundle.json']['request']

    def decoded(raw):
        data = bytes.fromhex(raw['raw_hex'])
        count = math.prod(raw['shape'])
        need(raw['dtype'] == 'float64' and raw['byte_order'] == 'little' and
             len(data) == raw['nbytes'] == 8 * count and digest(data) == raw['sha256'],
             'exact identity authenticated fixed raw input')
        values = struct.unpack('<' + 'd' * count, data)
        need(all(math.isfinite(v) for v in values), 'exact identity finite input')
        return [Fraction.from_float(v) for v in values]

    def check_slot(sid, expected):
        values = records['arrays/' + sid + '.json']['exact_array']['values']
        need([rational(v) for v in values] == expected, 'exact identity ' + sid)

    x = decoded(request['input'])
    need(len(x) == 3, 'exact identity fixed N=3')
    w = [Fraction(1), Fraction(-1, 2), Fraction(-1, 8)]
    g = [Fraction(1), Fraction(1, 2), Fraction(3, 8)]
    v = [x[0], x[1] - x[0], x[2] - x[1]]
    direct = [2 * sum(w[k] * x[i-k] for k in range(i+1)) for i in range(3)]
    need([sum(w[:i+1]) for i in range(3)] == g, 'exact identity signed prefix')
    for name, values in [('w', w), ('g', g), ('v', v), ('D', direct)]:
        check_slot('S-X-' + name, values)
    for index, candidate in enumerate(request['candidates']):
        if unavailable(index):
            continue  # supplied bytes authenticated; no unavailable fit arithmetic
        c, rho = decoded(candidate['coefficients']), decoded(candidate['rhos'])
        need(len(c) == len(rho) == candidate['configuration']['pole_count'] and
             all(a >= 0 for a in c) and all(0 < a <= 1 for a in rho), 'exact identity supplied eligibility')
        fitted = [Fraction(1), sum(c), sum(a*b for a, b in zip(c, rho, strict=True))]
        residual = [a-b for a, b in zip(fitted, g, strict=True)]
        epsilon = max(abs(a) for a in residual)
        weights = [fitted[0], fitted[1]-fitted[0], fitted[2]-fitted[1]]
        matrix = [2*weights[i-j] if j <= i else Fraction(0)
                  for i in range(3) for j in range(3)]
        output = [sum(matrix[3*i+j]*x[j] for j in range(3)) for i in range(3)]
        increment = [2*sum(fitted[k]*v[i-k] for k in range(i+1)) for i in range(3)]
        need(output == increment, 'exact identity direct fitted signed')
        need([output[i]-direct[i] for i in range(3)] ==
             [2*sum(residual[k]*v[i-k] for k in range(i+1)) for i in range(3)],
             'exact identity residual output')
        error = [abs(a-b) for a, b in zip(output, direct, strict=True)]
        bound = [2*epsilon*sum(abs(a) for a in v[:i]) for i in range(3)]
        need(all(a <= b for a, b in zip(error, bound, strict=True)), 'exact identity compression bound')
        gradient = [Fraction(2, 3)*sum(matrix[3*i+j]*output[i] for i in range(3)) for j in range(3)]
        quantities = {'g_hat': fitted, 'residual': residual, 'signed_fitted_weights': weights,
                      'L_hat': matrix, 'D_hat': output, 'error': error, 'B': bound,
                      'epsilon': [epsilon], 'analytic_input_gradient': gradient}
        for name, values in quantities.items():
            check_slot('S-' + str(index) + '-' + name, values)


def check_lifecycle(trace):
    records = trace['records']
    process = records['records/process.json']
    launch = records['records/launch.json']
    phases = process['phases']
    for key in ['preflight', 'watchdog']:
        phase = phases[key]
        need(phase['status'] == 'observed' and phase['reason'] == 'none' and
             0 <= phase['start_ns'] <= phase['end_ns'] and
             phase['end_ns'] - phase['start_ns'] == phase['elapsed_ns'], 'phase ordered exact duration')
    need(phases['preflight']['end_ns'] <= launch['launch_monotonic_ns'] == phases['watchdog']['start_ns'] and
         process['elapsed_monotonic_ns'] == phases['watchdog']['elapsed_ns'] and
         launch['barrier'] == 'held' and process['barrier'] == 'released', 'phase launch/confirmed-exit linkage')
    for key in ['grace', 'kill_to_exit']:
        need(phases[key] == {'status': 'not_applicable', 'start_ns': None, 'end_ns': None,
                             'elapsed_ns': None, 'reason': 'stage_not_used'}, 'phase unused normal-exit interval')
    export = records['records/export.json']['index_write']
    need(export['status'] == 'observed' and export['reason'] == 'none' and
         phases['watchdog']['end_ns'] <= export['start_ns'] <= export['end_ns'] and
         export['end_ns'] - export['start_ns'] == export['elapsed_ns'], 'phase later index-write receipt')
    positions = {e['body']: i for i, e in enumerate(trace['events']) if e['op'] == 'write'}
    need(positions['input-bundle.json'] == 0 and positions['INITIAL_INDEX'] == 1 and
         positions['records/launch.json'] == 2, 'publication order preflight before launch')
    for path, value in records.items():
        if value['record_type'] == 'producer_binding':
            need(positions['records/launch.json'] < positions[path], 'publication order launch before binding')
            for returned in value['returned']:
                need(positions[path] < positions['arrays/' + returned['slot_id'] + '.json'] < positions['result.json'],
                     'publication order binding then slot then result')
    need(positions['result.json'] < positions['records/process.json'] and
         all(positions[p] < positions['records/process.json'] for p in ['logs/stdout.bin', 'logs/stderr.bin']) and
         max(positions['records/process.json'], positions['records/output-control.json']) < positions['failure-index.json'],
         'publication order finalized process before index')
    replacements = [i for i, e in enumerate(trace['events']) if e['op'] == 'replace']
    need(len(replacements) == 1 and positions['failure-index.json'] < replacements[0] <
         positions['records/export.json'] < positions['run-manifest.json'] == len(trace['events']) - 1,
         'publication order index, replacement, later receipt, external manifest')


def verify_trace(trace):
    need(CASE in ADMITTED and
         trace['case_id'] == CASE and trace['label'] == AUTHORITY['label'],
         'fixed hypothetical scope')
    authenticate_added_case()
    records = trace['records']
    need(set(records) == set(AUTHORITY['bundle']['artifacts']), 'fixed record inventory')
    result = records['result.json']
    need(all(result[k] is False for k in [
        'implementation_authorized', 'a2_acceptance_passed',
        'arithmetic_verified', 'total_numerical_certified'
    ]) and result['primitive_count'] == 0 and result['max_normalized_bits'] == 0,
         'hypothetical boundary: false flags and unmeasured zero placeholders')
    for path, value in records.items():
        safe_path(path)
        schema_check(value, SCHEMA)
        nodes, depth = metrics(value)
        need(nodes <= CAPS['json_nodes'] and depth <= CAPS['json_depth'], 'per-record parse bounds')
        byte_cap = CAPS['input_bundle_bytes'] if path == 'input-bundle.json' else (
            CAPS['failure_index_bytes'] if path == 'failure-index.json' else CAPS['evidence_bytes'])
        need(len(canonical(value)) <= byte_cap, 'per-record byte bound')
    schema_check(trace['initial_index'], SCHEMA['$defs']['failure_index'])
    slots = [v for v in records.values() if v['record_type'] == 'slot']
    required = AUTHORITY['case']['required_evidence_slots']
    unknown_count = sum(unavailable(s['candidate_index']) for s in required)
    need(len(slots) == len(required) - unknown_count,
         'fixed slot inventory')
    check_links(trace)
    check_completion(records)
    check_fixed_exact_payloads(records)
    check_lifecycle(trace)
    ledger = replay_ledger(trace)
    need(trace['ledger'] == ledger, 'ledger claim differs from independent byte replay')
    return {'case_id': CASE, 'slot_count': len(required), 'ledger': ledger,
            'required_slot_count': len(required), 'complete_slot_count': len(slots),
            'unknown_slot_count': unknown_count,
            'implementation_authorized': False, 'a2_acceptance_passed': False}
