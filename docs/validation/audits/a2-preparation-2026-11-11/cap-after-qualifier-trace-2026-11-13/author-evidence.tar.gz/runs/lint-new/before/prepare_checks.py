"""Prepare portable, missing-input, equality, and explicit lint jobs."""

from jobs import FROZEN, HERE, OLD, base, job


def main():
    sources = base(HERE / 'candidate/a2_trace.py') | {
        n: HERE / 'candidate' / n for n in [
            'authority.json', 'frozen_case.py', 'verify_cap.py'
        ]
    } | {n: FROZEN / 'inputs' / n for n in [
        'fixtures.json', 'schema-control-fixtures.json'
    ]} | {'trace.json': HERE / 'runs/controls-01/artifacts/trace.json'}
    job('physical-replay', sources, command=['{before}/verify_cap.py', 'replay'])
    job('read-guard-control', sources,
        command=['{before}/verify_cap.py', 'guard-probe'])
    for name in ['authority.json', 'record-schemas.json', 'protocol.json', 'trace.json']:
        job('missing-' + name, {k: v for k, v in sources.items() if k != name},
            command=['{before}/verify_cap.py', 'replay'])
    equality = base(HERE / 'candidate/a2_trace.py') | {
        'authority.json': OLD / 'final/authority.json',
        'test_a2_nonqualifier.py': OLD / 'final/test_a2_nonqualifier.py',
        'test_old_equality.py': HERE / 'candidate/test_old_equality.py',
        'reviewed-negative-trace.json': OLD / 'final/trace.json',
    }
    job('negative-equality', equality, ['test_old_equality.py'])
    old_sources = {'a2_trace.py': OLD / 'final/a2_trace.py'} | {
        n: OLD / 'baseline' / n for n in ['test_a2_trace.py', 'test_a2_routing.py']
    } | {n: OLD / 'final' / n for n in [
        'test_a2_nonqualifier.py', 'test_semantics.py', 'test_equality.py',
        'test_derivation.py', 'verify_independent.py'
    ]}
    for label, files in [
        ('lint-baseline', old_sources),
        ('lint-candidate', old_sources | {'a2_trace.py': HERE / 'candidate/a2_trace.py'}),
        ('lint-new', {n: HERE / 'candidate' / n for n in [
            'test_cap_after.py', 'test_controls.py', 'test_old_equality.py',
            'frozen_case.py', 'verify_cap.py'
        ]} | {n: HERE / n for n in [
            'bootstrap.py', 'capture.py', 'jobs.py', 'derive.py', 'run_jobs.py',
            'prepare_replay.py', 'prepare_checks.py'
        ]}),
    ]:
        job(label, files | {'pyproject.toml': FROZEN / 'inputs/pyproject.toml'},
            command=['-m', 'ruff', 'check', '--no-cache', '--output-format=json']
            + list(files))


if __name__ == '__main__':
    main()
