"""Derive one authority by exact frozen subsection selection; no arithmetic."""

import json
from pathlib import Path

from jobs import FROZEN, HERE, OLD, meta, save

CASE = 'CAP-after-qualifier-f64-GL'


def main():
    fixture = json.loads((FROZEN / 'inputs/fixtures.json').read_bytes())
    controls = json.loads((FROZEN / 'inputs/schema-control-fixtures.json').read_bytes())
    prior = json.loads((OLD / 'final/authority.json').read_bytes())
    case = next(x for x in fixture['cases'] if x['case_id'] == CASE)
    bundle = next(x for x in controls['bundles']
                  if x['witness_id'] == 'afterqual-' + CASE)
    assert case == json.loads((FROZEN / 'selected-case.json').read_bytes())
    assert bundle == json.loads((FROZEN / 'selected-witness.json').read_bytes())
    authority = {'case': case, 'bundle': bundle,
                 'working_scalars': fixture['working_scalars'],
                 'label': controls['label'], 'scope': prior['scope'],
                 'packet_digest': controls['hypothetical_external_packet_sha256']}
    save(HERE / 'candidate/authority.json', authority)
    save(HERE / 'authority-derivation.json', {
        'role': 'exact frozen slice; no worker observations or candidate arithmetic',
        'inputs': {n: meta(FROZEN / 'inputs' / n) for n in [
            'fixtures.json', 'schema-control-fixtures.json', 'protocol.json']},
        'authority': meta(HERE / 'candidate/authority.json'),
        'case_selector': CASE, 'witness_selector': 'afterqual-' + CASE,
        'selected_case_equal': True, 'selected_witness_equal': True,
    })
    request = bundle['artifacts']['input-bundle.json']['request']
    print(json.dumps({
        'fixture_candidate': fixture['candidates'][case['request']['candidate_refs'][0]],
        'expanded_request': request,
        'fixture_array': fixture['arrays'][case['request']['input_ref']],
        'exact_slot_inventory': fixture['exact_slot_inventory'],
        'protocol_keys': list(json.loads((FROZEN / 'inputs/protocol.json').read_bytes())),
    }, indent=2))


if __name__ == '__main__':
    main()
