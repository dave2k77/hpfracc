"""Explicit allowlisted copy and protected-byte check; no repository writes."""

import hashlib
import json
import shutil
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
PARENT = Path('/home/davianc/.hermes/cache/scratch') / 'hpfracc-cap-after-preflight-20261113'
WORK = (ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
        / 'cap-after-qualifier-trace-2026-11-13')


def meta(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def protection():
    baseline = json.loads((WORK / 'baseline-inputs.json').read_bytes())
    mutable = {'docs/developer/phase-a-completion.md',
               'docs/developer/bug-resolution-tracker.md'}
    actual = {p: meta(ROOT / p) for p in baseline['files'] if p not in mutable}
    expected = {p: v for p, v in baseline['files'].items() if p not in mutable}
    raw_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT)
    head = raw_head.decode().strip()
    stage = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT)
    report = {'immutable_count': len(actual), 'files': actual, 'head': head,
              'git_stage_sha256': hashlib.sha256(stage).hexdigest(),
              'git_stage_encoding': baseline['git_stage_encoding'],
              'mutable_exclusions': sorted(mutable),
              'differences': [p for p in actual if actual[p] != expected[p]]}
    report['passed'] = (not report['differences'] and head == baseline['head']
                        and report['git_stage_sha256'] == baseline['git_stage_sha256'])
    return report


def main():
    report = protection()
    save(HERE / 'protection-before.json', report)
    assert report['passed'] and report['immutable_count'] == 901
    pins = json.loads((PARENT / 'copied-inputs.json').read_bytes())
    index = json.loads((PARENT / 'previous-author-index.json').read_bytes())
    assert len(index['files']) == index['file_count'] == 775
    for name, pin in pins.items():
        assert meta(PARENT / name) == pin, name
        if name.startswith('previous-author/'):
            assert index['files'][name.removeprefix('previous-author/')] == pin
        dest = HERE / 'frozen' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(PARENT / name, dest)
    for name in ['authorization.json', 'preflight.json', 'baseline-inputs.json',
                 'parent-frozen-reference.json']:
        shutil.copyfile(WORK / name, HERE / 'frozen' / name)
    save(HERE / 'copied-inputs.json', pins)
    candidate = HERE / 'candidate'
    candidate.mkdir()
    shutil.copyfile(HERE / 'frozen/previous-author/final/a2_trace.py',
                    candidate / 'a2_trace.py')
    for name in ['protocol.json', 'record-schemas.json', 'pyproject.toml']:
        shutil.copyfile(HERE / 'frozen/inputs' / name, candidate / name)
    fixture = json.loads((HERE / 'frozen/inputs/fixtures.json').read_bytes())
    witness = json.loads((HERE / 'frozen/selected-witness.json').read_bytes())
    previous_path = HERE / 'frozen/previous-author/final/authority.json'
    previous = json.loads(previous_path.read_bytes())
    print(json.dumps({'fixture_keys': list(fixture),
                      'fixture_library_types': {
                          k: type(v).__name__ for k, v in fixture.items()},
                      'witness_keys': list(witness), 'scope': previous['scope'],
                      'artifacts': list(witness['artifacts']),
                      'result': witness['artifacts']['result.json'],
                      'sample_unknown_index':
                          witness['artifacts']['failure-index.json']['slots'][-1]},
                     indent=2))


if __name__ == '__main__':
    main()
