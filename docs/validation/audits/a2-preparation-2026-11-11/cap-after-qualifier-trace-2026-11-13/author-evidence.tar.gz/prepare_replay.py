"""Copy the preserved independent-method helper before targeted adaptation."""

import shutil

from jobs import HERE, OLD

source = OLD / 'final/verify_independent.py'
target = HERE / 'candidate/verify_cap.py'
assert not target.exists()
shutil.copyfile(source, target)
print(str(target))
