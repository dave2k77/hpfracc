"""Launch already prepared jobs; wrapper success never means child success."""

import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    summaries = []
    for name in sys.argv[1:]:
        job = HERE / 'jobs' / (name + '.json')
        subprocess.run([sys.executable, '-B', str(HERE / 'capture.py'), str(job)],
                       check=True)
        plan = json.loads(job.read_bytes())
        result = json.loads((Path(plan['run']) / 'result.json').read_bytes())
        summaries.append({'name': name, 'child_exit': result['actual_child_exit']})
    print(json.dumps(summaries))


if __name__ == '__main__':
    main()
