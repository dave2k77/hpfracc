"""Prepare explicit inputs and literal execution jobs; never launch tests here."""

import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
FROZEN = HERE / 'frozen'
OLD = FROZEN / 'previous-author'


def meta(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2) + '\n')


def job(name, inputs, selection=None, command=None):
    run = HERE / 'runs' / name
    before = run / 'before'
    prefix = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync',
              'python', '-B']
    if command is None:
        command = ['-m', 'pytest', '-q', '-p', 'no:cacheprovider',
                   '--basetemp=' + str(run / 'runtime' / 'pytest'),
                   '--junitxml=' + str(run / 'raw.xml')] + selection
    argv = prefix + [s.replace('{before}', str(before)) for s in command]
    env = {'PYTHONDONTWRITEBYTECODE': '1', 'JAX_PLATFORMS': 'cpu',
           'UV_PROJECT_ENVIRONMENT': str(ROOT / '.venv'),
           'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1', 'TMPDIR': str(run / 'runtime')}
    plan = {'run': str(run), 'cwd': str(before), 'argv': argv, 'environment': env,
            'selection': selection, 'scope': 'author static self-verification only',
            'inputs': {n: {'path': str(p), 'pin': meta(p)} for n, p in inputs.items()},
            'capture_entrypoint': {'path': str(HERE / 'capture.py'),
                                   'pin': meta(HERE / 'capture.py')}}
    save(HERE / 'jobs' / (name + '.json'), plan)
    print(str(HERE / 'jobs' / (name + '.json')))


def base(checker):
    return {'a2_trace.py': checker} | {
        n: FROZEN / 'inputs' / n
        for n in ['protocol.json', 'record-schemas.json', 'pyproject.toml']
    }


def regression(name, checker):
    positive = base(checker) | {
        'authority.json': OLD / 'baseline/authority.json',
        'baseline-trace.json': OLD / 'baseline/trace.json',
        'test_equality.py': OLD / 'final/test_equality.py',
    } | {n: OLD / 'baseline' / n for n in ['test_a2_trace.py', 'test_a2_routing.py']}
    negative = base(checker) | {
        'authority.json': OLD / 'final/authority.json',
        'positive-authority.json': OLD / 'baseline/authority.json',
    } | {n: OLD / 'final' / n for n in [
        'test_a2_nonqualifier.py', 'test_semantics.py', 'test_derivation.py'
    ]} | {n: FROZEN / 'inputs' / n for n in [
        'fixtures.json', 'schema-control-fixtures.json', 'packet-manifest.json'
    ]}
    job(name + '-positive', positive,
        ['test_a2_trace.py', 'test_a2_routing.py', 'test_equality.py'])
    job(name + '-negative', negative,
        ['test_a2_nonqualifier.py', 'test_semantics.py', 'test_derivation.py'])


def third(name, selection):
    inputs = base(HERE / 'candidate/a2_trace.py') | {
        n: HERE / 'candidate' / n for n in ['authority.json', 'test_cap_after.py']
    } | {n: FROZEN / 'inputs' / n for n in [
        'fixtures.json', 'schema-control-fixtures.json'
    ]} | {'parent-frozen-reference.json': FROZEN / 'parent-frozen-reference.json'}
    for name_extra in ['frozen_case.py', 'test_controls.py', 'verify_cap.py']:
        path = HERE / 'candidate' / name_extra
        if path.exists():
            inputs[name_extra] = path
    job(name, inputs, selection)


if __name__ == '__main__':
    if sys.argv[1] == 'baseline':
        regression('baseline', OLD / 'final/a2_trace.py')
    elif sys.argv[1] == 'regression':
        regression(sys.argv[2], HERE / 'candidate/a2_trace.py')
    elif sys.argv[1] == 'third':
        third(sys.argv[2], sys.argv[3:] or ['test_cap_after.py'])
    else:
        raise ValueError('unrecognized job preparation mode')
