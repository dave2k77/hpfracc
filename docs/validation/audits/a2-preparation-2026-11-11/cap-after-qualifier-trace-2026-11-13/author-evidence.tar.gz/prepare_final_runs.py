"""Prepare fresh captures using current explicit sources, never old live paths."""

import json

from jobs import HERE, job, regression, third


def refresh(old, new):
    plan = json.loads((HERE / 'jobs' / (old + '.json')).read_bytes())
    inputs = {n: s['path'] for n, s in plan['inputs'].items()}
    from pathlib import Path

    inputs = {n: Path(p) for n, p in inputs.items()}
    if plan['selection'] is not None:
        job(new, inputs, plan['selection'])
    else:
        tail = plan['argv'][8:]
        old_before = plan['cwd']
        job(new, inputs, command=[s.replace(old_before, '{before}') for s in tail])


def main():
    third('controls-final', ['test_cap_after.py', 'test_controls.py'])
    regression('regression-final', HERE / 'candidate/a2_trace.py')
    for name in ['physical-replay', 'negative-equality', 'lint-candidate', 'lint-new']:
        refresh(name, name + '-final')
    for item in json.loads((HERE / 'mutants-plan.json').read_bytes()):
        name = 'mutant-' + item['name']
        refresh(name, name + '-final')


if __name__ == '__main__':
    main()
