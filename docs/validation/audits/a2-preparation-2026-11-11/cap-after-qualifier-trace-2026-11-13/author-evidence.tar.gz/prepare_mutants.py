"""Pin source, generate separate actual guard mutants, and prepare narrow jobs."""

import json

from jobs import FROZEN, HERE, base, job, meta, save


def main():
    original = HERE / 'candidate/a2_trace.py'
    source = original.read_text()
    mutants = [
        ('exhaustive-result',
         "need(result['status'] == expected_status and "
         "result['selected_id'] == expected_id,",
         'need(True,',
         'test_unknown_and_known_refusals[selected-known]'),
        ('unknown-assessment',
         "need(assessment['status'] == 'unknown' and "
         "assessment['qualifies'] is None\n"
         "                 and assessment['reasons'] == ['primitive_cap'],",
         'need(True,',
         'test_unknown_and_known_refusals[qualifies]'),
        ('unknown-payload',
         'and all(slot[k] is None for k in [',
         'and all(True for k in [',
         'test_unknown_and_known_refusals[slot-exact]'),
        ('unknown-index',
         "and row['completed_shape'] is None and row['artifact'] is None,",
         'and True,',
         'test_unknown_and_known_refusals[index-completed]'),
        ('supplied-copy', "need(supplied == request['candidates'][i],",
         'need(True,', 'test_unknown_and_known_refusals[supplied-copy]'),
        ('exact-values',
         "need([rational(v) for v in values] == expected, 'exact identity ' + sid)",
         "need(True, 'exact identity ' + sid)",
         'test_false_known_math_after_descriptor_and_outer_resigning'),
        ('binding-route',
         "need(binding['binding_id'] == 'host-' + suffix, 'binding path-to-ID')",
         "need(True, 'binding path-to-ID')", 'test_route_identity'),
        ('lifecycle', '    check_lifecycle(trace)\n', '    pass  # guard mutant\n',
         'test_process_lifecycle[order]'),
        ('byte-ledger', "need(trace['ledger'] == ledger,",
         'need(True,', 'test_real_charge_omission_with_recomputed_summaries'),
        ('authority', '        authenticate(AUTHORITY)\n',
         '        pass  # guard mutant\n',
         'test_frozen_authority_cannot_be_redefined[expected]'),
        ('inventory-defense',
         "need(set(records) == set(AUTHORITY['bundle']['artifacts']), "
         "'fixed record inventory')",
         "need(True, 'fixed record inventory')",
         'test_unknown_and_known_refusals[unknown-host]'),
    ]
    save(HERE / 'mutant-source-pin.json', {'source': meta(original),
                                          'mutants': [m[0] for m in mutants]})
    reports = []
    for name, old, new, selection in mutants:
        assert source.count(old) == 1, name
        directory = HERE / 'mutants' / name
        directory.mkdir(parents=True, exist_ok=False)
        mutated = directory / 'a2_trace.py'
        mutated.write_text(source.replace(old, new, 1))
        inputs = base(mutated) | {n: HERE / 'candidate' / n for n in [
            'authority.json', 'test_cap_after.py', 'test_controls.py', 'frozen_case.py'
        ]} | {n: FROZEN / 'inputs' / n for n in [
            'fixtures.json', 'schema-control-fixtures.json'
        ]} | {'parent-frozen-reference.json': FROZEN / 'parent-frozen-reference.json'}
        job('mutant-' + name, inputs, ['test_controls.py::' + selection])
        reports.append({'name': name, 'original': old, 'replacement': new,
                        'mutant_pin': meta(mutated), 'selection': selection})
    save(HERE / 'mutants-plan.json', reports)
    assert meta(original) == json.loads(
        (HERE / 'mutant-source-pin.json').read_bytes())['source']


if __name__ == '__main__':
    main()
