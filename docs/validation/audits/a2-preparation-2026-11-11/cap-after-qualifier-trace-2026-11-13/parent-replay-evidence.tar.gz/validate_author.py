"""Parent readback, copied-input replay and preservation of author evidence."""
import hashlib
import importlib.util
import io
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
AUTHOR = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-after-author-20261113')
HERE = Path(__file__).parent
PIN = '1d77d07793e5b0e3c816efdef95d3e6293357437505bf1f5df9a3c64da28f0f9'


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


raw = (AUTHOR / 'evidence-index.json').read_bytes()
assert ident(raw)['sha256'] == PIN
index = json.loads(raw)
assert index['file_count'] == len(index['files']) == 1706
for name, expected in index['files'].items():
    assert not name.startswith('/') and all(p not in ('', '.', '..') for p in name.split('/'))
    path = AUTHOR / name
    assert path.is_file() and not path.is_symlink()
    assert ident(path.read_bytes()) == expected
result = json.loads((AUTHOR / 'result.json').read_text())
assert result['passed'] and not result['independent_approval'] and not result['blockers']
assert result['checker']['sha256'] == '819fbbafd5b42e9f1bc0c5be320e56146876ff7047a71073def9b9141fba92fa'
parent = json.loads((WORK / 'parent-frozen-reference.json').read_text())
assert result['exact_math']['slots'] == parent['known_exact_slots']
assert result['exact_math']['unavailable_candidate_arithmetic_performed'] is False
checked_runs = {}
for name, declared in result['runs'].items():
    run = AUTHOR / 'runs' / name
    receipt = json.loads((run / 'result.json').read_text())
    job = json.loads((run / 'job.json').read_text())
    assert receipt['actual_child_exit'] == declared['actual_child_exit']
    assert receipt['source_hashes_unchanged']
    for filename, spec in job['inputs'].items():
        assert ident((run / 'before' / filename).read_bytes()) == spec['pin']
    assert ident((run / 'stdout.bin').read_bytes()) == receipt['stdout']
    assert ident((run / 'stderr.bin').read_bytes()) == receipt['stderr']
    if (run / 'raw.xml').exists():
        body = (run / 'raw.xml').read_bytes()
        assert ident(body) == receipt['junit']['raw']
        cases = ET.fromstring(body).findall('.//testcase')
        assert [c.attrib for c in cases] == receipt['junit']['identities']
        actual = {'collected': len(cases),
                  'failures': sum(c.find('failure') is not None for c in cases),
                  'errors': sum(c.find('error') is not None for c in cases),
                  'skipped': sum(c.find('skipped') is not None for c in cases)}
        assert all(receipt['junit'][key] == value for key, value in actual.items())
        checked_runs[name] = actual | {'actual_child_exit': receipt['actual_child_exit']}
    else:
        checked_runs[name] = {'actual_child_exit': receipt['actual_child_exit']}
final_names = ['regression-final-positive', 'regression-final-negative',
               'negative-equality-final', 'controls-complete', 'physical-replay-final']
for name in final_names:
    assert checked_runs[name]['actual_child_exit'] == 0
    assert result['runs'][name]['checker'] == result['checker']
assert sum(checked_runs[n]['collected'] for n in final_names[:2]) == 59
assert checked_runs['controls-complete']['collected'] == 66
assert checked_runs['negative-equality-final']['collected'] == 1
assert checked_runs['red-01']['actual_child_exit'] == 1
assert checked_runs['red-01']['failures'] == 1 and checked_runs['red-01']['errors'] == 0
pins = json.loads((WORK / 'baseline-inputs.json').read_text())
protected = {n: value for n, value in pins['files'].items() if n not in pins['allowed_status_delta']}
assert len(protected) == 901
assert all(ident((ROOT / n).read_bytes()) == value for n, value in protected.items())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == pins['head']
assert ident(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT))['sha256'] == pins['git_stage_sha256']
# Import the already inspected scanner only after its indexed bytes are verified.
scanner_raw = (AUTHOR / 'privacy_security.py').read_bytes()
(HERE / 'privacy_security.py').write_bytes(scanner_raw)
spec = importlib.util.spec_from_file_location('parent_privacy', HERE / 'privacy_security.py')
scanner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scanner)
file_names = list(index['files']) + ['evidence-index.json']
authored = [Path(n) for n in index['files'] if n.endswith('.py') and (n.startswith('candidate/') or '/' not in n)]
privacy = scanner.scan(AUTHOR, file_names, authored)
save(HERE / 'author-proof-privacy.json', privacy)
assert privacy['passed']
# Replay only the exact inputs of the author's final physical run, in fresh scratch.
source_job = json.loads((AUTHOR / 'runs/physical-replay-final/job.json').read_text())
before = HERE / 'replay/before'
before.mkdir(parents=True, exist_ok=False)
copies = {}
for name, expected in source_job['inputs'].items():
    source = AUTHOR / 'runs/physical-replay-final/before' / name
    assert ident(source.read_bytes()) == expected['pin']
    target = before / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(source.read_bytes())
    copies[name] = ident(target.read_bytes())
command = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync',
           'python', '-B', str(before / 'verify_cap.py'), 'replay']
save(HERE / 'replay/plan.json', {'argv': command, 'cwd': str(before), 'inputs': copies})
process = subprocess.run(command, cwd=before, capture_output=True,
    env=dict(os.environ, UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'),
             PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu'))
(HERE / 'replay/stdout.raw').write_bytes(process.stdout)
(HERE / 'replay/stderr.raw').write_bytes(process.stderr)
save(HERE / 'replay/receipt.json', {'actual_child_exit': process.returncode,
    'stdout': ident(process.stdout), 'stderr': ident(process.stderr)})
assert process.returncode == 0
assert all(ident((before / n).read_bytes()) == value for n, value in copies.items())
replay = json.loads((HERE / 'replay/artifacts/independent-report.json').read_text())
assert replay['exact']['slots'] == parent['known_exact_slots']
assert replay['physical']['ledger'] == result['physical_bytes']
assert len(replay['physical']['final_files']) == 28
assert replay['checker']['required_slot_count'] == 22
assert replay['checker']['complete_slot_count'] == 13 and replay['checker']['unknown_slot_count'] == 9
archive = WORK / 'author-evidence.tar.gz'
with tarfile.open(archive, 'x:gz') as out:
    for name in sorted(file_names):
        body = (AUTHOR / name).read_bytes()
        entry = tarfile.TarInfo(name)
        entry.size = len(body)
        entry.mode = 0o644
        out.addfile(entry, io.BytesIO(body))
with tarfile.open(archive, 'r:gz') as check:
    members = check.getmembers()
    assert len(members) == len(file_names) == 1707
    assert {m.name for m in members} == set(file_names)
    for member in members:
        assert member.isfile()
        expected = ident(raw) if member.name == 'evidence-index.json' else index['files'][member.name]
        assert ident(check.extractfile(member).read()) == expected
with (WORK / 'author-result.json').open('xb') as stream:
    stream.write((AUTHOR / 'result.json').read_bytes())
report = {'status': 'Author self-verification and parent copied-input replay passed; independent review pending',
          'author_index_sha256': PIN, 'indexed_files_verified': 1706,
          'archive': archive.name, **ident(archive.read_bytes()), 'archive_members_verified': 1707,
          'checker': result['checker'], 'raw_runs_verified': len(checked_runs),
          'prior_selected_tests': 59, 'new_case_selected_tests': 66,
          'additional_negative_artifact_equality_test': 1,
          'parent_replay_actual_child_exit': process.returncode,
          'all_13_known_values_match_parent_reference': True, 'unknown_slots_preserved': 9,
          'ledger': result['physical_bytes'], 'protected_files_unchanged': len(protected),
          'bounded_privacy': {'findings': privacy['findings'], 'security_findings': privacy['security_findings'],
                              'indexed_plus_index_files_scanned': privacy['file_count'],
                              'scope': privacy['limitations']},
          'mutation_limit': 'Ten meaningful kills; inventory-guard isolated coverage remains inconclusive because another guard refused the chosen input.',
          'independent_approval': False, 'a2_acceptance_passed': False}
save(WORK / 'author-preservation.json', report)
save(HERE / 'checked-runs.json', checked_runs)
print(json.dumps({k: report[k] for k in ['status', 'indexed_files_verified', 'archive_members_verified',
      'raw_runs_verified', 'prior_selected_tests', 'new_case_selected_tests',
      'parent_replay_actual_child_exit', 'protected_files_unchanged', 'sha256']}, indent=2))
