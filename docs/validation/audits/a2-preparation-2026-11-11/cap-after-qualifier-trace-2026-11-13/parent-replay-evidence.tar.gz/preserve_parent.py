"""Preserve the parent's actual copied-input replay without ambient scratch."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
HERE = Path(__file__).parent


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


plan = json.loads((HERE / 'replay/plan.json').read_text())
report = json.loads((HERE / 'replay/artifacts/independent-report.json').read_text())
receipt = json.loads((HERE / 'replay/receipt.json').read_text())
assert receipt['actual_child_exit'] == 0
names = ['validate_author.py', 'preserve_parent.py', 'privacy_security.py',
         'author-proof-privacy.json', 'checked-runs.json', 'replay/plan.json',
         'replay/receipt.json', 'replay/stdout.raw', 'replay/stderr.raw',
         'replay/artifacts/independent-report.json', 'replay/artifacts/trace.json']
names += ['replay/before/' + n for n in plan['inputs']]
names += ['replay/artifacts/bodies/' + n for n in report['physical']['final_files']]
assert len(names) == len(set(names))
files = {name: (HERE / name).read_bytes() for name in names}
for name, value in report['physical']['final_files'].items():
    assert ident(files['replay/artifacts/bodies/' + name]) == value
archive = WORK / 'parent-replay-evidence.tar.gz'
with tarfile.open(archive, 'x:gz') as out:
    for name, body in sorted(files.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(body)
        entry.mode = 0o644
        out.addfile(entry, io.BytesIO(body))
with tarfile.open(archive, 'r:gz') as check:
    members = check.getmembers()
    assert len(members) == len(files)
    assert all(m.isfile() and check.extractfile(m).read() == files[m.name] for m in members)
result = {'status': 'Fresh copied-input parent replay passed; independent review pending',
          'archive': archive.name, **ident(archive.read_bytes()),
          'members_verified': len(files), 'files': {n: ident(b) for n, b in files.items()},
          'actual_child_exit': receipt['actual_child_exit'],
          'required_slots': report['checker']['required_slot_count'],
          'complete_slots': report['checker']['complete_slot_count'],
          'unknown_slots': report['checker']['unknown_slot_count'],
          'physical_bodies_verified': len(report['physical']['final_files']),
          'ledger': report['physical']['ledger'], 'exact': report['exact'],
          'independent_approval': False}
with (WORK / 'parent-replay.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'members_verified': len(files), 'physical_bodies_verified': result['physical_bodies_verified'],
                  'actual_child_exit': result['actual_child_exit'], 'archive_sha256': result['sha256']}))
