"""Seal an honestly blocked checkpoint: status-only QA, no candidate repair."""
import datetime
import difflib
import hashlib
import io
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

from privacy_security import scan_body

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
HERE = Path(__file__).parent


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


review = json.loads((WORK / 'review-inputs.json').read_text())
baseline = json.loads((WORK / 'baseline-inputs.json').read_text())
protected = baseline['files'] | review['files']
allowed = set(review['allowed_post_review_status_delta'])
assert {n for n, p in protected.items() if ident((ROOT / n).read_bytes()) != p} == allowed
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == baseline['head']
assert ident(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT))['sha256'] == baseline['git_stage_sha256']
with tarfile.open(WORK / 'reviewed-status-before-rejection.tar.gz', 'r:gz') as archive:
    before = {m.name: archive.extractfile(m).read() for m in archive}
assert set(before) == allowed
changes, diff = {}, []
for name in sorted(allowed):
    after = (ROOT / name).read_bytes()
    assert ident(before[name]) == review['files'][name]
    changes[name] = {'before': ident(before[name]), 'after': ident(after), 'scope': 'Rejected-review disposition only'}
    diff += list(difflib.unified_diff(before[name].decode().splitlines(True), after.decode().splitlines(True),
                                     fromfile='reviewed/' + name, tofile='blocked/' + name))
(HERE / 'blocked-status.patch').write_text(''.join(diff))
for filename in ['independent-review-preservation.json', 'parent-rejection-readback.json',
                 'reviewed-status-before-rejection.json']:
    preserved = json.loads((WORK / filename).read_text())
    assert ident((WORK / preserved['archive']).read_bytes())['sha256'] == preserved['sha256']
verdict = json.loads((WORK / 'independent-review-verdict.json').read_text())
reproduction = json.loads((WORK / 'parent-rejection-readback.json').read_text())
assert verdict['review_completed'] and verdict['passed'] is False
assert verdict['finding']['finding_id'] == 'CAP-AUTH-TYPE-01'
assert reproduction['actual_probe_exit'] == 2 and reproduction['accepted_type_mutations'] == 3
assert not reproduction['source_repaired']
qa = HERE / 'blocked-qa'
qa.mkdir(exist_ok=False)
base = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync']
commands = [base + ['ruff', 'check', '--no-cache', '.'],
            base + ['python', '-B', '-m', 'pytest', 'tests/unit/test_docs_consistency.py',
                    '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(HERE / 'qa-runtime'),
                    '--junitxml=' + str(qa / 'docs.xml')],
            base + ['mkdocs', 'build', '--strict', '--site-dir', str(HERE / 'site')],
            ['git', 'diff', '--check']]
save(qa / 'plan.json', commands)
receipts = []
for i, command in enumerate(commands):
    process = subprocess.run(command, cwd=ROOT, capture_output=True,
        env=dict(os.environ, UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'),
                 PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu'))
    (qa / f'{i}-stdout.raw').write_bytes(process.stdout)
    (qa / f'{i}-stderr.raw').write_bytes(process.stderr)
    receipts.append({'command': command, 'actual_exit': process.returncode})
save(qa / 'receipts.json', receipts)
assert all(r['actual_exit'] == 0 for r in receipts)
tree = ET.parse(qa / 'docs.xml')
assert len(tree.findall('.//testcase')) == 23
assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
names = ['blocked_checkpoint.py', 'blocked-status.patch', 'blocked-qa/plan.json',
         'blocked-qa/receipts.json', 'blocked-qa/docs.xml']
names += [f'blocked-qa/{i}-{s}.raw' for i in range(4) for s in ['stdout', 'stderr']]
files = {n: (HERE / n).read_bytes() for n in names}
archive_path = WORK / 'blocked-qa-evidence.tar.gz'
with tarfile.open(archive_path, 'x:gz') as archive:
    for name, body in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(body), 0o644
        archive.addfile(member, io.BytesIO(body))
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(files)
    assert all(m.isfile() and archive.extractfile(m).read() == files[m.name] for m in members)
save(WORK / 'blocked-qa.json', {'archive': archive_path.name, **ident(archive_path.read_bytes()),
    'members_verified': len(files), 'files': {n: ident(b) for n, b in files.items()},
    'actual_exits': [r['actual_exit'] for r in receipts], 'docs_tests_passed': 23,
    'scope': 'Blocked-disposition repository QA only; the rejected candidate is not approved'})
save(WORK / 'blocked-status-delta.json', {'changes': changes,
    'unchanged_protected_files': len(protected) - len(allowed),
    'unchanged_baseline_files': len(baseline['files']) - len(baseline['allowed_status_delta']),
    'head_and_stage_unchanged': True, 'source_repaired': False})
outcome = {'status': 'BLOCKED_ON_INDEPENDENT_REVIEW',
    'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'case_id': 'CAP-after-qualifier-f64-GL', 'increment_complete': False,
    'review_completed': True, 'review_passed': False, 'finding_id': 'CAP-AUTH-TYPE-01',
    'tracker_id': 'VAL-017', 'review_record': 'independent-review-verdict.json',
    'review_proof_indexed_files_verified': 532, 'review_archive_members_verified': 533,
    'parent_counterexamples_reproduced': 3, 'parent_probe_actual_exit': 2,
    'unchanged_trace_math_and_ledger_reproduced': True,
    'positive_test_selections': {'previous': 59, 'new_case': 66, 'additional_artifact_equality': 1},
    'passing_selections_override_blocking_finding': False,
    'inventory_guard_coverage_isolated': True, 'candidate_repaired': False,
    'automatic_source_repair_authorized': False, 'numerical_source_changed': False,
    'caps_changed': False, 'criteria_changed': False, 'protocol_frozen': False,
    'a2_acceptance_passed': False, 'phase_closed': False, 'commit_or_push_performed': False,
    'checkpoint_qa_actual_exits': [r['actual_exit'] for r in receipts],
    'checkpoint_docs_tests_passed': 23,
    'proposed_next_step': 'Seek owner approval for one narrow type-preserving authority-identity repair, add preserved counterexample regressions, preserve valid artifact bytes and obtain fresh independent review.',
    'parent_harness_limit': 'Initial per-body privacy scan of a whole expanded nested archive failed; failure retained and bounded streaming scan completed. No candidate repair occurred.'}
save(WORK / 'blocked-outcome.json', outcome)
# Scan new metadata/status and small QA bodies. Large proof containers have already
# been streamed, scanned and verified; reauthenticate their exact preservation pins.
paths = [ROOT / n for n in allowed]
paths += [p for p in WORK.iterdir() if p.is_file() and p.suffix == '.json'
          and str(p.relative_to(ROOT)) not in review['files']]
findings = []
for path in sorted(set(paths)):
    findings.extend(scan_body(path.read_bytes(), str(path.relative_to(ROOT))))
for name, body in files.items():
    findings.extend(scan_body(body, 'blocked-qa-evidence.tar.gz::' + name))
assert scan_body(json.dumps({'chat_id': 'SYNTHETIC_ONLY'}).encode(), 'positive-control')
save(WORK / 'blocked-metadata-privacy.json', {'scope': 'New metadata/status and every small QA archive body; prior large proof identity and streamed-scan preservation rechecked separately',
    'files': {str(p.relative_to(ROOT)): ident(p.read_bytes()) for p in sorted(set(paths))},
    'qa_members_scanned': len(files), 'findings': findings, 'positive_control_passed': True,
    'limitations': 'Bounded patterns/fields, not private-identity matching or universal privacy clearance'})
assert not findings
assert all(ident((ROOT / n).read_bytes()) == p for n, p in protected.items() if n not in allowed)
all_paths = sorted([p for p in WORK.rglob('*') if p.is_file()] + [ROOT / n for n in baseline['allowed_status_delta']])
manifest = {'status': 'Preserved blocked checkpoint, not completion',
    'files': {str(p.relative_to(ROOT)): ident(p.read_bytes()) for p in all_paths},
    'file_count': len(all_paths), 'self_excluded': 'blocked-manifest.json',
    'readback_excluded': 'blocked-readback.json'}
save(WORK / 'blocked-manifest.json', manifest)
manifest_raw = (WORK / 'blocked-manifest.json').read_bytes()
assert all(ident((ROOT / n).read_bytes()) == p for n, p in manifest['files'].items())
assert not scan_body(manifest_raw, 'blocked-manifest.json')
readback = {'status': 'Blocked checkpoint preserved and verified; candidate remains rejected',
    'manifest': ident(manifest_raw), 'manifest_files_verified': len(manifest['files']),
    'protected_baseline_files_unchanged': 901, 'permitted_status_changes': len(allowed),
    'finding_id': 'CAP-AUTH-TYPE-01', 'counterexamples_confirmed': 3,
    'actual_counterexample_probe_exit': 2, 'candidate_repaired': False,
    'checkpoint_qa_actual_exits': [r['actual_exit'] for r in receipts],
    'increment_complete': False, 'readback_not_self_hashed': True,
    'receipt_role': 'Normalized verification record; actual command success is the terminal tool exit, not OS attestation'}
readback_raw = json.dumps(readback, indent=2).encode() + b'\n'
assert not scan_body(readback_raw, 'blocked-readback.json')
with (WORK / 'blocked-readback.json').open('xb') as stream:
    stream.write(readback_raw)
print(json.dumps({'status': readback['status'], 'manifest_files_verified': len(manifest['files']),
    'blocked_manifest_sha256': ident(manifest_raw)['sha256'], 'protected_baseline_files_unchanged': 901,
    'permitted_status_changes': len(allowed), 'qa_exits': [r['actual_exit'] for r in receipts],
    'counterexamples_confirmed': 3, 'candidate_repaired': False}, indent=2))
