"""Record actual imported files, then run an unchanged selected entrypoint."""

import hashlib
import json
import runpy
import sys
from pathlib import Path

import a2_trace
import frozen_case

HERE = Path(__file__).resolve().parent
OUT = HERE.parent / 'artifacts'
OUT.mkdir(exist_ok=True)
imports = {}
for module in [a2_trace, frozen_case]:
    source = Path(module.__file__).resolve()
    assert source.parent == HERE
    raw = source.read_bytes()
    imports[module.__name__] = {
        'path': str(source), 'bytes': len(raw),
        'sha256': hashlib.sha256(raw).hexdigest(),
    }
(OUT / 'imports.json').write_text(json.dumps(imports, indent=2) + '\n')
if sys.argv[1] == 'pytest':
    import pytest

    raise SystemExit(pytest.main(sys.argv[2:]))
entrypoint = sys.argv[1]
sys.argv = sys.argv[1:]
runpy.run_path(str(HERE / entrypoint), run_name='__main__')
