"""Independent posthoc JSON-type/identity controls; not author TDD evidence."""
import copy
import json

import a2_trace as audit
import frozen_case
import pytest

SEAMS = ['authenticate', 'make_trace', 'verify_trace']
ALIASES = [
    ('case-negative-zero', ['case', 'required_evidence_slots', 5, 'candidate_index'], -0.0),
    ('case-last-bool', ['case', 'required_evidence_slots', 21, 'candidate_index'], True),
    ('case-later-float', ['case', 'required_evidence_slots', 18, 'candidate_index'], 1.0),
    ('bundle-poles-bool', ['bundle', 'artifacts', 'records/candidate-1.json', 'configuration', 'pole_count'], True),
    ('bundle-exact-head-int', ['bundle', 'artifacts', 'records/candidate-0.json', 'configuration', 'exact_head'], 1),
    ('bundle-certification-int', ['bundle', 'artifacts', 'result.json', 'arithmetic_verified'], 0),
    ('bundle-shape-float', ['bundle', 'artifacts', 'arrays/S-X-w.json', 'exact_array', 'shape', 0], 3.0),
    ('bundle-iterations-bool', ['bundle', 'artifacts', 'records/candidate-0.json', 'producer', 'iterations'], False),
    ('bundle-cap-float', ['bundle', 'artifacts', 'input-bundle.json', 'request', 'caps', 'wall_seconds'], 60.0),
    ('scalar-f32-alpha', ['working_scalars', 'float32', 'alpha', 'nbytes'], 4.0),
    ('scalar-f32-dt', ['working_scalars', 'float32', 'dt', 'nbytes'], 4.0),
    ('scalar-f64-tmax', ['working_scalars', 'float64', 't_max', 'nbytes'], 8.0),
]
OTHER = [
    ('rational-number-not-string', ['case', 'request', 'alpha', 'num'], 1),
    ('null-not-false', ['case', 'resource_control', 'value'], False),
    ('scalar-same-type-value', ['working_scalars', 'float64', 'alpha', 'nbytes'], 9),
    ('bundle-null-not-false', ['bundle', 'artifacts', 'result.json', 'selected_id'], False),
]


def enc(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('utf-8')


def at(value, path):
    for key in path:
        value = value[key]
    return value


@pytest.fixture(scope='module')
def baseline():
    original = copy.deepcopy(audit.AUTHORITY)
    trace = audit.make_trace()
    audit.verify_trace(trace)
    return original, trace


def call(seam, changed, trace):
    if seam == 'authenticate':
        return frozen_case.authenticate(changed)
    if seam == 'make_trace':
        return audit.make_trace()
    return audit.verify_trace(copy.deepcopy(trace))


def rejection(seam, changed, baseline, monkeypatch, field):
    original, trace = baseline
    assert enc(changed) != enc(original)
    monkeypatch.setattr(audit, 'AUTHORITY', changed)
    with pytest.raises(ValueError) as exc:
        call(seam, changed, trace)
    message = ('static metadata' if field == 'working_scalars'
               else 'mechanical case/witness slice')
    assert type(exc.value) is ValueError
    assert str(exc.value) == 'frozen authority ' + message


@pytest.mark.parametrize('seam', SEAMS)
@pytest.mark.parametrize('name,path,value', ALIASES, ids=[v[0] for v in ALIASES])
def test_independent_alias(name, path, value, seam, baseline, monkeypatch):
    changed = copy.deepcopy(baseline[0])
    old = at(changed, path)
    assert old == value and type(old) is not type(value)
    at(changed, path[:-1])[path[-1]] = value
    assert changed == baseline[0]
    rejection(seam, changed, baseline, monkeypatch, path[0])


@pytest.mark.parametrize('seam', SEAMS)
@pytest.mark.parametrize('name,path,value', OTHER, ids=[v[0] for v in OTHER])
def test_nonalias_identity(name, path, value, seam, baseline, monkeypatch):
    changed = copy.deepcopy(baseline[0])
    at(changed, path[:-1])[path[-1]] = value
    rejection(seam, changed, baseline, monkeypatch, path[0])


@pytest.mark.parametrize('seam', SEAMS)
@pytest.mark.parametrize('field,path', [
    ('case', ['case', 'request', 'alpha']),
    ('bundle', ['bundle', 'artifacts', 'records/candidate-1.json', 'configuration']),
    ('working_scalars', ['working_scalars', 'float32', 'dt']),
])
def test_nested_extra_field(field, path, seam, baseline, monkeypatch):
    changed = copy.deepcopy(baseline[0])
    at(changed, path)['independent_extra'] = None
    rejection(seam, changed, baseline, monkeypatch, field)


def reorder(value, path=(), keep_schedule=False):
    if isinstance(value, dict):
        pairs = list(value.items())
        if not (keep_schedule and path == ('bundle', 'artifacts')):
            pairs.reverse()
        return {k: reorder(v, path + (k,), keep_schedule) for k, v in pairs}
    if isinstance(value, list):
        return [reorder(v, path + (i,), keep_schedule) for i, v in enumerate(value)]
    return value


def test_meaningful_order_preserving_schedule(baseline, monkeypatch):
    original, trace = baseline
    changed = reorder(original, keep_schedule=True)
    assert list(changed['working_scalars']) != list(original['working_scalars'])
    assert list(changed['case']['request']) != list(original['case']['request'])
    assert list(changed['bundle']['artifacts']) == list(original['bundle']['artifacts'])
    assert enc(changed) == enc(original)
    frozen_case.authenticate(changed)
    monkeypatch.setattr(audit, 'AUTHORITY', changed)
    rebuilt = audit.make_trace()
    assert enc(rebuilt) == enc(trace)
    audit.verify_trace(trace)
    audit.verify_trace(rebuilt)


def test_full_object_reorder_auth_and_existing_trace(baseline, monkeypatch):
    original, trace = baseline
    changed = reorder(original)
    assert list(changed['bundle']['artifacts']) != list(original['bundle']['artifacts'])
    assert enc(changed) == enc(original)
    frozen_case.authenticate(changed)
    monkeypatch.setattr(audit, 'AUTHORITY', changed)
    audit.verify_trace(copy.deepcopy(trace))
    # Artifact-map iteration encodes the unchanged static builder schedule;
    # this control does not assert arbitrary schedules are admitted.


@pytest.mark.parametrize('value', [True, 1, 1.0, False, 0, 0.0, -0.0, None,
                                   {'\u03bb': '\u00e9\n', 'z': [1, True, 1.0]}])
def test_encoding_agrees_with_contract(value):
    assert enc(value) == frozen_case.canonical(value) == audit.canonical(value)


def test_all_numeric_alias_encodings_distinct():
    values = [True, 1, 1.0, False, 0, 0.0, -0.0, None]
    assert len({frozen_case.canonical(v) for v in values}) == len(values)
