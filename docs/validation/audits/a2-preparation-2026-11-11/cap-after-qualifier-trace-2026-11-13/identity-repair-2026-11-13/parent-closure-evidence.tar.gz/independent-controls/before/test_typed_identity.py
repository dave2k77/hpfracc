"""Type-only rejection at each public seam; static local authority, not workers."""

import copy
import json
from pathlib import Path

import a2_trace as audit
import frozen_case
import pytest

HERE = Path(__file__).resolve().parent
PRESERVED = [
    ('case-unknown-occurrence-bool',
     ['case', 'required_evidence_slots', 13, 'candidate_index']),
    ('case-known-occurrence-bool',
     ['case', 'required_evidence_slots', 4, 'candidate_index']),
    ('scalar-alpha-nbytes-float', ['working_scalars', 'float64', 'alpha', 'nbytes']),
]
SIBLINGS = [
    ('case-index-float', ['case', 'required_evidence_slots', 13, 'candidate_index'],
     1.0),
    ('bundle-index-bool',
     ['bundle', 'initial_failure_index', 'slots', 4, 'candidate_index'], False),
    ('bundle-shape-float',
     ['bundle', 'initial_failure_index', 'slots', 0, 'expected_shape', 0], 3.0),
    ('bundle-exit-bool',
     ['bundle', 'artifacts', 'records/process.json', 'exit_code'], False),
    ('scalar-dt-float', ['working_scalars', 'float64', 'dt', 'nbytes'], 8.0),
    ('scalar-f32-tmax-float', ['working_scalars', 'float32', 't_max', 'nbytes'],
     4.0),
]
SEAMS = ['authenticate', 'make_trace', 'verify_trace']


def enc(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('utf-8')


def at(value, path):
    for key in path:
        value = value[key]
    return value


@pytest.fixture(scope='module')
def valid():
    original = copy.deepcopy(audit.AUTHORITY)
    trace = audit.make_trace()
    audit.verify_trace(trace)
    assert enc(trace) == (HERE / 'golden-cap.json').read_bytes()
    return original, trace


def reject(changed, path, seam, valid, monkeypatch):
    original, trace = valid
    assert type(at(changed, path)) is not type(at(original, path))
    assert at(changed, path) == at(original, path)
    assert changed == original
    assert enc(changed) != enc(original)
    for sibling in {'case', 'bundle', 'working_scalars'} - {path[0]}:
        assert enc(changed[sibling]) == enc(original[sibling])
    monkeypatch.setattr(audit, 'AUTHORITY', changed)
    message = ('frozen authority static metadata' if path[0] == 'working_scalars'
               else 'frozen authority mechanical case/witness slice')
    with pytest.raises(ValueError) as error:
        if seam == 'authenticate':
            frozen_case.authenticate(changed)
        elif seam == 'make_trace':
            audit.make_trace()
        else:
            # The valid trace was built BEFORE changing authority; independently
            # call verification, without first authenticating the changed input.
            audit.verify_trace(copy.deepcopy(trace))
    assert type(error.value) is ValueError
    assert str(error.value) == message


@pytest.mark.parametrize('seam', SEAMS)
@pytest.mark.parametrize('name,path', PRESERVED, ids=[x[0] for x in PRESERVED])
def test_preserved_alias_is_rejected(name, path, seam, valid, monkeypatch):
    changed = json.loads((HERE / 'counterexamples' / (name + '.json')).read_bytes())
    reject(changed, path, seam, valid, monkeypatch)


@pytest.mark.parametrize('seam', SEAMS)
@pytest.mark.parametrize('name,path,replacement', SIBLINGS,
                         ids=[x[0] for x in SIBLINGS])
def test_sibling_alias_is_rejected(name, path, replacement, seam, valid, monkeypatch):
    changed = copy.deepcopy(valid[0])
    at(changed, path[:-1])[path[-1]] = replacement
    reject(changed, path, seam, valid, monkeypatch)
