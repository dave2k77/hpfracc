"""Read-only input utilities for the bounded independent identity review."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
CASE = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
WORK = CASE / 'identity-repair-2026-11-13'
AUTHOR = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-identity-correction-20261113')
INPUT = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-identity-preflight-20261113')
BASE = Path(__file__).resolve().parent
REVIEW_SHA = '0b9ed4a3269ea00f1c9c5f674f60c0c9494cfacfebd36a873a502aaaf1037293'
OLD = '93354458e3633a1bd198049b265a6eb9d3582df9ec5d31d5d87006e24119462b'
NEW = 'f18113b7d05469e7cd657f8ef522114dcc6f6a175c3c60a32f55c21c44370c43'
CHECKER = '819fbbafd5b42e9f1bc0c5be320e56146876ff7047a71073def9b9141fba92fa'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def pin(path):
    assert not path.is_symlink(), str(path)
    h = hashlib.sha256()
    n = 0
    with path.open('rb') as stream:
        while data := stream.read(1024 * 1024):
            h.update(data)
            n += len(data)
    return {'bytes': n, 'sha256': h.hexdigest()}


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n')


def safe(name):
    p = Path(name)
    assert name and not p.is_absolute() and '..' not in p.parts
    assert str(p) == name and '\\' not in name
    return name


def protection(label):
    baseline = read(WORK / 'baseline-inputs.json')
    review = read(WORK / 'review-inputs.json')
    assert pin(WORK / 'review-inputs.json')['sha256'] == REVIEW_SHA
    assert len(baseline['files']) == 933
    ignored = set(baseline['allowed_status_delta'])
    immutable = {n: p for n, p in baseline['files'].items() if n not in ignored}
    assert len(immutable) == 930
    checked = {}
    for name, expected in immutable.items():
        actual = pin(ROOT / safe(name))
        assert actual == expected, ('protected bytes changed', name)
        checked[name] = actual
    assert len(review['files']) == review['file_count'] == 19
    current_review = {n: pin(ROOT / safe(n)) for n in review['files']}
    assert current_review == review['files']
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
    stages = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT)
    assert head == baseline['head']
    assert digest(stages) == baseline['git_stage_sha256']
    (BASE / ('git-stage-' + label + '.bin')).write_bytes(stages)
    result = {'head': head, 'git_stage_sha256': digest(stages),
              'git_stage_encoding': 'git ls-files --stage -z raw bytes',
              'review_manifest': pin(WORK / 'review-inputs.json'),
              'protected_count': len(checked), 'review_count': len(current_review),
              'protected_files': checked, 'review_files': current_review,
              'allowed_baseline_status_delta': sorted(ignored)}
    save(BASE / ('protection-' + label + '.json'), result)
    return {'immutable': len(checked), 'review_files': len(current_review), 'head': head}
