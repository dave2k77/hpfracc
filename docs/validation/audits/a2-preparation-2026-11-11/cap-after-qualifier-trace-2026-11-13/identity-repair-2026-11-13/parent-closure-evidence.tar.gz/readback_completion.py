"""Read back the exact final scoped completion and every sealed artifact pin."""
import hashlib
import json
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

from privacy import controls, leaf, scan

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
CASE = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
WORK = CASE / 'identity-repair-2026-11-13'
HERE = Path(__file__).parent


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


raw = (WORK / 'final-manifest.json').read_bytes()
assert ident(raw)['sha256'] == sys.argv[1]
manifest = json.loads(raw)
assert len(manifest['files']) == manifest['file_count']
for name, expected in manifest['files'].items():
    path = ROOT / name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert path.is_file() and not path.is_symlink() and ident(path.read_bytes()) == expected
baseline = json.loads((WORK / 'baseline-inputs.json').read_text())
review = json.loads((WORK / 'review-inputs.json').read_text())
actual = {str(p.relative_to(ROOT)) for p in WORK.rglob('*') if p.is_file()}
actual |= set(baseline['allowed_status_delta'])
assert actual == set(manifest['files']) | {str((WORK / 'final-manifest.json').relative_to(ROOT))}
protected = baseline['files'] | review['files']
allowed = set(review['allowed_post_review_status_delta'])
assert {n for n, p in protected.items() if ident((ROOT / n).read_bytes()) != p} == allowed
assert len(allowed) == 4
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == baseline['head']
assert ident(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT))['sha256'] == baseline['git_stage_sha256']
verdict = json.loads((WORK / 'independent-review-verdict.json').read_text())
outcome = json.loads((WORK / 'outcome.json').read_text())
assert outcome['repair_complete'] and outcome['increment_complete']
assert verdict['review_completed'] and verdict['passed'] and not verdict['logic_errors'] and not verdict['security_concerns']
assert outcome['passing_check_total'] == verdict['verified_counts']['fresh_passing_tests'] == 230
assert outcome['verified_counts'] == verdict['verified_counts']
assert outcome['artifact_identities'] == verdict['artifacts']
assert outcome['corrected_helper_sha256'] == verdict['reviewed_identities']['corrected_helper_sha256']
assert outcome['unchanged_checker_sha256'] == verdict['reviewed_identities']['unchanged_checker_sha256']
assert all(not outcome[k] for k in ['numerical_source_changed', 'caps_changed', 'criteria_changed',
    'new_numerical_worker_fitter_or_ad_observations', 'eight_fit_real_blockers_resolved',
    'whole_packet_resource_sufficiency_proved', 'scientific_certification', 'protocol_freeze_authorized',
    'a2_acceptance_passed', 'phase_complete', 'commit_push_or_release_performed'])
assert json.loads((CASE / 'independent-review-verdict.json').read_text())['passed'] is False
assert json.loads((CASE / 'blocked-outcome.json').read_text())['increment_complete'] is False
# Exact archive/member readback after the final status updates.
for filename in ['independent-review-preservation.json', 'parent-closure-preservation.json']:
    preservation = json.loads((WORK / filename).read_text())
    path = WORK / preservation['archive']
    assert ident(path.read_bytes())['sha256'] == preservation['sha256']
    with tarfile.open(path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == preservation['members_verified']
        assert len({m.name for m in members}) == len(members) and all(m.isfile() for m in members)
        if filename.startswith('independent'):
            idx_raw = archive.extractfile('evidence-index.json').read()
            assert ident(idx_raw)['sha256'] == preservation['review_index_sha256']
            index = json.loads(idx_raw)
            entries = {r['path']: {k: r[k] for k in ['bytes', 'sha256']} for r in index['files']}
            assert len(entries) == len(index['files']) == index['file_count'] == 720
            assert set(entries) | {'evidence-index.json'} == {m.name for m in members}
            assert all(ident(archive.extractfile(n).read()) == p for n, p in entries.items())
            assert archive.extractfile('verdict.json').read() == (WORK / 'independent-review-verdict.json').read_bytes()
        else:
            assert set(preservation['files']) == {m.name for m in members}
            assert all(ident(archive.extractfile(n).read()) == p for n, p in preservation['files'].items())
            for name, expected in [('final-qa/docs.xml', 23), ('independent-controls/raw.xml', 69)]:
                tree = ET.fromstring(archive.extractfile(name).read())
                assert len(tree.findall('.//testcase')) == expected
                assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
            qa = json.loads(archive.extractfile('final-qa/receipts.json').read())
            assert all(r['actual_exit'] == 0 for r in qa)
            assert json.loads(archive.extractfile('independent-controls/receipt.json').read())['actual_child_exit'] == 0
privacy = scan([WORK / 'outcome.json', WORK / 'final-privacy.json', WORK / 'final-manifest.json'],
               'Late final metadata only; prior complete closure scan and artifact pins verified')
privacy['positive_controls'] = controls()
assert not privacy['findings']
assert all(ident((ROOT / n).read_bytes()) == p for n, p in manifest['files'].items())
assert ident((WORK / 'final-manifest.json').read_bytes())['sha256'] == sys.argv[1]
record = {'status': 'Final local scoped correction and cap-after-qualifier increment verified complete',
    'final_manifest': ident(raw), 'manifest_files_verified': len(manifest['files']),
    'protected_baseline_files_unchanged': 930, 'allowed_status_documents_changed': 4,
    'independent_review_files_verified': 720, 'independent_review_archive_members_verified': 721,
    'independent_passing_checks_verified': 230, 'additional_controls_parent_replayed': 69,
    'parent_control_actual_exit': 0, 'final_docs_tests_passed': 23, 'final_qa_actual_exits': [r['actual_exit'] for r in qa],
    'late_metadata_privacy': privacy, 'historical_failed_verdict_and_blocked_outcome_unchanged': True,
    'head_and_stage_unchanged': True, 'commit_or_push_performed': False,
    'scope': 'Only reviewed static JSON identity and cap-after-qualifier proof; not wider A2/scientific/resource/delivery approval',
    'self_excluded_from_final_manifest': True,
    'receipt_role': 'Normalized local readback; actual execution is reported by terminal exit, not asserted as OS attestation'}
body = json.dumps(record, indent=2, ensure_ascii=True, allow_nan=False).encode() + b'\n'
assert not leaf(body, 'completion-readback.json')
with (WORK / 'completion-readback.json').open('xb') as stream:
    stream.write(body)
print(json.dumps({k: record[k] for k in ['status', 'manifest_files_verified',
    'protected_baseline_files_unchanged', 'allowed_status_documents_changed',
    'independent_passing_checks_verified', 'additional_controls_parent_replayed',
    'parent_control_actual_exit', 'final_docs_tests_passed', 'final_qa_actual_exits']}, indent=2))
