"""Parent verification and preservation of the passing independent re-review."""
import hashlib
import io
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13/identity-repair-2026-11-13'
REVIEW = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-identity-independent-20261113')
HERE = Path(__file__).parent
PIN = 'c8c11d490cb9721b0901443650a97a714976dabcfec29624764c4d3d9f99c938'
HELPER = 'f18113b7d05469e7cd657f8ef522114dcc6f6a175c3c60a32f55c21c44370c43'


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def pack(path, root, entries):
    with tarfile.open(path, 'x:gz') as archive:
        for name, expected in sorted(entries.items()):
            body = (root / name).read_bytes()
            assert ident(body) == expected
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(body), 0o644
            archive.addfile(member, io.BytesIO(body))
    with tarfile.open(path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(entries) and {m.name for m in members} == set(entries)
        assert all(m.isfile() and ident(archive.extractfile(m).read()) == entries[m.name] for m in members)
    return {'archive': path.name, **ident(path.read_bytes()), 'members_verified': len(entries)}


raw = (REVIEW / 'evidence-index.json').read_bytes()
assert ident(raw)['sha256'] == PIN
index = json.loads(raw)
entries = {r['path']: {k: r[k] for k in ['bytes', 'sha256']} for r in index['files']}
assert len(entries) == len(index['files']) == index['file_count'] == 720
for name, expected in entries.items():
    assert not name.startswith('/') and all(p not in ('', '.', '..') for p in name.split('/'))
    path = REVIEW / name
    assert path.is_file() and not path.is_symlink() and ident(path.read_bytes()) == expected
verdict = json.loads((REVIEW / 'verdict.json').read_text())
assert verdict['review_completed'] and verdict['passed']
assert not verdict['security_concerns'] and not verdict['logic_errors']
assert verdict['reviewed_identities']['corrected_helper_sha256'] == HELPER
manifest_raw = (WORK / 'review-inputs.json').read_bytes()
assert ident(manifest_raw) == {k: verdict['reviewed_identities']['review_inputs'][k] for k in ['bytes', 'sha256']}
review = json.loads(manifest_raw)
assert all(ident((ROOT / n).read_bytes()) == p for n, p in review['files'].items())
baseline = json.loads((WORK / 'baseline-inputs.json').read_text())
protected = {n: p for n, p in baseline['files'].items() if n not in baseline['allowed_status_delta']}
assert len(protected) == 930 and all(ident((ROOT / n).read_bytes()) == p for n, p in protected.items())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == baseline['head']
assert ident(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT))['sha256'] == baseline['git_stage_sha256']
results = {}
for name, expected in verdict['fresh_execution_results'].items():
    run = REVIEW / 'replays' / name
    plan = json.loads((run / 'plan.json').read_text())
    receipt = json.loads((run / 'receipt.json').read_text())
    assert receipt['actual_child_exit'] == expected['exit'] and receipt['inputs_unchanged']
    for filename, value in plan['inputs'].items():
        expected_pin = {k: value[k] for k in ['bytes', 'sha256']}
        assert ident((run / 'before' / filename).read_bytes()) == expected_pin == receipt['inputs_after'][filename]
    for stream in ['stdout', 'stderr']:
        assert ident((run / (stream + '.bin')).read_bytes()) == receipt[stream]
    if expected['count'] is not None:
        xml = (run / 'raw.xml').read_bytes()
        assert ident(xml) == receipt['junit']['raw']
        cases = ET.fromstring(xml).findall('.//testcase')
        assert len(cases) == expected['count'] == receipt['junit']['count']
        assert [[c.attrib['classname'], c.attrib['name']] for c in cases] == receipt['junit']['identities']
        assert not any(c.find('error') is not None or c.find('skipped') is not None for c in cases)
        if expected['exit'] == 0:
            assert not any(c.find('failure') is not None for c in cases)
        else:
            assert all(c.find('failure') is not None for c in cases)
    if expected['exit'] == 0:
        imports = receipt['imports']
        assert imports['frozen_case']['sha256'] == HELPER
        assert imports['a2_trace']['sha256'] == verdict['reviewed_identities']['unchanged_checker_sha256']
    results[name] = expected
passing = sum(r['count'] for r in results.values() if r['exit'] == 0 and r['count'] is not None)
assert passing == verdict['verified_counts']['fresh_passing_tests'] == 230
prior = json.loads((WORK / 'parent-replay.json').read_text())['replays']
for role, value in verdict['artifacts'].items():
    assert value['trace'] == prior[role]['canonical_trace']
    assert value['ledger'] == prior[role]['ledger'] and value['body_count'] == prior[role]['body_count']
# Replay the independent additional selection from exactly the reviewed input bytes.
source_run = REVIEW / 'replays/independent-controls'
plan = json.loads((source_run / 'plan.json').read_text())
before = HERE / 'independent-controls/before'
before.mkdir(parents=True, exist_ok=False)
copies = {}
for name, value in plan['inputs'].items():
    body = (source_run / 'before' / name).read_bytes()
    expected = {k: value[k] for k in ['bytes', 'sha256']}
    assert ident(body) == expected
    target = before / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(body)
    copies[name] = expected
command = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync', 'python', '-B',
           'run_selected.py', 'pytest', '-q', '-p', 'no:cacheprovider',
           '--basetemp=' + str(HERE / 'runtime/pytest'),
           '--junitxml=' + str(HERE / 'independent-controls/raw.xml'), 'test_independent_identity.py']
save(HERE / 'independent-controls/plan.json', {'argv': command, 'cwd': str(before), 'inputs': copies})
process = subprocess.run(command, cwd=before, capture_output=True,
    env=dict(os.environ, UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'), PYTHONDONTWRITEBYTECODE='1',
             JAX_PLATFORMS='cpu', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'))
(HERE / 'independent-controls/stdout.raw').write_bytes(process.stdout)
(HERE / 'independent-controls/stderr.raw').write_bytes(process.stderr)
save(HERE / 'independent-controls/receipt.json', {'actual_child_exit': process.returncode,
    'stdout': ident(process.stdout), 'stderr': ident(process.stderr)})
assert process.returncode == 0
assert all(ident((before / n).read_bytes()) == p for n, p in copies.items())
tree = ET.parse(HERE / 'independent-controls/raw.xml')
assert len(tree.findall('.//testcase')) == 69
assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
imports = json.loads((HERE / 'independent-controls/artifacts/imports.json').read_text())
assert imports['frozen_case']['sha256'] == HELPER
# Copy the inspected streaming scanner, without running its main/protection routines.
for name in ['privacy.py', 'review_common.py']:
    body = (REVIEW / name).read_bytes()
    assert ident(body) == entries[name]
    (HERE / name).write_bytes(body)
from privacy import controls, scan
all_entries = entries | {'evidence-index.json': ident(raw)}
privacy = scan([REVIEW / n for n in sorted(all_entries)], 'Parent readback of explicit passing-review proof')
privacy['positive_controls'] = controls()
save(HERE / 'review-proof-privacy.json', privacy)
assert not privacy['findings']
archive = pack(WORK / 'independent-review-evidence.tar.gz', REVIEW, all_entries)
with (WORK / 'independent-review-verdict.json').open('xb') as stream:
    stream.write((REVIEW / 'verdict.json').read_bytes())
archive.update({'review_index_sha256': PIN, 'indexed_files_verified': 720,
    'review_completed': True, 'passed': True, 'passing_tests_verified': passing,
    'parent_independent_controls_replayed': 69, 'parent_replay_actual_exit': process.returncode,
    'protected_files_unchanged': 930, 'reviewed_files_unchanged': 19,
    'bounded_privacy_findings': privacy['findings'],
    'scope': 'Predicate-only local JSON identity correction and reviewed static proof; not A2 or scientific closure'})
save(WORK / 'independent-review-preservation.json', archive)
status_root = HERE / 'reviewed-status'
status_root.mkdir()
status_entries = {}
for name in review['allowed_post_review_status_delta']:
    body = (ROOT / name).read_bytes()
    assert ident(body) == review['files'][name]
    target = status_root / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(body)
    status_entries[name] = ident(body)
status = pack(WORK / 'reviewed-status-before-close.tar.gz', status_root, status_entries)
status['files'] = status_entries
save(WORK / 'reviewed-status-before-close.json', status)
record = {'status': 'Independent PASS verified; final bounded closure QA remains',
    'index_sha256': PIN, 'indexed_files_verified': 720, 'archive_members_verified': 721,
    'passing_tests_verified': passing, 'parent_additional_controls_passed': 69,
    'parent_additional_controls_actual_exit': process.returncode,
    'corrected_helper_sha256': HELPER, 'source_changed_after_review': False,
    'scope': 'This does not close A2, alter historical failures or authorize commit/push'}
save(HERE / 'parent-review-readback.json', record)
print(json.dumps({'review_indexed_files_verified': 720, 'review_archive_members_verified': 721,
    'passing_tests_verified': passing, 'parent_independent_controls_passed': 69,
    'parent_actual_exit': process.returncode, 'review_archive_sha256': archive['sha256'],
    'review_privacy_findings': len(privacy['findings']), 'status_files_preserved': len(status_entries)}, indent=2))
