"""Final bounded closure QA and evidence seal; no source or delivery changes."""
import datetime
import difflib
import hashlib
import html
import io
import json
import os
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

from privacy import controls, leaf, scan

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
CASE = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
WORK = CASE / 'identity-repair-2026-11-13'
HERE = Path(__file__).parent


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    body = json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False).encode() + b'\n'
    assert not leaf(body, path.name)
    with path.open('xb') as stream:
        stream.write(body)


def pack(path, files):
    with tarfile.open(path, 'x:gz') as archive:
        for name, body in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(body), 0o644
            archive.addfile(member, io.BytesIO(body))
    with tarfile.open(path, 'r:gz') as archive:
        assert len(archive.getmembers()) == len(files)
        assert all(m.isfile() and archive.extractfile(m).read() == files[m.name] for m in archive)
    return {'archive': path.name, **ident(path.read_bytes()), 'members_verified': len(files),
            'files': {n: ident(b) for n, b in files.items()}}


baseline = json.loads((WORK / 'baseline-inputs.json').read_text())
review = json.loads((WORK / 'review-inputs.json').read_text())
protected = baseline['files'] | review['files']
allowed = set(review['allowed_post_review_status_delta'])
assert {n for n, p in protected.items() if ident((ROOT / n).read_bytes()) != p} == allowed
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == baseline['head']
assert ident(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT))['sha256'] == baseline['git_stage_sha256']
with tarfile.open(WORK / 'reviewed-status-before-close.tar.gz', 'r:gz') as archive:
    before = {m.name: archive.extractfile(m).read() for m in archive}
assert set(before) == allowed
changes, difference = {}, []
for name in sorted(allowed):
    after = (ROOT / name).read_bytes()
    assert ident(before[name]) == review['files'][name]
    changes[name] = {'before': ident(before[name]), 'after': ident(after), 'scope': 'Approval/progress only'}
    difference += list(difflib.unified_diff(before[name].decode().splitlines(True), after.decode().splitlines(True),
        fromfile='reviewed/' + name, tofile='final/' + name))
(HERE / 'status-delta.patch').write_text(''.join(difference))
verdict = json.loads((WORK / 'independent-review-verdict.json').read_text())
assert verdict['review_completed'] and verdict['passed']
assert not verdict['logic_errors'] and not verdict['security_concerns']
counts = verdict['verified_counts']
assert sum(counts[k] for k in ['typed_identity_green_tests', 'prior_regression_tests',
    'posthoc_author_defensive_tests', 'independent_additional_controls']) == counts['fresh_passing_tests'] == 230
readback = json.loads((HERE / 'parent-review-readback.json').read_text())
assert readback['parent_additional_controls_passed'] == 69 and readback['parent_additional_controls_actual_exit'] == 0
qa = HERE / 'final-qa'
qa.mkdir(exist_ok=False)
base = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync']
commands = [base + ['ruff', 'check', '--no-cache', '.'],
            base + ['python', '-B', '-m', 'pytest', 'tests/unit/test_docs_consistency.py',
                    '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(HERE / 'qa-runtime'),
                    '--junitxml=' + str(qa / 'docs.xml')],
            base + ['mkdocs', 'build', '--strict', '--site-dir', str(HERE / 'site')],
            ['git', 'diff', '--check']]
save(qa / 'plan.json', commands)
receipts = []
for i, command in enumerate(commands):
    process = subprocess.run(command, cwd=ROOT, capture_output=True,
        env=dict(os.environ, UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'),
                 PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu'))
    (qa / f'{i}-stdout.raw').write_bytes(process.stdout)
    (qa / f'{i}-stderr.raw').write_bytes(process.stderr)
    receipts.append({'command': command, 'actual_exit': process.returncode})
save(qa / 'receipts.json', receipts)
assert all(r['actual_exit'] == 0 for r in receipts)
tree = ET.parse(qa / 'docs.xml')
assert len(tree.findall('.//testcase')) == 23
assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
html_checks = {}
for name, needle in [
    ('docs/developer/phase-a-completion.md', 'Current bounded disposition'),
    ('docs/developer/bug-resolution-tracker.md', 'Scoped JSON-identity correction independently approved and parent-verified'),
    (str((CASE / 'README.md').relative_to(ROOT)), 'the scoped cap-after-qualifier increment is complete'),
    (str((WORK / 'README.md').relative_to(ROOT)), 'scoped correction independently approved and parent readback passed'),
]:
    path = Path(name).relative_to('docs')
    built = HERE / 'site' / (path.parent if path.name == 'README.md' else path.with_suffix('')) / 'index.html'
    text = ' '.join(html.unescape(re.sub('<[^>]*>', ' ', built.read_text())).split())
    assert needle in text, name
    html_checks[name] = ident(built.read_bytes())
save(HERE / 'built-status-readback.json', html_checks)
assert all(ident((ROOT / n).read_bytes()) == p for n, p in protected.items() if n not in allowed)
status = {'changed_files': changes, 'protected_files_unchanged': len(protected) - len(allowed),
    'baseline_immutable_files_unchanged': 930, 'reviewed_candidate_source_unchanged': True,
    'head_and_git_stage_unchanged': True, 'actual_qa_exits': [r['actual_exit'] for r in receipts],
    'docs_tests_passed': 23, 'built_status_text_verified': True,
    'main_repository_lint_passed': True, 'archived_lint_limitations_unchanged': True,
    'full_numerical_suites_rerun': False, 'commit_or_push_performed': False}
save(WORK / 'final-status-delta.json', status)
# Only explicit reviewed/replayed inputs and generated proof are preserved.
plan = json.loads((HERE / 'independent-controls/plan.json').read_text())
names = ['accept_review.py', 'close_increment.py', 'readback_completion.py', 'privacy.py', 'review_common.py',
         'review-proof-privacy.json', 'parent-review-readback.json', 'status-delta.patch',
         'built-status-readback.json', 'final-qa/plan.json', 'final-qa/receipts.json', 'final-qa/docs.xml',
         'independent-controls/plan.json', 'independent-controls/receipt.json',
         'independent-controls/stdout.raw', 'independent-controls/stderr.raw',
         'independent-controls/raw.xml', 'independent-controls/artifacts/imports.json']
names += ['independent-controls/before/' + n for n in plan['inputs']]
names += [f'final-qa/{i}-{s}.raw' for i in range(4) for s in ['stdout', 'stderr']]
assert len(names) == len(set(names))
files = {n: (HERE / n).read_bytes() for n in names}
parent_archive = pack(WORK / 'parent-closure-evidence.tar.gz', files)
save(WORK / 'parent-closure-preservation.json', parent_archive)
paths = sorted([p for p in WORK.rglob('*') if p.is_file()] + [ROOT / n for n in baseline['allowed_status_delta']])
privacy = scan(paths, 'Final scoped correction closure and four status documents; no private identity matching')
privacy['positive_controls'] = controls()
assert not privacy['findings']
save(WORK / 'final-privacy.json', privacy)
outcome = {'status': 'SCOPED CAP-AFTER-QUALIFIER INCREMENT AND VAL-017 REPAIR COMPLETE',
    'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'finding_id': 'CAP-AUTH-TYPE-01', 'tracker_id': 'VAL-017', 'repair_cycle': 1,
    'case_id': 'CAP-after-qualifier-f64-GL', 'repair_complete': True, 'increment_complete': True,
    'independent_review_passed': True, 'independent_review_record': 'independent-review-verdict.json',
    'corrected_helper_sha256': verdict['reviewed_identities']['corrected_helper_sha256'],
    'unchanged_checker_sha256': verdict['reviewed_identities']['unchanged_checker_sha256'],
    'source_change': 'Only the private frozen_case.py nested JSON identity predicates and minimal canonical encoder',
    'verified_counts': counts, 'passing_check_total': counts['fresh_passing_tests'],
    'parent_additional_controls_replayed': 69, 'parent_additional_control_exit': 0,
    'all_three_valid_artifacts_unchanged': True, 'artifact_identities': verdict['artifacts'],
    'historical_rejection_preserved_unchanged': True, 'historical_rejection_relabelled': False,
    'review_proof_files_verified': 720, 'review_archive_members_verified': 721,
    'baseline_immutable_files_unchanged': 930, 'status_documents_changed': len(allowed),
    'final_repository_qa': {'actual_exits': [r['actual_exit'] for r in receipts], 'docs_tests_passed': 23,
        'ruff_passed': True, 'strict_docs_passed': True, 'whitespace_passed': True,
        'built_status_text_verified': True, 'full_numerical_suites_rerun': False},
    'bounded_privacy_findings': len(privacy['findings']),
    'privacy_scope': 'Explicit regular-member streaming and pattern/field controls; local paths/hostnames retained, no universal clearance',
    'archived_checker_test_lint_findings_remaining': 106, 'inherited_capture_E501_remaining': 1,
    'numerical_source_changed': False, 'caps_changed': False, 'criteria_changed': False,
    'new_numerical_worker_fitter_or_ad_observations': False, 'eight_fit_real_blockers_resolved': False,
    'whole_packet_resource_sufficiency_proved': False, 'scientific_certification': False,
    'protocol_freeze_authorized': False, 'a2_acceptance_passed': False, 'phase_complete': False,
    'commit_push_or_release_performed': False,
    'next_boundary': 'Stop at the approved repair and static increment; broader A2/accounting or numerical implementation needs separate scope.'}
save(WORK / 'outcome.json', outcome)
paths = sorted([p for p in WORK.rglob('*') if p.is_file()] + [ROOT / n for n in baseline['allowed_status_delta']])
manifest = {'scope': 'Final scoped correction/increment; no wider A2 or delivery approval',
    'files': {str(p.relative_to(ROOT)): ident(p.read_bytes()) for p in paths},
    'file_count': len(paths), 'self_excluded': 'final-manifest.json',
    'readback_excluded': 'completion-readback.json'}
save(WORK / 'final-manifest.json', manifest)
print(json.dumps({'status': outcome['status'], 'final_manifest_files': len(paths),
    'final_manifest_sha256': ident((WORK / 'final-manifest.json').read_bytes())['sha256'],
    'parent_archive_members_verified': len(files), 'final_qa_exits': [r['actual_exit'] for r in receipts],
    'privacy_roots': privacy['root_count'], 'privacy_expanded_bodies': privacy['expanded_body_count'],
    'privacy_findings': len(privacy['findings'])}, indent=2))
