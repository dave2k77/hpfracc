"""Bounded per-member streaming privacy scan; no private identity matching."""
import ast
import gzip
import io
import json
import re
import tarfile
from pathlib import Path

from review_common import AUTHOR, BASE, CASE, ROOT, WORK, digest, pin, read, safe, save

MAX_LEAF = 100_000_000
MAX_CONTAINER = 700_000_000
MAX_AGGREGATE = 6_000_000_000
MAX_BODIES = 30_000
MAX_DEPTH = 8
SENSITIVE = {'chat_id', 'message_id', 'recipient_id', 'bot_token', 'api_key',
             'password', 'access_token', 'refresh_token', 'private_key', 'client_secret'}
PATTERNS = [re.compile(rb'\b[0-9]{7,}:[A-Za-z0-9_-]{30,}\b'),
            re.compile(rb'\bAKIA[A-Z0-9]{16}\b'),
            re.compile(rb'-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----'),
            re.compile(rb'\bBearer [A-Za-z0-9_.-]{24,}\b')]


class Meter(io.RawIOBase):
    def __init__(self, raw, state):
        self.raw = raw
        self.state = state
        self.hash = __import__('hashlib').sha256()
        self.size = 0

    def readable(self):
        return True

    def readinto(self, buffer):
        data = self.raw.read(len(buffer))
        buffer[:len(data)] = data
        self.hash.update(data)
        self.size += len(data)
        self.state['bytes'] += len(data)
        assert self.size <= MAX_CONTAINER
        assert self.state['bytes'] <= MAX_AGGREGATE
        return len(data)


def static(raw, name):
    found = []
    for node in ast.walk(ast.parse(raw)):
        if not isinstance(node, ast.Call):
            continue
        fn = node.func
        label = fn.id if isinstance(fn, ast.Name) else fn.attr if isinstance(fn, ast.Attribute) else ''
        bad = label in {'eval', 'exec', 'system'}
        bad |= any(k.arg == 'shell' and isinstance(k.value, ast.Constant)
                   and k.value.value is True for k in node.keywords)
        bad |= label in {'load', 'loads'} and isinstance(fn, ast.Attribute) and isinstance(fn.value, ast.Name) and fn.value.id == 'pickle'
        if bad:
            found.append({'path': name, 'line': node.lineno, 'rule': 'unsafe-call'})
    return found


def leaf(raw, name):
    findings = [{'path': name, 'rule': 'credential-pattern-' + str(i)}
                for i, pattern in enumerate(PATTERNS) if pattern.search(raw)]
    if any(token in name.lower() for token in ['telegram-receipt', 'delivery-receipt', 'message-receipt']):
        findings.append({'path': name, 'rule': 'private-receipt-path'})
    try:
        value = json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        return findings
    pending = [(value, '$')]
    while pending:
        value, location = pending.pop()
        if isinstance(value, dict):
            for key, child in value.items():
                field = location + '.' + key
                if key.lower() in SENSITIVE and child is not None:
                    findings.append({'path': name, 'field': field, 'rule': 'sensitive-field'})
                pending.append((child, field))
        elif isinstance(value, list):
            pending.extend((child, location + '[]') for child in value)
    return findings


def scan_stream(source, name, state, depth=0):
    assert depth <= MAX_DEPTH
    assert len(state['bodies']) < MAX_BODIES
    meter = Meter(source, state)
    buffered = io.BufferedReader(meter, buffer_size=64 * 1024)
    prefix = buffered.peek(512)
    container = False
    if name.endswith(('.tar.gz', '.tgz', '.tar')) or (len(prefix) >= 262 and prefix[257:262] == b'ustar'):
        container = True
        seen = set()
        with tarfile.open(fileobj=buffered, mode='r|*') as archive:
            for member in archive:
                safe(member.name)
                assert member.isfile() and member.name not in seen
                seen.add(member.name)
                assert member.size <= MAX_CONTAINER
                with archive.extractfile(member) as stream:
                    child = scan_stream(stream, name + '!' + member.name, state, depth + 1)
                assert child['bytes'] == member.size
    elif prefix.startswith(b'\x1f\x8b'):
        container = True
        with gzip.GzipFile(fileobj=buffered) as inflated:
            scan_stream(inflated, name + '!gzip', state, depth + 1)
    elif prefix.startswith(b'PK\x03\x04'):
        raise ValueError('Unexpected ZIP requires separate bounded review: ' + name)
    else:
        raw = buffered.read(MAX_LEAF + 1)
        assert len(raw) <= MAX_LEAF, ('leaf limit', name)
        state['findings'].extend(leaf(raw, name))
    while buffered.read(1024 * 1024):
        pass
    spec = {'bytes': meter.size, 'sha256': meter.hash.hexdigest(), 'container': container, 'depth': depth}
    state['bodies'][name] = spec
    return spec


def scan(paths, label):
    state = {'bytes': 0, 'bodies': {}, 'findings': []}
    roots = {}
    for path in paths:
        expected = pin(path)
        with path.open('rb') as stream:
            actual = scan_stream(stream, str(path), state)
        assert {k: actual[k] for k in ['bytes', 'sha256']} == expected
        roots[str(path)] = expected
    report = {'scope': label, 'roots': roots, 'root_count': len(roots),
              'expanded_body_count': len(state['bodies']), 'streamed_bytes': state['bytes'],
              'bodies': state['bodies'], 'findings': state['findings'],
              'bounds': {'per_leaf_bytes': MAX_LEAF, 'per_container_bytes': MAX_CONTAINER,
                         'aggregate_streamed_bytes': MAX_AGGREGATE, 'bodies': MAX_BODIES, 'depth': MAX_DEPTH},
              'limitations': ['Explicit task-input and owned-output closure only.',
                             'Local paths and hostnames retained; no private identity matching.',
                             'Patterns and structured fields do not establish universal privacy clearance.',
                             'Scanner bounds are administrative, not numerical caps.']}
    return report


def controls():
    raw = json.dumps({'chat_id': 'SYNTHETIC_NOT_REAL'}).encode()
    store = io.BytesIO()
    with tarfile.open(fileobj=store, mode='w:gz') as tar:
        info = tarfile.TarInfo('synthetic.json')
        info.size = len(raw)
        tar.addfile(info, io.BytesIO(raw))
    state = {'bytes': 0, 'bodies': {}, 'findings': []}
    scan_stream(io.BytesIO(store.getvalue()), 'synthetic.tar.gz', state)
    assert any(x['rule'] == 'sensitive-field' for x in state['findings'])
    assert leaf(b'A' + b'KIA' + b'Z' * 16, 'synthetic-token')
    assert static(b'eval("synthetic")', 'synthetic.py')
    assert not leaf(json.dumps({'case_id': 'STATIC', 'sha256': '0' * 64}).encode(), 'benign.json')
    return {'synthetic_only': True, 'gzip_tar_structured_positive': True,
            'credential_pattern_positive': True, 'unsafe_call_positive': True, 'benign_control': True}


def final_paths():
    paths = []
    for path in BASE.rglob('*'):
        relative = path.relative_to(BASE)
        if any(p in {'runtime', '__pycache__', '.pytest_cache', '.ruff_cache', 'site'} for p in relative.parts):
            continue
        if path.is_file():
            assert not path.is_symlink()
            if relative.as_posix() not in {'evidence-index.json', 'privacy-final.json'}:
                paths.append(path)
    return sorted(paths)


def main():
    control = controls()
    review = read(WORK / 'review-inputs.json')
    paths = [ROOT / n for n in review['files']]
    paths += [WORK / 'review-inputs.json', CASE / 'author-evidence.tar.gz',
              CASE / 'independent-review-rejected-evidence.tar.gz']
    report = scan(paths, 'Frozen corrected candidate/status set plus unchanged rejected archives')
    report['positive_controls'] = control
    authored = read(WORK / 'correction-result.json')['privacy']['static_sources']
    security = []
    for n in authored:
        security.extend(static((AUTHOR / n).read_bytes(), str(AUTHOR / n)))
    for path in sorted(BASE.glob('*.py')):
        security.extend(static(path.read_bytes(), str(path)))
    report['authored_source_security_findings'] = security
    report['authored_source_count'] = len(authored) + len(list(BASE.glob('*.py')))
    save(BASE / 'privacy-input-report.json', report)
    assert not report['findings'] and not security
    print(json.dumps({'root_count': report['root_count'], 'expanded_body_count': report['expanded_body_count'],
                      'streamed_bytes': report['streamed_bytes'], 'unresolved_findings': len(report['findings'])}))


if __name__ == '__main__':
    main()
