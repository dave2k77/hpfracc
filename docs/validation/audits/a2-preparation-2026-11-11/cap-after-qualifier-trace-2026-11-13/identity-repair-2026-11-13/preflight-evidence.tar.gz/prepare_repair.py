"""Freeze a narrow repair against preserved rejection, without rewriting history."""
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
CASE = AUDIT / 'cap-after-qualifier-trace-2026-11-13'
WORK = CASE / 'identity-repair-2026-11-13'
HERE = Path(__file__).parent


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def put(name, body):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(body)
    assert path.read_bytes() == body
    return ident(body)


blocked_raw = (CASE / 'blocked-manifest.json').read_bytes()
assert ident(blocked_raw)['sha256'] == 'a153aa81b7e6a8301e2dd5e58f83c1959345eac6462b08705b56e0e44a277f3c'
blocked = json.loads(blocked_raw)
assert blocked['file_count'] == len(blocked['files']) == 30
assert all(ident((ROOT / n).read_bytes()) == p for n, p in blocked['files'].items())
verdict = json.loads((CASE / 'independent-review-verdict.json').read_text())
assert verdict['review_completed'] and not verdict['passed']
assert verdict['finding']['finding_id'] == 'CAP-AUTH-TYPE-01'
copies, archive_checks = {}, {}
for name, pin, index_pin, expected_count in [
    ('author-evidence.tar.gz', '0d43fc05ffae9ca1c40d466fbb7d89505ea78ccea629c03698f83537aa09c060',
     '1d77d07793e5b0e3c816efdef95d3e6293357437505bf1f5df9a3c64da28f0f9', 1706),
    ('independent-review-rejected-evidence.tar.gz', 'b1e557ec4782621d4b3af6b936f1cd490372ea67aa04e1286a1559e75e007d0d',
     '3868fac2293dbef9049ad9bc1fd3b75a4e586472287e4a70e73b304c5162d895', 532),
]:
    path = CASE / name
    assert ident(path.read_bytes())['sha256'] == pin
    with tarfile.open(path, 'r:gz') as archive:
        members = archive.getmembers()
        names = [m.name for m in members]
        assert len(names) == len(set(names)) == expected_count + 1
        assert all(m.isfile() and not m.name.startswith('/') and '\\' not in m.name
                   and all(v not in ('', '.', '..') for v in m.name.split('/')) for m in members)
        raw = archive.extractfile('evidence-index.json').read()
        assert ident(raw)['sha256'] == index_pin
        index = json.loads(raw)
        assert index['file_count'] == len(index['files']) == expected_count
        assert set(names) == set(index['files']) | {'evidence-index.json'}
        for member, expected in index['files'].items():
            assert ident(archive.extractfile(member).read()) == expected
        if name == 'author-evidence.tar.gz':
            copies['author-index.json'] = put('author-index.json', raw)
            selected = {n: 'author/' + n for n in index['files'] if n.startswith('candidate/')}
            selected['capture.py'] = 'author/capture.py'
            selected['privacy_security.py'] = 'author/privacy_security.py'
            for group in ['regression-final-positive', 'regression-final-negative',
                          'controls-complete', 'negative-equality-final']:
                for n in index['files']:
                    if n.startswith('runs/' + group + '/before/') or n == 'runs/' + group + '/job.json':
                        selected[n] = 'author/' + n
            for role, member in [
                ('positive', 'frozen/previous-author/baseline/trace.json'),
                ('nonqualifier', 'frozen/previous-author/final/trace.json'),
                ('cap', 'runs/controls-complete/artifacts/trace.json')]:
                selected[member] = 'golden/' + role + '-trace.json'
        else:
            copies['review-index.json'] = put('review-index.json', raw)
            selected = {}
            prefix = 'runs/canonical-type-controls/'
            for n in index['files']:
                if n.startswith(prefix + 'before/') or n.startswith(prefix + 'artifacts/') or n in [prefix + 'plan.json', prefix + 'receipt.json']:
                    selected[n] = 'rejected-probe/' + n.removeprefix(prefix)
            selected['verdict.json'] = 'rejected-verdict.json'
        for member, destination in selected.items():
            copies[destination] = put(destination, archive.extractfile(member).read())
    archive_checks[name] = {'sha256': pin, 'indexed_files_verified': expected_count,
                           'members_verified': len(names), 'index_sha256': index_pin}
assert copies['author/candidate/a2_trace.py']['sha256'] == '819fbbafd5b42e9f1bc0c5be320e56146876ff7047a71073def9b9141fba92fa'
assert copies['author/candidate/frozen_case.py']['sha256'] == '93354458e3633a1bd198049b265a6eb9d3582df9ec5d31d5d87006e24119462b'
allowed = json.loads((WORK / 'authorization.json').read_text())['parent_status_updates_allowed']
tracked = [ROOT / n.decode() for n in subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0') if n]
paths = sorted(set(tracked + [p for p in AUDIT.rglob('*') if p.is_file() and WORK not in p.parents]
                   + [ROOT / 'docs/developer/a2-compression-budget-protocol.md']))
assert all(p.is_file() and not p.is_symlink() for p in paths)
baseline = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'git_stage_sha256': ident(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT))['sha256'],
    'git_stage_encoding': 'git ls-files --stage -z raw bytes',
    'files': {str(p.relative_to(ROOT)): ident(p.read_bytes()) for p in paths},
    'allowed_status_delta': allowed,
    'approval_record': ident((WORK / 'authorization.json').read_bytes()),
    'scope': 'Existing tracked repository and explicit A2 proof only; all prior failed evidence immutable except three enumerated progress documents'}
save(WORK / 'baseline-inputs.json', baseline)
save(HERE / 'copied-inputs.json', copies)
status_files = {n: (ROOT / n).read_bytes() for n in allowed}
with tarfile.open(WORK / 'pre-repair-status.tar.gz', 'x:gz') as archive:
    for n, body in sorted(status_files.items()):
        member = tarfile.TarInfo(n)
        member.size, member.mode = len(body), 0o644
        archive.addfile(member, io.BytesIO(body))
with tarfile.open(WORK / 'pre-repair-status.tar.gz', 'r:gz') as archive:
    assert len(archive.getmembers()) == len(status_files)
    assert all(archive.extractfile(n).read() == body for n, body in status_files.items())
save(WORK / 'pre-repair-status.json', {'archive': 'pre-repair-status.tar.gz',
    **ident((WORK / 'pre-repair-status.tar.gz').read_bytes()),
    'files': {n: ident(body) for n, body in status_files.items()}})
result = {'status': 'Owner-approved single repair pinned; historical rejection unchanged',
    'blocked_manifest_files_verified': len(blocked['files']), 'archives': archive_checks,
    'baseline_files': len(paths), 'immutable_baseline_files': len(paths) - len(allowed),
    'copied_files': len(copies), 'copied_input_directory': str(HERE), 'copied_inputs': copies,
    'repair_scope': 'Only frozen_case.py typed identity predicates and new separate tests/proof; unchanged valid artifacts required',
    'source_repair_started': False, 'independent_approval': False}
save(WORK / 'preflight.json', result)
print(json.dumps({k: result[k] for k in ['status', 'blocked_manifest_files_verified', 'baseline_files',
      'immutable_baseline_files', 'copied_files']}, indent=2))
