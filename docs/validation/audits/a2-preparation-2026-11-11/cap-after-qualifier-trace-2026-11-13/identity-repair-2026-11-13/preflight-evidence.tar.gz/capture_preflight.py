"""Capture pre-repair status QA and preserve the input-discovery procedure."""
import hashlib
import io
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13/identity-repair-2026-11-13'
HERE = Path(__file__).parent


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


pins = json.loads((WORK / 'baseline-inputs.json').read_text())
protected = {n: p for n, p in pins['files'].items() if n not in pins['allowed_status_delta']}
assert len(protected) == 930
assert all(ident((ROOT / n).read_bytes()) == p for n, p in protected.items())
qa = HERE / 'preflight-qa'
qa.mkdir(exist_ok=False)
base = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync']
commands = [base + ['ruff', 'check', '--no-cache', '.'],
            base + ['python', '-B', '-m', 'pytest', 'tests/unit/test_docs_consistency.py',
                    '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(HERE / 'qa-runtime'),
                    '--junitxml=' + str(qa / 'docs.xml')],
            base + ['mkdocs', 'build', '--strict', '--site-dir', str(HERE / 'site')],
            ['git', 'diff', '--check']]
save(qa / 'plan.json', commands)
receipts = []
for i, command in enumerate(commands):
    process = subprocess.run(command, cwd=ROOT, capture_output=True,
        env=dict(os.environ, UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'),
                 PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu'))
    (qa / f'{i}-stdout.raw').write_bytes(process.stdout)
    (qa / f'{i}-stderr.raw').write_bytes(process.stderr)
    receipts.append({'command': command, 'actual_exit': process.returncode})
save(qa / 'receipts.json', receipts)
assert all(r['actual_exit'] == 0 for r in receipts)
tree = ET.parse(qa / 'docs.xml')
assert len(tree.findall('.//testcase')) == 23
assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
assert all(ident((ROOT / n).read_bytes()) == p for n, p in protected.items())
names = ['prepare_repair.py', 'capture_preflight.py', 'copied-inputs.json',
         'preflight-qa/plan.json', 'preflight-qa/receipts.json', 'preflight-qa/docs.xml']
names += [f'preflight-qa/{i}-{s}.raw' for i in range(4) for s in ['stdout', 'stderr']]
files = {n: (HERE / n).read_bytes() for n in names}
archive_path = WORK / 'preflight-evidence.tar.gz'
with tarfile.open(archive_path, 'x:gz') as archive:
    for name, body in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(body), 0o644
        archive.addfile(member, io.BytesIO(body))
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(files)
    assert all(m.isfile() and archive.extractfile(m).read() == files[m.name] for m in members)
save(WORK / 'preflight-preservation.json', {'archive': archive_path.name, **ident(archive_path.read_bytes()),
    'members_verified': len(files), 'files': {n: ident(b) for n, b in files.items()},
    'qa_actual_exits': [r['actual_exit'] for r in receipts], 'docs_tests_passed': 23,
    'protected_files_unchanged': len(protected),
    'scope': 'Initial status/documentation QA and discovery-source preservation, not corrected-candidate or independent approval'})
print(json.dumps({'protected_files_unchanged': len(protected), 'qa_actual_exits': [r['actual_exit'] for r in receipts],
                  'docs_tests_passed': 23, 'archive_members_verified': len(files)}))
