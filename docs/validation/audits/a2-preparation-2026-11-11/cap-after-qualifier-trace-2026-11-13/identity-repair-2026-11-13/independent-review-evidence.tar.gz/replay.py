"""Execute only explicit verified copies; preserve actual exits and raw streams."""
import os
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

from review_common import AUTHOR, BASE, CHECKER, NEW, ROOT, pin, read, safe, save

UV = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync', 'python', '-B']


def execute(name, source_run, addition=None, script=None, expected_count=None):
    recipe = read(AUTHOR / 'runs' / source_run / 'job.json')
    run = BASE / 'replays' / name
    before = run / 'before'
    before.mkdir(parents=True)
    runtime = run / 'runtime'
    runtime.mkdir()
    input_pins = {}
    for n, spec in recipe['inputs'].items():
        src = AUTHOR / 'runs' / source_run / 'before' / safe(n)
        assert pin(src) == spec['pin']
        dst = before / n
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        assert pin(dst) == spec['pin']
        input_pins[n] = {'source': str(src), **pin(dst)}
    if addition:
        for n, src in addition.items():
            assert n not in input_pins
            shutil.copyfile(src, before / n)
            input_pins[n] = {'source': str(src), **pin(before / n)}
    selection = script if script is not None else recipe['selection']
    is_test = recipe['expected_count'] is not None if script is None else selection[0] == 'test_independent_identity.py'
    args = ['run_selected.py']
    count = expected_count if expected_count is not None else recipe['expected_count']
    if is_test:
        args += ['pytest', '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(runtime / 'pytest'),
                 '--junitxml=' + str(run / 'raw.xml')] + selection
    else:
        args += selection
    env = {'PYTHONDONTWRITEBYTECODE': '1', 'JAX_PLATFORMS': 'cpu',
           'UV_PROJECT_ENVIRONMENT': str(ROOT / '.venv'),
           'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1', 'TMPDIR': str(runtime)}
    plan = {'argv': UV + args, 'cwd': str(before), 'environment_overrides': env,
            'selection': selection, 'inputs': input_pins,
            'capture_entrypoint': pin(BASE / 'replay.py'),
            'environment_inputs': {str(ROOT / n): pin(ROOT / n) for n in ['pyproject.toml', 'uv.lock']},
            'source_recipe': str(AUTHOR / 'runs' / source_run / 'job.json'),
            'source_recipe_pin': pin(AUTHOR / 'runs' / source_run / 'job.json'),
            'expected_exit': recipe['expected_exit'], 'expected_count': count}
    save(run / 'plan.json', plan)
    started = time.time_ns()
    with (run / 'stdout.bin').open('wb') as out, (run / 'stderr.bin').open('wb') as err:
        child = subprocess.Popen(plan['argv'], cwd=before, env=os.environ | env, stdout=out, stderr=err)
        save(run / 'started.json', {'child_started': True, 'pid': child.pid, 'start_time_ns': started})
        exit_code = child.wait(timeout=240)
    after = {n: pin(before / n) for n in input_pins}
    assert after == {n: {k: p[k] for k in ['bytes', 'sha256']} for n, p in input_pins.items()}
    result = {'actual_child_exit': exit_code, 'ended_time_ns': time.time_ns(), 'inputs_after': after,
              'stdout': pin(run / 'stdout.bin'), 'stderr': pin(run / 'stderr.bin'), 'inputs_unchanged': True}
    imports = read(run / 'artifacts/imports.json')
    for mod in ['a2_trace', 'frozen_case']:
        src = before / (mod + '.py')
        assert imports[mod] == {'path': str(src), **pin(src)}
    assert imports['a2_trace']['sha256'] == CHECKER
    result['imports'] = imports
    if is_test:
        cases = ET.parse(run / 'raw.xml').getroot().findall('.//testcase')
        identities = [(c.attrib['classname'], c.attrib['name']) for c in cases]
        failures = [{'name': c.attrib['name'], 'message': c.find('failure').attrib['message']}
                    for c in cases if c.find('failure') is not None]
        result['junit'] = {'raw': pin(run / 'raw.xml'), 'count': len(cases), 'identities': identities,
                           'failures': failures, 'errors': sum(c.find('error') is not None for c in cases),
                           'skipped': sum(c.find('skipped') is not None for c in cases)}
    save(run / 'receipt.json', result)
    assert exit_code == plan['expected_exit'], (name, exit_code, plan['expected_exit'])
    if is_test:
        assert len(cases) == count and len(set(identities)) == count
        assert result['junit']['errors'] == result['junit']['skipped'] == 0
        if exit_code == 0:
            assert not failures
        if name != 'independent-controls':
            old_cases = ET.parse(AUTHOR / 'runs' / source_run / 'raw.xml').getroot().findall('.//testcase')
            assert identities == [(c.attrib['classname'], c.attrib['name']) for c in old_cases]
            old_failures = [{'name': c.attrib['name'], 'message': c.find('failure').attrib['message']}
                            for c in old_cases if c.find('failure') is not None]
            assert failures == old_failures
    print(name, 'actual_child_exit', exit_code, 'count', count, flush=True)
    return {'actual_child_exit': exit_code, 'count': count, 'receipt': pin(run / 'receipt.json')}


def main():
    outcomes = {}
    jobs = [('red-reproduction', 'red'), ('typed-green', 'green-final'),
            ('positive-regressions', 'regression-final-positive-final'),
            ('nonqualifier-regressions', 'regression-final-negative-final'),
            ('cap-regressions', 'controls-complete-final'),
            ('nonqualifier-equality', 'negative-equality-final-final'),
            ('posthoc-defensive', 'posthoc-defensive-final')]
    for name, original in jobs:
        outcomes[name] = execute(name, original)
        save(BASE / 'replay-progress.json', outcomes)
    outcomes['independent-controls'] = execute('independent-controls', 'green-final',
        addition={'test_independent_identity.py': BASE / 'test_independent_identity.py'},
        script=['test_independent_identity.py'], expected_count=12 * 3 + 4 * 3 + 3 * 3 + 2 + 9 + 1)
    save(BASE / 'replay-progress.json', outcomes)
    for kind in ['positive', 'nonqualifier', 'cap']:
        name = 'artifact-' + kind
        outcomes[name] = execute(name, 'artifact-' + kind + '-v2-final',
            addition={'reviewer_artifacts.py': BASE / 'reviewer_artifacts.py'}, script=['reviewer_artifacts.py'])
        save(BASE / 'replay-progress.json', outcomes)
    for name, original in [('probe-original', 'original-probe-red'), ('probe-corrected', 'original-probe-green-final'),
                           ('mutant-case', 'mutant-case-final'), ('mutant-bundle', 'mutant-bundle-final'),
                           ('mutant-scalar', 'mutant-scalar-final'), ('mutant-full', 'mutant-full-original')]:
        outcomes[name] = execute(name, original)
        save(BASE / 'replay-progress.json', outcomes)
    assert len(outcomes) == 17
    for name in ['typed-green', 'positive-regressions', 'nonqualifier-regressions', 'cap-regressions',
                 'nonqualifier-equality', 'posthoc-defensive', 'independent-controls',
                 'artifact-positive', 'artifact-nonqualifier', 'artifact-cap', 'probe-corrected']:
        assert read(BASE / 'replays' / name / 'artifacts/imports.json')['frozen_case']['sha256'] == NEW
    save(BASE / 'replay-summary.json', {'runs': outcomes, 'count': len(outcomes),
         'scope': 'New copied-input independent replay; no mutation of repository or author candidate'})


if __name__ == '__main__':
    main()
