"""Allowlisted input preservation and exact read-only repository protection."""

import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
INPUT = BASE.parent / 'hpfracc-cap-identity-preflight-20261113'
CASE = ROOT / ('docs/validation/audits/a2-preparation-2026-11-11/'
               'cap-after-qualifier-trace-2026-11-13')
WORK = CASE / 'identity-repair-2026-11-13'


def meta(path):
    assert path.is_file() and not path.is_symlink(), path
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': digest}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2) + '\n')


def protection(phase):
    baseline = json.loads((WORK / 'baseline-inputs.json').read_bytes())
    out = BASE / ('protection-' + phase)
    out.mkdir()
    commands = [['git', 'rev-parse', 'HEAD'], ['git', 'ls-files', '--stage', '-z']]
    save(out / 'plan.json', {'argv': commands, 'cwd': str(ROOT),
                           'baseline': meta(WORK / 'baseline-inputs.json'),
                           'entrypoint': meta(Path(__file__))})
    observed = []
    for name, argv in zip(['head', 'git-stage'], commands, strict=True):
        child = subprocess.run(argv, cwd=ROOT, capture_output=True, check=False)
        (out / (name + '.stdout.bin')).write_bytes(child.stdout)
        (out / (name + '.stderr.bin')).write_bytes(child.stderr)
        observed.append(child)
        assert child.returncode == 0
    assert observed[0].stdout.decode().strip() == baseline['head']
    stage = hashlib.sha256(observed[1].stdout).hexdigest()
    assert stage == baseline['git_stage_sha256']
    immutable = {}
    allowed = {}
    for name, pin in baseline['files'].items():
        actual = meta(ROOT / name)
        if name in baseline['allowed_status_delta']:
            allowed[name] = {'baseline': pin, 'current': actual}
        else:
            immutable[name] = actual
            assert actual == pin, name
    assert len(immutable) == 930 and len(allowed) == 3
    assert meta(WORK / 'authorization.json') == baseline['approval_record']
    copied = json.loads((INPUT / 'copied-inputs.json').read_bytes())
    assert len(copied) == 87
    for name, pin in copied.items():
        assert meta(INPUT / name) == pin, name
    save(out / 'result.json', {
        'passed': True, 'head': baseline['head'], 'git_stage_sha256': stage,
        'immutable_count': len(immutable), 'immutable': immutable,
        'allowed_parent_statuses': allowed, 'copied_inputs_verified': len(copied),
        'actual_child_exits': [c.returncode for c in observed],
    })
    print(json.dumps({'protection': phase, 'immutable': len(immutable),
                      'inputs': len(copied), 'passed': True}))


def initialize():
    protection('before')
    pins = json.loads((INPUT / 'copied-inputs.json').read_bytes())
    for name, pin in pins.items():
        dest = BASE / 'preserved' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        assert not dest.exists()
        shutil.copyfile(INPUT / name, dest)
        assert meta(dest) == pin
    for name in ['baseline-inputs.json', 'authorization.json', 'preflight.json']:
        shutil.copyfile(WORK / name, BASE / 'preserved' / name)
    shutil.copyfile(INPUT / 'copied-inputs.json', BASE / 'preserved/copied-inputs.json')
    candidate = BASE / 'candidate'
    candidate.mkdir()
    for name in ['frozen_case.py', 'a2_trace.py']:
        shutil.copyfile(BASE / 'preserved/author/candidate' / name, candidate / name)
    shutil.copyfile(BASE / 'preserved/author/capture.py', BASE / 'capture.py')
    save(BASE / 'initialization.json', {
        'copied_count': len(pins), 'candidate': {
            p.name: meta(p) for p in candidate.iterdir()},
        'scope': 'Owned scratch only; one authorized predicate repair; no review claim',
    })


if __name__ == '__main__':
    if sys.argv[1] == 'initialize':
        initialize()
    else:
        protection(sys.argv[1])
