"""Read CPU interpreter/package identities without importing numerical backends."""

import importlib.metadata
import json
import os
import platform
import sys
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
assert Path(sys.prefix) == ROOT / '.venv'
assert os.environ['JAX_PLATFORMS'] == 'cpu'
report = {
    'python': sys.version, 'executable': sys.executable, 'prefix': sys.prefix,
    'platform': platform.platform(),
    'packages': {n: importlib.metadata.version(n) for n in ['pytest', 'ruff', 'jax']},
    'environment': {n: os.environ[n] for n in ['UV_PROJECT_ENVIRONMENT',
                    'PYTHONDONTWRITEBYTECODE', 'JAX_PLATFORMS',
                    'PYTEST_DISABLE_PLUGIN_AUTOLOAD', 'TMPDIR']},
    'jax_imported': 'jax' in sys.modules,
}
assert report['jax_imported'] is False
print(json.dumps(report, indent=2))
