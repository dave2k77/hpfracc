"""Pin final formatted source and replay every affected gate in fresh copies."""

import ast
import difflib
import json
from pathlib import Path

from finalize import AUTHORED
from plan_jobs import job
from provision import meta, save
from verify_runs import FINAL_MAP

BASE = Path(__file__).resolve().parent
helper = BASE / 'candidate/frozen_case.py'
new = helper.read_text()
old = (BASE / 'preserved/author/candidate/frozen_case.py').read_text()
intermediate = (BASE / 'runs/green/before/frozen_case.py').read_text()
assert ast.dump(ast.parse(new)) == ast.dump(ast.parse(intermediate))
(BASE / 'source-final.diff').write_text(''.join(difflib.unified_diff(
    old.splitlines(True), new.splitlines(True), fromfile='original/frozen_case.py',
    tofile='candidate/frozen_case.py')))
save(BASE / 'source-final.json', {
    'candidate': meta(helper), 'intermediate': meta(
        BASE / 'runs/green/before/frozen_case.py'),
    'formatting_only_since_first_green': True,
    'ast_identical_to_first_green': True,
})
patterns = {
    'case': ("canonical(authority['case']) == canonical(case)",
             "authority['case'] == case"),
    'bundle': ("canonical(authority['bundle']) == canonical(bundle)",
               "authority['bundle'] == bundle"),
    'scalar': ("canonical(authority['working_scalars']) ==\n"
               "         canonical(fixture['working_scalars'])",
               "authority['working_scalars'] == fixture['working_scalars']"),
}
for name, (before, after) in patterns.items():
    assert new.count(before) == 1
    changed = new.replace(before, after)
    path = BASE / 'mutants-final' / name / 'frozen_case.py'
    path.parent.mkdir(parents=True)
    path.write_text(changed)
    (path.parent / 'mutation.diff').write_text(''.join(difflib.unified_diff(
        new.splitlines(True), changed.splitlines(True), fromfile='candidate',
        tofile=name)))
    save(path.parent / 'plan.json', {
        'original': meta(helper), 'mutant': meta(path), 'old_string': before,
        'new_string': after, 'exact_replacement_count': 1,
    })
for previous, name in FINAL_MAP.items():
    recipe = json.loads((BASE / 'jobs' / (previous + '.json')).read_bytes())
    inputs = {n: BASE / 'runs' / previous / 'before' / n for n in recipe['inputs']}
    inputs['frozen_case.py'] = helper
    if previous.startswith('mutant-'):
        inputs['frozen_case.py'] = (BASE / 'mutants-final' /
                                    previous.removeprefix('mutant-') / 'frozen_case.py')
    job(name, inputs, recipe['selection'],
        kind='pytest' if recipe['expected_count'] is not None else 'script',
        expected_exit=recipe['expected_exit'], expected_count=recipe['expected_count'])
lint_root = BASE / 'lint-preserved/runs'
recipe = json.loads((lint_root / 'lint-candidate-final/job.json').read_bytes())
args = recipe['argv'][8:]
for name, frozen in [('original', BASE / 'preserved/author/candidate/frozen_case.py'),
                     ('final', helper)]:
    inputs = {n: lint_root / 'lint-candidate-final/before' / n
              for n in recipe['inputs']}
    inputs['frozen_case.py'] = frozen
    job('lint-historical-' + name, inputs, args, kind='raw', expected_exit=1)
recipe = json.loads((lint_root / 'lint-inherited-capture/job.json').read_bytes())
job('lint-earlier-capture', {n: lint_root / 'lint-inherited-capture/before' / n
                            for n in recipe['inputs']},
    recipe['argv'][8:], kind='raw', expected_exit=1)
inputs = {n: BASE / n for n in AUTHORED}
inputs['pyproject.toml'] = BASE / 'preserved/author/candidate/pyproject.toml'
job('lint-new-final', inputs, ['-m', 'ruff', 'check', '--no-cache', '--config',
    'pyproject.toml', '--output-format', 'json'] + AUTHORED, kind='raw')
save(BASE / 'quality-attempts.json', {
    'lint_original_subset': {'findings': 87, 'scope': 'Six candidate-directory files'},
    'lint_candidate_intermediate_subset': {'findings': 88,
                                         'introduced': 'One E501 in new predicate'},
    'lint_new_intermediate': {'findings': 22, 'all_rule': 'E501'},
    'source_adjustment': 'Whitespace-only wrap; AST unchanged; all gates replayed',
    'current_capture_lint': {'findings': 0, 'actual_exit': 0,
                             'initial_expected_exit': 1},
    'historical_scope_correction': '106 belongs to original eight-file checker/test '
                                   'layout; E501 belongs to earlier run_snapshot.py, '
                                   'not the unchanged current capture.py.',
    'all_attempts_preserved': True,
})
