"""Posthoc artifact invariance and byte-state replay; not new numerical work."""

import hashlib
import json
from pathlib import Path

import a2_trace as audit

HERE = Path(__file__).resolve().parent
OUT = HERE.parent / 'artifacts'
OUT.mkdir(exist_ok=True)


def enc(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('utf-8')


def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def metrics(value):
    if isinstance(value, dict):
        children = [metrics(v) for v in value.values()]
        return (1 + len(value) + sum(c[0] for c in children),
                1 + max([1] + [c[1] for c in children]))
    if isinstance(value, list):
        children = [metrics(v) for v in value]
        return 1 + sum(c[0] for c in children), 1 + max([0] + [c[1] for c in children])
    return 1, 1


def main():
    golden_raw = (HERE / 'golden-trace.json').read_bytes()
    golden = json.loads(golden_raw)
    trace = audit.make_trace()
    verification = audit.verify_trace(trace)
    raw = enc(trace)
    golden_canonical = enc(golden)
    assert raw == golden_canonical
    old = {p: enc(v) for p, v in golden['records'].items()}
    old.update({p: bytes.fromhex(v) for p, v in golden['logs'].items()})
    bodies = audit.raw_files(trace)
    expected = {
        'REF-PASS-f64-GL': (38, 'selected', 'a-good2-f64-GL'),
        'REF-FAIL-f64-GL': (27, 'no_supplied_candidate_meets_bound', None),
        'CAP-after-qualifier-f64-GL': (28, 'indeterminate', None),
    }[trace['case_id']]
    assert len(bodies) == len(old) == expected[0]
    assert bodies == old
    assert enc(trace['initial_index']) == enc(golden['initial_index'])
    assert enc(trace['events']) == enc(golden['events'])
    assert enc(trace['ledger']) == enc(golden['ledger'])
    result = trace['records']['result.json']
    assert (result['status'], result['selected_id']) == expected[1:]
    all_bodies = bodies | {'INITIAL_INDEX': enc(trace['initial_index'])}
    live = {}
    cumulative = peak = 0
    terms = {}
    state_log = []
    for event in trace['events']:
        if event['op'] == 'write':
            data = all_bodies[event['body']]
            cumulative += len(data)
            live[event['path']] = data
            assert event['body'] not in terms
            terms[event['body']] = len(data)
        else:
            assert event['op'] == 'replace'
            live[event['target']] = live.pop(event['source'])
        live_bytes = sum(map(len, live.values()))
        peak = max(peak, live_bytes)
        state_log.append({'event': event, 'live_bytes': live_bytes,
                          'cumulative_written_bytes': cumulative})
    assert live == bodies
    ledger = trace['ledger']
    assert ledger['terms'] == terms
    assert ledger['cumulative_written_bytes'] == cumulative
    assert ledger['final_live_bytes'] == sum(map(len, live.values()))
    assert ledger['peak_live_bytes'] == peak
    assert ledger == audit.replay_ledger(trace) == verification['ledger']
    assert ledger['old_index_bytes_charged'] == len(all_bodies['INITIAL_INDEX'])
    assert ledger['temporary_bytes_charged'] == len(bodies['failure-index.json'])
    transaction = ['INITIAL_INDEX', 'failure-index.json', 'records/process.json',
                   'records/export.json', 'records/output-control.json']
    assert ledger['index_transaction_bytes'] == sum(len(all_bodies[p])
                                                   for p in transaction)
    parse = {p: {'nodes': metrics(v)[0], 'depth': metrics(v)[1]}
             for p, v in trace['records'].items()}
    assert parse == {p: {'nodes': metrics(v)[0], 'depth': metrics(v)[1]}
                     for p, v in golden['records'].items()}
    if trace['case_id'] == 'CAP-after-qualifier-f64-GL':
        assert verification['complete_slot_count'] == 13
        assert verification['unknown_slot_count'] == 9
        unknown = result['assessments'][1]
        assert unknown['qualifies'] is None and len(unknown['slots']) == 9
        for slot in unknown['slots']:
            assert slot['status'] == 'unknown'
            assert all(slot[k] is None for k in ['raw_array', 'exact_array',
                                               'producer_binding_sha256'])
            assert 'arrays/' + slot['slot_id'] + '.json' not in bodies
        assert 'records/binding-host-1.json' not in bodies
    else:
        assert verification['unknown_slot_count'] == 0
    for path, data in bodies.items():
        audit.safe_path(path)
        dest = OUT / 'bodies' / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
    (OUT / 'trace.json').write_bytes(raw)
    (OUT / 'initial-index.json').write_bytes(all_bodies['INITIAL_INDEX'])
    report = {
        'case_id': trace['case_id'], 'canonical_trace_equal': True,
        'golden_file': pin(golden_raw), 'golden_canonical_trace': pin(golden_canonical),
        'emitted_trace': pin(raw),
        'golden_file_already_canonical': golden_raw == golden_canonical,
        'emitted_body_count': len(bodies), 'every_body_equal': True,
        'bodies': {p: pin(v) for p, v in bodies.items()},
        'initial_index_equal': True, 'journal_equal': True, 'ledger_equal': True,
        'ledger': ledger, 'state_replay': state_log, 'parse': parse,
        'max_nodes': max(x['nodes'] for x in parse.values()),
        'max_depth': max(x['depth'] for x in parse.values()),
        'status': result['status'], 'selected_id': result['selected_id'],
        'verification': verification, 'unavailable_candidate_arithmetic': False,
        'scope': 'Three static preserved cases; no fitter/worker/AD observations',
    }
    (OUT / 'equality.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['case_id', 'emitted_body_count',
                                           'status', 'max_nodes', 'max_depth']}))


if __name__ == '__main__':
    main()
