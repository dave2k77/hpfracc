"""Byte-identical positive regression, not an expanded case evaluation."""

import hashlib
import json
from pathlib import Path

from test_a2_trace import module

HERE = Path(__file__).resolve().parent


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("ascii")


def test_positive_entire_canonical_trace_and_every_body_are_unchanged():
    raw = (HERE / "baseline-trace.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == (
        "ba9e40f8e9fa66d13dee2439e9087239b52e523128119eb3d0340ad2b00d2a62"
    )
    original = json.loads(raw)
    audit = module()
    trace = audit.make_trace()
    audit.verify_trace(trace)
    assert canonical(trace) == canonical(original)
    old_bodies = {p: canonical(v) for p, v in original["records"].items()}
    old_bodies.update({p: bytes.fromhex(v) for p, v in original["logs"].items()})
    new_bodies = audit.raw_files(trace)
    assert len(old_bodies) == len(new_bodies) == 38
    assert set(old_bodies) == set(new_bodies)
    for name in old_bodies:
        assert new_bodies[name] == old_bodies[name], name
    assert canonical(trace["initial_index"]) == canonical(original["initial_index"])
    output = HERE.parent / "artifacts"
    output.mkdir(exist_ok=True)
    (output / "positive-trace.json").write_bytes(canonical(trace))
    report = {"emitted_bodies_compared": len(old_bodies),
              "canonical_trace_equal": True, "initial_index_equal": True,
              "original_file_sha256": hashlib.sha256(raw).hexdigest(),
              "canonical_trace_sha256": hashlib.sha256(canonical(trace)).hexdigest(),
              "bodies": {p: {"bytes": len(v), "sha256": hashlib.sha256(v).hexdigest()}
                         for p, v in new_bodies.items()}}
    (output / "positive-equality.json").write_text(json.dumps(report, indent=2) + "\n")
