"""Bounded scanning of a pinned task closure, not private identity matching."""

import importlib.util
import json
from pathlib import Path

from provision import meta

BASE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location(
    'preserved_scanner', BASE / 'preserved/author/privacy_security.py')
SCANNER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SCANNER)
MAX_FILE = 100_000_000
MAX_TOTAL = 2_000_000_000
MAX_FILES = 10_000


def scan_inventory(pins, authored):
    assert len(pins) <= MAX_FILES
    total = 0
    findings = []
    for name, pin in pins.items():
        path = BASE / name
        assert path.resolve().is_relative_to(BASE)
        assert meta(path) == pin
        assert pin['bytes'] <= MAX_FILE
        total += pin['bytes']
        assert total <= MAX_TOTAL
        raw = path.read_bytes()
        # This deliverable contains regular files only, no nested archives.
        # Fail closed rather than whole-buffer inflating a large archive.
        assert not raw.startswith((b'\x1f\x8b', b'PK\x03\x04'))
        assert not (len(raw) > 262 and raw[257:262] == b'ustar')
        findings += SCANNER.scan_body(raw, name)
        if any(k in name.lower() for k in ['telegram-receipt', 'delivery-receipt',
                                           'message-receipt']):
            findings.append({'path': name, 'rule': 'messaging-receipt-path'})
    security = [f for name in authored for f in SCANNER.security(BASE / name)]
    positive = SCANNER.scan(BASE, [], [])['positive_control']
    synthetic = json.dumps({'access_token': 'SYNTHETIC_NOT_REAL'}).encode()
    assert SCANNER.scan_body(synthetic, 'in-memory-synthetic-field')
    token = b'A' + b'KIA' + b'Z' * 16
    assert SCANNER.scan_body(token, 'in-memory-synthetic-credential-pattern')

    class SyntheticSource:
        name = 'in-memory-synthetic-static.py'

        def read_bytes(self):
            return b'eval("synthetic")\n'

    assert SCANNER.security(SyntheticSource())
    return {
        'passed': not findings and not security,
        'files_scanned': len(pins), 'bytes_scanned': total,
        'findings': findings, 'security_findings': security,
        'static_sources': authored, 'positive_control': positive,
        'synthetic_structured_field_detected': True,
        'synthetic_credential_pattern_detected': True,
        'synthetic_unsafe_call_detected': True,
        'bounds': {'per_file_bytes': MAX_FILE, 'aggregate_bytes': MAX_TOTAL,
                   'file_count': MAX_FILES, 'recursive_scanner_depth': 8},
        'archives_in_this_closure': 0,
        'limits': ['Explicit owned task closure only; no private-store reads.',
                   'Local paths and hostnames remain; no private identity matching.',
                   'Pattern/field/static scanning is not universal privacy approval.',
                   'Administrative scanner bounds are not numerical protocol caps.',
                   'Original large archives are pinned, not inflated or rescanned.'],
    }
