"""Posthoc defensive controls; these are not claimed as original TDD RED."""

import copy

import a2_trace as audit
import frozen_case
import pytest


def test_canonical_encoding_fixed_vector():
    value = {'z': [True, 1, 1.0, False, 0, 0.0, None], 'é': 'λ', 'a': {}}
    expected = (b'{"a":{},"z":[true,1,1.0,false,0,0.0,null],'
                b'"\\u00e9":"\\u03bb"}')
    assert frozen_case.canonical(value) == expected == audit.canonical(value)


def test_key_order_does_not_change_fixed_authority_identity(monkeypatch):
    def reorder(value):
        if isinstance(value, dict):
            return {k: reorder(v) for k, v in reversed(list(value.items()))}
        if isinstance(value, list):
            return [reorder(v) for v in value]
        return value

    baseline = audit.make_trace()
    changed = reorder(audit.AUTHORITY)
    frozen_case.authenticate(changed)
    monkeypatch.setattr(audit, 'AUTHORITY', changed)
    assert audit.verify_trace(baseline)['unknown_slot_count'] == 9


@pytest.mark.parametrize('field', ['case', 'bundle', 'working_scalars'])
def test_extra_field_rejected(field):
    changed = copy.deepcopy(audit.AUTHORITY)
    changed[field]['extra_unapproved'] = 0
    with pytest.raises(ValueError, match='^frozen authority '):
        frozen_case.authenticate(changed)


@pytest.mark.parametrize('replacement', [float('nan'), float('inf'), -float('inf')])
def test_nonfinite_is_not_coerced(replacement):
    changed = copy.deepcopy(audit.AUTHORITY)
    changed['working_scalars']['float64']['alpha']['nbytes'] = replacement
    with pytest.raises(ValueError, match='Out of range float values'):
        frozen_case.authenticate(changed)
