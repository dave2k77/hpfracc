"""Persist literal copied-input jobs; never launch archived hardcoded recipes."""

import json
import sys
from pathlib import Path

from provision import ROOT, meta, save

BASE = Path(__file__).resolve().parent
PRESERVED = BASE / 'preserved'
PINS = json.loads((PRESERVED / 'copied-inputs.json').read_bytes())
UV = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync', 'python', '-B']


def closure(prefix):
    return {n.removeprefix(prefix): PRESERVED / n
            for n in PINS if n.startswith(prefix)}


def cap_inputs(helper=None):
    result = closure('author/runs/controls-complete/before/')
    if helper is not None:
        result['frozen_case.py'] = helper
    return result


def identity_inputs(helper=None):
    result = cap_inputs(helper)
    result['test_typed_identity.py'] = BASE / 'test_typed_identity.py'
    result['golden-cap.json'] = PRESERVED / 'golden/cap-trace.json'
    for name in ['case-unknown-occurrence-bool', 'case-known-occurrence-bool',
                 'scalar-alpha-nbytes-float']:
        result['counterexamples/' + name + '.json'] = (
            PRESERVED / 'rejected-probe/artifacts' / (name + '-authority.json'))
    return result


def job(name, inputs, selection, kind='pytest', expected_exit=0, expected_count=None):
    run = BASE / 'runs' / name
    before = run / 'before'
    inputs = dict(inputs)
    inputs['run_selected.py'] = BASE / 'run_selected.py'
    args = ['run_selected.py']
    if kind == 'pytest':
        args += ['pytest', '-q', '-p', 'no:cacheprovider',
                 '--basetemp=' + str(run / 'runtime/pytest'),
                 '--junitxml=' + str(run / 'raw.xml')] + selection
    elif kind == 'raw':
        args = selection
    else:
        args += selection
    data = {
        'run': str(run), 'cwd': str(before), 'argv': UV + args,
        'environment': {
            'PYTHONDONTWRITEBYTECODE': '1', 'JAX_PLATFORMS': 'cpu',
            'UV_PROJECT_ENVIRONMENT': str(ROOT / '.venv'),
            'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1', 'TMPDIR': str(run / 'runtime'),
        },
        'selection': selection, 'expected_exit': expected_exit,
        'expected_count': expected_count,
        'scope': 'Static author self-verification; not independent review',
        'inputs': {n: {'path': str(p), 'pin': meta(p)}
                   for n, p in sorted(inputs.items())},
        'capture_entrypoint': {'path': str(BASE / 'capture.py'),
                               'pin': meta(BASE / 'capture.py')},
        'environment_inputs': {str(ROOT / n): meta(ROOT / n)
                               for n in ['pyproject.toml', 'uv.lock']},
    }
    save(BASE / 'jobs' / (name + '.json'), data)
    print(name)


def prepare(phase):
    helper = BASE / 'candidate/frozen_case.py' if phase != 'red' else None
    if phase in ['red', 'green']:
        job(phase, identity_inputs(helper), ['test_typed_identity.py'],
            expected_exit=1 if phase == 'red' else 0, expected_count=27)
        probe = closure('rejected-probe/before/')
        if helper is not None:
            probe['frozen_case.py'] = helper
        job('original-probe-' + phase, probe, ['type_probe.py'], kind='script',
            expected_exit=2 if phase == 'red' else 0)
    elif phase == 'regression':
        for name, count in [('regression-final-positive', 27),
                            ('regression-final-negative', 32),
                            ('controls-complete', 66),
                            ('negative-equality-final', 1)]:
            recipe = json.loads((PRESERVED / 'author/runs' / name / 'job.json')
                                .read_bytes())
            inputs = closure('author/runs/' + name + '/before/')
            inputs['frozen_case.py'] = helper
            job(name, inputs, recipe['selection'], expected_count=count)
    else:
        raise ValueError(phase)


if __name__ == '__main__':
    prepare(sys.argv[1])
