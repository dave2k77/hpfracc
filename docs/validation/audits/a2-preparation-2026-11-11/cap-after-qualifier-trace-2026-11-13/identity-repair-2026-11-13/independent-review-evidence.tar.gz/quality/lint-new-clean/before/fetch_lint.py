"""Read only indexed regular lint members, never execute archived scripts."""

import hashlib
import json
import tarfile
from pathlib import Path

from plan_jobs import UV
from provision import CASE, meta, save

BASE = Path(__file__).resolve().parent
archive = CASE / 'author-evidence.tar.gz'
assert meta(archive)['sha256'] == (
    '0d43fc05ffae9ca1c40d466fbb7d89505ea78ccea629c03698f83537aa09c060')
index = json.loads((BASE / 'preserved/author-index.json').read_bytes())['files']
prefixes = ['runs/lint-candidate-final/before/',
            'runs/lint-inherited-capture/before/']
targets = {n: p for n, p in index.items() if any(n.startswith(k) for k in prefixes)}
for name in ['runs/lint-candidate-final/job.json',
             'runs/lint-inherited-capture/job.json']:
    targets[name] = index[name]
save(BASE / 'lint-fetch-plan.json', {
    'argv': UV + [str(Path(__file__))], 'cwd': str(BASE.parent),
    'archive': meta(archive), 'targets': targets,
    'bounds': {'per_regular_member': 1_000_000, 'aggregate_selected': 2_000_000},
})
seen = set()
total = 0
with tarfile.open(archive, mode='r|gz') as stream:
    for member in stream:
        if member.name not in targets:
            continue
        assert member.isfile() and member.name not in seen
        assert member.size <= 1_000_000
        total += member.size
        assert total <= 2_000_000
        raw = stream.extractfile(member).read()
        pin = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        assert pin == targets[member.name]
        dest = BASE / 'lint-preserved' / member.name
        dest.parent.mkdir(parents=True, exist_ok=True)
        assert not dest.exists()
        dest.write_bytes(raw)
        seen.add(member.name)
assert seen == set(targets)
save(BASE / 'lint-fetch-result.json', {'files': targets, 'count': len(targets),
                                     'bytes': total, 'verified': True})
print(json.dumps({'copied_lint_members': len(targets), 'verified': True}))
