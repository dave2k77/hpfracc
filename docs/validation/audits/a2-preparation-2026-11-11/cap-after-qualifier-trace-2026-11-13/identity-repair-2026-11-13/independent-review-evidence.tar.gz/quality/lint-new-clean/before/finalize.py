"""Finalize only the owned correction proof; no independent approval or delivery."""

import difflib
import json
from pathlib import Path

from provision import meta, protection, save
from scan_proof import scan_inventory
from verify_runs import RUN_NAMES, verify_all

BASE = Path(__file__).resolve().parent
AUTHORED = [
    'provision.py', 'test_typed_identity.py', 'run_selected.py', 'plan_jobs.py',
    'artifact_proof.py', 'test_defensive_identity.py', 'plan_proofs.py',
    'env_probe.py', 'scan_proof.py', 'verify_runs.py', 'finalize.py', 'plan_quality.py',
    'fetch_lint.py', 'plan_final.py', 'candidate/frozen_case.py',
]
TOP = AUTHORED[:-1] + [
    'capture.py', 'initialization.json', 'red-inspection.json', 'source.diff',
    'source-delta.json', 'artifact-attempt-disposition.json',
    'verification.json', 'privacy-inputs.json', 'privacy-report.json', 'result.json',
    'finalization-plan.json', 'source-final.diff', 'source-final.json',
    'lint-fetch-plan.json', 'lint-fetch-result.json', 'quality-attempts.json',
]
LIMITS = [
    'Self-verification only; fresh independent review remains required and pending.',
    'One owner-approved predicate repair; no automatic repair after failed re-review.',
    'Only three static local cases; no general arbitrary-authority service '
    'or OS attestation.',
    'No new numerical worker, fitter, AD, FIT-REAL observation, '
    'protocol freeze or A2 closure.',
    'Candidate 1 unknown calculations and observations remain absent.',
    '106 unchanged archived checker/test lint findings '
    'and inherited earlier capture E501 remain.',
    'Main repository lint/full numerical suites were not run; '
    'repository was not edited.',
    'Privacy is bounded explicit-closure pattern/field/static scanning, '
    'not universal clearance.',
    'Raw local paths/hostnames remain; no private identity matching '
    'or messaging-store reads.',
    'Positive golden file is pretty JSON; equality is complete canonical bytes '
    'and every body.',
    'One preserved proof-helper formatting-assumption failure and one read-only XML '
    'diagnostic assertion failure are disclosed; no failed attempt was removed.',
    'No commit, push, release, phase closure or independent approval is claimed.',
]


def inventory():
    expected = {n for n in TOP if (BASE / n).is_file()}
    pins = json.loads((BASE / 'preserved/copied-inputs.json').read_bytes())
    expected.update('preserved/' + n for n in pins)
    expected.update('preserved/' + n for n in ['baseline-inputs.json',
                    'authorization.json', 'preflight.json', 'copied-inputs.json'])
    expected.update(['candidate/frozen_case.py', 'candidate/a2_trace.py'])
    lint_inputs = json.loads((BASE / 'lint-fetch-result.json').read_bytes())['files']
    expected.update('lint-preserved/' + n for n in lint_inputs)
    for name in ['case', 'bundle', 'scalar']:
        expected.update('mutants/' + name + '/' + n for n in [
            'frozen_case.py', 'plan.json', 'mutation.diff'])
        expected.update('mutants-final/' + name + '/' + n for n in [
            'frozen_case.py', 'plan.json', 'mutation.diff'])
    for phase in ['before', 'after']:
        directory = BASE / ('protection-' + phase)
        if directory.exists():
            expected.update(str(p.relative_to(BASE)) for p in directory.iterdir()
                            if p.is_file())
    for name in RUN_NAMES:
        expected.add('jobs/' + name + '.json')
        run = BASE / 'runs' / name
        job = json.loads((run / 'job.json').read_bytes())
        expected.update('runs/' + name + '/before/' + n for n in job['inputs'])
        for output in ['entrypoint.py', 'job.json', 'started.json', 'result.json',
                       'stdout.bin', 'stderr.bin', 'raw.xml']:
            if (run / output).exists():
                expected.add('runs/' + name + '/' + output)
        # Explicit per-job output roots, never ambient user scratch or private stores.
        for output in ['artifacts', 'runtime']:
            expected.update(str(p.relative_to(BASE)) for p in (run / output).rglob('*')
                            if p.is_file())
    actual = {str(p.relative_to(BASE)) for p in BASE.rglob('*') if p.is_file()}
    actual.discard('evidence-index.json')
    assert actual == expected, {'unlisted': sorted(actual - expected),
                                'missing': sorted(expected - actual)}
    return {n: meta(BASE / n) for n in sorted(expected)}


def main():
    plan = json.loads((BASE / 'finalization-plan.json').read_bytes())
    for name, pin in plan['inputs'].items():
        assert meta(BASE / name) == pin
    verification = verify_all()
    save(BASE / 'verification.json', verification)
    old_path = BASE / 'preserved/author/candidate/frozen_case.py'
    new_path = BASE / 'candidate/frozen_case.py'
    old, new = old_path.read_text(), new_path.read_text()
    delta = ''.join(difflib.unified_diff(
        old.splitlines(True), new.splitlines(True),
        fromfile='original/frozen_case.py', tofile='candidate/frozen_case.py'))
    assert delta == (BASE / 'source-final.diff').read_text()
    assert meta(BASE / 'candidate/a2_trace.py') == meta(
        BASE / 'preserved/author/candidate/a2_trace.py')
    assert meta(new_path) == json.loads((BASE / 'source-final.json').read_bytes())[
        'candidate']
    protection('after')
    scan_pins = inventory()
    save(BASE / 'privacy-inputs.json', {
        'files': scan_pins, 'file_count': len(scan_pins)})
    privacy = scan_inventory(scan_pins, AUTHORED)
    assert privacy['passed']
    save(BASE / 'privacy-report.json', privacy)
    result = {
        'passed': True, 'self_verification': 'passed', 'blockers': [],
        'finding_id': 'CAP-AUTH-TYPE-01', 'tracker_id': 'VAL-017',
        'independent_approval': False, 'fresh_independent_review': 'pending',
        'source_repair_cycle': 1, 'repository_edits': False,
        'source_delta': delta, 'source_pins': {
            'original_frozen_case': meta(old_path),
            'corrected_frozen_case': meta(new_path),
            'unchanged_a2_trace': meta(BASE / 'candidate/a2_trace.py')},
        'outcomes': {'tdd': verification['tdd'],
                     'regression_count': verification['regression_count'],
                     'regression_counts': [27, 32, 66, 1],
                     'original_probe_exits': {'before': 2, 'after': 0},
                     'posthoc_defensive_passes': 8,
                     'isolated_mutation_failures': {
                         'case': 6, 'bundle': 9, 'scalar': 9},
                     'full_original_reversion_failures': 27,
                     'mutation_survivors': [], 'inconclusive_mutants': [],
                     'all_three_canonical_artifacts_equal': True,
                     'body_counts': {'REF-PASS': 38, 'REF-FAIL': 27, 'CAP': 28}},
        'lint': verification['lint'], 'privacy': privacy,
        'protection': {'before': 'protection-before/result.json',
                       'after': 'protection-after/result.json',
                       'immutable_files_verified_each_time': 930,
                       'copied_inputs_verified_each_time': 87,
                       'git_stage_encoding': 'git ls-files --stage -z raw bytes'},
        'evidence': {'raw_runs': 'runs/', 'verification': 'verification.json',
                     'source_diff': 'source-final.diff', 'jobs': 'jobs/',
                     'preserved_failed_verdict': 'preserved/rejected-verdict.json',
                     'privacy_inputs': 'privacy-inputs.json'},
        'limitations': LIMITS,
    }
    save(BASE / 'result.json', result)
    pins = inventory()
    # Scan final metadata too, and bind it in the final exhaustive index.
    tail = {n: p for n, p in pins.items() if n not in scan_pins}
    tail_scan = scan_inventory(tail, [])
    assert tail_scan['passed']
    index = {'file_count': len(pins), 'files': [dict(path=n, **p)
                                               for n, p in pins.items()],
             'excluded': ['evidence-index.json'],
             'scope': 'Exhaustive regular files in the owned correction proof'}
    save(BASE / 'evidence-index.json', index)
    for entry in index['files']:
        assert meta(BASE / entry['path']) == {k: entry[k] for k in ['bytes', 'sha256']}
    assert scan_inventory({'evidence-index.json': meta(BASE / 'evidence-index.json')},
                          [])['passed']
    print(json.dumps({'passed': True, 'file_count': len(pins),
                      'index': meta(BASE / 'evidence-index.json'),
                      'final_metadata_privacy_passed': True,
                      'result': str(BASE / 'result.json')}))


if __name__ == '__main__':
    main()
