"""Posthoc defensive controls, not new TDD or observed worker results."""

import copy
import json
from pathlib import Path

import pytest

from test_a2_nonqualifier import module


@pytest.fixture
def audit():
    return module()


def preserve(trace, name):
    directory = Path(__file__).resolve().parent.parent / "artifacts" / "controls"
    directory.mkdir(parents=True, exist_ok=True)
    (directory / (name + ".json")).write_text(json.dumps(trace, indent=2) + "\n")


def resigned(audit, trace):
    """Assert digest/link preconditions without asserting false semantics."""
    records = trace["records"]
    files = audit.raw_files(trace)
    manifest = records["run-manifest.json"]["files"]
    assert {x["path"]: (x["bytes"], x["sha256"]) for x in manifest} == {
        p: (len(v), audit.digest(v))
        for p, v in files.items()
        if p != "run-manifest.json"
    }
    for value in records.values():
        audit.schema_check(value, audit.SCHEMA)
        if value["record_type"] == "producer_binding":
            for returned in value["returned"]:
                slot = records["arrays/" + returned["slot_id"] + ".json"]
                assert slot["producer_binding_sha256"] == audit.digest(
                    audit.canonical(value)
                )
    index = records["failure-index.json"]
    for row in index["slots"]:
        raw = audit.canonical(records["arrays/" + row["slot_id"] + ".json"])
        assert row["artifact"]["sha256"] == audit.digest(raw)
        assert row["artifact"]["bytes"] == len(raw)
    export = records["records/export.json"]
    assert export["failure_index_sha256"] == audit.digest(audit.canonical(index))
    assert export["process_sha256"] == audit.digest(
        audit.canonical(records["records/process.json"])
    )
    assert trace["ledger"] == audit.replay_ledger(trace)


@pytest.mark.parametrize(
    "fault",
    [
        "unknown",
        "missing-assessment",
        "forged-qualifies",
        "forged-assessment-status",
        "forged-result-status",
        "forged-selected-id",
        "exit-unconfirmed",
        "exit-nonzero",
    ],
)
def test_completion_refusals(audit, fault):
    def mutate(records):
        result = records["result.json"]
        assessment = result["assessments"][0]
        if fault == "unknown":
            assessment.update(status="unknown", qualifies=None)
        elif fault == "missing-assessment":
            result["assessments"] = []
        elif fault == "forged-qualifies":
            assessment["qualifies"] = True
        elif fault == "forged-assessment-status":
            assessment["status"] = "known_qualifying"
        elif fault == "forged-result-status":
            result["status"] = "selected"
        elif fault == "forged-selected-id":
            result["selected_id"] = "bad1-f64-GL"
        elif fault == "exit-unconfirmed":
            records["records/process.json"].update(exit_confirmed=False, exit_code=None)
        else:
            records["records/process.json"]["exit_code"] = 1

    trace = audit.make_trace(mutate)
    assert trace["records"] != audit.make_trace()["records"]
    resigned(audit, trace)
    preserve(trace, fault)
    with pytest.raises(ValueError, match="selection|completion"):
        audit.verify_trace(trace)


@pytest.mark.parametrize(
    "fault",
    [
        "index-inventory",
        "preinventory",
        "descriptor-shape",
        "slot-shape",
        "mode",
        "alpha",
    ],
)
def test_inventory_and_binding_refusals(audit, fault):
    def mutate(records):
        binding = records["records/binding-host-0.json"]
        if fault == "index-inventory":
            records["failure-index.json"]["slots"].pop()
        elif fault == "preinventory":
            records["input-bundle.json"]["required_slots"].pop()
            input_hash = audit.digest(audit.canonical(records["input-bundle.json"]))
            for record in records.values():
                if "input_bundle_sha256" in record:
                    record["input_bundle_sha256"] = input_hash
        elif fault == "descriptor-shape":
            binding["returned"][0]["descriptor"]["shape"] = [1, 3]
        elif fault == "slot-shape":
            records["arrays/S-0-g_hat.json"]["exact_array"]["shape"] = [1, 3]
        elif fault == "mode":
            binding["mode"] = "jit"
            binding["producer"]["mode"] = "jit"
        else:
            binding["alpha"] = copy.deepcopy(binding["dt"])

    trace = audit.make_trace(mutate)
    assert trace["records"] != audit.make_trace()["records"]
    resigned(audit, trace)
    preserve(trace, fault)
    with pytest.raises(ValueError, match="binding"):
        audit.verify_trace(trace)


@pytest.mark.parametrize("suffix", ["X", "0"])
@pytest.mark.parametrize("kind", ["fresh", "colliding"])
def test_binding_route(audit, suffix, kind):
    replacement = (
        "host-fresh" if kind == "fresh" else "host-" + ("X" if suffix == "0" else "0")
    )
    path = "records/binding-host-" + suffix + ".json"

    def mutate(records):
        records[path]["binding_id"] = replacement

    trace = audit.make_trace(mutate)
    assert trace["records"][path]["binding_id"] == replacement
    assert path != "records/binding-" + replacement + ".json"
    resigned(audit, trace)
    audit.check_completion(trace["records"])
    audit.check_fixed_exact_payloads(trace["records"])
    audit.check_lifecycle(trace)
    preserve(trace, "route-" + suffix + "-" + kind)
    with pytest.raises(ValueError, match="binding path-to-ID"):
        audit.verify_trace(trace)


@pytest.mark.parametrize(
    "sid", ["S-X-D", "S-0-D_hat", "S-0-analytic_input_gradient", "S-0-B"]
)
def test_false_exact_payload_with_rebuilt_descriptor(audit, sid):
    def mutate(records):
        payload = records["arrays/" + sid + ".json"]["exact_array"]
        payload["values"][1] = {"num": "1", "den": "2"}
        for binding in records.values():
            if binding["record_type"] == "producer_binding":
                for item in binding["returned"]:
                    if item["slot_id"] == sid:
                        item["descriptor"]["payload_sha256"] = audit.digest(
                            audit.canonical(payload)
                        )

    trace = audit.make_trace(mutate)
    assert (
        trace["records"]["arrays/" + sid + ".json"]
        != audit.make_trace()["records"]["arrays/" + sid + ".json"]
    )
    resigned(audit, trace)
    audit.check_completion(trace["records"])
    audit.check_links(trace)
    preserve(trace, "false-exact-" + sid)
    with pytest.raises(ValueError, match="exact identity"):
        audit.verify_trace(trace)


def test_all_false_qualification_fields_cannot_redefine_bound(audit):
    def mutate(records):
        payload = records["arrays/S-0-B.json"]["exact_array"]
        payload["values"] = [{"num": "0", "den": "1"}] * 3
        binding = records["records/binding-host-0.json"]
        for item in binding["returned"]:
            if item["slot_id"] == "S-0-B":
                item["descriptor"]["payload_sha256"] = audit.digest(
                    audit.canonical(payload)
                )
        result = records["result.json"]
        result.update(status="selected", selected_id="bad1-f64-GL")
        result["assessments"][0].update(status="known_qualifying", qualifies=True)

    trace = audit.make_trace(mutate)
    resigned(audit, trace)
    audit.check_links(trace)
    audit.check_completion(trace["records"])
    preserve(trace, "false-qualifying-bound")
    with pytest.raises(ValueError, match="exact identity S-0-B"):
        audit.verify_trace(trace)


@pytest.mark.parametrize("fault", ["phase", "publication"])
def test_lifecycle_refusals(audit, fault):
    def mutate(records):
        if fault == "phase":
            records["records/process.json"]["phases"]["watchdog"]["elapsed_ns"] = 99

    trace = audit.make_trace(mutate)
    if fault == "publication":
        events = trace["events"]
        a = next(
            i for i, e in enumerate(events) if e.get("body") == "arrays/S-0-g_hat.json"
        )
        b = next(
            i
            for i, e in enumerate(events)
            if e.get("body") == "records/binding-host-0.json"
        )
        events[a], events[b] = events[b], events[a]
    resigned(audit, trace)
    audit.check_links(trace)
    audit.check_completion(trace["records"])
    preserve(trace, fault)
    with pytest.raises(ValueError, match="phase|publication order"):
        audit.verify_trace(trace)


@pytest.mark.parametrize(
    "component",
    [
        "logs/stdout.bin",
        "run-manifest.json",
        "INITIAL_INDEX",
        "failure-index.json",
    ],
)
def test_missing_actual_charge_recomputed_totals(audit, component):
    trace = audit.make_trace()
    ledger = trace["ledger"]
    assert ledger["terms"][component] > 0
    ledger["terms"][component] = 0
    terms = ledger["terms"]
    ledger["cumulative_written_bytes"] = sum(terms.values())
    ledger["final_live_bytes"] = sum(
        v for k, v in terms.items() if k != "INITIAL_INDEX"
    )
    ledger["peak_live_bytes"] = max(
        ledger["final_live_bytes"],
        ledger["final_live_bytes"]
        + terms["INITIAL_INDEX"]
        - terms["records/export.json"]
        - terms["run-manifest.json"],
    )
    ledger["index_transaction_bytes"] = sum(
        terms[p]
        for p in [
            "INITIAL_INDEX",
            "failure-index.json",
            "records/process.json",
            "records/export.json",
            "records/output-control.json",
        ]
    )
    ledger["old_index_bytes_charged"] = terms["INITIAL_INDEX"]
    ledger["temporary_bytes_charged"] = terms["failure-index.json"]
    audit.check_links(trace)
    audit.check_completion(trace["records"])
    audit.check_fixed_exact_payloads(trace["records"])
    audit.check_lifecycle(trace)
    preserve(trace, "missing-charge-" + component.replace("/", "-"))
    with pytest.raises(ValueError, match="ledger claim"):
        audit.verify_trace(trace)
