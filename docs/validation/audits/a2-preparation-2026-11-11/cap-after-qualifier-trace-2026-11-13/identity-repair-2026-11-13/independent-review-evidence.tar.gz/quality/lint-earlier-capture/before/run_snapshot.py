"""Capture explicitly copied audit inputs, command plan, streams and real exit."""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


def metadata(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    job_path, run = map(Path, sys.argv[1:])
    job = json.loads(job_path.read_bytes())
    run.mkdir(parents=True, exist_ok=False)
    before = run / "before"
    before.mkdir()
    inputs = dict(job["inputs"])
    inputs["capture-helper.py"] = str(Path(__file__).resolve())
    inputs["capture-job.json"] = str(job_path.resolve())
    for name, source in inputs.items():
        target = before / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    hashes = {name: metadata(before / name) for name in inputs}
    command = [x.replace("{before}", str(before)).replace("{run}", str(run))
               for x in job["command"]]
    environment = {
        "PYTHONDONTWRITEBYTECODE": "1",
        "JAX_PLATFORMS": "cpu",
        "UV_PROJECT_ENVIRONMENT": job["project"] + "/.venv",
        "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
        "TMPDIR": str(run / "runtime"),
    }
    (run / "runtime").mkdir()
    save(run / "plan.json", {
        "label": job["label"], "scope": job["scope"],
        "command": command, "cwd": str(before), "environment": environment,
        "inputs": hashes, "snapshot_role": "before-run evidence, not final source",
        "pytest_config": "byte-identical copied pyproject.toml; explicit test selection",
    })
    with (run / "stdout.bin").open("wb") as stdout:
        with (run / "stderr.bin").open("wb") as stderr:
            child = subprocess.run(
                command, cwd=before, env=os.environ | environment,
                stdout=stdout, stderr=stderr, check=False, timeout=180,
            )
    after = {name: metadata(before / name) for name in inputs}
    result = {
        "actual_exit": child.returncode, "source_hashes_unchanged": hashes == after,
        "inputs_after": after, "stdout": metadata(run / "stdout.bin"),
        "stderr": metadata(run / "stderr.bin"),
    }
    xml = run / "raw.xml"
    if xml.exists():
        root = ET.parse(xml).getroot()
        cases = root.findall(".//testcase")
        result["junit"] = {
            "file": metadata(xml), "collected": len(cases),
            "failures": sum(c.find("failure") is not None for c in cases),
            "errors": sum(c.find("error") is not None for c in cases),
            "skipped": sum(c.find("skipped") is not None for c in cases),
            "identities": [c.attrib for c in cases],
        }
    save(run / "result.json", result)
    print(json.dumps({"run": str(run), "result": result}, sort_keys=True))
    assert hashes == after, "copied inputs changed during run"


if __name__ == "__main__":
    main()
