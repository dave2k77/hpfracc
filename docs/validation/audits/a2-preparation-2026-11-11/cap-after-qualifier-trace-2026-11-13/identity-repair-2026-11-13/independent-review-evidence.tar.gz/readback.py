"""Independently check archive bodies, raw receipts, mutations and protected pins."""
import collections
import difflib
import hashlib
import shutil
import tarfile
import xml.etree.ElementTree as ET

from review_common import AUTHOR, BASE, CASE, CHECKER, INPUT, NEW, OLD, ROOT, WORK
from review_common import digest, pin, protection, read, safe, save


def archive_check(path, expected, file_map, index_pin=None):
    assert pin(path) == expected
    found = {}
    with tarfile.open(path, 'r|gz') as tar:
        for member in tar:
            safe(member.name)
            assert member.isfile() and member.name not in found
            assert member.size < 600_000_000
            h = hashlib.sha256()
            n = 0
            with tar.extractfile(member) as stream:
                while data := stream.read(1024 * 1024):
                    h.update(data)
                    n += len(data)
            actual = {'bytes': n, 'sha256': h.hexdigest()}
            assert n == member.size
            target = index_pin if member.name == 'evidence-index.json' else file_map[member.name]
            assert actual == target, (path.name, member.name)
            found[member.name] = actual
    expected_names = set(file_map) | ({'evidence-index.json'} if index_pin else set())
    assert set(found) == expected_names
    return found


def xml_cases(path):
    root = ET.parse(path).getroot()
    cases = root.findall('.//testcase')
    suites = root.findall('.//testsuite')
    assert sum(int(s.attrib['tests']) for s in suites) == len(cases)
    for kind in ['failure', 'error', 'skipped']:
        field = {'failure': 'failures', 'error': 'errors', 'skipped': 'skipped'}[kind]
        assert sum(int(s.attrib.get(field, 0)) for s in suites) == sum(
            c.find(kind) is not None for c in cases)
    assert len({(c.attrib['classname'], c.attrib['name']) for c in cases}) == len(cases)
    return cases


def run_check(name):
    r = AUTHOR / 'runs' / name
    job = read(r / 'job.json')
    res = read(r / 'result.json')
    assert (r / 'job.json').read_bytes() == (AUTHOR / 'jobs' / (name + '.json')).read_bytes()
    assert job['run'] == str(r) and job['cwd'] == str(r / 'before')
    assert read(r / 'started.json')['child_started'] is True
    assert res['timed_out'] is False and res['source_hashes_unchanged'] is True
    assert job['argv'][:8] == ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync', 'python', '-B']
    for n, spec in job['inputs'].items():
        assert pin(r / 'before' / safe(n)) == spec['pin'] == res['inputs_after'][n]
    for n in ['stdout', 'stderr']:
        assert pin(r / (n + '.bin')) == res[n]
    assert pin(r / 'entrypoint.py') == job['capture_entrypoint']['pin']
    for n, spec in job['environment_inputs'].items():
        assert n in [str(ROOT / 'pyproject.toml'), str(ROOT / 'uv.lock')]
        assert pin(ROOT / n) == spec
    expected = {'artifact-positive': 1, 'lint-new': 1, 'lint-new-final': 1,
                'lint-capture': 0}.get(name, job['expected_exit'])
    assert res['actual_child_exit'] == expected
    result = {'exit': res['actual_child_exit'], 'input_count': len(job['inputs']),
              'selection': job['selection'], 'job': pin(r / 'job.json')}
    if (r / 'artifacts/imports.json').exists():
        imports = read(r / 'artifacts/imports.json')
        for mod in ['a2_trace', 'frozen_case']:
            src = r / 'before' / (mod + '.py')
            assert imports[mod] == {'path': str(src), **pin(src)}
        assert imports['a2_trace']['sha256'] == CHECKER
        result['imports'] = imports
    if job['expected_count'] is not None:
        cases = xml_cases(r / 'raw.xml')
        assert pin(r / 'raw.xml') == res['junit']['raw']
        assert [c.attrib for c in cases] == res['junit']['identities']
        assert len(cases) == job['expected_count'] == res['junit']['collected']
        assert not any(c.find('error') is not None or c.find('skipped') is not None for c in cases)
        messages = collections.Counter(c.find('failure').attrib['message']
                                       for c in cases if c.find('failure') is not None)
        assert sum(messages.values()) == res['junit']['failures']
        result.update(count=len(cases), failures=dict(messages),
                      identities=[{k: c.attrib[k] for k in ['classname', 'name']} for c in cases])
        if expected == 0:
            assert not messages
    return result


def main():
    print('PROTECTION', protection('before'))
    inputs = BASE / 'inputs'
    inputs.mkdir()
    for n in ['authorization.json', 'README.md', 'baseline-inputs.json', 'correction-result.json',
              'correction-preservation.json', 'parent-replay.json', 'review-inputs.json',
              'pre-review-qa.json', 'pre-review-privacy.json']:
        shutil.copyfile(WORK / n, inputs / n)
    shutil.copyfile(CASE / 'independent-review-verdict.json', inputs / 'historical-failed-verdict.json')
    assert read(inputs / 'historical-failed-verdict.json')['passed'] is False
    idx = read(AUTHOR / 'evidence-index.json')
    assert isinstance(idx['files'], list)
    assert len(idx['files']) == idx['file_count'] == 1632
    assert len({x['path'] for x in idx['files']}) == 1632
    mapping = {safe(x['path']): {k: x[k] for k in ['bytes', 'sha256']} for x in idx['files']}
    for n, expected in mapping.items():
        assert pin(AUTHOR / n) == expected, n
    assert pin(AUTHOR / 'evidence-index.json')['sha256'] == '92dfd7a40eadea971066d52c9565cd366f6afa555979073e9d788b083d09283f'
    review = read(WORK / 'review-inputs.json')
    archive = WORK / 'correction-evidence.tar.gz'
    members = archive_check(archive, review['files'][str(archive.relative_to(ROOT))],
                            mapping, pin(AUTHOR / 'evidence-index.json'))
    assert len(members) == 1633
    save(BASE / 'archive-readback.json', {'archive': pin(archive), 'indexed_files': 1632,
         'member_count': len(members), 'members': members, 'all_live_indexed_bodies_equal': True})
    shutil.copyfile(archive, inputs / archive.name)
    shutil.copyfile(AUTHOR / 'evidence-index.json', inputs / 'correction-index.json')
    parent = read(WORK / 'parent-replay.json')
    found = archive_check(WORK / parent['archive'], {'bytes': parent['bytes'], 'sha256': parent['sha256']}, parent['files'])
    assert len(found) == parent['members_verified'] == 193
    save(BASE / 'parent-archive-readback.json', {'members': found, 'count': len(found)})
    names = sorted({n.split('/')[1] for n in mapping if n.startswith('runs/')})
    runs = {n: run_check(n) for n in names}
    assert len(runs) == 42
    dnr = "Failed: DID NOT RAISE <class 'ValueError'>"
    typ = 'TypeError: list indices must be integers or slices, not float'
    for n in ['red', 'mutant-full-original']:
        assert runs[n]['failures'] == {dnr: 26, typ: 1}
        cases = xml_cases(AUTHOR / 'runs' / n / 'raw.xml')
        orig = [c for c in cases if c.attrib['name'].startswith('test_preserved_alias')]
        assert len(orig) == 9 and all(c.find('failure').attrib['message'] == dnr for c in orig)
        assert runs[n]['imports']['frozen_case']['sha256'] == OLD
    assert (AUTHOR / 'runs/red/before/test_typed_identity.py').read_bytes() == (
        AUTHOR / 'runs/green-final/before/test_typed_identity.py').read_bytes()
    assert read(AUTHOR / 'red-inspection.json')['source_edit_started'] is False
    regressions = ['regression-final-positive', 'regression-final-negative', 'controls-complete', 'negative-equality-final']
    comparisons = []
    for name in regressions:
        final = AUTHOR / 'runs' / (name + '-final')
        original = INPUT / 'author/runs' / name / 'before'
        source_job = read(AUTHOR / 'preserved/author/runs' / name / 'job.json')
        assert read(final / 'job.json')['selection'] == source_job['selection']
        for n in source_job['inputs']:
            if n == 'frozen_case.py':
                continue
            assert pin(original / n) == pin(final / 'before' / n)
            comparisons.append({'run': name, 'path': n, **pin(original / n)})
        assert runs[name + '-final']['imports']['frozen_case']['sha256'] == NEW
    assert len(comparisons) == 40
    assert sum(runs[n + '-final']['count'] for n in regressions) == 126
    assert runs['green-final']['count'] == 27 and runs['posthoc-defensive-final']['count'] == 8
    original = (AUTHOR / 'preserved/author/candidate/frozen_case.py').read_text()
    corrected = (AUTHOR / 'candidate/frozen_case.py').read_text()
    delta = ''.join(difflib.unified_diff(original.splitlines(True), corrected.splitlines(True),
                  fromfile='original/frozen_case.py', tofile='candidate/frozen_case.py'))
    assert delta == (AUTHOR / 'source-final.diff').read_text() == read(WORK / 'correction-result.json')['source_delta']
    assert digest(original.encode()) == OLD and digest(corrected.encode()) == NEW
    assert pin(AUTHOR / 'candidate/a2_trace.py')['sha256'] == CHECKER
    (BASE / 'reviewed-source.diff').write_text(delta)
    mutant_checks = {}
    for name, count in [('case', 6), ('bundle', 9), ('scalar', 9)]:
        p = AUTHOR / 'mutants-final' / name
        plan = read(p / 'plan.json')
        assert corrected.count(plan['old_string']) == plan['exact_replacement_count'] == 1
        mutant = corrected.replace(plan['old_string'], plan['new_string'])
        assert mutant == (p / 'frozen_case.py').read_text()
        assert pin(p / 'frozen_case.py') == plan['mutant']
        assert pin(AUTHOR / 'runs' / ('mutant-' + name + '-final') / 'before/frozen_case.py') == plan['mutant']
        assert runs['mutant-' + name + '-final']['failures'] == {dnr: count}
        mutant_checks[name] = {'count': count, 'delta': (p / 'mutation.diff').read_text(),
                              'source': plan['mutant']}
    lint = {}
    for kind in ['original', 'final']:
        run = AUTHOR / 'runs' / ('lint-historical-' + kind)
        diagnostics = read(run / 'stdout.bin')
        ctx = []
        for d in diagnostics:
            path = run / 'before' / __import__('pathlib').Path(d['filename']).name
            lines = path.read_text().splitlines()
            ctx.append((path.name, d['code'], d['message'], '\n'.join(
                lines[d['location']['row'] - 1:d['end_location']['row']])))
        lint[kind] = collections.Counter(ctx)
        assert len(diagnostics) == 106
    assert lint['original'] == lint['final']
    assert read(AUTHOR / 'runs/lint-new-clean/stdout.bin') == []
    capture = read(AUTHOR / 'runs/lint-earlier-capture/stdout.bin')
    assert len(capture) == 1 and capture[0]['code'] == 'E501'
    save(BASE / 'raw-run-readback.json', {'raw_runs': runs, 'count': len(runs),
         'original_input_occurrences': comparisons, 'mutant_checks': mutant_checks,
         'tdd': {'red_old_helper': OLD, 'green_final_helper': NEW, 'same_test_pin': pin(AUTHOR / 'test_typed_identity.py'),
                 'nine_original_failures': dnr, 'red_failures': runs['red']['failures'],
                 'temporal_limit': 'Captured old source and contemporaneous pre-edit inspection; not external OS/time attestation'},
         'lint': {'same_context_count': 106, 'new_helper_count': 0, 'earlier_capture_E501': 1}})
    print('READBACK', {'archive_members': len(members), 'raw_runs': len(runs), 'unchanged_original_inputs': len(comparisons), 'regressions': 126})


if __name__ == '__main__':
    main()
