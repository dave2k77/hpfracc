"""Print bounded structural details of explicitly approved inputs."""
from review_common import AUTHOR, WORK, read

a = read(AUTHOR / 'runs/green-final/before/authority.json')
for n in ['case', 'working_scalars']:
    print(n, a[n])
b = a['bundle']
print('BUNDLE', list(b))
print('REQUEST', b['artifacts']['input-bundle.json']['request'])
print('RESULT', {k: v for k, v in b['artifacts']['result.json'].items() if k not in ['shared_slots', 'assessments']})
print('HISTORICAL', [p for p in read(WORK / 'baseline-inputs.json')['files'] if 'cap-after-qualifier' in p and p.endswith('.tar.gz')])
print('PROBE JOB', read(AUTHOR / 'runs/original-probe-green-final/job.json')['selection'])
for n in ['regression-final-positive-final', 'regression-final-negative-final', 'controls-complete-final', 'negative-equality-final-final']:
    print('REGRESSION', n, read(AUTHOR / 'runs' / n / 'job.json')['selection'])
print('EVIDENCE RELATED', [p['path'] for p in read(AUTHOR / 'evidence-index.json')['files'] if p['path'].startswith('preserved/') and p['path'].endswith('json') and '/before/' not in p['path'] and '/artifacts/' not in p['path']])
