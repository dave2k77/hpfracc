"""Fresh copied-layout lint replay, kept separate from live repository QA."""
import collections
import json
import os
import shutil
import subprocess
from pathlib import Path

from review_common import AUTHOR, BASE, ROOT, pin, read, save

UV = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync', 'python', '-B']


def run(name, inputs, args, expected):
    target = BASE / 'quality' / name
    before = target / 'before'
    before.mkdir(parents=True)
    (target / 'runtime').mkdir()
    manifest = {}
    for n, source in inputs.items():
        out = before / n
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, out)
        manifest[n] = {'source': str(source), **pin(out)}
    environment = {'UV_PROJECT_ENVIRONMENT': str(ROOT / '.venv'),
                   'PYTHONDONTWRITEBYTECODE': '1', 'JAX_PLATFORMS': 'cpu',
                   'TMPDIR': str(target / 'runtime')}
    plan = {'argv': UV + args, 'cwd': str(before), 'environment_overrides': environment,
            'inputs': manifest, 'selection': args,
            'capture_entrypoint': pin(BASE / 'quality_capture.py'),
            'environment_inputs': {str(ROOT / n): pin(ROOT / n) for n in ['pyproject.toml', 'uv.lock']}}
    save(target / 'plan.json', plan)
    with (target / 'stdout.bin').open('wb') as out, (target / 'stderr.bin').open('wb') as err:
        child = subprocess.Popen(plan['argv'], cwd=before, env=os.environ | environment, stdout=out, stderr=err)
        save(target / 'started.json', {'pid': child.pid, 'child_started': True})
        code = child.wait(timeout=120)
    after = {n: pin(before / n) for n in inputs}
    assert after == {n: {k: p[k] for k in ['bytes', 'sha256']} for n, p in manifest.items()}
    save(target / 'receipt.json', {'actual_child_exit': code, 'inputs_unchanged': True, 'inputs_after': after,
                                 'stdout': pin(target / 'stdout.bin'), 'stderr': pin(target / 'stderr.bin')})
    assert code == expected
    return target


def main():
    outcomes = {}
    contexts = {}
    for name in ['lint-historical-original', 'lint-historical-final', 'lint-new-clean', 'lint-earlier-capture']:
        source = AUTHOR / 'runs' / name
        job = read(source / 'job.json')
        inputs = {n: source / 'before' / n for n in job['inputs']}
        for n, p in inputs.items():
            assert pin(p) == job['inputs'][n]['pin']
        target = run(name, inputs, job['argv'][8:], 0 if name == 'lint-new-clean' else 1)
        diagnostics = read(target / 'stdout.bin')
        terms = []
        for d in diagnostics:
            path = target / 'before' / Path(d['filename']).name
            assert Path(d['filename']).resolve() == path.resolve()
            context = '\n'.join(path.read_text().splitlines()[d['location']['row'] - 1:d['end_location']['row']])
            terms.append((path.name, d['code'], d['message'], context))
        contexts[name] = collections.Counter(terms)
        outcomes[name] = {'findings': len(diagnostics), 'receipt': pin(target / 'receipt.json')}
    assert contexts['lint-historical-original'] == contexts['lint-historical-final']
    assert sum(contexts['lint-historical-final'].values()) == 106
    assert outcomes['lint-new-clean']['findings'] == 0
    assert outcomes['lint-earlier-capture']['findings'] == 1
    path = run('environment', {'environment_info.py': BASE / 'environment_info.py'}, ['environment_info.py'], 0)
    env = read(path / 'stdout.bin')
    assert env['environment_overrides']['JAX_PLATFORMS'] == 'cpu'
    assert env['environment_overrides']['UV_PROJECT_ENVIRONMENT'] == str(ROOT / '.venv')
    assert env['versions']['ruff'] == json.loads((AUTHOR / 'runs/environment/stdout.bin').read_bytes())['packages']['ruff']
    parent = read(BASE / 'parent-qa-receipts-readback.json')
    plan = read(BASE / 'parent-qa-plan-readback.json')
    assert [r['command'] for r in parent] == plan
    assert [r['actual_exit'] for r in parent] == [0, 0, 0, 0]
    save(BASE / 'quality-summary.json', {'archived_source_lint': outcomes, 'same_rule_message_source_context': True,
         'environment': env, 'parent_live_repository_qa': {'actual_exits': [0, 0, 0, 0], 'docs_tests': 23,
            'status': 'Verified pinned parent raw proof, not rerun by this reviewer'},
         'reviewer_instrumentation': 'Syntax checked at creation; author/helper lint gate is the explicit copied layout'})
    print(json.dumps({'archived_lint_findings': {k: v['findings'] for k, v in outcomes.items()}, 'versions': env['versions']}))


if __name__ == '__main__':
    main()
