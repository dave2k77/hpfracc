"""Record runtime provenance without importing numerical backends."""
import importlib.metadata
import json
import os
import sys

print(json.dumps({
    'python': sys.version,
    'executable': sys.executable,
    'versions': {n: importlib.metadata.version(n) for n in ['pytest', 'ruff', 'jax']},
    'environment_overrides': {n: os.environ.get(n) for n in [
        'UV_PROJECT_ENVIRONMENT', 'PYTHONDONTWRITEBYTECODE', 'JAX_PLATFORMS']},
    'backend_imported': False,
}, indent=2))
