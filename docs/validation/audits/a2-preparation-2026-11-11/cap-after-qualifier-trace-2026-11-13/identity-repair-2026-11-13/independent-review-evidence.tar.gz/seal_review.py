"""Freeze the independent verdict, scan its full closure, then seal an index."""
import json
import shutil
import xml.etree.ElementTree as ET

from privacy import controls, final_paths, leaf, scan, static
from review_common import AUTHOR, BASE, CASE, CHECKER, INPUT, NEW, OLD, ROOT, WORK
from review_common import digest, pin, protection, read, save

LIMITATIONS = [
    'Approval is limited to the predicate-only typed local JSON identity correction and its static proof; it is not scientific certification, whole-packet admission, protocol freeze or phase closure.',
    'REF-PASS and REF-FAIL remain regressions; CAP-after-qualifier-f64-GL remains one hypothetical cooperative checkpoint, not measured cap exhaustion, an OS kill or real RAM/runtime/operation-budget proof.',
    'No new numerical worker, fitter, accelerator or AD execution was performed; nine unavailable candidate quantities remain null and the eight FIT-REAL admission blockers remain open.',
    'Historical source, failed verdict, counterexamples, blocked records and prior failed attempts remain unchanged; historical captured process consistency is not independent OS/time attestation.',
    'Canonical full-trace and emitted-body equality is verified; outer pretty-JSON whitespace is not an artifact-equivalence requirement. Arbitrary reordered publication schedules are not newly admitted.',
    'Archived checker/tests retain 106 unchanged lint diagnostics and the earlier capture helper retains one E501. Corrected helper and author proof-helper lint is clean; independent review instrumentation was syntax-checked rather than subjected to that historical lint gate.',
    'Privacy checks are bounded pattern/structured-field scans of explicit inputs and owned outputs, with synthetic positive controls; local paths/hostnames remain, no private identity matching or universal publication clearance is claimed.',
    'Parent live repository Ruff, 23 documentation tests, strict documentation build and whitespace checks were verified from pinned raw proof, not rerun here. No full numerical suite, install, commit, push, release, task closure or delivery was performed.',
]


def main():
    for name in ['schema-control-contract.md']:
        source = CASE.parent / name
        shutil.copyfile(source, BASE / 'inputs' / name)
    source = ROOT / 'docs/developer/a2-compression-budget-protocol.md'
    shutil.copyfile(source, BASE / 'inputs/a2-compression-budget-protocol.md')
    author_index = read(AUTHOR / 'evidence-index.json')
    assert len(author_index['files']) == author_index['file_count'] == 1632
    for record in author_index['files']:
        assert pin(AUTHOR / record['path']) == {k: record[k] for k in ['bytes', 'sha256']}
    summaries = read(BASE / 'replay-summary.json')
    assert summaries['count'] == len(summaries['runs']) == 17
    new_checks = {}
    for name, summary in summaries['runs'].items():
        run = BASE / 'replays' / name
        plan = read(run / 'plan.json')
        receipt = read(run / 'receipt.json')
        assert pin(run / 'receipt.json') == summary['receipt']
        assert receipt['actual_child_exit'] == plan['expected_exit'] == summary['actual_child_exit']
        assert receipt['inputs_unchanged'] is True
        for n, spec in plan['inputs'].items():
            assert pin(run / 'before' / n) == {k: spec[k] for k in ['bytes', 'sha256']}
        for field in ['stdout', 'stderr']:
            assert pin(run / (field + '.bin')) == receipt[field]
        if 'junit' in receipt:
            assert pin(run / 'raw.xml') == receipt['junit']['raw']
            cases = ET.parse(run / 'raw.xml').getroot().findall('.//testcase')
            assert len(cases) == receipt['junit']['count']
            assert not any(c.find('error') is not None or c.find('skipped') is not None for c in cases)
        new_checks[name] = {'exit': receipt['actual_child_exit'], 'count': summary['count']}
    for name in ['lint-historical-original', 'lint-historical-final', 'lint-new-clean', 'lint-earlier-capture', 'environment']:
        run = BASE / 'quality' / name
        plan = read(run / 'plan.json')
        result = read(run / 'receipt.json')
        for n, spec in plan['inputs'].items():
            assert pin(run / 'before' / n) == {k: spec[k] for k in ['bytes', 'sha256']}
        assert result['actual_child_exit'] == (1 if name in ['lint-historical-original', 'lint-historical-final', 'lint-earlier-capture'] else 0)
        for field in ['stdout', 'stderr']:
            assert pin(run / (field + '.bin')) == result[field]
    protection_result = protection('after')
    privacy_inputs = read(BASE / 'privacy-input-report.json')
    assert not privacy_inputs['findings'] and not privacy_inputs['authored_source_security_findings']
    artifacts = {}
    for name in ['positive', 'nonqualifier', 'cap']:
        r = BASE / 'replays' / ('artifact-' + name)
        report = read(r / 'artifacts/independent-artifact-report.json')
        assert report['every_body_equal'] and report['complete_canonical_trace_equal']
        for p, spec in report['bodies'].items():
            assert pin(r / 'artifacts/bodies' / p) == spec
        assert pin(r / 'artifacts/trace.json') == report['trace']
        artifacts[name] = {'case_id': report['case_id'], 'body_count': report['body_count'],
                           'trace': report['trace'], 'ledger': report['ledger'],
                           'report': pin(r / 'artifacts/independent-artifact-report.json')}
    accepted_test_runs = ['typed-green', 'positive-regressions', 'nonqualifier-regressions', 'cap-regressions',
                          'nonqualifier-equality', 'posthoc-defensive', 'independent-controls']
    verdict = {
        'review_completed': True, 'passed': True, 'security_concerns': [], 'logic_errors': [],
        'finding_id': 'CAP-AUTH-TYPE-01', 'tracker_id': 'VAL-017', 'repair_cycle': 1,
        'review_role': 'Fresh independent re-review, not prior author/reviewer/corrector',
        'scope': 'One owner-approved predicate-only correction; source/test/proof approval only',
        'reviewed_identities': {
            'review_inputs': {'path': str(WORK / 'review-inputs.json'), **pin(WORK / 'review-inputs.json')},
            'correction_archive': {'path': str(WORK / 'correction-evidence.tar.gz'), **pin(WORK / 'correction-evidence.tar.gz')},
            'correction_index': pin(AUTHOR / 'evidence-index.json'),
            'old_helper_sha256': OLD, 'corrected_helper_sha256': NEW, 'unchanged_checker_sha256': CHECKER,
            'baseline_inputs': pin(WORK / 'baseline-inputs.json'),
            'source_delta': pin(BASE / 'reviewed-source.diff'),
        },
        'verified_counts': {
            'protected_baseline_files_before_and_after': 930, 'frozen_review_files_before_and_after': 19,
            'correction_indexed_files': 1632, 'correction_archive_regular_members': 1633,
            'archived_raw_runs': 42, 'unchanged_original_input_occurrences': 40,
            'original_regression_exact_test_identities': 126,
            'fresh_behavioral_runs': len(new_checks), 'fresh_quality_environment_runs': 5,
            'fresh_passing_tests': sum(new_checks[n]['count'] for n in accepted_test_runs),
            'typed_identity_green_tests': 27, 'prior_regression_tests': 126,
            'posthoc_author_defensive_tests': 8, 'independent_additional_controls': 69,
            'original_counterexample_seams': 9,
            'red_missing_refusals': 26, 'red_sibling_verifier_typeerrors': 1,
            'isolated_predicate_mutant_missing_refusals': {'case': 6, 'bundle': 9, 'scalar': 9},
            'historical_author_indexed_files': 1706, 'historical_author_regular_members': 1707,
            'historical_failed_review_indexed_files': 532, 'historical_failed_review_regular_members': 533,
        },
        'findings_and_reasoning': [
            'The actual final diff changes only canonical case, witness bundle and working-scalar identity comparisons plus their minimal local JSON encoder; a2_trace and all original test/fixture/protocol/schema/numerical bytes remain unchanged.',
            'The helper matches the normative sorted compact ensure_ascii=True allow_nan=False UTF-8 recipe. Because output is ASCII-escaped, its UTF-8 bytes agree with the existing ASCII-encoded a2_trace.canonical. JSON boolean/integer and integer/float aliases have different bytes; nonfinite values are refused.',
            'Preserved RED actually imported the old helper and used the exact same 27 test bytes as final GREEN. Nine original counterexample-entrypoint tests genuinely DID NOT RAISE; total RED is 26 missing refusals plus one sibling verifier TypeError, not 27 identical failures. Fresh isolated replays reproduce both sides.',
            'Tests exercise authenticate, make_trace, and verify_trace independently with a valid trace constructed before authority mutation. New independent nested boolean/integer, integer/float, signed-zero, nonalias-value, null and extra-field controls pass without earlier authentication masking verification.',
            'Dictionary-order identity is positively exercised: full object reordering authenticates and verifies a prebuilt trace; a meaningful recursively reordered input retaining the separately specified artifact publication schedule also reconstructs the identical complete trace.',
            'Unchanged original probe reproduces exit 2 with accepted altered authorities under old source and exit 0 with three exact ValueError refusals under corrected source. Its historical diagnostic-template prose is not treated as a current finding.',
            'All 126 original test identities and all 40 applicable original input occurrences match. Rebuilt complete canonical traces, all 38/27/28 body bytes, initial indexes, journals, parse metrics and independent live-state ledgers match the preserved three valid artifacts.',
            'CAP remains required 22, complete 13, unknown 9, global indeterminate, selected null. Candidate 1 calculated arrays and host-1 binding remain absent, while its supplied input is retained/authenticated. Its finite schedule remains final 51898, peak 55421, cumulative 59388, transaction 18276, old index 7490 and temporary index 8805 bytes.',
            'Case/bundle/scalar site reversions replace exactly one intended comparison while retaining others; their raw XML contains genuine missing-refusal failures, not setup errors or masked kills. Full old-helper reversion reproduces the original split failure modes.',
            'Raw receipt/job/input/XML/import bindings, all correction archive bodies and both immutable historical archives were independently rechecked. The list-shaped correction index was validated for declared count and unique paths before mapping.',
            'Fresh same-layout Ruff 0.16.7 replay confirms 106 identical inherited rule/message/source-context findings, zero corrected-helper/author-proof-helper findings, and the separate inherited capture E501.',
        ],
        'artifacts': artifacts,
        'fresh_execution_results': new_checks,
        'privacy': {
            'input_scan': 'privacy-input-report.json',
            'frozen_input_roots': privacy_inputs['root_count'],
            'expanded_bodies': privacy_inputs['expanded_body_count'],
            'streamed_bytes': privacy_inputs['streamed_bytes'],
            'unresolved_findings': 0,
            'final_proof_scan': 'privacy-final.json',
            'method': 'Per-member streaming archives with explicit size/depth/aggregate bounds; synthetic controls; full owned proof and final metadata scanned before sealing',
        },
        'protection': protection_result,
        'limitations': LIMITATIONS,
        'repository_or_candidate_edits': False,
        'historical_rejection_relabelled': False,
        'further_source_repair_authorized': False,
        'commit_push_release_closure_or_delivery_claim': False,
        'evidence_directory': str(BASE), 'verdict_path': str(BASE / 'verdict.json'),
        'evidence_index_path': str(BASE / 'evidence-index.json'),
    }
    save(BASE / 'verdict.json', verdict)
    paths = final_paths()
    report = scan(paths, 'Complete explicit independent-review proof, excluding only runtime/cache/site and self-indexing records')
    report['positive_controls'] = controls()
    security = [finding for p in BASE.glob('*.py') for finding in static(p.read_bytes(), str(p))]
    report['review_instrumentation_security_findings'] = security
    report['final_generated_metadata_scan'] = {
        'files': ['privacy-final.json', 'evidence-index.json'],
        'method': 'Scan exact serialized bytes in memory before writing; no self-referential hash claim',
    }
    assert not report['findings'] and not security
    raw_report = (json.dumps(report, indent=2) + '\n').encode()
    assert not leaf(raw_report, 'privacy-final.json')
    (BASE / 'privacy-final.json').write_bytes(raw_report)
    files = final_paths() + [BASE / 'privacy-final.json']
    index = {'file_count': len(files), 'files': [
        {'path': str(p.relative_to(BASE)), **pin(p)} for p in sorted(files)],
        'excluded': ['evidence-index.json', 'replays/*/runtime/**', 'quality/*/runtime/**',
                     '**/__pycache__/**', '**/.pytest_cache/**', '**/.ruff_cache/**', '**/site/**'],
        'scope': 'Explicit copied proof inputs plus generated outputs; no ambient scratch/private stores',
    }
    assert len({r['path'] for r in index['files']}) == index['file_count']
    assert 'evidence-index.json' not in {r['path'] for r in index['files']}
    raw_index = (json.dumps(index, indent=2) + '\n').encode()
    assert not leaf(raw_index, 'evidence-index.json')
    (BASE / 'evidence-index.json').write_bytes(raw_index)
    for record in index['files']:
        assert pin(BASE / record['path']) == {k: record[k] for k in ['bytes', 'sha256']}
    print(json.dumps({'passed': True, 'review_completed': True, 'evidence_directory': str(BASE),
                      'index_files': index['file_count'], 'index': pin(BASE / 'evidence-index.json'),
                      'verdict': pin(BASE / 'verdict.json'), 'fresh_passing_tests': verdict['verified_counts']['fresh_passing_tests'],
                      'final_scan_roots': report['root_count'], 'final_scan_bodies': report['expanded_body_count'],
                      'final_scan_bytes': report['streamed_bytes']}))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        # A partial sealing attempt must never leave a consumable PASS verdict.
        target = BASE / 'verdict.json'
        failed = read(target) if target.exists() else {}
        failed.update(review_completed=False, passed=False,
                      sealing_error_type=type(error).__name__,
                      sealing_error=str(error))
        save(target, failed)
        raise
