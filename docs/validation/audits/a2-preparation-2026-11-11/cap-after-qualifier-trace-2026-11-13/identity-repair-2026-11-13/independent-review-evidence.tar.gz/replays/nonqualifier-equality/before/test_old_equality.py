"""Full second-case body and trace equality against the reviewed artifact."""

import json
from pathlib import Path

from test_a2_nonqualifier import module

HERE = Path(__file__).resolve().parent


def test_nonqualifier_all_bytes_remain_unchanged():
    audit = module()
    original = json.loads((HERE / 'reviewed-negative-trace.json').read_bytes())
    trace = audit.make_trace()
    audit.verify_trace(trace)
    assert audit.canonical(trace) == audit.canonical(original)
    before, after = audit.raw_files(original), audit.raw_files(trace)
    assert len(before) == len(after) == 27
    assert before == after
    assert audit.canonical(trace['initial_index']) == audit.canonical(
        original['initial_index']
    )
    output = HERE.parent / 'artifacts'
    output.mkdir(exist_ok=True)
    report = {'canonical_trace_equal': True, 'every_body_equal': True,
              'emitted_bodies_compared': len(after),
              'bodies': {p: {'bytes': len(raw), 'sha256': audit.digest(raw)}
                         for p, raw in after.items()}}
    (output / 'negative-equality.json').write_text(json.dumps(report, indent=2) + '\n')
