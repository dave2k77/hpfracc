"""Independent full canonical/body/ledger replay for one copied static case."""
import hashlib
import json
from pathlib import Path

import a2_trace as audit

HERE = Path(__file__).resolve().parent
OUT = HERE.parent / 'artifacts'


def enc(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('utf-8')


def info(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def metrics(value):
    stack = [(value, 1)]
    nodes = depth = 0
    while stack:
        v, d = stack.pop()
        nodes += 1
        depth = max(depth, d)
        if isinstance(v, dict):
            nodes += len(v)
            depth = max(depth, d + 1)
            stack.extend((child, d + 1) for child in v.values())
        elif isinstance(v, list):
            stack.extend((child, d + 1) for child in v)
    return {'nodes': nodes, 'depth': depth}


def main():
    golden = json.loads((HERE / 'golden-trace.json').read_bytes())
    trace = audit.make_trace()
    verification = audit.verify_trace(trace)
    assert enc(golden) == enc(trace)
    expected = {p: enc(v) for p, v in golden['records'].items()}
    expected.update({p: bytes.fromhex(v) for p, v in golden['logs'].items()})
    actual = audit.raw_files(trace)
    assert expected == actual
    count, status, selected = {
        'REF-PASS-f64-GL': (38, 'selected', 'a-good2-f64-GL'),
        'REF-FAIL-f64-GL': (27, 'no_supplied_candidate_meets_bound', None),
        'CAP-after-qualifier-f64-GL': (28, 'indeterminate', None),
    }[trace['case_id']]
    assert len(actual) == count
    for field in ['initial_index', 'events', 'ledger']:
        assert enc(golden[field]) == enc(trace[field])
    bodies = {**actual, 'INITIAL_INDEX': enc(trace['initial_index'])}
    live = {}
    charges = {}
    states = []
    peak = cumulative = 0
    snapshots = {}
    for event in trace['events']:
        if event['op'] == 'write':
            path, body = event['path'], event['body']
            assert path not in live and body not in charges
            snapshots[body] = {'live_bytes': sum(map(len, live.values())),
                               'cumulative_written_bytes': cumulative}
            live[path] = bodies[body]
            charges[body] = len(bodies[body])
            cumulative += len(bodies[body])
        else:
            assert event == {'op': 'replace', 'source': 'tmp/index-final.part', 'target': 'failure-index.json'}
            assert live['failure-index.json'] == bodies['INITIAL_INDEX']
            live['failure-index.json'] = live.pop('tmp/index-final.part')
        peak = max(peak, sum(map(len, live.values())))
        states.append({'event': event, 'live': sum(map(len, live.values())), 'cumulative': cumulative})
    assert live == actual
    transaction = ['INITIAL_INDEX', 'failure-index.json', 'records/process.json',
                   'records/export.json', 'records/output-control.json']
    reconstructed = {'terms': charges, 'final_live_bytes': sum(map(len, live.values())),
                     'peak_live_bytes': peak, 'cumulative_written_bytes': cumulative,
                     'index_transaction_bytes': sum(charges[k] for k in transaction),
                     'old_index_bytes_charged': charges['INITIAL_INDEX'],
                     'temporary_bytes_charged': charges['failure-index.json']}
    assert reconstructed == trace['ledger'] == verification['ledger']
    records = trace['records']
    result = records['result.json']
    assert result['evidence_bytes'] == snapshots['result.json']['live_bytes']
    for n, body in [('INITIAL_INDEX', trace['initial_index']), ('failure-index.json', records['failure-index.json'])]:
        assert body['bytes_accounting'] == snapshots[n] | {'reserved_final_transaction_bytes': audit.CAPS['failure_index_bytes']}
    assert (result['status'], result['selected_id']) == (status, selected)
    flags = ['arithmetic_verified', 'total_numerical_certified', 'a2_acceptance_passed', 'implementation_authorized']
    assert all(result[k] is False for k in flags)
    parse = {p: metrics(v) for p, v in records.items()}
    assert parse == {p: metrics(v) for p, v in golden['records'].items()}
    if trace['case_id'] == 'CAP-after-qualifier-f64-GL':
        slots = result['shared_slots'] + [s for a in result['assessments'] for s in a['slots']]
        assert len(slots) == 22
        assert verification['complete_slot_count'] == 13 and verification['unknown_slot_count'] == 9
        unknown = result['assessments'][1]
        assert unknown['qualifies'] is None and unknown['status'] == 'unknown'
        assert len(unknown['slots']) == 9
        for s in unknown['slots']:
            assert s['status'] == 'unknown'
            assert all(s[k] is None for k in ['exact_array', 'raw_array', 'producer_binding_sha256'])
            assert 'arrays/' + s['slot_id'] + '.json' not in actual
        assert 'records/binding-host-1.json' not in actual
        assert records['records/candidate-1.json'] == records['input-bundle.json']['request']['candidates'][1]
        assert result['assessments'][0]['qualifies'] is True
        assert [reconstructed[k] for k in ['final_live_bytes', 'peak_live_bytes', 'cumulative_written_bytes',
                                          'index_transaction_bytes', 'old_index_bytes_charged',
                                          'temporary_bytes_charged']] == [51898, 55421, 59388, 18276, 7490, 8805]
    for path, raw in bodies.items():
        target = OUT / 'bodies' / path
        assert '..' not in Path(path).parts and not Path(path).is_absolute()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        assert target.read_bytes() == raw
    (OUT / 'trace.json').write_bytes(enc(trace))
    report = {'case_id': trace['case_id'], 'body_count': count, 'complete_canonical_trace_equal': True,
              'every_body_equal': True, 'trace': info(enc(trace)), 'ledger': reconstructed,
              'verification': verification, 'parse_metrics': parse, 'states': states,
              'bodies': {n: info(v) for n, v in bodies.items()}, 'status': status, 'selected': selected,
              'no_unknown_candidate_arithmetic': True, 'certification_flags_false': True}
    (OUT / 'independent-artifact-report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'case_id': trace['case_id'], 'body_count': count, 'status': status}))


if __name__ == '__main__':
    main()
