"""Authenticate the sole added hypothetical case from pinned packet bytes."""

import copy
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
CASE = 'CAP-after-qualifier-f64-GL'
PINS = {
    'fixtures.json': '7c50cf5a7ff86a1875f3324d413cc3f11fe6c63f4e1acd7633bf89f564b951e5',
    'schema-control-fixtures.json':
        '696b6b22d4d5e9b18c29ce9c6eb0eac4534404860c4221aae0344faea5a25e60',
    'protocol.json': '4622bd8740f592656a0cdba9ede5d8a6d44476413ae47a4fa576ab4c62b1ac9c',
    'record-schemas.json':
        '352939c1ff381276a22173f39d8ab02b370be4456740df96fa90c467dca4c706',
}


def need(condition, message):
    if not condition:
        raise ValueError('frozen authority ' + message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('utf-8')


def authenticate(authority):
    loaded = {}
    for name, pin in PINS.items():
        raw = (HERE / name).read_bytes()
        need(hashlib.sha256(raw).hexdigest() == pin, 'file pin ' + name)
        loaded[name] = json.loads(raw)
    fixture = loaded['fixtures.json']
    controls = loaded['schema-control-fixtures.json']
    protocol = loaded['protocol.json']
    case = next(x for x in fixture['cases'] if x['case_id'] == CASE)
    bundle = next(x for x in controls['bundles']
                  if x['witness_id'] == 'afterqual-' + CASE)
    need(canonical(authority['case']) == canonical(case)
         and authority['bundle'] == bundle,
         'mechanical case/witness slice')
    need(canonical(authority['working_scalars']) ==
         canonical(fixture['working_scalars'])
         and authority['label'] == controls['label']
         and authority['packet_digest'] ==
         controls['hypothetical_external_packet_sha256'],
         'static metadata')
    need(not case['mutations'], 'no mutations admitted')
    control = case['resource_control']
    need(control['override_cap'] is None and control['value'] is None
         and control['fault_checkpoint'] ==
         'after_candidate_index_0_commit_before_candidate_index_1'
         and control['injected_reason'] == 'primitive_cap', 'checkpoint')
    request = copy.deepcopy(case['request'])
    request['input'] = copy.deepcopy(fixture['arrays'][request.pop('input_ref')])
    need(request.pop('caps_ref') == 'protocol.json#/caps', 'caps reference')
    request['caps'] = copy.deepcopy(protocol['caps'])
    candidates = []
    for ref in request.pop('candidate_refs'):
        candidate = copy.deepcopy(fixture['candidates'][ref])
        candidate['record_type'] = 'candidate'
        for field in ['rhos', 'coefficients']:
            candidate[field] = copy.deepcopy(
                fixture['arrays'][candidate.pop(field + '_ref')]
            )
        candidates.append(candidate)
    request.update(candidates=candidates, record_type='request', request_id=CASE,
                   case_id=CASE, policy_id=fixture['protocol_id'],
                   packet_manifest_sha256=authority['packet_digest'])
    need(request == bundle['artifacts']['input-bundle.json']['request'],
         'expanded request including unavailable supplied candidate')
    arrays = [request['input']] + [c[k] for c in candidates
                                  for k in ['rhos', 'coefficients']]
    for value in arrays:
        raw = bytes.fromhex(value['raw_hex'])
        need(len(raw) == value['nbytes'] and
             hashlib.sha256(raw).hexdigest() == value['sha256'], 'raw array bytes')
    inventory = []
    for i in [None] + list(range(len(candidates))):
        names = fixture['exact_slot_inventory'][
            'shared' if i is None else 'each_candidate'
        ]
        for quantity in names:
            inventory.append({
                'slot_id': f'S-{i if i is not None else "X"}-{quantity}',
                'candidate_index': i, 'mode': 'shared' if i is None else 'synthetic',
                'branch': 'base', 'quantity': quantity,
                'initial_status': 'not_evaluated',
            })
    need(inventory == case['required_evidence_slots'], 'mechanical inventory')
    return {'unavailable_candidate_indices': [1], 'reason': control['injected_reason']}
