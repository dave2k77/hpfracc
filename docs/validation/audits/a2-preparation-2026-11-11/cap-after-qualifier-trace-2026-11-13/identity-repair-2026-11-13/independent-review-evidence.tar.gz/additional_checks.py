"""Additional historical archive and parent QA evidence readback."""
import collections
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET

from readback import archive_check
from review_common import AUTHOR, BASE, CASE, NEW, ROOT, WORK, digest, pin, read, save


def main():
    baseline = read(WORK / 'baseline-inputs.json')['files']
    specs = [
        ('author-evidence.tar.gz', 'author-index.json', 1706,
         '0d43fc05ffae9ca1c40d466fbb7d89505ea78ccea629c03698f83537aa09c060',
         '1d77d07793e5b0e3c816efdef95d3e6293357437505bf1f5df9a3c64da28f0f9'),
        ('independent-review-rejected-evidence.tar.gz', 'review-index.json', 532,
         'b1e557ec4782621d4b3af6b936f1cd490372ea67aa04e1286a1559e75e007d0d',
         '3868fac2293dbef9049ad9bc1fd3b75a4e586472287e4a70e73b304c5162d895'),
    ]
    summary = {}
    for archive, index, count, outer_sha, index_sha in specs:
        idxpath = AUTHOR / 'preserved' / index
        idx = read(idxpath)
        assert pin(idxpath)['sha256'] == index_sha
        assert len(idx['files']) == idx['file_count'] == count
        path = CASE / archive
        spec = baseline[str(path.relative_to(ROOT))]
        assert spec['sha256'] == outer_sha
        found = archive_check(path, spec, idx['files'], pin(idxpath))
        assert len(found) == count + 1
        save(BASE / ('historical-' + index), {'archive': str(path), 'archive_pin': spec,
             'index': pin(idxpath), 'members': found, 'count': len(found)})
        summary[archive] = {'members': len(found), 'archive_pin': spec, 'index_pin': pin(idxpath)}
    selections = ['regression-final-positive', 'regression-final-negative', 'controls-complete', 'negative-equality-final']
    original_cases = {}
    with tarfile.open(CASE / 'author-evidence.tar.gz', 'r|gz') as tar:
        for member in tar:
            for name in selections:
                if member.name == 'runs/' + name + '/raw.xml':
                    body = tar.extractfile(member).read()
                    out = BASE / 'historical-raw' / (name + '.xml')
                    out.parent.mkdir(exist_ok=True)
                    out.write_bytes(body)
                    cases = ET.fromstring(body).findall('.//testcase')
                    actual = ET.parse(AUTHOR / 'runs' / (name + '-final') / 'raw.xml').getroot().findall('.//testcase')
                    ids = lambda cs: [(c.attrib['classname'], c.attrib['name']) for c in cs]
                    assert ids(cases) == ids(actual)
                    assert not any(c.find('failure') is not None or c.find('error') is not None or c.find('skipped') is not None for c in cases)
                    original_cases[name] = {'count': len(cases), 'identities': ids(cases), 'raw': pin(out)}
    assert len(original_cases) == 4
    assert sum(x['count'] for x in original_cases.values()) == 126
    qa = read(WORK / 'pre-review-qa.json')
    archive_check(WORK / qa['archive'], {'bytes': qa['bytes'], 'sha256': qa['sha256']}, qa['files'])
    bodies = {}
    with tarfile.open(WORK / qa['archive'], 'r|gz') as tar:
        for member in tar:
            bodies[member.name] = tar.extractfile(member).read()
    save(BASE / 'parent-qa-plan-readback.json', json.loads(bodies['pre-review-qa/plan.json']))
    receipts = json.loads(bodies['pre-review-qa/receipts.json'])
    save(BASE / 'parent-qa-receipts-readback.json', receipts)
    for n, raw in bodies.items():
        if n != 'freeze_review.py':
            path = BASE / 'parent-qa-raw' / n
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
    docs = ET.fromstring(bodies['pre-review-qa/docs.xml']).findall('.//testcase')
    assert len(docs) == 23 and all(c.find('failure') is None and c.find('error') is None for c in docs)
    probes = {}
    for phase in ['original', 'corrected']:
        run = BASE / 'replays' / ('probe-' + phase)
        outcomes = read(run / 'artifacts/canonical-type-outcomes.json')
        assert len(outcomes) == 3
        for name, value in outcomes.items():
            assert value['accepted'] is (phase == 'original')
            if phase == 'corrected':
                assert value['exception'] == 'ValueError'
                assert value['message'] == ('frozen authority static metadata' if name.startswith('scalar') else 'frozen authority mechanical case/witness slice')
            else:
                assert value['emitted_trace_byte_identical_to_original'] is True
                assert (run / 'artifacts' / (name + '-trace.json')).read_bytes() == (AUTHOR / 'preserved/golden/cap-trace.json').read_bytes()
            assert (run / 'artifacts' / (name + '-authority.json')).read_bytes() == (AUTHOR / 'preserved/rejected-probe/artifacts' / (name + '-authority.json')).read_bytes()
        assert pin(run / 'before/type_probe.py') == pin(AUTHOR / 'preserved/rejected-probe/before/type_probe.py')
        probes[phase] = outcomes
    save(BASE / 'additional-readback.json', {'historical_archives': summary, 'original_selection_identities': original_cases,
         'parent_qa_member_count': len(bodies), 'parent_docs_test_count': len(docs), 'probe_outcomes': probes})
    print(json.dumps({'historical_archives': {k: v['members'] for k, v in summary.items()},
                      'prior_exact_identities': sum(v['count'] for v in original_cases.values()), 'parent_qa_docs': len(docs)}))


if __name__ == '__main__':
    main()
