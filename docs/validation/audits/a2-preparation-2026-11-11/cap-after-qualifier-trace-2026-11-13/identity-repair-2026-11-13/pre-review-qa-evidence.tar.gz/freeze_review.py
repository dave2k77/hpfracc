"""Freeze the predicate-only correction after current repository and privacy checks."""
import hashlib
import io
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

from privacy_security import scan_body

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13/identity-repair-2026-11-13'
HERE = Path(__file__).parent


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


baseline = json.loads((WORK / 'baseline-inputs.json').read_text())
assert all(ident((ROOT / n).read_bytes()) == p for n, p in baseline['files'].items()
           if n not in baseline['allowed_status_delta'])
qa = HERE / 'pre-review-qa'
qa.mkdir(exist_ok=False)
base = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync']
commands = [base + ['ruff', 'check', '--no-cache', '.'],
            base + ['python', '-B', '-m', 'pytest', 'tests/unit/test_docs_consistency.py',
                    '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(HERE / 'qa-runtime'),
                    '--junitxml=' + str(qa / 'docs.xml')],
            base + ['mkdocs', 'build', '--strict', '--site-dir', str(HERE / 'site')],
            ['git', 'diff', '--check']]
save(qa / 'plan.json', commands)
receipts = []
for i, command in enumerate(commands):
    process = subprocess.run(command, cwd=ROOT, capture_output=True,
        env=dict(os.environ, UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'),
                 PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu'))
    (qa / f'{i}-stdout.raw').write_bytes(process.stdout)
    (qa / f'{i}-stderr.raw').write_bytes(process.stderr)
    receipts.append({'command': command, 'actual_exit': process.returncode})
save(qa / 'receipts.json', receipts)
assert all(r['actual_exit'] == 0 for r in receipts)
tree = ET.parse(qa / 'docs.xml')
assert len(tree.findall('.//testcase')) == 23
assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
names = ['freeze_review.py', 'pre-review-qa/plan.json', 'pre-review-qa/receipts.json', 'pre-review-qa/docs.xml']
names += [f'pre-review-qa/{i}-{s}.raw' for i in range(4) for s in ['stdout', 'stderr']]
files = {n: (HERE / n).read_bytes() for n in names}
archive_path = WORK / 'pre-review-qa-evidence.tar.gz'
with tarfile.open(archive_path, 'x:gz') as archive:
    for name, body in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(body), 0o644
        archive.addfile(member, io.BytesIO(body))
with tarfile.open(archive_path, 'r:gz') as archive:
    assert len(archive.getmembers()) == len(files)
    assert all(archive.extractfile(n).read() == b for n, b in files.items())
save(WORK / 'pre-review-qa.json', {'archive': archive_path.name, **ident(archive_path.read_bytes()),
    'members_verified': len(files), 'files': {n: ident(b) for n, b in files.items()},
    'actual_exits': [r['actual_exit'] for r in receipts], 'docs_tests_passed': 23})
paths = sorted([p for p in WORK.rglob('*') if p.is_file()] + [ROOT / n for n in baseline['allowed_status_delta']])
findings, expanded, total = [], 0, 0
for path in paths:
    label = str(path.relative_to(ROOT))
    if path.name.endswith('.tar.gz'):
        with tarfile.open(path, 'r:gz') as archive:
            seen = set()
            for member in archive:
                assert member.isfile() and member.size <= 100_000_000
                assert not member.name.startswith('/') and all(p not in ('', '.', '..') for p in member.name.split('/'))
                assert member.name not in seen
                seen.add(member.name)
                body = archive.extractfile(member).read()
                assert len(body) == member.size
                # All archive bodies here are explicit regular files, not nested containers.
                assert not body.startswith((b'\x1f\x8b', b'PK\x03\x04'))
                findings.extend(scan_body(body, label + '::' + member.name))
                expanded += 1
                total += len(body)
                assert total <= 2_000_000_000
    else:
        body = path.read_bytes()
        findings.extend(scan_body(body, label))
        expanded += 1
        total += len(body)
assert scan_body(json.dumps({'chat_id': 'SYNTHETIC_ONLY'}).encode(), 'positive-control')
save(WORK / 'pre-review-privacy.json', {'scope': 'Explicit candidate/status roots and streamed regular archive members; no private identity matching',
    'input_files': {str(p.relative_to(ROOT)): ident(p.read_bytes()) for p in paths},
    'root_files': len(paths), 'expanded_bodies': expanded, 'expanded_bytes': total,
    'findings': findings, 'positive_control_passed': True,
    'limits': 'Bounded patterns/fields, not universal privacy clearance; local paths/hostnames retained.'})
assert not findings
paths.append(WORK / 'pre-review-privacy.json')
manifest = {'status': 'Frozen corrected candidate for fresh independent review, not approval or protocol freeze',
    'files': {str(p.relative_to(ROOT)): ident(p.read_bytes()) for p in sorted(paths)},
    'file_count': len(paths), 'immutable_baseline_files': 930,
    'allowed_post_review_status_delta': baseline['allowed_status_delta'] + [str((WORK / 'README.md').relative_to(ROOT))],
    'allowed_post_review_additions': 'Fresh review proof/verdict, parent readback, final QA and bounded completion metadata only',
    'further_source_repair_authorized': False,
    'correction_index_sha256': '92dfd7a40eadea971066d52c9565cd366f6afa555979073e9d788b083d09283f',
    'correction_archive_sha256': 'ab1f816abb7546dad387e3d39fc1de686aa31deb49abf64abe007bf7bd6a1e01',
    'corrected_helper_sha256': 'f18113b7d05469e7cd657f8ef522114dcc6f6a175c3c60a32f55c21c44370c43',
    'unchanged_checker_sha256': '819fbbafd5b42e9f1bc0c5be320e56146876ff7047a71073def9b9141fba92fa'}
save(WORK / 'review-inputs.json', manifest)
print(json.dumps({'review_files': len(paths), 'review_manifest_sha256': ident((WORK / 'review-inputs.json').read_bytes())['sha256'],
                  'qa_exits': [r['actual_exit'] for r in receipts], 'privacy_roots': len(paths) - 1,
                  'expanded_bodies': expanded, 'privacy_findings': len(findings)}, indent=2))
