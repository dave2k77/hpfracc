"""Prepare isolated predicate reversions and posthoc byte-invariance checks."""

import difflib
import json
from pathlib import Path

from plan_jobs import PRESERVED, cap_inputs, closure, identity_inputs, job
from provision import meta, save

BASE = Path(__file__).resolve().parent
helper = BASE / 'candidate/frozen_case.py'
original = PRESERVED / 'author/candidate/frozen_case.py'
new = helper.read_text()
old = original.read_text()
delta = ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                     fromfile='original/frozen_case.py',
                                     tofile='candidate/frozen_case.py'))
(BASE / 'source.diff').write_text(delta)
save(BASE / 'source-delta.json', {
    'original': meta(original), 'candidate': meta(helper),
    'unchanged_a2_trace': meta(BASE / 'candidate/a2_trace.py'),
    'scope': 'One canonical JSON encoder and three external identity comparisons',
    'unchanged_adjacent_logic': [
        'Pinned file digest authentication and fixture selection',
        'String-valued label and packet digest comparisons',
        'Internally derived request, array bytes and slot inventory comparisons',
        'Existing authenticate_added_case calls in make_trace and verify_trace',
    ],
})
mutants = {
    'case': ("canonical(authority['case']) == canonical(case)",
             "authority['case'] == case", 'case-known or case-unknown', 6),
    'bundle': ("canonical(authority['bundle']) == canonical(bundle)",
               "authority['bundle'] == bundle", 'bundle-', 9),
    'scalar': (
        "canonical(authority['working_scalars']) == canonical(fixture['working_scalars'])",
        "authority['working_scalars'] == fixture['working_scalars']", 'scalar-', 9),
}
for name, (before, after, selection, count) in mutants.items():
    assert new.count(before) == 1
    changed = new.replace(before, after)
    assert changed.count(before) == 0 and changed.count(after) == 1
    path = BASE / 'mutants' / name / 'frozen_case.py'
    path.parent.mkdir(parents=True)
    path.write_text(changed)
    diff = ''.join(difflib.unified_diff(new.splitlines(True), changed.splitlines(True),
                                       fromfile='candidate', tofile=name))
    (path.parent / 'mutation.diff').write_text(diff)
    save(path.parent / 'plan.json', {'original': meta(helper), 'mutant': meta(path),
                                   'old_string': before, 'new_string': after,
                                   'exact_replacement_count': 1,
                                   'selection': selection, 'expected_failures': count})
    job('mutant-' + name, identity_inputs(path),
        ['test_typed_identity.py', '-k', selection],
        expected_exit=1, expected_count=count)
job('mutant-full-original', identity_inputs(original), ['test_typed_identity.py'],
    expected_exit=1, expected_count=27)
for name, source in [('positive', 'regression-final-positive'),
                     ('nonqualifier', 'regression-final-negative'),
                     ('cap', 'controls-complete')]:
    inputs = closure('author/runs/' + source + '/before/')
    inputs['frozen_case.py'] = helper
    inputs['artifact_proof.py'] = BASE / 'artifact_proof.py'
    inputs['golden-trace.json'] = PRESERVED / 'golden' / (name + '-trace.json')
    job('artifact-' + name, inputs, ['artifact_proof.py'], kind='script')
inputs = cap_inputs(helper)
inputs['test_defensive_identity.py'] = BASE / 'test_defensive_identity.py'
job('posthoc-defensive', inputs, ['test_defensive_identity.py'], expected_count=8)
print(json.dumps({'mutation_sites': len(mutants), 'full_reversion_control': True,
                  'artifact_cases': 3}))
