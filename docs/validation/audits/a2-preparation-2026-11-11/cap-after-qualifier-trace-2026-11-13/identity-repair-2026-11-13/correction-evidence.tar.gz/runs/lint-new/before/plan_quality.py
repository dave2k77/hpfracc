"""Plan quality checks and the corrected canonical-byte comparison attempt."""

import json
import sys
from pathlib import Path

from finalize import AUTHORED, inventory
from plan_jobs import PRESERVED, ROOT, UV, cap_inputs, closure, job
from provision import meta, save

BASE = Path(__file__).resolve().parent


def quality():
    helper = BASE / 'candidate/frozen_case.py'
    for name, source in [('positive', 'regression-final-positive'),
                         ('nonqualifier', 'regression-final-negative'),
                         ('cap', 'controls-complete')]:
        inputs = closure('author/runs/' + source + '/before/')
        inputs['frozen_case.py'] = helper
        inputs['artifact_proof.py'] = BASE / 'artifact_proof.py'
        inputs['golden-trace.json'] = PRESERVED / 'golden' / (name + '-trace.json')
        job('artifact-' + name + '-v2', inputs, ['artifact_proof.py'], kind='script')
    save(BASE / 'artifact-attempt-disposition.json', {
        'failed_run': 'artifact-positive', 'actual_child_exit': 1,
        'failure': 'Proof helper required pretty-printed golden file to be canonical',
        'golden_file_bytes': 130130, 'golden_canonical_bytes': 76188,
        'diagnosis': 'Existing original equality test already passed complete canonical '
                     'trace and all 38 bodies. Golden positive file is pretty JSON.',
        'correction': 'Compare full canonical encoding against full canonical encoding; '
                      'retain and separately report raw golden file pin.',
        'source_or_fixture_change': False,
        'earlier_runs_retained': ['artifact-positive', 'artifact-nonqualifier',
                                  'artifact-cap'],
        'replacement_runs': ['artifact-positive-v2', 'artifact-nonqualifier-v2',
                             'artifact-cap-v2'],
    })
    targets = ['a2_trace.py', 'frozen_case.py', 'test_cap_after.py', 'test_controls.py',
               'test_old_equality.py', 'verify_cap.py']
    command = ['-m', 'ruff', 'check', '--no-cache', '--config', 'pyproject.toml',
               '--output-format', 'json']
    for name, frozen in [('original', PRESERVED / 'author/candidate/frozen_case.py'),
                         ('candidate', helper)]:
        inputs = cap_inputs(frozen)
        inputs['test_old_equality.py'] = PRESERVED / 'author/candidate/test_old_equality.py'
        job('lint-' + name, inputs, command + targets, kind='raw', expected_exit=1)
    inputs = {n: BASE / n for n in AUTHORED}
    inputs['pyproject.toml'] = PRESERVED / 'author/candidate/pyproject.toml'
    job('lint-new', inputs, command + AUTHORED, kind='raw')
    job('lint-capture', {'capture.py': BASE / 'capture.py',
                        'pyproject.toml': PRESERVED / 'author/candidate/pyproject.toml'},
        command + ['capture.py'], kind='raw', expected_exit=1)
    job('environment', {'env_probe.py': BASE / 'env_probe.py'},
        ['env_probe.py'], kind='raw')


def final_plan():
    pins = inventory()
    save(BASE / 'finalization-plan.json', {
        'argv': UV + [str(BASE / 'finalize.py')],
        'cwd': '/home/davianc/Documents/biomedical_engineering',
        'environment': {'UV_PROJECT_ENVIRONMENT': str(ROOT / '.venv'),
                        'PYTHONDONTWRITEBYTECODE': '1', 'JAX_PLATFORMS': 'cpu'},
        'selection': 'Aggregate preserved raw results, protection and bounded privacy',
        'inputs': pins,
        'scope': 'Administrative closure over immutable copied-run evidence; not a test run',
        'entrypoint': meta(BASE / 'finalize.py'),
    })
    print(json.dumps({'finalization_inputs': len(pins)}))


if __name__ == '__main__':
    if sys.argv[1] == 'quality':
        quality()
    else:
        final_plan()
