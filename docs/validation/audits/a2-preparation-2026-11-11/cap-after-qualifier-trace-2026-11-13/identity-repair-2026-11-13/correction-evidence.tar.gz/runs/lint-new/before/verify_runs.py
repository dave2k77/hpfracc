"""Recompute outcomes from raw receipts/XML and verify every copied run input."""

import collections
import json
import xml.etree.ElementTree as ET
from pathlib import Path

from provision import meta

BASE = Path(__file__).resolve().parent
REGRESSIONS = ['regression-final-positive', 'regression-final-negative',
               'controls-complete', 'negative-equality-final']
BEHAVIORAL = ['red', 'green', 'original-probe-red', 'original-probe-green']
MUTANTS = ['mutant-case', 'mutant-bundle', 'mutant-scalar', 'mutant-full-original']
ARTIFACTS = ['artifact-' + c + '-v2' for c in ['positive', 'nonqualifier', 'cap']]
EARLY = ['artifact-positive', 'artifact-nonqualifier', 'artifact-cap']
QUALITY = ['lint-original', 'lint-candidate', 'lint-new', 'lint-capture', 'environment']
RUN_NAMES = BEHAVIORAL + REGRESSIONS + MUTANTS + ARTIFACTS + EARLY + [
    'posthoc-defensive'] + QUALITY
DID_NOT_RAISE = "Failed: DID NOT RAISE <class 'ValueError'>"


def read(path):
    return json.loads(path.read_bytes())


def verify_run(name):
    run = BASE / 'runs' / name
    job = read(run / 'job.json')
    assert (run / 'job.json').read_bytes() == (BASE / 'jobs' / (name + '.json')).read_bytes()
    result = read(run / 'result.json')
    assert read(run / 'started.json')['child_started'] is True
    assert result['source_hashes_unchanged'] and not result['timed_out']
    for item, spec in job['inputs'].items():
        assert meta(run / 'before' / item) == spec['pin'] == result['inputs_after'][item]
    for field in ['stdout', 'stderr']:
        assert meta(run / (field + '.bin')) == result[field]
    assert meta(run / 'entrypoint.py') == job['capture_entrypoint']['pin']
    for path, pin in job['environment_inputs'].items():
        assert meta(Path(path)) == pin
    expected = 1 if name == 'artifact-positive' else job['expected_exit']
    assert result['actual_child_exit'] == expected, (name, result['actual_child_exit'])
    summary = {'actual_child_exit': result['actual_child_exit'],
               'source_hashes_unchanged': True, 'input_count': len(job['inputs'])}
    imports_path = run / 'artifacts/imports.json'
    if imports_path.exists():
        imports = read(imports_path)
        for module in ['a2_trace', 'frozen_case']:
            path = run / 'before' / (module + '.py')
            assert imports[module] == {'path': str(path), **meta(path)}
        assert imports['a2_trace']['sha256'] == (
            '819fbbafd5b42e9f1bc0c5be320e56146876ff7047a71073def9b9141fba92fa')
        summary['actual_imports'] = imports
    if job['expected_count'] is not None:
        cases = ET.parse(run / 'raw.xml').getroot().findall('.//testcase')
        assert len(cases) == job['expected_count'] == result['junit']['collected']
        assert meta(run / 'raw.xml') == result['junit']['raw']
        identities = [c.attrib for c in cases]
        assert identities == result['junit']['identities']
        unique = {(c.attrib['classname'], c.attrib['name']) for c in cases}
        assert len(unique) == len(cases)
        assert not any(c.find('error') is not None or c.find('skipped') is not None
                       for c in cases)
        failures = [c.find('failure').attrib['message'] for c in cases
                    if c.find('failure') is not None]
        assert len(failures) == result['junit']['failures']
        summary['collected'] = len(cases)
        summary['failure_messages'] = dict(collections.Counter(failures))
        if expected == 0:
            assert not failures
        elif name in ['red', 'mutant-full-original']:
            assert collections.Counter(failures) == {
                DID_NOT_RAISE: 26,
                'TypeError: list indices must be integers or slices, not float': 1,
            }
            preserved = [c for c in cases if 'test_preserved_' in c.attrib['name']]
            assert len(preserved) == 9
            assert all(c.find('failure').attrib['message'] == DID_NOT_RAISE
                       for c in preserved)
        else:
            assert len(failures) == len(cases)
            assert set(failures) == {DID_NOT_RAISE}
    return summary


def lint_context(name):
    run = BASE / 'runs' / name
    diagnostics = read(run / 'stdout.bin')
    entries = []
    for d in diagnostics:
        path = Path(d['filename'])
        assert path.parent == run / 'before'
        lines = path.read_text().splitlines()
        context = '\n'.join(lines[d['location']['row'] - 1:d['end_location']['row']])
        entries.append((path.name, d['code'], d['message'], context))
    return collections.Counter(entries), diagnostics


def verify_all():
    runs = {name: verify_run(name) for name in RUN_NAMES}
    assert sum(runs[n]['collected'] for n in REGRESSIONS) == 126
    assert (BASE / 'runs/red/before/test_typed_identity.py').read_bytes() == (
        BASE / 'runs/green/before/test_typed_identity.py').read_bytes()
    probe_names = ['case-unknown-occurrence-bool', 'case-known-occurrence-bool',
                   'scalar-alpha-nbytes-float']
    probes = {}
    for phase in ['red', 'green']:
        run = BASE / 'runs' / ('original-probe-' + phase)
        assert meta(run / 'before/type_probe.py') == meta(
            BASE / 'preserved/rejected-probe/before/type_probe.py')
        outcomes = read(run / 'artifacts/canonical-type-outcomes.json')
        assert set(outcomes) == set(probe_names)
        for name, value in outcomes.items():
            expected_message = ('frozen authority static metadata' if name.startswith(
                'scalar') else 'frozen authority mechanical case/witness slice')
            if phase == 'red':
                assert value['accepted'] is True
                assert value['emitted_trace_byte_identical_to_original'] is True
                assert (run / 'artifacts' / (name + '-trace.json')).read_bytes() == (
                    BASE / 'preserved/golden/cap-trace.json').read_bytes()
            else:
                assert value['accepted'] is False
                assert value['exception'] == 'ValueError'
                assert value['message'] == expected_message
            assert (run / 'artifacts' / (name + '-authority.json')).read_bytes() == (
                BASE / 'preserved/rejected-probe/artifacts' /
                (name + '-authority.json')).read_bytes()
        probes[phase] = outcomes
    equalities = {name: read(BASE / 'runs' / name / 'artifacts/equality.json')
                  for name in ARTIFACTS}
    for value in equalities.values():
        assert all(value[k] is True for k in ['canonical_trace_equal', 'every_body_equal',
                                             'initial_index_equal', 'journal_equal',
                                             'ledger_equal'])
        assert value['emitted_trace'] == value['golden_canonical_trace']
    baseline, base_raw = lint_context('lint-original')
    current, current_raw = lint_context('lint-candidate')
    assert baseline == current
    assert len(base_raw) == len(current_raw) == 106
    assert read(BASE / 'runs/lint-new/stdout.bin') == []
    capture = read(BASE / 'runs/lint-capture/stdout.bin')
    assert len(capture) == 1 and capture[0]['code'] == 'E501'
    return {
        'passed': True, 'runs': runs, 'regression_count': 126,
        'tdd': {'red_exit': 1, 'green_exit': 0, 'same_test_bytes': True,
                'preserved_seams_real_did_not_raise': 9,
                'total_did_not_raise': 26, 'sibling_verifier_typeerror': 1,
                'green_passes': 27},
        'probe_replay': probes, 'artifact_equalities': equalities,
        'mutation_sites_killed': ['case', 'bundle', 'scalar'],
        'full_reversion_behavior': '26 DID NOT RAISE and one verifier TypeError',
        'lint': {'baseline_findings': len(base_raw), 'candidate_findings': len(current_raw),
                 'new_helper_findings': 0, 'inherited_capture_E501': 1,
                 'comparison': 'Same filenames, config, version; rule/message/source context',
                 'main_repository_lint': 'Not run; outside this scratch-only scope'},
    }
