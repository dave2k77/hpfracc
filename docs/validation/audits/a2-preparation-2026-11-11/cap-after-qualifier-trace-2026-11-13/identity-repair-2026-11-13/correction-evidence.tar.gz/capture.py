"""Execute a durable literal job from pinned copied inputs; preserve child exit."""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


def meta(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    job_path = Path(sys.argv[1]).resolve()
    job = json.loads(job_path.read_bytes())
    run = Path(job['run'])
    run.mkdir(parents=True, exist_ok=False)
    before = Path(job['cwd'])
    before.mkdir()
    for name, spec in job['inputs'].items():
        source = Path(spec['path'])
        assert meta(source) == spec['pin'], name
        dest = before / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
        assert meta(dest) == spec['pin'], name
    shutil.copyfile(job_path, run / 'job.json')
    shutil.copyfile(Path(__file__), run / 'entrypoint.py')
    Path(job['environment']['TMPDIR']).mkdir()
    save(run / 'started.json', {'child_started': False, 'state': 'ready'})
    with (run / 'stdout.bin').open('wb') as stdout:
        with (run / 'stderr.bin').open('wb') as stderr:
            child = subprocess.Popen(
                job['argv'], cwd=before, env=os.environ | job['environment'],
                stdout=stdout, stderr=stderr,
            )
            save(run / 'started.json', {'child_started': True, 'pid': child.pid})
            try:
                exit_code = child.wait(timeout=180)
                timed_out = False
            except subprocess.TimeoutExpired:
                child.kill()
                exit_code = child.wait()
                timed_out = True
    after = {name: meta(before / name) for name in job['inputs']}
    unchanged = all(after[n] == s['pin'] for n, s in job['inputs'].items())
    result = {'actual_child_exit': exit_code, 'timed_out': timed_out,
              'source_hashes_unchanged': unchanged, 'inputs_after': after,
              'stdout': meta(run / 'stdout.bin'), 'stderr': meta(run / 'stderr.bin')}
    xml = run / 'raw.xml'
    if xml.is_file():
        cases = ET.parse(xml).getroot().findall('.//testcase')
        result['junit'] = {
            'collected': len(cases),
            'failures': sum(c.find('failure') is not None for c in cases),
            'errors': sum(c.find('error') is not None for c in cases),
            'skipped': sum(c.find('skipped') is not None for c in cases),
            'identities': [c.attrib for c in cases], 'raw': meta(xml),
        }
    save(run / 'result.json', result)
    print(json.dumps({'run': run.name, 'exit': exit_code, 'unchanged': unchanged,
                      'junit': {k: v for k, v in result.get('junit', {}).items()
                                if k not in ('identities', 'raw')}}))
    assert unchanged


if __name__ == '__main__':
    main()
