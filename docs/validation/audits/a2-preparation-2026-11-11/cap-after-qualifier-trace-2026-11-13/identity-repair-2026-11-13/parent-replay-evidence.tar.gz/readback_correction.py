"""Read back the narrow correction and replay its preserved behavior in fresh copies."""
import difflib
import hashlib
import importlib.util
import io
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
CASE = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
WORK = CASE / 'identity-repair-2026-11-13'
AUTHOR = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-identity-correction-20261113')
INPUT = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-identity-preflight-20261113')
HERE = Path(__file__).parent
INDEX_PIN = '92dfd7a40eadea971066d52c9565cd366f6afa555979073e9d788b083d09283f'
HELPER = 'f18113b7d05469e7cd657f8ef522114dcc6f6a175c3c60a32f55c21c44370c43'
CHECKER = '819fbbafd5b42e9f1bc0c5be320e56146876ff7047a71073def9b9141fba92fa'


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


raw = (AUTHOR / 'evidence-index.json').read_bytes()
assert ident(raw)['sha256'] == INDEX_PIN
index = json.loads(raw)
assert type(index['files']) is list
entries = {row['path']: {k: row[k] for k in ['bytes', 'sha256']} for row in index['files']}
assert len(entries) == len(index['files']) == index['file_count'] == 1632
for name, pin in entries.items():
    assert not name.startswith('/') and '\\' not in name
    assert all(p not in ('', '.', '..') for p in name.split('/'))
    path = AUTHOR / name
    assert path.is_file() and not path.is_symlink()
    assert ident(path.read_bytes()) == pin
result = json.loads((AUTHOR / 'result.json').read_text())
verification = json.loads((AUTHOR / 'verification.json').read_text())
assert result['passed'] and verification['passed'] and not result['independent_approval']
assert not result['blockers']
old = (INPUT / 'author/candidate/frozen_case.py').read_bytes()
assert ident(old)['sha256'] == '93354458e3633a1bd198049b265a6eb9d3582df9ec5d31d5d87006e24119462b'
new = (AUTHOR / 'candidate/frozen_case.py').read_bytes()
assert ident(new)['sha256'] == HELPER
assert ident((AUTHOR / 'candidate/a2_trace.py').read_bytes())['sha256'] == CHECKER
actual_diff = ''.join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True),
    fromfile='original/frozen_case.py', tofile='candidate/frozen_case.py'))
assert actual_diff == (AUTHOR / 'source-final.diff').read_text() == result['source_delta']
counts, run_checks = {}, {}
for name, declared in verification['runs'].items():
    run = AUTHOR / 'runs' / name
    job = json.loads((run / 'job.json').read_text())
    receipt = json.loads((run / 'result.json').read_text())
    assert receipt['actual_child_exit'] == declared['actual_child_exit']
    assert receipt['source_hashes_unchanged'] and not receipt['timed_out']
    for filename, item in job['inputs'].items():
        assert ident((run / 'before' / filename).read_bytes()) == item['pin'] == receipt['inputs_after'][filename]
    for stream in ['stdout', 'stderr']:
        assert ident((run / (stream + '.bin')).read_bytes()) == receipt[stream]
    if (run / 'raw.xml').is_file():
        body = (run / 'raw.xml').read_bytes()
        assert ident(body) == receipt['junit']['raw']
        cases = ET.fromstring(body).findall('.//testcase')
        assert [c.attrib for c in cases] == receipt['junit']['identities']
        actual = {'collected': len(cases),
            'failures': sum(c.find('failure') is not None for c in cases),
            'errors': sum(c.find('error') is not None for c in cases),
            'skipped': sum(c.find('skipped') is not None for c in cases)}
        assert all(receipt['junit'][k] == v for k, v in actual.items())
        counts[name] = actual
    imports = run / 'artifacts/imports.json'
    if imports.is_file():
        imported = json.loads(imports.read_text())
        for module in ['a2_trace', 'frozen_case']:
            source = run / 'before' / (module + '.py')
            assert imported[module] == {'path': str(source), **ident(source.read_bytes())}
    run_checks[name] = {'actual_child_exit': receipt['actual_child_exit'], 'inputs_verified': len(job['inputs'])}
regressions = ['regression-final-positive-final', 'regression-final-negative-final',
               'controls-complete-final', 'negative-equality-final-final']
assert sum(counts[n]['collected'] for n in regressions) == 126
for name in regressions + ['green-final', 'posthoc-defensive-final']:
    assert run_checks[name]['actual_child_exit'] == 0
    assert all(counts[name][k] == 0 for k in ['failures', 'errors', 'skipped'])
    imports = json.loads((AUTHOR / 'runs' / name / 'artifacts/imports.json').read_text())
    assert imports['frozen_case']['sha256'] == HELPER
assert counts['green-final']['collected'] == 27
assert counts['posthoc-defensive-final']['collected'] == 8
assert (AUTHOR / 'runs/red/before/test_typed_identity.py').read_bytes() == (AUTHOR / 'runs/green-final/before/test_typed_identity.py').read_bytes()
assert run_checks['red']['actual_child_exit'] == 1
pins = json.loads((WORK / 'baseline-inputs.json').read_text())
protected = {n: p for n, p in pins['files'].items() if n not in pins['allowed_status_delta']}
assert len(protected) == 930 and all(ident((ROOT / n).read_bytes()) == p for n, p in protected.items())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == pins['head']
assert ident(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT))['sha256'] == pins['git_stage_sha256']
# Four fresh replays use only verified copied input closures, never old output paths.
replays = {}
for role, original, entrypoint in [
    ('positive', 'artifact-positive-v2-final', 'artifact_proof.py'),
    ('nonqualifier', 'artifact-nonqualifier-v2-final', 'artifact_proof.py'),
    ('cap', 'artifact-cap-v2-final', 'artifact_proof.py'),
    ('counterexamples', 'original-probe-green-final', 'type_probe.py'),
]:
    source_run = AUTHOR / 'runs' / original
    job = json.loads((source_run / 'job.json').read_text())
    before = HERE / role / 'before'
    before.mkdir(parents=True, exist_ok=False)
    copies = {}
    for name, source in job['inputs'].items():
        body = (source_run / 'before' / name).read_bytes()
        assert ident(body) == source['pin']
        target = before / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(body)
        copies[name] = source['pin']
    command = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync',
               'python', '-B', 'run_selected.py', entrypoint]
    save(HERE / role / 'plan.json', {'argv': command, 'cwd': str(before), 'inputs': copies})
    process = subprocess.run(command, cwd=before, capture_output=True,
        env=dict(os.environ, UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'),
                 PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu'))
    (HERE / role / 'stdout.raw').write_bytes(process.stdout)
    (HERE / role / 'stderr.raw').write_bytes(process.stderr)
    save(HERE / role / 'receipt.json', {'actual_child_exit': process.returncode,
        'stdout': ident(process.stdout), 'stderr': ident(process.stderr)})
    assert process.returncode == 0
    assert all(ident((before / n).read_bytes()) == p for n, p in copies.items())
    imported = json.loads((HERE / role / 'artifacts/imports.json').read_text())
    assert imported['frozen_case']['sha256'] == HELPER and imported['a2_trace']['sha256'] == CHECKER
    if role == 'counterexamples':
        outcomes = json.loads((HERE / role / 'artifacts/canonical-type-outcomes.json').read_text())
        assert len(outcomes) == 3
        assert all(not v['accepted'] and v['exception'] == 'ValueError' for v in outcomes.values())
        replays[role] = {'actual_exit': process.returncode, 'preserved_counterexamples_rejected': len(outcomes)}
    else:
        proof = json.loads((HERE / role / 'artifacts/equality.json').read_text())
        assert proof['canonical_trace_equal'] and proof['every_body_equal'] and proof['ledger_equal']
        assert proof['emitted_trace'] == proof['golden_canonical_trace']
        for name, pin in proof['bodies'].items():
            assert ident((HERE / role / 'artifacts/bodies' / name).read_bytes()) == pin
        replays[role] = {'actual_exit': process.returncode, 'body_count': proof['emitted_body_count'],
            'canonical_trace': proof['emitted_trace'], 'ledger': proof['ledger'], 'every_body_equal': True}
assert [replays[r]['body_count'] for r in ['positive', 'nonqualifier', 'cap']] == [38, 27, 28]
scanner_source = 'preserved/author/privacy_security.py'
scanner_raw = (AUTHOR / scanner_source).read_bytes()
assert ident(scanner_raw) == entries[scanner_source]
(HERE / 'privacy_security.py').write_bytes(scanner_raw)
spec = importlib.util.spec_from_file_location('parent_scanner', HERE / 'privacy_security.py')
scanner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scanner)
all_entries = entries | {'evidence-index.json': ident(raw)}
privacy = scanner.scan(AUTHOR, list(all_entries), [Path('candidate/frozen_case.py')])
assert privacy['passed']
save(HERE / 'author-privacy.json', privacy)
archive_path = WORK / 'correction-evidence.tar.gz'
with tarfile.open(archive_path, 'x:gz') as archive:
    for name, expected in sorted(all_entries.items()):
        body = (AUTHOR / name).read_bytes()
        assert ident(body) == expected
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(body), 0o644
        archive.addfile(member, io.BytesIO(body))
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(all_entries) == 1633
    assert {m.name for m in members} == set(all_entries)
    assert all(m.isfile() and ident(archive.extractfile(m).read()) == all_entries[m.name] for m in members)
with (WORK / 'correction-result.json').open('xb') as stream:
    stream.write((AUTHOR / 'result.json').read_bytes())
save(HERE / 'parent-replays.json', replays)
save(HERE / 'checked-runs.json', run_checks)
preservation = {'status': 'Correction self-verification and parent replay passed; fresh independent review pending',
    'archive': archive_path.name, **ident(archive_path.read_bytes()), 'index_sha256': INDEX_PIN,
    'indexed_files_verified': len(entries), 'archive_members_verified': len(all_entries),
    'raw_runs_verified': len(run_checks), 'fixed_helper_sha256': HELPER,
    'unchanged_checker_sha256': CHECKER, 'typed_regressions_passed': 27,
    'prior_regressions_passed': 126, 'posthoc_defensive_passes': 8,
    'parent_replays': replays, 'protected_files_unchanged': len(protected),
    'privacy_findings': privacy['findings'], 'independent_approval': False,
    'historical_rejection_relabelled_successful': False}
save(WORK / 'correction-preservation.json', preservation)
print(json.dumps({k: preservation[k] for k in ['status', 'indexed_files_verified', 'archive_members_verified',
    'raw_runs_verified', 'typed_regressions_passed', 'prior_regressions_passed',
    'protected_files_unchanged', 'sha256']}, indent=2))
