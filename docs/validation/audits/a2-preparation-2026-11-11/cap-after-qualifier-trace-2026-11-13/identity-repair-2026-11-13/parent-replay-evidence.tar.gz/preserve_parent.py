"""Bind preserved original inputs and archive the parent's fresh correction replays."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13/identity-repair-2026-11-13'
AUTHOR = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-identity-correction-20261113')
INPUT = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-identity-preflight-20261113')
HERE = Path(__file__).parent


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


verified = {}
for group in ['regression-final-positive', 'regression-final-negative', 'controls-complete', 'negative-equality-final']:
    original = INPUT / 'author/runs' / group
    current = AUTHOR / 'runs' / (group + '-final')
    job = json.loads((original / 'job.json').read_text())
    for name, item in job['inputs'].items():
        before = (original / 'before' / name).read_bytes()
        assert ident(before) == item['pin']
        if name == 'frozen_case.py':
            continue
        assert (current / 'before' / name).read_bytes() == before, (group, name)
        verified[group + '/' + name] = ident(before)
record = {'status': 'Every original regression input except the authorized helper remains byte-identical',
          'verified_input_occurrences': len(verified), 'files': verified,
          'only_permitted_original_source_change': 'frozen_case.py'}
(HERE / 'regression-input-readback.json').write_text(json.dumps(record, indent=2) + '\n')
names = ['readback_correction.py', 'preserve_parent.py', 'privacy_security.py',
         'author-privacy.json', 'checked-runs.json', 'parent-replays.json', 'regression-input-readback.json']
for role in ['positive', 'nonqualifier', 'cap', 'counterexamples']:
    plan = json.loads((HERE / role / 'plan.json').read_text())
    names += [role + '/' + n for n in ['plan.json', 'receipt.json', 'stdout.raw', 'stderr.raw']]
    names += [role + '/before/' + n for n in plan['inputs']]
    names.append(role + '/artifacts/imports.json')
    if role == 'counterexamples':
        outcomes = json.loads((HERE / role / 'artifacts/canonical-type-outcomes.json').read_text())
        names += [role + '/artifacts/' + n for n in ['canonical-type-outcomes.json', 'blocking-finding.json']]
        names += [role + '/artifacts/' + n + '-authority.json' for n in outcomes]
    else:
        proof = json.loads((HERE / role / 'artifacts/equality.json').read_text())
        names += [role + '/artifacts/' + n for n in ['trace.json', 'initial-index.json', 'equality.json']]
        names += [role + '/artifacts/bodies/' + n for n in proof['bodies']]
assert len(names) == len(set(names))
files = {n: (HERE / n).read_bytes() for n in names}
archive_path = WORK / 'parent-replay-evidence.tar.gz'
with tarfile.open(archive_path, 'x:gz') as archive:
    for name, body in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(body), 0o644
        archive.addfile(member, io.BytesIO(body))
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(files)
    assert all(m.isfile() and archive.extractfile(m).read() == files[m.name] for m in members)
result = {'status': 'Parent current-source copied replay passed; independent re-review pending',
          'archive': archive_path.name, **ident(archive_path.read_bytes()),
          'members_verified': len(files), 'files': {n: ident(b) for n, b in files.items()},
          'replays': json.loads((HERE / 'parent-replays.json').read_text()),
          'original_regression_input_occurrences_verified': len(verified),
          'source_change_limited_to': 'frozen_case.py', 'independent_approval': False}
with (WORK / 'parent-replay.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'archive_members_verified': len(files), 'original_regression_input_occurrences_verified': len(verified),
                  'archive_sha256': result['sha256']}))
