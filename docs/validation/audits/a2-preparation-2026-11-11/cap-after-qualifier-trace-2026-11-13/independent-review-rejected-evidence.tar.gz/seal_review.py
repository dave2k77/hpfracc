"""Preserve independent review verdict and an explicit hash/size proof index.

Only owned, declared proof paths are enumerated. Runtime/cache trees and ambient
scratch are excluded. The archive is streamed by member, never fully inflated.
"""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile

HERE=Path(__file__).resolve().parent
SCANNER=HERE/'runs/author-archive-scan/before/privacy_security.py'
spec=importlib.util.spec_from_file_location('review_privacy',SCANNER)
scanner=importlib.util.module_from_spec(spec);spec.loader.exec_module(scanner)

def enc(v):return json.dumps(v,indent=2,ensure_ascii=True,allow_nan=False).encode()+b'\n'
def identity(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def save(p,v):
    path=HERE/p
    assert not path.exists(),str(path)
    path.write_bytes(enc(v))
def read(p):return json.loads((HERE/p).read_bytes())

assert not (HERE/'verdict.json').exists()
finding=read('runs/canonical-type-controls/artifacts/blocking-finding.json')
assert finding['blocking']
canonical=read('runs/canonical-type-controls/artifacts/canonical-type-outcomes.json')
assert len(canonical)==3 and all(v['accepted'] and v['emitted_trace_byte_identical_to_original'] for v in canonical.values())
assert read('runs/canonical-type-controls/receipt.json')['actual_child_exit']==2
assert read('protected-before.json')['protected_files']==read('protected-after.json')['protected_files']
assert read('protected-before.json')['review_files']==read('protected-after.json')['review_files']
review=read('reviewed-metadata/review-inputs.json')
checks={}
for name,expected in [('controls-complete',66),('regression-final-positive',27),('regression-final-negative',32),('negative-equality-final',1)]:
    receipt=read('runs/'+name+'/receipt.json');xml=receipt['xml']
    assert receipt['actual_child_exit']==0 and xml['count']==expected and not any(xml[k] for k in ['failures','errors','skipped'])
    assert all(receipt['unchanged_inputs'].values())
    checks[name]={'count':xml['count'],'exit':receipt['actual_child_exit'],'xml':xml['pin'],'exact_test_identities':xml['identities']}
math=read('runs/independent-controls/artifacts/exact.json')
physical=read('runs/independent-controls/artifacts/physical.json')
original=read('runs/independent-controls/artifacts/inventory-original-outcome.json')
mutant=read('runs/inventory-mutant/artifacts/inventory-mutant-outcome.json')
assert original['message']=='fixed record inventory' and mutant['accepted']
assert (HERE/'runs/independent-controls/artifacts/extra-supplied-candidate.json').read_bytes()==(HERE/'runs/inventory-mutant/artifacts/extra-supplied-candidate.json').read_bytes()
notes={
 'scope':'One added named CAP-after-qualifier static witness; REF-PASS and REF-FAIL regressions only. No fitter/application/AD/FIT-REAL execution.',
 'known_unknown':'13 exact shared/candidate-0 quantities checked independently from IEEE bit decomposition and GL recurrence; nine explicit unknown null slots with retained authenticated candidate-1 supply. No candidate-1 calculations or observations invented.',
 'decision':'Known candidate-0 qualifies with epsilon=0 and B=[0,0,0]; exhaustive policy still requires global indeterminate, selected_id=null, primitive_cap. This is a hypothetical cooperative checkpoint, not measured cap exhaustion or minimum-uncertainty theorem.',
 'math':math,
 'ledger':physical['ledger'],
 'ledger_method':'Own physical file-map event replay includes all 28 final bodies, old index and temporary coexistence; own per-body charges equal copied verify_cap and parent frozen reference. Snapshot fields checked before their own writes; manifest own bytes charged. No phantom unknown artifacts.',
 'regressions':checks,
 'regression_count_basis':{'previous_selections':59,'new_case_selection':66,'additional_nonqualifier_equality':1,'old_positive_bodies':38,'old_nonqualifier_bodies':27,'both_complete_canonical_traces_equal':True,'counts_from_exact_raw_XML':True},
 'independent_controls':{'valid_baseline':True,'target_semantic_refusals':len(read('runs/independent-controls/artifacts/controls-outcomes.json')),'actual_charge_omissions_rejected':len(read('runs/independent-charge-controls/artifacts/charge-controls.json')),'noncanonical_authority_controls_incorrectly_accepted':len(canonical)},
 'inventory_gap':{'new_input':'Fresh records/candidate-2.json copy before result; no unavailable binding and no extra numerical slot. Every schema, link, lifecycle and byte replay predicate passes before inventory checking.','original_refusal':original,'isolated_mutant_accepted':True,'same_control_bytes_for_both':True,'mutant_delta':'Only the fixed record inventory guard removed in owned copy; diff and both complete source closures preserved.','interpretation':'The original inventory guard is effective and not redundant. Earlier host-1 test was masked by the separate absent-binding guard; new control isolates inventory defense.'},
 'author_history':{'archive_indexed':1706,'regular_members':1707,'raw_run_records_verified':56,'meaningful_mutants_killed':10,'prior_inventory_mutant_survived_due_to_other_guard':1,'initial_positive_RED':'Wrong fixed authority ValueError under previous two-case checker','boundary_RED':'Two unmeasured counter controls genuinely lacked refusal; four certification flags already schema-rejected and only regex matching failed.','posthoc':'Already-passing defensive controls and mutation kills are not TDD REDs. Historical schema-masked and diagnostic-regression attempts remain preserved.'},
 'lint':{'baseline_findings':108,'candidate_findings':106,'introduced_rule_context':[],'new_candidate_helpers_exit':0,'final_all_author_helpers_exit':0,'inherited_run_snapshot_E501':1,'parent_repository_QA':'Archived parent Ruff, 23 documentation tests, strict build and whitespace commands all zero; read back separately, not rerun as independent live-repository QA.','review_harness_limit':'Two preserved outer expectation failures were selection mistakes: current capture.py passed when inherited E501 was expected; historical lint-all-authored-clean snapshot reproduced its original two findings. Final actual green helper selection was separately reproduced, exact pins matched, no source changed.'},
 'blocking_finding':finding,
 'stop':'All requested focused review categories exercised. No repair after the blocking canonical-type finding; only preservation/privacy/index sealing and protected-byte recheck followed.'
}
save('review-report.json',notes)
limitations=[
 'Only three trusted local static cases are reviewed, with one newly admitted CAP-after-qualifier witness; this is not a general operational validator or arbitrary-authority service.',
 'CAP-AUTH-TYPE-01 blocks approval: full fixed-authority authentication accepts bool/int and float/int lookalikes. Original frozen trace bytes and independently reconstructed mathematics remain correct; source/criteria were not repaired.',
 'Primitive-cap reason, process exit/timing/security fields and zero work counters are illustrative, not measured work, an OS kill, peak RAM, runtime or security certification.',
 'Finite serialized schedule accounting does not establish whole-packet admission; all eight FIT-REAL admission blockers and wider A2 work remain open.',
 'Privacy is bounded pattern/structured-field and static-code scanning with a positive synthetic control, not private-identity matching or universal publication clearance; local paths/hostnames remain.',
 'No repository changes, messages, commit/push, source repair, numerical acceptance, protocol freeze, tracked-work closure or delivery claim. Independent reviewer proof is newly created only in owned scratch.',
 'Archived lint remains baseline-failing (108 baseline, 106 candidate, no introduced context findings); actual final new-helper lint passed. Parent current-repository QA was verified from preserved raw receipts rather than rerun.',
 'Preserved author records support archive consistency and copied replay, not historical OS-process attestation. Wrapper exits are distinct from actual child exits; canonical-type probe child exited 2 to signal its blocking finding.'
]
logic=['CAP-AUTH-TYPE-01: frozen_case.py:37-43 uses Python structural == rather than canonical typed identity. Re-signed local authority copies with required_evidence_slots[13].candidate_index=true instead of 1, required_evidence_slots[4].candidate_index=false instead of 0, or working_scalars.float64.alpha.nbytes=8.0 instead of 8 all pass authenticate(), make_trace() and verify_trace(). Each changed canonical authority digest differs while emitted trace bytes stay identical. This violates the promised full pinned case/scalar typed identity; preserve-and-stop applies.']
verdict={'review_completed':True,'passed':False,'security_concerns':[],'logic_errors':logic,'limitations':limitations,'verdict_path':str(HERE/'verdict.json'),'evidence_index_path':str(HERE/'evidence-index.json'),'evidence_directory':str(HERE),'review_identity':{'review_inputs_sha256':'fd3dbc7d4b6d8f4cdf4dbb66c8f081509bc3a3e97195d8a0d61eaf4028bc9e4e','head':read('protected-after.json')['head'],'git_stage_sha256':read('protected-after.json')['git_stage']['sha256'],'git_stage_encoding':'git ls-files --stage -z raw bytes','checker_sha256':review['checker_sha256'],'frozen_case_sha256':'93354458e3633a1bd198049b265a6eb9d3582df9ec5d31d5d87006e24119462b','authority_sha256':'a1f0d64365a2abfc72ce9107d941ec8542a43d9fb7b6000a2682b127850fcec9','verify_cap_sha256':'1dff339b9b2172508d7479dd2058133a040e486134fc3861149022cf450fad6d','author_archive_sha256':review['author_archive_sha256'],'author_index_sha256':review['author_index_sha256'],'protected_baseline_count':901,'frozen_review_file_count':17},'finding':finding,'raw_proof':'review-report.json and runs/*/{plan.json,started.json,receipt.json,stdout.raw,stderr.raw,raw.xml if applicable}; all supplied closures and counterexamples indexed.','repair_performed':False,'parent_only_status_changes_pending':True}
save('verdict.json',verdict)
# Enumerate only explicitly owned proof roots/files. Generated cache/runtime excluded.
top=['inspect_proof.py','check_archive.py','capture_review.py','independent_probe.py','run_independent.py','audit_runs_lint.py','lint_followup.py','lint_history.py','lint_final.py','scan_archive.py','charge_probe.py','run_support.py','type_probe.py','run_type.py','final_readbacks.py','seal_review.py','protected-before.json','protected-after.json','author-index-copy.json','archive-members.json','archive-xml.json','archive-integrity.json','author-raw-run-readback.json','old-test-identities.json','inventory-mutant.diff','lint-context-delta.json','lint-harness-note.json','lint-history-readback.json','final-helper-selection.json','parent-qa-readback.json','red-provenance-readback.json','author-mutation-readback.json','cross-replay-equality.json','review-report.json','verdict.json']
runs=['controls-complete','regression-final-positive','regression-final-negative','negative-equality-final','physical-replay-final','independent-controls','inventory-mutant','lint-baseline-review','lint-candidate-review','lint-new-helpers-review','lint-capture-review','lint-inherited-capture-review','lint-all-authored-review','lint-authored-final-review','author-archive-scan','independent-charge-controls','canonical-type-controls']
paths=set(top)
paths.add('inventory-mutant-source/a2_trace.py')
for name in ['authorization.json','README.md','baseline-inputs.json','parent-frozen-reference.json','author-result.json','author-preservation.json','parent-replay.json','review-inputs.json']:
    paths.add('reviewed-metadata/'+name)
for name in runs:
    root=HERE/'runs'/name
    plan=read('runs/'+name+'/plan.json')
    for p in plan['inputs']:paths.add('runs/'+name+'/before/'+p)
    for p in ['plan.json','started.json','receipt.json','stdout.raw','stderr.raw']:
        paths.add('runs/'+name+'/'+p)
    if (root/'raw.xml').is_file():paths.add('runs/'+name+'/raw.xml')
    if (root/'context-findings.json').is_file():paths.add('runs/'+name+'/context-findings.json')
    if (root/'artifacts').is_dir():
        for p in (root/'artifacts').rglob('*'):
            assert not p.is_symlink()
            if p.is_file():paths.add(str(p.relative_to(HERE)))
final_metadata=['publication-allowlist.json','privacy-review.json','evidence-index.json']
allow=sorted(paths|set(final_metadata))
save('publication-allowlist.json',{'files':allow,'declared_count_including_index':len(allow),'excluded_roots':['runs/*/runtime','__pycache__','ambient scratch, runtime/site/cache and all private receipt/profile/session stores'],'index_self_hash_excluded':True})
paths.add('publication-allowlist.json')
findings=[];security=[];scanned=0;bytes_scanned=0
for rel in sorted(paths):
    p=HERE/rel; assert p.is_file() and not p.is_symlink(),rel
    raw=p.read_bytes();bytes_scanned+=len(raw)
    if rel.endswith('.tar.gz'):
        with tarfile.open(p,'r|gz') as tf:
            for m in tf:
                assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
                assert m.size<=100_000_000
                findings+=scanner.scan_body(tf.extractfile(m).read(),rel+'!'+m.name)
                scanned+=1
    else:
        findings+=scanner.scan_body(raw,rel);scanned+=1
    if rel.endswith('.py'):security+=scanner.security(p)
assert not findings and not security,(findings,security)
positive=scanner.scan_body(json.dumps({'chat_id':'SYNTHETIC_NOT_REAL'}).encode(),'synthetic-memory-control')
assert any(x['rule']=='sensitive-field' for x in positive)
privacy={'passed':True,'allowlisted_files_scanned_before_final_metadata':len(paths),'scan_bodies_including_archive_members':scanned,'outer_file_bytes':bytes_scanned,'findings':findings,'security_findings':security,'positive_synthetic_control':positive,'final_metadata':['privacy-review.json','evidence-index.json'],'final_metadata_policy':'Scan the actual serialized report and index in memory before writing; abort on findings. Index excludes its own body only. No hashing self-reference is claimed.','limits':limitations[4]}
raw=enc(privacy);assert not scanner.scan_body(raw,'privacy-review.json')
save('privacy-review.json',privacy);paths.add('privacy-review.json')
files={p:identity((HERE/p).read_bytes()) for p in sorted(paths)}
index={'file_count':len(files),'files':files,'excluded':['evidence-index.json (self hash)','runs/*/runtime','ambient/private/cache/site trees'],'review_completed':True,'passed':False,'publication_allowlist':'publication-allowlist.json','review_manifest_sha256':verdict['review_identity']['review_inputs_sha256']}
assert set(files)|{'evidence-index.json'}==set(allow)
raw=enc(index);assert not scanner.scan_body(raw,'evidence-index.json')
save('evidence-index.json',index)
# Explicit final readback, including declared counts and exact each body.
actual=read('evidence-index.json');assert actual['file_count']==len(actual['files'])
for p,pin in actual['files'].items():assert identity((HERE/p).read_bytes())==pin,p
assert read('verdict.json')['passed'] is False and read('verdict.json')['review_completed'] is True
print(json.dumps({'verdict_path':str(HERE/'verdict.json'),'verdict':identity((HERE/'verdict.json').read_bytes()),'evidence_index_path':str(HERE/'evidence-index.json'),'evidence_index':identity((HERE/'evidence-index.json').read_bytes()),'indexed_files_excluding_index':len(files),'review_completed':True,'passed':False,'privacy_scan_no_findings':True,'parent_status_not_modified':True}))
