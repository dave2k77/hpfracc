"""Stream the pinned outer tar member-by-member under the existing scan bound."""
import ast
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
import gzip
from privacy_security import scan_body

HERE=Path(__file__).resolve().parent
OUT=HERE.parent/'artifacts';OUT.mkdir(exist_ok=True)
archive=HERE/'author-evidence.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='0d43fc05ffae9ca1c40d466fbb7d89505ea78ccea629c03698f83537aa09c060'
index=json.loads((HERE/'author-index-copy.json').read_bytes())
seen={};findings=[];security=[];python_count=0;total=0
with tarfile.open(archive,'r|gz') as tf:
    for member in tf:
        p=PurePosixPath(member.name)
        assert member.isfile() and not p.is_absolute() and '..' not in p.parts and member.name not in seen
        assert member.size<=100_000_000
        raw=tf.extractfile(member).read();total+=len(raw)
        actual={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
        seen[member.name]=actual
        if member.name!='evidence-index.json':assert actual==index['files'][member.name]
        else:assert actual['sha256']=='1d77d07793e5b0e3c816efdef95d3e6293357437505bf1f5df9a3c64da28f0f9'
        findings+=scan_body(raw,'author-evidence.tar.gz!'+member.name)
        if member.name.endswith('.py'):
            python_count+=1
            tree=ast.parse(raw)
            for n in ast.walk(tree):
                if not isinstance(n,ast.Call):continue
                name=n.func.id if isinstance(n.func,ast.Name) else n.func.attr if isinstance(n.func,ast.Attribute) else ''
                forbidden=name in {'eval','exec','system'} or any(k.arg=='shell' and isinstance(k.value,ast.Constant) and k.value.value is True for k in n.keywords)
                forbidden|=name in {'load','loads'} and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='pickle'
                if forbidden:security.append({'member':member.name,'line':n.lineno,'rule':'unsafe-call'})
assert set(seen)==set(index['files'])|{'evidence-index.json'}
buf=io.BytesIO();synthetic=json.dumps({'chat_id':'SYNTHETIC_NOT_REAL'}).encode()
with tarfile.open(fileobj=buf,mode='w') as tf:
    m=tarfile.TarInfo('synthetic.json');m.size=len(synthetic);tf.addfile(m,io.BytesIO(synthetic))
positive=scan_body(gzip.compress(buf.getvalue()),'synthetic-memory-control')
assert any(f.get('rule')=='sensitive-field' for f in positive)
report={'regular_members':len(seen),'indexed_members':len(index['files']),'uncompressed_member_bytes_scanned':total,'python_members_static_scanned':python_count,'findings':findings,'security_findings':security,'synthetic_recursive_control':positive,'method':'tarfile r|gz outer stream; bounded scan_body on each indexed regular member, never whole-tar inflation or extraction','per_body_bound':100_000_000,'limits':['No private-identity matching or credential/profile/session/receipt-store reads.','Patterns and structured fields are bounded checks, not universal clearance.','Absolute local paths/hostnames remain raw provenance.']}
(OUT/'author-archive-privacy.json').write_text(json.dumps(report,indent=2)+'\n')
assert not findings and not security,report
print(json.dumps({k:v for k,v in report.items() if k not in ['synthetic_recursive_control','limits']}))
