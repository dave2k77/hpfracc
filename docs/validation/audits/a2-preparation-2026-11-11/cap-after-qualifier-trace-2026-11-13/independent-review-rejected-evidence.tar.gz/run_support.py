"""Run the archive scan and charge controls from explicit copied inputs."""
from capture_review import AUTHOR,HERE,ROOT,closure,run
WORK=ROOT/'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
inputs={'author-evidence.tar.gz':WORK/'author-evidence.tar.gz','author-index-copy.json':HERE/'author-index-copy.json','privacy_security.py':AUTHOR/'privacy_security.py','scan_archive.py':HERE/'scan_archive.py'}
run('author-archive-scan',inputs,['scan_archive.py'])
inputs=closure('runs/controls-complete/before/')
inputs.update({'independent_probe.py':HERE/'independent_probe.py','charge_probe.py':HERE/'charge_probe.py'})
run('independent-charge-controls',inputs,['charge_probe.py'])
