"""Read preserved QA, RED provenance, mutation outcomes and parse dimensions."""
from capture_review import AUTHOR,HERE,ROOT,INDEX,pin,record
import collections
import json
import tarfile
import xml.etree.ElementTree as ET
WORK=ROOT/'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
qa=json.loads((WORK/'pre-review-qa.json').read_bytes()); bodies={}
with tarfile.open(WORK/qa['archive'],'r|gz') as tf:
    for m in tf:
        assert m.isfile() and m.name in qa['files'];raw=tf.extractfile(m).read();assert pin(raw)==qa['files'][m.name];bodies[m.name]=raw
assert len(bodies)==qa['members_verified']==len(qa['files'])
xml=ET.fromstring(bodies['pre-review-qa/docs.xml']);cases=xml.findall('.//testcase')
assert len(cases)==23 and not any(c.find('failure') is not None or c.find('error') is not None for c in cases)
record(HERE/'parent-qa-readback.json',{'archive':pin((WORK/qa['archive']).read_bytes()),'all_members_verified':len(bodies),'plan':json.loads(bodies['pre-review-qa/plan.json']),'receipts':json.loads(bodies['pre-review-qa/receipts.json']),'doc_xml_count':len(cases),'scope':'Preserved parent current-repository QA; not a new independent repo execution and separate from copied archived lint.'})
# Inspect actual failure bodies, not just counts.
reds={}
for name in ['red-01','boundary-red','regression-01-negative']:
    cases=ET.fromstring((AUTHOR/'runs'/name/'raw.xml').read_bytes()).findall('.//testcase')
    reds[name]=[{'name':c.get('name'),'failure_message':c.find('failure').get('message'),'failure_body':c.find('failure').text} for c in cases if c.find('failure') is not None]
record(HERE/'red-provenance-readback.json',reds)
result=json.loads((WORK/'author-result.json').read_bytes())
record(HERE/'author-mutation-readback.json',result['mutations'])
print('mutation counts',result['mutations']['counts'])
print('RED messages',{k:[(x['name'],x['failure_message']) for x in v] for k,v in reds.items()})
# Compare frozen regenerated and parent replay reports against own independent replay.
a=json.loads((HERE/'runs/independent-controls/artifacts/physical.json').read_bytes())
b=json.loads((HERE/'runs/physical-replay-final/artifacts/independent-report.json').read_bytes())
assert a['ledger']==b['physical']['ledger']
assert a['final_bodies']==b['physical']['final_files']
assert b['physical']['max_parse_nodes']==1004 and b['physical']['max_parse_depth']==9
assert b['exact']['slots']==json.loads((HERE/'runs/independent-controls/artifacts/exact.json').read_bytes())['known_slots']
record(HERE/'cross-replay-equality.json',{'every_body_equal':len(a['final_bodies']),'every_charge_equal':len(a['ledger']['terms']),'ledger':a['ledger'],'max_parse_nodes':1004,'max_parse_depth':9,'independent_methods':'Direct IEEE-bit rational reconstruction + own event map compared to separate copied verify_cap replay.'})
