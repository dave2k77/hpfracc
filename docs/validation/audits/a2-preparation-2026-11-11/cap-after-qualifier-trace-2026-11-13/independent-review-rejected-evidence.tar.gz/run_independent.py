"""Dispatch independent controls using explicit frozen input closures."""
from capture_review import AUTHOR, HERE, closure, run
import sys

inputs=closure('runs/controls-complete/before/')
inputs['independent_probe.py']=HERE/'independent_probe.py'
mode=sys.argv[1]
if mode=='original':
    run('independent-controls',inputs,['independent_probe.py','original'])
    mutant=HERE/'inventory-mutant-source'
    mutant.mkdir(exist_ok=False)
    (mutant/'a2_trace.py').write_bytes((AUTHOR/'candidate/a2_trace.py').read_bytes())
elif mode=='mutant':
    inputs['a2_trace.py']=HERE/'inventory-mutant-source/a2_trace.py'
    run('inventory-mutant',inputs,['independent_probe.py','inventory-mutant'])
