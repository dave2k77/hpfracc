"""Reduce explicit lint run history and final current helper identities."""
from capture_review import AUTHOR, HERE, INDEX, record
import json
out={}
for name in INDEX:
    if not name.startswith('runs/lint') or not name.endswith('/result.json'):continue
    prefix=name.removesuffix('result.json'); result=json.loads((AUTHOR/name).read_bytes()); job=json.loads((AUTHOR/(prefix+'job.json')).read_bytes())
    findings=json.loads((AUTHOR/(prefix+'stdout.bin')).read_bytes())
    out[prefix]={'exit':result['actual_child_exit'],'count':len(findings) if isinstance(findings,list) else None,'argv':job['argv'],'source_pins':{k:v['pin'] for k,v in job['inputs'].items()}}
record(HERE/'lint-history-readback.json',out)
print({k:{f:v[f] for f in ['exit','count']} for k,v in out.items()})
print('claimed lint',json.loads((AUTHOR/'result.json').read_bytes()).get('lint'))
