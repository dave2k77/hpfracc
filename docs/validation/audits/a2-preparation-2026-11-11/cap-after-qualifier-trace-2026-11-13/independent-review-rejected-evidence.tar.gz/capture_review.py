"""Run only frozen copied proof closures; retain child exit and raw evidence."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUTHOR = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-after-author-20261113')
INDEX = json.loads((HERE / 'author-index-copy.json').read_bytes())['files']

def pin(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def record(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def run(name, inputs, command, expected_count=None, expected_exit=0):
    dest = HERE / 'runs' / name
    dest.mkdir(parents=True, exist_ok=False)
    before = dest / 'before'
    before.mkdir()
    runtime = dest / 'runtime'
    runtime.mkdir()
    pins = {}
    for rel, source in inputs.items():
        raw = source.read_bytes()
        if source.is_relative_to(AUTHOR):
            assert pin(raw) == INDEX[str(source.relative_to(AUTHOR))]
        (before / rel).parent.mkdir(parents=True, exist_ok=True)
        (before / rel).write_bytes(raw)
        pins[rel] = {'source': str(source), **pin(raw)}
    env = {'PYTHONDONTWRITEBYTECODE': '1', 'JAX_PLATFORMS': 'cpu', 'UV_PROJECT_ENVIRONMENT': str(ROOT / '.venv'), 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1', 'TMPDIR': str(runtime)}
    argv = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync', 'python', '-B'] + command
    argv = [a.replace('{run}', str(dest)) for a in argv]
    plan = {'argv': argv, 'cwd': str(before), 'environment_overrides': env, 'inputs': pins, 'expected_count': expected_count, 'expected_exit': expected_exit, 'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Independent review fresh copied execution, no numerical worker'}
    record(dest / 'plan.json', plan)
    with (dest / 'stdout.raw').open('wb') as stdout, (dest / 'stderr.raw').open('wb') as stderr:
        child = subprocess.Popen(argv, cwd=before, env=os.environ | env, stdout=stdout, stderr=stderr)
        record(dest / 'started.json', {'pid': child.pid, 'plan': pin((dest / 'plan.json').read_bytes()), 'child_started': True})
        code = child.wait()
    unchanged = {rel: pin((before / rel).read_bytes()) == {k: v for k, v in val.items() if k != 'source'} for rel, val in pins.items()}
    report = {'actual_child_exit': code, 'unchanged_inputs': unchanged, 'stdout': pin((dest / 'stdout.raw').read_bytes()), 'stderr': pin((dest / 'stderr.raw').read_bytes()), 'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    if (dest / 'raw.xml').exists():
        xml = ET.fromstring((dest / 'raw.xml').read_bytes())
        cases = xml.findall('.//testcase')
        report['xml'] = {'pin': pin((dest / 'raw.xml').read_bytes()), 'count': len(cases), 'failures': sum(c.find('failure') is not None for c in cases), 'errors': sum(c.find('error') is not None for c in cases), 'skipped': sum(c.find('skipped') is not None for c in cases), 'identities': [c.attrib.get('classname', '') + '::' + c.attrib['name'] for c in cases], 'headers': [n.attrib for n in xml.iter('testsuite')]}
    record(dest / 'receipt.json', report)
    assert all(unchanged.values()), name
    assert code == expected_exit, (name, code)
    if expected_count is not None:
        assert report['xml']['count'] == expected_count
    print(name, code, report.get('xml', {}).get('count'))
    return dest

def closure(prefix):
    return {p.removeprefix(prefix): AUTHOR / p for p in INDEX if p.startswith(prefix)}

if __name__ == '__main__':
    if sys.argv[1] == 'regressions':
        jobs = [('controls-complete', ['test_cap_after.py', 'test_controls.py'], 66), ('regression-final-positive', ['test_a2_trace.py', 'test_a2_routing.py', 'test_equality.py'], 27), ('regression-final-negative', ['test_a2_nonqualifier.py', 'test_semantics.py', 'test_derivation.py'], 32), ('negative-equality-final', ['test_old_equality.py'], 1)]
        for name, tests, count in jobs:
            command = ['-m', 'pytest', '-q', '-p', 'no:cacheprovider', '--basetemp={run}/runtime/pytest', '--junitxml={run}/raw.xml'] + tests
            dest = run(name, closure('runs/' + name + '/before/'), command, count)
            historical = json.loads((HERE / 'archive-xml.json').read_bytes())['runs/' + name + '/raw.xml']['identities']
            observed = json.loads((dest / 'receipt.json').read_bytes())['xml']['identities']
            assert historical == observed
        run('physical-replay-final', closure('runs/physical-replay-final/before/'), ['verify_cap.py', 'replay'])
