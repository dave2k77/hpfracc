"""Complete lint context checks and disclose the earlier selection mistake."""
from capture_review import AUTHOR, HERE, closure, run, record
record(HERE/'lint-harness-note.json',{'issue':'Independent harness selected current capture.py while expecting the inherited run_snapshot.py E501. Current capture.py correctly exited 0; the outer wrapper assertion failed, not the linted source. No candidate or criteria changed. The exact earlier plan, receipt and streams remain under runs/lint-capture-review.','followup':'Run explicit inherited capture closure and all author helpers separately.'})
inputs=closure('runs/lint-inherited-capture/before/')
print('inherited explicit files',list(inputs))
run('lint-inherited-capture-review',inputs,['-m','ruff','check','--no-cache','--output-format=json']+[p for p in inputs if p.endswith('.py')],expected_exit=1)
inputs=closure('runs/lint-all-authored-clean/before/')
run('lint-all-authored-review',inputs,['-m','ruff','check','--no-cache','--output-format=json']+[p for p in inputs if p.endswith('.py')])
