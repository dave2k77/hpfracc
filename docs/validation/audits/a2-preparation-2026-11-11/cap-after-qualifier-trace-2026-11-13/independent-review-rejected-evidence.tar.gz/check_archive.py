"""Validate indexed member identities and reduce raw run receipts."""
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from inspect_proof import AUTHOR, OUT, ident, save

index = json.loads((OUT / 'author-index-copy.json').read_bytes())
members = json.loads((OUT / 'archive-members.json').read_bytes())
assert index['file_count'] == len(index['files']) == 1706
assert set(members) == set(index['files']) | {'evidence-index.json'}
for name, pin in index['files'].items():
    assert members[name] == pin, name
    assert ident((AUTHOR / name).read_bytes()) == pin, name
save('archive-integrity.json', {'members': len(members), 'indexed': len(index['files']), 'all_archive_and_explicit_author_bodies_match_index': True})
for prefix in ['runs/controls-complete/', 'runs/regression-final-positive/', 'runs/regression-final-negative/', 'runs/negative-equality-final/']:
    print(prefix)
    for name in index['files']:
        if name.startswith(prefix) and ('/before/' in name or name.count('/') == 2):
            print(name)
for name in index['files']:
    if name.endswith(('receipt.json', 'plan.json', 'job.json')) and name.startswith('runs/controls-complete/'):
        print(name, (AUTHOR / name).read_text())
print('top helper names', [p for p in index['files'] if p.count('/') <= 1 and p.endswith('.py')])
print('old paths', [p for p in index['files'] if p.startswith('frozen/previous-author/') and p.count('/') <= 3])
