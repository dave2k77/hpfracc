"""Capture final fixed-authority canonical-type controls without repairs."""
from capture_review import HERE,closure,run
inputs=closure('runs/controls-complete/before/')
inputs.update({'independent_probe.py':HERE/'independent_probe.py','type_probe.py':HERE/'type_probe.py'})
run('canonical-type-controls',inputs,['type_probe.py'],expected_exit=2)
