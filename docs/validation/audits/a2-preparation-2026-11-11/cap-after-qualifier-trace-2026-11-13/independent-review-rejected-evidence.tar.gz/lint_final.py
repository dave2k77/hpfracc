"""Reproduce the actual final green helper selection, preserving prior failures."""
from capture_review import AUTHOR, HERE, INDEX, closure, record, run
import json
inputs=closure('runs/lint-authored-pass/before/')
job=json.loads((AUTHOR/'runs/lint-authored-pass/job.json').read_bytes())
command=job['argv'][job['argv'].index('-m'):]
assert command[:2]==['-m','ruff']
checks={}
for rel,source in inputs.items():
    possible=['candidate/'+rel,rel]
    targets=[p for p in possible if p in INDEX]
    if targets: checks[rel]={'matches_current':any(INDEX[str(source.relative_to(AUTHOR))]==INDEX[p] for p in targets),'candidates':targets}
record(HERE/'final-helper-selection.json',{'pins_relative_to_current':checks,'note':'Prior independent lint-all-authored-review deliberately preserved the historical lint-all-authored-clean snapshot, whose actual child exit was 1. Its name did not mean passing. This run targets the indexed actual final green selection; no source is changed.'})
run('lint-authored-final-review',inputs,command)
print('current pin match',checks)
