"""Check raw run linkage, old-test byte identities and context-aware lint."""
import collections
import difflib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from capture_review import AUTHOR, HERE, INDEX, closure, pin, record, run

runs={}
for path in INDEX:
    if not path.startswith('runs/') or not path.endswith('/job.json'):
        continue
    prefix=path.removesuffix('job.json')
    job=json.loads((AUTHOR/path).read_bytes())
    result=json.loads((AUTHOR/(prefix+'result.json')).read_bytes())
    started=json.loads((AUTHOR/(prefix+'started.json')).read_bytes())
    assert result['source_hashes_unchanged']
    for rel,desc in job['inputs'].items():
        expected=desc['pin']
        assert INDEX[prefix+'before/'+rel]==expected
        assert result['inputs_after'][rel]==expected
    for label,fn in [('stdout','stdout.bin'),('stderr','stderr.bin')]:
        assert pin((AUTHOR/(prefix+fn)).read_bytes())==result[label]
    entry=job['capture_entrypoint']
    assert INDEX[prefix+'entrypoint.py']==entry['pin']
    summary={'actual_child_exit':result['actual_child_exit'],'input_count':len(job['inputs']),'inputs_unchanged':True,'started':started,'argv':job['argv'],'cwd':job['cwd'],'environment':job['environment']}
    if prefix+'raw.xml' in INDEX:
        cases=ET.fromstring((AUTHOR/(prefix+'raw.xml')).read_bytes()).findall('.//testcase')
        counts={'collected':len(cases),'failures':sum(c.find('failure') is not None for c in cases),'errors':sum(c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases)}
        assert all(result['junit'][k]==v for k,v in counts.items())
        assert [(c.get('classname'),c.get('name')) for c in cases]==[(c['classname'],c['name']) for c in result['junit']['identities']]
        summary['junit']=counts
    runs[prefix]=summary
assert len(runs)==56
record(HERE/'author-raw-run-readback.json',runs)
old={}
for name,origin in [('test_a2_trace.py','baseline'),('test_a2_routing.py','baseline'),('test_equality.py','final')]:
    before='runs/regression-final-positive/before/'+name; source='frozen/previous-author/'+origin+'/'+name
    assert INDEX[before]==INDEX[source]; old[name]=INDEX[source]
for name in ['test_a2_nonqualifier.py','test_semantics.py','test_derivation.py']:
    source='frozen/previous-author/final/'+name
    assert INDEX['runs/regression-final-negative/before/'+name]==INDEX[source]; old[name]=INDEX[source]
record(HERE/'old-test-identities.json',old)
# Original source and one-line isolated mutant, no other differences.
a=(AUTHOR/'candidate/a2_trace.py').read_text(); b=(HERE/'inventory-mutant-source/a2_trace.py').read_text()
diff=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='pinned-candidate',tofile='isolated-inventory-mutant'))
assert b==a.replace("    need(set(records) == set(AUTHORITY['bundle']['artifacts']), 'fixed record inventory')",'    # ISOLATED REVIEW MUTANT: exact record inventory guard removed.')
(HERE/'inventory-mutant.diff').write_text(diff)
# Reproduce legacy archived lint in same filenames/config context.
files=['a2_trace.py','test_a2_trace.py','test_a2_routing.py','test_a2_nonqualifier.py','test_semantics.py','test_equality.py','test_derivation.py','verify_independent.py']
cmd=['-m','ruff','check','--no-cache','--output-format=json']+files
base=closure('runs/lint-baseline/before/')
run('lint-baseline-review',base,cmd,expected_exit=1)
candidate=dict(base);candidate['a2_trace.py']=AUTHOR/'candidate/a2_trace.py'
run('lint-candidate-review',candidate,cmd,expected_exit=1)
keys=[]
for tag in ['lint-baseline-review','lint-candidate-review']:
    dest=HERE/'runs'/tag
    findings=json.loads((dest/'stdout.raw').read_bytes())
    contexts=collections.Counter()
    for item in findings:
        p=Path(item['filename']); lines=p.read_text().splitlines()
        line=lines[item['location']['row']-1].strip()
        contexts[(p.name,item['code'],line)]+=1
    keys.append(contexts)
    record(dest/'context-findings.json',{'count':len(findings),'contexts':[{'file':k[0],'rule':k[1],'line':k[2],'count':v} for k,v in contexts.items()]})
added=keys[1]-keys[0];removed=keys[0]-keys[1]
record(HERE/'lint-context-delta.json',{'baseline':sum(keys[0].values()),'candidate':sum(keys[1].values()),'introduced':[list(k)+[v] for k,v in added.items()],'removed':[list(k)+[v] for k,v in removed.items()]})
assert not added
helpers={p.name:p for p in [AUTHOR/'candidate/frozen_case.py',AUTHOR/'candidate/test_cap_after.py',AUTHOR/'candidate/test_controls.py',AUTHOR/'candidate/test_old_equality.py',AUTHOR/'candidate/verify_cap.py',AUTHOR/'frozen/inputs/pyproject.toml']}
run('lint-new-helpers-review',helpers,['-m','ruff','check','--no-cache','--output-format=json']+[p for p in helpers if p.endswith('.py')])
run('lint-capture-review',{'capture.py':AUTHOR/'capture.py','pyproject.toml':AUTHOR/'frozen/inputs/pyproject.toml'},['-m','ruff','check','--no-cache','--output-format=json','capture.py'],expected_exit=1)
print('56 raw records verified; old test identities unchanged; lint',sum(keys[0].values()),sum(keys[1].values()),'introduced',len(added))
