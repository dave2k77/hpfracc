"""Independent actual-affine-term omissions with recalculated claimed totals."""
import copy
import json
from independent_probe import audit, OUT, enc, save, outcome

def charged(t,lengths):
    live={};cumulative=peak=0
    for e in t['events']:
        if e['op']=='write':
            n=lengths[e['body']];live[e['path']]=n;cumulative+=n
        else:live[e['target']]=live.pop(e['source'])
        peak=max(peak,sum(live.values()))
    return {'terms':lengths,'final_live_bytes':sum(live.values()),'peak_live_bytes':peak,'cumulative_written_bytes':cumulative,'index_transaction_bytes':sum(lengths[p] for p in ['INITIAL_INDEX','failure-index.json','records/process.json','records/export.json','records/output-control.json']),'old_index_bytes_charged':lengths['INITIAL_INDEX'],'temporary_bytes_charged':lengths['failure-index.json']}

base=audit.make_trace(); assert audit.verify_trace(base)
results={}
terms=['input-bundle.json','records/candidate-1.json','result.json','records/process.json','records/output-control.json','records/export.json','run-manifest.json','INITIAL_INDEX','failure-index.json','logs/stdout.bin','logs/stderr.bin','inline-result-unknown','inline-index-unknown','inline-input-unknown']
for term in terms:
    t=copy.deepcopy(base);lengths=dict(t['ledger']['terms'])
    if term.startswith('inline-'):
        path={'inline-result-unknown':'result.json','inline-index-unknown':'failure-index.json','inline-input-unknown':'input-bundle.json'}[term]
        smaller=copy.deepcopy(t['records'][path])
        if path=='result.json':smaller['assessments'][1]['slots']=[]
        else:
            key='slots' if path=='failure-index.json' else 'required_slots'
            smaller[key]=[s for s in smaller[key] if s['candidate_index']!=1]
        removed=len(enc(t['records'][path]))-len(enc(smaller));assert removed>0
        lengths[path]-=removed
    else:removed=lengths[term];lengths[term]=0
    t['ledger']=charged(t,lengths)
    audit.check_links(t);audit.check_completion(t['records']);audit.check_fixed_exact_payloads(t['records']);audit.check_lifecycle(t)
    got=outcome(t);save('omission-'+term.replace('/','-')+'.json',t)
    assert not got['accepted'] and got['message']=='ledger claim differs from independent byte replay',got
    results[term]={'removed_actual_bytes':removed,'outcome':got}
save('charge-controls.json',results)
print(json.dumps({'actual_term_omission_controls':len(results),'target_semantic_rejections':True}))
