"""Read-only explicit-input integrity review; no shared output writes."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import sys

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
AUTHOR = Path('/home/davianc/.hermes/cache/scratch/hpfracc-cap-after-author-20261113')
OUT = Path(__file__).resolve().parent

def ident(b):
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2) + '\n')

def main():
    phase = sys.argv[1]
    baseline = json.loads((WORK / 'baseline-inputs.json').read_bytes())
    review_raw = (WORK / 'review-inputs.json').read_bytes()
    assert ident(review_raw)['sha256'] == 'fd3dbc7d4b6d8f4cdf4dbb66c8f081509bc3a3e97195d8a0d61eaf4028bc9e4e'
    review = json.loads(review_raw)
    mutable = {'docs/developer/phase-a-completion.md', 'docs/developer/bug-resolution-tracker.md'}
    checked = {}
    for rel, pin in baseline['files'].items():
        if rel in mutable:
            continue
        actual = ident((ROOT / rel).read_bytes())
        assert actual == pin, (rel, actual, pin)
        checked[rel] = actual
    assert len(checked) == 901
    for rel, pin in review['files'].items():
        assert ident((ROOT / rel).read_bytes()) == pin, rel
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
    stage = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT)
    assert head == baseline['head']
    assert ident(stage)['sha256'] == baseline['git_stage_sha256']
    save('protected-' + phase + '.json', {'head': head, 'git_stage': ident(stage), 'git_stage_encoding': 'git ls-files --stage -z raw bytes', 'baseline_verified_count': len(checked), 'review_verified_count': len(review['files']), 'review_manifest': ident(review_raw), 'protected_files': checked, 'review_files': review['files']})
    if phase != 'before':
        return
    names = ['authorization.json', 'README.md', 'baseline-inputs.json', 'parent-frozen-reference.json', 'author-result.json', 'author-preservation.json', 'parent-replay.json', 'review-inputs.json']
    (OUT / 'reviewed-metadata').mkdir(exist_ok=True)
    for n in names:
        (OUT / 'reviewed-metadata' / n).write_bytes((WORK / n).read_bytes())
    members = {}
    xmls = {}
    import xml.etree.ElementTree as ET
    index = None
    with tarfile.open(WORK / 'author-evidence.tar.gz', 'r|gz') as tf:
        for m in tf:
            p = PurePosixPath(m.name)
            assert m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name not in members
            body = tf.extractfile(m).read()
            members[m.name] = ident(body)
            if m.name == 'evidence-index.json':
                assert ident(body)['sha256'] == review['author_index_sha256']
                index = json.loads(body)
                save('author-index-copy.json', index)
            if m.name.endswith('.xml'):
                tree = ET.fromstring(body)
                cases = tree.findall('.//testcase')
                xmls[m.name] = {'identities': [c.attrib.get('classname', '') + '::' + c.attrib['name'] for c in cases], 'count': len(cases), 'failed': sum(c.find('failure') is not None for c in cases), 'errors': sum(c.find('error') is not None for c in cases), 'skipped': sum(c.find('skipped') is not None for c in cases), 'headers': [s.attrib for s in tree.iter('testsuite')]}
    save('archive-members.json', members)
    save('archive-xml.json', xmls)
    print('archive members', len(members), 'index keys', list(index))
    print('baseline keys', list(baseline))
    for n in ['author-result.json', 'author-preservation.json', 'parent-replay.json']:
        d = json.loads((WORK / n).read_bytes())
        print(n, {k: (list(v)[:15] if isinstance(v, dict) else {'length': len(v), 'sample': v[:2]} if isinstance(v, list) else v) for k, v in d.items()})
    print('final closure', [n for n in members if n.startswith('runs/physical-replay-final/before/')])
    print('run xml counts', {k: {a: b for a, b in v.items() if a not in ('identities', 'headers')} for k, v in xmls.items()})

if __name__ == '__main__':
    main()
