"""Run pre-review QA, stream-scan the explicit candidate, and pin review inputs."""
import hashlib
import io
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

from privacy_security import scan_body

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
HERE = Path(__file__).parent


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


pins = json.loads((WORK / 'baseline-inputs.json').read_text())
assert all(ident((ROOT / n).read_bytes()) == p for n, p in pins['files'].items()
           if n not in pins['allowed_status_delta'])
qa = HERE / 'pre-review-qa'
qa.mkdir(exist_ok=False)
base = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync']
commands = [base + ['ruff', 'check', '--no-cache', '.'],
            base + ['python', '-B', '-m', 'pytest', 'tests/unit/test_docs_consistency.py',
                    '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(HERE / 'qa-runtime'),
                    '--junitxml=' + str(qa / 'docs.xml')],
            base + ['mkdocs', 'build', '--strict', '--site-dir', str(HERE / 'site')],
            ['git', 'diff', '--check']]
save(qa / 'plan.json', commands)
receipts = []
for i, command in enumerate(commands):
    process = subprocess.run(command, cwd=ROOT, capture_output=True,
        env=dict(os.environ, UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'),
                 PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu'))
    (qa / f'{i}-stdout.raw').write_bytes(process.stdout)
    (qa / f'{i}-stderr.raw').write_bytes(process.stderr)
    receipts.append({'command': command, 'actual_exit': process.returncode})
save(qa / 'receipts.json', receipts)
assert all(r['actual_exit'] == 0 for r in receipts)
tree = ET.parse(qa / 'docs.xml')
assert len(tree.findall('.//testcase')) == 23
assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
names = ['freeze_review.py', 'pre-review-qa/plan.json', 'pre-review-qa/receipts.json', 'pre-review-qa/docs.xml']
names += [f'pre-review-qa/{i}-{s}.raw' for i in range(4) for s in ['stdout', 'stderr']]
files = {n: (HERE / n).read_bytes() for n in names}
archive_path = WORK / 'pre-review-qa-evidence.tar.gz'
with tarfile.open(archive_path, 'x:gz') as archive:
    for name, body in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(body), 0o644
        archive.addfile(member, io.BytesIO(body))
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(files)
    assert all(m.isfile() and archive.extractfile(m).read() == files[m.name] for m in members)
save(WORK / 'pre-review-qa.json', {'archive': archive_path.name, **ident(archive_path.read_bytes()),
    'members_verified': len(files), 'files': {n: ident(b) for n, b in files.items()},
    'actual_exits': [r['actual_exit'] for r in receipts], 'docs_tests_passed': 23})
statuses = [ROOT / n for n in pins['allowed_status_delta']]
paths = sorted([p for p in WORK.rglob('*') if p.is_file()] + statuses)
findings, expanded, scanned_bytes = [], 0, 0
# Stream the large outer tar; scan each exact regular body without whole-tar inflation.
assert scan_body(json.dumps({'chat_id': 'SYNTHETIC_ONLY'}).encode(), 'positive-control')
for path in paths:
    name = str(path.relative_to(ROOT))
    if path.name.endswith('.tar.gz'):
        with tarfile.open(path, 'r:gz') as archive:
            seen = set()
            for member in archive:
                assert member.isfile() and not member.name.startswith('/')
                assert all(p not in ('', '.', '..') for p in member.name.split('/'))
                assert member.name not in seen and member.size <= 100_000_000
                seen.add(member.name)
                body = archive.extractfile(member).read()
                assert len(body) == member.size
                findings.extend(scan_body(body, name + '::' + member.name))
                expanded += 1
                scanned_bytes += len(body)
    else:
        body = path.read_bytes()
        findings.extend(scan_body(body, name))
        expanded += 1
        scanned_bytes += len(body)
save(WORK / 'pre-review-privacy.json', {'scope': 'Explicit candidate roots; outer tar streaming and bounded recursive per-member patterns/fields. No private identity matching.',
    'input_files': {str(p.relative_to(ROOT)): ident(p.read_bytes()) for p in paths},
    'root_files': len(paths), 'expanded_bodies': expanded, 'expanded_bytes': scanned_bytes,
    'findings': findings, 'positive_control_passed': True,
    'limits': 'No universal privacy/hostile-filesystem assurance; raw local paths and hostnames retained.'})
assert not findings
paths.append(WORK / 'pre-review-privacy.json')
manifest = {'status': 'Frozen candidate for independent review; not protocol freeze or approval',
    'files': {str(p.relative_to(ROOT)): ident(p.read_bytes()) for p in sorted(paths)},
    'file_count': len(paths), 'immutable_baseline_files': 901,
    'allowed_post_review_status_delta': pins['allowed_status_delta'] + [str((WORK / 'README.md').relative_to(ROOT))],
    'allowed_post_review_additions': 'Independent proof/verdict, parent preservation/readback and final QA/closure metadata only',
    'source_or_criteria_repairs_authorized': False,
    'author_index_sha256': '1d77d07793e5b0e3c816efdef95d3e6293357437505bf1f5df9a3c64da28f0f9',
    'author_archive_sha256': '0d43fc05ffae9ca1c40d466fbb7d89505ea78ccea629c03698f83537aa09c060',
    'checker_sha256': '819fbbafd5b42e9f1bc0c5be320e56146876ff7047a71073def9b9141fba92fa'}
save(WORK / 'review-inputs.json', manifest)
print(json.dumps({'review_input_files': len(paths), 'review_manifest_sha256': ident((WORK / 'review-inputs.json').read_bytes())['sha256'],
    'qa_exits': [r['actual_exit'] for r in receipts], 'privacy_roots': len(paths) - 1,
    'expanded_bodies': expanded, 'privacy_findings': len(findings)}, indent=2))
