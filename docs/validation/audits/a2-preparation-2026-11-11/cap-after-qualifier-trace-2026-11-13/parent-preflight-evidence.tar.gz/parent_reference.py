"""Independent exact arithmetic for available frozen slots, never unknown ones."""
import hashlib
import json
import math
import struct
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).parent
ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'


def rational(value):
    return Fraction(int(value['num'], 16), int(value['den'], 16))


def decode(value):
    raw = bytes.fromhex(value['raw_hex'])
    assert value['dtype'] == 'float64' and value['byte_order'] == 'little'
    assert value['layout'] == 'C'
    count = math.prod(value['shape'])
    assert len(raw) == value['nbytes'] == 8 * count
    assert hashlib.sha256(raw).hexdigest() == value['sha256']
    return list(map(Fraction.from_float, struct.unpack('<' + 'd' * count, raw)))


witness = json.loads((HERE / 'selected-witness.json').read_text())
case = json.loads((HERE / 'selected-case.json').read_text())
records = witness['artifacts']
request = records['input-bundle.json']['request']
x = decode(request['input'])
n = len(x)
a = rational(request['alpha'])
dt = rational(request['dt'])
assert n == 3 and a == Fraction(1, 2) and dt == Fraction(1, 4)
scale = Fraction(math.isqrt(dt.denominator), math.isqrt(dt.numerator))
assert scale * scale * dt == 1
w = [Fraction(1)]
for k in range(1, n):
    w.append(w[-1] * (k - 1 - a) / k)
g = [sum(w[:k + 1]) for k in range(n)]
v = [x[0]] + [x[k] - x[k - 1] for k in range(1, n)]
direct = [scale * sum(w[k] * x[i - k] for k in range(i + 1)) for i in range(n)]
assert direct == [scale * sum(g[k] * v[i - k] for k in range(i + 1)) for i in range(n)]
# Only candidate 0 has computed evidence. Candidate 1 remains unassessed.
candidate = request['candidates'][0]
c = decode(candidate['coefficients'])
rho = decode(candidate['rhos'])
assert len(c) == len(rho) == candidate['configuration']['pole_count']
fitted = [Fraction(1)] + [sum(coef * pole ** (k - 1) for coef, pole in zip(c, rho, strict=True)) for k in range(1, n)]
residual = [fitted[k] - g[k] for k in range(n)]
epsilon = max(map(abs, residual))
weights = [fitted[0]] + [fitted[k] - fitted[k - 1] for k in range(1, n)]
matrix = [[scale * weights[i - j] if j <= i else Fraction(0) for j in range(n)] for i in range(n)]
output = [sum(row[j] * x[j] for j in range(n)) for row in matrix]
assert output == [scale * sum(fitted[k] * v[i - k] for k in range(i + 1)) for i in range(n)]
error = [abs(output[k] - direct[k]) for k in range(n)]
assert [output[i] - direct[i] for i in range(n)] == [scale * sum(residual[k] * v[i - k] for k in range(i + 1)) for i in range(n)]
bound = [scale * epsilon * sum(map(abs, v[:i])) for i in range(n)]
assert all(e <= b for e, b in zip(error, bound, strict=True))
gradient = [Fraction(2, n) * sum(matrix[i][j] * output[i] for i in range(n)) for j in range(n)]
values = {'S-X-w': w, 'S-X-g': g, 'S-X-v': v, 'S-X-D': direct}
for name, value in {'g_hat': fitted, 'residual': residual, 'signed_fitted_weights': weights,
                    'L_hat': [e for row in matrix for e in row], 'D_hat': output,
                    'error': error, 'B': bound, 'epsilon': [epsilon],
                    'analytic_input_gradient': gradient}.items():
    values['S-0-' + name] = value
for sid, expected in values.items():
    slot = records['arrays/' + sid + '.json']
    assert slot['status'] == 'complete'
    assert [rational(v) for v in slot['exact_array']['values']] == expected
unknown = records['result.json']['assessments'][1]
assert unknown['status'] == 'unknown' and unknown['qualifies'] is None
unknown_ids = []
for slot in unknown['slots']:
    sid = slot['slot_id']
    unknown_ids.append(sid)
    assert slot['candidate_index'] == 1 and slot['status'] == 'unknown'
    assert slot['reason'] == 'primitive_cap' and slot['reasons'] == ['primitive_cap']
    assert all(slot[k] is None for k in ['raw_array', 'exact_array', 'producer_binding_sha256'])
    assert 'arrays/' + sid + '.json' not in records
    row = next(s for s in records['failure-index.json']['slots'] if s['slot_id'] == sid)
    assert row['status'] == 'unknown' and row['artifact'] is None and row['completed_shape'] is None
assert len(values) == 13 and len(unknown_ids) == 9
assert 'records/binding-host-1.json' not in records
qualifies = all(b <= rational(request['tau']) for b in bound)
assert qualifies
expected_status = 'indeterminate' if unknown_ids else ('selected' if qualifies else 'no_supplied_candidate_meets_bound')
assert records['result.json']['status'] == expected_status
assert records['result.json']['selected_id'] is None
result = {
    'scope': 'Independent host exact check of frozen available STATIC/HYPOTHETICAL quantities; not worker observations or byte-ledger closure',
    'case_id': case['case_id'], 'known_candidate_index': 0,
    'known_candidate_id': candidate['stable_id'], 'known_candidate_qualifies': qualifies,
    'tau': str(rational(request['tau'])), 'epsilon': str(epsilon), 'bound': list(map(str, bound)),
    'known_exact_slots': {sid: list(map(str, value)) for sid, value in values.items()},
    'known_exact_slots_verified': len(values), 'unknown_slot_ids': unknown_ids,
    'unknown_slots_preserved': len(unknown_ids), 'unavailable_candidate_arithmetic_performed': False,
    'derived_request_status': expected_status, 'selected_id': None,
    'fault_role': case['resource_control'], 'measured_cap_feasibility_claimed': False,
    'implementation_authorized': False, 'a2_acceptance_passed': False,
}
with (WORK / 'parent-frozen-reference.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['known_candidate_qualifies', 'tau', 'epsilon', 'bound',
      'known_exact_slots_verified', 'unknown_slots_preserved', 'derived_request_status', 'selected_id']}, indent=2))
