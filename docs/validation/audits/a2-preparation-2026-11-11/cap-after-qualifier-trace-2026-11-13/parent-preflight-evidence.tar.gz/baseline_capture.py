"""Capture initial repository QA and durable pre-extension reference proof."""
import hashlib
import io
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/cap-after-qualifier-trace-2026-11-13'
HERE = Path(__file__).parent


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


pins = json.loads((WORK / 'baseline-inputs.json').read_text())
assert all(ident((ROOT / name).read_bytes()) == expected for name, expected in pins['files'].items())
status = HERE / 'prior-status'
status.mkdir(exist_ok=False)
for name in pins['allowed_status_delta']:
    (status / Path(name).name).write_bytes((ROOT / name).read_bytes())
qa = HERE / 'baseline-qa'
qa.mkdir(exist_ok=False)
base = ['uv', '--project', str(ROOT), 'run', '--frozen', '--no-sync']
commands = [
    base + ['ruff', 'check', '--no-cache', '.'],
    base + ['python', '-B', '-m', 'pytest', 'tests/unit/test_docs_consistency.py', '-q',
            '-p', 'no:cacheprovider', '--basetemp=' + str(HERE / 'qa-runtime'),
            '--junitxml=' + str(qa / 'docs.xml')],
    base + ['mkdocs', 'build', '--strict', '--site-dir', str(HERE / 'site')],
    ['git', 'diff', '--check'],
]
save(qa / 'plan.json', commands)
results = []
for i, command in enumerate(commands):
    env = dict(os.environ, UV_PROJECT_ENVIRONMENT=str(ROOT / '.venv'),
               PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu')
    process = subprocess.run(command, cwd=ROOT, env=env, capture_output=True)
    (qa / f'{i}-stdout.raw').write_bytes(process.stdout)
    (qa / f'{i}-stderr.raw').write_bytes(process.stderr)
    results.append({'command': command, 'actual_exit': process.returncode})
    print(json.dumps({'command_index': i, 'actual_exit': process.returncode}))
save(qa / 'receipts.json', results)
assert all(r['actual_exit'] == 0 for r in results)
tree = ET.parse(qa / 'docs.xml')
assert len(tree.findall('.//testcase')) == 23
assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
assert all(ident((ROOT / name).read_bytes()) == expected for name, expected in pins['files'].items())
names = ['preflight.py', 'parent_reference.py', 'baseline_capture.py', 'copied-inputs.json',
         'selected-case.json', 'selected-witness.json', 'baseline-qa/plan.json',
         'baseline-qa/receipts.json', 'baseline-qa/docs.xml']
names += ['prior-status/' + Path(p).name for p in pins['allowed_status_delta']]
names += [f'baseline-qa/{i}-{stream}.raw' for i in range(4) for stream in ['stdout', 'stderr']]
files = {name: (HERE / name).read_bytes() for name in names}
archive = WORK / 'parent-preflight-evidence.tar.gz'
with tarfile.open(archive, 'x:gz') as out:
    for name, body in sorted(files.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(body)
        entry.mode = 0o644
        out.addfile(entry, io.BytesIO(body))
with tarfile.open(archive, 'r:gz') as check:
    members = check.getmembers()
    assert len(members) == len(files)
    assert all(m.isfile() and check.extractfile(m).read() == files[m.name] for m in members)
result = {'status': 'Initial repository QA and parent available-slot reference captured',
          'archive': archive.name, **ident(archive.read_bytes()),
          'members_verified': len(files), 'files': {n: ident(b) for n, b in files.items()},
          'qa_actual_exits': [r['actual_exit'] for r in results], 'docs_tests_passed': 23,
          'baseline_files_unchanged': len(pins['files']),
          'parent_reference_actual_terminal_exit': 0,
          'parent_reference_receipt_kind': 'Normalized observation of prior terminal execution, not raw OS attestation',
          'independent_review_completed': False,
          'scope': 'Metadata/source/available exact arithmetic only; new conditional ledger pending'}
save(WORK / 'parent-preflight-preservation.json', result)
print(json.dumps({k: result[k] for k in ['status', 'members_verified', 'docs_tests_passed',
      'baseline_files_unchanged']}, indent=2))
