"""Pin the approved third static case and copy only declared review inputs."""
import copy
import hashlib
import json
import os
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
PRIOR = AUDIT / 'nonqualifier-trace-2026-11-13'
WORK = AUDIT / 'cap-after-qualifier-trace-2026-11-13'
HERE = Path(__file__).parent
CASE = 'CAP-after-qualifier-f64-GL'


def ident(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def copy_bytes(name, body):
    target = HERE / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(body)
    assert target.read_bytes() == body
    return ident(body)


prior_raw = (PRIOR / 'final-manifest.json').read_bytes()
assert ident(prior_raw)['sha256'] == '7e75893cccc2830a645edf67648fcdf45d87b8f926162e7bf67c80c2f1d5a944'
prior = json.loads(prior_raw)
assert prior['file_count'] == len(prior['files']) == 64
assert all(ident((ROOT / p).read_bytes()) == value for p, value in prior['files'].items())
prior_outcome = json.loads((PRIOR / 'outcome.json').read_text())
assert prior_outcome['increment_complete'] and prior_outcome['independent_review_passed']
copy_map = {}
archive = PRIOR / 'author-evidence.tar.gz'
assert ident(archive.read_bytes())['sha256'] == '8bb7abf9283211a3bc86634a12ac5ec20ba4c27070c4592770cc95619110e45a'
with tarfile.open(archive, 'r:gz') as opened:
    members = opened.getmembers()
    names = [m.name for m in members]
    assert len(names) == len(set(names)) == 776
    assert all(m.isfile() and not m.name.startswith('/') and '\\' not in m.name
               and all(p not in ('', '.', '..') for p in m.name.split('/')) for m in members)
    index_raw = opened.extractfile('evidence-index.json').read()
    assert ident(index_raw)['sha256'] == 'eb341ebe9f912a3e0684cf074489c36dd849b3dd0049af014fa6a9ccbe3c9f23'
    index = json.loads(index_raw)
    assert len(index['files']) == index['file_count'] == 775
    assert set(names) == set(index['files']) | {'evidence-index.json'}
    for name, expected in index['files'].items():
        assert ident(opened.extractfile(name).read()) == expected
    selected = [n for n in index['files'] if n.startswith(('baseline/', 'final/', 'inputs/'))]
    selected += ['tools/run_snapshot.py', 'authority-derivation.json', 'result.json', 'lint-delta.json']
    assert len(selected) == len(set(selected))
    for name in selected:
        copy_map['previous-author/' + name] = copy_bytes(
            'previous-author/' + name, opened.extractfile(name).read())
    copy_map['previous-author-index.json'] = copy_bytes('previous-author-index.json', index_raw)
for name in ['fixtures.json', 'schema-control-fixtures.json', 'record-schemas.json',
             'protocol.json', 'comparison-policies.json', 'schema-control-contract.md',
             'packet-notes.md', 'packet-manifest.json']:
    copy_map['inputs/' + name] = copy_bytes('inputs/' + name, (AUDIT / name).read_bytes())
for name, path in [('pyproject.toml', ROOT / 'pyproject.toml'),
                   ('preparation-contract.md', ROOT / 'docs/developer/a2-compression-budget-protocol.md')]:
    copy_map['inputs/' + name] = copy_bytes('inputs/' + name, path.read_bytes())
fixture = json.loads((HERE / 'inputs/fixtures.json').read_text())
schema_fixture = json.loads((HERE / 'inputs/schema-control-fixtures.json').read_text())
case = next(c for c in fixture['cases'] if c['case_id'] == CASE)
witness = next(w for values in schema_fixture.values() if isinstance(values, list)
               for w in values if isinstance(w, dict) and w.get('declared_case_id') == CASE)
artifacts = witness['artifacts']
request = artifacts['input-bundle.json']['request']
assert not case['mutations']
assert request['input'] == fixture['arrays'][case['request']['input_ref']]
assert request['caps'] == json.loads((HERE / 'inputs/protocol.json').read_text())['caps']
for i, name in enumerate(case['request']['candidate_refs']):
    original = copy.deepcopy(fixture['candidates'][name])
    original['rhos'] = copy.deepcopy(fixture['arrays'][original.pop('rhos_ref')])
    original['coefficients'] = copy.deepcopy(fixture['arrays'][original.pop('coefficients_ref')])
    original['record_type'] = 'candidate'
    assert original == request['candidates'][i]
    assert artifacts['records/candidate-' + str(i) + '.json'] == original
slots = artifacts['failure-index.json']['slots']
assert len(slots) == len(case['required_evidence_slots']) == 22
assert sum(s['status'] == 'complete' for s in slots) == 13
assert sum(s['status'] == 'unknown' for s in slots) == 9
save(HERE / 'selected-case.json', case)
save(HERE / 'selected-witness.json', witness)
copy_map['selected-case.json'] = ident((HERE / 'selected-case.json').read_bytes())
copy_map['selected-witness.json'] = ident((HERE / 'selected-witness.json').read_bytes())
save(HERE / 'copied-inputs.json', copy_map)
tracked = [ROOT / p.decode() for p in subprocess.check_output(
    ['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0') if p]
audit_files = [p for p in AUDIT.rglob('*') if p.is_file() and WORK not in p.parents]
paths = sorted(set(tracked + audit_files + [ROOT / 'docs/developer/a2-compression-budget-protocol.md']))
assert all(p.is_file() and not p.is_symlink() for p in paths)
allowed = ['docs/developer/phase-a-completion.md', 'docs/developer/bug-resolution-tracker.md']
baseline = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'git_stage_sha256': ident(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT))['sha256'],
    'git_stage_encoding': 'git ls-files --stage -z raw bytes',
    'files': {str(p.relative_to(ROOT)): ident(p.read_bytes()) for p in paths},
    'allowed_status_delta': allowed,
    'scope': 'Tracked repository inputs and explicit current A2 evidence root; no profiles, private receipts or ambient scratch',
}
save(WORK / 'baseline-inputs.json', baseline)
result = {'status': 'Approved case and prior completed increment pinned',
          'previous_final_manifest_files_verified': len(prior['files']),
          'previous_author_indexed_files_verified': len(index['files']),
          'previous_checker_sha256': copy_map['previous-author/final/a2_trace.py']['sha256'],
          'baseline_files': len(paths), 'immutable_baseline_files': len(paths) - len(allowed),
          'copied_files': len(copy_map), 'copied_source_directory': str(HERE),
          'case_id': CASE, 'witness_id': witness['witness_id'], 'inventory_slots': len(slots),
          'complete_slots': 13, 'unknown_slots': 9, 'witness_records': len(artifacts),
          'assessments': [{k: v for k, v in a.items() if k != 'slots'}
                          for a in artifacts['result.json']['assessments']],
          'resource_control': case['resource_control'],
          'unknown_payloads_must_remain_absent': True,
          'worker_execution_observed': False,
          'input_files': copy_map}
save(WORK / 'preflight.json', result)
print(json.dumps({k: result[k] for k in ['status', 'baseline_files', 'immutable_baseline_files',
      'copied_files', 'inventory_slots', 'complete_slots', 'unknown_slots', 'witness_records']}, indent=2))
