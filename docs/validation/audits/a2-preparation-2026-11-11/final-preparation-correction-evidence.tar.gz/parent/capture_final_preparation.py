"""Capture final preparation evidence; replay static checks without repair."""
from __future__ import annotations

import collections
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import time

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
SOURCE = Path('/home/davianc/.hermes/cache/scratch/a2-final-preparation-cycle2-66g2mcem')
HERE = Path(__file__).parent


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def ident(raw: bytes) -> dict:
    return {'sha256': sha(raw), 'bytes': len(raw)}


def put(path: Path, obj: dict) -> None:
    assert not path.exists(), path
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')


old = json.loads(Path('/home/davianc/.hermes/cache/scratch/a2-corrected-review-20261111/review-input-manifest.json').read_text())
assert all(sha((ROOT / name).read_bytes()) == value for name, value in old['protected_numerical_inputs'].items())
assert sha(subprocess.check_output(['git', 'ls-files', '--stage'], cwd=ROOT)) == old['protected_index_entries_sha256']
index_path = SOURCE / 'evidence-index.json'
assert sha(index_path.read_bytes()) == 'b154a991d1d9dd51832eace4ac3b3d232792e8f64e1c17c5f9e8aa3c444ff339'
index = json.loads(index_path.read_text())
assert len(index['files']) == 80
entries = {}
replay = HERE / 'static-replay'
assert not replay.exists()
replay.mkdir()
for row in index['files']:
    relative = Path(row['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    path = SOURCE / relative
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    assert ident(raw) == {'sha256': row['sha256'], 'bytes': row['bytes']}, relative
    entries['correction/' + row['path']] = raw
    if '__pycache__' not in relative.parts:
        destination = replay / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
entries['correction/evidence-index.json'] = index_path.read_bytes()
entries['parent/capture_final_preparation.py'] = Path(__file__).read_bytes()

manifest = json.loads((AUDIT / 'packet-manifest.json').read_text())
assert sha((AUDIT / 'packet-manifest.json').read_bytes()) == '2d572491100e76897bc4c298f1a75387110e6942a027da9eeae14b06aadec481'
for row in manifest['files']:
    assert ident((ROOT / row['repo_path']).read_bytes()) == {'sha256': row['sha256'], 'bytes': row['bytes']}
f = json.loads((AUDIT / 'fixtures.json').read_text())
previous = json.loads((SOURCE / 'before/fixtures.json').read_text())
assert len(f['cases']) == 560 and len(f['arrays']) == 840
assert {row['case_id'] for row in previous['cases']} <= {row['case_id'] for row in f['cases']}
assert all(ident(json.dumps(f['arrays'][key], sort_keys=True).encode()) == ident(json.dumps(value, sort_keys=True).encode()) for key, value in previous['arrays'].items())
assert dict(collections.Counter(row['group'] for row in f['cases'])) == f['counts']['groups']
assert sum(len(row['required_evidence_slots']) for row in f['cases']) == 24336

# Execute only the read-only, scratch-output STATIC checker. Never run the
# archived construction/build/finish scripts, which can rewrite the packet.
command = ['uv', 'run', '--frozen', '--no-sync', 'python', '-B', str(replay / 'check_static_representability.py')]
start = time.monotonic_ns()
result = subprocess.run(command, cwd=ROOT, capture_output=True, check=False)
elapsed = time.monotonic_ns() - start
(HERE / 'static-replay.stdout.raw').write_bytes(result.stdout)
(HERE / 'static-replay.stderr.raw').write_bytes(result.stderr)
put(HERE / 'static-replay.process.json', {
    'command': command, 'exit_code': result.returncode,
    'elapsed_monotonic_ns': elapsed, 'stdout_sha256': sha(result.stdout),
    'stderr_sha256': sha(result.stderr),
    'checker_sha256': sha((replay / 'check_static_representability.py').read_bytes()),
    'helper_sha256': sha((replay / 'prep_common.py').read_bytes()),
    'scope': 'STATIC/HYPOTHETICAL preparation only; no actual worker or numerical execution',
})
assert result.returncode == 0, result.stderr.decode(errors='replace')
proof = json.loads(result.stdout)
assert proof['passed'] is True
sizes = json.loads((replay / 'full-size-templates.json').read_text())
nodes = json.loads((replay / 'node-size-templates.json').read_text())
assert len(sizes) == len(nodes) == len(f['cases'])
for row in sizes:
    assert row['full_index_transaction_bytes'] == row['initial_index_bytes'] + row['complete_descriptor_index_bytes'] + row['receipt_allowance_bytes']
blocked = [row for row in sizes if row['preflight_disposition'].startswith('reservation_')]
reported = json.loads((SOURCE / 'final-delivery-report.json').read_text())
assert sorted(row['case_id'] for row in blocked) == sorted(reported['bounded_refusal_case_ids'])
assert len(blocked) == 8
assert max(row['full_index_transaction_bytes'] for row in sizes) == 792318
assert max(max(row[key] for key in ['input_nodes_including_keys', 'index_pending_nodes_including_keys', 'index_complete_template_nodes_including_keys']) for row in nodes) == 36687
assert 792318 > 512 * 1024 and 36687 > 32768

archive_path = AUDIT / 'final-preparation-correction-evidence.tar.gz'
assert not archive_path.exists()
with archive_path.open('wb') as out:
    with gzip.GzipFile(filename='', fileobj=out, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(entries.items()):
                member = tarfile.TarInfo(name)
                member.size = len(raw)
                member.mode = 0o644
                archive.addfile(member, io.BytesIO(raw))
with tarfile.open(archive_path, 'r:gz') as archive:
    members = {member.name: member for member in archive.getmembers()}
    assert set(members) == set(entries)
    for name, raw in entries.items():
        assert archive.extractfile(members[name]).read() == raw
put(AUDIT / 'final-preparation-correction-preservation.json', {
    'scope': 'Final cycle2 preparation evidence; NOT independent approval or production numerical results',
    'archive': archive_path.name, 'archive_identity': ident(archive_path.read_bytes()),
    'files': {name: ident(raw) for name, raw in sorted(entries.items())},
    'indexed_artifacts_verified': len(index['files']),
    'source_index_sha256': sha(index_path.read_bytes()),
    'implementation_authorized': False, 'a2_acceptance_passed': False,
})
summary = {
    'indexed_artifacts_verified': len(index['files']), 'archive_members_verified': len(entries),
    'packet_files_verified': len(manifest['files']) + 1,
    'original_case_ids_preserved': len(previous['cases']),
    'original_raw_descriptors_byte_values_preserved': len(previous['arrays']),
    'counts': f['counts'], 'static_replay_exit_code': result.returncode,
    'hypothetical_bundles': proof['checks']['linked_bundles'],
    'structural_negative_controls': len(proof['structural_negative_controls']),
    'semantic_tamper_controls': len(proof['tamper_controls']),
    'template_refusal_count': len(blocked),
    'template_refusal_case_ids': sorted(row['case_id'] for row in blocked),
    'max_index_transaction_bytes': 792318, 'frozen_failure_reservation_bytes': 512 * 1024,
    'max_template_nodes_including_keys': 36687, 'frozen_json_node_cap': 32768,
    'numeric_inputs_unchanged': len(old['protected_numerical_inputs']),
    'index_entries_unchanged': True,
    'scope': 'Conservative STATIC templates, not actual runtime/hardware infeasibility or numerical failure',
    'readiness': 'blocked_pending_final_independent_review_and_owner_decision',
    'implementation_authorized': False, 'a2_acceptance_passed': False,
}
put(HERE / 'parent-preflight.json', summary)
print(json.dumps(summary, sort_keys=True))
