"""Construct STATIC/HYPOTHETICAL witnesses; NEVER execute represented workers."""
from prep_common import *
from fractions import Fraction as F
import struct
f=read('fixtures.json'); p=read('protocol.json'); s=read('record-schemas.json')
# Refresh synthetic specification-source bindings after final prose edits only.
new_doc_sha=sha((ROOT/'docs/developer/a2-compression-budget-protocol.md').read_bytes())
for c in f['candidates'].values():
    if c.get('producer',{}).get('kind')=='synthetic_control': c['producer']['source']['sha256']=new_doc_sha
dump(AUD/'fixtures.json',f)
byid={c['case_id']:c for c in f['cases']}
def rat(x): return {'num':('-' if x<0 else '')+format(abs(x.numerator),'x'),'den':format(x.denominator,'x')}
def exact(sh,values): return {'shape':C(sh),'values':[rat(F(v)) for v in values]}
def decode(a):
    fmt=('<' if a['byte_order']=='little' else '>')+('f' if a['dtype']=='float32' else 'd')
    return [F(x[0]) for x in struct.iter_unpack(fmt,bytes.fromhex(a['raw_hex']))]
def raw(sh,values,dtype='float64'):
    b=b''.join(struct.pack('<f' if dtype=='float32' else '<d',float(x)) for x in values)
    return dict(dtype=dtype,shape=C(sh),byte_order='little',layout='C',nbytes=len(b),raw_hex=b.hex(),sha256=sha(b))
def exact_synthetic(q):
    x=decode(q['input']); n=len(x); w=[F(1)]; g=[F(1)]
    for k in range(1,n): w.append(w[-1]*(k-1-F(1,2))/k); g.append(g[-1]*(k-F(1,2))/k)
    v=[x[0]]+[x[i]-x[i-1] for i in range(1,n)]; D=[2*sum(w[k]*x[i-k] for k in range(i+1)) for i in range(n)]
    shared={k:exact([n],z) for k,z in [('w',w),('g',g),('v',v),('D',D)]}; cs=[]
    for ca in q['candidates']:
        c=decode(ca['coefficients']); rho=decode(ca['rhos']); gh=[F(1)]+[sum(a*b**(k-1) for a,b in zip(c,rho)) for k in range(1,n)]
        eps=max(abs(a-b) for a,b in zip(gh,g)); wh=[gh[0]]+[gh[k]-gh[k-1] for k in range(1,n)]
        L=[[2*wh[i-j] if j<=i else F(0) for j in range(n)] for i in range(n)]; Dh=[sum(a*b for a,b in zip(row,x)) for row in L]; grad=[F(2,n)*sum(L[i][j]*Dh[i] for i in range(n)) for j in range(n)]
        B=[F(0)]+[2*eps*sum(abs(a) for a in v[:i]) for i in range(1,n)]
        cs.append({k:exact(sh,z) for k,sh,z in [('g_hat',[n],gh),('residual',[n],[a-b for a,b in zip(gh,g)]),('signed_fitted_weights',[n],wh),('L_hat',[n,n],[a for row in L for a in row]),('D_hat',[n],Dh),('error',[n],[abs(a-b) for a,b in zip(Dh,D)]),('B',[n],B),('epsilon',[],[eps]),('analytic_input_gradient',[n],grad)]})
    return shared,cs

def build(case_id,kind='pending',reason='not_evaluated'):
    case=byid[case_id]; q=expanded(case,f,p); invalid=kind=='invalid'
    bundle=input_bundle(case,q,not invalid); bh=dh(bundle); pr=process(q,'not_launched' if invalid or kind=='unsupported' else kind if kind in ['barrier','timeout','unconfirmed'] else 'normal',bh)
    launch=dict(record_type='launch_receipt',run_id=pr['run_id'],process_id=pr['process_id'],case_id=case_id,request_id=case_id,input_bundle_sha256=bh,command=C(pr['command']),pid=None if pr['termination']=='not_launched' else 123,launch_monotonic_ns=None if pr['termination']=='not_launched' else 12,status='not_launched' if pr['termination']=='not_launched' else 'launched',barrier='held' if kind=='barrier' else 'not_used',sources=C(bundle['sources']))
    pr['launch_receipt_sha256']=None if pr['termination']=='not_launched' else dh(launch)
    idx=index(case,q,pr,bh); idx['status']='invalid_request' if invalid else 'indeterminate'; idx['reasons']=[reason]
    artifacts={'input-bundle.json':bundle,'records/launch.json':launch}
    if not invalid:
        artifacts['records/request.json']=q
        for i,ca in enumerate(q['candidates']): artifacts[f'records/candidate-{i}.json']=ca
    for z in idx['slots']:
        z['status']='not_evaluated' if invalid else 'unknown'; z['reason']=reason; z['reasons']=[reason]
    # Complete synthetic exact evidence only; NOT future real fit arrays.
    complete=kind in ['selected','nonqualify','full','knownbad']; partial=kind=='partial'
    if complete or partial or kind=='afterqual':
        shared,cs=exact_synthetic(q)
        for group,vals in [(None,shared)]+list(enumerate(cs)):
            if kind=='knownbad' and group==0: continue
            if kind=='afterqual' and group==1: continue
            rows=[z for z in idx['slots'] if z['candidate_index']==group]
            if partial: rows=[z for z in rows if z['quantity']=='D']
            if not rows: continue
            source={'repo_path':'docs/developer/a2-compression-budget-protocol.md','sha256':new_doc_sha}
            if group is None:
                cfg=dict(history='host_exact',operator=q['operator'],n=q['input']['shape'][0],alpha=C(q['alpha']),dt=C(q['dt']),grid='uniform',lower_terminal=C(q['lower_terminal']),prehistory='zero')
                producer=dict(kind='host_exact',entrypoint='STATIC-exact-formulas-NOT-WORKER',source=source,policy_id=PID,backend='host',mode='shared')
            else: cfg=C(q['candidates'][group]['configuration']); producer=C(q['candidates'][group]['producer'])
            payloads={z['slot_id']:C(vals[z['quantity']]) for z in rows}
            if partial:
                for payload in payloads.values(): payload['shape']=[1]; payload['values']=payload['values'][:1]
            bid='host-X' if group is None else 'host-'+str(group)
            binding=dict(record_type='producer_binding',binding_id=bid,run_id=pr['run_id'],process_id=pr['process_id'],invocation_id='inv-'+bid,observation_id='obs-'+bid,case_id=case_id,request_id=case_id,candidate_id=None if group is None else q['candidates'][group]['stable_id'],candidate_index=group,input_bundle_sha256=bh,packet_manifest_sha256=HYP,launch_receipt_sha256=dh(launch),policy_id=PID,mode='shared' if group is None else 'synthetic',branch='base',configuration=cfg,producer=producer,sources=C(bundle['sources']),input=rawdesc(q['input']),alpha=rawdesc(f['working_scalars'][q['input']['dtype']]['alpha']),dt=rawdesc(f['working_scalars'][q['input']['dtype']]['dt']),h=None,direction=None,returned=[dict(slot_id=z['slot_id'],quantity=z['quantity'],descriptor=descriptor(payloads[z['slot_id']])) for z in rows])
            artifacts['records/binding-'+bid+'.json']=binding
            for z in rows:
                payload=payloads[z['slot_id']]; st='partial' if partial else 'complete'; rs=reason if partial else 'none'
                slot=dict(record_type='slot',slot_id=z['slot_id'],case_id=case_id,candidate_id=z['candidate_id'],candidate_index=group,mode=z['mode'],branch=z['branch'],quantity=z['quantity'],status=st,reason=rs,reasons=[rs],raw_array=None,exact_array=payload,producer_binding_sha256=dh(binding))
                path='arrays/'+z['slot_id']+'.json'; artifacts[path]=slot; z.update(status=st,reason=rs,reasons=[rs],completed_shape=C(payload['shape']),artifact={'path':path,'bytes':len(canonical(slot)),'sha256':dh(slot)})
        if complete: idx['status']='complete'; idx['reasons']=['none']
    if kind=='knownbad':
        for z in idx['slots']:
            if z['candidate_index']==0: z.update(status='not_applicable',reason='configuration_mismatch',reasons=['configuration_mismatch'])
    all_reasons=[reason]
    if 'duplicate-id' in case_id: all_reasons=['duplicate_id','duplicate_content']
    if case_id.startswith('COMBINED-incompatible'): all_reasons=['missing_producer_binding','configuration_mismatch']
    if not complete:
        idx['reasons']=C(all_reasons)
        for z in idx['slots']:
            if len(all_reasons)>1 and (invalid or z['candidate_index']==0): z['reasons']=C(all_reasons)
    # A successful candidate-free full encoding uses exactly computed small
    # synthetic D, NOT invented production fitter/full-run observations.
    if kind=='full':
        payload=raw(q['input']['shape'],decode_synth_D(artifacts),q['input']['dtype'])
        cfg=dict(history='full',operator=q['operator'],kernel='gl_signed',n=q['input']['shape'][0],alpha=C(q['alpha']),dt=C(q['dt']),grid='uniform',lower_terminal=C(q['lower_terminal']),prehistory='zero')
        prod=dict(kind='actual_full_history',entrypoint='hpfracc.ops.fractional.'+('grunwald_letnikov' if q['operator']=='GL' else 'riemann_liouville'),source=next(z for z in bundle['sources'] if z['repo_path'].endswith('fractional.py')),lock_sha256=sha((ROOT/'uv.lock').read_bytes()),policy_id=PID,backend='cpu',working_dtype=q['input']['dtype'],x64=q['input']['dtype']=='float64',jax_version='HYPOTHETICAL-NOT-OBSERVED',device_class='HYPOTHETICAL-NOT-OBSERVED',mode='eager')
        sid='hyp-full_output'; binding=C(next(v for v in artifacts.values() if v.get('record_type')=='producer_binding')); binding.update(binding_id='full',invocation_id='inv-full',observation_id='obs-full',candidate_id=None,candidate_index=None,mode='eager',configuration=cfg,producer=prod,returned=[dict(slot_id=sid,quantity='full_output',descriptor=rawdesc(payload))]); artifacts['records/binding-full.json']=binding
        slot=dict(record_type='slot',slot_id=sid,case_id=case_id,candidate_id=None,candidate_index=None,mode='eager',branch='base',quantity='full_output',status='complete',reason='none',reasons=['none'],raw_array=payload,exact_array=None,producer_binding_sha256=dh(binding)); artifacts['arrays/'+sid+'.json']=slot
        obs=dict(record_type='observation',observation_id='obs-full',case_id=case_id,candidate_id=None,candidate_index=None,policy_id=PID,producer=prod,configuration=cfg,mode='eager',branch='base',input_bundle_sha256=bh,base_observation_id=None,slots=[slot],status='complete',reasons=['none'],run_id=pr['run_id'],process_id=pr['process_id'],invocation_id='inv-full',launch_receipt_sha256=dh(launch),producer_binding_sha256=dh(binding)); artifacts['records/observation-obs-full.json']=obs
        # Full synthetic is a separate declared scenario, with extra slot and comparison explicitly inventoried.
        inv={k:slot[k] for k in ['slot_id','candidate_id','candidate_index','mode','branch','quantity']}; bundle['required_slots'].append(inv)
        cmp=dict(record_type='comparison',comparison_id='hyp-full-comparison',case_id=case_id,candidate_id=None,candidate_index=None,policy_id=q['input']['dtype']+'-forward_full_exact',a_slot_id=sid,reference_slot_id='S-X-D',status='pass',reasons=['none'])
        bundle['required_comparisons'].append({k:cmp[k] for k in ['comparison_id','candidate_id','candidate_index','policy_id','a_slot_id','reference_slot_id']}); idx['comparisons'].append(cmp)
        idx['slots'].append(dict(**inv,status='complete',reason='none',reasons=['none'],expected_shape=C(payload['shape']),completed_shape=C(payload['shape']),artifact={'path':'arrays/'+sid+'.json','bytes':len(canonical(slot)),'sha256':dh(slot)}))
        # Since bundle changed before launch, rebuild downstream links once topologically.
        rebind(artifacts,idx,pr,bundle,launch)
    assessments=[]
    def slot_from_row(z):
        if z['artifact']: return C(artifacts[z['artifact']['path']])
        return {**{k:C(z[k]) for k in ['slot_id','candidate_id','candidate_index','mode','branch','quantity','status','reason','reasons']},'record_type':'slot','case_id':case_id,'raw_array':None,'exact_array':None,'producer_binding_sha256':None}
    for i,ca in enumerate(q['candidates']):
        rows=[slot_from_row(z) for z in idx['slots'] if z['candidate_index']==i]
        st='known_ineligible' if kind=='knownbad' and i==0 else 'known_qualifying' if kind=='afterqual' and i==0 or complete and i==1 else 'known_rejected_by_bound' if complete else 'unknown'
        assessments.append(dict(candidate_id=ca['stable_id'],candidate_index=i,status=st,reasons=['configuration_mismatch'] if st=='known_ineligible' else ['none'] if st!='unknown' else C(all_reasons) if i==0 else [reason],qualifies=True if st=='known_qualifying' else False if st in ['known_rejected_by_bound','known_ineligible'] else None,slots=rows))
    result_status='selected' if complete and len(q['candidates'])>1 else 'no_supplied_candidate_meets_bound' if complete else 'invalid_request' if invalid else 'indeterminate'
    result=dict(record_type='result',case_id=case_id,request_id=case_id,input_bundle_sha256=dh(bundle),packet_manifest_sha256=HYP,status=result_status,selected_id=q['candidates'][1]['stable_id'] if result_status=='selected' else None,reasons=['none'] if complete else C(all_reasons),assessments=assessments,shared_slots=[slot_from_row(z) for z in idx['slots'] if z['candidate_index'] is None],primitive_count=0,max_normalized_bits=0,evidence_bytes=0,arithmetic_verified=False,total_numerical_certified=False,a2_acceptance_passed=False,implementation_authorized=False)
    result['evidence_bytes']=sum(len(canonical(v)) for v in artifacts.values())
    artifacts['result.json']=result; artifacts['records/process.json']=C(pr); idx['process']=C(pr)
    artifacts['records/output-control.json']=dict(record_type='output_control',request_id=case_id,root_token='hyp-private-root',status='safe',fresh_private_root=True,subdirs_private=True,nofollow_verified=True,regular_owned_single_link=True,containment_verified=True,reasons=['none'])
    prior=sum(len(canonical(v)) for v in artifacts.values())
    initial=C(idx); initial.update(status='not_evaluated',reasons=['not_evaluated'],process=process(q,'not_launched',dh(bundle)))
    for z in initial['slots']: z.update(status='not_evaluated',reason='not_evaluated',reasons=['not_evaluated'],completed_shape=None,artifact=None)
    for z in initial['comparisons']+initial['binding_checks']: z.update(status='not_evaluated',reasons=['not_evaluated'])
    before_initial=sum(len(canonical(v)) for k,v in artifacts.items() if k in ['input-bundle.json','records/request.json','records/output-control.json'] or k.startswith('records/candidate-'))
    initial['bytes_accounting'].update(live_bytes=before_initial,cumulative_written_bytes=before_initial,reserved_final_transaction_bytes=524288)
    old_index_bytes=len(canonical(initial))
    result['evidence_bytes']=sum(len(canonical(v)) for k,v in artifacts.items() if k!='result.json')+old_index_bytes
    prior=sum(len(canonical(v)) for v in artifacts.values())
    idx['bytes_accounting'].update(live_bytes=prior+old_index_bytes,cumulative_written_bytes=prior+old_index_bytes,reserved_final_transaction_bytes=524288)
    artifacts['failure-index.json']=idx
    artifacts['records/export.json']=dict(record_type='supervisor_export',run_id=pr['run_id'],process_id=pr['process_id'],case_id=case_id,input_bundle_sha256=dh(bundle),process_sha256=dh(pr),failure_index_sha256=dh(idx),failure_index_bytes=len(canonical(idx)),index_write=phase('observed',70000000000,70000000010,'none'),status='complete',reasons=['none'])
    manifest=dict(record_type='run_manifest',run_id=pr['run_id'],case_id=case_id,files=[{'path':path,'bytes':len(canonical(v)),'sha256':dh(v)} for path,v in artifacts.items()],self_hash_excluded=True); artifacts['run-manifest.json']=manifest
    return dict(witness_id=kind+'-'+case_id,label='STATIC/HYPOTHETICAL REPRESENTABILITY: NOT ACTUAL WORKER/PROCESS/FITTER OUTPUT',declared_case_id=case_id,kind=kind,initial_failure_index=initial,artifacts=artifacts)
def decode_synth_D(a): return [F(int(z['num'],16),int(z['den'],16)) for z in a['arrays/S-X-D.json']['exact_array']['values']]
def rebind(artifacts,idx,pr,bundle,launch):
    bh=dh(bundle); launch['input_bundle_sha256']=bh; lh=dh(launch); pr.update(input_bundle_sha256=bh,launch_receipt_sha256=lh); idx['input_bundle_sha256']=bh
    for v in artifacts.values():
        if v.get('record_type')=='producer_binding': v.update(input_bundle_sha256=bh,launch_receipt_sha256=lh)
    bindings={v['binding_id']:v for v in artifacts.values() if v.get('record_type')=='producer_binding'}
    for path,v in artifacts.items():
        if v.get('record_type')=='slot':
            b=next(b for b in bindings.values() if any(z['slot_id']==v['slot_id'] for z in b['returned'])); v['producer_binding_sha256']=dh(b)
        elif v.get('record_type')=='observation':
            b=next(b for b in bindings.values() if b['observation_id']==v['observation_id']); v.update(input_bundle_sha256=bh,launch_receipt_sha256=lh,producer_binding_sha256=dh(b))
    for z in idx['slots']:
        if z['artifact']:
            v=artifacts[z['artifact']['path']]; z['artifact'].update(bytes=len(canonical(v)),sha256=dh(v))

w=[]
for case,kind,reason in [('CAP-after-qualifier-f64-GL','afterqual','primitive_cap'),('FIT-ramp-tau0-f64-GL','pending','missing_producer_binding'),('REF-PASS-f64-GL','selected','none'),('REF-FAIL-f64-GL','nonqualify','none'),('REF-PASS-f64-GL','full','none'),('REF-PASS-f64-GL','partial','primitive_cap'),('EDGE-l1-f64-GL','knownbad','configuration_mismatch'),('REQUEST-empty-f64-GL','invalid','empty_candidates'),('REQUEST-duplicate-id-f64-GL','invalid','duplicate_id'),('REQUEST-N18-f64-GL','unsupported','unsupported_reference'),('CAP-wall-f64-GL','barrier','watchdog'),('REF-PASS-f64-GL','timeout','watchdog'),('REF-PASS-f64-GL','unconfirmed','exit_unconfirmed'),('CAP-ops-f64-GL','pending','primitive_cap'),('CAP-bits-f64-GL','pending','normalized_bit_cap'),('CAP-bytes-f64-GL','pending','evidence_cap'),('COMBINED-incompatible-unavailable-f64-GL','pending','missing_producer_binding')]: w.append(build(case,kind,reason))
# Every future full observation binding represented without future observed arrays.
fulls=[]
for case in f['cases']:
 if case['group']!='FIT-REAL': continue
 q=expanded(case,f,p)
 for z in case['required_full_observations']:
    inv=next(v for v in inventory(case,q) if v['slot_id']==z['slot_id']); slot=dict(record_type='slot',case_id=q['case_id'],**inv,status='not_evaluated',reason='not_evaluated',reasons=['not_evaluated'],raw_array=None,exact_array=None,producer_binding_sha256=None)
    cfg=dict(history='full',operator=q['operator'],kernel='gl_signed',n=17,alpha=C(q['alpha']),dt=C(q['dt']),grid='uniform',lower_terminal=C(q['lower_terminal']),prehistory='zero')
    obs=dict(record_type='observation',observation_id=z['observation_id'],case_id=q['case_id'],candidate_id=None,candidate_index=None,policy_id=PID,producer=None,configuration=cfg,mode=z['mode'],branch='base',input_bundle_sha256='2'*64,base_observation_id=None,slots=[slot],status='not_evaluated',reasons=['not_evaluated'],run_id='hyp-run',process_id='hyp-process',invocation_id='inv-'+z['mode']+'-full',launch_receipt_sha256='3'*64,producer_binding_sha256=None)
    fulls.append({'case_id':case['case_id'],'observation':obs,'comparison':next(v for v in comparisons(case,q) if v['comparison_id']==z['comparison_id'])})
# Typed status matrix, deliberately isolated from run-result assertions.
base=next(b for b in w if b['kind']=='selected')['artifacts']; sample=C(base['arrays/S-0-B.json']); matrix=[]
for status,reason in [('complete','none'),('partial','incomplete_evidence'),('unknown','missing_raw_artifact'),('not_evaluated','not_evaluated'),('not_applicable','malformed_fit'),('not_applicable','configuration_mismatch'),('not_applicable','unselected_candidate'),('not_applicable','stage_not_used'),('not_applicable','unused_quantity'),('not_applicable','singleton_fd_adjacency')]:
    x=C(sample); x.update(status=status,reason=reason,reasons=[reason]);
    if status=='partial': x['exact_array']['shape']=[1]; x['exact_array']['values']=x['exact_array']['values'][:1]
    if status not in ['complete','partial']: x.update(raw_array=None,exact_array=None,producer_binding_sha256=None)
    matrix.append({'route':'arrays/'+x['slot_id']+'.json','record':x,'label':'isolated STATIC status-shape witness; binding context tested in linked bundles'})
fitcase=next(c for c in f['cases'] if c['group']=='FIT-REAL'); q=expanded(fitcase,f,p)
for typ,proto in [('comparison',comparisons(fitcase,q)[0]),('binding_check',checks(fitcase,q)[0])]:
 for status,reason in [('pass','none'),('fail','comparison_failed'),('unknown','missing_producer_binding'),('not_evaluated','not_evaluated'),('not_applicable','unselected_candidate')]:
    x=C(proto); x.update(status=status,reasons=[reason]);
    if typ=='binding_check' and status in ['pass','fail']: x.update(observation_id='hyp-invocation',reference_observation_id='hyp-base')
    matrix.append({'route':('records/comparison-'+x['comparison_id']+'.json') if typ=='comparison' else 'records/check-'+x['check_id']+'.json','record':x,'label':'isolated STATIC disposition witness, not a comparison measurement'})
for reason in ['reservation_exceeded','input_envelope_exceeded','unsafe_output_target']:
    matrix.append({'route':'records/preflight-failure.json','record':dict(record_type='bounded_failure',request_id=None,received_bytes=None,retained_prefix_hex='7b',retained_prefix_sha256=sha(b'{'),status='indeterminate',reasons=[reason],worker_launched=False,implementation_authorized=False,a2_acceptance_passed=False,arithmetic_verified=False,total_numerical_certified=False),'label':'bounded STATIC refusal, retained-prefix digest is NOT full-input digest'})
for status,reason in [('unavailable','timing_unavailable'),('not_applicable','stage_not_used'),('not_evaluated','not_evaluated'),('observed','none')]: matrix.append({'definition':'phase_timing','record':phase(status,1 if status=='observed' else None,2 if status=='observed' else None,reason),'label':'STATIC timing status witness'})
# Standalone candidate_spec root witness, no fit arrays.
matrix.append({'route':'records/candidate-0.json','record':q['candidates'][0],'label':'future unobserved producer-call specification, NOT observation'})
for status,reason in [('unknown','missing_producer_binding'),('not_evaluated','not_evaluated'),('not_applicable','unselected_candidate')]:
    obs=C(fulls[0]['observation']); ca=q['candidates'][0]; obs.update(observation_id='hyp-fit-ad-base',case_id=q['case_id'],candidate_id=ca['stable_id'],candidate_index=0,configuration=C(ca['configuration']),branch='ad-base',status=status,reasons=[reason]); sl=obs['slots'][0]; sl.update(slot_id='hyp-fit-output',case_id=q['case_id'],candidate_id=ca['stable_id'],candidate_index=0,branch='ad-base',quantity='output',status=status,reason=reason,reasons=[reason]); matrix.append({'route':'records/observation-hyp-fit-ad-base.json','record':obs,'label':'STATIC unobserved candidate observation disposition; NO fitted arrays/producer invented'})
term=C(next(b for b in w if b['kind']=='timeout')['artifacts']['records/process.json']); term.update(termination='terminate',exit_code=-15); term['phases']['watchdog']['end_ns']=term['phases']['grace']['end_ns']; term['phases']['watchdog']['elapsed_ns']=term['phases']['watchdog']['end_ns']-term['phases']['watchdog']['start_ns']; term['elapsed_monotonic_ns']=term['phases']['watchdog']['elapsed_ns']; term['phases']['kill_to_exit']=phase(); matrix.append({'route':'records/process.json','record':term,'label':'STATIC terminate-within-grace confirmed-exit variant'})
for status,reason in [('unsafe','unsafe_output_target'),('unavailable','unsafe_output_target')]:
    control=C(next(b for b in w if b['kind']=='selected')['artifacts']['records/output-control.json']); control.update(status=status,fresh_private_root=False,subdirs_private=False,nofollow_verified=False,regular_owned_single_link=False,containment_verified=False,reasons=[reason]); matrix.append({'route':'records/output-control.json','record':control,'label':'STATIC unsafe/unavailable refusal, NOT actual filesystem observation'})
for status,reason in [('missing','missing_raw_artifact'),('corrupt','corrupt_raw_artifact'),('not_evaluated','not_evaluated')]:
    ca=C(base['records/candidate-0.json']); ca.update(artifact_status=status,rhos=None,coefficients=None,reasons=[reason]); matrix.append({'route':'records/candidate-0.json','record':ca,'label':'STATIC supplied-evidence availability variant, no unavailable bytes invented'})
ex=C(base['records/export.json']); ex.update(index_write=phase('unavailable',reason='timing_unavailable'),status='indeterminate',reasons=['timing_unavailable']); matrix.append({'route':'records/export.json','record':ex,'context_bundle':'selected-REF-PASS-f64-GL','label':'STATIC later export with unavailable timing, targets remain exactly linked'})
mutants=[{'id':name,'target':target,'replacement':value,'rehash_outer':True,'expected':'reject_semantic_relationship'} for name,target,value in [('swapped-receipt','binding/launch_receipt_sha256','4'*64),('swapped-case','binding/case_id','OTHER-case'),('swapped-branch','binding/branch','order-h0-plus'),('swapped-source','binding/producer/source/sha256','5'*64),('swapped-array','binding/returned/0/descriptor/sha256','6'*64),('wrong-null-candidate','observation/candidate_id','invented-fit'),('rank-squeeze','index/slots/0/expected_shape',[3,1]),('grace-not-recorded','process/phases/grace/status','not_applicable'),('zero-barrier-released','process/barrier','released'),('none-for-knownbad','slot/reason','not_evaluated'),('unsafe-symlink-target','output/containment_verified',False),('missing-check','index/binding_checks',[])]]
packet=dict(label='STATIC/HYPOTHETICAL REPRESENTABILITY ONLY; NOT ACTUAL WORKER/PROCESS/FITTER OUTPUTS',protocol_id=PID,hypothetical_external_packet_sha256=HYP,implementation_authorized=False,a2_acceptance_passed=False,arithmetic_verified=False,total_numerical_certified=False,bundles=w,future_full_bindings=fulls,status_matrix=matrix,tamper_controls=mutants,limits='No future real fit arrays supplied. Synthetic exact arrays only from unchanged finite formulas on REF inputs. Isolated status records are not completed numerical assertions. Real process receipts, comparisons, producer authentication and portable operational validation remain unimplemented.')
dump(AUD/'schema-control-fixtures.json',packet)
print(json.dumps({'bundles':len(w),'future_full_bindings':len(fulls),'status_matrix':len(matrix),'tamper_controls':len(mutants),'label':packet['label']},indent=2))
