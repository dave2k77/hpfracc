"""Scoped static packet construction ONLY; no numerical/runtime imports."""
from pathlib import Path
from copy import deepcopy as C
from collections import Counter
import json, hashlib
ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
HERE=Path(__file__).parent
AUD=ROOT/'docs/validation/audits/a2-preparation-2026-11-11'
def load(n): return json.loads((HERE/'before'/n).read_text())
def emit(n,v):
    assert n in {'protocol.json','fixtures.json','record-schemas.json','schema-control-fixtures.json'}
    (AUD/n).write_text(json.dumps(v,indent=2,ensure_ascii=True,allow_nan=False)+'\n')
def digest(v): return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()).hexdigest()
def obj(**props): return {'type':'object','additionalProperties':False,'required':list(props),'properties':props}
def ref(n): return {'$ref':'#/$defs/'+n}
def nullable(s): return {'anyOf':[C(s),{'type':'null'}]}
def arr(s,n=2048,minimum=0): return {'type':'array','items':C(s),'minItems':minimum,'maxItems':n}
def en(*xs): return {'enum':list(xs)}
def integer(mx=9223372036854775807,mn=0): return {'type':'integer','minimum':mn,'maximum':mx}
def string(mx=256): return {'type':'string','pattern':'^[ -~]*$','maxLength':mx}
def add(d,**props):
    d['properties'].update(C(props)); d['required']+=list(props)
s=load('record-schemas.json'); d=s['$defs']; p=load('protocol.json'); f=load('fixtures.json')
# Preserve original enums and add only dispositions needed by the findings.
reasons=C(d['slot']['properties']['reason']['enum'])
extra=['unselected_candidate','stage_not_used','unused_quantity','singleton_fd_adjacency','timing_unavailable','timing_out_of_envelope','unsafe_output_target','reservation_exceeded','exit_unconfirmed']
reasons+=extra
def replace_enums(x):
    if isinstance(x,dict):
        if x.get('enum')==d['slot']['properties']['reason']['enum']: x['enum']=C(reasons)
        for v in x.values(): replace_enums(v)
    elif isinstance(x,list):
        for v in x: replace_enums(v)
# avoid recursive comparison against changing shared reference
def update_reasons(x):
    if isinstance(x,dict):
        if 'enum' in x and 'invalid_tau' in x['enum']: x['enum']=C(reasons)
        for v in x.values(): update_reasons(v)
    elif isinstance(x,list):
        for v in x: update_reasons(v)
update_reasons(s)
d['reason']=en(*reasons); d['reasons']=arr(ref('reason'),32,1)
ci=nullable(integer(31)); cid=nullable(ref('id'))
for name in ['slot','assessment','observation','comparison','binding_check','inventory_entry','index_slot']:
    add(d[name],candidate_index=ci)
# Reasons list preserves all observable causes; old primary reason retained.
for name in ['slot','index_slot']: add(d[name],reasons=ref('reasons'))
add(d['slot'],record_type=en('slot'))
for name in ['expected_shape','completed_shape']:
    x=d['index_slot']['properties'][name]
    if 'anyOf' in x: x=x['anyOf'][0]
    x['items']['maximum']=1024
# Full variant is truthful and disjoint, not a fitted candidate with null ID.
d['full_configuration']=obj(history=en('full'),operator=en('GL','RL'),kernel=en('gl_signed'),n=integer(1024,1),alpha=ref('rat'),dt=ref('rat'),grid=en('uniform'),lower_terminal=ref('rat'),prehistory=en('zero'))
d['full_producer']=obj(kind=en('actual_full_history'),entrypoint=en('hpfracc.ops.fractional.grunwald_letnikov','hpfracc.ops.fractional.riemann_liouville'),source=ref('source'),lock_sha256=ref('sha'),policy_id=ref('id'),backend=en('cpu','cuda'),working_dtype=en('float32','float64'),x64={'type':'boolean'},jax_version=string(),device_class=string(),mode=en('eager','jit'))
d['host_configuration']=obj(history=en('host_exact'),operator=en('GL','RL'),n=integer(17,1),alpha=ref('rat'),dt=ref('rat'),grid=en('uniform'),lower_terminal=ref('rat'),prehistory=en('zero'))
d['host_producer']=obj(kind=en('host_exact'),entrypoint=string(),source=ref('source'),policy_id=ref('id'),backend=en('host'),mode=en('shared','synthetic','eager','jit'))
d['observation']['properties']['candidate_id']=C(cid)
d['observation']['properties']['configuration']={'oneOf':[ref('configuration'),ref('full_configuration')]}
d['observation']['properties']['producer']={'oneOf':[ref('producer'),ref('full_producer')]}
d['observation']['properties']['status']=en('complete','unknown','not_evaluated','not_applicable')
d['candidate']['properties']['producer']=nullable(ref('producer'))
# Supplied FUTURE producer-call specs are not actual runtime producer receipts.
call_example=next(v['producer_call'] for v in f['candidates'].values() if 'producer_call' in v)
d['producer_call_spec']=obj(entrypoint=string(),source=ref('source'),lock_sha256=ref('sha'),alpha_ref=en('request/alpha'),n=integer(1024,1),n_poles=integer(512,1),t_max=ref('rat'),kernel=en('gl'),method=en('scaled_tail'),expected_dtype=en('float32','float64'),x64={'type':'boolean'})
assert set(call_example)==set(d['producer_call_spec']['required'])
d['candidate_spec']=obj(record_type=en('candidate_spec'),stable_id=ref('id'),configuration=ref('configuration'),producer_call=ref('producer_call_spec'),rhos= en(None),coefficients=en(None),artifact_status=en('not_evaluated'),reasons=ref('reasons'))
d['supplied_candidate']={'oneOf':[ref('candidate'),ref('candidate_spec')]}
d['request']['properties']['candidates']['items']=ref('supplied_candidate')
d['observation']['properties']['producer']=nullable(d['observation']['properties']['producer'])
# Closed raw/exact descriptors carry NO wrapper or producer-binding digest.
d['raw_descriptor']=C(d['raw_array']); d['raw_descriptor']['required'].remove('raw_hex'); del d['raw_descriptor']['properties']['raw_hex']
d['exact_descriptor']=obj(shape=C(d['exact_array']['properties']['shape']),values_count=integer(289),payload_sha256=ref('sha'))
d['payload_descriptor']={'oneOf':[ref('raw_descriptor'),ref('exact_descriptor')]}
d['named_payload']=obj(slot_id=ref('id'),quantity=C(d['slot']['properties']['quantity']),descriptor=ref('payload_descriptor'))
d['phase_timing']=obj(status=en('observed','unavailable','not_applicable','not_evaluated'),start_ns=nullable(integer()),end_ns=nullable(integer()),elapsed_ns=nullable(integer()),reason=ref('reason'))
d['launch_receipt']=obj(record_type=en('launch_receipt'),run_id=ref('id'),process_id=ref('id'),case_id=ref('id'),request_id=ref('id'),input_bundle_sha256=ref('sha'),command=C(d['process']['properties']['command']),pid=nullable(integer(2147483647,1)),launch_monotonic_ns=nullable(integer()),status=en('launched','not_launched'),barrier=en('held','not_used'),sources=arr(ref('source'),125,1))
d['producer_binding']=obj(record_type=en('producer_binding'),binding_id=ref('id'),run_id=ref('id'),process_id=ref('id'),invocation_id=ref('id'),observation_id=ref('id'),case_id=ref('id'),request_id=ref('id'),candidate_id=cid,candidate_index=ci,input_bundle_sha256=ref('sha'),packet_manifest_sha256=ref('sha'),launch_receipt_sha256=ref('sha'),policy_id=ref('id'),mode=en('shared','synthetic','eager','jit'),branch=ref('id'),configuration={'oneOf':[ref('configuration'),ref('full_configuration'),ref('host_configuration')]},producer={'oneOf':[ref('producer'),ref('full_producer'),ref('host_producer')]},sources=arr(ref('source'),125,1),input=ref('raw_descriptor'),alpha=ref('raw_descriptor'),dt=ref('raw_descriptor'),h=nullable(ref('raw_descriptor')),direction=nullable(ref('raw_descriptor')),returned=arr(ref('named_payload'),64,1))
add(d['observation'],run_id=ref('id'),process_id=ref('id'),invocation_id=ref('id'),launch_receipt_sha256=ref('sha'),producer_binding_sha256=nullable(ref('sha')))
# Timings not self-referential: final process before final index before export.
add(d['process'],process_id=ref('id'),case_id=ref('id'),request_id=ref('id'),input_bundle_sha256=ref('sha'),launch_receipt_sha256=nullable(ref('sha')),exit_confirmed={'type':'boolean'},barrier=en('held','released','not_used','not_launched'),phases=obj(preflight=ref('phase_timing'),watchdog=ref('phase_timing'),grace=ref('phase_timing'),kill_to_exit=ref('phase_timing')))
d['process']['properties']['elapsed_monotonic_ns']=nullable(integer())
d['supervisor_export']=obj(record_type=en('supervisor_export'),run_id=ref('id'),process_id=ref('id'),case_id=ref('id'),input_bundle_sha256=ref('sha'),process_sha256=ref('sha'),failure_index_sha256=ref('sha'),failure_index_bytes=integer(524288),index_write=ref('phase_timing'),status=en('complete','indeterminate'),reasons=ref('reasons'))
d['candidate_occurrence']=obj(candidate_index=integer(31),candidate_id=ref('id'))
for name in ['input_bundle','failure_index']: add(d[name],candidate_occurrences=arr(ref('candidate_occurrence'),32))
# Fixed typed check IDs before launch and all dispositions after kill.
add(d['binding_check'],check_id=ref('id'))
d['comparison_inventory']=obj(comparison_id=ref('id'),candidate_id=cid,candidate_index=ci,policy_id=ref('id'),a_slot_id=nullable(ref('id')),reference_slot_id=nullable(ref('id')))
d['binding_inventory']=obj(check_id=ref('id'),candidate_id=ref('id'),candidate_index=integer(31),mode=en('eager','jit'),branch=ref('id'),reference_branch=ref('id'),comparison=C(d['binding_check']['properties']['comparison']))
add(d['input_bundle'],required_comparisons=arr(ref('comparison_inventory')),required_binding_checks=arr(ref('binding_inventory')))
add(d['failure_index'],comparisons=arr(ref('comparison')),binding_checks=arr(ref('binding_check')),bytes_accounting=obj(live_bytes=integer(16777216),cumulative_written_bytes=integer(16777216),reserved_final_transaction_bytes=integer(524288)))
d['failure_index']['properties']['status']=en('not_evaluated','indeterminate','invalid_request','complete')
d['run_manifest']=obj(record_type=en('run_manifest'),run_id=ref('id'),case_id=ref('id'),files=arr(obj(path=string(96),bytes=integer(16777216),sha256=ref('sha')),4096),self_hash_excluded=en(True))
d['output_control']=obj(record_type=en('output_control'),request_id=ref('id'),root_token=ref('id'),status=en('safe','unsafe','unavailable'),fresh_private_root={'type':'boolean'},subdirs_private={'type':'boolean'},nofollow_verified={'type':'boolean'},regular_owned_single_link={'type':'boolean'},containment_verified={'type':'boolean'},reasons=ref('reasons'))
d['bounded_failure']=obj(record_type=en('bounded_failure'),request_id=nullable(ref('id')),received_bytes=nullable(integer()),retained_prefix_hex={'type':'string','pattern':'^(?:[0-9a-f]{2})*$','maxLength':512},retained_prefix_sha256=ref('sha'),status=en('indeterminate'),reasons=ref('reasons'),worker_launched=en(False),implementation_authorized=en(False),a2_acceptance_passed=en(False),arithmetic_verified=en(False),total_numerical_certified=en(False))
s['oneOf']=[ref(n) for n in ['bounded_failure','candidate_spec','request','candidate','observation','comparison','process','result','failure_index','input_bundle','binding_check','slot','launch_receipt','producer_binding','supervisor_export','run_manifest','output_control']]
s['x-artifact-routing']={
 'records/preflight-failure.json':'#/$defs/bounded_failure',
 'input-bundle.json':'#/$defs/input_bundle','failure-index.json':'#/$defs/failure_index','result.json':'#/$defs/result','records/process.json':'#/$defs/process','records/launch.json':'#/$defs/launch_receipt','records/export.json':'#/$defs/supervisor_export','records/output-control.json':'#/$defs/output_control','run-manifest.json':'#/$defs/run_manifest',
 'arrays/{slot_id}.json':'#/$defs/slot','records/observation-{observation_id}.json':'#/$defs/observation','records/binding-{binding_id}.json':'#/$defs/producer_binding','records/comparison-{comparison_id}.json':'#/$defs/comparison','records/check-{check_id}.json':'#/$defs/binding_check','records/candidate-{candidate_index}.json':'#/$defs/supplied_candidate','records/request.json':'#/$defs/request','logs/stdout.bin':'bounded raw bytes <=16384','logs/stderr.bin':'bounded raw bytes <=16384','tmp/{id}.part':'charged owned uncommitted bounded bytes; never a successful final artifact'}
s['x-disposition-table']={
 'slot_complete':{'status':'complete','payloads':1,'binding':'required','reasons':['none']},
 'slot_partial':{'status':'partial','payloads':1,'binding':'required','reasons':'non-none unavailable reason; proper prefix only'},
 'slot_pending':{'status':['unknown','not_evaluated'],'payloads':0,'binding':None,'reasons':'non-none unavailable reason or not_evaluated'},
 'slot_inapplicable':{'status':'not_applicable','payloads':0,'binding':None,'reasons':['configuration_mismatch','malformed_fit','invalid_type','nonfinite_fit','negative_coefficient','invalid_rho','unselected_candidate','stage_not_used','unused_quantity','singleton_fd_adjacency']},
 'check_pass':{'status':'pass','reasons':['none']},'check_fail':{'status':'fail','reasons':'non-none mismatch reason'},'check_pending':{'status':['unknown','not_evaluated'],'reasons':'non-none unavailable/not_evaluated reason'},'check_inapplicable':{'status':'not_applicable','reasons':'same causal inapplicability reasons as slots'}}
s['x-binding-digest-recipe']='sha256(json.dumps(entire producer_binding payload,sort_keys=True,separators=(comma,colon),ensure_ascii=True,allow_nan=False).encode(UTF-8)); no newline, no own digest. returned raw descriptors hash raw bytes; exact descriptors hash canonical exact_array only, never slot wrapper. Mandatory crosslinks and acyclic order in schema-control-contract.md.'
# Remove contradictory former predicates, not merely append an override.
pr=s['x-canonical-parse-predicate']
pr[5]='Evidence IDs unique per case+record kind; candidate IDs need not be unique in bounded INVALID raw input. Candidate occurrences retain supplied-order candidate_index including duplicate IDs, no coercion. Exact post-mutation slot/comparison/binding inventory required. Typed disposition table and schema-control-contract.md are mandatory: known-ineligible slots not_applicable with actual ineligibility reasons, never not_evaluated; unknown/not_evaluated null payloads/binding; complete exactly one payload/binding; partial proper prefix with explicit index remainder. reason equals reasons[0], preserve every observable reason.'
pr[6]='Producer binding has the exact closed payload/digest recipe in x-binding-digest-recipe and schema-control-contract.md; enforce launch/run/process/invocation/case/request/input/source/config/mode/branch and actual returned payload descriptor crosslinks. Candidate-free full observations use full_configuration/full_producer and null candidate ID/index, source fractional.py, never fit attribution. Hashes establish consistency, not execution authentication.'
pr[9]='External manifests exclude themselves. Input bundle precedes launch receipt, raw payload descriptors precede producer binding, then slot wrappers and observations, final process, final index, later supervisor export and external run manifest. Never require own digest or own write duration. No binding hashes a wrapper containing its own binding hash.'
pr[-1]='failure_index.slots uses compact index_slot references to immutable record_type=slot artifacts routed by x-artifact-routing and accepted by schema root. Preserve true bounded unsupported expected shapes (including [18] and [18,18]); no arithmetic support extension. Complete/partial artifacts retain actual shapes; unavailable/inapplicable have null artifact/completed shape. Prepersist and budget ALL comparison and fit-binding dispositions and candidate occurrences too. Safe fresh-root/no-follow ownership, immutable array versus atomic index replacement, cumulative/live byte accounting, phase timing and acyclic later index-write export are mandatory per schema-control-contract.md. Reservation failure is bounded indeterminate before numerical work, never omission.'
pr.append('All JSON output artifacts must match both root oneOf and x-artifact-routing; raw logs and owned temporary files are explicitly routed exceptions. STATIC/HYPOTHETICAL witness containers are not observed run artifacts. Full timing/ownership/binding relationships and disposition table are mandatory, not waived by false acceptance flags.')
# Fixture stages and truthful post-mutation inventories.
f['mutation_semantics']='Apply references-stage replacements before dereference; clone every candidate occurrence; apply expanded-stage replacements only at existing expanded fields, then evidence-stage replacements to declared nullable evidence cells. No insertion/coercion/ID-keyed deduplication. Exact post-mutation inventory/ownership in schema-control-contract.md. Invalid requests preserve bounded raw input with parsed request null.'
for c in f['cases']:
    for m in c.get('mutations',[]):
        m['stage']='references' if m['replace']=='request/candidate_refs' else ('evidence' if m['replace'].startswith('evidence/') else 'expanded')
    refms=[m for m in c['mutations'] if m['stage']=='references']
    if refms:
        refs=C(c['request']['candidate_refs'])
        for m in refms: refs=C(m['value'])
        c['required_evidence_slots']=[z for z in c['required_evidence_slots'] if z['candidate_index'] is None or z['candidate_index']<len(refs)]
        c['post_mutation_candidate_refs']=refs
    if any('evidence/' in m['replace'] for m in c['mutations']):
        c['evidence_mutation_cells']=[{'path':m['replace'],'initial_value':None,'disposition':'unavailable_after_fault_recipe'} for m in c['mutations'] if m['stage']=='evidence']
# Narrowly related rank-preservation and combined precedence controls.
new=[]
for dt in ['f32','f64']:
 for op in ['GL','RL']:
  for n in [1,3]:
   base=next(c for c in f['cases'] if c['case_id']==f'GRID-N{n}-M1-{dt}-{op}')
   c=C(base); c['case_id']=f'RANK2-N{n}-M1-{dt}-{op}'; c['group']='SCHEMA-CONTROLS'
   old=c['request']['input_ref']; key=c['case_id']+'-x'; a=C(f['arrays'][old]); a['shape']=[n,1]; f['arrays'][key]=a; c['request']['input_ref']=key; new.append(c)
  base=next(c for c in f['cases'] if c['case_id']==f'REQUEST-duplicate-id-{dt}-{op}')
  c=C(base); c['case_id']=f'COMBINED-duplicate-{dt}-{op}'; c['group']='SCHEMA-CONTROLS'; c['expected']['all_reasons']=['duplicate_id','duplicate_content']; new.append(c)
  base=next(c for c in f['cases'] if c['case_id']==f'REF-PASS-{dt}-{op}')
  c=C(base); c['case_id']=f'COMBINED-incompatible-unavailable-{dt}-{op}'; c['group']='SCHEMA-CONTROLS'; c['mutations']=[{'stage':'expanded','replace':'candidate:0/configuration/kernel','value':'l1'},{'stage':'expanded','replace':'candidate:0/producer','value':None}]; c['expected']={'request_status':'indeterminate','selected_id':None,'reason':'missing_producer_binding','all_reasons':['missing_producer_binding','configuration_mismatch']}; new.append(c)
f['cases']+=new
f['real_worker_inventory']['branches']={k:[v[0],'ad-base']+v[1:] for k,v in f['real_worker_inventory']['branches'].items()}
f['real_worker_inventory']['base_extra_quantities']=[]
f['real_worker_inventory']['ad_base_extra_quantities']=['input_AD','order_AD','directional_AD']
f['real_worker_inventory']['ad_base_joint_cotangents']='input_AD and order_AD come from one selected same-forward joint value_and_grad composition; directional_AD uses fixed actual q'
# Add stable check IDs, and explicit full observation inventory (no arrays).
for c in f['cases']:
 for i,ch in enumerate(c.get('required_fit_identity_checks',[])): ch['check_id']='fit-check-'+str(i)
 if c['group']=='FIT-REAL':
  c['required_full_observations']=[{'observation_id':mode+'-X-base-full','candidate_id':None,'candidate_index':None,'mode':mode,'branch':'base','slot_id':mode+'-X-base-full_output','comparison_id':mode+'-X-forward_full_exact','configuration_variant':'full_configuration','producer_variant':'full_producer'} for mode in ['eager','jit']]
f['counts']={**f['counts'],'cases':len(f['cases']),'arrays':len(f['arrays']),'groups':dict(sorted(Counter(c['group'] for c in f['cases']).items())),'required_evidence_slots':sum(len(c['required_evidence_slots']) for c in f['cases']),'max_slots_per_case':max(len(c['required_evidence_slots']) for c in f['cases']),'working_comparison_slots':sum(len(c.get('required_working_comparisons',[])) for c in f['cases']),'fit_identity_check_slots':sum(len(c.get('required_fit_identity_checks',[])) for c in f['cases']),'candidate_free_full_observations':sum(len(c.get('required_full_observations',[])) for c in f['cases'])}
f['preinventory_rules']+=' Reference-level list mutations apply FIRST. Inventories reflect actual post-mutation occurrences; empty means no candidate slots. Candidate index distinguishes duplicate invalid raw occurrences. All unfinished working comparisons and fit identity checks persist in initialized/final index. See schema-control-contract.md.'
# Protocol corrections retain domain/caps/math/policy values.
p['status']='corrected_DRAFT_pending_independent_FINAL_review_and_owner_approval'
p['resource_accounting']['persistence']='Mandatory exact lifecycle in schema-control-contract.md: fresh private per-request root/subdirs, no-follow handle-relative creation/readback and owner/type/inode/containment verification; immutable array no-overwrite, atomic owned index replacement only. Charge all owned temporary/partial/coexisting bytes and cumulative written bytes; both live and cumulative <=16MiB. No deletion/rewrite evasion. Prepersist all quantity, comparison, fit-binding and occurrence dispositions. Whole reserved final index transaction including coexisting files/receipts must fit 512KiB or bounded reservation_exceeded/indeterminate, no numerical work.'
p['resource_accounting']['failure_index_layout']='Closed index_slot rows and ALL comparison/binding_check dispositions, occurrence list, process/phase receipt and byte-accounting fields. Full transaction templates must cover initial/final index coexistence and later supervisor export; <=512KiB reservation is not promised feasible for every case. Refuse launch with bounded indeterminate reservation_exceeded when required transaction cannot fit, never omit fields/checks.'
p['resource_accounting']['watchdog']+=' Closed phase_timing/process/launch_receipt/supervisor_export define preflight, watchdog, grace, kill-through-confirmed-exit and later index-write intervals without digest/write cycles; unavailable/not-applicable are explicit, zero-wall barrier never released. No 60-second total guarantee.'
p['resource_accounting']['output_security_contract']='schema-control-contract.md#output-security-and-byte-accounting-lifecycle'
p['identity']['execution_binding']='Separate volatile producer_binding payload SHA recipe in record-schemas.json and schema-control-contract.md; no change to ID-free content identity.'
p['precedence_notes'].append('Any required missing producer evidence keeps assessment UNKNOWN even with locally observed configuration incompatibility; retain both reasons. Duplicate supplied ID and complete content retain both reasons and supplied occurrences. No ID uniqueness coercion in invalid raw input.')
p['packet_refs']+=['schema-control-contract.md','schema-control-fixtures.json']
p['lineage']['corrected_failed_archive']='corrected-contract-reviews-failed.tar.gz'
p['lineage']['corrected_failed_archive_sha256']='d44c2b69c29f2e88862d5380c188f1855798131a1b34ddaf4736d4ac34a81616'
p['lineage']['repair_cycle']='2_of_2_final_preparation_only'
emit('protocol.json',p); emit('fixtures.json',f); emit('record-schemas.json',s)
print(json.dumps({'counts':f['counts'],'root_variants':len(s['oneOf']),'schema_definitions':len(d),'written_static_only':True},indent=2))
