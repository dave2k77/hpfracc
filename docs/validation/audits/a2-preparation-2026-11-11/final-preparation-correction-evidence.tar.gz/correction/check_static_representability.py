"""Bounded stdlib checks of STATIC preparation artifacts, NOT operational replay."""
from prep_common import *
from fractions import Fraction
from collections import Counter
import re, struct, os, subprocess
s=read('record-schemas.json'); f=read('fixtures.json'); p=read('protocol.json'); w=read('schema-control-fixtures.json')
OUT={}; checked=Counter(); failures=[]
class Invalid(Exception): pass
def need(ok,label):
    if not ok: raise Invalid(label)
def schema(x,t,path='$'):
    if '$ref' in t: return schema(x,s['$defs'][t['$ref'].split('/')[-1]],path)
    for key in ['oneOf','anyOf']:
        if key in t:
            n=0
            for sub in t[key]:
                try: schema(x,sub,path); n+=1
                except Invalid: pass
            need(n==1 if key=='oneOf' else n>=1,path+':'+key); return
    if 'enum' in t: need(any(type(x) is type(z) and x==z for z in t['enum']),path+':enum')
    typ=t.get('type')
    types={'object':dict,'array':list,'string':str,'integer':int,'boolean':bool,'null':type(None)}
    if typ: need(type(x) is types[typ],path+':type')
    if typ=='object':
        need(set(t['required'])<=set(x),path+':required')
        if t.get('additionalProperties') is False: need(set(x)<=set(t['properties']),path+':extra')
        for k,v in x.items(): schema(v,t['properties'][k],path+'/'+k)
    elif typ=='array':
        need(t.get('minItems',0)<=len(x)<=t.get('maxItems',10**8),path+':cardinality')
        for i,v in enumerate(x): schema(v,t['items'],path+'/'+str(i))
    elif typ=='string':
        need(t.get('minLength',0)<=len(x)<=t.get('maxLength',10**8),path+':length')
        if 'pattern' in t: need(re.fullmatch(t['pattern'],x) is not None,path+':pattern')
    elif typ=='integer': need(t.get('minimum',-10**100)<=x<=t.get('maximum',10**100),path+':range')

def shape_product(sh): return math.prod(sh)
def canonical_values(x):
    if isinstance(x,dict):
        if set(x)=={'num','den'}:
            need(re.fullmatch(r'(0|-?[1-9a-f][0-9a-f]*)',x['num']) is not None,'rat spelling')
            need(re.fullmatch(r'[1-9a-f][0-9a-f]*',x['den']) is not None,'rat denominator')
            a=int(x['num'],16); b=int(x['den'],16); need(math.gcd(abs(a),b)==1 and (a!=0 or b==1),'rat canonical'); need(max(abs(a).bit_length(),b.bit_length())<=32768,'rat bits')
        if 'raw_hex' in x:
            data=bytes.fromhex(x['raw_hex']); need(len(data)==x['nbytes']==shape_product(x['shape'])*{'float32':4,'float64':8,'complex64':8,'complex128':16}[x['dtype']],'raw size'); need(sha(data)==x['sha256'],'raw digest')
        if set(x)=={'shape','values'}: need(shape_product(x['shape'])==len(x['values']),'exact cardinality')
        if x.get('record_type')=='slot': disposition(x)
        if 'candidate_index' in x and 'candidate_id' in x:
            need((x['candidate_index'] is None)==(x['candidate_id'] is None),'occurrence null pairing')
        for v in x.values(): canonical_values(v)
    elif isinstance(x,list):
        for v in x: canonical_values(v)

def disposition(x):
    need(x['reasons'] and len(x['reasons'])==len(set(x['reasons'])) and x['reason']==x['reasons'][0],'reason primary/all')
    count=sum(x[k] is not None for k in ['raw_array','exact_array'])
    if x['status'] in ['complete','partial']:
        need(count==1 and x['producer_binding_sha256'] is not None,'slot payload/binding')
        need((x['reasons']==['none'])==(x['status']=='complete'),'complete/partial reason')
    else:
        need(count==0 and x['producer_binding_sha256'] is None and 'none' not in x['reasons'],'null unavailable')
        if x['status']=='not_applicable': need(x['reason'] in s['x-disposition-table']['slot_inapplicable']['reasons'],'typed inapplicable reason')

def timing(x):
    if x['status']=='observed': need(all(type(x[k]) is int for k in ['start_ns','end_ns','elapsed_ns']) and x['end_ns']>=x['start_ns'] and x['elapsed_ns']==x['end_ns']-x['start_ns'] and x['reason']=='none','timing observed')
    else: need(all(x[k] is None for k in ['start_ns','end_ns','elapsed_ns']) and x['reason']!='none','timing unavailable/null')

def routed(path,x):
    defs=[]
    for pattern,definition in s['x-artifact-routing'].items():
        r=re.escape(pattern); r=re.sub(r'\\\{[^}]+\\\}',r'[A-Za-z0-9][A-Za-z0-9._-]{0,63}',r)
        if re.fullmatch(r,path): defs.append(definition)
    need(len(defs)==1,'closed path routing '+path)
    need(defs[0].startswith('#/'),'JSON route expected')
    schema(x,{'$ref':defs[0]}); schema(x,s); canonical_values(x); checked['root_and_route']+=1
    # Path identifiers must refer to the actual payload, not merely fit grammar.
    for prefix,field in [('arrays/','slot_id'),('records/observation-','observation_id'),('records/binding-','binding_id'),('records/comparison-','comparison_id'),('records/check-','check_id')]:
        if path.startswith(prefix): need(path==prefix+x[field]+'.json','path identifier binding')

def phase_process(pr,q):
    for x in pr['phases'].values(): timing(x)
    ph=pr['phases']; wd=ph['watchdog']
    if pr['termination']=='not_launched': need(pr['launch_receipt_sha256'] is None and pr['elapsed_monotonic_ns'] is None and not pr['exit_confirmed'] and wd['status']=='not_applicable','not launched phases')
    elif pr['exit_confirmed']:
        need(wd['status']=='observed' and pr['elapsed_monotonic_ns']==wd['elapsed_ns'] and pr['exit_code'] is not None,'confirmed exit timing')
        need(ph['preflight']['end_ns']<=wd['start_ns'],'preflight before launch')
    else: need(wd['status']=='unavailable' and pr['exit_code'] is None,'unconfirmed unavailable')
    if pr['watchdog_triggered']:
        need(ph['grace']['status']=='observed','grace represented')
        need(ph['grace']['start_ns']-wd['start_ns']>=q['caps']['wall_seconds']*1000000000,'watchdog trigger not early')
        if q['caps']['wall_seconds']==0: need(pr['barrier']=='held','zero barrier held')
    if pr['termination']=='kill': need(ph['kill_to_exit']['status']=='observed' and ph['kill_to_exit']['start_ns']==ph['grace']['end_ns'] and ph['kill_to_exit']['end_ns']==wd['end_ns'],'kill through exit')

def bundle_semantics(b):
    a=b['artifacts']; inp=a['input-bundle.json']; pr=a['records/process.json']; idx=a['failure-index.json']; launch=a['records/launch.json']; result=a['result.json']
    q=inp['request'] if inp['request'] is not None else json.loads(bytes.fromhex(inp['raw_request_utf8_hex']))
    need(dh(q)==inp['raw_request_sha256'],'raw request digest')
    need(inp['candidate_ids']==[c['stable_id'] for c in q['candidates']],'supplied list exact')
    need(inp['candidate_occurrences']==idx['candidate_occurrences']==occurrence(q),'occurrence identity')
    need(idx['candidate_ids']==inp['candidate_ids'],'index supplied IDs')
    bh=dh(inp); lh=dh(launch); case=q['case_id']
    phase_process(pr,q)
    need(idx['process']==pr,'embedded final process exact')
    for x in [pr,idx,launch,result]: need(x['input_bundle_sha256']==bh,'bundle link')
    need(launch['case_id']==pr['case_id']==case and launch['run_id']==pr['run_id'] and launch['process_id']==pr['process_id'] and launch['command']==pr['command'],'launch process context')
    need(pr['launch_receipt_sha256']==(lh if launch['status']=='launched' else None),'launch receipt digest')
    inv={z['slot_id']:z for z in inp['required_slots']}; need(len(inv)==len(inp['required_slots']),'unique slot inventory')
    rows={z['slot_id']:z for z in idx['slots']}; need(set(inv)==set(rows) and len(rows)==len(idx['slots']),'full index inventory')
    allslots=result['shared_slots']+[z for ca in result['assessments'] for z in ca['slots']]
    need(Counter(z['slot_id'] for z in allslots)==Counter(inv.keys()),'result full inventory')
    for z in idx['slots']:
        need(all(z[k]==inv[z['slot_id']][k] for k in inv[z['slot_id']]),'index metadata inventory match')
        expected=shape(z,q); need(z['expected_shape']==expected,'true expected shape')
        if z['status'] in ['complete','partial']:
            ar=z['artifact']; need(ar is not None and ar['path'] in a,'committed artifact present')
            slot=a[ar['path']]; need(ar['bytes']==len(canonical(slot)) and ar['sha256']==dh(slot),'artifact readback identity')
            payload=slot['raw_array'] or slot['exact_array']; need(z['completed_shape']==payload['shape'],'payload prefix shape')
            if z['status']=='complete': need(z['completed_shape']==expected,'complete full shape')
            else: need(len(expected)>0 and len(payload['shape'])==len(expected) and 0<payload['shape'][0]<expected[0] and payload['shape'][1:]==expected[1:],'proper prefix missing suffix')
        else: need(z['artifact'] is None and z['completed_shape'] is None,'unavailable artifact null')
    need([{k:x[k] for k in invx} for x,invx in zip(idx['comparisons'],inp['required_comparisons'])]==inp['required_comparisons'] and len(idx['comparisons'])==len(inp['required_comparisons']),'all comparisons prepersisted')
    need([{k:x[k] for k in invx} for x,invx in zip(idx['binding_checks'],inp['required_binding_checks'])]==inp['required_binding_checks'] and len(idx['binding_checks'])==len(inp['required_binding_checks']),'all binding checks prepersisted')
    bindings={dh(x):x for x in a.values() if x.get('record_type')=='producer_binding'}
    for bindhash,x in bindings.items():
        need(x['input_bundle_sha256']==bh and x['launch_receipt_sha256']==lh,'binding receipt link')
        need(x['case_id']==case and x['request_id']==q['request_id'] and x['run_id']==pr['run_id'] and x['process_id']==pr['process_id'],'binding execution context')
        need(x['policy_id']==q['policy_id'] and x['packet_manifest_sha256']==q['packet_manifest_sha256'],'binding policy/packet')
        need(x['input']==rawdesc(q['input']),'actual input descriptor')
        need(x['alpha']==rawdesc(f['working_scalars'][q['input']['dtype']]['alpha']) and x['dt']==rawdesc(f['working_scalars'][q['input']['dtype']]['dt']),'actual scalar descriptors')
        need(x['sources']==inp['sources'] and x['producer']['source'] in inp['sources'],'source list binding')
        for source in x['sources']: need(sha((ROOT/source['repo_path']).read_bytes())==source['sha256'],'source bytes')
        need(x['configuration']['alpha']==q['alpha'] and x['configuration']['dt']==q['dt'] and x['configuration']['n']==q['input']['shape'][0],'configuration/input binding')
        payload_ids=[]
        for z in x['returned']:
            sl=a['arrays/'+z['slot_id']+'.json']; payload=sl['raw_array'] or sl['exact_array']; need(sl['producer_binding_sha256']==bindhash and z['descriptor']==descriptor(payload),'raw/exact descriptor NOT wrapper')
            need(sl['case_id']==case and sl['candidate_id']==x['candidate_id'] and sl['candidate_index']==x['candidate_index'] and sl['mode']==x['mode'] and sl['branch']==x['branch'] and sl['quantity']==z['quantity'],'branch occurrence payload binding'); payload_ids.append(z['slot_id'])
        need(len(payload_ids)==len(set(payload_ids)),'no duplicated returned slots')
        if x['configuration'].get('history')=='full':
            need(x['candidate_id'] is None and x['candidate_index'] is None and x['producer']['kind']=='actual_full_history' and x['producer']['source']['repo_path']=='src/hpfracc/ops/fractional.py','candidate-free full source')
    for x in a.values():
        if x.get('record_type')=='observation' and x['producer_binding_sha256'] is not None:
            bx=bindings[x['producer_binding_sha256']]
            for k in ['case_id','candidate_id','candidate_index','mode','branch','run_id','process_id','invocation_id','observation_id','input_bundle_sha256','launch_receipt_sha256','configuration','producer']: need(x[k]==bx[k],'observation '+k)
    for ca in result['assessments']:
        need(ca['candidate_id']==q['candidates'][ca['candidate_index']]['stable_id'],'assessment occurrence')
        if ca['status']=='known_ineligible': need(ca['qualifies'] is False and all(z['status']=='not_applicable' for z in ca['slots']),'knownbad no fabricated arrays')
        if ca['status']=='unknown': need(ca['qualifies'] is None,'unknown no qualification')
        if ca['status'] in ['known_qualifying','known_rejected_by_bound']:
            def val(z): return Fraction(int(z['num'],16),int(z['den'],16))
            def vals(sl): return [val(z) for z in sl['exact_array']['values']]
            slots={z['quantity']:z for z in ca['slots']}; x=[Fraction(z[0]) for z in struct.iter_unpack('<f' if q['input']['dtype']=='float32' else '<d',bytes.fromhex(q['input']['raw_hex']))]; n=len(x); cand=q['candidates'][ca['candidate_index']]
            coeff=[Fraction(z[0]) for z in struct.iter_unpack('<f' if q['input']['dtype']=='float32' else '<d',bytes.fromhex(cand['coefficients']['raw_hex']))]; rho=[Fraction(z[0]) for z in struct.iter_unpack('<f' if q['input']['dtype']=='float32' else '<d',bytes.fromhex(cand['rhos']['raw_hex']))]
            g=[Fraction(math.comb(2*k,k),4**k) for k in range(n)]; gh=[Fraction(1)]+[sum(c*r**(k-1) for c,r in zip(coeff,rho)) for k in range(1,n)]; epsilon=max(abs(a-b) for a,b in zip(g,gh)); v=[x[0]]+[x[k]-x[k-1] for k in range(1,n)]; B=[2*epsilon*sum(abs(z) for z in v[:i]) for i in range(n)]; Dhat=[2*sum(gh[k]*v[i-k] for k in range(i+1)) for i in range(n)]; signed=[g[0]]+[g[k]-g[k-1] for k in range(1,n)]; D=[2*sum(signed[k]*x[i-k] for k in range(i+1)) for i in range(n)]
            need(vals(slots['B'])==B and vals(slots['D_hat'])==Dhat and vals(slots['epsilon'])==[epsilon] and vals(slots['error'])==[abs(a-b) for a,b in zip(Dhat,D)],'independent small exact synthetic components')
            need(ca['qualifies']==all(z<=val(q['tau']) for z in B) and all(abs(a-b)<=z for a,b,z in zip(Dhat,D,B)),'synthetic bound/qualification semantics')
    if result['status']=='selected':
        need(all(ca['status']!='unknown' for ca in result['assessments']),'exhaustive selected')
        quals=[ca for ca in result['assessments'] if ca['qualifies'] is True]; minimum=min(quals,key=lambda z:(q['candidates'][z['candidate_index']]['configuration']['pole_count'],z['candidate_id'].encode('ascii'))); need(result['selected_id']==minimum['candidate_id'],'minimum among supplied')
    elif result['status']=='no_supplied_candidate_meets_bound': need(all(ca['qualifies'] is False for ca in result['assessments']) and result['selected_id'] is None,'completed no qualifier')
    else: need(result['selected_id'] is None,'no premature selection')
    if pr['barrier']=='held': need(not bindings,'barrier no arithmetic')
    security=a['records/output-control.json']; need(security['status']!='safe' or all(security[k] is True for k in ['fresh_private_root','subdirs_private','nofollow_verified','regular_owned_single_link','containment_verified']),'output safe invariant')
    ex=a['records/export.json']; timing(ex['index_write']); need(ex['process_sha256']==dh(pr) and ex['failure_index_sha256']==dh(idx) and ex['failure_index_bytes']==len(canonical(idx)),'later export exact targets')
    need(ex['input_bundle_sha256']==bh and ex['run_id']==pr['run_id'] and ex['process_id']==pr['process_id'],'export context')
    if pr['exit_confirmed']: need(ex['index_write']['start_ns']>=pr['phases']['watchdog']['end_ns'],'export after confirmed exit')
    # Snapshot fields explicitly precede their own serialization, no self-size cycle.
    beforeidx=sum(len(canonical(v)) for k,v in a.items() if k not in ['failure-index.json','records/export.json','run-manifest.json'])
    old=b['initial_failure_index']; schema(old,s['$defs']['failure_index']); need(old['input_bundle_sha256']==bh,'initial index exact bundle'); need(len(old['slots'])==len(idx['slots']) and len(old['comparisons'])==len(idx['comparisons']) and len(old['binding_checks'])==len(idx['binding_checks']),'initial ALL dispositions')
    need(all(z['status']=='not_evaluated' for z in old['slots']+old['comparisons']+old['binding_checks']),'initialized before work')
    beforeidx+=len(canonical(old))
    need(idx['bytes_accounting']['live_bytes']==beforeidx==idx['bytes_accounting']['cumulative_written_bytes'],'pre-index byte snapshot INCLUDING old coexisting index')
    manifest=a['run-manifest.json']; need(set(z['path'] for z in manifest['files'])==set(a)-{'run-manifest.json'},'acyclic run manifest complete set')
    for z in manifest['files']: need(z['bytes']==len(canonical(a[z['path']])) and z['sha256']==dh(a[z['path']]),'run manifest bytes')
    # DAG edges are exact serialized references, not execution authentication.
    graph={key:[] for key in a}
    graph['records/launch.json']=['input-bundle.json']
    for key,x in a.items():
        typ=x.get('record_type')
        if typ=='producer_binding': graph[key]=['input-bundle.json','records/launch.json']
        if typ=='slot' and x['producer_binding_sha256'] in bindings: graph[key]=[next(k for k,v in a.items() if v is bindings[x['producer_binding_sha256']])]
        if typ=='observation': graph[key]=['arrays/'+z['slot_id']+'.json' for z in x['slots']]
    graph['records/process.json']=['records/launch.json']; graph['failure-index.json']=['records/process.json']+[z['artifact']['path'] for z in idx['slots'] if z['artifact']]; graph['records/export.json']=['records/process.json','failure-index.json']; graph['run-manifest.json']=list(set(a)-{'run-manifest.json'})
    active=set(); done=set()
    def visit(n):
        need(n not in active,'DAG cycle');
        if n in done: return
        active.add(n)
        for dep in graph[n]: visit(dep)
        active.remove(n); done.add(n)
    for n in graph: visit(n)
    checked['acyclic_nodes']+=len(done); checked['linked_bundles']+=1

# All request expansions are bounded, replace-only and occurrence preserving.
exp=[]; sizes=[]
for case in f['cases']:
    q=expanded(case,f,p); inv=inventory(case,q); canonical_ok=True
    try: schema(q,s['$defs']['request']); canonical_values(q)
    except Invalid: canonical_ok=False
    ib=input_bundle(case,q,canonical_ok); pr=process(q,'not_launched',dh(ib)); ix=index(case,q,pr,dh(ib))
    schema(ib,s['$defs']['input_bundle']); schema(ix,s['$defs']['failure_index'])
    need(len(inv)==len(set(z['slot_id'] for z in inv)),'all case unique slot IDs')
    need(set(z['candidate_index'] for z in inv if z['candidate_index'] is not None)==set(range(len(q['candidates']))),'all post-mutation occurrences inventoried')
    if 'empty-' in case['case_id']: need(not q['candidates'] and len(inv)==4,'empty actual list no stale inventory')
    if 'duplicate-id-' in case['case_id'] or case['case_id'].startswith('COMBINED-duplicate'):
        need(q['candidates'][0] is not q['candidates'][1],'clone each occurrence'); need(q['candidates'][0]['stable_id']==q['candidates'][1]['stable_id'],'duplicate retained')
        q['candidates'][0]['configuration']['kernel']='sentinel'; need(q['candidates'][1]['configuration']['kernel']!='sentinel','no shared mutable occurrence')
    # Render complete-descriptor and pending transaction templates with ALL checks.
    for z in ix['slots']:
        z.update(status='complete',reason='none',reasons=['none'],completed_shape=C(z['expected_shape']),artifact={'path':'arrays/'+z['slot_id']+'.json','bytes':16777216,'sha256':'f'*64})
    ix['status']='complete'; ix['reasons']=['none']
    for z in ix['comparisons']+ix['binding_checks']: z.update(status='unknown',reasons=['incomplete_evidence'])
    final_bytes=len(canonical(ix)); initial=index(case,expanded(case,f,p),pr,dh(ib)); initial_bytes=len(canonical(initial))
    # Explicit upper template receipt/control allowance rendered, not hidden.
    ancillary=8192  # reserve for bounded process/export/output/failure receipts, checked against rendered witnesses below
    transaction=initial_bytes+final_bytes+ancillary
    inputbytes=len(canonical(ib))
    sizes.append({'case_id':case['case_id'],'input_bundle_bytes':inputbytes,'initial_index_bytes':initial_bytes,'complete_descriptor_index_bytes':final_bytes,'receipt_allowance_bytes':ancillary,'full_index_transaction_bytes':transaction,'preflight_disposition':'reservation_exceeded_indeterminate_NO_WORK' if transaction>524288 or inputbytes>262144 else 'template_fits_NOT_FEASIBILITY'})
    exp.append({'case_id':case['case_id'],'canonical_request_schema':canonical_ok,'actual_candidate_occurrences':len(q['candidates']),'slots':len(inv),'comparisons':len(case.get('required_working_comparisons',[])),'fit_bindings':len(case.get('required_fit_identity_checks',[]))})
need(len(exp)==f['counts']['cases']==560,'case totals')
need(sum(z['slots'] for z in exp)==f['counts']['required_evidence_slots']==24336,'slot totals')
need(sum(z['comparisons'] for z in exp)==1312 and sum(z['fit_bindings'] for z in exp)==1056,'check totals')
for b in w['bundles']:
    for path,x in b['artifacts'].items(): routed(path,x)
    bundle_semantics(b)
for x in w['future_full_bindings']:
    schema(x['observation'],s); schema(x['comparison'],s); canonical_values(x)
    case=next(c for c in f['cases'] if c['case_id']==x['case_id']); z=next(z for z in case['required_full_observations'] if z['mode']==x['observation']['mode'])
    need(x['observation']['slots'][0]['slot_id']==z['slot_id'] and x['comparison']['a_slot_id']==z['slot_id'] and x['comparison']['reference_slot_id']=='S-X-D','all 64 full crosslinks')
    need(x['observation']['producer'] is None and x['observation']['producer_binding_sha256'] is None,'no invented unobserved full producer')
need(len(w['future_full_bindings'])==64,'all64')
for x in w['status_matrix']:
    if 'route' in x: routed(x['route'],x['record'])
    else: schema(x['record'],s['$defs'][x['definition']]); timing(x['record'])
    canonical_values(x['record'])
    if x['record'].get('record_type') in ['comparison','binding_check']:
        r=x['record']; need((r['reasons']==['none'])==(r['status']=='pass'),'check status reasons')

# Meaningful one-field semantic mutants: recompute outer indexes/manifests so
# failures cannot be explained by merely stale outer hashes.
mutant_results=[]
for control in w['tamper_controls']:
    target=control['target']; name=control['id']
    source=next(b for b in w['bundles'] if b['declared_case_id']=='FIT-ramp-tau0-f64-GL') if name=='missing-check' else next(b for b in w['bundles'] if b['kind']==('barrier' if name=='zero-barrier-released' else 'timeout' if name=='grace-not-recorded' else 'knownbad' if name=='none-for-knownbad' else 'full'))
    b=C(source); a=b['artifacts']; parts=target.split('/'); category=parts.pop(0)
    if category=='binding': obj=next(v for v in a.values() if v.get('record_type')=='producer_binding' and v['binding_id']=='full')
    elif category=='observation': obj=next(v for v in a.values() if v.get('record_type')=='observation')
    elif category=='index': obj=a['failure-index.json']
    elif category=='process': obj=a['records/process.json']
    elif category=='slot': obj=next(z for z in a['result.json']['assessments'][0]['slots'] if z['status']=='not_applicable')
    elif category=='output': obj=a['records/output-control.json']
    else: raise Invalid('unknown mutant target')
    if name=='swapped-array':
        # Full returned raw descriptor has a SHA field; exact descriptors do not.
        need('sha256' in obj['returned'][0]['descriptor'],'mutant actual raw descriptor target')
    prior=dh(obj); replace_existing(obj,parts,control['replacement']); need(dh(obj)!=prior,'mutant is not a no-op '+name)
    if category=='binding':
        bh=dh(obj)
        for v in a.values():
            if v.get('record_type')=='slot' and any(z['slot_id']==v['slot_id'] for z in obj['returned']): v['producer_binding_sha256']=bh
            if v.get('record_type')=='observation' and v['observation_id']==obj['observation_id']: v['producer_binding_sha256']=bh
        for z in a['failure-index.json']['slots']:
            if z['artifact']: z['artifact'].update(bytes=len(canonical(a[z['artifact']['path']])),sha256=dh(a[z['artifact']['path']]))
    a['records/export.json'].update(process_sha256=dh(a['records/process.json']),failure_index_sha256=dh(a['failure-index.json']),failure_index_bytes=len(canonical(a['failure-index.json'])))
    a['run-manifest.json']['files']=[{'path':k,'bytes':len(canonical(v)),'sha256':dh(v)} for k,v in a.items() if k!='run-manifest.json']
    rejected=False; error=''
    try:
        for k,v in a.items(): routed(k,v)
        bundle_semantics(b)
    except Invalid as e: rejected=True; error=str(e)
    need(rejected,'meaningful mutant escaped '+name)
    mutant_results.append({'id':name,'rejected':rejected,'actual_rejection':error,'outer_digests_recomputed':True})
# Every closed root gets required-key/extra-key/type rejection controls, not
# just one hash check. No implementation parser or worker is shipped.
samples={}
for b in w['bundles']:
    for x in b['artifacts'].values(): samples.setdefault(x['record_type'],x)
for z in w['status_matrix']:
    if 'record_type' in z['record']: samples.setdefault(z['record']['record_type'],z['record'])
rootnames={x['$ref'].split('/')[-1] for x in s['oneOf']}
need(set(samples)==rootnames,'EVERY schema root has a static witness')
structural_controls=[]
for name,x in samples.items():
    for mutation in ['missing_record_type','extra_key']:
        y=C(x)
        if mutation=='missing_record_type': del y['record_type']
        else: y['not_allowed']=False
        rejected=False
        try: schema(y,s)
        except Invalid: rejected=True
        need(rejected,'closed required key control '+name)
        structural_controls.append(name+':'+mutation)
for field,value in [('exit_code',True),('elapsed_monotonic_ns',1.0)]:
    y=C(samples['process']); y[field]=value; rejected=False
    try: schema(y,s)
    except Invalid: rejected=True
    need(rejected,'canonical numeric type '+field); structural_controls.append('process:'+field)
y=C(samples['result']); y['implementation_authorized']=0; rejected=False
try: schema(y,s)
except Invalid: rejected=True
need(rejected,'canonical false flag, not zero'); structural_controls.append('result:false_bool_not_zero')
for b in w['bundles']:
    a=b['artifacts']; result=a['result.json']; case=b['declared_case_id']
    if case.startswith('COMBINED-incompatible'):
        need(result['assessments'][0]['status']=='unknown' and result['reasons']==['missing_producer_binding','configuration_mismatch'] and result['assessments'][0]['reasons']==result['reasons'],'combined unavailable precedence ALL reasons')
    if 'duplicate-id-' in case: need(result['reasons']==['duplicate_id','duplicate_content'],'combined duplicate ALL reasons')
    if b['kind']=='afterqual': need(result['status']=='indeterminate' and result['assessments'][0]['qualifies'] is True and result['assessments'][1]['status']=='unknown','qualifier preserved no premature selected')
    for path,x in a.items():
        limit=262144 if path=='input-bundle.json' else 524288 if path=='failure-index.json' else 16777216
        need(len(canonical(x))<=limit,'concrete witness artifact byte cap')
for z in w['status_matrix']:
    x=z['record']
    if x.get('record_type')=='process':
        for ph in x['phases'].values(): timing(ph)
    if x.get('record_type')=='observation': need(x['producer'] is None and x['producer_binding_sha256'] is None and all(sl['raw_array'] is None and sl['exact_array'] is None for sl in x['slots']),'unobserved observation has no invented arrays/context')
# Prior controls and all original input/config bytes remain present, unchanged.
oldf=json.loads((HERE/'before/fixtures.json').read_text())
need(f['parse_controls']==oldf['parse_controls'] and f['identity_controls']==oldf['identity_controls'] and f['shortcut_controls']==oldf['shortcut_controls'],'prior parser/identity/shortcut controls preserved')
need(all(f['arrays'][k]==v for k,v in oldf['arrays'].items()),'all original832 raw descriptors preserved')
need([c['case_id'] for c in f['cases'][:544]]==[c['case_id'] for c in oldf['cases']],'all original544 case IDs preserved')
for old,new in zip(oldf['cases'],f['cases']):
    need(old['request']==new['request'] and old['expected']==new['expected'],'old signals/budgets/configs/stop gates unchanged')
    need([{k:v for k,v in m.items() if k!='stage'} for m in new['mutations']]==old['mutations'],'old mutations preserved, stages corrected')
OUT['root_variants_covered']=sorted(rootnames); OUT['structural_negative_controls']=structural_controls
status_coverage={}; status_expected={}
for name,definition in s['$defs'].items():
    for field in ['status','artifact_status','termination']:
        props=definition.get('properties',{})
        if field in props and 'enum' in props[field]:
            status_expected[(name,field)]=set(props[field]['enum']); status_coverage[(name,field)]=set()
def statuses(x):
    if isinstance(x,dict):
        for (name,field),values in status_coverage.items():
            definition=s['$defs'][name]
            if set(x)==set(definition['required']):
                try: schema(x,definition); values.add(x[field])
                except Invalid: pass
        for v in x.values(): statuses(v)
    elif isinstance(x,list):
        for v in x: statuses(v)
statuses(w)
need(status_coverage==status_expected,'EVERY emitted typed status/termination path witnessed')
OUT['typed_status_coverage']={name+'.'+field:sorted(values) for (name,field),values in status_coverage.items()}
def tree_size(x,depth=1):
    if isinstance(x,dict):
        subs=[tree_size(v,depth+1) for v in x.values()]
        return 1+len(x)+sum(z[0] for z in subs),max([depth]+[z[1] for z in subs])
    if isinstance(x,list):
        subs=[tree_size(v,depth+1) for v in x]
        return 1+sum(z[0] for z in subs),max([depth]+[z[1] for z in subs])
    return 1,depth
node_sizes=[]
for case,rec in zip(f['cases'],sizes):
    q=expanded(case,f,p); ib=input_bundle(case,q,True); ix=index(case,q,process(q,'not_launched',dh(ib)),dh(ib))
    n1,dp1=tree_size(ib); n2,dp2=tree_size(ix)
    for row in ix['slots']: row.update(status='complete',reason='none',reasons=['none'],completed_shape=C(row['expected_shape']),artifact={'path':'arrays/'+row['slot_id']+'.json','bytes':16777216,'sha256':'f'*64})
    n3,dp3=tree_size(ix)
    node_sizes.append({'case_id':case['case_id'],'input_nodes_including_keys':n1,'index_pending_nodes_including_keys':n2,'index_complete_template_nodes_including_keys':n3,'max_depth':max(dp1,dp2,dp3)})
    rec['max_nodes_including_keys']=max(n1,n2,n3)
    if max(n1,n2,n3)>32768 or max(dp1,dp2,dp3)>16: rec['preflight_disposition']='reservation_exceeded_indeterminate_NO_WORK'
receipt_sizes=[]
for b in w['bundles']:
    a=b['artifacts']; actual=sum(len(canonical(a[k])) for k in ['records/process.json','records/launch.json','records/output-control.json','records/export.json'])
    need(actual<=8192,'rendered receipt allowance covers concrete full templates'); receipt_sizes.append(actual)
for z in w['status_matrix']:
    if z['record'].get('record_type')=='supervisor_export':
        rec=z['record']; context=next(b for b in w['bundles'] if b['witness_id']==z['context_bundle'])['artifacts']; need(rec['process_sha256']==dh(context['records/process.json']) and rec['failure_index_sha256']==dh(context['failure-index.json']),'unavailable timing still links exact immutable targets'); timing(rec['index_write'])
OUT['max_concrete_receipt_bytes']=max(receipt_sizes); OUT['template_nodes_max']=max(max(z['input_nodes_including_keys'],z['index_pending_nodes_including_keys'],z['index_complete_template_nodes_including_keys']) for z in node_sizes); OUT['template_depth_max']=max(z['max_depth'] for z in node_sizes)
dump(HERE/'node-size-templates.json',node_sizes)
# Independent immutable boundaries and exact mathematics byte equality.
before=(HERE/'before/a2-compression-budget-protocol.md').read_bytes(); now=(ROOT/'docs/developer/a2-compression-budget-protocol.md').read_bytes()
def math_section(x):
    header=b'## 4. Exact finite mathematical contract\n'
    return header+x.split(header,1)[1].split(b'## 5.',1)[0]
need(math_section(before)==math_section(now),'exact math bytes unchanged')
need(p['caps']==json.loads((HERE/'before/protocol.json').read_text())['caps'],'all proposed caps unchanged')
need(p['domain']==json.loads((HERE/'before/protocol.json').read_text())['domain'],'domain unchanged')
need((AUD/'comparison-policies.json').read_bytes()==(HERE/'before/comparison-policies.json').read_bytes(),'threshold/FD policies byte-identical')
base=json.loads((HERE/'baseline.json').read_text()); allowed={'docs/developer/a2-compression-budget-protocol.md'}|{'docs/validation/audits/a2-preparation-2026-11-11/'+n for n in ['protocol.json','fixtures.json','record-schemas.json','comparison-policies.json','packet-notes.md','packet-manifest.json']}; protected=[]
for rel,desc in base['files'].items():
    if rel in allowed or rel in {'docs/developer/bug-resolution-tracker.md','docs/developer/phase-a-completion.md'}: continue
    path=ROOT/rel; data=os.readlink(path).encode('utf-8') if desc['kind']=='symlink_target_utf8' else path.read_bytes()
    need(len(data)==desc['bytes'] and sha(data)==desc['sha256'],'protected bytes '+rel); protected.append(rel)
need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==base['head'],'HEAD pin')
need(sha((ROOT/'.git/index').read_bytes())==base['index_sha256'],'index bytes pin')
need(sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT))==base['index_entries_sha256'],'index entries pin')
for z in p['preparation_source_pin']['files']: need(sha((ROOT/z['repo_path']).read_bytes())==z['sha256'],'125 numerical pins')
# Preserve raw parser controls with strict finite/type/canonical rejection.
parser=[]
for x in f['parse_controls']:
    raw=bytes.fromhex(x['raw_utf8_hex']); need(sha(raw)==x['sha256'],'parser bytes')
    def pairs(kv):
        need(len(kv)==len({k for k,v in kv}),'duplicate keys'); return dict(kv)
    rejected=False
    try:
        def bad(_): raise Invalid('noninteger/nonfinite token')
        v=json.loads(raw,object_pairs_hook=pairs,parse_float=bad,parse_constant=bad)
        if x['expected']=='reject_integer_type': need(type(v['n']) is int,'strict integer')
        if x['expected']=='reject_boolean_type': need(type(v['exact_head']) is bool,'strict boolean')
        canonical_values(v)
    except Invalid: rejected=True
    need(rejected,'preserved parser control '+x['case_id']); parser.append(x['case_id'])
# Real candidate specs remain absent observation arrays.
future=[v for v in f['candidates'].values() if 'producer_call' in v]
need(len(future)==12 and all(v['rhos_ref'] is None and v['coefficients_ref'] is None for v in future),'future arrays absent')
need(len(f['identity_controls'])==4 and len(f['shortcut_controls'])==6,'prior controls preserved')
need(Counter(tuple(f['arrays'][c['request']['input_ref']]['shape']) for c in f['cases'] if c['group']=='SCHEMA-CONTROLS' and c['case_id'].startswith('RANK2'))==Counter({(1,1):4,(3,1):4}),'rank preservation both dtypes aliases')
OUT.update(label='STATIC/HYPOTHETICAL REPRESENTABILITY ONLY; no operational worker/validator/selector/CLI implemented',passed=True,counts=f['counts'],checks=dict(checked),math_section_bytes=len(math_section(now)),math_section_sha256=sha(math_section(now)),full_observation_bindings=64,parser_controls_rejected=parser,tamper_controls=mutant_results,protected_paths_checked=len(protected),numerical_pins=125,policy_bytes_unchanged=True,head_index_pinned=True,input_max_bytes=max(z['input_bundle_bytes'] for z in sizes),index_single_max_bytes=max(z['complete_descriptor_index_bytes'] for z in sizes),index_transaction_max_bytes=max(z['full_index_transaction_bytes'] for z in sizes),bounded_preflight_refusals=sum(z['preflight_disposition'].startswith('reservation_') for z in sizes),limits=['No future actual fit/application/AD or real process run.','Concrete templates, not universal feasibility/peak-memory/scheduling proof.','Some whole reserved transactions may require bounded refusal; no cap relaxation or omitted checks.','Independent FINAL review and owner approval still required; all acceptance flags false.'])
dump(HERE/'case-expansion-proof.json',exp); dump(HERE/'full-size-templates.json',sizes); dump(HERE/'representability-proof.json',OUT)
print(json.dumps(OUT,indent=2))
