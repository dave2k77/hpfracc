"""Finalize only external static manifest and scratch receipts; no product code."""
from prep_common import *
import subprocess, os
proof=json.loads((HERE/'representability-proof.json').read_text()); need=proof['passed']; assert need
names=['docs/developer/a2-compression-budget-protocol.md']+['docs/validation/audits/a2-preparation-2026-11-11/'+n for n in ['protocol.json','fixtures.json','comparison-policies.json','record-schemas.json','packet-notes.md','schema-control-contract.md','schema-control-fixtures.json']]
manifest=json.loads((HERE/'before/packet-manifest.json').read_text()); manifest['status']='corrected_DRAFT_pending_independent_FINAL_review_and_owner_approval'; manifest['files']=[{'repo_path':rel,'bytes':len((ROOT/rel).read_bytes()),'sha256':sha((ROOT/rel).read_bytes())} for rel in names]; manifest['closed_planning_counts']=read('fixtures.json')['counts']; manifest['repair_cycle']='2_of_2_FINAL_preparation_only'; manifest['not_execution_evidence']=True
manifest['corrected_failed_review_archive']={'repo_path':'docs/validation/audits/a2-preparation-2026-11-11/corrected-contract-reviews-failed.tar.gz','sha256':'d44c2b69c29f2e88862d5380c188f1855798131a1b34ddaf4736d4ac34a81616'}
manifest['schema_control_witnesses']={'linked_hypothetical_bundles':17,'typed_status_witnesses':38,'future_full_bindings':64,'root_variants':17,'structural_negative_controls':37,'semantic_tamper_controls':12,'label':'STATIC/HYPOTHETICAL REPRESENTABILITY ONLY; NOT ACTUAL WORKER/PROCESS/FITTER OUTPUTS'}
manifest['resource_limit_disclosure']={k:proof[k] for k in ['input_max_bytes','index_single_max_bytes','index_transaction_max_bytes','bounded_preflight_refusals','template_nodes_max','template_depth_max']}
dump(AUD/'packet-manifest.json',manifest)
# Read back exact target, not a successful write alone.
back=read('packet-manifest.json'); assert back==manifest and back['self_hash_excluded'] is True
for z in back['files']: assert len((ROOT/z['repo_path']).read_bytes())==z['bytes'] and sha((ROOT/z['repo_path']).read_bytes())==z['sha256']
review_inputs=[('/home/davianc/.hermes/cache/scratch/a2-math-independent-corrected-t2gfcgtl/verdict.json','c1ef69eacf2d824171a0af65df01da54664d2b475d561f10b220b77caea4775b'),('/home/davianc/.hermes/cache/scratch/a2-validation-schema-review-20261111/review-verdict.json','4c7598dd227f8deea6967128b9f8f578a99b5eba2b5716c45fec924ae50b3bf6'),(str(AUD/'corrected-contract-reviews-failed.tar.gz'),'d44c2b69c29f2e88862d5380c188f1855798131a1b34ddaf4736d4ac34a81616')]
review_verification=[]
for path,h in review_inputs:
    raw=Path(path).read_bytes(); assert sha(raw)==h; review_verification.append({'path':path,'bytes':len(raw),'sha256':h,'verified':True})
dump(HERE/'review-evidence-input-verification.json',review_verification)
base=json.loads((HERE/'baseline.json').read_text()); modified=[]
for rel in names+['docs/validation/audits/a2-preparation-2026-11-11/packet-manifest.json']:
    data=(ROOT/rel).read_bytes(); row={'repo_path':rel,'bytes':len(data),'sha256':sha(data)}
    if rel not in base['files'] or base['files'][rel]['sha256']!=row['sha256']: modified.append(row)
    # Include untracked documentation/JSON in whitespace checks.
    assert data.endswith(b'\n') and all(not line.endswith((b' ',b'\t')) for line in data.splitlines()),rel
    if rel.endswith('.json'): json.loads(data)
assert 'docs/validation/audits/a2-preparation-2026-11-11/comparison-policies.json' not in [x['repo_path'] for x in modified]
refs=read('fixtures.json')['counts']; refusals=[z['case_id'] for z in json.loads((HERE/'full-size-templates.json').read_text()) if z['preflight_disposition'].startswith('reservation_')]
q=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True); (HERE/'git-diff-check.stdout').write_bytes(q.stdout); (HERE/'git-diff-check.stderr').write_bytes(q.stderr); dump(HERE/'git-diff-check.process.json',{'command':['git','diff','--check'],'exit_code':q.returncode}); assert q.returncode==0
report={'status':'corrected_DRAFT_pending_independent_FINAL_review_and_owner_approval','modified_or_new_paths':modified,'comparison_policy_bytes_unchanged':True,'counts':refs,'witness_counts':manifest['schema_control_witnesses'],'resource_limit_disclosure':manifest['resource_limit_disclosure'],'bounded_refusal_case_ids':refusals,'protected_numerical_files':125,'protected_baseline_paths':proof['protected_paths_checked'],'parent_owned_allowed_status_paths_not_written':['docs/developer/bug-resolution-tracker.md','docs/developer/phase-a-completion.md'],'math_section_bytes':proof['math_section_bytes'],'math_section_sha256':proof['math_section_sha256'],'implementation_authorized':False,'a2_acceptance_passed':False,'arithmetic_verified':False,'total_numerical_certified':False,'limits':proof['limits'],'raw_failures_preserved':'construction/representability numbered stdout, stderr, process JSON in this scratch directory; initial failed attempts are not reclassified','future_real_arrays_observed':False}
dump(HERE/'final-delivery-report.json',report)
print(json.dumps(report,indent=2))
