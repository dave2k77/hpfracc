"""Finite scratch-only static construction helpers; not a product validator."""
from pathlib import Path
from copy import deepcopy as C
import json, hashlib, math
ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUD=ROOT/'docs/validation/audits/a2-preparation-2026-11-11'
HERE=Path(__file__).parent
PID='a2-glrl-exact-reference-v1-draft'
HYP='1'*64  # hypothetical external packet, NOT the manifest containing these examples

def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('utf-8')
def sha(b): return hashlib.sha256(b).hexdigest()
def dh(x): return sha(canonical(x))
def read(n): return json.loads((AUD/n).read_text())
def dump(path,x): path.write_text(json.dumps(x,indent=2,ensure_ascii=True,allow_nan=False)+'\n')
def rawdesc(x): return {k:C(v) for k,v in x.items() if k!='raw_hex'}
def descriptor(x):
    return rawdesc(x) if 'raw_hex' in x else {'shape':C(x['shape']),'values_count':len(x['values']),'payload_sha256':dh(x)}
def replace_existing(root,parts,value):
    o=root
    for k in parts[:-1]:
        if isinstance(o,list): k=int(k)
        assert (isinstance(o,list) and 0<=k<len(o)) or (isinstance(o,dict) and k in o),parts
        o=o[k]
    k=parts[-1]; k=int(k) if isinstance(o,list) else k
    assert (isinstance(o,list) and 0<=k<len(o)) or (isinstance(o,dict) and k in o),parts
    o[k]=C(value)

def expanded(case,f,p):
    q=C(case['request'])
    for m in case['mutations']:
        if m['stage']=='references':
            assert m['replace'].startswith('request/')
            replace_existing(q,m['replace'].split('/')[1:],m['value'])
    refs=q.pop('candidate_refs'); q['input']=C(f['arrays'][q.pop('input_ref')]); assert q.pop('caps_ref')=='protocol.json#/caps'; q['caps']=C(p['caps'])
    q['candidates']=[]
    for key in refs:
        c=C(f['candidates'][key])
        c['record_type']='candidate_spec' if 'producer_call' in c else 'candidate'
        for field in ['rhos','coefficients']:
            a=c.pop(field+'_ref'); c[field]=None if a is None else C(f['arrays'][a])
        q['candidates'].append(c)
    q.update(record_type='request',request_id=case['case_id'],case_id=case['case_id'],policy_id=PID,packet_manifest_sha256=HYP)
    for m in case['mutations']:
        if m['stage']=='expanded':
            parts=m['replace'].split('/'); target=q if parts[0]=='request' else q['candidates'][int(parts[0].split(':')[1])]
            replace_existing(target,parts[1:],m['value'])
        elif m['stage']=='evidence':
            assert any(x['path']==m['replace'] for x in case['evidence_mutation_cells'])
            parts=m['replace'].split('/'); idx=int(parts[1].split(':')[1]); t=int(parts[3].split(':')[1]); assert idx<len(q['candidates']) and t<q['input']['shape'][0]
            tree={'evidence':{'candidate:'+str(idx):{parts[2]:{'time:'+str(k):None for k in range(q['input']['shape'][0])}}}}
            replace_existing(tree,parts,m['value'])
    if case.get('resource_control') and case['resource_control'].get('override_cap') is not None:
        z=case['resource_control']; assert z['override_cap'] in q['caps']; q['caps'][z['override_cap']]=z['value']
    return q

def occurrence(q): return [{'candidate_index':i,'candidate_id':c['stable_id']} for i,c in enumerate(q['candidates'])]
def inventory(case,q):
    return [{'slot_id':z['slot_id'],'candidate_id':None if z['candidate_index'] is None else q['candidates'][z['candidate_index']]['stable_id'],'candidate_index':z['candidate_index'],'mode':z['mode'],'branch':z['branch'],'quantity':z['quantity']} for z in case['required_evidence_slots']]
def shape(z,q):
    k=z['quantity']; sh=q['input']['shape']; n=sh[0]
    if k in ['input','v','D','D_hat','error','B','analytic_input_gradient','output','full_output','input_AD','direction']: return C(sh)
    if k in ['w','g','g_hat','residual','signed_fitted_weights']: return [n]
    if k=='L_hat': return [n,n]
    if k in ['rhos','coefficients','zero_pattern']: return [q['candidates'][z['candidate_index']]['configuration']['pole_count']]
    return []
def comparisons(case,q):
    return [dict(record_type='comparison',comparison_id=z['comparison_id'],case_id=q['case_id'],candidate_id=None if z['candidate_index'] is None else q['candidates'][z['candidate_index']]['stable_id'],candidate_index=z['candidate_index'],policy_id=z['policy_id'],a_slot_id=z['a_slot_id'],reference_slot_id=z['reference_slot_id'],status='not_evaluated',reasons=['not_evaluated']) for z in case.get('required_working_comparisons',[])]
def checks(case,q):
    return [dict(record_type='binding_check',case_id=q['case_id'],candidate_id=q['candidates'][z['candidate_index']]['stable_id'],candidate_index=z['candidate_index'],mode=z['mode'],branch=z['branch'],reference_branch=z['reference_branch'],observation_id=None,reference_observation_id=None,comparison=z['comparison'],status='not_evaluated',reasons=['not_evaluated'],check_id=z['check_id']) for z in case.get('required_fit_identity_checks',[])]
def phase(status='not_applicable',a=None,b=None,reason='stage_not_used'):
    return dict(status=status,start_ns=a,end_ns=b,elapsed_ns=None if a is None or b is None else b-a,reason=reason)
def process(q,kind='normal',bundle='2'*64):
    launched=kind not in ['not_launched','reservation_exceeded']
    killed=kind in ['timeout','barrier']; unavailable=kind=='unconfirmed'
    trigger=12 if kind=='barrier' else 60000000012
    kill=trigger+1000000000; stop=kill+10 if killed else 112
    return dict(record_type='process',run_id='hyp-run',process_id='hyp-process',case_id=q['case_id'],request_id=q['request_id'],input_bundle_sha256=bundle,launch_receipt_sha256='3'*64 if launched else None,command=['HYPOTHETICAL-NOT-EXECUTED'],exit_code=None if unavailable or not launched else (-9 if killed else 0),termination='kill' if killed else ('normal' if launched else 'not_launched'),elapsed_monotonic_ns=None if not launched or unavailable else stop-12,watchdog_triggered=killed,stdout_sha256=None,stderr_sha256=None,stdout_truncated=False,stderr_truncated=False,exit_confirmed=launched and not unavailable,barrier='held' if kind=='barrier' else ('released' if launched else 'not_launched'),phases=dict(preflight=phase('observed',1,11,'none'),watchdog=phase('unavailable',reason='exit_unconfirmed') if unavailable else phase('observed',12,stop,'none') if launched else phase(),grace=phase('observed',trigger,kill,'none') if killed else phase(),kill_to_exit=phase('observed',kill,stop,'none') if killed else phase()))
def input_bundle(case,q,canonical_valid=True):
    inv=inventory(case,q); cmp=comparisons(case,q); chk=checks(case,q)
    sources=[{'repo_path':name,'sha256':sha((ROOT/name).read_bytes())} for name in ['src/hpfracc/ops/_soe.py','src/hpfracc/ops/fractional.py','uv.lock','docs/developer/a2-compression-budget-protocol.md']]
    return dict(record_type='input_bundle',request=C(q) if canonical_valid else None,sources=sources,required_slots=inv,raw_request_utf8_hex='' if canonical_valid else canonical(q).hex(),raw_request_sha256=dh(q),candidate_ids=[x['candidate_id'] for x in occurrence(q)],candidate_occurrences=occurrence(q),required_comparisons=[{k:z[k] for k in ['comparison_id','candidate_id','candidate_index','policy_id','a_slot_id','reference_slot_id']} for z in cmp],required_binding_checks=[{k:z[k] for k in ['check_id','candidate_id','candidate_index','mode','branch','reference_branch','comparison']} for z in chk])
def index(case,q,pr,bundle):
    return dict(record_type='failure_index',request_id=q['request_id'],input_bundle_sha256=bundle,candidate_ids=[c['stable_id'] for c in q['candidates']],candidate_occurrences=occurrence(q),slots=[dict(**z,status='not_evaluated',reason='not_evaluated',reasons=['not_evaluated'],expected_shape=shape(z,q),completed_shape=None,artifact=None) for z in inventory(case,q)],status='not_evaluated',reasons=['not_evaluated'],process=C(pr),comparisons=comparisons(case,q),binding_checks=checks(case,q),bytes_accounting=dict(live_bytes=0,cumulative_written_bytes=0,reserved_final_transaction_bytes=0))
