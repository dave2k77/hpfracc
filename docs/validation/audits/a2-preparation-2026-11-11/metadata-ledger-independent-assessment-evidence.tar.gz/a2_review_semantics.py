"""Bounded independent negative probes of the copied, unmodified author model.
No repairs, fabricated numerical arrays, process observations, or full exports.
The intended gate exits 1 when independently demonstrated blockers survive.
"""
import copy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'author-copy'))
from a2_model import Graph, F, DEFS, schema

CASE = next(c for c in F['cases'] if c['case_id']=='FIT-stacked-tau1-f32-GL')
SPEC = {'tag':'review-negative','winners':(0,0),'fault':None}

def graph(): return Graph(CASE,SPEC)
def audit_accepts(g):
    try:
        r=g.audit()
        return {'accepted':True,'structural_constraints_flag':r['symbolic_constraints_closed'],'ledger_components_flag':r['ledger_components_closed']}
    except AssertionError as e:
        return {'accepted':False,'error':str(e)}

def main():
    tests=[]
    g=graph(); default=audit_accepts(g)
    assert default['accepted'] and default['structural_constraints_flag']
    tests.append({'control':'unclosed-positive-context-already-accepted','actual':default,'normal_exit_confirmed':g.records['records/process.json']['exit_confirmed'],'output_control_status':g.records['records/output-control.json']['status'],'result_status':g.records['result.json']['status'],'interpretation':'Necessary structural flags are true despite unconfirmed normal process and unsafe/unavailable output context; these are not valid success conditions.'})

    g=graph()
    c=next(x for x in g.comparisons if x['status']=='pass' and x['a_slot_id'] and x['reference_slot_id'])
    a=c['a_slot_id']; before=c['reference_slot_id']; ash=g.payloads[a]['shape']
    bad=next(s for s,v in g.payloads.items() if v['shape']!=ash)
    c['reference_slot_id']=bad
    assert before!=bad and a in g.payloads and bad in g.payloads
    schema(c,DEFS['comparison'])
    observed=audit_accepts(g); assert observed['accepted']
    tests.append({'control':'presence-does-not-establish-comparison-semantic-match','comparison_id':c['comparison_id'],'original_reference':before,'mutated_reference':bad,'a_shape':ash,'reference_shape':g.payloads[bad]['shape'],'status_after_mutation':c['status'],'actual':observed,'interpretation':'Both slot operands exist, but their true shapes disagree. Pass remains and audit accepts. This is a labelled in-memory negative, not measured output.'})

    g=graph()
    b=next(x for x in g.binding_checks if x['status']=='pass')
    obs={x['observation_id']:x for x in g.records.values() if x['record_type']=='observation'}
    before=b['reference_observation_id']
    swapped=next(oid for oid,v in obs.items() if v['mode']!=b['mode'] and v['candidate_index']==b['candidate_index'] and v['branch']==b['reference_branch'])
    b['reference_observation_id']=swapped
    assert swapped in obs and obs[swapped]['mode']!=b['mode'] and before!=swapped
    schema(b,DEFS['binding_check'])
    observed=audit_accepts(g); assert observed['accepted']
    tests.append({'control':'same-mode-check-rebound-to-existing-other-mode','check_id':b['check_id'],'declared_mode':b['mode'],'original_reference':before,'mutated_reference':swapped,'reference_mode':obs[swapped]['mode'],'status_after_mutation':b['status'],'actual':observed,'interpretation':'An existing target/link is not same-mode authentication. No numerical execution is needed to demonstrate the missing relationship predicate.'})

    g=graph()
    result=g.records['result.json']
    result.update(status='selected',selected_id=g.q['candidates'][0]['stable_id'],reasons=['none'])
    assert all(x['status']=='unknown' and x['qualifies'] is None for x in result['assessments'])
    schema(result,DEFS['result'])
    observed=audit_accepts(g); assert observed['accepted']
    tests.append({'control':'invalid-selected-result-with-all-assessments-unknown','result_status':result['status'],'selected_id':result['selected_id'],'assessment_statuses':[a['status'] for a in result['assessments']],'qualifies':[a['qualifies'] for a in result['assessments']],'exit_confirmed':g.records['records/process.json']['exit_confirmed'],'actual':observed,'interpretation':'Deliberately invalid copied symbolic success passes the local structural interpreter and audit. This is NOT an author-generated successful export or a defect in the normative packet; required semantic predicates are absent from the author method.'})

    g=graph()
    original=g.ledger
    pristine=original()
    def uncharged_log():
        ledger=original()
        for name in ('cumulative','live_sufficient'):
            term=ledger[name]
            assert term['coefficients'].pop('stdout_raw')==1
            term['limits'].pop('stdout_raw')
            term['lower']=term['constant']+sum(n*term['limits'][k][0] for k,n in term['coefficients'].items())
            term['upper']=term['constant']+sum(n*term['limits'][k][1] for k,n in term['coefficients'].items())
        return ledger
    g.ledger=uncharged_log
    mutated=g.ledger()
    assert 'stdout_raw' in mutated['components']
    assert mutated['cumulative']['upper']==pristine['cumulative']['upper']-16384
    observed=audit_accepts(g); assert observed['accepted'] and observed['ledger_components_flag']
    tests.append({'control':'remove-charged-log-affine-term-and-recompute-bounds','omitted_parameter':'stdout_raw','upper_bytes_uncharged':16384,'lower_bytes_uncharged':0,'component_name_retained':True,'actual':observed,'interpretation':'Unlike the original mutants that edit reported lower/upper summaries only, this removes the actual affine log coefficient and recomputes both summaries. A possible bounded log is uncharged but the component-name gate still accepts. No actual future log length is claimed.'})
    out={'scope':'Independent reviewer-designed bounded symbolic negatives; copied original model, no repair or implementation. Every acceptance above is a demonstrated BLOCKER, not a passing operational validator result.','controls':tests,'blockers_surviving':len(tests),'overall_passed':False,'accounting_complete':False}
    with (ROOT/'independent-semantic-negative-proof.json').open('x') as f:
        json.dump(out,f,indent=2,sort_keys=True); f.write('\n')
    print(json.dumps(out,indent=2))
    raise SystemExit(1)

if __name__=='__main__': main()
