"""Assemble independent adjudication from actual preserved and fresh receipts."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
M=Path('/home/davianc/.hermes/cache/scratch/a2-ledger-continuation-20261112/ledger-assessment-inputs.json')
A=Path('/home/davianc/.hermes/cache/scratch/a2_ledger_proof_20261112_d72ac91b')
B=Path('/home/davianc/.hermes/cache/scratch/a2_obligation_TomeBgNo')
AUDIT=REPO/'docs/validation/audits/a2-preparation-2026-11-11'

def load(p):return json.loads(p.read_bytes())
def desc(p):
    raw=p.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def dump(name,x):
    with (ROOT/name).open('x')as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
def nodes(x):
    # Interpret only declared symbolic atoms; don't count their annotation wrappers as real JSON nodes.
    if isinstance(x,dict)and 'SYMBOL'in x:return 1
    if isinstance(x,dict)and 'SYMBOLIC_RATIONAL_VECTOR'in x:return 1+5*x['count']
    if isinstance(x,dict):return 1+len(x)+sum(nodes(v)for v in x.values())
    if isinstance(x,list):return 1+sum(nodes(v)for v in x)
    return 1

def main():
    before=load(ROOT/'input-verification.json');manifest=load(M)
    assert desc(M)['sha256']=='329b3305c6d6096bb780ea01a5afff60f45c1f318e123026093083b9c8cdf005'
    sets=[]
    for base,files in [(REPO,manifest['repo_files'])]+[(Path(k),{str(Path(p).relative_to(k)):v for p,v in fs.items()})for k,fs in manifest['child_files'].items()]:
        for rel,expected in files.items():assert desc(base/rel)==expected,str(base/rel)
        sets.append({'base':str(base),'verified_files':len(files)})
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()==manifest['head']
    assert desc(REPO/'.git/index')['sha256']==manifest['git_index_sha256']
    assert hashlib.sha256(subprocess.check_output(['git','ls-files','--stage'],cwd=REPO)).hexdigest()==manifest['index_entries_sha256']
    packet=load(AUDIT/'packet-manifest.json')
    for e in packet['files']:assert desc(REPO/e['repo_path'])=={k:e[k]for k in ('bytes','sha256')}
    protocol=load(AUDIT/'protocol.json')
    sources=protocol['preparation_source_pin']['files']
    for e in sources:assert desc(REPO/e['repo_path'])['sha256']==e['sha256']
    # Validate raw capture readbacks, using child actual exits rather than wrapper success.
    replays={}
    wanted={
        'author-copy/semantic-replay':1,'author-copy/mutants-replay':1,
        'author-copy/structural-red-replay':1,'author-copy/structural-green-replay':0,
        'advisory-copy/lower-replay':0,'parse-coverage-and-raw':0,'independent-negatives':1,'verify-inputs':0}
    for rel,exit_code in wanted.items():
        path=ROOT/rel;r=load(path/'process.json');pre=load(path/'pre_run.json')
        assert r['actual_exit']==exit_code and r['launch_error']is None and r['command']==pre['command'],rel
        for n,expected in r['streams'].items():assert desc(path/n)==expected
        for n,expected in pre['sources'].items():assert desc(path/'pre_run_sources'/n)==expected
        replays[rel]={'actual_exit':r['actual_exit'],'process_handle':desc(path/'process.json'),'stdout':desc(path/'stdout.txt'),'stderr':desc(path/'stderr.txt'),'pre_run':desc(path/'pre_run.json')}
    mutant=load(ROOT/'author-copy/mutants-results.json')
    assert (mutant['tests_run'],mutant['failures'],mutant['errors'])==(11,5,0)
    assert set(mutant['survivors'])=={'uncharged-log','uncharged-manifest','uncharged-old-index','uncharged-temp','unsupported-shape-truncation'}
    semantic=load(ROOT/'author-copy/checked-open-obligations.json')
    assert semantic==load(A/'checked-open-obligations.json')
    assert load(ROOT/'advisory-copy/index-lower-proof.json')==load(B/'index-lower-proof.json')
    for rel,n,fails in [('author-copy/mutants-replay',11,5),('author-copy/structural-red-replay',4,4),('author-copy/structural-green-replay',4,0)]:
        text=(ROOT/rel/'stderr.txt').read_text()
        assert re.search(r'Ran '+str(n)+r' tests? in ',text)
        assert (f'FAILED (failures={fails})'in text)if fails else ('\nOK\n'in text)
        assert not re.search(r'^ERROR:',text,re.M)
    raw=load(ROOT/'coverage-and-raw-record-proof.json')
    annotations=load(A/'representative-symbolic-records.json')['records'];sizes=load(A/'representative-record-sizes.json')
    calculated={k:nodes(v)for k,v in annotations.items()}
    assert calculated=={k:v['nodes']for k,v in sizes.items()}
    # Verify that the controlling process used the currently frozen model and semantic source.
    stop_pre=load(A/'final_semantic_gate/pre_run.json');stop=load(A/'final_semantic_gate/process.json')
    for name in ('a2_model.py','a2_obligations.py'):assert desc(A/name)==stop_pre['sources'][name]
    subsequent=[]
    for p in sorted(A.rglob('process.json')):
        r=load(p)
        if r['started_utc']>stop['ended_utc']:subsequent.append({'label':p.parent.name,'actual_exit':r['actual_exit'],'command':r['command']})
    assert {r['label']for r in subsequent}=={'finalize_evidence','index_build','index_verify'}
    # No universal claim follows from a conservative interval. Verify just the schedule arithmetic recorded.
    ledger=load(A/'representative-ledger.json')
    assert ledger['index_generations']==374 and ledger['array_commits']==372
    assert ledger['cumulative']['lower']==136772468
    assert max(calculated.values())==51560
    guard={'all_frozen_files_reverified':sets,'manifest':desc(M),'head':manifest['head'],'git_index_sha256':manifest['git_index_sha256'],'index_entries_sha256':manifest['index_entries_sha256'],'packet_files':len(packet['files'])+1,'numerical_source_pins':len(sources),'all_protected_bytes_unchanged':True,'status_docs':'Two parent-owned status docs excluded from protected-byte equality; no reviewer writes.'}
    dump('protected-inputs-after.json',guard)
    rawproof={'scope':'Independent read-only assessment. Original records parsed; bounded copied-script and reviewer-designed symbolic negative replays. No operational validator, selector, JAX, fitter, application, AD, worker, full suite or GPU executed.','input_verification':{'path':'input-verification.json',**desc(ROOT/'input-verification.json')},'replays':replays,'raw_record_proof':{'path':'coverage-and-raw-record-proof.json',**desc(ROOT/'coverage-and-raw-record-proof.json')},'reviewer_negative_proof':{'path':'independent-semantic-negative-proof.json',**desc(ROOT/'independent-semantic-negative-proof.json')},'independently_recounted_nodes_all_505_records_match':True,'author_semantic_record_exact_replay_match':True,'advisory_lower_record_exact_replay_match':True,'mutants':mutant,'subsequent_captured_author_processes':subsequent,'controlling_pre_run_sources_match_final_bytes':True,'capture_limits':['Historical receipts and their matching byte snapshots are preserved evidence, not independent OS authentication of historical execution.','1392 profile coverage was checked by parsing/identities/inventories, not rebuilt. Only bounded representative models and negative fixtures were replayed.','Symbolic descriptors lacking equality constraints are not proof that real unobserved values differ.','A zero issue count from the partial semantic checker is not full export validity.','Declared frozen sets were checked, not unrelated filesystem/profile/process state.','Index excludes itself, its verification record and live capture directories explicitly.']}
    dump('raw-proof.json',rawproof)
    blockers=[
        {'id':'METHOD-SEMANTICS','classification':'author symbolic model / semantic proof','detail':'131 unclosed conditions: 42 same-mode alpha/dt/input identities (20/20/2), 18 perturbed-alpha configuration linkages, 69 inferred passes (37 comparisons/32 binding checks), normal-exit confirmation and conditional safe output. Different symbols are unproved equalities, not measured mismatches.','evidence':['author-copy/semantic-replay/process.json','coverage-and-raw-record-proof.json']},
        {'id':'METHOD-LEDGER','classification':'author gate / accounting predicate','detail':'All four author uncharged-byte controls survive. Original controls alter summary bounds only and therefore demonstrate no independent total/equation check, not that the pristine formula omitted those terms. The reviewer additionally removed the actual affine stdout coefficient, recomputed bounds and retained the component name: audit still accepted.','evidence':['author-copy/mutants-results.json','independent-semantic-negative-proof.json']},
        {'id':'METHOD-SHAPE','classification':'author semantic linkage','detail':'Unsupported admitted D shape [18] -> [17] is accepted by audit. A separate existing-operand [17,3] -> [17] comparison-reference substitution also retains pass. Normative true-shape/no-broadcast requirements are present, not missing schema scope.','evidence':['author-copy/mutants-results.json','independent-semantic-negative-proof.json']},
        {'id':'METHOD-COMPLETION','classification':'author coverage / success semantics','detail':'All generated results are indeterminate with unknown assessments; 512 winner labels are not qualified selected/noqualifier outcomes. A deliberately invalid selected result with all assessments unknown and normal exit unconfirmed is accepted by the local structural interpreter/audit. Complete valid exports demonstrated: 0.','evidence':['a2_review_coverage.py','independent-semantic-negative-proof.json','author-copy/a2_model.py']},
        {'id':'RESOURCE-UNFINISHED','classification':'unclosed whole-ledger sufficiency; pre-existing index admission obstruction','detail':'No complete justified LIVE and cumulative inequality with semantic branches, constrained payload lengths, bounded context/reasons/logs/temp/manifests, reservation schedule and refusal proof. Unchanged 512 KiB index transaction still has a mandatory-cardinality lower obstruction; raising it alone would not close other gates.','evidence':['advisory-copy/index-lower-proof.json','coverage-and-raw-record-proof.json','author-copy/a2_model.py']}
    ]
    assessment={
        'assessment_id':'a2-resumed-ledger-independent-assessment-20261112-c4f26a91',
        'overall_passed':False,'accounting_complete':False,'cap_revision_justified':False,'budget_proposed':None,'budget_applied':False,'stop_correct':True,
        'verdict':'FAILED_LEDGER_PROOF_CONFIRMED_STOP_CORRECT_NO_CAP_REVISION',
        'scope':'Fresh independent read-only adjudication, not a writer/repair cycle or a rerun of scientific tests. Parent owns closure/status.',
        'reviewed_input_manifest':{'path':str(M),**desc(M)},'protected_pins':guard,'verified_archives':before['archives'],'verified_evidence_indices':before['children'],
        'inventories':raw['inventories'],'coverage':raw['coverage'],'representative':raw['representative'],
        'semantic_categories':raw['independent_raw_semantic_reduction']['categories'],
        'blockers':blockers,'actual_replay_exits':{k:v['actual_exit']for k,v in replays.items()},
        'inferred_pass_adjudication':'Not justified: complete operands or present observations do not establish the named shape/finite/tolerance/byte-identity predicates. Symbolic conditional pass is permissible only when those explicit predicates constrain the branch; here source lines 365 and 373 infer it from presence. Winner labels do not supply those constraints. The 69 are unproved statuses, not 69 observed numerical failures.',
        'structural_red_green_adjudication':'Reproduced 4 failures/4 tests/exit1 -> 4 passes/4 tests/exit0. Necessary graph/presence seams only. symbolic_constraints_closed is a guard-count comparison, not semantic closure. Partial semantic checker reports zero on 356 coverage rows; these are not 356 complete valid exports.',
        'advisory_adjudication':{
            'approval_of_author':False,'batching_defensible':True,
            'schedule':'I0 INITIAL before arithmetic; Iq required candidate-0 qualifier checkpoint for the fault-control path; If FINAL after process confirmation or a truthful incomplete/kill outcome. Other bounded checkpoints only where needed, with every generation charged.',
            'text_handles':['docs/developer/a2-compression-budget-protocol.md:376-394','docs/validation/audits/a2-preparation-2026-11-11/schema-control-contract.md:188-229','docs/validation/audits/a2-preparation-2026-11-11/packet-notes.md:136-175'],
            'conditions':['Immutable atomic batch publication and no overwrite/upgrading partials','Preserve mandatory qualifier checkpoint; no silent completed-file loss','Final supervisor authentication of every retained file, including partial/kill windows; stale checkpoint never means completion','Charge each index generation, old+new coexistence, failure roots, process/export and manifest; reserve final report before each batch'],
            'author_schedule':{'array_commits':372,'index_generations':374,'cumulative_lower_bytes':136772468,'adjudication':'Schedule-specific draft expression. Every-array rewrites are not textually mandated. This is neither actual overflow of a valid export nor intrinsic 16 MiB impossibility.'},
            'independent_index_lower_bytes':[614416,616852],'historic_stronger_index_lower_bytes':[614748,617184],
            'index_scope':'Copied advisory derivation replayed byte-for-byte. Intentionally smaller-than-valid skeletons lower-bound mandatory inventory and old/new coexistence for eight float32 tau1 cases. Independently weaker historical corroboration, not replacement and not valid exports.',
            'node_scope':'Author chosen result has 51560 nodes; advisory all-inventory placement has 41598..46044 completed-base lower nodes. Per-record, not sum across files. Placement-specific, not proof every schema-permitted placement overflows.',
            'whole_evidence_scope':'Conservative rational-length envelope can exceed 16 MiB (one 289-value array upper 4741073, six Lhat/two copies upper 56892876). Upper > cap does not establish actual overflow, attainable simultaneous maxima, or impossibility. A chosen finite schedule/design is not full sufficient accounting.'},
        'caps_unchanged':{'failure_index_transaction_bytes':524288,'json_nodes_per_record':32768,'live_evidence_bytes':16777216,'cumulative_evidence_bytes':16777216},
        'why_keep_caps_unchanged':'The bounded authorization conditions revision on sufficient completed accounting, which failed. No sufficient replacement values follow. This is NOT proof current caps permit all required positive cases: the known 512 KiB admission obstruction remains. It does NOT establish a need to change 16 MiB or numerical limits; changing only index/node caps cannot repair semantic omissions.',
        'scope_or_schema_redesign_necessity_established':False,'numerical_execution_necessity_for_conditional_metadata_established':False,
        'necessity_limits':'The reproduced blockers are method/gate defects with normative predicates already present. No new scope/schema redesign or physical fitter/AD execution necessity is established by this bounded assessment; this is not a global proof that no other obstacle exists. Actual future scientific gates remain unobserved.',
        'stop_basis':'Authorized one bounded attempt failed the controlling semantic gate; captured later author commands are finalization/index preservation only and controlling model/obligation bytes match final sources. No post-stop repair authorization exists. Captures are not a global process-history proof.',
        'method_lesson':'Before bulk profile enumeration, close one end-to-end conditional semantic tracer through comparison/binding predicates, truthful completion, and a recomputed whole-ledger equation; require arithmetic omissions and invalid-success negatives to fail. Necessary presence GREEN is not completion.',
        'remaining_decision':'Parent may close this bounded attempt as stopped/failed on this evidence. Any further proof work needs a separately authorized finite acceptance target and stop rule; no automatic new cycle, repair, cap choice, implementation, freeze, commit or push is recommended.',
        'approval_flags':{'implementation_authorized':False,'protocol_freeze':False,'scientific_acceptance':False,'a2_acceptance':False,'phase_a_closed':False},
        'writes':'Only this new unique scratch directory; no repository/index/old-proof/profile/skill/config/auth writes.',
        'raw_proof':{'path':'raw-proof.json',**desc(ROOT/'raw-proof.json')}
    }
    dump('assessment.json',assessment)
    print(json.dumps({'overall_passed':False,'accounting_complete':False,'cap_revision_justified':False,'stop_correct':True,'new_outputs':['protected-inputs-after.json','raw-proof.json','assessment.json'],'replay_exits':assessment['actual_replay_exits'],'pins_verified':sets},indent=2))

if __name__=='__main__':main()
