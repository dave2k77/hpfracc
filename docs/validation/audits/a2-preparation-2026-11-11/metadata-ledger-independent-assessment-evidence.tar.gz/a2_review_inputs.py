"""Read-only verification of frozen inputs; all new writes beside this script."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
MANIFEST = Path('/home/davianc/.hermes/cache/scratch/a2-ledger-continuation-20261112/ledger-assessment-inputs.json')
PIN = '329b3305c6d6096bb780ea01a5afff60f45c1f318e123026093083b9c8cdf005'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def desc(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}

def dump(name, value):
    target = ROOT / name
    with target.open('x') as f:
        json.dump(value, f, sort_keys=True, indent=2)
        f.write('\n')

def verify():
    raw = MANIFEST.read_bytes()
    assert sha(raw) == PIN
    data = json.loads(raw)
    failures = []
    sets = {}
    for label, base, files in [('repo', REPO, data['repo_files'])] + [(p, Path(p), {str(Path(k).relative_to(p)): v for k, v in files.items()}) for p, files in data['child_files'].items()]:
        total = 0
        for rel, expected in files.items():
            p = base / rel
            assert not p.is_symlink(), p
            raw = p.read_bytes()
            total += len(raw)
            if desc(raw) != expected:
                failures.append({'path': str(p), 'expected': expected, 'actual': desc(raw)})
        sets[label] = {'files': len(files), 'bytes': total}
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip()
    index = sha((REPO / '.git/index').read_bytes())
    stage = sha(subprocess.check_output(['git', 'ls-files', '--stage'], cwd=REPO))
    assert head == data['head'] and index == data['git_index_sha256'] and stage == data['index_entries_sha256']
    children = {}
    for base, files in data['child_files'].items():
        p = Path(base)
        idx_raw = (p / 'evidence-index.json').read_bytes()
        idx = json.loads(idx_raw)
        if isinstance(idx['files'], dict):
            entries = idx['files']
            exclusions = set(idx['excluded_exact_files'])
            prefixes = [x + '/' for x in idx['excluded_capture_directories']]
        else:
            entries = {v['path']: {k: v[k] for k in ('bytes', 'sha256')} for v in idx['files']}
            exclusions = set(idx['excluded_records'])
            prefixes = idx['excluded_in_progress_run_prefixes']
        for rel, expected in entries.items():
            assert desc((p / rel).read_bytes()) == expected, rel
        actual = {str(x.relative_to(p)) for x in p.rglob('*') if x.is_file()}
        filtered = {x for x in actual if x not in exclusions and not any(x.startswith(q) for q in prefixes)}
        assert filtered == set(entries), (p, sorted(filtered ^ set(entries)))
        frozen = {str(Path(k).relative_to(p)) for k in files}
        assert actual == frozen, (p, actual ^ frozen)
        children[p.name] = {'index': desc(idx_raw), 'indexed_files': len(entries), 'indexed_bytes': sum(v['bytes'] for v in entries.values()), 'all_files': len(actual), 'exact_membership_verified': True}
    audit = REPO / 'docs/validation/audits/a2-preparation-2026-11-11'
    archives = {}
    for who, base in zip(('author', 'advisory'), data['child_files']):
        p = audit / ('metadata-ledger-' + who + '-evidence.tar.gz')
        with tarfile.open(p, 'r:gz') as tf:
            members = tf.getmembers()
            assert all(m.isfile() for m in members), 'archive nonregular members'
            names = [m.name for m in members]
            assert len(names) == len(set(names)), 'duplicate archive names'
            expected = {str(Path(k).relative_to(base)): v for k, v in data['child_files'][base].items()}
            assert set(names) == set(expected), (who, sorted(set(names) ^ set(expected)))
            for member in members:
                assert desc(tf.extractfile(member).read()) == expected[member.name], member.name
            archives[who] = {'archive': str(p), **desc(p.read_bytes()), 'members_verified_against_frozen_child_files': len(members)}
    author = Path(next(p for p in data['child_files'] if 'ledger_proof' in p))
    advisor = Path(next(p for p in data['child_files'] if 'obligation_' in p))
    for a, b in [(audit/'metadata-ledger-author-outcome.json', author/'proof.json'), (audit/'metadata-ledger-author-methodology.md', author/'methodology.md'), (audit/'metadata-ledger-advisory-methodology.md', advisor/'findings-methodology.md')]:
        assert a.read_bytes() == b.read_bytes()
    processes = {}
    for who, base in [('author', author), ('advisory', advisor)]:
        receipts = []
        for p in sorted(base.rglob('process.json')):
            r = json.loads(p.read_bytes())
            # Author stream receipts bind exact raw stdout/stderr, not wrapper exits.
            for name, expect in r.get('streams', {}).items():
                assert desc((p.parent / name).read_bytes()) == expect, str(p)
            pre = p.parent / 'pre_run.json'
            if pre.exists():
                plan = json.loads(pre.read_bytes())
                assert plan['command'] == r['command']
                for name, expected in plan['sources'].items():
                    assert desc((p.parent/'pre_run_sources'/name).read_bytes()) == expected
            receipts.append({'path': str(p.relative_to(base)), 'receipt': r})
        processes[who] = receipts
    assert not failures, failures
    result = {'passed': True, 'manifest': {'path': str(MANIFEST), **desc(MANIFEST.read_bytes())}, 'sets': sets, 'head': head, 'git_index_sha256': index, 'index_entries_sha256': stage, 'children': children, 'archives': archives, 'raw_processes': processes, 'status': subprocess.check_output(['git', 'status', '--short'], cwd=REPO).decode(), 'scope': 'Exact frozen bytes, archive members, declared index membership, source snapshots and original stream receipts. No numerical or semantic approval.'}
    dump('input-verification.json', result)
    # Replay sources only after input verification. Output paths in these files resolve beside copied a2_capture.py.
    target = ROOT / 'author-copy'
    target.mkdir()
    selected = ['a2_capture.py','a2_model.py','a2_obligations.py','a2_mutants.py','a2_tests.py']
    ast_summary = {}
    for name in selected:
        raw = (author/name).read_bytes()
        tree = ast.parse(raw)
        ast_summary[name] = {'source': str(author/name), **desc(raw), 'imports': [ast.unparse(n) for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))], 'write_and_process_calls': [ast.unparse(n) for n in ast.walk(tree) if isinstance(n, ast.Call) and any(k in ast.unparse(n.func) for k in ('write','dump','mkdir','subprocess','open','run('))]}
        (target/name).write_bytes(raw)
    dump('copied-source-inspection.json', {'files': ast_summary, 'adaptations': [], 'output_location_change': 'Unmodified sources relocated; ROOT comes from copied a2_capture.py __file__. No outputs target the originals. No numerical imports.'})
    print(json.dumps({'verified_sets':sets,'indices':children,'archives':archives,'author_processes':[(x['path'],x['receipt'].get('actual_exit')) for x in processes['author']], 'copied': selected}, indent=2))

if __name__ == '__main__':
    verify()
