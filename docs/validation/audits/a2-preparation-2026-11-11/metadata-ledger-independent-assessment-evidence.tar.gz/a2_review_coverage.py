"""Independent reductions of frozen records; no bulk model construction."""
from collections import Counter, defaultdict
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
A = Path('/home/davianc/.hermes/cache/scratch/a2_ledger_proof_20261112_d72ac91b')
B = Path('/home/davianc/.hermes/cache/scratch/a2_obligation_TomeBgNo')
AUDIT = REPO/'docs/validation/audits/a2-preparation-2026-11-11'

def load(p): return json.loads(p.read_bytes())
def dump(name, d):
    with (ROOT/name).open('x') as f: json.dump(d, f, indent=2, sort_keys=True); f.write('\n')

def raw_obligations(records):
    # Independently read annotated original records, not the author's unresolved() function.
    bindings = [(p,b) for p,b in records.items() if b['record_type']=='producer_binding' and b['producer']['kind']=='actual_fitter']
    bases = {(b['mode'],b['candidate_index']):b for _,b in bindings if b['branch']=='base'}
    categories = Counter()
    examples = {}
    for path,b in bindings:
        base = bases.get((b['mode'],b['candidate_index']))
        branch = b['branch']
        fields = ['alpha','dt'] + (['input'] if branch=='ad-base' else []) if branch=='ad-base' or branch.startswith('input-') else []
        for field in fields:
            if base and b[field] != base[field]:
                key = 'same-mode-actual-'+field+'-identity'
                categories[key] += 1
                examples.setdefault(key, {'record':path,'actual_descriptor':b[field],'base_descriptor':base[field]})
        if branch.startswith('order-') and b['configuration']['alpha']=={'num':'1','den':'2'}:
            key = 'actual-perturbed-alpha-equals-configuration-alpha'
            categories[key] += 1
            examples.setdefault(key, {'record':path,'configuration_alpha':b['configuration']['alpha'],'raw_alpha_descriptor':b['alpha']})
    index = records['failure-index.json']
    pass_by_type = {k:sum(x['status']=='pass' for x in index[k]) for k in ('comparisons','binding_checks')}
    categories['pass-conditioned-on-declared-numerical-or-identity-predicate'] = sum(pass_by_type.values())
    process = records['records/process.json']
    slots = records['result.json']['shared_slots'] + [s for a in records['result.json']['assessments'] for s in a['slots']]
    if any(s['status']=='complete' for s in slots) and process['termination']=='normal' and not process['exit_confirmed']:
        categories['positive-normal-completion-has-confirmed-exit-or-constrained-observation'] += 1
    out = records['records/output-control.json']
    if any(s['status']=='complete' for s in slots) and (out['status']!='safe' or not all(out[k] for k in ('fresh_private_root','subdirs_private','nofollow_verified','regular_owned_single_link','containment_verified'))):
        categories['emitted-evidence-has-valid-hypothetical-safe-owned-schedule'] += 1
    return {'categories':dict(categories),'unresolved':sum(categories.values()),'pass_by_type':pass_by_type,'examples':examples,'process':process,'output_control':out,'result_status':records['result.json']['status'],'selected_id':records['result.json']['selected_id'],'assessment_statuses':dict(Counter(a['status'] for a in records['result.json']['assessments']))}

def main():
    f = load(AUDIT/'fixtures.json'); w = load(AUDIT/'schema-control-fixtures.json'); p = load(AUDIT/'protocol.json')
    cases = {c['case_id']:c for c in f['cases']}; assert len(cases)==len(f['cases'])
    inv = {'cases':len(cases),'groups':dict(Counter(c['group'] for c in cases.values())),'arrays':len(f['arrays']),'candidate_specs':len(f['candidates']),'quantity_slots':sum(len(c['required_evidence_slots']) for c in cases.values()),'max_slots':max(len(c['required_evidence_slots']) for c in cases.values()),'working_comparisons':sum(len(c.get('required_working_comparisons',[])) for c in cases.values()),'fit_binding_checks':sum(len(c.get('required_fit_identity_checks',[])) for c in cases.values()),'exact_required_comparison_names':sum(len(c['required_comparisons']) for c in cases.values()),'parser_controls':len(f['parse_controls']),'identity_controls':len(f['identity_controls']),'shortcut_controls':len(f['shortcut_controls'])}
    future = [c for c in f['candidates'].values() if 'producer_call' in c]
    assert len(future)==12 and all(c['rhos_ref'] is None and c['coefficients_ref'] is None for c in future)
    full = w['future_full_bindings']; assert len(full)==64
    assert all(x['observation']['producer'] is None and x['observation']['producer_binding_sha256'] is None and all(s['raw_array'] is None and s['exact_array'] is None for s in x['observation']['slots']) for x in full)
    inv.update(future_fit_specs_unobserved=len(future), future_full_observations_unobserved=len(full))
    rows=[]
    for path in sorted(A.glob('coverage-*.jsonl')):
        rows.extend(json.loads(line) for line in path.read_text().splitlines())
    assert len(rows)==1392 and sorted(r['ordinal'] for r in rows)==list(range(1392))
    bycase=defaultdict(list)
    for r in rows:
        bycase[r['case_id']].append(r)
        c=cases[r['case_id']]
        assert r['group']==c['group']
        assert r['inventories']=={'slots':len(c['required_evidence_slots']),'comparisons':len(c.get('required_working_comparisons',[])),'binding_checks':len(c.get('required_fit_identity_checks',[])),'full_observations':len(c.get('required_full_observations',[]))}
    assert set(bycase)==set(cases)
    faults={'bits','bytes','invalid','knownbad','missing','ops','partial','refusal','startup','timeout','unconfirmed'}
    for cid, rs in bycase.items():
        if cases[cid]['group']=='FIT-REAL':
            assert len(rs)==27
            assert Counter(tuple(r['profile']['winners']) for r in rs if r['profile']['fault'] is None)==Counter(itertools.product((None,0,1,2),repeat=2))
            assert Counter(r['profile']['fault'] for r in rs if r['profile']['fault'])==Counter(faults)
        else: assert len(rs)==1 and rs[0]['profile']=={'tag':'declared','fault':None,'winners':[None,None]}
    coverage={'profiles':len(rows),'distinct_cases':len(bycase),'structural_successes':sum(r['model_structural_exit']==0 for r in rows),'zero_open_semantics':sum(r['open_semantic_obligations']==0 for r in rows),'profiles_by_group':dict(Counter(r['group'] for r in rows)),'winner_pair_profiles':sum(r['group']=='FIT-REAL' and r['profile']['fault'] is None for r in rows),'supplementary_fault_profiles':sum(r['profile']['fault'] is not None for r in rows),'per_fit_case_profiles':27,'limitations':'Parsed and cross-checked recorded coverage, not a replay of all 1392 models. Winner labels are not qualified outcomes. Source unconditionally constructs indeterminate result/unknown assessments.'}
    rep = load(A/'representative-symbolic-records.json')['records']
    sizes = load(A/'representative-record-sizes.json'); links = load(A/'representative-link-table.json')
    standalone = [v for v in rep.values() if v['record_type']=='slot']
    assert len(rep)==len(sizes)==505 and len(standalone)==372 and len(links)==1389
    semantic = raw_obligations(rep)
    declared = load(A/'checked-open-obligations.json')
    assert semantic['unresolved']==131==declared['unresolved_count']
    assert Counter(semantic['categories'])==Counter(x['obligation'] for x in declared['unresolved'])
    assert all(rep['result.json']['status']=='indeterminate' for _ in [0])
    metrics={'records':len(rep),'standalone_payload_terms':len(standalone),'links':len(links),'max_record_nodes':max(x['nodes'] for x in sizes.values()),'max_depth':max(x['depth'] for x in sizes.values()),'node_max_records':[k for k,v in sizes.items() if v['nodes']==max(x['nodes'] for x in sizes.values())]}
    original_processes = {}
    for label in ['regression_red','regression_green_structural_only','meaningful_mutants','final_semantic_gate','coverage_a','coverage_b','coverage_c','first_model','model_exercise']:
        receipt=load(A/label/'process.json')
        text=(A/label/'stderr.txt').read_text()
        original_processes[label]={'actual_exit':receipt['actual_exit'],'raw_summary_lines':[line for line in text.splitlines() if line.startswith(('Ran ','FAILED','OK','AssertionError:'))]}
    lower=load(B/'index-lower-proof.json'); resource=load(B/'resource-proof.json')
    blocked=[x for x in lower['rows'] if x['exceeds_524288']]
    assert len(blocked)==8 and [min(x['old_plus_new_necessary_lower_bytes'] for x in blocked),max(x['old_plus_new_necessary_lower_bytes'] for x in blocked)]==[614416,616852]
    resource_summary={'advisory_index_lower':lower['obstructed_minmax'],'obstructed_cases':len(blocked),'all_inline_base_node_lower_minmax':[min(r['all_inline_base_complete_lower'] for r in resource['all_inline_result_node_bounds'] if '-tau1-f32-' in r['case_id']),max(r['all_inline_base_complete_lower'] for r in resource['all_inline_result_node_bounds'] if '-tau1-f32-' in r['case_id'])],'syntax_envelope':resource['syntactic_bit_envelope'],'reason_bound':resource['reason_bound']}
    out={'inventories':inv,'coverage':coverage,'representative':metrics,'independent_raw_semantic_reduction':semantic,'original_process_outcomes':original_processes,'advisory_resource_summary':resource_summary,'caps':p['caps']}
    dump('coverage-and-raw-record-proof.json',out)
    print(json.dumps({'inventories':inv,'coverage':coverage,'representative':metrics,'semantic_categories':semantic['categories'],'pass_by_type':semantic['pass_by_type'],'original_outcomes':original_processes},indent=2))

if __name__=='__main__': main()
