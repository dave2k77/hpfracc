"""Build/verify this scratch review's explicit non-self-referential inventory."""
import hashlib
import json
from pathlib import Path
import sys
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
M=Path('/home/davianc/.hermes/cache/scratch/a2-ledger-continuation-20261112/ledger-assessment-inputs.json')
EXACT={'evidence-index.json','evidence-index-verification.json'}
PREFIXES=('review-index-build/','review-index-verify/')

def desc(p):
    raw=p.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def entries():
    d={}
    for p in sorted(ROOT.rglob('*')):
        assert not p.is_symlink(),p
        if not p.is_file():continue
        rel=str(p.relative_to(ROOT))
        if rel in EXACT or any(rel.startswith(x)for x in PREFIXES):continue
        d[rel]=desc(p)
    return d

def protected():
    assert desc(M)['sha256']=='329b3305c6d6096bb780ea01a5afff60f45c1f318e123026093083b9c8cdf005'
    m=json.loads(M.read_bytes())
    groups=[(REPO,m['repo_files'])]+[(Path(k),{str(Path(p).relative_to(k)):v for p,v in fs.items()})for k,fs in m['child_files'].items()]
    for base,files in groups:
        for rel,v in files.items():assert desc(base/rel)==v,str(base/rel)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()==m['head']
    assert desc(REPO/'.git/index')['sha256']==m['git_index_sha256']
    assert hashlib.sha256(subprocess.check_output(['git','ls-files','--stage'],cwd=REPO)).hexdigest()==m['index_entries_sha256']
    return {'manifest':desc(M),'groups':{str(p):len(fs)for p,fs in groups},'head':m['head'],'git_index_sha256':m['git_index_sha256'],'index_entries_sha256':m['index_entries_sha256']}

def main():
    mode=sys.argv[1]
    if mode=='build':
        d={'label':'Independent assessment evidence, not numerical validation or approval','excluded_exact_files':sorted(EXACT),'excluded_capture_prefixes':list(PREFIXES),'files':entries()}
        with (ROOT/'evidence-index.json').open('x')as f:json.dump(d,f,indent=2,sort_keys=True);f.write('\n')
        print(json.dumps({'built_index':desc(ROOT/'evidence-index.json'),'indexed_files':len(d['files']),'indexed_bytes':sum(x['bytes']for x in d['files'].values())}))
    elif mode=='verify':
        d=json.loads((ROOT/'evidence-index.json').read_bytes())
        assert d['files']==entries(),'Exact review inventory/hash/size mismatch'
        pins=protected()
        a=json.loads((ROOT/'assessment.json').read_bytes())
        assert a['overall_passed']is False and a['accounting_complete']is False and a['cap_revision_justified']is False and a['stop_correct']is True
        out={'verified':True,'exact_index_membership':True,'index':desc(ROOT/'evidence-index.json'),'indexed_files':len(d['files']),'indexed_bytes':sum(x['bytes']for x in d['files'].values()),'protected_pins':pins,'assessment':desc(ROOT/'assessment.json'),'assessment_markdown':desc(ROOT/'assessment.md'),'raw_proof':desc(ROOT/'raw-proof.json'),'exclusions_are_explicit_not_budget_exemptions':True}
        with (ROOT/'evidence-index-verification.json').open('x')as f:json.dump(out,f,indent=2,sort_keys=True);f.write('\n')
        print(json.dumps(out,indent=2))
    else:raise ValueError(mode)

if __name__=='__main__':main()
