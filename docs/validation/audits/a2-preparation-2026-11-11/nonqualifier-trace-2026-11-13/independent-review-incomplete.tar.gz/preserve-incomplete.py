"""Preserve an incomplete review; do not resume the approval-gated action."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
ALLOW = (
    'inputs/author-index.json', 'inputs/review-inputs.json',
    'inputs/baseline-inputs.json', 'protection-start.json',
    'blocked-attempt.json', 'executed-initial-command.txt',
    'initial-tool-result.json', 'verdict.json', 'preserve-incomplete.py',
)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


checks = {}
review = json.loads((HERE / 'inputs/review-inputs.json').read_bytes())
baseline = json.loads((HERE / 'inputs/baseline-inputs.json').read_bytes())
exceptions = set(baseline['allowed_status_delta'])
for label, entries in (
    ('review', review['files']),
    ('baseline', {p: m for p, m in baseline['files'].items() if p not in exceptions}),
):
    changed = []
    for name, expected in entries.items():
        raw = (ROOT / name).read_bytes()
        if len(raw) != expected['bytes'] or digest(raw) != expected['sha256']:
            changed.append(name)
    checks[label] = {'count': len(entries), 'mismatches': changed}
assert not any(v['mismatches'] for v in checks.values()), 'Protected source drift'
(HERE / 'protection-end.json').write_text(json.dumps({
    'checks': checks,
    'scope': 'Final read-only protected-file check; no author member verification or copying.',
}, indent=2) + '\n')

# This is only a bounded review-proof scan, not the unperformed candidate scan.
# Pattern specifications in this scanner are benign detector definitions.
patterns = {
    'credential_value': r'(?i)(?:api[_-]?key|password|passwd|access_token|refresh_token|bot_token)\s*[=:]\s*[\"\x27][A-Za-z0-9_./+=:-]{8,}',
    'private_key_material': r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    'telegram_credential_shape': r'\b[0-9]{8,12}:[A-Za-z0-9_-]{30,}\b',
    'service_credential_shape': r'\bsk-[A-Za-z0-9]{16,}\b',
    'numeric_delivery_identifier': r'(?i)[\"\x27](?:chat_id|user_id|recipient_id|message_id)[\"\x27]\s*:\s*[\"\x27]?-?[0-9]{4,}',
}
findings = []
scan_names = (*ALLOW, 'protection-end.json')
for name in scan_names:
    text = (HERE / name).read_text()
    for rule, pattern in patterns.items():
        count = len(re.findall(pattern, text))
        if count:
            findings.append({'file': name, 'rule': rule, 'count': count})
privacy = {
    'scope': 'Explicit generated-file allowlist only; no candidate archive body scan.',
    'files_scanned': list(scan_names),
    'findings': findings,
    'private_identity_matching': False,
    'limitations': [
        'Pattern-only; no private identity sources accessed.',
        'No recursive candidate body inspection; no publication approval.',
        'Expected task-local paths and manifest hashes are retained as evidence handles.',
    ],
}
(HERE / 'reviewer-proof-privacy.json').write_text(json.dumps(privacy, indent=2) + '\n')
assert not findings, 'Unresolved reviewer-proof privacy pattern findings'
print(json.dumps({'preservation_only': True, 'protection': checks,
                  'proof_scan_file_count': len(scan_names), 'pattern_findings': findings,
                  'blocked_action_executed': False}, sort_keys=True))
