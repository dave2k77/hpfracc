"""Approved archive verification/copy operation; no execution of archived code."""
import hashlib
import json
import tarfile
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/nonqualifier-trace-2026-11-13'
HERE = Path(__file__).parent
ARCHIVE_PIN = '8bb7abf9283211a3bc86634a12ac5ec20ba4c27070c4592770cc95619110e45a'
INDEX_PIN = 'eb341ebe9f912a3e0684cf074489c36dd849b3dd0049af014fa6a9ccbe3c9f23'
REVIEW_PIN = 'e0f5c757763d00159a2ca85ffe4a890f05674341d6e264755aea1508cba69654'

def metadata(body):
    return {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}

archive = WORK / 'author-evidence.tar.gz'
assert metadata(archive.read_bytes())['sha256'] == ARCHIVE_PIN
review_raw = (WORK / 'review-inputs.json').read_bytes()
assert metadata(review_raw)['sha256'] == REVIEW_PIN
review = json.loads(review_raw)
assert all(metadata((ROOT/name).read_bytes()) == expected for name,expected in review['files'].items())
with tarfile.open(archive,'r:gz') as opened:
    members = opened.getmembers()
    names = [member.name for member in members]
    assert len(names) == len(set(names)) == 776
    assert all(m.isfile() and not m.name.startswith('/') and '\\' not in m.name
               and all(part not in ('','.','..') for part in m.name.split('/')) for m in members)
    index_raw = opened.extractfile('evidence-index.json').read()
    assert metadata(index_raw)['sha256'] == INDEX_PIN
    index = json.loads(index_raw)
    assert index['file_count'] == len(index['files']) == 775
    assert set(names) == set(index['files']) | {'evidence-index.json'}
    for name, expected in index['files'].items():
        assert metadata(opened.extractfile(name).read()) == expected
    chosen = [name for name in index['files'] if name.startswith(('baseline/','final/','inputs/'))]
    chosen += ['source.diff','last-approved-source.diff','authority-derivation.json',
               'result.json','lint-delta.json','security-scan.json','privacy-scan.json',
               'prepare.py','tools/run_snapshot.py','prepare_final_runs.py']
    assert len(chosen) == len(set(chosen)) and set(chosen) <= set(names)
    destination = HERE / 'copied'
    destination.mkdir(mode=0o700,exist_ok=False)
    for name in chosen:
        target = destination / name
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:
            stream.write(opened.extractfile(name).read())
        assert metadata(target.read_bytes()) == index['files'][name]
    with (HERE/'author-index.json').open('xb') as stream:
        stream.write(index_raw)
    result = {'status':'Approved verification/copy operation completed',
              'archive_sha256':ARCHIVE_PIN,'index_sha256':INDEX_PIN,
              'review_manifest_sha256':REVIEW_PIN,
              'verified_indexed_files':len(index['files']),
              'regular_members':len(members),
              'explicit_copied_members':{name:index['files'][name] for name in chosen},
              'repository_files_written':False,'archived_code_executed':False,
              'independent_review_completed':False,
              'prior_blocked_invocation_relabelled_executed':False}
    with (HERE/'archive-verification.json').open('x') as stream:
        stream.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'verified_indexed_files':len(index['files']),
                      'regular_members':len(members),'copied_members':len(chosen)},indent=2))
