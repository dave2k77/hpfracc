"""Parent exact-reference check of ONE frozen static no-qualifier witness.

No JAX, fitting, worker simulation or claimed runtime/operation-counter evidence.
"""
import hashlib
import json
import math
import struct
from fractions import Fraction
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
OUT = AUDIT / 'nonqualifier-trace-2026-11-13'
fixtures = json.loads((AUDIT / 'fixtures.json').read_text())
witnesses = json.loads((AUDIT / 'schema-control-fixtures.json').read_text())
case = next(c for c in fixtures['cases'] if c['case_id'] == 'REF-FAIL-f64-GL')
witness = next(b for b in witnesses['bundles'] if b['witness_id'] == 'nonqualify-REF-FAIL-f64-GL')
assert case['mutations'] == [] and case['resource_control'] is None
assert len(case['request']['candidate_refs']) == 1
candidate = fixtures['candidates'][case['request']['candidate_refs'][0]]

def rational(item):
    n, d = int(item['num'], 16), int(item['den'], 16)
    assert d > 0 and math.gcd(abs(n), d) == 1
    return Fraction(n, d)

def values(descriptor):
    assert descriptor['dtype'] == 'float64'
    assert descriptor['byte_order'] == 'little' and descriptor['layout'] == 'C'
    body = bytes.fromhex(descriptor['raw_hex'])
    assert len(body) == descriptor['nbytes']
    assert hashlib.sha256(body).hexdigest() == descriptor['sha256']
    decoded = struct.unpack('<' + 'd' * math.prod(descriptor['shape']), body)
    assert all(math.isfinite(x) for x in decoded)
    return list(map(Fraction.from_float, decoded))

request = case['request']
x = values(fixtures['arrays'][request['input_ref']])
c = values(fixtures['arrays'][candidate['coefficients_ref']])
rho = values(fixtures['arrays'][candidate['rhos_ref']])
alpha, dt, tau = map(rational, [request['alpha'], request['dt'], request['tau']])
assert alpha == Fraction(1, 2) and dt == Fraction(1, 4)
assert x == [Fraction(1)] * 3 and c == rho == [Fraction(1, 2)]
n = len(x)
scale = Fraction(2)  # Exact dt**(-alpha) at the frozen half order and quarter dt.
w = [Fraction(1)]
for k in range(1, n):
    w.append(w[-1] * (k - 1 - alpha) / k)
g = [sum(w[:k+1]) for k in range(n)]
v = [x[0]] + [x[k] - x[k-1] for k in range(1, n)]
direct = [scale * sum(w[k]*x[i-k] for k in range(i+1)) for i in range(n)]
fitted = [Fraction(1)] + [sum(coef * pole**(k-1) for coef,pole in zip(c,rho,strict=True)) for k in range(1,n)]
residual = [a-b for a,b in zip(fitted,g,strict=True)]
epsilon = max(map(abs,residual))
weights = [fitted[0]] + [fitted[k]-fitted[k-1] for k in range(1,n)]
matrix = [[scale*weights[i-j] if j<=i else Fraction(0) for j in range(n)] for i in range(n)]
output = [sum(matrix[i][j]*x[j] for j in range(n)) for i in range(n)]
assert output == [scale*sum(fitted[k]*v[i-k] for k in range(i+1)) for i in range(n)]
assert [output[i]-direct[i] for i in range(n)] == [scale*sum(residual[k]*v[i-k] for k in range(i+1)) for i in range(n)]
error = [abs(a-b) for a,b in zip(output,direct,strict=True)]
bound = [scale*epsilon*sum(map(abs,v[:i])) for i in range(n)]
assert all(e<=b for e,b in zip(error,bound,strict=True))
gradient = [Fraction(2,n)*sum(matrix[i][j]*output[i] for i in range(n)) for j in range(n)]
quantities = {'S-X-w':w,'S-X-g':g,'S-X-v':v,'S-X-D':direct,
              'S-0-g_hat':fitted,'S-0-residual':residual,
              'S-0-signed_fitted_weights':weights,
              'S-0-L_hat':[a for row in matrix for a in row],
              'S-0-D_hat':output,'S-0-error':error,'S-0-B':bound,
              'S-0-epsilon':[epsilon],'S-0-analytic_input_gradient':gradient}
assert set(quantities) == {row['slot_id'] for row in case['required_evidence_slots']}
for sid, expected in quantities.items():
    slot = witness['artifacts']['arrays/'+sid+'.json']
    payload = slot['exact_array']
    shape = [] if sid.endswith('epsilon') else ([n,n] if sid.endswith('L_hat') else [n])
    assert payload['shape'] == shape and list(map(rational,payload['values'])) == expected
qualifies = all(b<=tau for b in bound)
assert not qualifies
result = witness['artifacts']['result.json']
assert result['status'] == case['expected']['request_status'] == 'no_supplied_candidate_meets_bound'
assert result['selected_id'] is None and result['assessments'][0]['qualifies'] is qualifies
report = {'scope':'PARENT SELF-CHECK of frozen STATIC/HYPOTHETICAL inputs; not independent review or worker observation',
          'case_id':case['case_id'],'witness_id':witness['witness_id'],
          'input_files':{name:hashlib.sha256((AUDIT/name).read_bytes()).hexdigest() for name in ['fixtures.json','schema-control-fixtures.json']},
          'slot_count':len(quantities),'tau':str(tau),'epsilon':str(epsilon),
          'bounds':list(map(str,bound)),'actual_discrete_errors':list(map(str,error)),
          'candidate_qualifies':qualifies,'expected_status':result['status'],
          'all_exact_payloads_match':True,'reference_quantities':{k:list(map(str,v)) for k,v in quantities.items()},
          'working_fitter_arrays_observed':False,'process_timing_security_counters_observed':False,
          'cap_change_or_implementation_authorized':False}
with (OUT/'parent-frozen-reference.json').open('x') as stream:
    stream.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['case_id','slot_count','tau','epsilon','bounds','candidate_qualifies','all_exact_payloads_match']},indent=2))
