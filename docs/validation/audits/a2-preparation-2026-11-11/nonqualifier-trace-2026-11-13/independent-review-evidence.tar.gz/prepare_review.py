"""Set up explicitly selected private test inputs; never modify originals."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
C = HERE / 'copied'
common = {n: 'final/'+n for n in ['a2_trace.py', 'record-schemas.json', 'protocol.json', 'pyproject.toml']}
plans = {
    'negative': common | {n: 'final/'+n for n in ['authority.json', 'test_a2_nonqualifier.py', 'test_semantics.py']},
    'positive': common | {n: 'baseline/'+n for n in ['authority.json', 'test_a2_trace.py', 'test_a2_routing.py']} | {'test_equality.py': 'final/test_equality.py', 'baseline-trace.json': 'baseline/trace.json'},
    'derivation': common | {'authority.json': 'final/authority.json', 'positive-authority.json': 'baseline/authority.json', 'test_derivation.py': 'final/test_derivation.py'} | {n: 'inputs/'+n for n in ['fixtures.json', 'schema-control-fixtures.json', 'packet-manifest.json']},
}
for name, files in plans.items():
    dest = HERE / 'runs' / name / 'before'
    dest.mkdir(parents=True, exist_ok=False)
    for target, source in files.items():
        (dest / target).write_bytes((C / source).read_bytes())
(HERE/'test-input-plan.json').write_text(json.dumps(plans, indent=2)+'\n')
trace = json.loads((C/'final/trace.json').read_bytes())
records = trace['records']
print(json.dumps({
    'result_without_inline_payloads': {k:v for k,v in records['result.json'].items() if k not in ['shared_slots', 'assessments']},
    'assessment_without_slots': {k:v for k,v in records['result.json']['assessments'][0].items() if k != 'slots'},
    'process': records['records/process.json'],
    'export': records['records/export.json']}, indent=2))
