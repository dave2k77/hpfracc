"""Read-only pin verification and explicit private copies for bounded review."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/nonqualifier-trace-2026-11-13'
APPROVED = Path('/home/davianc/.hermes/cache/scratch/hpfracc-approved-review-copy-20261113')

def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def write(name, raw):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(raw)

def load(name, expected=None):
    raw = (WORK / name).read_bytes()
    if expected:
        assert identity(raw)['sha256'] == expected, name
    write('pins/' + name, raw)
    return json.loads(raw)

review = load('review-inputs.json', 'e0f5c757763d00159a2ca85ffe4a890f05674341d6e264755aea1508cba69654')
resumption = load('review-resumption-inputs.json', 'd1e2810f0a95d15b6d4e5e92654848d133d6431927f2f7ed2eb6a1dcc06f1b0f')
baseline = load('baseline-inputs.json')
mutable = {'docs/developer/phase-a-completion.md', 'docs/developer/bug-resolution-tracker.md'}
protected = {p: v for p, v in baseline['files'].items() if p not in mutable}
for entries in (review['files'], resumption['additional_files'], protected):
    for name, expected in entries.items():
        assert identity((ROOT / name).read_bytes()) == expected, name
assert len(review['files']) == 45 and len(resumption['additional_files']) == 6
assert len(protected) == 234
commands = []
for args in (['git', 'rev-parse', 'HEAD'], ['git', 'ls-files', '--stage', '-z']):
    child = subprocess.run(args, cwd=ROOT, capture_output=True, check=False)
    commands.append({'argv': args, 'cwd': str(ROOT), 'child_exit': child.returncode,
                     'stdout': identity(child.stdout), 'stderr': identity(child.stderr)})
    assert child.returncode == 0
    if args[1] == 'rev-parse':
        assert child.stdout.decode().strip() == baseline['head']
    else:
        assert identity(child.stdout)['sha256'] == baseline['git_stage_sha256']
archive = WORK / 'author-evidence.tar.gz'
assert identity(archive.read_bytes())['sha256'] == '8bb7abf9283211a3bc86634a12ac5ec20ba4c27070c4592770cc95619110e45a'
selected = json.loads((APPROVED / 'archive-verification.json').read_bytes())['explicit_copied_members']
verified = {}
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    names = [m.name for m in members]
    assert len(names) == len(set(names)) == 776
    for m in members:
        p = PurePosixPath(m.name)
        assert m.isfile() and not p.is_absolute() and '..' not in p.parts and str(p) == m.name
    indexes = [n for n in names if n == 'evidence-index.json']
    assert len(indexes) == 1
    raw = tar.extractfile(indexes[0]).read()
    assert identity(raw)['sha256'] == 'eb341ebe9f912a3e0684cf074489c36dd849b3dd0049af014fa6a9ccbe3c9f23'
    index = json.loads(raw)
    assert set(names) == set(index['files']) | {'evidence-index.json'}
    assert len(index['files']) == index['file_count'] == 775
    write('pins/author-index.json', raw)
    for name, expected in index['files'].items():
        raw = tar.extractfile(name).read()
        assert identity(raw) == expected and len(raw) == tar.getmember(name).size, name
        verified[name] = identity(raw)
        if name in selected:
            assert expected == selected[name]
            assert (APPROVED / 'copied' / name).read_bytes() == raw
            write('copied/' + name, raw)
assert len(selected) == 32 and set(selected) <= set(verified)
report = {'review_manifest': identity((WORK/'review-inputs.json').read_bytes()),
          'resumption_manifest': identity((WORK/'review-resumption-inputs.json').read_bytes()),
          'candidate_files': 45, 'resumption_files': 6, 'protected_files': 234,
          'git_head': baseline['head'], 'git_stage_sha256': baseline['git_stage_sha256'],
          'git_commands': commands, 'archive': identity(archive.read_bytes()),
          'regular_members': 776, 'verified_indexed_files': len(verified),
          'selected_copies': selected}
write('input-verification.json', (json.dumps(report, indent=2)+'\n').encode())
print(json.dumps({'pinned_files_verified': True, 'regular_members': 776,
                  'verified_indexed_files': len(verified), 'selected_copies': len(selected)}))
