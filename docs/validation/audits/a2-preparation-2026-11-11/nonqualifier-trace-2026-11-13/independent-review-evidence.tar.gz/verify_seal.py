"""Read back every explicitly indexed proof body and final verdict."""
import hashlib
import json
from pathlib import Path
H=Path(__file__).resolve().parent
index=json.loads((H/'evidence-index.json').read_bytes())
assert index['file_count']==len(index['files'])
assert 'evidence-index.json' not in index['files']
for name,expected in index['files'].items():
    p=H/name
    assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(H)
    raw=p.read_bytes()
    assert {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}==expected,name
verdict=json.loads((H/'verdict.json').read_bytes())
assert type(verdict['review_completed']) is bool and type(verdict['passed']) is bool
assert not verdict['passed'] or (verdict['review_completed'] and not verdict['security_concerns'] and not verdict['logic_errors'])
assert verdict['evidence_directory']==str(H)
print(json.dumps({'verified_proof_files':len(index['files']),
    'evidence_index_sha256':hashlib.sha256((H/'evidence-index.json').read_bytes()).hexdigest(),
    'review_completed':verdict['review_completed'],'passed':verdict['passed'],
    'verdict_path':str(H/'verdict.json'),'evidence_index_path':str(H/'evidence-index.json')}))
