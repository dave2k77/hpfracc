"""Assert recorded child exits; capture-helper success alone is insufficient."""

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    name = sys.argv[1]
    result = json.loads((HERE / "runs" / name / "result.json").read_bytes())
    path = HERE / "expected-controls.json"
    expectations = json.loads(path.read_bytes()) if path.exists() else {}
    expected = expectations.get(name, {"exit": 0})
    assert result["actual_exit"] == expected["exit"], (name, result)
    assert result["source_hashes_unchanged"]
    for key, value in expected.get("junit", {}).items():
        assert result["junit"][key] == value
    for stream in ["stdout", "stderr"]:
        if stream + "_contains" in expected:
            raw = (HERE / "runs" / name / (stream + ".bin")).read_bytes().decode()
            assert expected[stream + "_contains"] in raw, raw
    if "missing" in expected:
        assert expected["missing"] in (HERE / "runs" / name / "stderr.bin").read_text()
    print(
        json.dumps(
            {
                "run": name,
                "actual_exit_asserted": result["actual_exit"],
                "expected_control": name in expectations,
                "junit": result.get("junit", {}).get("collected"),
            }
        )
    )


if __name__ == "__main__":
    main()
