"""Explicit run selections; executes nothing."""

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = "/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc"
PREFIX = ["uv", "--project", ROOT, "run", "--frozen", "--no-sync"]


def job(
    name,
    files,
    args,
    authority="data/nonqualifier/authority.json",
    source="final/a2_trace.py",
):
    inputs = {
        p: str(HERE / "inputs" / p)
        for p in [
            "pyproject.toml",
            "protocol.json",
            "record-schemas.json",
        ]
    }
    inputs["a2_trace.py"] = str(HERE / source)
    inputs["authority.json"] = str(HERE / authority)
    inputs.update({p: str(HERE / src) for p, src in files.items()})
    value = {
        "label": name,
        "project": ROOT,
        "scope": (
            "STATIC/HYPOTHETICAL author self-verification only; no worker execution"
        ),
        "inputs": inputs,
        "command": PREFIX + args,
    }
    (HERE / "jobs" / (name + ".json")).write_text(json.dumps(value, indent=2) + "\n")


def pytest_args(*names):
    return [
        "python",
        "-B",
        "-m",
        "pytest",
        "-c",
        "{before}/pyproject.toml",
        "-q",
        "-p",
        "no:cacheprovider",
        "--basetemp={run}/runtime/pytest",
        "--junitxml={run}/raw.xml",
        *["{before}/" + name for name in names],
    ]


def main():
    job(
        "01-semantic",
        {p: "final/" + p for p in ["test_a2_nonqualifier.py", "test_semantics.py"]},
        pytest_args("test_a2_nonqualifier.py", "test_semantics.py"),
    )
    job(
        "02-regression",
        {p: "baseline/" + p for p in ["test_a2_trace.py", "test_a2_routing.py"]},
        pytest_args("test_a2_trace.py", "test_a2_routing.py"),
        authority="baseline/authority.json",
    )
    job(
        "03-exact-physical",
        {"verify_independent.py": "final/verify_independent.py"},
        ["python", "-B", "{before}/verify_independent.py", "build"],
    )
    job(
        "04-equality",
        {
            "test_a2_trace.py": "baseline/test_a2_trace.py",
            "test_equality.py": "final/test_equality.py",
            "baseline-trace.json": "baseline/trace.json",
        },
        pytest_args("test_equality.py"),
        authority="baseline/authority.json",
    )
    job(
        "05-derivation",
        {
            **{
                p: "inputs/" + p
                for p in [
                    "fixtures.json",
                    "schema-control-fixtures.json",
                    "packet-manifest.json",
                ]
            },
            "test_derivation.py": "final/test_derivation.py",
            "positive-authority.json": "baseline/authority.json",
        },
        pytest_args("test_derivation.py"),
    )


if __name__ == "__main__":
    main()
