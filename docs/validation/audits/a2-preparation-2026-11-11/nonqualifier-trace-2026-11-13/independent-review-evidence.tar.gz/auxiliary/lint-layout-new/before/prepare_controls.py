"""Prepare finite portability, missing-input, mutation and lint jobs only."""

import json
import shutil
from pathlib import Path

from make_jobs import job, pytest_args

HERE = Path(__file__).resolve().parent


def main():
    for name, source in {
        "trace.json": "runs/03-exact-physical/artifacts/trace.json",
        "authority.json": "data/nonqualifier/authority.json",
        "protocol.json": "inputs/protocol.json",
        "record-schemas.json": "inputs/record-schemas.json",
        "pyproject.toml": "inputs/pyproject.toml",
    }.items():
        shutil.copyfile(HERE / source, HERE / "final" / name)
    files = {
        "verify_independent.py": "final/verify_independent.py",
        "trace.json": "final/trace.json",
    }
    job(
        "06-portable",
        files,
        ["python", "-B", "{before}/verify_independent.py", "replay"],
    )
    job(
        "07-read-guard",
        files,
        ["python", "-B", "{before}/verify_independent.py", "guard-probe"],
    )
    expectations = {
        "06-portable": {"exit": 0},
        "07-read-guard": {
            "exit": 1,
            "stderr_contains": "PermissionError: undeclared Python-level read",
        },
    }
    for n, missing in enumerate(
        ["authority.json", "record-schemas.json", "protocol.json", "trace.json"], 8
    ):
        name = f"{n:02d}-missing-{missing.removesuffix('.json')}"
        job(name, files, ["python", "-B", "{before}/verify_independent.py", "replay"])
        path = HERE / "jobs" / (name + ".json")
        value = json.loads(path.read_bytes())
        del value["inputs"][missing]
        path.write_text(json.dumps(value, indent=2) + "\n")
        expectations[name] = {
            "exit": 1,
            "stderr_contains": "FileNotFoundError",
            "missing": missing,
        }
    source = (HERE / "final/a2_trace.py").read_text()
    mutants = {
        "completion": (
            "    check_completion(records)\n",
            "",
            "test_semantics.py::test_completion_refusals[unknown]",
        ),
        "binding": (
            "    check_links(trace)\n",
            "",
            "test_semantics.py::test_binding_route[fresh-0]",
        ),
        "exact": (
            "    check_fixed_exact_payloads(records)\n",
            "",
            "test_semantics.py::test_false_exact_payload_with_rebuilt_descriptor[S-0-B]",
        ),
        "lifecycle": (
            "    check_lifecycle(trace)\n",
            "",
            "test_semantics.py::test_lifecycle_refusals[publication]",
        ),
        "ledger": (
            "    need(trace['ledger'] == ledger, "
            "'ledger claim differs from independent byte replay')\n",
            "",
            "test_semantics.py::test_missing_actual_charge_recomputed_totals[INITIAL_INDEX]",
        ),
    }
    for n, (kind, (old, new, selection)) in enumerate(mutants.items(), 12):
        assert source.count(old) == 1, kind
        dest = HERE / "mutants" / kind / "a2_trace.py"
        dest.parent.mkdir(parents=True, exist_ok=False)
        dest.write_text(source.replace(old, new, 1))
        name = f"{n:02d}-mutant-{kind}"
        job(
            name,
            {p: "final/" + p for p in ["test_semantics.py", "test_a2_nonqualifier.py"]},
            pytest_args(selection),
            source=str(dest.relative_to(HERE)),
        )
        expectations[name] = {
            "exit": 1,
            "junit": {"collected": 1, "failures": 1, "errors": 0},
            "stdout_contains": "DID NOT RAISE",
            "kind": "posthoc mutation only",
        }
    lint_args = [
        "ruff",
        "check",
        "--no-cache",
        "--output-format",
        "json",
        "--config",
        "{before}/pyproject.toml",
    ]
    originals = {p: "baseline/" + p for p in ["test_a2_trace.py", "test_a2_routing.py"]}
    job(
        "17-baseline-lint",
        originals,
        lint_args
        + [
            "{before}/a2_trace.py",
            "{before}/test_a2_trace.py",
            "{before}/test_a2_routing.py",
        ],
        authority="baseline/authority.json",
        source="baseline/a2_trace.py",
    )
    job(
        "18-candidate-lint",
        originals,
        lint_args
        + [
            "{before}/a2_trace.py",
            "{before}/test_a2_trace.py",
            "{before}/test_a2_routing.py",
        ],
        authority="baseline/authority.json",
    )
    new_names = [
        "test_a2_nonqualifier.py",
        "test_semantics.py",
        "test_equality.py",
        "test_derivation.py",
        "verify_independent.py",
    ]
    job(
        "19-new-lint",
        {p: "final/" + p for p in new_names},
        lint_args + ["{before}/" + p for p in new_names],
    )
    (HERE / "expected-controls.json").write_text(
        json.dumps(expectations, indent=2) + "\n"
    )
    print(json.dumps({"planned_expected_outcomes": expectations}, sort_keys=True))


if __name__ == "__main__":
    main()
