"""Prepare an explicit, read-only-source continuation closure."""

import difflib
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path("/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc")
OLD = Path("/home/davianc/.hermes/cache/scratch/hpfracc-a2-nonqualifier-01168laz")
NEW = (
    ROOT
    / "docs/validation/audits/a2-preparation-2026-11-11/nonqualifier-trace-2026-11-13"
)


def metadata(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def protect():
    pins = json.loads((NEW / "baseline-inputs.json").read_bytes())
    checked = {
        p: metadata(ROOT / p)
        for p in pins["files"]
        if p not in pins["allowed_status_delta"]
    }
    bad = [p for p, value in checked.items() if value != pins["files"][p]]
    head = (
        subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip()
    )
    stage = hashlib.sha256(
        subprocess.check_output(["git", "ls-files", "--stage", "-z"], cwd=ROOT)
    ).hexdigest()
    assert len(checked) == 234 and not bad
    assert head == pins["head"] and stage == pins["git_stage_sha256"]
    return {
        "protected_files": checked,
        "count": len(checked),
        "changed": bad,
        "head": head,
        "git_stage_sha256": stage,
        "git_stage_encoding": "git ls-files --stage -z raw bytes",
        "excluded_parent_statuses": pins["allowed_status_delta"],
    }


def main():
    save(HERE / "protection-before.json", protect())
    mapping = {
        "final/a2_trace.py": OLD / "final/a2_trace.py",
        "final/test_a2_nonqualifier.py": OLD / "final/test_a2_nonqualifier.py",
        "tools/run_snapshot.py": OLD / "run_snapshot.py",
        "data/nonqualifier/authority.json": OLD / "data/nonqualifier/authority.json",
        "authority-derivation.json": OLD / "authority-derivation.json",
    }
    for name in [
        "a2_trace.py",
        "test_a2_trace.py",
        "test_a2_routing.py",
        "authority.json",
        "trace.json",
    ]:
        mapping["baseline/" + name] = OLD / "baseline" / name
    for name in [
        "protocol.json",
        "record-schemas.json",
        "pyproject.toml",
        "fixtures.json",
        "schema-control-fixtures.json",
        "packet-manifest.json",
    ]:
        mapping["inputs/" + name] = OLD / "inputs" / name
    for name in [
        "authorization.json",
        "execution-resumption-approval.json",
        "approved-resumption.json",
        "partial-author-result.json",
        "parent-frozen-reference.json",
        "baseline-inputs.json",
    ]:
        mapping["context/" + name] = NEW / name
    for name, source in mapping.items():
        dest = HERE / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
        assert metadata(source) == metadata(dest)
    expected = {
        "final/a2_trace.py": (
            "8b7049e3e5ee25f7266f0228cb72efc0726d55eb98d2a1699e3bab3263ef1c2a"
        ),
        "final/test_a2_nonqualifier.py": (
            "0f396c9913ea94ffaa193f40d484cdc08d94dcdfa53bd14b0a70b0f685bc6ba3"
        ),
        "data/nonqualifier/authority.json": (
            "9f973fc6b4de16098cb1fe7001678a1eafdf845ad4b1f3da0109055d357b271d"
        ),
        "baseline/a2_trace.py": (
            "4b28a7dfc4587dd6d6bfb63cdb5ea5362b0f5cf5ab3c1c9d31fe211465dfbd4e"
        ),
        "baseline/trace.json": (
            "ba9e40f8e9fa66d13dee2439e9087239b52e523128119eb3d0340ad2b00d2a62"
        ),
    }
    for name, digest in expected.items():
        assert metadata(HERE / name)["sha256"] == digest
    save(HERE / "copied-inputs.json", {name: metadata(HERE / name) for name in mapping})
    original = (HERE / "baseline/a2_trace.py").read_text()
    current = (HERE / "final/a2_trace.py").read_text()
    (HERE / "source.diff").write_text(
        "".join(
            difflib.unified_diff(
                original.splitlines(True),
                current.splitlines(True),
                fromfile="original-reviewed/a2_trace.py",
                tofile="final/a2_trace.py",
            )
        )
    )
    (HERE / "last-approved-source.diff").write_bytes(b"")
    (HERE / "jobs").mkdir()
    print(
        json.dumps(
            {
                "directory": str(HERE),
                "copied_files": len(mapping),
                "protected_files": 234,
                "checker_unchanged_from_approved": True,
            }
        )
    )


if __name__ == "__main__":
    main()
