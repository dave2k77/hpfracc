"""Verify archived process bindings and reproduce lint/portable controls."""
import ast
from collections import Counter
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import xml.etree.ElementTree as ET

H=Path(__file__).resolve().parent
C=H/'copied'
ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK=ROOT/'docs/validation/audits/a2-preparation-2026-11-11/nonqualifier-trace-2026-11-13'
OUT=H/'auxiliary'
OUT.mkdir(exist_ok=False)
UV=['uv','--project',str(ROOT),'run','--frozen','--no-sync']
ENV={'PYTHONDONTWRITEBYTECODE':'1','JAX_PLATFORMS':'cpu','UV_PROJECT_ENVIRONMENT':str(ROOT/'.venv'),'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}

def ident(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def enc(v):
    return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def put(name,v):
    p=OUT/name
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,indent=2)+'\n')

index=json.loads((H/'pins/author-index.json').read_bytes())['files']
archived={}
mutant_deltas={}
with tarfile.open(WORK/'author-evidence.tar.gz','r:gz') as tar:
    def get(name):
        m=tar.getmember(name)
        assert m.isfile()
        raw=tar.extractfile(m).read()
        assert ident(raw)==index[name]
        return raw
    expected=json.loads(get('expected-controls.json'))
    run_names=sorted({p.split('/')[1] for p in index if p.startswith('runs/') and p.endswith('/plan.json')})
    for name in run_names:
        prefix='runs/'+name+'/'
        plan=json.loads(get(prefix+'plan.json'))
        result=json.loads(get(prefix+'result.json'))
        assert type(result['actual_exit']) is int and result['source_hashes_unchanged'] is True
        actual_inputs={p:ident(get(prefix+'before/'+p)) for p in plan['inputs']}
        assert enc(actual_inputs)==enc(plan['inputs'])==enc(result['inputs_after'])
        for stream in ['stdout','stderr']:
            assert ident(get(prefix+stream+'.bin'))==result[stream]
        row={'actual_exit':result['actual_exit'],'input_count':len(actual_inputs),'inputs_unchanged':True,'command':plan['command'],
             'plan':index[prefix+'plan.json'],'result':index[prefix+'result.json']}
        if prefix+'raw.xml' in index:
            raw=get(prefix+'raw.xml')
            tree=ET.fromstring(raw)
            cases=tree.findall('.//testcase')
            junit={'file':ident(raw),'collected':len(cases),
                   'failures':sum(c.find('failure') is not None for c in cases),
                   'errors':sum(c.find('error') is not None for c in cases),
                   'skipped':sum(c.find('skipped') is not None for c in cases),
                   'identities':[c.attrib for c in cases]}
            assert enc(junit)==enc(result['junit'])
            for suite in tree.findall('.//testsuite'):
                local=suite.findall('testcase')
                assert int(suite.attrib['tests'])==len(local)
                for field,tag in [('failures','failure'),('errors','error'),('skipped','skipped')]:
                    assert int(suite.attrib[field])==sum(c.find(tag) is not None for c in local)
            row['junit']=junit
        archived[name]=row
        if name.startswith(('29-','30-','31-','32-','33-')):
            raw=get(prefix+'before/a2_trace.py')
            delta=''.join(difflib.unified_diff((C/'final/a2_trace.py').read_text().splitlines(True),raw.decode().splitlines(True)))
            assert delta and result['actual_exit']==1 and row['junit']['failures']>0
            mutant_deltas[name]=delta
    for name in ['make_jobs.py','prepare_controls.py','assert_run.py']:
        (C/name).write_bytes(get(name))
# Bind final success count, exact identities and intended failed controls.
selections={'20-final-semantic':31,'02-regression':26,'04-equality':1,'21-final-derivation':1}
assert sum(selections.values())==59
for name,count in selections.items():
    row=archived[name]
    assert row['actual_exit']==0 and row['junit']['collected']==count
    assert row['junit']['failures']==row['junit']['errors']==row['junit']['skipped']==0
    pin=index['runs/'+name+'/before/a2_trace.py']['sha256']
    assert pin=='8b7049e3e5ee25f7266f0228cb72efc0726d55eb98d2a1699e3bab3263ef1c2a'
for name in ['24-final-read-guard','25-final-missing-authority','26-final-missing-schemas','27-final-missing-protocol','28-final-missing-trace']:
    assert archived[name]['actual_exit']==1
put('archived-run-bindings.json',{'runs':archived,'selected_test_count':59,'mutant_deltas':mutant_deltas,
    'limitation':'Checks preserved plans/results/raw XML; not historical OS process attestation. New local runs are separate.'})

# New raw process evidence. Wrapper asserts the actual child code.
def capture(name,command,cwd,expected=0):
    directory=OUT/name
    directory.mkdir()
    plan={'argv':command,'cwd':str(cwd),'environment':ENV,'expected_child_exit':expected}
    put(name+'/plan.json',plan)
    child=subprocess.run(command,cwd=cwd,env=os.environ|ENV,capture_output=True,check=False)
    (directory/'stdout.raw').write_bytes(child.stdout)
    (directory/'stderr.raw').write_bytes(child.stderr)
    result={'actual_child_exit':child.returncode,'stdout':ident(child.stdout),'stderr':ident(child.stderr)}
    put(name+'/result.json',result)
    assert child.returncode==expected,(name,child.returncode)
    return child

config=C/'final/pyproject.toml'
base=[C/'baseline'/p for p in ['a2_trace.py','test_a2_trace.py','test_a2_routing.py']]
final=[C/'final/a2_trace.py',C/'baseline/test_a2_trace.py',C/'baseline/test_a2_routing.py']
lint={}
for name,files in [('baseline-lint',base),('candidate-lint',final)]:
    child=capture(name,UV+['ruff','check','--no-cache','--output-format','json','--config',str(config)]+list(map(str,files)),H,1)
    lint[name]=json.loads(child.stdout)
def lintkey(row):
    p=Path(row['filename'])
    return (p.name,row['code'],row['message'],p.read_text().splitlines()[row['location']['row']-1])
b=Counter(map(lintkey,lint['baseline-lint']))
f=Counter(map(lintkey,lint['candidate-lint']))
assert not (f-b)
assert len(lint['baseline-lint'])==len(lint['candidate-lint'])==108
new_files=[C/'final'/p for p in ['test_a2_nonqualifier.py','test_semantics.py','test_equality.py','test_derivation.py','verify_independent.py']]
new_files += [C/p for p in ['prepare.py','make_jobs.py','prepare_controls.py','assert_run.py','prepare_final_runs.py']]
child=capture('new-helper-lint',UV+['ruff','check','--no-cache','--output-format','json','--config',str(config)]+list(map(str,new_files)),H)
assert json.loads(child.stdout)==[]
child=capture('inherited-capture-lint',UV+['ruff','check','--no-cache','--output-format','json','--config',str(config),str(C/'tools/run_snapshot.py')],H,1)
cap=json.loads(child.stdout)
assert len(cap)==1 and cap[0]['code']=='E501'
put('lint-summary.json',{'baseline':108,'candidate':108,'added':list((f-b).elements()),'removed':list((b-f).elements()),
    'new_helper_files':len(new_files),'new_helper_findings':0,'inherited_capture_findings':1,
    'status':'Archived checker/tests retain inherited lint failures; no added checker findings. Not a repository lint claim.'})
# Basic added-source risk scan. Do not execute archived preparation scripts.
old=(C/'baseline/a2_trace.py').read_text()
new=(C/'final/a2_trace.py').read_text()
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original-reviewed/a2_trace.py',tofile='final/a2_trace.py'))
assert diff==(C/'source.diff').read_text()
assert (C/'last-approved-source.diff').read_bytes()==b''
issues=[]
scanned=[C/'final/a2_trace.py']+new_files
for p in scanned:
    tree=ast.parse(p.read_text())
    for node in ast.walk(tree):
        if isinstance(node,ast.Call):
            name=ast.unparse(node.func)
            if name in ['eval','exec','os.system','pickle.load','pickle.loads'] or any(k.arg=='shell' and isinstance(k.value,ast.Constant) and k.value.value is True for k in node.keywords):
                issues.append({'file':str(p.relative_to(H)),'line':node.lineno,'call':name})
assert not issues
put('static-security.json',{'explicit_sources':[str(p.relative_to(H)) for p in scanned], 'dangerous_calls':issues,
    'source_diff_exact':True,'approved_source_diff_empty':True,'limitation':'Finite AST/manual source review; not an operational or hostile-filesystem security assessment.'})

# Isolated copied helper replay, and truly absent input / read-guard controls.
files=['a2_trace.py','authority.json','record-schemas.json','protocol.json','trace.json','verify_independent.py']
portability={}
for name,missing,mode in [('portable',None,'replay'),('missing-authority','authority.json','replay'),
                          ('missing-schemas','record-schemas.json','replay'),('missing-protocol','protocol.json','replay'),
                          ('missing-trace','trace.json','replay'),('read-guard',None,'guard-probe')]:
    before=OUT/('input-'+name)/'before'
    before.mkdir(parents=True)
    for file in files:
        if file!=missing:
            (before/file).write_bytes((C/'final'/file).read_bytes())
    snapshots={f:ident((before/f).read_bytes()) for f in files if f!=missing}
    expected_exit=0 if name=='portable' else 1
    child=capture(name,UV+['python',str(before/'verify_independent.py'),mode],before,expected_exit)
    assert all(ident((before/f).read_bytes())==v for f,v in snapshots.items())
    if name=='read-guard':
        assert b'PermissionError: undeclared Python-level read' in child.stderr
    elif missing:
        assert b'FileNotFoundError' in child.stderr and missing.encode() in child.stderr
    portability[name]={'actual_child_exit':child.returncode,'input_files':snapshots,'missing':missing,
                       'source_hashes_unchanged':True,'python_read_audit_not_os_sandbox':True}
put('portability-summary.json',portability)
print(json.dumps({'archived_runs_bound':len(archived),'archived_selected_tests':59,'checker_mutants_rejected':len(mutant_deltas),
    'inherited_ruff_findings':108,'new_checker_findings':0,'new_helpers_clean':True,
    'portable_replay_passed':True,'negative_input_controls':5}))
