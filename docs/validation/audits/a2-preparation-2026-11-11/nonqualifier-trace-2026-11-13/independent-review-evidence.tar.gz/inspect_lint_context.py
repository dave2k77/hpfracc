"""Compare inherited lint by rule and exact source context."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import tarfile
H=Path(__file__).resolve().parent
WORK=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/docs/validation/audits/a2-preparation-2026-11-11/nonqualifier-trace-2026-11-13')
index=json.loads((H/'pins/author-index.json').read_bytes())['files']
report={}
with tarfile.open(WORK/'author-evidence.tar.gz','r:gz') as tar:
    def raw(name):
        b=tar.extractfile(name).read()
        assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==index[name]
        return b
    for current,old in [('baseline-lint','17-baseline-lint'),('candidate-lint','18-candidate-lint')]:
        current_data=json.loads((H/'auxiliary'/current/'stdout.raw').read_bytes())
        archived=json.loads(raw('runs/'+old+'/stdout.bin'))
        def key(row,arch=False):
            p=Path(row['filename'])
            source=raw('runs/'+old+'/before/'+p.name).decode() if arch else p.read_text()
            return (p.name,row['code'],row['message'],source.splitlines()[row['location']['row']-1])
        a=Counter(key(r,True) for r in archived)
        c=Counter(key(r) for r in current_data)
        report[current]={'archived_count':len(archived),'current_count':len(current_data),
                         'added_contexts':list((c-a).elements()),'removed_contexts':list((a-c).elements())}
(H/'auxiliary/lint-context-inspection.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
