"""Independent posthoc controls against the unchanged pinned checker."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

H = Path(__file__).resolve().parent
OUT = H/'controls'
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('review_negative', H/'copied/final/a2_trace.py')
A = importlib.util.module_from_spec(spec)
spec.loader.exec_module(A)

def enc(v):
    return json.dumps(v, sort_keys=True, separators=(',',':'), ensure_ascii=True, allow_nan=False).encode()

def sha(v):
    return hashlib.sha256(v).hexdigest()

def linked(t, schema=True, ledger=True):
    r=t['records']
    files={p:enc(v) for p,v in r.items()} | {p:bytes.fromhex(v) for p,v in t['logs'].items()}
    manifest={e['path']:(e['bytes'],e['sha256']) for e in r['run-manifest.json']['files']}
    assert manifest=={p:(len(v),sha(v)) for p,v in files.items() if p!='run-manifest.json'}
    for record in r.values():
        if schema:
            A.schema_check(record,A.SCHEMA)
        if record['record_type']=='producer_binding':
            for item in record['returned']:
                assert r['arrays/'+item['slot_id']+'.json']['producer_binding_sha256']==sha(enc(record))
    for row in r['failure-index.json']['slots']:
        raw=files['arrays/'+row['slot_id']+'.json']
        assert row['artifact']['sha256']==sha(raw) and row['artifact']['bytes']==len(raw)
    assert r['records/export.json']['failure_index_sha256']==sha(files['failure-index.json'])
    assert r['records/export.json']['process_sha256']==sha(files['records/process.json'])
    assert r['failure-index.json']['process']==r['records/process.json']
    if ledger:
        assert enc(A.replay_ledger(t))==enc(t['ledger'])

results=[]
def control(name, mutate, expected, transform=None, schema=True, ledger=True, pre=None):
    t=A.make_trace(mutate)
    if transform:
        transform(t)
    assert enc(t)!=enc(A.make_trace()),name
    linked(t,schema=schema,ledger=ledger)
    if pre:
        pre(t)
    (OUT/(name+'.json')).write_bytes(enc(t))
    try:
        A.verify_trace(t)
    except ValueError as exc:
        message=str(exc)
        assert any(x in message for x in expected), (name,message)
        results.append({'name':name,'rejected':True,'exception':'ValueError','reason':message,
                        'outer_hashes_checked':True,'schema_precondition':schema,'ledger_precondition':ledger,
                        'trace_sha256':sha(enc(t))})
    else:
        (OUT/'blocking-finding.json').write_text(json.dumps({'name':name,'unexpectedly_accepted':True,'trace':name+'.json'},indent=2)+'\n')
        raise AssertionError('Blocking unexpectedly accepted control: '+name)

# Exhaustive-known completion, null-bound sequencing and conditional exit.
control('unknown-assessment',lambda r:r['result.json']['assessments'][0].update(status='unknown',qualifies=None),['selection'])
control('missing-assessment',lambda r:r['result.json'].update(assessments=[]),['selection'])
control('forged-qualification',lambda r:r['result.json']['assessments'][0].update(status='known_qualifying',qualifies=True),['qualification'])
control('forged-selection',lambda r:r['result.json'].update(status='selected',selected_id='bad1-f64-GL'),['exhaustive'])
control('missing-bound-payload',lambda r:r['arrays/S-0-B.json'].update(exact_array=None),['shape'])
control('unconfirmed-exit',lambda r:r['records/process.json'].update(exit_confirmed=False,exit_code=None),['completion'])
control('nonzero-exit',lambda r:r['records/process.json'].update(exit_code=7),['completion'])
control('unexpected-watchdog',lambda r:r['records/process.json'].update(watchdog_triggered=True),['completion'])
# Canonical type checks are separate from semantic refusals.
control('boolean-exit',lambda r:r['records/process.json'].update(exit_code=False),['schema'],schema=False)
control('float-counter',lambda r:r['result.json'].update(primitive_count=0.0),['schema'],schema=False)
# Fresh as well as colliding route identities, with all outer links rebound.
for suffix,other in [('X','0'),('0','X')]:
    for kind,identity in [('fresh','host-independent-fresh'),('colliding','host-'+other)]:
        control('route-'+suffix+'-'+kind,lambda r,s=suffix,i=identity:r['records/binding-host-'+s+'.json'].update(binding_id=i),['path-to-ID'])
control('wrong-alpha',lambda r:r['records/binding-host-0.json'].update(alpha=copy.deepcopy(r['records/binding-host-0.json']['dt'])),['alpha'])
control('wrong-mode',lambda r:r['records/binding-host-0.json'].update(mode='eager'),['mode'])
control('wrong-shape',lambda r:r['arrays/S-0-D_hat.json']['exact_array'].update(shape=[1,3]),['shape'])
control('missing-index-slot',lambda r:r['failure-index.json']['slots'].pop(),['slot count'])
# Independent false payloads, including all forged qualification fields.
def payload_mutant(sid,zero_bound=False):
    def mutate(r):
        payload=r['arrays/'+sid+'.json']['exact_array']
        if zero_bound:
            payload['values']=[{'num':'0','den':'1'} for _ in payload['values']]
            r['result.json'].update(status='selected',selected_id='bad1-f64-GL')
            r['result.json']['assessments'][0].update(status='known_qualifying',qualifies=True)
        else:
            payload['values'][-1]={'num':'7','den':'8'}
        for record in r.values():
            if record['record_type']=='producer_binding':
                for item in record['returned']:
                    if item['slot_id']==sid:
                        item['descriptor']['payload_sha256']=sha(enc(payload))
    return mutate
for sid in ['S-X-D','S-0-D_hat','S-0-analytic_input_gradient','S-0-B']:
    control('false-exact-'+sid,payload_mutant(sid),['exact identity'],pre=lambda t:(A.check_links(t),A.check_completion(t['records'])))
control('false-bound-and-selection',payload_mutant('S-0-B',True),['exact identity S-0-B'],pre=lambda t:(A.check_links(t),A.check_completion(t['records'])))
control('inconsistent-phase-duration',lambda r:r['records/process.json']['phases']['watchdog'].update(elapsed_ns=98),['phase'])
control('export-before-exit',lambda r:r['records/export.json']['index_write'].update(start_ns=1,end_ns=11,elapsed_ns=10),['phase'])
def reorder(t):
    events=t['events']
    a=next(i for i,e in enumerate(events) if e.get('body')=='records/binding-host-0.json')
    b=next(i for i,e in enumerate(events) if e.get('body')=='arrays/S-0-B.json')
    events[a],events[b]=events[b],events[a]
control('publication-before-binding',lambda r:None,['publication order'],transform=reorder)
# Remove real positive byte terms, then recompute all affected claims.
def omission(component):
    def transform(t):
        claim=t['ledger']
        terms=claim['terms']
        assert terms[component]>0
        terms[component]=0
        claim['cumulative_written_bytes']=sum(terms.values())
        claim['final_live_bytes']=sum(v for k,v in terms.items() if k!='INITIAL_INDEX')
        claim['peak_live_bytes']=max(claim['final_live_bytes'],claim['final_live_bytes']+terms['INITIAL_INDEX']-terms['records/export.json']-terms['run-manifest.json'])
        claim['index_transaction_bytes']=sum(terms[p] for p in ['INITIAL_INDEX','failure-index.json','records/process.json','records/export.json','records/output-control.json'])
        claim['old_index_bytes_charged']=terms['INITIAL_INDEX']
        claim['temporary_bytes_charged']=terms['failure-index.json']
    return transform
for component in ['logs/stdout.bin','logs/stderr.bin','run-manifest.json','INITIAL_INDEX','failure-index.json','records/export.json','records/process.json']:
    control('omitted-'+component.replace('/','-'),lambda r:None,['ledger claim'],transform=omission(component),ledger=False,
            pre=lambda t:(A.check_links(t),A.check_completion(t['records']),A.check_fixed_exact_payloads(t['records']),A.check_lifecycle(t)))
assert sha((H/'copied/final/a2_trace.py').read_bytes())=='8b7049e3e5ee25f7266f0228cb72efc0726d55eb98d2a1699e3bab3263ef1c2a'
(OUT/'results.json').write_text(json.dumps({'posthoc':True,'controls':results,'control_count':len(results),'all_rejected':True},indent=2)+'\n')
print(json.dumps({'independent_posthoc_controls':len(results),'all_rejected':True,'source_unchanged':True}))
