"""Report raw lint selections without presuming archived totals."""
from collections import Counter
import json
from pathlib import Path
H=Path(__file__).resolve().parent
out={}
for label in ['baseline-lint','candidate-lint']:
    data=json.loads((H/'auxiliary'/label/'stdout.raw').read_bytes())
    out[label]={'total':len(data),'by_file':dict(Counter(Path(x['filename']).name for x in data))}
archive=json.loads((H/'auxiliary/archived-run-bindings.json').read_bytes())
for name in ['17-baseline-lint','18-candidate-lint']:
    out[name]=archive['runs'][name]['command']
(H/'auxiliary/lint-selection-inspection.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
