"""Capture actual focused child exits and raw results from copied inputs."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = '/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc'
UV = ['uv', '--project', ROOT, 'run', '--frozen', '--no-sync']

def ident(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

reports = {}
for name, tests, expected in [
    ('negative', ['test_a2_nonqualifier.py', 'test_semantics.py'], 31),
    ('positive', ['test_a2_trace.py', 'test_a2_routing.py', 'test_equality.py'], 27),
    ('derivation', ['test_derivation.py'], 1),
]:
    run = HERE / 'runs' / name
    source = run / 'before'
    snapshots = {p.name: ident(p) for p in source.iterdir() if p.is_file()}
    command = UV + ['python', '-m', 'pytest'] + [str(source/t) for t in tests] + [
        '-q', '-p', 'no:cacheprovider', '--basetemp='+str(run/'runtime'),
        '--junitxml='+str(run/'raw.xml'), '-c', str(source/'pyproject.toml')]
    plan = {'argv': command, 'cwd': str(source), 'input_files': snapshots,
            'env_overrides': {'PYTHONDONTWRITEBYTECODE': '1'}, 'expected_count': expected}
    (run/'plan.json').write_text(json.dumps(plan, indent=2)+'\n')
    child = subprocess.run(command, cwd=source, env=os.environ | {'PYTHONDONTWRITEBYTECODE': '1'},
                           capture_output=True, check=False)
    (run/'stdout.raw').write_bytes(child.stdout)
    (run/'stderr.raw').write_bytes(child.stderr)
    result = {'actual_child_exit': child.returncode, 'source_hashes_unchanged':
              all(ident(source/p) == v for p, v in snapshots.items()),
              'python_executable': sys.executable}
    if (run/'raw.xml').exists():
        tree = ET.parse(run/'raw.xml')
        cases = tree.findall('.//testcase')
        result['test_ids'] = [c.attrib['classname']+'::'+c.attrib['name'] for c in cases]
        result['test_count'] = len(cases)
        result['failed_or_skipped'] = sum(len(c) > 0 for c in cases)
        result['xml'] = ident(run/'raw.xml')
    (run/'result.json').write_text(json.dumps(result, indent=2)+'\n')
    assert child.returncode == 0, name
    assert result['source_hashes_unchanged'] and result['test_count'] == expected
    assert result['failed_or_skipped'] == 0 and len(set(result['test_ids'])) == expected
    reports[name] = result
(HERE/'focused-results.json').write_text(json.dumps(reports, indent=2)+'\n')
print(json.dumps({k: {'exit': v['actual_child_exit'], 'tests':v['test_count']} for k,v in reports.items()}))
