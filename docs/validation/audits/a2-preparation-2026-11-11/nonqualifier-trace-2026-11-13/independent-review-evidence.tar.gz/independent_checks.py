"""Independent frozen authority, exact IEEE arithmetic, physical byte replay.

Static host calculations only: no production worker, fitter, selector, JAX or AD.
"""
import hashlib
import importlib.util
import json
import math
import os
from fractions import Fraction as Q
from pathlib import Path

HERE = Path(__file__).resolve().parent
C = HERE / 'copied'
OUT = HERE / 'independent'
OUT.mkdir(exist_ok=False)

def enc(v):
    return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')

def ident(b):
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def put(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2)+'\n')

def rat(v):
    assert set(v) == {'num', 'den'} and all(type(x) is str for x in v.values())
    return Q(int(v['num'], 16), int(v['den'], 16))

def ieee(d):
    raw = bytes.fromhex(d['raw_hex'])
    assert d['byte_order'] == 'little' and d['dtype'] == 'float64'
    assert len(raw) == d['nbytes'] == 8 * math.prod(d['shape'])
    assert ident(raw)['sha256'] == d['sha256']
    numbers = []
    for i in range(0, len(raw), 8):
        bits = int.from_bytes(raw[i:i+8], 'little')
        sign, exponent, mantissa = bits >> 63, (bits >> 52) & 2047, bits & ((1 << 52)-1)
        assert exponent != 2047
        significand = mantissa + ((1 << 52) if exponent else 0)
        power = (exponent - 1023 if exponent else -1022) - 52
        value = Q(significand * (-1 if sign else 1))
        numbers.append(value * (Q(2) ** power))
    return numbers

# Re-establish trust in the source slice through frozen repository identities.
authority = json.loads((C/'final/authority.json').read_bytes())
fixture = json.loads((C/'inputs/fixtures.json').read_bytes())
witnesses = json.loads((C/'inputs/schema-control-fixtures.json').read_bytes())
positive = json.loads((C/'baseline/authority.json').read_bytes())
baseline = json.loads((HERE/'pins/baseline-inputs.json').read_bytes())['files']
source_pins = {}
for name in ['fixtures.json', 'schema-control-fixtures.json', 'protocol.json', 'record-schemas.json', 'packet-manifest.json']:
    identity = ident((C/'inputs'/name).read_bytes())
    matches = [p for p, v in baseline.items() if v == identity]
    assert matches, name
    source_pins[name] = {'identity': identity, 'frozen_repository_matches': matches}
expected = {
    'case': next(c for c in fixture['cases'] if c['case_id'] == 'REF-FAIL-f64-GL'),
    'bundle': next(b for b in witnesses['bundles'] if b['witness_id'] == 'nonqualify-REF-FAIL-f64-GL'),
    'working_scalars': fixture['working_scalars'], 'scope': positive['scope'],
    'label': witnesses['label'], 'packet_digest': witnesses['hypothetical_external_packet_sha256'],
}
assert enc(authority) == enc(expected)
assert authority['packet_digest'] == '1'*64
assert ident((C/'inputs/packet-manifest.json').read_bytes())['sha256'] != authority['packet_digest']
trace = json.loads((C/'final/trace.json').read_bytes())
R = trace['records']
request = R['input-bundle.json']['request']
assert request['tau'] == {'num': '3', 'den': '10'}
assert len(request['candidates']) == 1 and len(authority['case']['required_evidence_slots']) == 13
assert len(R) == 25 and len(trace['logs']) == 2
scalar = authority['working_scalars']['float64']
alpha, = ieee(scalar['alpha'])
dt, = ieee(scalar['dt'])
x = ieee(request['input'])
assert x == [Q(1), Q(1), Q(1)] and alpha == rat(request['alpha']) == Q(1, 2)
assert dt == rat(request['dt']) == Q(1, 4)
scale = Q(math.isqrt(dt.denominator), math.isqrt(dt.numerator))
assert scale**2 * dt == 1
candidate, = request['candidates']
c, = ieee(candidate['coefficients'])
rho, = ieee(candidate['rhos'])
assert c == rho == Q(1, 2) and candidate['stable_id'] == 'bad1-f64-GL'
w = [Q(1)]
for k in range(1, len(x)):
    w.append(w[-1] * (k-1-alpha) / k)
g = [sum(w[:j+1]) for j in range(len(x))]
v = [x[j] - (x[j-1] if j else 0) for j in range(len(x))]
direct = [scale * sum(w[j-k]*x[k] for k in range(j+1)) for j in range(len(x))]
fitted = [Q(1)] + [c*rho**j for j in range(len(x)-1)]
residual = [a-b for a,b in zip(fitted, g, strict=True)]
epsilon = max(map(abs, residual))
fitted_weights = [fitted[j] - (fitted[j-1] if j else 0) for j in range(len(x))]
L = [[scale*fitted_weights[i-j] if i>=j else Q(0) for j in range(len(x))] for i in range(len(x))]
y = [sum(a*b for a,b in zip(row,x,strict=True)) for row in L]
assert y == [scale*sum(fitted[j-k]*v[k] for k in range(j+1)) for j in range(len(x))]
error = [abs(a-b) for a,b in zip(y,direct,strict=True)]
B = [scale*epsilon*sum(map(abs,v[:j])) for j in range(len(x))]
gradient = [Q(2,len(x))*sum(L[i][j]*y[i] for i in range(len(x))) for j in range(len(x))]
values = {'S-X-w': w, 'S-X-g':g, 'S-X-v':v, 'S-X-D':direct,
          'S-0-g_hat':fitted, 'S-0-residual':residual, 'S-0-epsilon':[epsilon],
          'S-0-signed_fitted_weights':fitted_weights, 'S-0-L_hat':[t for row in L for t in row],
          'S-0-D_hat':y, 'S-0-error':error, 'S-0-B':B, 'S-0-analytic_input_gradient':gradient}
assert set(values) == {s['slot_id'] for s in authority['case']['required_evidence_slots']}
for sid, value in values.items():
    payload = R['arrays/'+sid+'.json']['exact_array']
    assert [rat(q) for q in payload['values']] == value, sid
    assert payload['shape'] == ([] if sid.endswith('epsilon') else [3,3] if sid.endswith('L_hat') else [3]), sid
assert epsilon == Q(1,8) and B == [Q(0),Q(1,4),Q(1,4)]
tau = rat(request['tau'])
assert tau == Q(3,16) and not all(b<=tau for b in B)
assert all(e<=b for e,b in zip(error,B,strict=True))
assert R['result.json']['status'] == 'no_supplied_candidate_meets_bound' and R['result.json']['selected_id'] is None
put('authority-and-exact.json', {'frozen_source_matches': source_pins, 'canonical_authority_equal': True,
    'method':'Exact IEEE-754 bit decoding and recursive GL coefficients; no checker arithmetic helpers',
    'slots':{k:list(map(str,val)) for k,val in values.items()}, 'slot_count':len(values),
    'tau':str(tau), 'epsilon':str(epsilon), 'bounds':list(map(str,B)), 'qualifies':False})

# Replay actual serialized bodies on disk, recounting every live state.
bodies = {p:enc(value) for p,value in R.items()}
bodies.update({p:bytes.fromhex(value) for p,value in trace['logs'].items()})
initial = enc(trace['initial_index'])
all_bodies = bodies | {'INITIAL_INDEX':initial}
root = OUT/'physical'
root.mkdir()
live = {}
charges = {}
states = []
snapshots = {}
cumulative = peak = 0
for event in trace['events']:
    if event['op'] == 'write':
        path, body = event['path'], event['body']
        assert path not in live and body not in charges
        assert not Path(path).is_absolute() and '..' not in Path(path).parts
        if body in ['INITIAL_INDEX','result.json','failure-index.json']:
            snapshots[body] = {'live_bytes':sum((root/p).stat().st_size for p in live), 'cumulative_written_bytes':cumulative}
        p = root/path
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open('xb') as f:
            assert f.write(all_bodies[body]) == len(all_bodies[body])
        live[path] = all_bodies[body]
        assert p.read_bytes() == live[path]
        charges[body] = p.stat().st_size
        cumulative += charges[body]
    else:
        assert event == {'op':'replace','source':'tmp/index-final.part','target':'failure-index.json'}
        assert live['failure-index.json'] == initial and live['tmp/index-final.part'] == bodies['failure-index.json']
        os.replace(root/event['source'], root/event['target'])
        live[event['target']] = live.pop(event['source'])
    assert all((root/p).read_bytes() == raw for p,raw in live.items())
    live_bytes = sum((root/p).stat().st_size for p in live)
    peak = max(peak, live_bytes)
    states.append({'event':event,'live_bytes':live_bytes,'cumulative_written_bytes':cumulative})
assert live == bodies and set(charges) == set(all_bodies)
transaction = sum(charges[p] for p in ['INITIAL_INDEX','failure-index.json','records/process.json','records/export.json','records/output-control.json'])
ledger = {'terms':charges, 'final_live_bytes':live_bytes, 'peak_live_bytes':peak,
          'cumulative_written_bytes':cumulative, 'index_transaction_bytes':transaction,
          'old_index_bytes_charged':charges['INITIAL_INDEX'], 'temporary_bytes_charged':charges['failure-index.json']}
assert enc(ledger) == enc(trace['ledger'])
caps = json.loads((C/'inputs/protocol.json').read_bytes())['caps']
assert max(peak,cumulative) <= caps['evidence_bytes'] and transaction <= caps['failure_index_bytes']
assert [live_bytes,peak,cumulative,transaction,charges['INITIAL_INDEX'],charges['failure-index.json']] == [40245,41328,45148,13098,4903,6258]
assert R['result.json']['evidence_bytes'] == snapshots['result.json']['live_bytes']
for name,record in [('INITIAL_INDEX',trace['initial_index']),('failure-index.json',R['failure-index.json'])]:
    assert enc(record['bytes_accounting']) == enc(snapshots[name] | {'reserved_final_transaction_bytes':caps['failure_index_bytes']})
# Independently count parse nodes including property keys.
metrics = {}
for name,record in list(R.items())+[('INITIAL_INDEX',trace['initial_index'])]:
    stack = [(record,1)]
    nodes = depth = 0
    while stack:
        value,level = stack.pop()
        nodes += 1
        depth = max(depth,level)
        if type(value) is dict:
            stack.extend((x,level+1) for pair in value.items() for x in pair)
        elif type(value) is list:
            stack.extend((x,level+1) for x in value)
    metrics[name] = {'nodes':nodes,'depth':depth}
    assert nodes <= caps['json_nodes'] and depth <= caps['json_depth']
assert max(m['nodes'] for m in metrics.values()) == 720
assert max(m['depth'] for m in metrics.values()) == 9
# Check lifecycle independently of the sum and checker predicates.
pos = {e['body']:i for i,e in enumerate(trace['events']) if e['op']=='write'}
assert [pos[p] for p in ['input-bundle.json','INITIAL_INDEX','records/launch.json']] == [0,1,2]
for p,record in R.items():
    if record['record_type'] == 'producer_binding':
        assert pos['records/launch.json'] < pos[p]
        for item in record['returned']:
            assert pos[p] < pos['arrays/'+item['slot_id']+'.json'] < pos['result.json']
assert pos['result.json'] < pos['records/process.json'] < pos['failure-index.json']
assert all(pos[p]<pos['records/process.json'] for p in trace['logs'])
replace, = [i for i,e in enumerate(trace['events']) if e['op']=='replace']
assert pos['failure-index.json'] < replace < pos['records/export.json'] < pos['run-manifest.json'] == len(trace['events'])-1
process = R['records/process.json']
assert process['termination']=='normal' and process['exit_confirmed'] is True and type(process['exit_code']) is int and process['exit_code']==0
for phase in [process['phases']['preflight'],process['phases']['watchdog'],R['records/export.json']['index_write']]:
    assert all(type(phase[k]) is int for k in ['start_ns','end_ns','elapsed_ns'])
    assert phase['end_ns']-phase['start_ns']==phase['elapsed_ns']>=0
assert process['phases']['watchdog']['end_ns']<=R['records/export.json']['index_write']['start_ns']
put('physical-and-causal.json', {'ledger':ledger,'states':states,'prewrite_snapshots':snapshots,
    'parse_metrics':metrics,'final_bodies':{p:ident(raw) for p,raw in bodies.items()},
    'every_body_equal':True,'all_charges_equal':True,'publication_order':True})

# Independent complete original trace and all emitted bodies under final source.
spec = importlib.util.spec_from_file_location('review_positive', HERE/'runs/positive/before/a2_trace.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
original = json.loads((C/'baseline/trace.json').read_bytes())
rebuilt = audit.make_trace()
audit.verify_trace(rebuilt)
assert enc(original) == enc(rebuilt)
assert ident(enc(original))['sha256'] == '4ce9d81072637ddbde8bb3b8fd0ed3ce6941543261c57162c916a9ee9e4b4e61'
old = {p:enc(v) for p,v in original['records'].items()} | {p:bytes.fromhex(v) for p,v in original['logs'].items()}
new = {p:enc(v) for p,v in rebuilt['records'].items()} | {p:bytes.fromhex(v) for p,v in rebuilt['logs'].items()}
assert old==new and len(old)==38
put('positive-equality.json', {'canonical_trace':ident(enc(original)), 'raw_trace':ident((C/'baseline/trace.json').read_bytes()),
    'all_bodies':{p:ident(v) for p,v in old.items()}, 'emitted_body_count':len(old), 'complete_canonical_trace_equal':True})
print(json.dumps({'exact_slots':len(values),'bounds':list(map(str,B)),'qualifies':False,'ledger':{k:v for k,v in ledger.items() if k!='terms'},'positive_bodies':len(old)}))
