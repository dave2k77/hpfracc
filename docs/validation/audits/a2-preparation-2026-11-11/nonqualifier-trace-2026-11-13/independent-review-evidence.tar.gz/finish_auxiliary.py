"""Reproduce archived lint layout and finish independent auxiliary checks.

Earlier reviewer-only lint-selection assumptions remain preserved, not repaired.
"""
import ast
from collections import Counter
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess
H=Path(__file__).resolve().parent
C=H/'copied'
OUT=H/'auxiliary'
ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
UV=['uv','--project',str(ROOT),'run','--frozen','--no-sync']
ENV={'PYTHONDONTWRITEBYTECODE':'1','JAX_PLATFORMS':'cpu','UV_PROJECT_ENVIRONMENT':str(ROOT/'.venv'),'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}
def ident(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(name,value):
    p=OUT/name
    p.parent.mkdir(parents=True,exist_ok=True)
    assert not p.exists()
    p.write_text(json.dumps(value,indent=2)+'\n')
def capture(name,command,cwd,expected=0):
    directory=OUT/name
    directory.mkdir()
    put(name+'/plan.json',{'argv':command,'cwd':str(cwd),'environment':ENV,'expected_child_exit':expected})
    child=subprocess.run(command,cwd=cwd,env=os.environ|ENV,capture_output=True,check=False)
    (directory/'stdout.raw').write_bytes(child.stdout)
    (directory/'stderr.raw').write_bytes(child.stderr)
    put(name+'/result.json',{'actual_child_exit':child.returncode,'stdout':ident(child.stdout),'stderr':ident(child.stderr)})
    assert child.returncode==expected,(name,child.returncode)
    return child

def key(row):
    p=Path(row['filename'])
    return (p.name,row['code'],row['message'],p.read_text().splitlines()[row['location']['row']-1])
results={}
for label,source in [('baseline','baseline'),('candidate','final')]:
    before=OUT/('lint-layout-'+label)/'before'
    before.mkdir(parents=True)
    files={'a2_trace.py':C/source/'a2_trace.py','test_a2_trace.py':C/'baseline/test_a2_trace.py',
           'test_a2_routing.py':C/'baseline/test_a2_routing.py','pyproject.toml':C/'final/pyproject.toml'}
    for name,p in files.items():
        (before/name).write_bytes(p.read_bytes())
    child=capture('lint-layout-run-'+label,UV+['ruff','check','--no-cache','--output-format','json','--config',str(before/'pyproject.toml')]+[str(before/n) for n in files if n.endswith('.py')],before,1)
    results[label]=json.loads(child.stdout)
b=Counter(map(key,results['baseline']))
f=Counter(map(key,results['candidate']))
assert len(results['baseline'])==109 and len(results['candidate'])==108 and not (f-b)
expected=json.loads((C/'lint-delta.json').read_bytes())
assert [list(v) for v in (b-f).elements()]==expected['removed_findings']
put('reviewer-harness-correction.json',{'preserved_failed_scripts':['scoped_auxiliary.py','continue_auxiliary.py'],
    'actual_terminal_exits':[1,1],
    'diagnosis':'Initial reviewer expectation incorrectly equated baseline and candidate counts. In addition, linting non-colocated paths with a different cwd added the same I001 for test_a2_routing to both trees. Identical archived layout reproduces baseline109/candidate108.',
    'candidate_changed':False,'lint_context_inspection':'lint-context-inspection.json'})
new_files={p:C/'final'/p for p in ['test_a2_nonqualifier.py','test_semantics.py','test_equality.py','test_derivation.py','verify_independent.py']}
new_files.update({p:C/p for p in ['prepare.py','make_jobs.py','prepare_controls.py','assert_run.py','prepare_final_runs.py']})
before=OUT/'lint-layout-new/before'
before.mkdir(parents=True)
for name,p in new_files.items():
    (before/name).write_bytes(p.read_bytes())
(before/'pyproject.toml').write_bytes((C/'final/pyproject.toml').read_bytes())
child=capture('new-helper-lint',UV+['ruff','check','--no-cache','--output-format','json','--config',str(before/'pyproject.toml')]+[str(before/n) for n in new_files],before)
assert json.loads(child.stdout)==[]
child=capture('inherited-capture-lint',UV+['ruff','check','--no-cache','--output-format','json','--config',str(before/'pyproject.toml'),str(C/'tools/run_snapshot.py')],before,1)
cap=json.loads(child.stdout)
assert len(cap)==1 and cap[0]['code']=='E501'
put('lint-summary.json',{'baseline':109,'candidate':108,'added':list((f-b).elements()),'removed':list((b-f).elements()),
    'new_helper_files':len(new_files),'new_helper_findings':0,'inherited_capture_findings':1,
    'status':'Archived checker/tests retain 108 inherited findings (baseline109); capture helper adds inherited E501. Repository lint separate.'})
old=(C/'baseline/a2_trace.py').read_text()
new=(C/'final/a2_trace.py').read_text()
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original-reviewed/a2_trace.py',tofile='final/a2_trace.py'))
assert diff==(C/'source.diff').read_text()
assert (C/'last-approved-source.diff').read_bytes()==b''
issues=[]
scanned=[C/'final/a2_trace.py']+list(new_files.values())
for p in scanned:
    for node in ast.walk(ast.parse(p.read_text())):
        if isinstance(node,ast.Call):
            name=ast.unparse(node.func)
            if name in ['eval','exec','os.system','pickle.load','pickle.loads'] or any(k.arg=='shell' and isinstance(k.value,ast.Constant) and k.value.value is True for k in node.keywords):
                issues.append({'file':str(p.relative_to(H)),'line':node.lineno,'call':name})
assert not issues
put('static-security.json',{'explicit_sources':[str(p.relative_to(H)) for p in scanned], 'dangerous_calls':issues,
    'source_diff_exact':True,'approved_source_diff_empty':True,'limitation':'Finite AST/manual source review; not operational/hostile-filesystem certification.'})
files=['a2_trace.py','authority.json','record-schemas.json','protocol.json','trace.json','verify_independent.py']
portability={}
for name,missing,mode in [('portable',None,'replay'),('missing-authority','authority.json','replay'),
                          ('missing-schemas','record-schemas.json','replay'),('missing-protocol','protocol.json','replay'),
                          ('missing-trace','trace.json','replay'),('read-guard',None,'guard-probe')]:
    before=OUT/('input-'+name)/'before'
    before.mkdir(parents=True)
    for file in files:
        if file!=missing:
            (before/file).write_bytes((C/'final'/file).read_bytes())
    snapshots={file:ident((before/file).read_bytes()) for file in files if file!=missing}
    child=capture(name,UV+['python',str(before/'verify_independent.py'),mode],before,0 if name=='portable' else 1)
    assert all(ident((before/file).read_bytes())==v for file,v in snapshots.items())
    if name=='read-guard':
        assert b'PermissionError: undeclared Python-level read' in child.stderr
    elif missing:
        assert b'FileNotFoundError' in child.stderr and missing.encode() in child.stderr
    portability[name]={'actual_child_exit':child.returncode,'input_files':snapshots,'missing':missing,
                       'source_hashes_unchanged':True,'python_read_audit_not_os_sandbox':True}
put('portability-summary.json',portability)
archived=json.loads((OUT/'archived-run-bindings.json').read_bytes())
print(json.dumps({'archived_runs_bound':len(archived['runs']),'archived_selected_tests':59,'checker_mutants_rejected':len(archived['mutant_deltas']),
    'baseline_ruff_findings':109,'candidate_inherited_ruff_findings':108,'added_checker_findings':0,
    'portable_replay_passed':True,'negative_input_controls':5,'reviewer_lint_context_corrections_preserved':True}))
