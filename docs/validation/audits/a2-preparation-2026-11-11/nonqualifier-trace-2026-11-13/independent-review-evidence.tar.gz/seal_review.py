"""Scan explicit task closures, recheck pins, and seal a bounded review.

No private identity matching, ambient scratch copying or external delivery.
"""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile

H=Path(__file__).resolve().parent
ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK=ROOT/'docs/validation/audits/a2-preparation-2026-11-11/nonqualifier-trace-2026-11-13'

def ident(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def put(name,value):
    p=H/name
    assert not p.exists()
    p.write_text(json.dumps(value,indent=2)+'\n')

def load(name):
    return json.loads((H/name).read_bytes())

# Build exact proof path allowlist from known inputs and generated outputs.
paths=set([
    'verify_inputs.py','prepare_review.py','run_selected.py','independent_checks.py','independent_controls.py',
    'scoped_auxiliary.py','continue_auxiliary.py','inspect_lint_selection.py','inspect_lint_context.py','finish_auxiliary.py',
    'seal_review.py','verify_seal.py','direct-terminal-receipts.json','input-verification.json','test-input-plan.json','focused-results.json',
    'pins/review-inputs.json','pins/review-resumption-inputs.json','pins/baseline-inputs.json','pins/author-index.json',
])
paths.update('copied/'+p for p in load('input-verification.json')['selected_copies'])
paths.update('copied/'+p for p in ['make_jobs.py','prepare_controls.py','assert_run.py'])
for group,inputs in load('test-input-plan.json').items():
    paths.update('runs/'+group+'/before/'+p for p in inputs)
    paths.update('runs/'+group+'/'+p for p in ['plan.json','stdout.raw','stderr.raw','raw.xml','result.json'])
negative=['unknown','missing-assessment','forged-qualifies','forged-assessment-status','forged-result-status','forged-selected-id','exit-unconfirmed','exit-nonzero',
          'index-inventory','preinventory','descriptor-shape','slot-shape','mode','alpha',
          'false-qualifying-bound','phase','publication']
negative += ['route-'+s+'-'+kind for s in ['X','0'] for kind in ['fresh','colliding']]
negative += ['false-exact-'+s for s in ['S-X-D','S-0-D_hat','S-0-analytic_input_gradient','S-0-B']]
negative += ['missing-charge-'+p.replace('/','-') for p in ['logs/stdout.bin','run-manifest.json','INITIAL_INDEX','failure-index.json']]
paths.update('runs/negative/artifacts/controls/'+n+'.json' for n in negative)
paths.update('runs/positive/artifacts/'+n for n in ['positive-trace.json','positive-equality.json'])
trace=load('copied/final/trace.json')
body_paths=set(trace['records'])|set(trace['logs'])
paths.update('independent/'+n for n in ['authority-and-exact.json','physical-and-causal.json','positive-equality.json'])
paths.update('independent/physical/'+n for n in body_paths)
paths.add('controls/results.json')
paths.update('controls/'+c['name']+'.json' for c in load('controls/results.json')['controls'])
paths.update('auxiliary/'+n for n in ['archived-run-bindings.json','lint-selection-inspection.json','lint-context-inspection.json',
    'reviewer-harness-correction.json','lint-summary.json','static-security.json','portability-summary.json'])
run_names=['baseline-lint','candidate-lint','lint-layout-run-baseline','lint-layout-run-candidate','new-helper-lint','inherited-capture-lint',
           'portable','missing-authority','missing-schemas','missing-protocol','missing-trace','read-guard']
for name in run_names:
    paths.update('auxiliary/'+name+'/'+f for f in ['plan.json','result.json','stdout.raw','stderr.raw'])
for label in ['baseline','candidate']:
    paths.update('auxiliary/lint-layout-'+label+'/before/'+p for p in ['a2_trace.py','test_a2_trace.py','test_a2_routing.py','pyproject.toml'])
paths.update('auxiliary/lint-layout-new/before/'+p for p in ['test_a2_nonqualifier.py','test_semantics.py','test_equality.py','test_derivation.py',
    'verify_independent.py','prepare.py','make_jobs.py','prepare_controls.py','assert_run.py','prepare_final_runs.py','pyproject.toml'])
for name,item in load('auxiliary/portability-summary.json').items():
    paths.update('auxiliary/input-'+name+'/before/'+p for p in item['input_files'])
paths.update('auxiliary/input-portable/artifacts/'+n for n in ['trace.json','independent-report.json'])
paths.update('auxiliary/input-portable/artifacts/bodies/'+n for n in body_paths)
assert all('runtime' not in Path(p).parts and '__pycache__' not in Path(p).parts for p in paths)
for name in paths:
    p=H/name
    assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(H),name

# Re-verify exact original and resumption manifests, protected files and Git.
review=load('pins/review-inputs.json')
resume=load('pins/review-resumption-inputs.json')
baseline=load('pins/baseline-inputs.json')
assert ident((WORK/'review-inputs.json').read_bytes())['sha256']=='e0f5c757763d00159a2ca85ffe4a890f05674341d6e264755aea1508cba69654'
assert ident((WORK/'review-resumption-inputs.json').read_bytes())['sha256']=='d1e2810f0a95d15b6d4e5e92654848d133d6431927f2f7ed2eb6a1dcc06f1b0f'
mutable={'docs/developer/phase-a-completion.md','docs/developer/bug-resolution-tracker.md'}
protected={p:v for p,v in baseline['files'].items() if p not in mutable}
for items in [review['files'],resume['additional_files'],protected]:
    for name,pin in items.items():
        assert ident((ROOT/name).read_bytes())==pin,name
head=subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,check=False)
stage=subprocess.run(['git','ls-files','--stage','-z'],cwd=ROOT,capture_output=True,check=False)
assert head.returncode==stage.returncode==0
assert head.stdout.decode().strip()==baseline['head']
assert ident(stage.stdout)['sha256']==baseline['git_stage_sha256']
assert ident((H/'copied/final/a2_trace.py').read_bytes())['sha256']=='8b7049e3e5ee25f7266f0228cb72efc0726d55eb98d2a1699e3bab3263ef1c2a'
put('final-pin-verification.json',{'candidate_files':len(review['files']),'resumption_files':len(resume['additional_files']),
    'protected_files':len(protected),'all_unchanged':True,'git_head':baseline['head'],'git_stage_sha256':baseline['git_stage_sha256'],
    'git_commands':[{'argv':['git','rev-parse','HEAD'],'actual_child_exit':head.returncode,'stdout':ident(head.stdout),'stderr':ident(head.stderr)},
                    {'argv':['git','ls-files','--stage','-z'],'actual_child_exit':stage.returncode,'stdout':ident(stage.stdout),'stderr':ident(stage.stderr)}]})
paths.add('final-pin-verification.json')

# Bounded credential/identifier patterns; emit paths/counts, never values.
patterns={
    'private-key':re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    'telegram-style-token':re.compile(rb'\b[0-9]{7,12}:[A-Za-z0-9_-]{30,}\b'),
    'provider-token':re.compile(rb'\b(?:ghp_|github_pat_|xox[baprs]-|sk-proj-)[A-Za-z0-9_-]{20,}'),
    'email-address':re.compile(rb'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'),
    'bearer-value':re.compile(rb'(?i)\bBearer\s+[A-Za-z0-9._~-]{20,}'),
    'credential-assignment':re.compile(rb'''(?i)\b(?:api_key|access_token|refresh_token|bot_token|password|passwd|secret)\b["']?\s*[:=]\s*["'][A-Za-z0-9_./+~=-]{16,}["']'''),
}
sensitive={'chat_id','user_id','sender_id','recipient_id','message_id','phone','phone_number','email','access_token','refresh_token','bot_token','api_key','password','passwd'}
positive=b'12345678'+b':'+b'A'*35
assert patterns['telegram-style-token'].search(positive)
assert patterns['email-address'].search(b'fixture'+b'@'+b'example.invalid')
assert not patterns['telegram-style-token'].search(b'STATIC HYPOTHETICAL STDOUT; NOT A WORKER RUN')
scans={}

def scan_set(label,items):
    findings=[]
    leaves=[]
    bytes_seen=0
    def scan(name,raw,depth=0):
        nonlocal bytes_seen
        assert depth<=6 and len(raw)<=128*1024*1024
        bytes_seen+=len(raw)
        assert bytes_seen<=2*1024*1024*1024
        leaves.append({'path':name,**ident(raw)})
        if raw.startswith(b'\x1f\x8b'):
            decoded=gzip.decompress(raw)
            try:
                tar=tarfile.open(fileobj=io.BytesIO(decoded),mode='r:')
            except tarfile.ReadError:
                scan(name+'::gzip-body',decoded,depth+1)
            else:
                with tar:
                    seen=set()
                    for member in tar.getmembers():
                        p=PurePosixPath(member.name)
                        assert member.isfile() and not p.is_absolute() and '..' not in p.parts
                        assert member.name not in seen and str(p)==member.name
                        seen.add(member.name)
                        body=tar.extractfile(member).read()
                        assert len(body)==member.size
                        scan(name+'::'+member.name,body,depth+1)
            return
        for kind,pattern in patterns.items():
            count=sum(1 for _ in pattern.finditer(raw))
            if count:
                findings.append({'path':name,'kind':kind,'count':count})
        try:
            value=json.loads(raw)
        except (ValueError,UnicodeError):
            return
        stack=[value]
        field_counts={}
        while stack:
            value=stack.pop()
            if type(value) is dict:
                for key,item in value.items():
                    if key.lower() in sensitive and item not in [None,'']:
                        field_counts[key]=field_counts.get(key,0)+1
                    stack.append(item)
            elif type(value) is list:
                stack.extend(value)
        for field,count in field_counts.items():
            findings.append({'path':name,'kind':'sensitive-json-field','field':field,'count':count})
    for name,raw in items:
        scan(name,raw)
    result={'root_count':len(items),'expanded_body_count':len(leaves),'total_bytes_inspected':bytes_seen,
            'findings':findings,'body_identities':leaves}
    scans[label]=result
    return findings

candidate_roots=review['files']|resume['additional_files']
findings=scan_set('candidate',[(p,(ROOT/p).read_bytes()) for p in sorted(candidate_roots)])
limits=[
    'Only REF-FAIL-f64-GL / nonqualify-REF-FAIL-f64-GL is the additional STATIC/HYPOTHETICAL case; REF-PASS-f64-GL is regression-only.',
    'No production worker, fitter, selector, JAX/AD or FIT-REAL execution occurred. Process/timing/ownership/counter fields and the all-ones packet digest are hypothetical; harness exits concern tests only.',
    'Exact arithmetic and physical byte replay establish this frozen finite trace and chosen write schedule, not whole-packet admission, operation budgets, scheduling/watchdog behavior, true peak RAM or numerical certification. The eight FIT-REAL admission blockers remain open.',
    'Archived checker/original tests retain 108 inherited Ruff findings (baseline 109), plus one inherited capture-helper E501. Ten new helpers/tests are clean; no checker findings were added. Repository lint is a separate gate.',
    'Two reviewer-only lint count/context assertion failures were preserved. Reproducing the archived colocated input/cwd layout resolved the counting discrepancy without changing candidate source, tests or criteria.',
    'Privacy review is limited to explicitly pinned candidate/proof closures, recursive regular archive streams and documented credential/identifier patterns; no private identity matching or universal publication/security clearance is claimed.',
    'Python read auditing is not an OS sandbox. Trusted owner-controlled local inputs were assumed; no hostile-filesystem service or operational validator is certified.',
    'Archived process records were bound to copied sources and raw XML/streams; this is not historical OS/process attestation. New local executions are identified separately. Defensive controls are posthoc/mutation evidence, not TDD.',
    'No repository source, packet, schema, cap, index or HEAD changes; no commit, push, freeze, phase closure or external delivery. Parent status-only follow-up remains separate.',
]
verdict={
    'review_completed':True,'passed':not findings,'security_concerns':[] if not findings else ['Credential/identifier pattern findings require disposition; see privacy-scan.json.'],
    'logic_errors':[],'limitations':limits,'evidence_directory':str(H),'verdict_path':str(H/'verdict.json'),'evidence_index_path':str(H/'evidence-index.json'),
    'scope':'Fresh independent bounded source/evidence/privacy review of one approved static no-qualifier extension; no candidate repairs.',
    'reviewed_identities':{'review_manifest_sha256':'e0f5c757763d00159a2ca85ffe4a890f05674341d6e264755aea1508cba69654',
        'resumption_manifest_sha256':'d1e2810f0a95d15b6d4e5e92654848d133d6431927f2f7ed2eb6a1dcc06f1b0f',
        'author_archive_sha256':'8bb7abf9283211a3bc86634a12ac5ec20ba4c27070c4592770cc95619110e45a',
        'author_index_sha256':'eb341ebe9f912a3e0684cf074489c36dd849b3dd0049af014fa6a9ccbe3c9f23',
        'checker_sha256':'8b7049e3e5ee25f7266f0228cb72efc0726d55eb98d2a1699e3bab3263ef1c2a',
        'baseline_checker_sha256':'4b28a7dfc4587dd6d6bfb63cdb5ea5362b0f5cf5ab3c1c9d31fe211465dfbd4e',
        'authority_sha256':'9f973fc6b4de16098cb1fe7001678a1eafdf845ad4b1f3da0109055d357b271d',
        'trace_sha256':'31439bb705bf64c99b96cdcb6ab80e367677c6f0aaee5b082156fdc820491a6e'},
    'verified':{'archive_index_entries':775,'regular_archive_members':776,'candidate_pins':45,'resumption_pins':6,'immutable_repository_files':234,
        'new_local_selected_pytest':{'nonqualifier':31,'unchanged_regressions':26,'full_positive_equality':1,'authority_derivation':1,'total':59,'actual_child_exits':[0,0,0]},
        'independent_posthoc_controls_rejected':33,'archived_checker_mutants_rejected':5,'archived_run_bindings':36,
        'portable_replay_actual_child_exit':0,'missing_input_controls_rejected':4,'read_guard_control_rejected':1,
        'exact_slots':13,'epsilon':'1/8','tau':'3/16','bounds':['0','1/4','1/4'],'qualifies':False,
        'selected_status':'no_supplied_candidate_meets_bound','selected_id':None,
        'ledger':{k:v for k,v in load('independent/physical-and-causal.json')['ledger'].items() if k!='terms'},
        'json_records':25,'static_logs':2,'max_parse_nodes':720,'max_parse_depth':9,
        'positive_complete_canonical_trace_equal':True,'positive_emitted_bodies_equal':38},
    'source_review':'Minimal authority/case/inventory/qualification/check-order delta inspected. Frozen input authentication, route identities, canonical record types, exact payloads, completion, lifecycle and byte-accounting guards exercised. No blocking source/evidence counterexample found.',
    'boundary_note':'Initial recovery file-search returned unrelated scratch path names; no contents at those unrelated paths were read or copied. No private archives, credentials, messaging receipts or identity sources were accessed.',
    'prior_approval_pause':'Historical blocked attempts remain unlaunched. This fresh named-script verification/copy ran with actual exit0; no safety configuration changes or new gate bypass occurred.',
}
# Scan the final verdict bytes before writing, together with the explicit proof.
verdict_raw=(json.dumps(verdict,indent=2)+'\n').encode()
proof_findings=scan_set('proof',[(p,(H/p).read_bytes()) for p in sorted(paths)]+[('verdict.json',verdict_raw)])
if proof_findings:
    verdict['passed']=False
    verdict['security_concerns'].append('Reviewer proof credential/identifier pattern findings require disposition; see privacy-scan.json.')
put('verdict.json',verdict)
paths.add('verdict.json')
privacy={'scope':'Explicit candidate/proof allowlists; recursive regular tar streams; no arbitrary extraction or private identity matching.',
         'patterns':list(patterns),'sensitive_json_field_names':sorted(sensitive),
         'synthetic_positive_pattern_controls_passed':True,'scans':dict(scans),
         'unresolved_findings':len(findings)+len(proof_findings),
         'limitations':'Pattern absence is not universal privacy clearance; archive headers are validated structurally, body bytes are scanned, unknown private identities are not matched.'}
# Generated scan output contains identities/path metadata, never matched values.
report_raw=(json.dumps(privacy,indent=2)+'\n').encode()
selfscan=scan_set('generated-scan-report',[('privacy-scan.json',report_raw)])
assert not selfscan,'Generated scan report unexpectedly contains sensitive-pattern data'
put('privacy-scan.json',privacy)
paths.add('privacy-scan.json')
index={'scope':'Exact generated reviewer proof and copied task inputs; no ambient scratch capture.',
       'excluded':['self evidence-index.json','all runtime/cache directories','unrelated scratch content'],
       'file_count':len(paths),'files':{p:ident((H/p).read_bytes()) for p in sorted(paths)}}
put('evidence-index.json',index)
print(json.dumps({'review_completed':verdict['review_completed'],'passed':verdict['passed'],
    'proof_files':len(paths),'candidate_roots_scanned':len(candidate_roots),
    'candidate_expanded_bodies':scans['candidate']['expanded_body_count'],
    'unresolved_privacy_findings':privacy['unresolved_findings'],
    'evidence_directory':str(H),'verdict_path':str(H/'verdict.json'),'evidence_index_path':str(H/'evidence-index.json')}))
