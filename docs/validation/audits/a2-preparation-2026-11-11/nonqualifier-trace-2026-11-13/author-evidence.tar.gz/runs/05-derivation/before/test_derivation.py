"""Mechanical authority derivation and cross-check against frozen source bytes."""

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def test_nonqualifier_authority_is_mechanical_frozen_slice():
    authority = json.loads((HERE / "authority.json").read_bytes())
    fixture = json.loads((HERE / "fixtures.json").read_bytes())
    schemas = json.loads((HERE / "schema-control-fixtures.json").read_bytes())
    positive = json.loads((HERE / "positive-authority.json").read_bytes())
    expected = {
        "bundle": next(x for x in schemas["bundles"]
                       if x["witness_id"] == "nonqualify-REF-FAIL-f64-GL"),
        "case": next(x for x in fixture["cases"] if x["case_id"] == "REF-FAIL-f64-GL"),
        "working_scalars": fixture["working_scalars"],
        "label": schemas["label"], "scope": positive["scope"],
        "packet_digest": schemas["hypothetical_external_packet_sha256"],
    }
    assert authority == expected
    assert len(expected["case"]["required_evidence_slots"]) == 13
    assert len(expected["bundle"]["artifacts"]) == 25
    actual_packet_hash = hashlib.sha256((HERE / "packet-manifest.json").read_bytes()).hexdigest()
    assert authority["packet_digest"] == "1" * 64
    assert authority["packet_digest"] != actual_packet_hash
    assert actual_packet_hash == "2d572491100e76897bc4c298f1a75387110e6942a027da9eeae14b06aadec481"
