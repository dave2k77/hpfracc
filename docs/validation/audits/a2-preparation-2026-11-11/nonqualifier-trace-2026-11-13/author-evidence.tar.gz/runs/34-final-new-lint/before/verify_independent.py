"""Finite static exact arithmetic and physical byte replay, not a worker.

This separate mechanism does not use checker arithmetic/ledger helpers. Python
read auditing is a limited portability assertion, NOT an OS/security sandbox.
"""

import hashlib
import importlib.util
import json
import math
import os
import struct
import sys
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent


def encoded(value):
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False
    ).encode("ascii")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_checker():
    spec = importlib.util.spec_from_file_location("a2_copied", HERE / "a2_trace.py")
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    return checker


def rat(value):
    return Fraction(int(value["num"], 16), int(value["den"], 16))


def ieee(raw):
    data = bytes.fromhex(raw["raw_hex"])
    assert sha(data) == raw["sha256"]
    assert raw["dtype"] == "float64" and raw["byte_order"] == "little"
    assert raw["nbytes"] == len(data) == 8 * math.prod(raw["shape"])
    return [Fraction(v) for (v,) in struct.iter_unpack("<d", data)]


def exact(trace, authority):
    """Derive GL coefficients recursively from raw alpha, then all 13 slots."""
    records = trace["records"]
    request = records["input-bundle.json"]["request"]
    scalar = authority["working_scalars"]["float64"]
    (alpha,) = ieee(scalar["alpha"])
    (dt,) = ieee(scalar["dt"])
    assert alpha == rat(request["alpha"]) == Fraction(1, 2)
    assert dt == rat(request["dt"]) == Fraction(1, 4)
    sqrt_dt = Fraction(math.isqrt(dt.numerator), math.isqrt(dt.denominator))
    assert sqrt_dt * sqrt_dt == dt
    scale = 1 / sqrt_dt
    x = ieee(request["input"])
    assert len(x) == 3 and len(request["candidates"]) == 1
    n = len(x)
    w = [Fraction(1)]
    for k in range(1, n):
        w.append(-w[-1] * (alpha - k + 1) / k)
    g = [sum(w[: k + 1]) for k in range(n)]
    v = [a - b for a, b in zip(x, [Fraction(0)] + x[:-1], strict=True)]
    direct = [scale * sum(w[i - j] * x[j] for j in range(i + 1)) for i in range(n)]
    (candidate,) = request["candidates"]
    coefficients = ieee(candidate["coefficients"])
    rhos = ieee(candidate["rhos"])
    assert (
        len(coefficients) == len(rhos) == candidate["configuration"]["pole_count"] == 1
    )
    fitted = [Fraction(1)] + [
        sum(c * r ** (k - 1) for c, r in zip(coefficients, rhos, strict=True))
        for k in range(1, n)
    ]
    residual = [fitted[k] - g[k] for k in range(n)]
    epsilon = max(map(abs, residual))
    fitted_weights = [fitted[0]] + [fitted[k] - fitted[k - 1] for k in range(1, n)]
    matrix = [
        [scale * fitted_weights[i - j] if i >= j else Fraction(0) for j in range(n)]
        for i in range(n)
    ]
    output = [sum(a * b for a, b in zip(row, x, strict=True)) for row in matrix]
    error = [abs(output[i] - direct[i]) for i in range(n)]
    bound = [scale * epsilon * sum(map(abs, v[:i])) for i in range(n)]
    gradient = [
        Fraction(2, n) * sum(matrix[i][j] * output[i] for i in range(n))
        for j in range(n)
    ]
    values = {
        "S-X-w": w,
        "S-X-g": g,
        "S-X-v": v,
        "S-X-D": direct,
        "S-0-g_hat": fitted,
        "S-0-residual": residual,
        "S-0-signed_fitted_weights": fitted_weights,
        "S-0-L_hat": [v for row in matrix for v in row],
        "S-0-D_hat": output,
        "S-0-error": error,
        "S-0-B": bound,
        "S-0-epsilon": [epsilon],
        "S-0-analytic_input_gradient": gradient,
    }
    assert set(values) == {
        x["slot_id"] for x in authority["case"]["required_evidence_slots"]
    }
    for sid, expected in values.items():
        slot = records["arrays/" + sid + ".json"]["exact_array"]
        assert [rat(v) for v in slot["values"]] == expected, sid
        shape = (
            []
            if sid.endswith("epsilon")
            else ([n, n] if sid.endswith("L_hat") else [n])
        )
        assert slot["shape"] == shape
    tau = rat(request["tau"])
    assert tau == Fraction(3, 16) and epsilon == Fraction(1, 8)
    assert bound == [Fraction(0), Fraction(1, 4), Fraction(1, 4)]
    assert all(a <= b for a, b in zip(error, bound, strict=True))
    assert not all(b <= tau for b in bound)
    return {
        "slots": {k: list(map(str, v)) for k, v in values.items()},
        "slot_count": len(values),
        "tau": str(tau),
        "epsilon": str(epsilon),
        "bound": list(map(str, bound)),
        "qualifies": False,
        "method": "Fraction from decoded IEEE values; recursive GL coefficients",
    }


def parse_metrics(value):
    """Count nodes (including object keys) iteratively, depth independently."""
    stack = [(value, 1)]
    nodes = depth = 0
    while stack:
        item, level = stack.pop()
        nodes += 1
        depth = max(depth, level)
        if isinstance(item, dict):
            nodes += len(item)
            depth = max(depth, level + 1)
            stack.extend((v, level + 1) for v in item.values())
        elif isinstance(item, list):
            stack.extend((v, level + 1) for v in item)
    return {"nodes": nodes, "depth": depth}


def physical(trace, root, caps):
    """Write bodies to a fresh map-backed directory, read back each state."""
    root.mkdir(parents=True, exist_ok=False)
    bodies = {p: encoded(v) for p, v in trace["records"].items()}
    bodies.update({p: bytes.fromhex(v) for p, v in trace["logs"].items()})
    initial = encoded(trace["initial_index"])
    all_bodies = bodies | {"INITIAL_INDEX": initial}
    live = {}
    charges = {}
    states = []
    snapshots = {}
    cumulative = peak = 0
    for event in trace["events"]:
        if event["op"] == "write":
            path, name = event["path"], event["body"]
            if name in ("INITIAL_INDEX", "failure-index.json", "result.json"):
                snapshots[name] = {
                    "live_bytes": sum(map(len, live.values())),
                    "cumulative_written_bytes": cumulative,
                }
            raw = all_bodies[name]
            assert path not in live and name not in charges
            dest = root / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open("xb") as stream:
                assert stream.write(raw) == len(raw)
            live[path] = dest.read_bytes()
            assert live[path] == raw
            charges[name] = len(live[path])
            cumulative += charges[name]
        else:
            assert event == {
                "op": "replace",
                "source": "tmp/index-final.part",
                "target": "failure-index.json",
            }
            assert live["failure-index.json"] == initial
            assert live["tmp/index-final.part"] == bodies["failure-index.json"]
            os.replace(root / event["source"], root / event["target"])
            live[event["target"]] = live.pop(event["source"])
        for name, expected in live.items():
            assert (root / name).read_bytes() == expected
        live_bytes = sum((root / name).stat().st_size for name in live)
        peak = max(peak, live_bytes)
        states.append(
            {
                "event": event,
                "live_bytes": live_bytes,
                "cumulative_written_bytes": cumulative,
            }
        )
    assert live == bodies
    final = sum(len(v) for v in live.values())
    transaction_paths = [
        "INITIAL_INDEX",
        "failure-index.json",
        "records/process.json",
        "records/export.json",
        "records/output-control.json",
    ]
    transaction = sum(len(all_bodies[p]) for p in transaction_paths)
    ledger = {
        "terms": charges,
        "final_live_bytes": final,
        "peak_live_bytes": peak,
        "cumulative_written_bytes": cumulative,
        "index_transaction_bytes": transaction,
        "temporary_bytes_charged": len(bodies["failure-index.json"]),
        "old_index_bytes_charged": len(initial),
    }
    assert ledger == trace["ledger"]  # every charge, not merely aggregate totals
    assert set(charges) == set(all_bodies)
    assert (
        trace["records"]["result.json"]["evidence_bytes"]
        == snapshots["result.json"]["live_bytes"]
    )
    for name, record in [
        ("INITIAL_INDEX", trace["initial_index"]),
        ("failure-index.json", trace["records"]["failure-index.json"]),
    ]:
        assert record["bytes_accounting"] == snapshots[name] | {
            "reserved_final_transaction_bytes": caps["failure_index_bytes"],
        }
    assert max(peak, cumulative) <= caps["evidence_bytes"]
    assert transaction <= caps["failure_index_bytes"]
    metrics = {p: parse_metrics(v) for p, v in trace["records"].items()}
    metrics["INITIAL_INDEX"] = parse_metrics(trace["initial_index"])
    assert all(
        v["nodes"] <= caps["json_nodes"] and v["depth"] <= caps["json_depth"]
        for v in metrics.values()
    )
    return {
        "ledger": ledger,
        "states": states,
        "prewrite_snapshots": snapshots,
        "per_record_parse_metrics": metrics,
        "final_files": {
            p: {"bytes": len(v), "sha256": sha(v)} for p, v in live.items()
        },
        "initial_index": {"bytes": len(initial), "sha256": sha(initial)},
        "physical_final_map_equal": True,
        "every_charge_equal": True,
    }


def read_guard():
    """Reject undeclared Python-level source reads, allowing local output reads."""
    declared = {
        HERE / p
        for p in [
            "a2_trace.py",
            "authority.json",
            "record-schemas.json",
            "protocol.json",
            "trace.json",
        ]
    }
    allowed_runtime = [Path(sys.base_prefix).resolve(), Path(sys.prefix).resolve()]
    output = HERE.parent / "artifacts"
    reads = set()

    def hook(event, args):
        if event != "open" or not isinstance(args[0], (str, bytes, os.PathLike)):
            return
        mode = args[1]
        if isinstance(mode, str) and any(x in mode for x in "wax+"):
            return
        path = Path(os.fsdecode(args[0])).resolve()
        allowed = (
            path in declared
            or path.is_relative_to(output)
            or any(path.is_relative_to(p) for p in allowed_runtime)
        )
        if not allowed:
            raise PermissionError("undeclared Python-level read")
        reads.add(str(path))

    sys.addaudithook(hook)
    return reads


def main():
    mode = sys.argv[1]
    reads = read_guard()
    if mode == "guard-probe":
        (HERE / "not-declared.txt").read_bytes()
        raise AssertionError("read guard did not reject")
    checker = load_checker()
    trace = (
        json.loads((HERE / "trace.json").read_bytes())
        if mode == "replay"
        else checker.make_trace()
    )
    checker_report = checker.verify_trace(trace)
    authority = json.loads((HERE / "authority.json").read_bytes())
    caps = json.loads((HERE / "protocol.json").read_bytes())["caps"]
    output = HERE.parent / "artifacts"
    output.mkdir(exist_ok=True)
    report = {
        "scope": "STATIC/HYPOTHETICAL finite read-only arithmetic; physical local replay",
        "exact": exact(trace, authority),
        "checker": checker_report,
    }
    report["physical"] = physical(trace, output / "bodies", caps)
    report["read_audit"] = {"opened_paths": sorted(reads), "os_sandbox": False}
    (output / "trace.json").write_bytes(encoded(trace))
    (output / "independent-report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        json.dumps(
            {
                "exact_slots": report["exact"]["slot_count"],
                "ledger": report["physical"]["ledger"],
                "mode": mode,
            }
        )
    )


if __name__ == "__main__":
    main()
