"""Pin style-only edits and prepare final exact-byte verification selections."""

import ast
import difflib
import json
from collections import Counter
from pathlib import Path

from make_jobs import job

HERE = Path(__file__).resolve().parent


def main():
    changed = ["test_semantics.py", "test_derivation.py", "verify_independent.py"]
    equivalent = {}
    for name in changed:
        old = HERE / "runs/19-new-lint/before" / name
        new = HERE / "final" / name
        equivalent[name] = ast.dump(ast.parse(old.read_text())) == ast.dump(
            ast.parse(new.read_text())
        )
        assert equivalent[name]
    (HERE / "style-only-equivalence.json").write_text(
        json.dumps(equivalent, indent=2) + "\n"
    )
    results = {}
    for name in ["17-baseline-lint", "18-candidate-lint", "19-new-lint"]:
        result = json.loads((HERE / "runs" / name / "result.json").read_bytes())
        assert result["actual_exit"] == 1 and result["source_hashes_unchanged"]
        data = json.loads((HERE / "runs" / name / "stdout.bin").read_bytes())
        results[name] = data

    def identity(item):
        path = Path(item["filename"])
        line = path.read_text().splitlines()[item["location"]["row"] - 1]
        return (path.name, item["code"], item["message"], line)

    baseline = Counter(map(identity, results["17-baseline-lint"]))
    current = Counter(map(identity, results["18-candidate-lint"]))
    added = list((current - baseline).elements())
    removed = list((baseline - current).elements())
    assert not added
    report = {
        "baseline_findings": len(results["17-baseline-lint"]),
        "candidate_findings": len(results["18-candidate-lint"]),
        "added_findings": added,
        "removed_findings": removed,
        "preserved_findings": list((current & baseline).elements()),
        "new_helper_preformat_findings": len(results["19-new-lint"]),
        "comparison": "filename/code/message/exact source line; not shifted line numbers",
        "checker_or_original_tests_reformatted": False,
        "repository_production_lint": "separate gate, not this archived proof-source lint",
    }
    (HERE / "lint-delta.json").write_text(json.dumps(report, indent=2) + "\n")
    remap = {
        "20-final-semantic": "01-semantic",
        "21-final-derivation": "05-derivation",
        "22-final-physical": "03-exact-physical",
        "23-final-portable": "06-portable",
        "24-final-read-guard": "07-read-guard",
        "25-final-missing-authority": "08-missing-authority",
        "26-final-missing-schemas": "09-missing-record-schemas",
        "27-final-missing-protocol": "10-missing-protocol",
        "28-final-missing-trace": "11-missing-trace",
        "29-final-mutant-completion": "12-mutant-completion",
        "30-final-mutant-binding": "13-mutant-binding",
        "31-final-mutant-exact": "14-mutant-exact",
        "32-final-mutant-lifecycle": "15-mutant-lifecycle",
        "33-final-mutant-ledger": "16-mutant-ledger",
    }
    expected_path = HERE / "expected-controls.json"
    expected = json.loads(expected_path.read_bytes())
    for name, original in remap.items():
        value = json.loads((HERE / "jobs" / (original + ".json")).read_bytes())
        value["label"] = name
        (HERE / "jobs" / (name + ".json")).write_text(
            json.dumps(value, indent=2) + "\n"
        )
        expected[name] = expected.get(original, {"exit": 0})
    expected_path.write_text(json.dumps(expected, indent=2) + "\n")
    new_files = {
        p: "final/" + p
        for p in [
            "test_a2_nonqualifier.py",
            "test_semantics.py",
            "test_equality.py",
            "test_derivation.py",
            "verify_independent.py",
        ]
    }
    new_files.update(
        {
            p: p
            for p in [
                "prepare.py",
                "make_jobs.py",
                "prepare_controls.py",
                "assert_run.py",
                "prepare_final_runs.py",
            ]
        }
    )
    new_files["run_snapshot.py"] = "tools/run_snapshot.py"
    job(
        "34-final-new-lint",
        new_files,
        [
            "ruff",
            "check",
            "--no-cache",
            "--output-format",
            "json",
            "--config",
            "{before}/pyproject.toml",
        ]
        + ["{before}/" + p for p in new_files],
    )
    original = (HERE / "baseline/a2_trace.py").read_text()
    current_source = (HERE / "final/a2_trace.py").read_text()
    assert (HERE / "source.diff").read_text() == "".join(
        difflib.unified_diff(
            original.splitlines(True),
            current_source.splitlines(True),
            fromfile="original-reviewed/a2_trace.py",
            tofile="final/a2_trace.py",
        )
    )
    print(
        json.dumps(
            {
                "lint_delta": {
                    k: report[k]
                    for k in [
                        "baseline_findings",
                        "candidate_findings",
                        "added_findings",
                        "removed_findings",
                    ]
                },
                "style_ast_equivalent": equivalent,
            }
        )
    )


if __name__ == "__main__":
    main()
