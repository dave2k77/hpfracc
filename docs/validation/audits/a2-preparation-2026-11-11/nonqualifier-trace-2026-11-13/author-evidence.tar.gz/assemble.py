"""Explicit owned-proof inventory, bounded privacy scan and result assembly.

No ambient directory capture. All test runtimes and self-index are excluded.
This is author self-verification, not independent review or publication approval.
"""

import ast
import gzip
import io
import json
import re
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath

from prepare import metadata, protect, save

HERE = Path(__file__).resolve().parent
RUNS = [
    "01-semantic",
    "02-regression",
    "03-exact-physical",
    "04-equality",
    "05-derivation",
    "06-portable",
    "07-read-guard",
    "08-missing-authority",
    "09-missing-record-schemas",
    "10-missing-protocol",
    "11-missing-trace",
    "12-mutant-completion",
    "13-mutant-binding",
    "14-mutant-exact",
    "15-mutant-lifecycle",
    "16-mutant-ledger",
    "17-baseline-lint",
    "18-candidate-lint",
    "19-new-lint",
    "20-final-semantic",
    "21-final-derivation",
    "22-final-physical",
    "23-final-portable",
    "24-final-read-guard",
    "25-final-missing-authority",
    "26-final-missing-schemas",
    "27-final-missing-protocol",
    "28-final-missing-trace",
    "29-final-mutant-completion",
    "30-final-mutant-binding",
    "31-final-mutant-exact",
    "32-final-mutant-lifecycle",
    "33-final-mutant-ledger",
    "34-final-new-lint",
    "35-final-new-lint",
    "36-assembly-lint",
]
CONTROLS = [
    "unknown",
    "missing-assessment",
    "forged-qualifies",
    "forged-assessment-status",
    "forged-result-status",
    "forged-selected-id",
    "exit-unconfirmed",
    "exit-nonzero",
    "index-inventory",
    "preinventory",
    "descriptor-shape",
    "slot-shape",
    "mode",
    "alpha",
    "route-X-fresh",
    "route-0-fresh",
    "route-X-colliding",
    "route-0-colliding",
    "false-exact-S-X-D",
    "false-exact-S-0-D_hat",
    "false-exact-S-0-analytic_input_gradient",
    "false-exact-S-0-B",
    "false-qualifying-bound",
    "phase",
    "publication",
    "missing-charge-logs-stdout.bin",
    "missing-charge-run-manifest.json",
    "missing-charge-INITIAL_INDEX",
    "missing-charge-failure-index.json",
]
SENSITIVE_KEYS = {
    "chat_id",
    "message_id",
    "user_id",
    "recipient_id",
    "delivery_receipt",
    "password",
    "api_key",
    "access_token",
    "refresh_token",
    "bot_token",
}
CREDENTIAL_PATTERNS = [
    rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
    rb"\bAKIA[0-9A-Z]{16}\b",
    rb"\bgh[pousr]_[A-Za-z0-9]{30,}\b",
    rb"\b[0-9]{8,}:[A-Za-z0-9_-]{30,}\b",
]


def scan_body(path, raw, findings, counts):
    counts["bodies"] += 1
    for pattern in CREDENTIAL_PATTERNS:
        if re.search(pattern, raw):
            findings.append({"path": path, "kind": "credential-pattern"})
    if raw.startswith(b"\x1f\x8b"):
        scan_body(path + "::gzip", gzip.decompress(raw), findings, counts)
        return
    if len(raw) > 262 and raw[257:262] == b"ustar":
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            names = set()
            for member in archive:
                assert member.isfile() and member.name not in names
                assert not PurePosixPath(member.name).is_absolute()
                assert ".." not in PurePosixPath(member.name).parts
                names.add(member.name)
                scan_body(
                    path + "::" + member.name,
                    archive.extractfile(member).read(),
                    findings,
                    counts,
                )
        return
    try:
        value = json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        return
    counts["json_bodies"] += 1
    stack = [("$", value)]
    while stack:
        location, item = stack.pop()
        if isinstance(item, dict):
            for key, child in item.items():
                if key.lower() in SENSITIVE_KEYS:
                    findings.append(
                        {
                            "path": path,
                            "field": location + "." + key,
                            "kind": "sensitive-field",
                        }
                    )
                if key in ("raw_hex", "raw_request_utf8_hex") and isinstance(
                    child, str
                ):
                    scan_body(
                        path + "::" + location + "." + key,
                        bytes.fromhex(child),
                        findings,
                        counts,
                    )
                else:
                    stack.append((location + "." + key, child))
        elif isinstance(item, list):
            stack.extend((location + "[]", x) for x in item)


def validate_run(name, inventory, outcomes):
    root = HERE / "runs" / name
    plan = json.loads((root / "plan.json").read_bytes())
    result = json.loads((root / "result.json").read_bytes())
    expected = json.loads((HERE / "expected-controls.json").read_bytes()).get(name)
    exit_code = (
        expected["exit"]
        if expected
        else (
            1
            if name
            in [
                "17-baseline-lint",
                "18-candidate-lint",
                "19-new-lint",
                "34-final-new-lint",
            ]
            else 0
        )
    )
    assert result["actual_exit"] == exit_code and result["source_hashes_unchanged"]
    assert plan["inputs"] == result["inputs_after"]
    for path, pin in plan["inputs"].items():
        assert metadata(root / "before" / path) == pin
        inventory.add(str((root / "before" / path).relative_to(HERE)))
    for path in ["plan.json", "result.json", "stdout.bin", "stderr.bin"]:
        inventory.add(str((root / path).relative_to(HERE)))
    for stream in ["stdout", "stderr"]:
        assert metadata(root / (stream + ".bin")) == result[stream]
        if expected and stream + "_contains" in expected:
            assert (
                expected[stream + "_contains"] in (root / (stream + ".bin")).read_text()
            )
    if "junit" in result:
        assert metadata(root / "raw.xml") == result["junit"]["file"]
        cases = ET.parse(root / "raw.xml").getroot().findall(".//testcase")
        actual = {
            "collected": len(cases),
            "failures": sum(x.find("failure") is not None for x in cases),
            "errors": sum(x.find("error") is not None for x in cases),
            "skipped": sum(x.find("skipped") is not None for x in cases),
        }
        for key, value in actual.items():
            assert result["junit"][key] == value
        assert [x.attrib for x in cases] == result["junit"]["identities"]
        if expected and "junit" in expected:
            assert all(actual[k] == v for k, v in expected["junit"].items())
        else:
            assert actual["failures"] == actual["errors"] == actual["skipped"] == 0
        inventory.add(str((root / "raw.xml").relative_to(HERE)))
    inventory.add("jobs/" + name + ".json")
    outcomes[name] = {
        "actual_exit": exit_code,
        "input_count": len(plan["inputs"]),
        "hashes_unchanged": True,
        "junit": result.get("junit"),
    }


def security_scan(paths):
    findings = []
    for name in paths:
        if not name.endswith(".py"):
            continue
        tree = ast.parse((HERE / name).read_bytes())
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = ast.unparse(node.func)
            if func in ["eval", "exec", "os.system", "pickle.load", "pickle.loads"]:
                findings.append({"path": name, "line": node.lineno, "call": func})
            if any(
                k.arg == "shell"
                and isinstance(k.value, ast.Constant)
                and k.value.value is True
                for k in node.keywords
            ):
                findings.append(
                    {"path": name, "line": node.lineno, "call": "shell=True"}
                )
    return findings


def main():
    inventory = set(json.loads((HERE / "copied-inputs.json").read_bytes()))
    for name, pin in json.loads((HERE / "copied-inputs.json").read_bytes()).items():
        assert metadata(HERE / name) == pin
    inventory.update(
        [
            "prepare.py",
            "make_jobs.py",
            "prepare_controls.py",
            "assert_run.py",
            "prepare_final_runs.py",
            "assemble.py",
            "tools/run_snapshot.py",
            "copied-inputs.json",
            "protection-before.json",
            "source.diff",
            "last-approved-source.diff",
            "expected-controls.json",
            "lint-delta.json",
            "style-only-equivalence.json",
            "final/test_semantics.py",
            "final/test_equality.py",
            "final/test_derivation.py",
            "final/verify_independent.py",
            "final/authority.json",
            "final/protocol.json",
            "final/record-schemas.json",
            "final/pyproject.toml",
            "final/trace.json",
        ]
    )
    for kind in ["completion", "binding", "exact", "lifecycle", "ledger"]:
        inventory.add("mutants/" + kind + "/a2_trace.py")
    outcomes = {}
    for name in RUNS:
        validate_run(name, inventory, outcomes)
    for name in ["01-semantic", "20-final-semantic"]:
        for control in CONTROLS:
            inventory.add("runs/" + name + "/artifacts/controls/" + control + ".json")
    control_by_kind = {
        "completion": "unknown",
        "binding": "route-0-fresh",
        "exact": "false-exact-S-0-B",
        "lifecycle": "publication",
        "ledger": "missing-charge-INITIAL_INDEX",
    }
    for name in RUNS:
        if "-mutant-" in name:
            control = control_by_kind[name.split("-mutant-")[1]]
            inventory.add("runs/" + name + "/artifacts/controls/" + control + ".json")
    for name in [
        "03-exact-physical",
        "06-portable",
        "22-final-physical",
        "23-final-portable",
    ]:
        base = "runs/" + name + "/artifacts/"
        inventory.update([base + "trace.json", base + "independent-report.json"])
        report = json.loads((HERE / (base + "independent-report.json")).read_bytes())
        for path, pin in report["physical"]["final_files"].items():
            body = base + "bodies/" + path
            assert metadata(HERE / body) == pin
            inventory.add(body)
        assert (HERE / (base + "trace.json")).read_bytes() == (
            HERE / "final/trace.json"
        ).read_bytes()
    inventory.update(
        [
            "runs/04-equality/artifacts/positive-trace.json",
            "runs/04-equality/artifacts/positive-equality.json",
        ]
    )
    save(HERE / "protection-after.json", protect())
    inventory.add("protection-after.json")
    security = security_scan(sorted(inventory))
    assert not security
    save(
        HERE / "security-scan.json",
        {
            "findings": security,
            "method": "Python AST dangerous calls + shell=True",
            "scope": "explicit indexed Python source; static self-inspection only",
            "not_security_certification": True,
        },
    )
    inventory.add("security-scan.json")
    for name in inventory:
        path = HERE / name
        assert path.is_file() and not path.is_symlink()
        assert "runtime" not in path.parts and "__pycache__" not in path.parts
    counts = {"bodies": 0, "json_bodies": 0}
    positive = []
    scan_body(
        "synthetic-detector-control",
        json.dumps(
            {
                "chat_id": "synthetic-only",
                "access_token": "synthetic-only",
            }
        ).encode(),
        positive,
        counts,
    )
    assert len(positive) == 2
    recursive = io.BytesIO()
    with tarfile.open(fileobj=recursive, mode="w") as archive:
        body = json.dumps({"chat_id": "synthetic-only"}).encode()
        member = tarfile.TarInfo("control.json")
        member.size = len(body)
        archive.addfile(member, io.BytesIO(body))
    scan_body(
        "synthetic-recursive-control",
        gzip.compress(recursive.getvalue()),
        positive,
        counts,
    )
    scan_body("synthetic-pattern-control", b"AKIA" + b"A" * 16, positive, counts)
    assert len(positive) == 4
    findings = []
    counts = {"bodies": 0, "json_bodies": 0}
    scan_pins = {p: metadata(HERE / p) for p in sorted(inventory)}
    for name in scan_pins:
        scan_body(name, (HERE / name).read_bytes(), findings, counts)
    assert not findings, findings
    save(
        HERE / "privacy-scan.json",
        {
            "scope": "Explicit owned inventory; recursive gzip/tar/JSON/raw-hex bodies",
            "scan_inputs": scan_pins,
            "counts": counts,
            "findings": findings,
            "synthetic_positive_detector_controls": len(positive),
            "limitations": [
                "Pattern/field inspection, not universal privacy assurance",
                "No private archives, credentials or messaging receipts read",
                "No identity-matching against private data; no publication approval",
            ],
        },
    )
    inventory.add("privacy-scan.json")
    proof = json.loads(
        (HERE / "runs/22-final-physical/artifacts/independent-report.json").read_bytes()
    )
    equality = json.loads(
        (HERE / "runs/04-equality/artifacts/positive-equality.json").read_bytes()
    )
    final_tests = {
        n: outcomes[n]["junit"]["collected"]
        for n in [
            "20-final-semantic",
            "02-regression",
            "04-equality",
            "21-final-derivation",
        ]
    }
    assert final_tests == {
        "20-final-semantic": 31,
        "02-regression": 26,
        "04-equality": 1,
        "21-final-derivation": 1,
    }
    metrics = proof["physical"]["per_record_parse_metrics"]
    result = {
        "completed": True,
        "scope": "Author self-verification only; ONE additional static case",
        "authoritative_source": "final/a2_trace.py",
        "source": metadata(HERE / "final/a2_trace.py"),
        "source_changed_after_approved_resumption": False,
        "source_diff": "source.diff",
        "last_approved_source_diff": "last-approved-source.diff",
        "authority": metadata(HERE / "final/authority.json"),
        "trace": metadata(HERE / "final/trace.json"),
        "authoritative_test_sources": {
            p: metadata(HERE / "final" / p)
            for p in [
                "test_a2_nonqualifier.py",
                "test_semantics.py",
                "test_equality.py",
                "test_derivation.py",
                "verify_independent.py",
            ]
        },
        "final_selected_pytest_counts": final_tests,
        "final_selected_pytest_total": sum(final_tests.values()),
        "all_actual_runs": outcomes,
        "exact_arithmetic": proof["exact"],
        "ledger": proof["physical"]["ledger"],
        "positive_equality": equality,
        "per_record_parse_metrics": metrics,
        "parse_metric_maxima": {
            k: max(v[k] for v in metrics.values()) for k in ["nodes", "depth"]
        },
        "new_case_inventory": {"json_records": 25, "static_logs": 2, "exact_slots": 13},
        "final_controls": {
            "missing_required_input_exits_asserted": 4,
            "python_read_guard_rejection": 1,
            "checker_mutants_killed": 5,
            "posthoc_defensive_tests": 29,
        },
        "test_history": (
            "Existing author RED/GREEN and approved pause resumption are historical; "
            "new controls are posthoc and mutation-validated, not TDD claims."
        ),
        "historical_unlaunched_action_relabelled": False,
        "lint": {
            "baseline_findings": 109,
            "candidate_findings": 108,
            "added_checker_findings": 0,
            "new_helpers_final_findings": 0,
            "inherited_capture_helper_E501": 1,
            "preserved_preformat_lint_failures": ["19-new-lint", "34-final-new-lint"],
            "main_repository_lint_run": False,
        },
        "protected_repository_files": 234,
        "head_index_unchanged": True,
        "repository_writes_performed": False,
        "independent_review_passed": False,
        "production_implementation_authorized": False,
        "a2_acceptance_passed": False,
        "protocol_freeze_authorized": False,
        "commit_push_or_phase_closure": False,
        "limitations": [
            "Trace process/timing/security/counter fields are STATIC/HYPOTHETICAL.",
            "Actual exits/XML describe self-tests, never worker observations.",
            "All-1 packet digest is hypothetical; actual packet hash is pinned.",
            "No worker/fitter/selector/AD execution or numerical source edits.",
            "No operation-count, runtime, security or numerical certification.",
            "No resource-sufficiency claim; physical replay is schedule-specific.",
            "Old index and temporary index coexistence are separately counted.",
            "Python audit hook is not an OS sandbox; local authority is trusted.",
            "Ruff baseline retained; production repository lint is separate.",
            "No review approval, freeze, commit, push or phase closure.",
        ],
        "unresolved_issues": [
            "Independent review pending; no correction after a blocking review.",
            "Inherited Ruff: 108 checker/test findings, one capture-helper E501.",
        ],
    }
    save(HERE / "result.json", result)
    inventory.add("result.json")
    tail_findings = []
    for name in ["privacy-scan.json", "result.json"]:
        scan_body(
            name,
            (HERE / name).read_bytes(),
            tail_findings,
            {"bodies": 0, "json_bodies": 0},
        )
    assert not tail_findings
    pins = {p: metadata(HERE / p) for p in sorted(inventory)}
    save(
        HERE / "evidence-index.json",
        {
            "files": pins,
            "file_count": len(pins),
            "excluded": ["self index", "all runtime/cache files"],
            "source_roles": {
                "final/": "authoritative source and static trace",
                "baseline/": "unchanged original evidence",
                "runs/": "immutable per-run snapshots and raw process evidence",
                "mutants/": "deliberately invalid test copies, never candidate source",
            },
            "scope": "Author self-verification only, not independent approval",
        },
    )
    assert all(metadata(HERE / p) == pin for p, pin in pins.items())
    scan_body(
        "evidence-index.json",
        (HERE / "evidence-index.json").read_bytes(),
        tail_findings,
        {"bodies": 0, "json_bodies": 0},
    )
    assert not tail_findings
    print(
        json.dumps(
            {
                "indexed_files": len(pins),
                "final_tests": final_tests,
                "ledger": result["ledger"],
                "parse_maxima": result["parse_metric_maxima"],
                "privacy_findings": 0,
                "independent_review_passed": False,
            }
        )
    )


if __name__ == "__main__":
    main()
