"""Bounded read-only scan of an explicit hash-pinned evidence file allowlist."""
import gzip
import hashlib
import io
import json
import re
import sys
import tarfile
from pathlib import Path, PurePosixPath

PATTERNS = {
    'private-key': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    'telegram-token': re.compile(rb'\b[0-9]{7,12}:[A-Za-z0-9_-]{30,}\b'),
    'provider-token': re.compile(rb'\b(?:ghp_|github_pat_|xox[baprs]-|sk-proj-)[A-Za-z0-9_-]{20,}'),
    'bearer': re.compile(rb'(?i)\bBearer\s+[A-Za-z0-9._~-]{20,}'),
}
SENSITIVE = {'chat_id','message_id','user_id','sender_id','recipient_id',
             'phone','phone_number','email','access_token','refresh_token',
             'bot_token','api_key','password','passwd'}
assert PATTERNS['telegram-token'].search(b'12345678' + b':' + b'A'*35)
findings, bodies = [], []
expanded = 0

def ident(body):
    return {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}

def scan(name, body, depth=0):
    global expanded
    expanded += len(body)
    assert depth <= 8 and len(body) <= 128*1024*1024 and expanded <= 2*1024*1024*1024
    bodies.append({'path':name,**ident(body)})
    if body.startswith(b'\x1f\x8b'):
        with gzip.GzipFile(fileobj=io.BytesIO(body)) as stream:
            decoded = stream.read(128*1024*1024+1)
        assert len(decoded) <= 128*1024*1024
        try:
            archive = tarfile.open(fileobj=io.BytesIO(decoded),mode='r:')
        except tarfile.ReadError:
            scan(name+'::gzip',decoded,depth+1)
        else:
            with archive:
                seen=set()
                for member in archive:
                    path=PurePosixPath(member.name)
                    assert member.isfile() and not path.is_absolute()
                    assert '..' not in path.parts and member.name not in seen
                    assert str(path)==member.name
                    seen.add(member.name)
                    value=archive.extractfile(member).read()
                    assert len(value)==member.size
                    scan(name+'::'+member.name,value,depth+1)
        return
    for kind,pattern in PATTERNS.items():
        if pattern.search(body):
            findings.append({'path':name,'kind':kind})
    try:
        pending=[json.loads(body)]
    except (ValueError,UnicodeError):
        return
    keys=set()
    while pending:
        value=pending.pop()
        if isinstance(value,dict):
            for key,item in value.items():
                if key.lower() in SENSITIVE and item not in (None,''):
                    keys.add(key)
                pending.append(item)
        elif isinstance(value,list):
            pending.extend(value)
    if keys:
        findings.append({'path':name,'kind':'sensitive-json-field','fields':sorted(keys)})

manifest_path, output_path = map(Path,sys.argv[1:])
raw=manifest_path.read_bytes()
manifest=json.loads(raw)
base=Path(manifest['base'])
for name,expected in manifest['files'].items():
    assert name and not name.startswith('/') and '..' not in Path(name).parts
    target=base/name
    assert target.is_file() and not target.is_symlink()
    body=target.read_bytes()
    assert ident(body)==expected
    scan(name,body)
result={'scope':'Bounded explicit-file and recursive regular-archive pattern/field scan; no private identity matching or universal privacy clearance',
        'input_manifest':ident(raw),'root_files':len(manifest['files']),
        'expanded_body_count':len(bodies),'expanded_bytes':expanded,
        'findings':findings,'body_identities':bodies,
        'synthetic_positive_pattern_control_passed':True}
with output_path.open('x') as stream:
    stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'root_files':result['root_files'],'expanded_body_count':len(bodies),'findings':len(findings)}))
assert not findings
