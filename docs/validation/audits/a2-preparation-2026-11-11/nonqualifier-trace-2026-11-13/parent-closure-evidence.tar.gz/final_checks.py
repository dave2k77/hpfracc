"""Verify the permitted post-review status delta and current repository QA."""
import difflib
import hashlib
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK=ROOT/'docs/validation/audits/a2-preparation-2026-11-11/nonqualifier-trace-2026-11-13'
HERE=Path(__file__).parent

def ident(body):
    return {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}

def save(path,value):
    with path.open('x') as stream:
        stream.write(json.dumps(value,indent=2)+'\n')

review=json.loads((WORK/'review-inputs.json').read_text())
resume=json.loads((WORK/'review-resumption-inputs.json').read_text())
baseline=json.loads((WORK/'baseline-inputs.json').read_text())
protected=baseline['files'] | review['files'] | resume['additional_files']
allowed=set(review['allowed_post_review_status_delta'])
changed={name for name,expected in protected.items() if ident((ROOT/name).read_bytes())!=expected}
assert changed==allowed
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==baseline['head']
assert ident(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT))['sha256']==baseline['git_stage_sha256']
with tarfile.open(WORK/'reviewed-status-before-close.tar.gz','r:gz') as archive:
    before={m.name:archive.extractfile(m).read() for m in archive}
assert set(before)==allowed
changes={}
diff=[]
for name in sorted(allowed):
    after=(ROOT/name).read_bytes()
    assert ident(before[name])==review['files'][name]
    changes[name]={'before':ident(before[name]),'after':ident(after),'scope':'Status/progress only'}
    diff.extend(difflib.unified_diff(before[name].decode().splitlines(True),after.decode().splitlines(True),fromfile='reviewed/'+name,tofile='final/'+name))
(HERE/'status-delta.patch').write_text(''.join(diff))
author=json.loads((WORK/'author-result.json').read_text())
verdict=json.loads((WORK/'independent-review-verdict.json').read_text())
assert verdict['review_completed'] and verdict['passed']
assert not verdict['security_concerns'] and not verdict['logic_errors']
assert verdict['reviewed_identities']['checker_sha256']==author['source']['sha256']
assert all(author['ledger'][key]==value for key,value in verdict['verified']['ledger'].items())
readme=(WORK/'README.md').read_text()
for label,key in [('Final retained bodies','final_live_bytes'),('Peak simultaneously live bodies','peak_live_bytes'),('Cumulative writes','cumulative_written_bytes'),('Chosen index transaction','index_transaction_bytes'),('Old index charged','old_index_bytes_charged'),('Temporary replacement index charged','temporary_bytes_charged')]:
    assert f'| {label} | {author["ledger"][key]:,} |' in readme
assert sum(author['final_selected_pytest_counts'].values())==59
qa=HERE/'final-qa'
qa.mkdir(exist_ok=False)
base=['uv','--project',str(ROOT),'run','--frozen','--no-sync']
commands=[
    base+['ruff','check','--no-cache','.'],
    base+['python','-B','-m','pytest','tests/unit/test_docs_consistency.py','-q','-p','no:cacheprovider','--basetemp='+str(HERE/'qa-runtime'),'--junitxml='+str(qa/'docs.xml')],
    base+['mkdocs','build','--strict','--site-dir',str(HERE/'site')],
    ['git','diff','--check'],
]
save(qa/'plan.json',commands)
results=[]
for i,command in enumerate(commands):
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',UV_PROJECT_ENVIRONMENT=str(ROOT/'.venv'),JAX_PLATFORMS='cpu')
    process=subprocess.run(command,cwd=ROOT,env=env,capture_output=True)
    (qa/f'{i}-stdout.raw').write_bytes(process.stdout)
    (qa/f'{i}-stderr.raw').write_bytes(process.stderr)
    results.append({'command':command,'actual_exit':process.returncode})
    print(json.dumps({'command_index':i,'actual_exit':process.returncode}))
save(qa/'receipts.json',results)
assert all(r['actual_exit']==0 for r in results)
tree=ET.parse(qa/'docs.xml')
assert len(tree.findall('.//testcase'))==23
assert not tree.findall('.//failure') and not tree.findall('.//error')
assert all(ident((ROOT/name).read_bytes())==expected for name,expected in protected.items() if name not in allowed)
result={'status':'Allowed three-file status delta and final repository QA verified',
        'changed_files':changes,'protected_files_unchanged':len(protected)-len(allowed),
        'baseline_immutable_files_unchanged':len(baseline['files'])-len(baseline['allowed_status_delta']),
        'head_and_git_stage_unchanged':True,'qa_actual_exits':[r['actual_exit'] for r in results],
        'docs_tests_passed':23,'documentation_ledger_matches_final_report':True,
        'archived_checker_lint_findings_remain':108,'inherited_capture_helper_E501_remains':1,
        'main_repository_lint_passed':True,'full_numerical_suites_rerun':False,
        'raw_qa_location':'parent-closure-evidence.tar.gz::final-qa/',
        'commit_or_push_performed':False}
save(WORK/'final-status-delta.json',result)
print(json.dumps({'status':result['status'],'protected_files_unchanged':result['protected_files_unchanged'],
                  'baseline_immutable_files_unchanged':result['baseline_immutable_files_unchanged'],'docs_tests_passed':23},indent=2))
