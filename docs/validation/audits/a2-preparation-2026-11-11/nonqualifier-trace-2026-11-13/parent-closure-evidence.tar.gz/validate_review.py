"""Parent verification of completed reviewer artifacts after delivery failure."""
import gzip
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11/nonqualifier-trace-2026-11-13'
REVIEW = Path('/home/davianc/.hermes/cache/scratch/hpfracc-independent-resumed-8aWg6Z2V')
HERE = Path(__file__).parent
INDEX_PIN = '8e6149dabc0e5925969d634a4f8a4ebb2f50eedf9107491797ad0d463ae479e9'

def ident(body):
    return {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}

def save(name, data):
    with (HERE/name).open('x') as stream:
        stream.write(json.dumps(data,indent=2)+'\n')

raw = (REVIEW/'evidence-index.json').read_bytes()
assert ident(raw)['sha256'] == INDEX_PIN
index = json.loads(raw)
assert index['file_count'] == len(index['files']) == 329
for name, expected in index['files'].items():
    assert name and not name.startswith('/') and '..' not in Path(name).parts
    path = REVIEW/name
    assert path.is_file() and not path.is_symlink()
    assert ident(path.read_bytes()) == expected
verdict = json.loads((REVIEW/'verdict.json').read_text())
assert verdict['review_completed'] is True and verdict['passed'] is True
assert not verdict['security_concerns'] and not verdict['logic_errors']
for filename,pin,key in [
    ('review-inputs.json','e0f5c757763d00159a2ca85ffe4a890f05674341d6e264755aea1508cba69654','files'),
    ('review-resumption-inputs.json','d1e2810f0a95d15b6d4e5e92654848d133d6431927f2f7ed2eb6a1dcc06f1b0f','additional_files'),
]:
    body=(WORK/filename).read_bytes()
    assert ident(body)['sha256']==pin
    assert all(ident((ROOT/name).read_bytes())==expected for name,expected in json.loads(body)[key].items())
focused = json.loads((REVIEW/'focused-results.json').read_text())
counts={}
for group, expected in focused.items():
    body=(REVIEW/'runs'/group/'raw.xml').read_bytes()
    assert ident(body)==expected['xml']
    tree=ET.fromstring(body)
    cases=tree.findall('.//testcase')
    assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
    assert [c.attrib['classname']+'::'+c.attrib['name'] for c in cases]==expected['test_ids']
    assert len(cases)==expected['test_count'] and expected['actual_child_exit']==0
    actual=json.loads((REVIEW/'runs'/group/'result.json').read_text())
    assert actual['actual_child_exit']==0
    counts[group]=len(cases)
assert sum(counts.values())==verdict['verified']['new_local_selected_pytest']['total']==59
chosen=[name for name in index['files'] if name.startswith(('copied/baseline/','copied/final/','copied/inputs/','runs/positive/before/'))]
chosen+=['pins/baseline-inputs.json','independent_checks.py','independent_controls.py']
assert len(chosen)==len(set(chosen))
for name in chosen:
    target=HERE/name
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream:
        stream.write((REVIEW/name).read_bytes())
commands=[['uv','--project',str(ROOT),'run','--frozen','--no-sync','python','-B',str(HERE/name)]
          for name in ['independent_checks.py','independent_controls.py']]
save('replay-plan.json',{'commands':commands,'copied_inputs':{name:index['files'][name] for name in chosen}})
results=[]
for i,command in enumerate(commands):
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',UV_PROJECT_ENVIRONMENT=str(ROOT/'.venv'),JAX_PLATFORMS='cpu')
    process=subprocess.run(command,cwd=HERE,env=env,capture_output=True)
    (HERE/f'replay-{i}-stdout.raw').write_bytes(process.stdout)
    (HERE/f'replay-{i}-stderr.raw').write_bytes(process.stderr)
    results.append({'command':command,'actual_exit':process.returncode})
save('replay-exits.json',results)
assert all(result['actual_exit']==0 for result in results)
assert all(ident((HERE/name).read_bytes())==index['files'][name] for name in chosen)
physical=json.loads((HERE/'independent/physical-and-causal.json').read_text())
author=json.loads((WORK/'author-result.json').read_text())
assert physical['ledger']==author['ledger']
exact=json.loads((HERE/'independent/authority-and-exact.json').read_text())
assert exact['slots']==author['exact_arithmetic']['slots']
controls=json.loads((HERE/'controls/results.json').read_text())
assert controls['control_count']==len(controls['controls'])==33
assert all(c['rejected'] and c['exception']=='ValueError' for c in controls['controls'])
for control in controls['controls']:
    assert ident((HERE/'controls'/(control['name']+'.json')).read_bytes())['sha256']==control['trace_sha256']
original_controls=json.loads((REVIEW/'controls/results.json').read_text())
assert controls==original_controls
result={'status':'Saved independent PASS accepted after parent index/test/replay readback',
        'review_index_sha256':INDEX_PIN,'reviewed_files_verified':len(index['files']),
        'verdict_sha256':ident((REVIEW/'verdict.json').read_bytes())['sha256'],
        'focused_test_counts':counts,'focused_test_total':sum(counts.values()),
        'fresh_parent_independent_controls_rejected':len(controls['controls']),
        'parent_replay_actual_exits':[r['actual_exit'] for r in results],
        'ledger':physical['ledger'],'exact_slots':exact['slot_count'],
        'positive_bodies':json.loads((HERE/'independent/positive-equality.json').read_text())['emitted_body_count'],
        'delivery_error':'The delegation final-message transport returned HTTP 400. On-disk verdict, complete index and executable proof were recovered and checked; transport failure is not relabeled a test failure.',
        'scope':'Scoped static proof only, not A2 completion or numerical implementation'}
save('parent-review-readback.json',result)
print(json.dumps({k:result[k] for k in ['status','reviewed_files_verified','focused_test_total','fresh_parent_independent_controls_rejected','parent_replay_actual_exits','exact_slots','positive_bodies']},indent=2))
