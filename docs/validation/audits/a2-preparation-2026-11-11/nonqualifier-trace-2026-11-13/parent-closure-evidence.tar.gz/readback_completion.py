"""Final readback of local completion; no delivery or phase-closure claim."""
import hashlib
import html
import json
import os
import re
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK=ROOT/'docs/validation/audits/a2-preparation-2026-11-11/nonqualifier-trace-2026-11-13'
HERE=Path(__file__).parent

def ident(body):
    return {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}

def save(path,value):
    with path.open('x') as stream:
        stream.write(json.dumps(value,indent=2)+'\n')

raw=(WORK/'final-manifest.json').read_bytes()
assert ident(raw)['sha256']==sys.argv[1]
manifest=json.loads(raw)
assert manifest['file_count']==len(manifest['files'])
for name,expected in manifest['files'].items():
    assert not name.startswith('/') and '..' not in Path(name).parts
    assert ident((ROOT/name).read_bytes())==expected
actual={str(p.relative_to(ROOT)) for p in WORK.rglob('*') if p.is_file()}
actual|={'docs/developer/phase-a-completion.md','docs/developer/bug-resolution-tracker.md'}
assert actual==set(manifest['files'])|{str((WORK/'final-manifest.json').relative_to(ROOT))}
review=json.loads((WORK/'review-inputs.json').read_text())
resume=json.loads((WORK/'review-resumption-inputs.json').read_text())
baseline=json.loads((WORK/'baseline-inputs.json').read_text())
protected=baseline['files']|review['files']|resume['additional_files']
allowed=set(review['allowed_post_review_status_delta'])
assert {n for n,e in protected.items() if ident((ROOT/n).read_bytes())!=e}==allowed
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==baseline['head']
assert ident(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT))['sha256']==baseline['git_stage_sha256']
outcome=json.loads((WORK/'outcome.json').read_text())
author=json.loads((WORK/'author-result.json').read_text())
verdict=json.loads((WORK/'independent-review-verdict.json').read_text())
delta=json.loads((WORK/'final-status-delta.json').read_text())
assert outcome['increment_complete'] and verdict['review_completed'] and verdict['passed']
assert not verdict['security_concerns'] and not verdict['logic_errors']
assert outcome['selected_tests_passed']==sum(author['final_selected_pytest_counts'].values())==59
assert outcome['ledger']==author['ledger']
assert outcome['source']==author['source'] and outcome['trace']==author['trace']
assert all(code==0 for code in delta['qa_actual_exits'])
assert all(not outcome[key] for key in ['caps_changed','numerical_source_changed','a2_acceptance_passed',
    'phase_a_complete','production_implementation_authorized','protocol_freeze_authorized','commit_or_push_performed'])
for report_name in ['independent-review-preservation.json','parent-closure-preservation.json']:
    report=json.loads((WORK/report_name).read_text())
    path=WORK/report['archive']
    assert ident(path.read_bytes())['sha256']==report['sha256']
    with tarfile.open(path,'r:gz') as archive:
        members=archive.getmembers()
        assert len(members)==report['members_verified']
        assert len({m.name for m in members})==len(members) and all(m.isfile() for m in members)
        if report_name.startswith('independent'):
            idxraw=archive.extractfile('evidence-index.json').read()
            assert ident(idxraw)['sha256']==report['review_index_sha256']
            index=json.loads(idxraw)
            assert len(index['files'])==index['file_count']==329
            assert set(index['files'])|{'evidence-index.json'}=={m.name for m in members}
            assert all(ident(archive.extractfile(n).read())==e for n,e in index['files'].items())
            assert archive.extractfile('verdict.json').read()==(WORK/'independent-review-verdict.json').read_bytes()
        else:
            assert set(report['files'])=={m.name for m in members}
            assert all(ident(archive.extractfile(n).read())==e for n,e in report['files'].items())
            tree=ET.fromstring(archive.extractfile('final-qa/docs.xml').read())
            assert len(tree.findall('.//testcase'))==23
            assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
            readback=json.loads(archive.extractfile('parent-review-readback.json').read())
            assert readback['fresh_parent_independent_controls_rejected']==33
            assert readback['parent_replay_actual_exits']==[0,0]
for name,needle in [('phase-a-completion','The additional no-qualifier trace now passes scoped independent review.'),
                    ('bug-resolution-tracker','VAL-015 is fixed within the two named static-case checker scope.')]:
    candidates=[HERE/'site/developer'/name/'index.html',HERE/'site/developer'/(name+'.html')]
    built=next(p for p in candidates if p.is_file())
    rendered=' '.join(html.unescape(re.sub('<[^>]*>',' ',built.read_text())).split())
    assert needle in rendered
late_names=['outcome.json','final-privacy-check.json','final-privacy-receipt.json','final-manifest.json']
late={'base':str(WORK),'files':{n:ident((WORK/n).read_bytes()) for n in late_names}}
save(HERE/'late-metadata-privacy-inputs.json',late)
cmd=['uv','--project',str(ROOT),'run','--frozen','--no-sync','python','-B',str(HERE/'scan_evidence.py'),str(HERE/'late-metadata-privacy-inputs.json'),str(HERE/'late-metadata-privacy.json')]
process=subprocess.run(cmd,cwd=ROOT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',UV_PROJECT_ENVIRONMENT=str(ROOT/'.venv')),capture_output=True)
assert process.returncode==0
privacy=json.loads((HERE/'late-metadata-privacy.json').read_text())
assert not privacy['findings']
assert all(ident((ROOT/n).read_bytes())==e for n,e in manifest['files'].items())
assert ident((WORK/'final-manifest.json').read_bytes())['sha256']==sys.argv[1]
record={'status':'Final local scoped completion verified',
        'final_manifest':ident(raw),'final_manifest_files_verified':len(manifest['files']),
        'protected_files_unchanged':len(protected)-len(allowed),'permitted_status_files_changed':len(allowed),
        'independent_review_indexed_files_verified':329,'independent_review_archive_members_verified':330,
        'selected_tests_verified':59,'independent_controls_parent_replayed':33,'docs_tests_verified':23,
        'published_status_text_present_in_built_html':True,
        'late_metadata_privacy':privacy,'late_scan_actual_exit':process.returncode,
        'late_scan_raw_stdout_utf8':process.stdout.decode(),'late_scan_raw_stderr_utf8':process.stderr.decode(),
        'head_and_stage_unchanged':True,'commit_or_push_performed':False,
        'scope':'Only the one additional static no-qualifier increment and scoped VAL-015 ordering repair; not A2/scientific acceptance or remote delivery',
        'self_excluded_from_final_manifest':True,
        'execution_authentication':'This is a normalized local verification record; successful execution is reported by the actual terminal tool exit, not authenticated by this field.'}
save(WORK/'completion-readback.json',record)
print(json.dumps({k:record[k] for k in ['status','final_manifest_files_verified','protected_files_unchanged',
    'permitted_status_files_changed','selected_tests_verified','independent_controls_parent_replayed',
    'docs_tests_verified','published_status_text_present_in_built_html','late_scan_actual_exit']},indent=2))
