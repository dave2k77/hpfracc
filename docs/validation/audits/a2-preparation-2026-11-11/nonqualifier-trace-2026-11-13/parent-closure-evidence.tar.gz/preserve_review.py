"""Preserve the verified independent review and pre-closure status bytes."""
import hashlib
import io
import json
import os
import subprocess
import tarfile
from pathlib import Path

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK=ROOT/'docs/validation/audits/a2-preparation-2026-11-11/nonqualifier-trace-2026-11-13'
REVIEW=Path('/home/davianc/.hermes/cache/scratch/hpfracc-independent-resumed-8aWg6Z2V')
HERE=Path(__file__).parent

def ident(body):
    return {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}

def save(path,data):
    with path.open('x') as stream:
        stream.write(json.dumps(data,indent=2)+'\n')

def archive(path,files):
    with tarfile.open(path,'x:gz') as out:
        for name,body in sorted(files.items()):
            entry=tarfile.TarInfo(name)
            entry.size=len(body)
            entry.mode=0o644
            out.addfile(entry,io.BytesIO(body))
    with tarfile.open(path,'r:gz') as check:
        members=check.getmembers()
        assert len(members)==len(files)
        assert all(m.isfile() and check.extractfile(m).read()==files[m.name] for m in members)
    return {'archive':path.name,**ident(path.read_bytes()),'members_verified':len(files)}

raw=(REVIEW/'evidence-index.json').read_bytes()
assert ident(raw)['sha256']=='8e6149dabc0e5925969d634a4f8a4ebb2f50eedf9107491797ad0d463ae479e9'
index=json.loads(raw)
files={name:(REVIEW/name).read_bytes() for name in index['files']}
assert len(files)==index['file_count']==329
assert all(ident(files[name])==expected for name,expected in index['files'].items())
files['evidence-index.json']=raw
manifest={'base':str(REVIEW),'files':{name:ident(body) for name,body in files.items()}}
save(HERE/'review-privacy-inputs.json',manifest)
cmd=['uv','--project',str(ROOT),'run','--frozen','--no-sync','python','-B',str(HERE/'scan_evidence.py'),str(HERE/'review-privacy-inputs.json'),str(HERE/'review-proof-privacy.json')]
save(HERE/'review-privacy-plan.json',{'command':cmd,'scanner':ident((HERE/'scan_evidence.py').read_bytes())})
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',UV_PROJECT_ENVIRONMENT=str(ROOT/'.venv'))
r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True)
(HERE/'review-privacy-stdout.raw').write_bytes(r.stdout)
(HERE/'review-privacy-stderr.raw').write_bytes(r.stderr)
save(HERE/'review-privacy-exit.json',{'actual_exit':r.returncode})
assert r.returncode==0
scan=json.loads((HERE/'review-proof-privacy.json').read_text())
assert not scan['findings'] and scan['root_files']==len(files)
result=archive(WORK/'independent-review-evidence.tar.gz',files)
with (WORK/'independent-review-verdict.json').open('xb') as stream:
    stream.write(files['verdict.json'])
result.update({'review_indexed_files_verified':index['file_count'],
               'review_index_sha256':ident(raw)['sha256'],
               'verdict_sha256':ident(files['verdict.json'])['sha256'],
               'parent_readback':'All indexed files, raw selected-test XML/receipts and fresh exact/physical/33-control replay verified.',
               'reviewer_proof_privacy_findings':len(scan['findings']),
               'review_completed':True,'passed':True,
               'delegation_completion_transport_error':'HTTP 400 after proof/verdict creation; saved evidence independently read back, not discarded or relabeled as a numerical failure.',
               'scope':'One frozen static increment only; no A2 closure, numerical implementation or delivery approval'})
save(WORK/'independent-review-preservation.json',result)
review=json.loads((WORK/'review-inputs.json').read_text())
statuses=review['allowed_post_review_status_delta']
old={name:(ROOT/name).read_bytes() for name in statuses}
assert all(ident(body)==review['files'][name] for name,body in old.items())
saved=archive(WORK/'reviewed-status-before-close.tar.gz',old)
saved['files']={name:ident(body) for name,body in old.items()}
save(WORK/'reviewed-status-before-close.json',saved)
print(json.dumps({'review_indexed_files':index['file_count'],'archive_members':result['members_verified'],
                  'proof_privacy_findings':len(scan['findings']),'status_files_preserved':len(old),
                  'archive_sha256':result['sha256']},indent=2))
