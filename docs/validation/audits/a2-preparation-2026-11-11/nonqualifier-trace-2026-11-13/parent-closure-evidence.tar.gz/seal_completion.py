"""Archive explicit parent proof, scan final closure, and seal local completion."""
import datetime
import hashlib
import io
import json
import os
import subprocess
import tarfile
from pathlib import Path

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
WORK=ROOT/'docs/validation/audits/a2-preparation-2026-11-11/nonqualifier-trace-2026-11-13'
HERE=Path(__file__).parent

def ident(body):
    return {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}

def save(path,value):
    with path.open('x') as stream:
        stream.write(json.dumps(value,indent=2)+'\n')

plan=json.loads((HERE/'replay-plan.json').read_text())
physical=json.loads((HERE/'independent/physical-and-causal.json').read_text())
controls=json.loads((HERE/'controls/results.json').read_text())
names=set(plan['copied_inputs'])
names.update(['validate_review.py','scan_evidence.py','preserve_review.py','final_checks.py',
              'seal_completion.py','readback_completion.py',
              'parent-review-readback.json','replay-plan.json','replay-exits.json',
              'review-privacy-inputs.json','review-privacy-plan.json','review-proof-privacy.json',
              'review-privacy-stdout.raw','review-privacy-stderr.raw','review-privacy-exit.json',
              'status-delta.patch','independent/authority-and-exact.json',
              'independent/physical-and-causal.json','independent/positive-equality.json',
              'controls/results.json','final-qa/plan.json','final-qa/receipts.json','final-qa/docs.xml'])
names.update(f'replay-{i}-{stream}.raw' for i in range(2) for stream in ['stdout','stderr'])
names.update(f'final-qa/{i}-{stream}.raw' for i in range(4) for stream in ['stdout','stderr'])
names.update('independent/physical/'+name for name in physical['final_bodies'])
names.update('controls/'+item['name']+'.json' for item in controls['controls'])
files={name:(HERE/name).read_bytes() for name in sorted(names)}
archive=WORK/'parent-closure-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as out:
    for name,body in files.items():
        member=tarfile.TarInfo(name)
        member.size=len(body)
        member.mode=0o644
        out.addfile(member,io.BytesIO(body))
with tarfile.open(archive,'r:gz') as check:
    members=check.getmembers()
    assert len(members)==len(files)
    assert all(m.isfile() and check.extractfile(m).read()==files[m.name] for m in members)
save(WORK/'parent-closure-preservation.json',{'archive':archive.name,**ident(archive.read_bytes()),
     'members_verified':len(files),'files':{name:ident(body) for name,body in files.items()},
     'capture_scope':'Explicit parent code, copied replay inputs, raw checks, synthetic control traces and final QA; no ambient scratch or messaging receipts'})
# Pin every current file of this task plus the only two existing status documents.
paths=[p for p in WORK.rglob('*') if p.is_file()]
paths += [ROOT/'docs/developer/phase-a-completion.md',ROOT/'docs/developer/bug-resolution-tracker.md']
manifest={'base':str(ROOT),'files':{str(p.relative_to(ROOT)):ident(p.read_bytes()) for p in sorted(paths)}}
save(HERE/'final-privacy-inputs.json',manifest)
cmd=['uv','--project',str(ROOT),'run','--frozen','--no-sync','python','-B',str(HERE/'scan_evidence.py'),str(HERE/'final-privacy-inputs.json'),str(WORK/'final-privacy-check.json')]
process=subprocess.run(cmd,cwd=ROOT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',UV_PROJECT_ENVIRONMENT=str(ROOT/'.venv')),capture_output=True)
(HERE/'final-privacy-stdout.raw').write_bytes(process.stdout)
(HERE/'final-privacy-stderr.raw').write_bytes(process.stderr)
assert process.returncode==0
privacy=json.loads((WORK/'final-privacy-check.json').read_text())
assert not privacy['findings']
save(WORK/'final-privacy-receipt.json',{'command':cmd,'actual_exit':process.returncode,
     'input_files':manifest['files'],'scanner':ident((HERE/'scan_evidence.py').read_bytes()),
     'stdout':ident(process.stdout),'stderr':ident(process.stderr),
     'raw_stdout_utf8':process.stdout.decode(),'raw_stderr_utf8':process.stderr.decode(),
     'scope':'Bounded scan; no private identity matching'})
author=json.loads((WORK/'author-result.json').read_text())
verdict=json.loads((WORK/'independent-review-verdict.json').read_text())
delta=json.loads((WORK/'final-status-delta.json').read_text())
readback=json.loads((HERE/'parent-review-readback.json').read_text())
assert verdict['review_completed'] and verdict['passed']
assert all(code==0 for code in delta['qa_actual_exits'])
assert readback['fresh_parent_independent_controls_rejected']==33
outcome={'status':'SCOPED ADDITIONAL STATIC NO-QUALIFIER INCREMENT COMPLETE',
         'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'approval_record':'authorization.json','case_id':'REF-FAIL-f64-GL',
         'witness_id':'nonqualify-REF-FAIL-f64-GL','increment_complete':True,
         'source':author['source'],'trace':author['trace'],
         'independent_review_passed':True,'independent_review_record':'independent-review-verdict.json',
         'independent_review_proof_indexed_files':329,'independent_review_archive_members':330,
         'selected_tests_passed':59,'selected_tests_breakdown':author['final_selected_pytest_counts'],
         'independent_posthoc_controls_rejected':33,'parent_replayed_independent_controls':33,
         'exact_slots':13,'exact_arithmetic':author['exact_arithmetic'],
         'prior_selected_canonical_trace_and_all_38_bodies_unchanged':True,
         'ledger':author['ledger'],'parse_metric_maxima':author['parse_metric_maxima'],
         'final_repository_qa':{'actual_exits':delta['qa_actual_exits'],'docs_tests_passed':23,
             'ruff_passed':True,'strict_docs_passed':True,'whitespace_passed':True,
             'full_numerical_suites_rerun':False},
         'archived_source_lint_limitations':author['lint'],
         'status_delta_record':'final-status-delta.json','protected_files_unchanged':delta['protected_files_unchanged'],
         'baseline_immutable_files_unchanged':234,
         'final_privacy_check':{'record':'final-privacy-check.json','root_files':privacy['root_files'],
             'expanded_bodies':privacy['expanded_body_count'],'unresolved_pattern_findings':0,
             'scope':'Bounded explicit-file/recursive archive patterns; no private identity matching or universal clearance'},
         'prior_approval_pauses_preserved':True,'review_completion_transport_error_preserved':'HTTP 400; saved verdict/index/proof recovered and verified',
         'hypothetical_fields_are_worker_observations':False,
         'broader_accounting_proved':False,'eight_fit_real_admission_blockers_resolved':False,
         'caps_changed':False,'numerical_source_changed':False,'a2_acceptance_passed':False,
         'phase_a_complete':False,'production_implementation_authorized':False,
         'protocol_freeze_authorized':False,'commit_or_push_performed':False,
         'next_boundary':'Stop at this one-case increment. Further conditional cases or resource-budget revisions need separate approval.'}
save(WORK/'outcome.json',outcome)
paths=[p for p in WORK.rglob('*') if p.is_file()]+[ROOT/'docs/developer/phase-a-completion.md',ROOT/'docs/developer/bug-resolution-tracker.md']
final={'scope':'Final local scoped increment; not remote delivery or phase closure',
       'files':{str(p.relative_to(ROOT)):ident(p.read_bytes()) for p in sorted(paths)},
       'self_excluded':'final-manifest.json','completion_receipt_excluded':'completion-readback.json'}
final['file_count']=len(final['files'])
save(WORK/'final-manifest.json',final)
print(json.dumps({'status':outcome['status'],'parent_archive_members':len(files),
                  'final_manifest_files':final['file_count'],
                  'final_manifest_sha256':ident((WORK/'final-manifest.json').read_bytes())['sha256'],
                  'final_privacy_roots':privacy['root_files'],'final_privacy_findings':len(privacy['findings'])},indent=2))
