"""ONE additional STATIC/HYPOTHETICAL case; no observed worker outcomes."""

import importlib.util
from pathlib import Path

HERE = Path(__file__).resolve().parent


def module():
    path = HERE / "a2_trace.py"
    spec = importlib.util.spec_from_file_location("a2_noqualifier", path)
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    return audit


def test_completed_nonqualifier_has_all_exact_slots_and_closed_ledger():
    audit = module()
    trace = audit.make_trace()
    report = audit.verify_trace(trace)
    assert report["case_id"] == "REF-FAIL-f64-GL"
    assert report["slot_count"] == 13
    assert len(trace["records"]) == 25
    result = trace["records"]["result.json"]
    assert result["status"] == "no_supplied_candidate_meets_bound"
    assert result["selected_id"] is None
    assert result["reasons"] == ["none"]
    assert len(result["assessments"]) == 1
    assessment = result["assessments"][0]
    assert assessment["status"] == "known_rejected_by_bound"
    assert assessment["candidate_id"] == "bad1-f64-GL"
    assert assessment["qualifies"] is False
    assert assessment["reasons"] == ["none"]
    assert trace["ledger"] == report["ledger"] == audit.replay_ledger(trace)
    assert report["implementation_authorized"] is False
    assert report["a2_acceptance_passed"] is False
