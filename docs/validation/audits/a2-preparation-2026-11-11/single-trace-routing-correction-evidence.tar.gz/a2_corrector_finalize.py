"""Verify this one correction's actual results and create a readback proof index."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

from a2_corrector_guard import AUTHOR, HERE, check


def enc(value):
    return json.dumps(value, ensure_ascii=True, allow_nan=False, sort_keys=True, separators=(',', ':')).encode('ascii')


def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    assert not path.exists(), str(path)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def checked_run(name, exit_code, expected_counts=None):
    folder = HERE / name
    result = load(folder / 'process.json')
    assert result['actual_child_exit'] == exit_code
    for stream in ('stdout', 'stderr'):
        assert pin(folder / (stream + '.raw')) == result[stream]
    if (folder / 'plan.json').exists():
        plan = load(folder / 'plan.json')
        if 'executed_source_snapshots' in plan:
            assert result['command'] == plan['command']
            for filename, expected in plan['executed_source_snapshots'].items():
                assert pin(folder / 'before' / filename) == expected
    if expected_counts is not None:
        root = ET.parse(folder / 'raw.xml').getroot()
        cases = list(root.iter('testcase'))
        actual = {'tests': len(cases), 'failures': sum(c.find('failure') is not None for c in cases),
                  'errors': sum(c.find('error') is not None for c in cases),
                  'skipped': sum(c.find('skipped') is not None for c in cases)}
        actual['passed'] = actual['tests'] - sum(actual[k] for k in ('failures', 'errors', 'skipped'))
        assert actual == expected_counts == result['counts']
        suite = list(root.iter('testsuite'))[0]
        assert all(int(suite.get(k)) == actual[k] for k in ('tests', 'failures', 'errors', 'skipped'))
        assert pin(folder / 'raw.xml') == result['xml']
    return result


protected = check()
assert protected == load(HERE / 'protected-before.json') == load(HERE / 'protected-after.json')
rejected = (HERE / 'rejected/a2_trace.py').read_bytes()
corrected = (HERE / 'candidate/a2_trace.py').read_bytes()
assert hashlib.sha256(rejected).hexdigest() == '48742703d81152398f7879875d1e7f4f35d5b011cdb8950cb3cbda7b6fa8c48a'
added_line = b"        need(binding['binding_id'] == 'host-' + suffix, 'binding path-to-ID')\n"
assert corrected.count(added_line) == 1 and corrected.replace(added_line, b'') == rejected
original_tests = (AUTHOR / 'test_a2_trace.py').read_bytes()
assert (HERE / 'candidate/test_a2_trace.py').read_bytes() == original_tests
for filename in ('authority.json', 'protocol.json', 'record-schemas.json', 'trace.json', 'self-check.json', 'methodology.md'):
    assert (HERE / 'candidate' / filename).read_bytes() == (AUTHOR / filename).read_bytes()
red = checked_run('red-routing', 1, {'tests': 26, 'passed': 20, 'failures': 6, 'errors': 0, 'skipped': 0})
green = checked_run('green-routing', 0, {'tests': 26, 'passed': 26, 'failures': 0, 'errors': 0, 'skipped': 0})
isolated = checked_run('isolated-tests', 0, {'tests': 26, 'passed': 26, 'failures': 0, 'errors': 0, 'skipped': 0})
assert (HERE / 'red-routing/before/a2_trace.py').read_bytes() == rejected
for phase in ('green-routing', 'isolated-tests', 'isolated-replay', 'missing-artifact'):
    assert (HERE / phase / 'before/a2_trace.py').read_bytes() == corrected
for phase in ('red-routing', 'green-routing', 'isolated-tests'):
    assert (HERE / phase / 'before/test_a2_trace.py').read_bytes() == original_tests
    assert (HERE / phase / 'before/test_a2_routing.py').read_bytes() == (HERE / 'candidate/test_a2_routing.py').read_bytes()
failures = [c for c in red['testcases'] if c['failure'] is not None]
assert len(failures) == 6 and all('DID NOT RAISE' in c['failure'] for c in failures)
assert all(c['classname'] == 'test_a2_routing' for c in failures)
assert [c['name'] for c in red['testcases']] == [c['name'] for c in green['testcases']] == [c['name'] for c in isolated['testcases']]
assert sum(c['classname'] == 'test_a2_trace' for c in green['testcases']) == 20
replay = checked_run('isolated-replay', 0)
missing = checked_run('missing-artifact', 1)
assert not (HERE / 'missing-artifact/before/trace.json').exists()
assert b'FileNotFoundError: required preserved positive artifact is missing:' in (HERE / 'missing-artifact/stderr.raw').read_bytes()
assert not (HERE / 'missing-artifact/before/replay-report.json').exists()
for phase in ('guard-failure-reproduction-01', 'guard-failure-reproduction-02'):
    checked_run(phase, 1)
assert load(HERE / 'guard-before-run/process.json')['actual_child_exit'] == 0
assert load(HERE / 'guard-after-run/process.json')['actual_child_exit'] == 0
assert load(HERE / 'scoped-lint/process.json')['actual_child_exit'] == 0
positive = load(HERE / 'isolated-replay/before/replay-report.json')
original_trace_raw = (AUTHOR / 'trace.json').read_bytes()
assert original_trace_raw == (HERE / 'candidate/trace.json').read_bytes() == (HERE / 'isolated-replay/before/trace.json').read_bytes()
original_trace = json.loads(original_trace_raw)
assert positive['canonical_positive_trace'] == {'bytes': len(enc(original_trace)), 'sha256': hashlib.sha256(enc(original_trace)).hexdigest()}
assert positive['ledger'] == original_trace['ledger']
original_files = {name: enc(value) for name, value in original_trace['records'].items()} | {
    name: bytes.fromhex(value) for name, value in original_trace['logs'].items()}
assert len(original_files) == positive['final_files']
artifact_pins = {}
for name, raw in original_files.items():
    materialized = HERE / 'isolated-replay/before/materialized' / name
    assert materialized.read_bytes() == raw
    artifact_pins[name] = pin(materialized)
save(HERE / 'positive-artifact-readback.json', {
    'original_source': str(AUTHOR / 'trace.json'), 'original_source_pin': pin(AUTHOR / 'trace.json'),
    'canonical_positive_trace': positive['canonical_positive_trace'],
    'direct_live_original_to_preserved_copy_equality': True,
    'all_emitted_artifacts_equal_original_canonical_bytes': True,
    'files': artifact_pins, 'ledger_equal_original': True,
})
diff = ''.join(difflib.unified_diff(rejected.decode().splitlines(keepends=True), corrected.decode().splitlines(keepends=True),
                                    fromfile='rejected/a2_trace.py', tofile='candidate/a2_trace.py'))
(HERE / 'implementation.diff').write_text(diff)
full_diff = diff
for filename in ('test_a2_routing.py', 'a2_portable_replay.py'):
    full_diff += ''.join(difflib.unified_diff([], (HERE / 'candidate' / filename).read_text().splitlines(keepends=True),
                                            fromfile='/dev/null', tofile='candidate/' + filename))
(HERE / 'changes.diff').write_text(full_diff)
# Parse every source body without importing or producing __pycache__ writes.
for path in HERE.rglob('*.py'):
    if 'uv-cache' not in path.relative_to(HERE).parts:
        ast.parse(path.read_text(), filename=str(path))
report = {
    'finding': 'FIXED-TRACE-ROUTING-01', 'role': 'third-context corrector, not author or reviewer',
    'correction_cycle': 1, 'maximum_correction_cycles': 1,
    'status': 'single routing guard corrected; self-verification passed; fresh independent review required',
    'scope': 'ONE STATIC/HYPOTHETICAL selected-REF-PASS-f64-GL; N=3; two supplied synthetic candidates; all 22 exact slots',
    'rejected_source': pin(HERE / 'rejected/a2_trace.py'), 'corrected_source': pin(HERE / 'candidate/a2_trace.py'),
    'implementation_diff': pin(HERE / 'implementation.diff'), 'complete_delta_diff': pin(HERE / 'changes.diff'),
    'original_test_source_byte_identical': True, 'unchanged_original_tests': 20,
    'new_fully_resigned_route_parameters': 6, 'red_failure_reason': 'six behavioral DID NOT RAISE failures; no setup/hash errors',
    'runs': {name: {'actual_child_exit': result['actual_child_exit'], **({'counts': result['counts']} if 'counts' in result else {}),
                    'process': str(HERE / name / 'process.json')}
             for name, result in [('red-routing', red), ('green-routing', green), ('isolated-tests', isolated),
                                  ('isolated-replay', replay), ('missing-artifact', missing)]},
    'all_audit_runs_execute_prerun_source_snapshot': True,
    'scoped_lint': {'actual_child_exit': 0, 'selection': 'new regression and portable replay; E4,E7,E9,F only; not a whole-repository lint claim',
                    'process': str(HERE / 'scoped-lint/process.json')},
    'positive_artifact': positive, 'direct_positive_original_readback': str(HERE / 'positive-artifact-readback.json'),
    'protected_before_after_equal': True, 'protected_counts': {k: protected[k] for k in ('author', 'review', 'repo_union', 'numerical', 'history', 'packet')},
    'head': protected['head'], 'git_index_sha256': protected['index_sha256'], 'git_stage_sha256': protected['stage_sha256'],
    'protected_extra_pins': protected['extra_pins'],
    'issues_encountered': [
        'Two preliminary guard-harness metadata representation failures were preserved, then exactly replayed with raw child exit 1. They are not trace RED failures, protected-file drift, or extra implementation correction cycles.',
        'First two guard invocations have terminal-result transcriptions and unchanged post-failure source copies, not pre-run captures or separate original raw-child files; later captured failures are explicitly reproductions.',
    ],
    'parent_tasks_closed': False, 'repository_files_modified_by_corrector': False,
    'caps_changed': False, 'schema_or_allowlist_changed': False, 'coverage_expanded': False,
    'numerical_source_math_tolerance_domain_changed': False,
    'operational_validator_or_worker_implemented': False,
    'hypothetical_execution_security_counter_fields_are_observations': False,
    'independent_review_passed': False, 'a2_acceptance_passed': False,
    'implementation_authorized': False, 'protocol_freeze_authorized': False,
    'broader_accounting_proved': False,
    'output_directory': str(HERE), 'proof_index': str(HERE / 'proof-index.json'),
    'proof_index_verification': str(HERE / 'proof-index-verification.json'),
}
save(HERE / 'correction-report.json', report)
# Full proof coverage, including pytest route-mutant bodies and symlink targets as
# labelled readlink bytes; do not follow their referents or self-hash the index.
files = {}
excluded_files = ['proof-index.json', 'proof-index-verification.json']
for path in sorted(HERE.rglob('*')):
    name = path.relative_to(HERE).as_posix()
    if name in excluded_files or name.split('/')[0] == 'uv-cache':
        continue
    if path.is_symlink():
        raw = os.readlink(path).encode('utf-8')
        files[name] = {'kind': 'symlink_readlink_utf8', 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    elif path.is_file():
        files[name] = {'kind': 'regular_file', **pin(path)}
index = {'scope': 'corrector proof files only; not independent approval', 'excluded_exact_files': excluded_files,
         'excluded_directories': ['uv-cache'], 'files': files, 'files_count': len(files),
         'total_indexed_bytes': sum(p['bytes'] for p in files.values())}
save(HERE / 'proof-index.json', index)
readback = load(HERE / 'proof-index.json')
assert readback == index
for name, expected in readback['files'].items():
    path = HERE / name
    if expected['kind'] == 'symlink_readlink_utf8':
        raw = os.readlink(path).encode('utf-8')
        actual = {'kind': 'symlink_readlink_utf8', 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    else:
        actual = {'kind': 'regular_file', **pin(path)}
    assert actual == expected, name
assert check() == protected
verification = {'proof_index': pin(HERE / 'proof-index.json'), 'indexed_file_entries_verified': len(files),
                'indexed_bytes_verified': sum(p['bytes'] for p in files.values()), 'all_index_entries_read_back': True,
                'protected_original_pins_rechecked_after_index': True,
                'verification_self_excluded': True, 'verification_bound_by_real_finalizer_tool_exit_output': True,
                'independent_review_passed': False, 'a2_acceptance_passed': False,
                'implementation_authorized': False, 'protocol_freeze_authorized': False,
                'broader_accounting_proved': False}
save(HERE / 'proof-index-verification.json', verification)
print(json.dumps({'report': str(HERE / 'correction-report.json'), 'report_pin': pin(HERE / 'correction-report.json'),
                  'corrected_source': report['corrected_source'], 'verification': verification,
                  'runs': report['runs'], 'implementation_diff': diff}, sort_keys=True))
