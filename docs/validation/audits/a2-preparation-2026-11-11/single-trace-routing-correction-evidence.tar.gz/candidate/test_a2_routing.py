"""FIXED-TRACE-ROUTING-01; mutations of the ONE existing hypothetical trace."""
import copy
import json

import pytest

from test_a2_trace import module


@pytest.mark.parametrize('suffix', ['X', '0', '1'])
@pytest.mark.parametrize('identity_kind', ['duplicate', 'fresh'])
def test_existing_binding_route_matches_resigned_binding_id(suffix, identity_kind, tmp_path):
    audit = module()
    original = audit.make_trace()
    path = 'records/binding-host-' + suffix + '.json'
    replacement = ('host-0' if suffix == '1' else 'host-1') if identity_kind == 'duplicate' else 'host-fresh'
    original_ids = [v['binding_id'] for v in original['records'].values()
                    if v['record_type'] == 'producer_binding']
    assert (replacement in original_ids) is (identity_kind == 'duplicate')
    assert replacement != original['records'][path]['binding_id']

    def mutate(records):
        records[path]['binding_id'] = replacement

    trace = audit.make_trace(mutate)
    records = trace['records']
    binding = records[path]
    assert binding['binding_id'] == replacement
    assert path != 'records/binding-' + binding['binding_id'] + '.json'
    expected_binding = copy.deepcopy(original['records'][path])
    expected_binding['binding_id'] = replacement
    assert binding == expected_binding  # source/mode/occurrence/descriptor fields unchanged
    for other_path, value in records.items():
        audit.schema_check(value, audit.SCHEMA)
        if value['record_type'] == 'producer_binding' and other_path != path:
            assert value == original['records'][other_path]
    assert audit.SCHEMA['x-artifact-routing']['records/binding-{binding_id}.json'] == '#/$defs/producer_binding'

    # Prove the preconditions before invoking the actual verifier: re-signed
    # binding/standalone/inline/index/manifest/export links and live-byte ledger.
    for returned in binding['returned']:
        slot = records['arrays/' + returned['slot_id'] + '.json']
        assert slot['producer_binding_sha256'] == audit.digest(audit.canonical(binding))
        assert slot['exact_array'] == original['records']['arrays/' + returned['slot_id'] + '.json']['exact_array']
        assert returned['descriptor']['payload_sha256'] == audit.digest(audit.canonical(slot['exact_array']))
    result = records['result.json']
    inline = result['shared_slots'] + [s for assessment in result['assessments'] for s in assessment['slots']]
    assert len(inline) == 22
    for slot in inline:
        assert slot == records['arrays/' + slot['slot_id'] + '.json']
    index = records['failure-index.json']
    for row in index['slots']:
        slot_path = 'arrays/' + row['slot_id'] + '.json'
        raw = audit.canonical(records[slot_path])
        assert row['artifact'] == {'path': slot_path, 'bytes': len(raw), 'sha256': audit.digest(raw)}
    files = audit.raw_files(trace)
    assert {entry['path']: (entry['bytes'], entry['sha256']) for entry in records['run-manifest.json']['files']} == {
        name: (len(raw), audit.digest(raw)) for name, raw in files.items() if name != 'run-manifest.json'
    }
    export = records['records/export.json']
    assert export['failure_index_sha256'] == audit.digest(audit.canonical(index))
    assert export['failure_index_bytes'] == len(audit.canonical(index))
    assert export['process_sha256'] == audit.digest(audit.canonical(records['records/process.json']))
    assert index['process'] == records['records/process.json']
    audit.check_completion(records)
    audit.check_fixed_exact_payloads(records)
    audit.check_lifecycle(trace)
    assert trace['ledger'] == audit.replay_ledger(trace)
    (tmp_path / 'fully-resigned-route-mutant.json').write_text(json.dumps(trace, indent=2) + '\n')
    with pytest.raises(ValueError, match='binding path-to-ID'):
        audit.verify_trace(trace)
