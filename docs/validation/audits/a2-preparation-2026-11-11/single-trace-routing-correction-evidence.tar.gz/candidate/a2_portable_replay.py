"""Portable read-only fixed-trace replay and positive-byte comparison.

All inputs resolve beside this file. Process/security/counter fields in the
STATIC witness remain illustrative, never observations of this replay process.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
BLOCKED = ('/home/davianc/.hermes/cache/scratch/a2-single-trace-20261112',
           '/home/davianc/.hermes/cache/scratch/a2-independent-fixed-review-kgblph4j',
           '/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/src',
           '/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/tests',
           '/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/benchmarks',
           '/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/docs')


def deny_original_reads(event, arguments):
    if event == 'open' and isinstance(arguments[0], (str, bytes)):
        name = str(Path(arguments[0]).resolve())
        if any(name == prefix or name.startswith(prefix + '/') for prefix in BLOCKED):
            raise PermissionError('isolated replay forbids reading original source data: ' + name)


sys.addaudithook(deny_original_reads)
trace_path = HERE / 'trace.json'
if not trace_path.is_file():
    raise FileNotFoundError('required preserved positive artifact is missing: ' + str(trace_path))
raw_preserved = trace_path.read_bytes()
assert hashlib.sha256(raw_preserved).hexdigest() == 'ba9e40f8e9fa66d13dee2439e9087239b52e523128119eb3d0340ad2b00d2a62'
preserved = json.loads(raw_preserved)
spec = importlib.util.spec_from_file_location('a2_local_fixed_trace', HERE / 'a2_trace.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
built = audit.make_trace()


def enc(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')


def bodies(trace):
    return {p: enc(v) for p, v in trace['records'].items()} | {
        p: bytes.fromhex(v) for p, v in trace['logs'].items()
    }


assert enc(built) == enc(preserved), 'positive canonical trace changed'
assert bodies(built) == bodies(preserved), 'positive canonical artifacts changed'
assert built['ledger'] == preserved['ledger']
verified = audit.verify_trace(preserved)
assert audit.verify_trace(built) == verified
files = bodies(built)
materialized = HERE / 'materialized'
materialized.mkdir()
for name, raw in files.items():
    path = materialized / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    assert path.read_bytes() == raw and path.stat().st_size == len(raw)
initial = enc(built['initial_index'])
all_bodies = files | {'INITIAL_INDEX': initial}
live = {}
terms = {}
cumulative = peak = 0
writes = replacements = 0
for event in built['events']:
    if event['op'] == 'write':
        raw = all_bodies[event['body']]
        assert event['path'] not in live and event['body'] not in terms
        live[event['path']] = raw
        terms[event['body']] = len(raw)
        cumulative += len(raw)
        writes += 1
    else:
        assert live[event['target']] == initial
        live[event['target']] = live.pop(event['source'])
        replacements += 1
    peak = max(peak, sum(len(raw) for raw in live.values()))
assert live == files
independent = {'terms': terms, 'cumulative_written_bytes': cumulative,
               'final_live_bytes': sum(p.stat().st_size for p in materialized.rglob('*') if p.is_file()),
               'peak_live_bytes': peak,
               'index_transaction_bytes': sum(len(all_bodies[p]) for p in
                   ['INITIAL_INDEX', 'failure-index.json', 'records/process.json',
                    'records/export.json', 'records/output-control.json']),
               'temporary_bytes_charged': len(files['failure-index.json']),
               'old_index_bytes_charged': len(initial)}
assert independent == built['ledger']
report = {
    'scope': 'ONE STATIC/HYPOTHETICAL selected-REF-PASS-f64-GL; self-verification only',
    'case_id': built['case_id'],
    'canonical_positive_trace_equal': True,
    'all_emitted_canonical_artifact_bytes_equal': True,
    'preserved_trace_file': {'bytes': len(raw_preserved), 'sha256': hashlib.sha256(raw_preserved).hexdigest()},
    'canonical_positive_trace': {'bytes': len(enc(built)), 'sha256': hashlib.sha256(enc(built)).hexdigest()},
    'comparison': 'Rebuilt positive compared directly to preserved original trace bytes parsed locally, not ledger constants alone',
    'final_files': len(files), 'json_records': len(built['records']),
    'raw_logs': len(built['logs']), 'slots': verified['slot_count'],
    'events': len(built['events']), 'charged_writes': writes, 'replacements': replacements,
    'index_generations': 2,
    'max_record_nodes': max(audit.metrics(v)[0] for v in built['records'].values()),
    'max_record_depth': max(audit.metrics(v)[1] for v in built['records'].values()),
    'ledger': independent,
    'python_open_audit_guard_blocks_original_source_data': True,
    'reads_original_author_reviewer_or_repo_source_data': False,
    'operating_system_sandbox_or_security_attestation': False,
    'hypothetical_fields_are_observed_execution': False,
    'independent_review_passed': False, 'a2_acceptance_passed': False,
    'implementation_authorized': False, 'protocol_freeze_authorized': False,
    'broader_accounting_proved': False,
}
(HERE / 'replay-report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps(report, sort_keys=True))
