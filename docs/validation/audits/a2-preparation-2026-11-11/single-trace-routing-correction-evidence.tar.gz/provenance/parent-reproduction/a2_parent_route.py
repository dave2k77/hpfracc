import importlib.util,json
from pathlib import Path
base=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('fixed_audit',base/'a2_trace.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
t=a.make_trace(lambda r:r['records/binding-host-0.json'].update(binding_id='host-1'))
a.verify_trace(t)
actual='records/binding-host-0.json'
required='records/binding-'+t['records'][actual]['binding_id']+'.json'
print(json.dumps({'checker_accepted':True,'actual_path':actual,'required_path':required}),flush=True)
assert actual==required,'fixed audit accepts a path-to-binding-ID routing violation'
