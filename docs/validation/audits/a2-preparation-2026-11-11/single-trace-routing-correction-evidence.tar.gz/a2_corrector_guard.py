"""Read-only pinned-input guard for FIXED-TRACE-ROUTING-01 only."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
AUTHOR = Path('/home/davianc/.hermes/cache/scratch/a2-single-trace-20261112')
REVIEW = Path('/home/davianc/.hermes/cache/scratch/a2-independent-fixed-review-kgblph4j')
ROOT = REPO / 'docs/validation/audits/a2-preparation-2026-11-11'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def info(path):
    assert not path.is_symlink(), str(path)
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}


def checked_json(path, expected):
    raw = path.read_bytes()
    assert sha(raw) == expected, str(path)
    return json.loads(raw)


def inventory(base, items):
    for name, pin in items.items():
        actual = info(base / name)
        assert (actual['sha256'] == pin if isinstance(pin, str) else actual == pin), str(base / name)
    return {'files': len(items), 'bytes': sum(info(base / name)['bytes'] for name in items)}


def check():
    manifest = checked_json(AUTHOR / 'review-manifest.json', '266772753264b13e0788628c62c196400fa6515ceca5c1555713edff228e3ac9')
    author_index = checked_json(AUTHOR / 'evidence-index.json', 'be5a1ba950860abbf66b849fdc5a057c75b6bafbe064ea21635e26a60633aa07')
    review_index = checked_json(REVIEW / 'proof-index.json', 'ea1cf140c393c5426e328833bff087ba52c37b0fcf297fd9ae83dd75ffe3d4d9')
    checked_json(REVIEW / 'assessment.json', '2c52c108aa98c89cdb882e4194c75898fc4d3f7f4bd474dc5cc1a7b04fc4055a')
    assert manifest['artifact_files'] == author_index['files']
    outputs = {
        'author': inventory(AUTHOR, manifest['artifact_files']),
        'review': inventory(REVIEW, review_index['files']),
        'repo_union': inventory(REPO, manifest['repo_files']),
    }
    baseline = json.loads((AUTHOR / 'baseline.json').read_bytes())
    for label, key in [('numerical', 'numerical_inputs'), ('history', 'history'), ('packet', 'packet_before')]:
        outputs[label] = inventory(REPO, baseline[key])
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    def git(*args):
        return subprocess.check_output(['git', '-C', str(REPO), *args], env=env)
    head = git('rev-parse', 'HEAD').decode().strip()
    index_path = Path(git('rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
    index_hash = sha(index_path.read_bytes())
    stage_hash = sha(git('ls-files', '--stage'))
    assert head == manifest['head']
    assert index_hash == manifest['index_sha256']
    assert stage_hash == manifest['stage_sha256']
    outputs.update(head=head, index_sha256=index_hash, stage_sha256=stage_hash)
    extras = [
        (AUTHOR, 'review-manifest.json'), (AUTHOR, 'evidence-index.json'),
        (REVIEW, 'assessment.json'), (REVIEW, 'assessment.md'), (REVIEW, 'proof-index.json'),
        (REVIEW, 'proof-index-verification.json'), (REVIEW, 'final-pins.json'),
    ]
    for name in ['single-trace-failed-review-preservation.json', 'single-trace-routing-correction-plan.json',
                 'single-trace-rejected-author-evidence.tar.gz', 'single-trace-independent-review-failed-evidence.tar.gz']:
        extras.append((ROOT, name))
    for name in ['a2_parent_route.py', 'process.json', 'stdout.raw', 'stderr.raw']:
        extras.append((AUTHOR / 'parent-route-reproduction', name))
    outputs['extra_pins'] = {str(base / name): info(base / name) for base, name in extras}
    preservation = json.loads((ROOT / 'single-trace-failed-review-preservation.json').read_bytes())
    for row in preservation['archives']:
        assert info(REPO / row['path']) == {k: row[k] for k in ('bytes', 'sha256')}
    outputs['protected_unchanged'] = True
    before = HERE / 'protected-before.json'
    if before.exists():
        assert outputs == json.loads(before.read_bytes()), 'protected inputs changed'
    return outputs


if __name__ == '__main__':
    result = check()
    destination = HERE / sys.argv[1]
    assert destination.parent == HERE and not destination.exists()
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, sort_keys=True))
