"""Copy only SHA-verified rejected fixed-trace inputs; never run old finalizers."""
import json
from pathlib import Path
from a2_corrector_guard import AUTHOR, REVIEW, ROOT, HERE, checked_json, info, check

check()
manifest = checked_json(AUTHOR / 'review-manifest.json', '266772753264b13e0788628c62c196400fa6515ceca5c1555713edff228e3ac9')
review_index = checked_json(REVIEW / 'proof-index.json', 'ea1cf140c393c5426e328833bff087ba52c37b0fcf297fd9ae83dd75ffe3d4d9')
copy_receipts = []


def copy_verified(source, destination, expected):
    assert info(source) == expected, str(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists()
    destination.write_bytes(source.read_bytes())
    assert info(destination) == expected
    copy_receipts.append({'source': str(source), 'destination': str(destination.relative_to(HERE)), **expected})


names = ['a2_trace.py', 'test_a2_trace.py', 'authority.json', 'protocol.json',
         'record-schemas.json', 'trace.json', 'self-check.json', 'methodology.md']
for name in names:
    copy_verified(AUTHOR / name, HERE / 'rejected' / name, manifest['artifact_files'][name])
    copy_verified(AUTHOR / name, HERE / 'candidate' / name, manifest['artifact_files'][name])
for name, expected in [('review-manifest.json', info(AUTHOR / 'review-manifest.json')),
                       ('evidence-index.json', info(AUTHOR / 'evidence-index.json'))]:
    copy_verified(AUTHOR / name, HERE / 'provenance/author' / name, expected)
for name in ['assessment.json', 'assessment.md', 'proof-index.json',
             'test_a2_independent_negatives.py', 'a2_minimal_reproduction.py',
             'targeted-negative-tests/raw.xml', 'targeted-negative-tests/stdout.raw',
             'targeted-negative-tests/stderr.raw', 'targeted-negative-tests/process.json',
             'minimal-reproduction/stdout.raw', 'minimal-reproduction/stderr.raw',
             'minimal-reproduction/process.json', 'targeted-fixtures/binding-route-mismatch.json']:
    expected = review_index['files'].get(name) or json.loads((HERE / 'protected-before.json').read_bytes())['extra_pins'][str(REVIEW / name)]
    copy_verified(REVIEW / name, HERE / 'provenance/review' / name, expected)
for name in ['single-trace-authorization.json', 'single-trace-routing-correction-plan.json',
             'single-trace-failed-review-preservation.json', 'schema-control-contract.md']:
    expected = manifest['repo_files'].get(str((ROOT / name).relative_to(ROOT.parents[3])))
    if expected is None:
        expected = info(ROOT / name)
    copy_verified(ROOT / name, HERE / 'provenance/root' / name, expected)
for name in ['a2_parent_route.py', 'process.json', 'stdout.raw', 'stderr.raw']:
    source = AUTHOR / 'parent-route-reproduction' / name
    expected = json.loads((HERE / 'protected-before.json').read_bytes())['extra_pins'][str(source)]
    copy_verified(source, HERE / 'provenance/parent-reproduction' / name, expected)
(HERE / 'copy-receipts.json').write_text(json.dumps(copy_receipts, indent=2, sort_keys=True) + '\n')
print(json.dumps({'copied_files': len(copy_receipts), 'all_source_hashes_checked_before_copy': True}))
