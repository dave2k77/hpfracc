# FIXED-TRACE-ROUTING-01 correction evidence

This is the third-context corrector's ONE bounded correction cycle, not an
independent review or owner approval. All created files are under this unique
scratch directory. No repository, original author/reviewer file, schema,
allowlist, cap, numerical source, criterion, dependency, Git index or profile was
modified. The parent retains responsibility for fresh review and status updates.

## Source delta

`candidate/a2_trace.py` adds one equality inside the existing three-binding loop:

    need(binding['binding_id'] == 'host-' + suffix, 'binding path-to-ID')

The enclosing lookup already fixes the exact `records/binding-host-{suffix}.json`
path. Schema checking already establishes the ID type. No general parser, new
branch, separate uniqueness condition or invocation/observation uniqueness rule
is added. `candidate/test_a2_trace.py` is byte-identical to the rejected original.
`candidate/test_a2_routing.py` adds six parameters of the same missing-rejection
behavior: shared/candidate-0/candidate-1 crossed with duplicate/fresh wrong IDs.
These are mutations of the one authorized trace, not new request cases.

## Evidence boundaries

- `rejected/` preserves the exact rejected implementation and its original tests,
  fixtures and documentation. `provenance/` preserves the rejected verdict, raw
  reviewer failure, parent reproduction and authority handles. Existing original
  archives remain at their pinned repository bytes.
- `red-routing/`, `green-routing/`, `isolated-tests/`, `isolated-replay/` and
  `missing-artifact/` contain pre-run `before/` source snapshots, command plans,
  raw child stdout/stderr and actual exits. Pytest results include raw JUnit and
  parsed exact identities. The capture helper executes the snapshot, not a live
  source file. Capture-wrapper exit 0 is not substituted for child exit 1.
- Every route regression asserts the intended field change, unchanged other
  binding fields and payloads, rebuilt digest/inline/index/export/manifest links,
  root-schema validity and independently replayed valid byte ledger BEFORE the
  verifier. All six original-source failures are `DID NOT RAISE`, not setup/hash
  failures. Original 20 tests remain passing during RED.
- Portable replay compares rebuilt canonical bytes to the actual preserved
  original trace, not only hardcoded ledger values; all 38 emitted artifact byte
  strings match. A Python open audit hook rejects original author/reviewer and
  repository source/data reads during that portable process. This is not an OS
  sandbox, worker observation or security attestation.
- The missing-artifact control omits only copied `trace.json`; the same portable
  executable refuses with FileNotFoundError and actual child exit 1.
- `candidate/self-check.json` and `candidate/methodology.md` are unchanged original
  historical author artifacts, NOT updated corrector completion receipts. Use
  `correction-report.json` for this correction's current results.

## Preliminary guard-harness failures

Two setup-only guard invocations failed before any audit edit or RED run: the
baseline's numerical pins are SHA strings rather than size/hash objects, and
its Git-stage pin hashes newline output, not `-z` output. Both source versions
and terminal-result transcriptions are retained under `guard-attempt-01/02`.
These two first invocations did not have pre-run capture or separately captured
raw child streams; do not relabel later matching source copies as pre-run
snapshots. Their exact unchanged helpers were subsequently replayed under
`guard-failure-reproduction-01/02`, with actual raw streams and exit 1, labelled
reproductions rather than original observations. The attempt-02 JSON output is
a transcription (quote spelling differs from terminal display), not a byte-exact
raw-stream claim. Both guard defects concern capture metadata representation,
not protected-source drift or the trace acceptance criteria. Successful full
protected before/after checks use the original pin representations.

## Limits

The command, PID, clocks, ownership and operation/bit fields inside the trace
remain STATIC/HYPOTHETICAL illustrative fields, not observations of these real
self-check processes. One corrected static trace does not establish broader
resource sufficiency, operational validation, scientific accuracy, AD/FD/JAX,
FIT-REAL, fitter/worker/selector implementation or A2/Phase A completion.
All independent-review, A2-acceptance, implementation-authorization,
protocol-freeze and broader-accounting flags remain false. No second correction
cycle or bulk restart is authorized here.

## Index convention

`proof-index.json` covers all proof files, including raw failures, per-run source
snapshots, generated route mutants and reports. Symlinks are indexed as readlink
bytes, never followed. It excludes itself and `proof-index-verification.json`
to avoid self-reference, and excludes only the runtime `uv-cache/` directory.
The verification receipt is bound by the finalizer's real tool exit/output, not
falsely included in its own hash. Hash consistency is not independent approval.
