"""Capture actual child exits; execute the immutable per-run source copy."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
REPO = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')


def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, obj):
    assert not path.exists(), str(path)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')


def run(phase, source, mode, arguments):
    target = HERE / phase
    assert target.parent == HERE
    target.mkdir()
    before = target / 'before'
    before.mkdir()
    pins = {}
    for path in sorted(source.iterdir()):
        if path.is_file():
            assert not path.is_symlink()
            expected = pin(path)
            raw = path.read_bytes()
            assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256']
            copied = before / path.name
            copied.write_bytes(raw)
            assert pin(copied) == expected
            pins[path.name] = expected
    env = dict(os.environ, UV_OFFLINE='1', UV_CACHE_DIR=str(HERE / 'uv-cache'),
               PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',
               TMPDIR=str(target / 'tmp'), GIT_OPTIONAL_LOCKS='0')
    Path(env['TMPDIR']).mkdir()
    cmd = ['uv', 'run', '--project', str(REPO), '--frozen', '--no-sync', 'python', '-B']
    if mode == 'pytest':
        cmd += ['-m', 'pytest', '-q', '-c', '/dev/null', '--rootdir', str(before),
                '-p', 'no:cacheprovider', '--basetemp', str(target / 'pytest-temp'),
                '--junitxml', str(target / 'raw.xml')]
        cmd += [str(before / name) for name in arguments]
    else:
        assert mode == 'script'
        cmd += [str(before / arguments[0]), *arguments[1:]]
    plan = {'command': cmd, 'cwd': str(before), 'source': str(source),
            'executed_source_snapshots': pins, 'network_disabled_by_uv_offline': True,
            'hypothetical_trace_fields_are_actual_observations': False}
    save(target / 'plan.json', plan)
    started = time.monotonic_ns()
    process = subprocess.run(cmd, cwd=before, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
    finished = time.monotonic_ns()
    (target / 'stdout.raw').write_bytes(process.stdout)
    (target / 'stderr.raw').write_bytes(process.stderr)
    assert {p.name: pin(p) for p in before.iterdir() if p.name in pins} == pins
    result = {'command': cmd, 'actual_child_exit': process.returncode,
              'start_monotonic_ns': started, 'end_monotonic_ns': finished,
              'source_snapshots_unchanged': True,
              'stdout': pin(target / 'stdout.raw'), 'stderr': pin(target / 'stderr.raw')}
    xml = target / 'raw.xml'
    if xml.exists():
        root = ET.parse(xml).getroot()
        cases = list(root.iter('testcase'))
        result['xml'] = pin(xml)
        result['counts'] = {'tests': len(cases), 'failures': sum(c.find('failure') is not None for c in cases),
                            'errors': sum(c.find('error') is not None for c in cases),
                            'skipped': sum(c.find('skipped') is not None for c in cases)}
        result['counts']['passed'] = len(cases) - sum(result['counts'][k] for k in ('failures', 'errors', 'skipped'))
        result['testcases'] = [{'classname': c.get('classname'), 'name': c.get('name'),
                               'failure': None if c.find('failure') is None else c.find('failure').get('message')}
                              for c in cases]
        suites = list(root.iter('testsuite'))
        assert int(suites[0].get('tests')) == len(cases)
        for key in ('failures', 'errors', 'skipped'):
            assert int(suites[0].get(key)) == result['counts'][key]
    save(target / 'process.json', result)
    print(json.dumps(result, sort_keys=True))
    return result


if __name__ == '__main__':
    run(sys.argv[1], Path(sys.argv[2]), sys.argv[3], sys.argv[4:])
