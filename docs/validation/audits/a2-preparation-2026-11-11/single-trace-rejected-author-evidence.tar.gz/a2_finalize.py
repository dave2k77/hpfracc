"""Generate and verify the fixed-trace artifact, actual checks and frozen inputs."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
REPO = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def guard():
    baseline = json.loads((HERE / 'baseline.json').read_text())
    for name, expected in baseline['numerical_inputs'].items():
        assert sha((REPO / name).read_bytes()) == expected, name
    for group in ['packet_before', 'history']:
        for name, expected in baseline[group].items():
            raw = (REPO / name).read_bytes()
            assert sha(raw) == expected['sha256'] and len(raw) == expected['bytes'], name
    assert sha((REPO / '.git/index').read_bytes()) == baseline['index_sha256']
    assert sha(subprocess.check_output(['git', 'ls-files', '--stage'], cwd=REPO)) == baseline['stage_sha256']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip() == baseline['head']
    return {'packet_files': 9, 'numerical_inputs': 125, 'historical_files': len(baseline['history']),
            'index_and_head_unchanged': True}


if __name__ == '__main__':
    before = guard()
    spec = importlib.util.spec_from_file_location('one_fixed_audit', HERE / 'a2_trace.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    trace = audit.make_trace()
    report = audit.verify_trace(trace)
    (HERE / 'trace.json').write_text(json.dumps(trace, indent=2) + '\n')
    table = {path: {'bytes': len(audit.canonical(value)), 'sha256': sha(audit.canonical(value)),
                    'nodes': audit.metrics(value)[0], 'depth': audit.metrics(value)[1]}
             for path, value in trace['records'].items()}
    (HERE / 'record-sizes.json').write_text(json.dumps(table, indent=2, sort_keys=True) + '\n')
    stages = []
    for number in range(1, 8):
        red = HERE / f'red-{number:02d}'
        green = HERE / f'green-{number:02d}'
        r = ET.parse(red / 'raw.xml')
        g = ET.parse(green / 'raw.xml')
        red_exit = json.loads((red / 'process.json').read_text())['child_exit']
        green_exit = json.loads((green / 'process.json').read_text())['child_exit']
        assert red_exit == 1 and green_exit == 0
        assert not r.findall('.//error') and not g.findall('.//error') and not g.findall('.//failure')
        failures = len(r.findall('.//failure'))
        assert failures == len(r.findall('.//testcase'))
        stages.append({'stage': number, 'red_failures': failures, 'red_exit': red_exit,
                       'green_cases': len(g.findall('.//testcase')), 'green_exit': green_exit,
                       'first_red_scope': 'collected absent-module check; later tests exercise behavior' if number == 1 else 'actual semantic/arithmetic rejection missing'})
    assert sum(x['red_failures'] for x in stages) == 20
    assert stages[-1]['green_cases'] == 20
    (HERE / 'vertical-red-green.json').write_text(json.dumps(stages, indent=2) + '\n')
    report |= {
        'scope': 'ONE labelled static conditional metadata trace and concrete byte ledger; self-check only',
        'single_trace_self_check_passed': True, 'independent_review_passed': False,
        'fixed_case_count': 1, 'record_count': len(trace['records']),
        'final_files': len(audit.raw_files(trace)), 'index_generations': 2,
        'max_record_nodes': max(v['nodes'] for v in table.values()),
        'max_record_depth': max(v['depth'] for v in table.values()),
        'tdd_cases': 20, 'vertical_stages': stages,
        'guards': guard(), 'caps_changed': False, 'coverage_expanded': False,
        'worker_executed': False, 'operation_counter_runtime_verified': False,
        'timing_or_security_runtime_verified': False,
        'hypothetical_packet_digest_is_current_packet': False,
        'broader_accounting_proved': False, 'protocol_freeze_authorized': False,
        'arithmetic_verified': False, 'total_numerical_certified': False,
    }
    assert report['guards'] == before
    (HERE / 'self-check.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps(report, indent=2))
