"""Freeze one fixed-case audit and verify every declared artifact before review."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
EXCLUDE = {'evidence-index.json', 'evidence-index-verification.json', 'review-manifest.json'}
EXCLUDE_DIRS = {'pytest-temp', 'temp', 'missing-temp', 'baseline-docs-temp', 'qa-site'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


if __name__ == '__main__':
    files = {}
    for path in sorted(HERE.rglob('*')):
        relative = path.relative_to(HERE)
        if any(part in EXCLUDE_DIRS for part in relative.parts) or 'telegram' in path.name:
            continue
        assert not path.is_symlink(), path
        if path.is_file() and relative.as_posix() not in EXCLUDE:
            raw = path.read_bytes()
            files[relative.as_posix()] = {'bytes': len(raw), 'sha256': sha(raw)}
    index = {'scope': 'One fixed STATIC/HYPOTHETICAL metadata trace; no broader accounting or execution approval',
             'files': files, 'excluded_exact_files': sorted(EXCLUDE),
             'excluded_directories': sorted(EXCLUDE_DIRS), 'private_telegram_receipts_excluded': True}
    path = HERE / 'evidence-index.json'
    assert not path.exists()
    path.write_text(json.dumps(index, indent=2, sort_keys=True) + '\n')
    for name, metadata in files.items():
        raw = (HERE / name).read_bytes()
        assert len(raw) == metadata['bytes'] and sha(raw) == metadata['sha256']
    verification = {'files_verified': len(files), 'bytes_verified': sum(x['bytes'] for x in files.values()),
                    'index_sha256': sha(path.read_bytes()), 'verification_passed': True,
                    'scope': 'Readback integrity, not independent semantic approval'}
    (HERE / 'evidence-index-verification.json').write_text(json.dumps(verification, indent=2) + '\n')
    baseline = json.loads((HERE / 'baseline.json').read_text())
    protected = dict(baseline['history']) | dict(baseline['packet_before'])
    protected |= {name: {'sha256': digest, 'bytes': (REPO / name).stat().st_size}
                  for name, digest in baseline['numerical_inputs'].items()}
    manifest = {'scope': 'Independent review of ONE fixed conditional trace, not all A2 acceptance or production execution',
                'artifact_index_sha256': sha(path.read_bytes()), 'artifact_files': files,
                'repo_files': protected, 'head': baseline['head'],
                'index_sha256': baseline['index_sha256'], 'stage_sha256': baseline['stage_sha256'],
                'allowed_parent_status_paths': baseline['parent_status_paths'],
                'allowed_writes': 'Reviewer new unique scratch only; parent status records and new evidence archives permitted',
                'single_case': 'REF-PASS-f64-GL', 'cap_changes_authorized': False,
                'implementation_authorized': False, 'protocol_freeze_authorized': False}
    (HERE / 'review-manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    print(json.dumps(verification))
    print('review_manifest_sha256', sha((HERE / 'review-manifest.json').read_bytes()))
