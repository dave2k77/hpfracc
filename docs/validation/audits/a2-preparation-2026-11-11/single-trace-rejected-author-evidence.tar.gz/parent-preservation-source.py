"""Verify and preserve the rejected fixed-case review before any bounded correction."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
REVIEW = HERE.parent / 'a2-independent-fixed-review-kgblph4j'
ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def checked(base, name, meta=None):
    relative = PurePosixPath(name)
    assert not relative.is_absolute() and '..' not in relative.parts
    path = base / name
    assert path.resolve().is_relative_to(base.resolve()) and not path.is_symlink()
    raw = path.read_bytes()
    if meta is not None:
        assert len(raw) == meta['bytes'] and sha(raw) == meta['sha256'], name
    return raw


def verify_pins():
    manifest = json.loads((HERE / 'review-manifest.json').read_text())
    assert sha((HERE / 'review-manifest.json').read_bytes()) == '266772753264b13e0788628c62c196400fa6515ceca5c1555713edff228e3ac9'
    for name, meta in manifest['repo_files'].items():
        checked(ROOT, name, meta)
    assert sha((ROOT / '.git/index').read_bytes()) == manifest['index_sha256']
    assert sha(subprocess.check_output(['git', 'ls-files', '--stage'], cwd=ROOT)) == manifest['stage_sha256']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == manifest['head']
    return len(manifest['repo_files'])


def archive(name, files):
    target = OUT / name
    assert not target.exists(), target
    with tarfile.open(target, 'w:gz') as tar:
        for member_name, raw in sorted(files.items()):
            info = tarfile.TarInfo(member_name)
            info.size = len(raw)
            info.mode = 0o644
            info.mtime = 0
            tar.addfile(info, io.BytesIO(raw))
    with tarfile.open(target, 'r:gz') as tar:
        members = tar.getmembers()
        assert len(members) == len(files) and len({m.name for m in members}) == len(files)
        for member in members:
            assert member.isfile() and member.name in files
            actual = tar.extractfile(member).read()
            assert actual == files[member.name]
    raw = target.read_bytes()
    return {'path': str(target.relative_to(ROOT)), 'members_verified': len(files),
            'bytes': len(raw), 'sha256': sha(raw), 'all_member_bytes_verified': True}


if __name__ == '__main__':
    pins = verify_pins()
    author_index = json.loads((HERE / 'evidence-index.json').read_text())
    assert sha((HERE / 'evidence-index.json').read_bytes()) == 'be5a1ba950860abbf66b849fdc5a057c75b6bafbe064ea21635e26a60633aa07'
    author_files = {name: checked(HERE, name, meta) for name, meta in author_index['files'].items()}
    assert len(author_files) == 210 and sum(map(len, author_files.values())) == 5388615
    for name in ['evidence-index.json', 'evidence-index-verification.json', 'review-manifest.json']:
        author_files[name] = checked(HERE, name)
    review_index_raw = checked(REVIEW, 'proof-index.json')
    assert sha(review_index_raw) == 'ea1cf140c393c5426e328833bff087ba52c37b0fcf297fd9ae83dd75ffe3d4d9'
    review_index = json.loads(review_index_raw)
    review_files = {name: checked(REVIEW, name, meta) for name, meta in review_index['files'].items()}
    final_raw = checked(REVIEW, 'final-pins.json')
    assert sha(final_raw) == 'f608c629ff8ad5fb4f2c7bbfe9ecddc5016241048a77a0e3e9acccfad954ed1c'
    final = json.loads(final_raw)
    for name, key in [('assessment.json', 'assessment_json'), ('assessment.md', 'assessment_markdown'),
                      ('proof-index.json', 'proof_index'), ('proof-index-verification.json', 'proof_index_verification')]:
        review_files[name] = checked(REVIEW, name, final[key])
    review_files['final-pins.json'] = final_raw
    assert len(review_index['files']) == final['proof_files_verified'] == 452
    assert sum(len(review_files[n]) for n in review_index['files']) == final['proof_bytes_verified'] == 15627201
    verdict = json.loads(review_files['assessment.json'])
    assert verdict['passed'] is False and not verdict['security_concerns']
    assert [x['id'] for x in verdict['logic_errors']] == ['FIXED-TRACE-ROUTING-01']
    xml = ET.fromstring(review_files['targeted-negative-tests/raw.xml'])
    rows = xml.findall('.//testcase')
    failures = [r for r in rows if r.find('failure') is not None]
    assert len(rows) == 23 and len(failures) == 1 and not xml.findall('.//error')
    assert failures[0].attrib['name'] == 'test_binding_filename_must_match_its_declared_binding_id'
    assert json.loads(review_files['targeted-negative-tests/process.json'])['child_exit'] == 1
    # Parent's new, independently launched reproduction runs only already-pinned code.
    replay = HERE / 'parent-route-reproduction'
    replay.mkdir()
    script = """import importlib.util,json
from pathlib import Path
base=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('fixed_audit',base/'a2_trace.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
t=a.make_trace(lambda r:r['records/binding-host-0.json'].update(binding_id='host-1'))
a.verify_trace(t)
actual='records/binding-host-0.json'
required='records/binding-'+t['records'][actual]['binding_id']+'.json'
print(json.dumps({'checker_accepted':True,'actual_path':actual,'required_path':required}),flush=True)
assert actual==required,'fixed audit accepts a path-to-binding-ID routing violation'
"""
    (replay / 'a2_parent_route.py').write_text(script)
    cmd = ['uv', 'run', '--frozen', '--no-sync', 'python', '-B', str(replay / 'a2_parent_route.py')]
    result = subprocess.run(cmd, cwd=ROOT, capture_output=True)
    (replay / 'stdout.raw').write_bytes(result.stdout)
    (replay / 'stderr.raw').write_bytes(result.stderr)
    receipt = {'command': cmd, 'child_exit': result.returncode,
               'scope': 'New parent reproduction of rejected frozen checker; not a repair or numerical run'}
    (replay / 'process.json').write_text(json.dumps(receipt, indent=2) + '\n')
    assert result.returncode == 1 and json.loads(result.stdout)['checker_accepted'] is True
    for path in replay.iterdir():
        author_files['parent-route-reproduction/' + path.name] = path.read_bytes()
    author_files['parent-preservation-source.py'] = Path(__file__).read_bytes()
    for name in ['docs/developer/phase-a-completion.md', 'docs/developer/bug-resolution-tracker.md']:
        author_files['parent-pre-status/' + Path(name).name] = (ROOT / name).read_bytes()
    author_archive = archive('single-trace-rejected-author-evidence.tar.gz', author_files)
    review_archive = archive('single-trace-independent-review-failed-evidence.tar.gz', review_files)
    for name, target in [('assessment.json', 'single-trace-independent-review-failed.json'),
                         ('assessment.md', 'single-trace-independent-review-failed.md')]:
        destination = OUT / target
        assert not destination.exists()
        destination.write_bytes(review_files[name])
    assert verify_pins() == pins
    preservation = {'status': 'Rejected fixed-case checker preserved before any correction',
                    'passed': False, 'protected_repo_files_verified': pins,
                    'original_author_indexed_files_verified': 210, 'original_author_bytes_verified': 5388615,
                    'review_indexed_files_verified': 452, 'review_indexed_bytes_verified': 15627201,
                    'review_assessment_sha256': sha(review_files['assessment.json']),
                    'review_index_sha256': sha(review_index_raw),
                    'review_targeted': {'tests': 23, 'passed': 22, 'failed': 1, 'errors': 0, 'actual_exit': 1},
                    'parent_reproduction_actual_exit': result.returncode,
                    'archives': [author_archive, review_archive],
                    'private_telegram_receipts_excluded': True,
                    'caps_changed': False, 'source_repaired': False, 'a2_acceptance_passed': False,
                    'implementation_authorized': False, 'protocol_freeze_authorized': False}
    (OUT / 'single-trace-failed-review-preservation.json').write_text(json.dumps(preservation, indent=2) + '\n')
    print(json.dumps(preservation, indent=2))
