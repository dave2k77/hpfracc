from pathlib import Path
import hashlib,json,subprocess,shutil
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
S=Path(__file__).parent
H=lambda b:hashlib.sha256(b).hexdigest()
pin=Path('/home/davianc/.hermes/cache/scratch/a2-preparation-20261111/preparation-inputs.json')
p=json.loads(pin.read_text()); mismatches=[]
for name,digest in p['baseline_numeric_inputs'].items():
    if H((R/name).read_bytes())!=digest: mismatches.append(name)
idx=subprocess.check_output(['git','ls-files','--stage'],cwd=R)
assert not mismatches,mismatches
assert H(idx)==p['index_entries_sha256']
assert len(p['baseline_numeric_inputs'])==125
(S/'index-before.raw').write_bytes(idx)
(S/'preparation-inputs.raw.json').write_bytes(pin.read_bytes())
protocol=R/'docs/developer/a2-compression-budget-protocol.md'
assert H(protocol.read_bytes())==p['protocol_sha256']
(S/'protocol-before.raw.md').write_bytes(protocol.read_bytes())
A=R/'docs/validation/audits/a2-preparation-2026-11-11'
old={str(f.relative_to(R)):{'sha256':H(f.read_bytes()),'bytes':f.stat().st_size} for f in A.iterdir() if f.is_file()}
assert H((A/'initial-contract-reviews-failed.tar.gz').read_bytes())=='3b6b397ce0c92efe726360623e3860f8e5c5c8850be11dca0fe129864c3225fb'
for src,digest in [('/home/davianc/.hermes/cache/scratch/a2-math-contract-review-hz4u9cds/verdict.json','c4417b0131acaf5949dc178241b267f712d25a7ceacf92643ee59b5958aad95e'),('/home/davianc/.hermes/cache/scratch/a2-validation-resource-provenance-review-20261111/review-verdict.json','7c4b79fc8468584b01b27dd7fdcf108daa5343af5b81ee1f460173cda1b65885')]:
    assert H(Path(src).read_bytes())==digest
(S/'before.json').write_text(json.dumps({'command':'uv run --locked --no-sync python -B '+str(Path(__file__)),'numeric_inputs_verified':125,'index_sha256':H(idx),'protocol_sha256':H(protocol.read_bytes()),'preserved_existing_files':old,'status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'implementation_authorized':False,'a2_acceptance_passed':False},indent=2)+'\n')
print(json.dumps({'numeric_inputs_verified':125,'index_matched':True,'old_protocol_matched':True,'preserved_files':len(old)}))
