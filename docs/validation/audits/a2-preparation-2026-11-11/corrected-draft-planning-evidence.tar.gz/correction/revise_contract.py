from pathlib import Path
import json
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');S=Path(__file__).parent;A=R/'docs/validation/audits/a2-preparation-2026-11-11'
old=(S/'protocol-before.raw.md').read_text();math_section=old.split('## 4. Exact finite mathematical contract')[1].split('## 5. Identity')[0]
intro='''# A2 compression-budget tracer: preparation contract

Status: **corrected DRAFT, pending independent re-review and owner approval;
implementation not authorized; A2 acceptance false**. This is preparation only.
Baseline: `a3951bde6a633f22ee2c1e006ea78c62421f599b`.
Protocol ID: `a2-glrl-exact-reference-v1-draft`. The closed constants below are
predeclared proposals for re-review, not an approved implementation freeze.

The original failed reviews and reviewed draft remain immutable in
[the failed-review preservation record](../validation/audits/a2-preparation-2026-11-11/initial-contract-reviews-preservation.json)
and its archived bytes. They have **not** been relabeled as passing. The exact
finite mathematics in section 4 is unchanged. This revision addresses
DECISION-01/02/03, B1/B2/B3/B4 and the known Markdown anchor only.

## 1. Purpose and unchanged acceptance boundary

Prepare one private, CPU-first tracer: independent exact finite compression
assessment, exhaustive evaluation of supplied candidates and deterministic
minimum configured-pole/ID ranking. There is no selector, validator or numerical
worker implementation in this preparation. Proposed later files remain
`benchmarks/numerical/_compression_budget.py` and
`tests/unit/test_compression_budget.py`; this document does not authorize them.

The [A2 programme](phase-a-completion.md#a2-history-approximation-and-memory-open)
remains authoritative. This tiny diagnostic is not an alternative acceptance
scope. A1/A2/A3/A4, scientific certification, Phase A completion, broader
improving-fit refinement and measured CPU/CUDA forward/reverse peak memory remain
open. Per-state solver scope and Phase B questions remain unanswered. SCI-003
and the private trajectory-defect helper are not reference oracles for this work.
Full-history defaults, public APIs, lazy JAX imports, JAX as sole runtime
dependency, fitting/application code and global precision policies are unchanged.
Research software only; no clinical or diagnostic claim.

## 2. Closed, portable preparation packet

All support lives under
`docs/validation/audits/a2-preparation-2026-11-11/`:

- [protocol.json](../validation/audits/a2-preparation-2026-11-11/protocol.json):
  scope, ordered status precedence, exact candidate identity, caps and accounting;
  includes the 125 pinned numerical-input identities and index-entry digest.
- [fixtures.json](../validation/audits/a2-preparation-2026-11-11/fixtures.json):
  exact case IDs, raw input/fit IEEE hex, dtype/shape/layout/hash, configuration,
  ordered candidates, reduced rational budgets, declarative negative mutations,
  expected outcome roles and complete future evidence/comparison inventories.
- [comparison-policies.json](../validation/audits/a2-preparation-2026-11-11/comparison-policies.json):
  every working comparison operand, reference, dtype, shape and tolerance;
  objectives, scalar-order handling and all predeclared FD steps.
- [record-schemas.json](../validation/audits/a2-preparation-2026-11-11/record-schemas.json):
  closed required-key/type/enum record definitions **plus the mandatory canonical
  parse and semantic predicates**. JSON Schema alone is insufficient.
- [packet-notes.md](../validation/audits/a2-preparation-2026-11-11/packet-notes.md):
  case expansion, evidence binding, resource-control and replay requirements.
- [packet-manifest.json](../validation/audits/a2-preparation-2026-11-11/packet-manifest.json):
  final path/byte/SHA-256 identities, external to every file it hashes; it does
  not hash itself. No self-referential hash is required.

Packet paths are relative to this audit directory unless explicitly named
`repo_path`, which is relative to the repository root. No scratch executable,
absolute workstation path or original review directory is a replay dependency.
The packet is static input/specification, not an observation or a shipped replay
CLI. A portable implementation and tamper-tested semantic replay remain future
gates after separate authorization. If prose and packet disagree, stop and
re-review; do not choose the more permissive interpretation.

## 3. Initial reference domain and proposed resource limits

Exactly scalar alpha=1/2, uniform dt=1/4, lower terminal zero, zero GL/RL
prehistory; GL and its current RL alias use the same finite reference. Shapes are
(N,) or (N,M), 1<=N<=17, 1<=M<=3, actual float32/float64 values decoded exactly.
No decimal-intent substitution. The 204 EXACT-GRID cases cover every N/M pair in
both dtypes and aliases; scalar signals and the explicit stacked case are also
frozen. This is not a continuous-operator accuracy claim at the initial sample.

Eligible candidates have method `scaled_tail`, kernel `gl_prefix`, genuine bool
`exact_head=True`, matching N/order/dt and complete authenticated producer
binding, 1..8 poles, one-dimensional equally sized finite c/rho arrays, c>=0,
0<rho<=1. The existing `_SOEFit` does **not** store alpha/dt/t_max; capture the
source-bound producer call rather than infer those fields from that record.
Actual-fit calls use `_fit_soe(alpha,17,n_poles=p,t_max=1,kernel="gl",
method="scaled_tail")`, unchanged 400 updates and dimensionless rate grid.
`scaled_tail` does not use t_max as an independent accuracy control; preserve it
as supplied configuration, not an attainability parameter.

| Proposed per-request limit | Value |
| --- | --- |
| Supplied candidates / configured poles per candidate | 8 / 8 |
| Exact rational primitives, cumulative | 100,000 |
| Normalized numerator or denominator | 32,768 bits |
| All serialized per-request evidence, including raw inputs and failure index | 16 MiB |
| Worker wall watchdog, launch through confirmed exit | 60 seconds |
| Pre-work input bundle / separate failure-index reservation | 256 KiB / 512 KiB |
| Individual raw array / tau numerator or denominator | 4 KiB / 256 bits |
| ID / ordinary ASCII metadata string | 64 / 256 bytes |
| Inventory envelope / source entries / evidence slots per request | 32 / 125 / 2,048 |
| JSON depth / node count / each stdout or stderr capture | 16 / 32,768 / 16 KiB |

All are **proposed diagnostic caps**, not measured feasibility, global numerical
accuracy, memory-complexity or peak-memory guarantees. Beyond the tiny finite
reference domain is `unsupported_reference`, not a mathematically invalid
problem or changed public support. Empty candidate list is invalid; 9..32
inventoried candidates or >8 poles are unsupported assessments. Inputs beyond
bounded transport/inventory are `input_envelope_exceeded`/indeterminate, with a
bounded failure receipt; do not promise unlimited raw-byte/ID retention for an
unadmitted malicious envelope. For every admitted case, persist all supplied IDs
and its complete slot inventory **before arithmetic**.

Count each exact rational add/subtract/multiply/divide/abs/comparison as one,
including shared reference setup, every candidate, signed/prefix/residual
cross-checks, all qualification comparisons and analytic gradient/transpose
work. Repeated pole powers are charged multiplications; no hidden uncharged
power/dot/sum. Integer work in the independent binomial cross-check is charged
likewise. Validate operand bits before work and normalized result bits after;
normalization/GCD and transient integer products are not covered by a primitive
count (a product can reach twice the operand bit cap). Parsing/decoding/hashing/
serialization are wall/byte bounded, not rational primitives. Shared results may
be reused free only if no new arithmetic occurs. Mode-specific exact arrays and
any rerun charge the same cumulative request counter.

The byte limit includes **all files** produced for the request: input/fit/working
and exact arrays, descriptors, metadata, hashes/manifests, commands, bounded
logs, partial files and the reserved failure index, including whitespace and
newlines. Referenced frozen packet/source bytes need not be copied; any copies
are charged. Precheck each bounded serialized result before committing it.
Never hide required arrays or omit charged files to fit a cap.

## 4. Exact finite mathematical contract'''
rest='''## 5. Explicit decision precedence and identity

### DECISION-01: ownership and precedence

1. Global request syntax/type/tau errors and duplicate IDs or complete content
   make the request `invalid_request` (no selected ID). Retain all observable
   reasons. Genuine canonical fields reject bool/float integer lookalikes and
   integer boolean lookalikes; candidate-local malformed fields are isolated as
   candidate errors, not silently coerced into the global envelope.
2. A well-formed unsupported REQUEST (e.g. order 1/3, nonuniform, Caputo or
   complex input, N/M outside the tiny domain) makes the whole request
   `indeterminate/unsupported_reference`.
3. In a supported request, authenticated provided candidate bytes with known
   L1/kernel/method/head/N/order/dt/producer mismatch, malformed shapes/types,
   nonfinite c/rho, negative c or invalid rho are `known_ineligible`. They do not
   turn a valid GL request into an unsupported request. Continue the other
   candidates. Eligibility checks still run for zero signals and singletons.
4. MISSING/CORRUPT raw artifacts, failed claimed byte digest/length, unavailable
   producer binding, unsupported assessment, exhausted resources or incomplete
   required evidence are `unknown`; the whole request is `indeterminate` even
   after another qualifier. A supplied authenticated NaN is a known bad fit;
   an unreadable file is **not** evidence of a bad numeric fit. An explicitly
   supplied malformed array shape is known-ineligible, not a missing artifact.
   Known producer/config incompatibility differs from missing/corrupt producer
   provenance. Request input artifact integrity failure is globally unknown.
5. Only after every required assessment is known, select minimum
   `(pole_count, stable_id)` among eligible qualifiers. Otherwise return
   `selected_id=null` and `no_supplied_candidate_meets_bound`. This does not mean
   no fit can meet the budget; bound rejection need not imply actual-error
   failure. No fallback, first-success or monotone-fit-quality assumption.

### DECISION-02: canonical content identity

IDs match ASCII `^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$`, case-sensitive unsigned-byte
lexical order, at most 64 bytes. No Unicode/locale normalization. Equal IDs OR
equal **ID-free** content tuples invalidate the request, including identical
content renamed under different IDs. Same pole count alone is not a duplicate.

The ordered tuple is `(configuration, producer, rhos_descriptor,
coefficients_descriptor)` with every nested field fixed in `protocol.json`.
Configuration includes N/P/kernel/method/exact_head/alpha/dt/t_max/grid/lower
terminal/prehistory. Producer includes kind, entrypoint, source repo path/hash,
lock/policy, iterations/grid, backend, working dtype, x64, JAX version, device
class and mode. Each array descriptor includes dtype, exact shape, byte order,
C layout, byte count and verified SHA-256 of raw bytes. Tuple JSON has sorted
object keys, compact separators and canonical types. Explicitly excluded:
stable/case/request/observation/run IDs, PID/times/elapsed/command/exit/hostname,
artifact location and logs; no other untyped provenance or extra metadata exists.
Do not normalize signed zero, pole permutations, zero coefficients or equivalent
kernels. Missing content cannot be hashed into a guessed identity: it is unknown.

### DECISION-03: mandatory EXHAUSTIVE policy, not a theorem of uncertainty

Any unknown assessment makes the result indeterminate whether its rank is lower
**or higher** than a known qualifier. A known lower minimum cannot mathematically
be displaced by an unknown strictly higher rank. The stricter outcome here is
nevertheless mandatory because this tracer requires exhaustive completed
assessment, not because a minimum is universally unknowable. Both rank cases
are frozen fixtures. Pole count is a configured cost proxy, not measured cost.

## 6. Closed fixture matrix and outcome roles (B1)

`fixtures.json` enumerates 544 request cases: 204 EXACT-GRID, 32 FIT-REAL,
28 REF-CAPS, 16 REF-CORE, 148 REF-EDGES, 100 REF-RANK and 16 REF-SIGNAL.
There are 10 separate raw parser controls and 4 identity controls. The static
library contains 832 raw arrays and 160 candidate specs; 12 are future real-fit
producer specs with **no arrays observed**. The packet preinventories 23,168
evidence slots and 1,120 working-comparison slots; no case exceeds 894 evidence
slots. These are planning identities, not executed test/worker counts.

REF-FAIL remains x=(1,1,1), c=rho=(1/2), tau=3/16: epsilon=1/8,
B=(0,1/4,1/4), D=(2,1,3/4), D_hat=(2,1,1/2), no qualifier. REF-PASS adds
c=(1/4,1/4), rho=(1/2,1), exact over three lags; selected only among the supplied
list. Equality tau=1/4 qualifies; tau=1/4-2^-100 does not. Never convert that
comparison to binary64. A distinct one-pole c=1/2,rho=3/4 is also exact over three
lags, so no global pole-minimality claim follows from REF-PASS.

All 24 permutations of the four-candidate rank list are explicit in each
dtype/alias, including same-pole lexical ties, a larger exact candidate and a
bad smaller candidate; separate good-smaller/bad-larger controls reject monotone
quality assumptions. Zero, singleton, changed and stacked signals, missing
intermediate evidence rows, canonical invalid types/tau, duplicate IDs/content,
known incompatibilities, nonfinite provided arrays, missing/corrupt artifacts,
unknown higher/lower rank, outside-domain and controlled resource outcomes are
concrete requests/mutations, not headings awaiting favorable examples.

REF-SIGNAL and FIT-REAL use N=17, ramp k/16, step 1[k>=8], alternating
(-1)^k/8, each separately and stacked (17,3), in **both float32/float64 and
GL/RL**. FIT-REAL has no zero signal. Its supplied order is always poles (8,2,4).
For EACH declared signal/dtype/alias and mode, tau=1 requires at least one real
qualifier; tau=0 requires no qualifier. These are **predeclared preserve-and-stop
gates, not observed or proved attainability**. Do not invent arrays, guess the
winning pole count, change signal, skip cases or retune if contradicted. Preserve
all actual returned candidates and exact assessments first.

The prefix bound is monotone in time per feature: final B alone suffices for the
mathematical threshold. Requiring every intermediate row is an evidence-
completeness rule, not a claim that omitting one necessarily changes selection.
Actual error need not be monotone. Shortcut controls distinguish these facts.

## 7. Working and derivative comparison contract (B2)

All policies are frozen **proposals for re-review**, narrow empirical gates, not
roundoff/gradient bounds or extensions of B. Check every finite component with
exact equal shape/rank, **no broadcasting**:

`abs(a-r) <= atol + rtol*abs(r)`

`a` is the named observed operand and `r` the named reference in
`comparison-policies.json`; rtol never silently uses the other operand. Compare
decoded represented observations to exact rational targets without first
rounding the latter to the worker dtype. M=1 for shape (N,).

| Comparison | float32 rtol / atol | float64 rtol / atol |
| --- | --- | --- |
| Recursive vs own exact D_hat; full vs D; JIT vs eager forward | 2e-5 / 2e-5 | 1e-10 / 6e-10 |
| Input AD vs own analytic exact gradient | 2e-5 / 2e-5 | 2e-7 / 2e-8 |
| JIT vs eager input and order gradients | 2e-5 / 2e-5 | 2e-7 / 2e-8 |
| Input directional AD vs central FD; adjacent FDs | 2e-3 / 2e-4 | 2e-6 / 2e-7 |
| Order AD vs central FD; adjacent FDs | 5e-3 / 5e-4 | 2e-5 / 2e-6 |

Base objective is mean(D_hat squared) over N*M entries. For each mode's actual
base fitted kernel, set g_hat[-1]=0, w_hat[k]=g_hat[k]-g_hat[k-1] and
L_hat[i,j]=2*w_hat[i-j] for j<=i, else zero. The exact input gradient is
`2/(N*M) * L_hat.T @ D_hat`, applied independently to each feature and retained
in input shape. This is the explicit analytic target for **both dtypes**.

Choose q=cos(x_base) once in working dtype, save its raw bytes and hold it fixed
with stop-gradient, including input perturbations. Directional AD is sum(grad*q).
For input derivatives the fit is fixed: each same-mode base/perturbed composition
must return identical actual base fit bytes or stop. For order derivatives,
hold selected configuration fixed but refit at every a. Strong scalar alpha,
dt and h have shape [] in the target dtype; JIT takes alpha dynamically. Recompute
`dt**(-a)` **inside** every differentiated/perturbed objective; 2 is exact only
at base alpha=1/2. Do not freeze coefficients or reselect inside AD/FD.

The source-bound private worker composition is fit -> apply -> scale, returning
its actual rhos/coefficients as auxiliary arrays for EACH eager/JIT/AD/FD
invocation. Base auxiliary arrays used for gradient/reference binding must match
the same-mode base output producer; any mismatch stops. No eager-array borrowing
for JIT, and no claim that a public SOE wrapper has been instrumented. Preserve
branch-specific producer/config/alpha/dt/input/q/h, actual arrays, outputs,
objectives, cotangents, FD values and coefficient-zero patterns.

Float32 h=(1/128,1/256,1/512), all three; float64 h is the actual binary64
encoding of 1e-5 retained in the packet. For each mode, ALL steps must meet the
AD policy and every adjacent pair the corresponding FD policy, using larger-h
FD as reference. Float64 has no adjacent pair: explicitly not applicable.
Fixed-fit input objectives are quadratic, so central FD has **zero real-
arithmetic truncation error**; floating perturbation/evaluation remains.
O(h^2)+O(u/h) is only a sufficiently smooth order-objective heuristic, not a
bound for projected-fit kinks or active-set changes. Final zero-pattern stability
is a limited diagnostic, not evidence that intermediate active sets agree.
Any unstable/nonfinite/nonsmooth/unresolved comparison: preserve and stop,
without tolerance relaxation or scientific acceptance.

Scope x64 off/on outside JIT for float32/float64 workers and restore it. Assert
actual input/alpha/dt/h/q/perturbation/fit/output/objective and both cotangent
dtypes/shapes; a float32 cotangent alone does not establish float32 forward
execution. All host rational work has a separate context from the future JAX
worker. No working stage has been run by this preparation.

## 8. Closed records and bounded partial evidence (B3/B4)

All required typed keys and enums are in `record-schemas.json`, with
`additionalProperties=false`. Its canonical predicate rejects duplicate JSON
keys and NaN/Inf tokens, integer 1.0/true and boolean 0/1 coercion. Nonfinite
provided IEEE bytes remain distinct from nonfinite JSON syntax. Field failure
belongs to its request/candidate ownership boundary; unsupported finite domain
values are not relabeled malformed by a restrictive schema. Raw malformed input
is retained in the bounded input bundle, not coerced into a canonical record.

Rationals are `{num,den}` lowercase hexadecimal strings, no plus/0x/leading
zeros/-0, positive denominator, gcd=1. Zero is uniquely `{num:"0",den:"1"}`.
Check field lengths before conversion (internal 8,192 magnitude hex digits,
plus optional numerator minus), then normalized bits. Tau is finite nonnegative
and capped at 256 bits per part. Raw arrays require dtype, shape, explicit byte
order, C layout, byte count, hex bytes and SHA-256 with exact size relationships.
Every supplied candidate, observation branch, quantity and comparison has a
unique preinventoried slot; missing rows cannot become a completed rejection.
Unavailable slots use null plus explicit unknown/not_evaluated/reason, not zero.
Nonselected or genuinely unused slots use explicit not_applicable and reason.

Before arithmetic, persist the bounded raw input/config/source bundle, all IDs
and slot inventory; initialize the separately reserved failure index. Serialize
results into bounded buffers, check remaining bytes, commit arrays atomically,
then update index. On cap/kill, retain completed arrays and valid partial prefixes
within budget; explicitly inventory missing remainders and ALL unfinished slots.
Do not promise complete exact arrays after exhaustion, unlimited failure logs,
or no-supplied-candidate/minimum results. Keep partial file bytes charged too.

Supervisor wall time starts immediately before process launch and includes
imports/decode/arithmetic/serialization/flush until confirmed exit. At 60s,
terminate, allow separately recorded 1s grace, then kill if needed; timeout is
indeterminate. Failure-index write/kill latency uses its reserved bytes and is
separately recorded, not hidden in a claimed 60s total guarantee. Bounded preflight
input capture is separately timed. Concrete controls set operation cap 0, bit
cap 1, evidence cap 786,432 bytes (only input/index reservations), watchdog 0
with a startup barrier, and an explicit fault checkpoint after candidate 0's
qualifier commit. The last is fault injection, **not** measured exhaustion or
feasibility. No exhaustion protocol has been executed here.

The preserved independent reviews established only their schedules: 612 exact
synthetic Fraction cases/7,344 outputs; a represented-extreme charged schedule
used 55,480 operations with 32,768-bit/16 MiB caps plausible for that schedule.
Neither is a general feasibility certificate. The earlier 136 parent rows are
planning arithmetic, not production results. This revision's own scratch checks
are also preparation only. No measured fit/application/AD or peak-memory result
can be inferred from any of these counts.

## 9. Preparation exit gates and unresolved limits

Independent re-review of this corrected digest and packet is still required,
including empirical-policy sufficiency, closed schemas, byte accounting and
resource controls; then explicit owner approval before implementation. Portable
semantic replay/tamper controls, behavioral RED, numerical workers, all future
FIT-REAL outcomes and working comparisons remain unimplemented/unmeasured.
Documentation checks/build are separate from scientific acceptance.

`implementation_authorized`, `a2_acceptance_passed`, `arithmetic_verified` and
`total_numerical_certified` remain false in the preparation packet. No current
core/public/default/dependency change, full/GPU benchmark, commit/push or closure
of A2/Phase A or unanswered scientific/per-state/Phase B scope is authorized.
'''
new=intro+math_section+rest
assert new.split('## 4. Exact finite mathematical contract')[1].split('## 5. Explicit')[0]==math_section
(R/'docs/developer/a2-compression-budget-protocol.md').write_text(new)
notes='''# A2 corrected preparation packet: reading and replay contract

**Corrected DRAFT; independent re-review and owner approval pending.** Static
planning data only. Implementation authorization and A2/scientific acceptance
remain false. No fixture value is an observed production-fitter output.

## Files, lineage and portable resolution

Read `protocol.json`, `fixtures.json`, `comparison-policies.json` and
`record-schemas.json` together with the
[preparation contract](../../../developer/a2-compression-budget-protocol.md).
All local references resolve from this audit directory, except `repo_path`
which resolves from the repository root. A fixture `_ref` indexes the exact
named library object; no external array is implied. Source hashes cover the
unchanged repository source, not a synthetic-fitter implementation.

`packet-manifest.json` lists exact file byte counts and hashes after edits and
excludes itself. It is a proposed review identity, not an approved freeze or an
execution receipt. Its included protocol/source identities do not authenticate
worker observations. The preserved `initial-contract-reviews-failed.tar.gz` and
`initial-contract-reviews-preservation.json` remain unchanged and failed.
Original review files are accessible from the archive without scratch paths.

## Expansion and explicit expected roles

Each case names actual raw input bytes, shape, dtype and candidate order, exact
rational tau, required comparisons, initial evidence-slot inventory and expected
outcome role. Expand array/candidate refs, then apply ordered declarative
`replace` mutations without coercion. `candidate:i` is supplied-order index;
`request` is global ownership. Mutation `artifact_status=missing/corrupt` withholds
or fails authentication of the referenced bytes deliberately. It does NOT turn
those bytes into an observed malformed numerical fit. A provided raw replacement
has its own frozen bytes/shape/SHA; malformed-shape controls keep deliberately
inconsistent dimensions as authenticated supplied metadata, not silently repair
it. A complex request replacement has interleaved real/imaginary IEEE bytes and
is unsupported by the tiny reference even though structurally decodable.

Negative syntax/type/canonical fixtures deliberately are not valid canonical
record instances; preserve raw request bytes in `input_bundle` and a null parsed
request when needed. A canonical export of an error need not pretend its input
satisfied the success-record schema. Unknown producer bindings are not completed
ineligibility findings; authenticated incompatible producer configuration is.

Every required slot is explicit. Case ID plus slot ID is the unique evidence
key. Full-output reference observations have candidate ID null; they are not
attributed to a selected SOE candidate. For each actual-fit case, BOTH modes
assess all three base candidates. The tau=1 working stage preinventories every
candidate's branches; after base exhaustive selection, unselected AD/FD branches
are explicit not_applicable. Base forward comparisons still apply to ALL
candidates. Tau=0 stops after base no-qualifier gate: no derivative stage is
implied. Full base references remain required for both tau requests.

For every mode/branch, preserve actual returned fit arrays, not copied eager
arrays or a later replay fit. The same source-bound composition must return
fit/output/objective auxiliaries; gradient auxiliaries must bind to that exact
same-mode base producer, or stop. Recompute/refit at perturbed order without
reselection; base strong alpha and dt encodings are frozen in `working_scalars`.
FD h encodings are in `comparison-policies.json`. Direction q is a FUTURE raw
cos(x_base) output, not a synthetic precomputed cos array. Input directional AD
uses fixed saved q, and the analytic directional target uses its decoded bytes.

No observation arrays are provided for the 12 actual-fitter configurations.
All 32 FIT-REAL cases bind nonzero ramp/step/alternating/stacked inputs. Tau=1
qualifier and tau=0 nonqualifier are required future stop gates, not claims of
attainability. A contradiction stops the stage, not a search for a nicer signal.

## Shapes and canonical parse (mandatory, not Schema-only)

Input-shaped quantities: input/v/D/D_hat/error/B/analytic input gradient/output/
full output/input AD/direction. Lag arrays: w/g/g_hat/residual/signed fitted
weights [N]. L_hat [N,N], containing scale 2. Fit arrays/zero-pattern [P]. Scalar
quantities (including alpha/dt/h/objective/order AD/directional AD/FD/epsilon)
have shape []. Exact matrix/vector arrays are flat C-order rational lists with
cardinality equal to shape product. Zero-pattern is exact 0/1 rational data,
not an untyped bool-to-number conversion. A partial time-leading prefix has
shape [K,...] with K<N and status partial; missing [K:N,...] is explicitly
unknown in the index using the expected full shape from this packet. Never
call a missing endpoint or component a complete array.

The canonical parse predicate in `record-schemas.json` is part of this contract:
duplicate keys/nonfinite JSON rejected, type(value) is int or bool as appropriate,
closed keys/enums, bounded parse depth/nodes/strings, reduced hex rationals,
explicit byte order/layout/length/SHA. Schema acceptance of integer 1.0 is not
sufficient. Canonical structure and tiny-domain support are separate: finite
N=18/M=4/P=9/complex requests are unsupported, not invalid mathematical problems.
Candidate-local authenticated malformed fields are known-ineligible; global
request syntax/type/tau/duplicates are invalid; corrupt/missing bytes are UNKNOWN.

Identity tuple excludes stable IDs and volatile receipt/location fields but
includes every declared configuration/producer/source/dtype/shape/byte-order/
layout/byte-count/raw digest field. Signed-zero bytes and pole order are identity
data. Content-equivalent renamed candidates are forbidden duplicates; equal
kernels with distinct bytes/configs remain distinct. Do not silently canonicalize
mathematics into byte identity. Unknown tuples are not guessed.

## Resource controls and bounded evidence

The proposed 8 candidates, 8 poles, 100k exact primitives, 32,768 normalized bits,
16 MiB evidence and 60s watchdog remain diagnostic caps pending review. Pure
exact planning does not measure fitter feasibility or application/AD peak memory.
Counters include shared reference, cross-checks, analytic gradients and all
mode/branch reference arithmetic. Decode/GCD/hash/export costs are wall bounded,
not free unlimited work. The manifest/source SHA fields and raw arrays belong
to byte coverage, including JSON formatting and partial files.

Persist bounded raw input/all admitted IDs plus compact slot inventory before
work, and a separate initialized failure index within the reserved 512 KiB.
The entire input bundle including any raw-request escape copy must fit 256 KiB;
use compact JSON and do not duplicate raw bytes unnecessarily. Oversize envelope
gets a bounded prefix/digest-of-retained-prefix/received-length-if-known failure
receipt, never a falsely labeled full-input digest or promise of unlimited IDs.
No arithmetic begins before successful preflight persistence.

The controlled exhaustion protocol is predeclared, NOT executed:

| IDs (each dtype/alias) | Trigger | Required future receipt |
| --- | --- | --- |
| CAP-ops | rational primitives=0 | first attempted primitive refused; all unknown |
| CAP-bits | normalized bits=1 | normalization of 1/2 exceeds cap; no rejection proof |
| CAP-bytes | evidence=786432 bytes | 256 KiB+512 KiB reservations leave no result allowance |
| CAP-wall | watchdog=0, held startup barrier | supervisor does not release arithmetic; timeout, confirmed exit |
| CAP-after-qualifier | injected fault at candidate-0 commit | retain qualifier; next unknown; whole request indeterminate |

After normal preflight, fault/cap/kill retains each completed array and any
budget-fitting valid prefix. ALL other candidate/quantity slots remain explicit
UNKNOWN/not_evaluated. Atomic temporary files also count toward bytes; failed
large allocations must not evade the byte limit. Supervisor terminates at 60s,
waits separately recorded <=1s grace then kills; complete process confirmation
and failure-index receipt are mandatory. Reservation is not a claim that all
required exact arrays always fit. Never claim no qualifier or a minimum after
an unknown, even if an earlier lower-ranked qualifier is mathematically minimal.

## Semantic replay and limits

A future authorized replay must first validate bounded canonical structure and
source/case/policy/producer/raw-byte relationships, then independently recompute
exact shared identities, signed/prefix/fitted/residual outputs, each B, analytic
input gradient, candidate completeness and rank. Working comparisons use every
named reference/shape/dtype/atol/rtol and all declared FD steps. Only then checksum
completed immutable artifacts and write the external manifest. Missing files,
rebound producer/alpha/dt, swapped eager/JIT fits, duplicate/omitted rows, changed
raw bytes, signed-zero normalization and dropped candidates need explicit tamper
controls. Static schemas/checksums do not implement this replay or authenticate
execution. A portable repository CLI remains a separate implementation gate.

Thresholds are empirical; fixed-fit input FD has zero real truncation while
smooth-order h-squared heuristics do not cover projected-fit kinks. No derivative,
roundoff, continuum, A1/A2/A3/A4, per-state solver or Phase B closure is granted.
'''
assert not (A/'packet-notes.md').exists()
(A/'packet-notes.md').write_text(notes)
print(json.dumps({'math_section_byte_identical':True,'protocol_bytes':len(new.encode()),'notes_bytes':len(notes.encode())}))
