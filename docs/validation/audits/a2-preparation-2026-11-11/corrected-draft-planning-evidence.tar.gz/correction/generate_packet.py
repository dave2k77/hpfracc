"""Static preparation packet generation; no JAX, fitter, selector or worker."""
from pathlib import Path
from fractions import Fraction as F
import copy, hashlib, itertools, json, math, struct
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
S=Path(__file__).parent
A=R/'docs/validation/audits/a2-preparation-2026-11-11'
P='a2-glrl-exact-reference-v1-draft'
H=lambda b:hashlib.sha256(b).hexdigest()
def write(name,obj):
    p=A/name
    assert not p.exists(),str(p)
    p.write_text(json.dumps(obj,indent=2,ensure_ascii=True,allow_nan=False)+'\n')
def rat(x):
    x=F(x)
    return {'num':('-' if x<0 else '')+format(abs(x.numerator),'x'),'den':format(x.denominator,'x')}
def arr(values,dtype,shape):
    raw=b''.join(struct.pack('<'+('f' if dtype=='float32' else 'd'),float(x)) for x in values)
    return {'dtype':dtype,'shape':shape,'byte_order':'little','layout':'C','nbytes':len(raw),'raw_hex':raw.hex(),'sha256':H(raw)}
source={'repo_path':'src/hpfracc/ops/_soe.py','sha256':H((R/'src/hpfracc/ops/_soe.py').read_bytes())}
caps={'candidates':8,'poles':8,'rational_primitives':100000,'normalized_bits':32768,'evidence_bytes':16777216,'wall_seconds':60,'input_bundle_bytes':262144,'failure_index_bytes':524288,'raw_array_bytes':4096,'tau_bits':256,'json_depth':16,'json_nodes':32768,'string_ascii_bytes':256,'id_ascii_bytes':64,'inventory_candidates':32,'source_entries':125,'slots_per_request':2048,'stdout_bytes':16384,'stderr_bytes':16384}
protocol={
 'protocol_id':P,'status':'corrected_draft_pending_independent_re_review_and_owner_approval','implementation_authorized':False,'a2_acceptance_passed':False,'total_numerical_certified':False,'arithmetic_verified':False,
 'domain':{'operators':['GL','RL'],'alpha':rat(F(1,2)),'dt':rat(F(1,4)),'lower_terminal':rat(0),'prehistory':'zero','grid':'uniform','dtypes':['float32','float64'],'shapes':['N','N,M'],'N_min':1,'N_max':17,'M_min':1,'M_max':3},
 'candidate_contract':{'method':'scaled_tail','kernel':'gl_prefix','exact_head':True,'pole_min':1,'pole_max':8,'coefficient_rule':'finite >= 0','rho_rule':'finite 0 < rho <= 1','t_max':rat(1),'rank':['pole_count','stable_id_ascii_byte_lexicographic'],'no_pruning':True},
 'caps_status':'proposed_diagnostic_caps_not_feasibility_certificate','caps':caps,
 'decision_precedence':[
  {'priority':1,'condition':'malformed request envelope, canonical types, tau, duplicate IDs or duplicate complete content','request_status':'invalid_request','selected_id':None},
  {'priority':2,'condition':'well-formed request outside tiny reference domain or resource envelope','request_status':'indeterminate','reason':'unsupported_reference','selected_id':None},
  {'priority':3,'condition':'candidate supplied bytes available and authenticated; known incompatible config, malformed array, nonfinite coefficient/rho or invalid values','candidate_status':'known_ineligible','continue_other_candidates':True},
  {'priority':4,'condition':'missing/corrupt raw artifact, producer binding absent/corrupt, unsupported assessment, incomplete slots or resource exhaustion','candidate_status':'unknown','request_status':'indeterminate','selected_id':None},
  {'priority':5,'condition':'every required assessment completed; at least one known eligible qualifier','request_status':'selected','rule':'minimum (pole_count, stable_id)'},
  {'priority':6,'condition':'every required assessment completed; no known eligible qualifier','request_status':'no_supplied_candidate_meets_bound','selected_id':None}],
 'precedence_notes':[
  'Inventory all observable reasons, even when a higher-priority request disposition applies; incomplete assessment is never a completed rejection.',
  'Known incompatible kernel l1, method legacy, head false, N/order/dt/producer mismatch is candidate-ineligible in a valid GL/RL request; not an unsupported request.',
  'Authenticated NaN/Inf bytes in a supplied fit are known-ineligible. A missing file, bad byte count or failed digest for bytes claimed to be a complete raw artifact is UNKNOWN. An explicitly supplied array with invalid rank/shape is known malformed, not missing.',
  'The EXHAUSTIVE completeness policy mandates indeterminate for any unknown lower OR higher rank. A higher unknown cannot displace an already established lower mathematical minimum; policy nevertheless withholds selection. This is stricter than minimum-rank inference.',
  'An input integrity failure (missing/corrupt request input artifact) is global indeterminate, not numerical evidence. Request syntax/type errors are invalid_request.',
  'An unsupported finite problem is not mathematically invalid and does not narrow public support. Empty candidate list is invalid_request; 9..32 inventoried candidates are unsupported_reference; over 32 or over input-byte limits is input_envelope_exceeded/indeterminate without promising unlimited ID inventory.'
 ],
 'identity':{
  'id_regex':'^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$','id_comparison':'unsigned ASCII bytes, case-sensitive, no locale/Unicode normalization',
  'tuple_order':['configuration','producer','rhos_descriptor','coefficients_descriptor'],
  'configuration_fields':['n','pole_count','kernel','method','exact_head','alpha','dt','t_max','grid','lower_terminal','prehistory'],
  'producer_fields':['kind','entrypoint','source.repo_path','source.sha256','lock_sha256','policy_id','iterations','rate_grid','backend','working_dtype','x64','jax_version','device_class','mode'],
  'array_descriptor_fields':['dtype','shape','byte_order','layout','nbytes','sha256'],
  'serialization':'ordered tuple fields, canonical JSON UTF-8 ASCII with sorted object keys, separators comma/colon, no whitespace; native bool/int types; raw digest verified first; unavailable tuples not guessed',
  'excluded_fields':['stable_id','case_id','request_id','observation_id','run_id','pid','start_time','stop_time','elapsed_time','command','exit_code','hostname','artifact_path','logs'],
  'forbidden_normalization':['signed_zero','pole_permutation','zero_coefficient_pruning','equivalent_kernel_merging','GL_RL_request_alias_merging'],
  'duplicate_rule':'same ID OR same ID-free content tuple is request-invalid, including equal content under different IDs; same pole count alone is not a duplicate; request alias is not in candidate identity',
  'missing_identity':'if content cannot be authenticated, assessment is UNKNOWN; independently known duplicate IDs still make request invalid'
 },
 'resource_accounting':{
  'primitive_unit':'each exact rational add, subtract, multiply, divide, abs, comparison = 1, including comparisons for min/max/qualification and independent checks',
  'shared':'one cumulative counter per request across shared w/g/v/D, every candidate, independent signed/prefix/residual cross-check, all analytic input-gradient Lhat/transpose/objective references and any reruns/mode-specific exact arrays; cache reuse costs zero only when no arithmetic is performed',
  'powers':'rho^0 is literal 1; each subsequent power is one charged multiply. Closed-form binomial cross-check integer multiplications/divisions/comparisons are also charged as rational primitives; no opaque uncharged power/sum/dot.',
  'nonprimitive':'raw IEEE decode, gcd normalization internals, bit-length checks, canonical parse, hashing, allocation and serialization are not rational primitives but are wall/byte bounded; counter is not bit complexity or a peak-memory bound',
  'reservation':'check op_count+1 <= limit BEFORE operation; validate operand bits; normalize/check result bits AFTER operation; integers inside multiplication/GCD may temporarily exceed normalized cap (up to twice operand bits for products)',
  'evidence_coverage':'sum actual raw file byte lengths of ALL per-request input/fit/working and exact arrays, descriptors, hashes, manifests, metadata, command/process logs and failure index, including whitespace/newline/partial files. A compressed file is not a license to omit raw evidence. Frozen shared packet/source files referenced by path+hash need not be recopied; if copied charge full bytes. No uncounted mirror/log.',
  'reservations_bytes':{'input_bundle':262144,'failure_index':524288,'remaining_results':15990784},
  'persistence':'Before arithmetic, persist bounded input bundle containing all admitted IDs, received raw arrays, configs, source/packet bindings and required slot inventory; initialize separate bounded failure index with all slots not_evaluated. Per result use bounded temporary buffer, precheck serialized size against remaining budget, persist atomically and update index. At cap retain already committed arrays and partial completed arrays if within total cap; otherwise record unavailable reason, never fabricate arrays.',
  'watchdog':'Supervisor monotonic clock starts immediately before worker process launch, includes launch/import/decode/arithmetic/export/flush; stops only on confirmed exit. At 60s terminate then bounded 1s grace then kill; timeout is indeterminate regardless of any earlier qualifier. Supervisor writes reserved index/process record after kill; includes grace/kill latency separately, never calls 60s a total elapsed guarantee. Preflight bounded input capture is separately timed/byte-bounded, occurs before launch.',
  'overflow':'Any work/bit/evidence/watchdog/integrity/completeness exhaustion leaves explicit UNKNOWN and not_evaluated slots for all unfinished admitted IDs; known earlier results remain known but whole request indeterminate. No minimum/no-qualifier claim.'
 },
 'future_real_fitter':{'entrypoint':'hpfracc.ops._soe._fit_soe','source':source,'n':17,'n_poles_order':[8,2,4],'t_max':rat(1),'kernel_argument':'gl','method':'scaled_tail','iterations':400,'rate_grid':'existing dimensionless rates [1/(16*n),8], unchanged','dt_not_passed_to_fit':True,'fit_record_lacks':['alpha','dt','t_max'],'binding':'capture producer call alpha/dt/t_max/source/policy outside _SOEFit; source-bound fit->apply+dt**(-alpha) worker composition returns actual rhos and coefficients as auxiliary arrays from EACH mode/branch. This is NOT instrumentation of the public SOE wrapper.'},
 'preparation_source_pin':{'head':'a3951bde6a633f22ee2c1e006ea78c62421f599b','index_entries_sha256':json.loads((S/'preparation-inputs.raw.json').read_text())['index_entries_sha256'],'files':[{'repo_path':name,'sha256':digest} for name,digest in json.loads((S/'preparation-inputs.raw.json').read_text())['baseline_numeric_inputs'].items()]},
 'packet_refs':['fixtures.json','comparison-policies.json','record-schemas.json','packet-notes.md'],
 'lineage':{'failed_archive':'initial-contract-reviews-failed.tar.gz','failed_archive_sha256':'3b6b397ce0c92efe726360623e3860f8e5c5c8850be11dca0fe129864c3225fb','preservation':'initial-contract-reviews-preservation.json','original_protocol_sha256':'331d0d72ade81c242475bc9b3b1a0d37b4c3393251661e5b113bcbb0d48dd066','old_reviews_remain_failed':True}}
write('protocol.json',protocol)
# Explicit tolerance/reference/dtype/shape mappings. No execution claims.
policies=[]
for d in ['float32','float64']:
    forward=(F(2,100000),F(2,100000)) if d=='float32' else (F(1,10**10),F(6,10**10))
    grad=(F(2,100000),F(2,100000)) if d=='float32' else (F(2,10**7),F(2,10**8))
    fdinput=(F(2,1000),F(2,10000)) if d=='float32' else (F(2,10**6),F(2,10**7))
    fdorder=(F(5,1000),F(5,10000)) if d=='float32' else (F(2,10**5),F(2,10**6))
    specs=[('forward_recursive_exact','recursive_output','exact_D_hat','input_shape','exact_rational',forward),('forward_full_exact','full_signed_output','exact_D','input_shape','exact_rational',forward),('forward_eager_jit','jit_output','eager_output','input_shape',d,forward),('input_grad_analytic','input_AD','exact_input_gradient','input_shape','exact_rational',grad),('input_grad_eager_jit','jit_input_AD','eager_input_AD','input_shape',d,grad),('order_grad_eager_jit','jit_order_AD','eager_order_AD','scalar',d,grad),('input_FD_AD','input_directional_AD','input_central_FD','scalar',d,fdinput),('input_FD_adjacent','input_FD_smaller_h','input_FD_larger_h','scalar',d,fdinput),('order_FD_AD','order_AD','order_central_FD','scalar',d,fdorder),('order_FD_adjacent','order_FD_smaller_h','order_FD_larger_h','scalar',d,fdorder)]
    for name,a,r,shape,rd,tol in specs:
        policies.append({'policy_id':d+'-'+name,'a':a,'reference':r,'observed_dtype':d,'reference_dtype':rd,'shape':shape,'rtol':rat(tol[0]),'atol':rat(tol[1]),'modes':['eager','jit'] if name not in ['forward_eager_jit','input_grad_eager_jit','order_grad_eager_jit'] else ['cross_mode'],'required':'every component, no broadcasting, finite only','status':'frozen_proposed_empirical_gate_not_bound'})
comparisons={'protocol_id':P,'predicate':'same rank and exact shape; all values finite; for EVERY component abs(a-r) <= atol + rtol*abs(r). a is observed operand, r is explicitly named reference. Decode represented working operands exactly for comparison; do not round rational references to worker dtype. No norm reduction, squeeze, broadcast, relative denominator swap or equal_nan.',
 'policies':policies,'input_gradient':{'objective':'mean(D_hat**2) over all N*M entries; M=1 for (N,)','signed_weights':'g_hat[-1]=0; w_hat[k]=g_hat[k]-g_hat[k-1], k=0..N-1','L_hat':'N by N lower triangular, L_hat[i,j]=2*w_hat[i-j] if j<=i else 0; acts on each feature independently','exact_target':'2/(N*M) * L_hat.T @ D_hat, retaining input shape','direction':'q=cos(x_base) computed once in target worker dtype; raw q retained, stop_gradient q; never cos(x_perturbed); directional AD=sum(input_AD*q); exact directional target=sum(exact_input_gradient*decoded_q)','fixed_fit':'input perturbations hold alpha/config fixed; each composition must return actual fit arrays, compare identities to same-mode base; exact gradient bound to that mode base actual fit, not borrowed eager arrays'},
 'order_gradient':{'objective':'mean((dt**(-a) * apply(x, fit(a,fixed_config)))**2)','alpha':'strong scalar shape [] in worker dtype, including every +/- branch and JIT dynamic argument','scale':'dt is strong scalar in same dtype; recompute dt**(-a) INSIDE differentiated objective and each perturbation. 2 is exact only at base a=1/2. dt remains fixed; alpha perturbs.','selection':'outside AD/FD; fix selected pole count and producer config from base, refit at each a; never reselect, never freeze order-dependent coefficients','scope':'differentiate existing finite 400 projected iterations, not an implicit optimizer optimum; only empirical AD/FD observations at perturbed orders, no rational-budget domain extension'},
 'FD_steps':{'float32':[arr([F(1,128)],'float32',[]),arr([F(1,256)],'float32',[]),arr([F(1,512)],'float32',[])],'float64':[arr([1e-5],'float64',[])]},
 'FD_rules':['central (J(+h)-J(-h))/(2*h) in worker dtype; retain both objectives, actual perturbed input/alpha, q, dt, h, effective dtypes and returned fit arrays from EACH composition invocation','all declared FD steps vs AD in both modes; float32 every adjacent pair in descending h order; float64 singleton has no adjacent pair (explicit not_applicable)','input fixed-fit objective is quadratic: real-arithmetic central-FD truncation error is ZERO, not O(h^2); floating input/objective/FD arithmetic remains unbounded by this gate','O(h^2)+O(u/h) is only a smooth-order heuristic; projected-fit kinks and coefficient active-set transitions are not covered. Retain final coefficient-zero pattern per branch as a limited diagnostic; change/nonfinite/unresolved comparison => preserve and stop, no retune','scope x64 off/on outside JIT for float32/float64 respectively and restore; assert actual input, strong alpha/dt/h/q/perturbations, fit arrays, output, objective, input cotangent and order cotangent dtypes; scalar order cotangent shape []','every eager/JIT/AD/FD composition returns actual fit arrays via aux from fit->apply+scale; exact D_hat/reference/analytic gradient use THAT mode and branch arrays. Never borrow eager fit arrays for JIT; no claim that public SOE wrapper has instrumentation']}
write('comparison-policies.json',comparisons)
# Schemas specify future records, not an implemented parser/validator.
def obj(props):return {'type':'object','additionalProperties':False,'required':list(props),'properties':props}
def ref(n):return {'$ref':'#/$defs/'+n}
def en(*v):return {'enum':list(v)}
def integer(lo=0,hi=100000):return {'type':'integer','minimum':lo,'maximum':hi}
def ls(item,lo=0,hi=2048):return {'type':'array','items':item,'minItems':lo,'maxItems':hi}
def nullable(s):return {'anyOf':[s,{'type':'null'}]}
idfield={'type':'string','pattern':'^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$','maxLength':64}
sha={'type':'string','pattern':'^[0-9a-f]{64}$','minLength':64,'maxLength':64}
text={'type':'string','pattern':'^[ -~]*$','maxLength':256}
shape=ls(integer(0,17),0,2)
reason_codes=['none','invalid_type','invalid_tau','duplicate_id','duplicate_content','empty_candidates','unsupported_reference','input_envelope_exceeded','configuration_mismatch','malformed_fit','nonfinite_fit','negative_coefficient','invalid_rho','missing_raw_artifact','corrupt_raw_artifact','missing_producer_binding','corrupt_producer_binding','primitive_cap','normalized_bit_cap','evidence_cap','watchdog','not_evaluated','incomplete_evidence','shape_mismatch','comparison_failed','nonsmooth_unresolved','gate_contradiction','process_failed']
quantity=['w','g','v','D','g_hat','residual','signed_fitted_weights','L_hat','D_hat','error','B','epsilon','analytic_input_gradient','rhos','coefficients','input','alpha','dt','h','direction','output','full_output','objective','input_AD','order_AD','directional_AD','input_FD','order_FD','zero_pattern']
defs={
 'id':idfield,'sha':sha,'rat':obj({'num':{'type':'string','pattern':'^(0|-?[1-9a-f][0-9a-f]*)$','maxLength':8193},'den':{'type':'string','pattern':'^[1-9a-f][0-9a-f]*$','maxLength':8192}}),
 'source':obj({'repo_path':text,'sha256':sha}),
 'raw_array':obj({'dtype':en('float32','float64'),'shape':shape,'byte_order':en('little','big'),'layout':en('C'),'nbytes':integer(0,4096),'raw_hex':{'type':'string','pattern':'^(?:[0-9a-f]{2})*$','maxLength':8192},'sha256':sha}),
 'exact_array':obj({'shape':shape,'values':ls(ref('rat'),0,289)}),
 'configuration':obj({'n':integer(1,17),'pole_count':integer(1,8),'kernel':en('gl_prefix','l1','gl'),'method':en('scaled_tail','legacy'),'exact_head':{'type':'boolean'},'alpha':ref('rat'),'dt':ref('rat'),'t_max':ref('rat'),'grid':en('uniform','nonuniform'),'lower_terminal':ref('rat'),'prehistory':en('zero','nonzero')}),
 'producer':obj({'kind':en('synthetic_control','actual_fitter'),'entrypoint':text,'source':ref('source'),'lock_sha256':sha,'policy_id':idfield,'iterations':integer(0,400),'rate_grid':text,'backend':en('host','cpu','cuda','unobserved'),'working_dtype':en('float32','float64'),'x64':{'type':'boolean'},'jax_version':text,'device_class':text,'mode':en('synthetic','eager','jit','unobserved')}),
 'candidate':obj({'record_type':en('candidate'),'stable_id':idfield,'configuration':ref('configuration'),'producer':ref('producer'),'rhos':nullable(ref('raw_array')),'coefficients':nullable(ref('raw_array')),'artifact_status':en('provided','missing','corrupt','not_evaluated'),'reasons':ls(en(*reason_codes),0,32)}),
 'request':obj({'record_type':en('request'),'request_id':idfield,'case_id':idfield,'policy_id':idfield,'packet_manifest_sha256':sha,'operator':en('GL','RL','Caputo'),'alpha':ref('rat'),'dt':ref('rat'),'lower_terminal':ref('rat'),'prehistory':en('zero','nonzero'),'grid':en('uniform','nonuniform'),'input':ref('raw_array'),'tau':ref('rat'),'candidates':ls(ref('candidate'),1,32),'caps':obj({k:integer(0,max(v,100000)) for k,v in caps.items()})}),
 'slot':obj({'slot_id':idfield,'case_id':idfield,'candidate_id':nullable(idfield),'mode':en('shared','synthetic','eager','jit'),'branch':idfield,'quantity':en(*quantity),'status':en('complete','partial','unknown','not_evaluated','not_applicable'),'reason':en(*reason_codes),'raw_array':nullable(ref('raw_array')),'exact_array':nullable(ref('exact_array')),'producer_binding_sha256':nullable(sha)}),
 'assessment':obj({'candidate_id':idfield,'status':en('known_qualifying','known_rejected_by_bound','known_ineligible','unknown'),'reasons':ls(en(*reason_codes),1,32),'qualifies':nullable({'type':'boolean'}),'slots':ls(ref('slot'),0,2048)}),
 'observation':obj({'record_type':en('observation'),'observation_id':idfield,'case_id':idfield,'candidate_id':idfield,'policy_id':idfield,'producer':ref('producer'),'configuration':ref('configuration'),'mode':en('eager','jit'),'branch':idfield,'input_bundle_sha256':sha,'base_observation_id':nullable(idfield),'slots':ls(ref('slot'),1,64),'status':en('complete','unknown','not_evaluated'),'reasons':ls(en(*reason_codes),1,32)}),
 'comparison':obj({'record_type':en('comparison'),'comparison_id':idfield,'case_id':idfield,'candidate_id':idfield,'policy_id':idfield,'a_slot_id':idfield,'reference_slot_id':idfield,'status':en('pass','fail','unknown','not_evaluated','not_applicable'),'reasons':ls(en(*reason_codes),1,32)}),
 'process':obj({'record_type':en('process'),'run_id':idfield,'command':ls(text,1,32),'exit_code':nullable({'type':'integer','minimum':-255,'maximum':255}),'termination':en('normal','terminate','kill','not_launched'),'elapsed_monotonic_ns':nullable(integer(0,10**12)),'watchdog_triggered':{'type':'boolean'},'stdout_sha256':nullable(sha),'stderr_sha256':nullable(sha),'stdout_truncated':{'type':'boolean'},'stderr_truncated':{'type':'boolean'}}),
 'result':obj({'record_type':en('result'),'case_id':idfield,'request_id':idfield,'input_bundle_sha256':sha,'packet_manifest_sha256':sha,'status':en('invalid_request','indeterminate','selected','no_supplied_candidate_meets_bound'),'selected_id':nullable(idfield),'reasons':ls(en(*reason_codes),1,32),'assessments':ls(ref('assessment'),0,32),'shared_slots':ls(ref('slot'),0,2048),'primitive_count':integer(0,100000),'max_normalized_bits':integer(0,32768),'evidence_bytes':integer(0,16777216),'arithmetic_verified':en(False),'total_numerical_certified':en(False),'a2_acceptance_passed':en(False),'implementation_authorized':en(False)}),
 'failure_index':obj({'record_type':en('failure_index'),'request_id':idfield,'input_bundle_sha256':sha,'candidate_ids':ls(idfield,0,32),'slots':ls(ref('slot'),0,2048),'status':en('not_evaluated','indeterminate','complete'),'reasons':ls(en(*reason_codes),1,32),'process':ref('process')}),
 'input_bundle':obj({'record_type':en('input_bundle'),'request':ref('request'),'sources':ls(ref('source'),1,125),'required_slots':ls(ref('slot'),1,2048)})}
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'urn:hpfracc:a2:preparation:records:v1','title':'Proposed closed A2 record structures; semantic predicate is mandatory','oneOf':[ref(x) for x in ['request','candidate','observation','comparison','process','result','failure_index','input_bundle']],'$defs':defs,
 'x-canonical-parse-predicate':[
  'Before decoding: UTF-8 ASCII JSON only, total bytes <= input_bundle cap, depth <=16, nodes <=32768, strings <=256 ASCII bytes except raw_hex <=8192 and rational fields <=8193/8192; IDs <=64; bounded decoder must count before allocation. No comments/BOM/trailing data.',
  'Reject duplicate object keys using object_pairs_hook or equivalent; reject NaN/Infinity/-Infinity via parse_constant; every JSON numeric token must use integer lexical form (no decimal point/exponent). For integer fields require type(value) is int, not bool/float; for boolean fields require type(value) is bool. In particular JSON 1.0 and true are not integer 1, and 0/1 are not booleans. Schema integer checks alone are insufficient.',
  'Only declared keys allowed, ALL keys required, no implicit default. Exact enums require type as well as value: certification flags are genuine false bool, not 0. Preserve malformed request bytes for negative fixtures rather than coercing them.',
  'Rationals use lowercase hex, no 0x/plus/leading zeros/-0; den>0; gcd(abs(num),den)==1; zero ONLY num=0,den=1. Validate lengths BEFORE int conversion, normalized bits <=32768; request tau <=256 bits each, tau>=0. Negative/noncanonical tau is invalid_request; oversized canonical tau is unsupported_reference.',
  'Raw arrays: nbytes == len(raw_hex)//2 == product(shape)*itemsize, scalar [] has one item; rank/shape validated before allocation, C order, explicit byte order, SHA256 over decoded raw bytes. Finite check follows artifact authentication. Signed zero bytes remain identity data. Exact arrays have product(shape) values, each canonical rational. N by N analytic matrix may have 289 values.',
  'All IDs and slots unique; exact set of candidate IDs equals supplied list; exact slot/comparison/branch inventory equals fixtures plus selected-mode expansion, no omitted/extra/duplicate evidence. Unknown/not_evaluated slots have null arrays and explicit non-none reason; partial has only a shape-consistent complete prefix and explicit unavailable remainder inventoried; complete has exactly one appropriate raw/exact payload and no missing reason. not_applicable has null payload and explicit reason not_evaluated (e.g. singleton FD adjacency).',
  'Bind source/case/policy/producer/configuration, input bytes, alpha/dt/t_max and actual returned arrays for each mode/branch before hashing. _SOEFit lacks alpha/dt/t_max: do not infer binding from it. Source path/hash and lock/policy/context participate in identity. Raw artifact hashes authenticate bytes, not actual execution.',
  'Recompute shared exact identities, every fitted kernel/output/residual/B/analytic gradient, qualification, completeness and rank from authenticated bytes; compare all required empirical operands using named policies. Checksums alone and synthetic expected fields are not semantic proof or worker results.',
  'If result status selected, all assessments known, selected ID minimum eligible qualifier; no_supplied requires all known and none qualify. Any unknown or missing required slot makes result indeterminate under EXHAUSTIVE policy. known_ineligible remains completed only for authenticated, fully characterized invalidity; no numerical arrays need be invented. Retain all observable reason codes.',
  'Frozen manifest lives OUTSIDE files it hashes; it lists exact repo-relative path, byte count and SHA256, excludes itself. Hash request bundle before result/process records reference it; never require an artifact to contain its own digest. Future run manifest hashes completed immutable artifacts last and is not part of its own list.'
 ]}
write('record-schemas.json',schema)
# Concrete synthetic arrays and request cases, not a simulated production fitter.
arrays={}; candidates={}; cases=[]
locksha=H((R/'uv.lock').read_bytes())
def addarray(key,vals,d,shape):
    value=arr(vals,d,shape)
    if key in arrays: assert arrays[key]==value
    arrays[key]=value;return key
def config(n,p):return {'n':n,'pole_count':p,'kernel':'gl_prefix','method':'scaled_tail','exact_head':True,'alpha':rat(F(1,2)),'dt':rat(F(1,4)),'t_max':rat(1),'grid':'uniform','lower_terminal':rat(0),'prehistory':'zero'}
def candidate(key,n,d,rhos,cs):
    if key in candidates:return key
    candidates[key]={'stable_id':key,'configuration':config(n,len(rhos)),'producer':{'kind':'synthetic_control','entrypoint':'static_fixture','source':source,'lock_sha256':locksha,'policy_id':P,'iterations':0,'rate_grid':'explicit raw fixture arrays; not fitter output','backend':'host','working_dtype':d,'x64':d=='float64','jax_version':'not_used','device_class':'host_exact_planning','mode':'synthetic'},'rhos_ref':addarray(key+'-rho',rhos,d,[len(rhos)]),'coefficients_ref':addarray(key+'-coef',cs,d,[len(cs)]),'artifact_status':'provided','reasons':[]}
    return key
exact_comps=['signed_prefix_identity','direct_fitted_signed_identity','residual_output_identity','all_component_error_le_B','every_time_bound_vs_tau','complete_candidate_inventory','complete_exact_slot_inventory','minimum_rank_or_exhaustive_indeterminate']
shared_q=['w','g','v','D'];cand_q=['g_hat','residual','signed_fitted_weights','L_hat','D_hat','error','B','epsilon','analytic_input_gradient']
def addcase(cid,group,n,d,op,vals,shape,cs,tau,expected,mutations=None,resource=None):
    ir=addarray(cid+'-x',vals,d,shape)
    cases.append({'case_id':cid,'group':group,'request':{'operator':op,'alpha':rat(F(1,2)),'dt':rat(F(1,4)),'lower_terminal':rat(0),'prehistory':'zero','grid':'uniform','input_ref':ir,'tau':rat(tau),'candidate_refs':cs,'caps_ref':'protocol.json#/caps'},'mutations':mutations or [],'resource_control':resource,'required_comparisons':exact_comps.copy(),'expected':expected,'expectation_role':'predeclared_synthetic_planning_not_selector_result' if group!='FIT-REAL' else 'future_observation_stop_gate_not_observed_attainability'})
def ex(status,selected=None,reason='none'):return {'request_status':status,'selected_id':selected,'reason':reason}
for d,op in itertools.product(['float32','float64'],['GL','RL']):
    suffix=('f32' if d=='float32' else 'f64')+'-'+op
    bad=candidate('bad1-'+suffix,3,d,[F(1,2)],[F(1,2)])
    good=candidate('a-good2-'+suffix,3,d,[F(1,2),1],[F(1,4),F(1,4)])
    tie=candidate('z-good2-'+suffix,3,d,[F(5,8),F(7,8)],[F(1,4),F(1,4)])
    big=candidate('good3-'+suffix,3,d,[F(1,2),1,F(3,4)],[F(1,4),F(1,4),0])
    one=candidate('good1-'+suffix,3,d,[F(3,4)],[F(1,2)])
    badbig=candidate('bad3-'+suffix,3,d,[F(1,2),F(3,4),1],[F(1,2),0,0])
    for label,cs,tau,expected in [('FAIL',[bad],F(3,16),ex('no_supplied_candidate_meets_bound')),('PASS',[bad,good],F(3,16),ex('selected',good)),('EQUAL',[bad],F(1,4),ex('selected',bad)),('BELOW',[bad],F(1,4)-F(1,2**100),ex('no_supplied_candidate_meets_bound'))]:
        addcase('REF-'+label+'-'+suffix,'REF-CORE',3,d,op,[1,1,1],[3],cs,tau,expected)
    for i,perm in enumerate(itertools.permutations([bad,good,tie,big])):
        addcase('RANK-'+str(i).zfill(2)+'-'+suffix,'REF-RANK',3,d,op,[1,1,1],[3],list(perm),F(3,16),ex('selected',good))
    addcase('RANK-smaller-'+suffix,'REF-RANK',3,d,op,[1,1,1],[3],[badbig,one],0,ex('selected',one))
    for label,vals,shape,tau,expected in [('zero',[0,0,0],[3],0,ex('selected',bad)),('changed',[1,-1,1],[3],F(3,16),ex('no_supplied_candidate_meets_bound')),('stacked',[1,0,1,0,1,0],[3,2],F(3,16),ex('no_supplied_candidate_meets_bound'))]:
        addcase('EDGE-'+label+'-'+suffix,'REF-EDGES',3,d,op,vals,shape,[bad],tau,expected)
    single=candidate('single1-'+suffix,1,d,[F(1,2)],[F(1,2)])
    addcase('EDGE-singleton-'+suffix,'REF-EDGES',1,d,op,[F(-3,2)],[1],[single],0,ex('selected',single))
    # Declarative raw negative fixtures: apply explicit JSON-pointer replacements BEFORE parsing the request/candidate.
    negatives=[('bool-n','candidate:0/configuration/n',True,'known_ineligible','invalid_type'),('float-n','candidate:0/configuration/n',3.0,'known_ineligible','invalid_type'),('int-head','candidate:0/configuration/exact_head',1,'known_ineligible','invalid_type'),('head','candidate:0/configuration/exact_head',False,'known_ineligible','configuration_mismatch'),('l1','candidate:0/configuration/kernel','l1','known_ineligible','configuration_mismatch'),('method','candidate:0/configuration/method','legacy','known_ineligible','configuration_mismatch'),('length','candidate:0/configuration/n',2,'known_ineligible','configuration_mismatch'),('alpha','candidate:0/configuration/alpha',rat(F(1,3)),'known_ineligible','configuration_mismatch'),('missing','candidate:0/artifact_status','missing','unknown','missing_raw_artifact'),('corrupt','candidate:0/artifact_status','corrupt','unknown','corrupt_raw_artifact'),('bad-shape','candidate:0/rhos/shape',[1,1],'known_ineligible','malformed_fit'),('negative-c','candidate:0/coefficients',arr([-F(1,2)],d,[1]),'known_ineligible','negative_coefficient'),('rho-zero','candidate:0/rhos',arr([0],d,[1]),'known_ineligible','invalid_rho'),('rho-large','candidate:0/rhos',arr([2],d,[1]),'known_ineligible','invalid_rho'),('nan','candidate:0/coefficients',arr([float('nan')],d,[1]),'known_ineligible','nonfinite_fit'),('inf','candidate:0/rhos',arr([float('inf')],d,[1]),'known_ineligible','nonfinite_fit')]
    for label,path,value,status,reason in negatives:
        e=ex('indeterminate' if status=='unknown' else 'selected',None if status=='unknown' else good,reason);e['mutated_candidate_status']=status
        addcase('EDGE-'+label+'-'+suffix,'REF-EDGES',3,d,op,[1,1,1],[3],[bad,good],F(3,16),e,[{'replace':path,'value':value}])
    reqneg=[('tau-bool','tau',True,'invalid_request','invalid_tau'),('tau-float','tau',0.25,'invalid_request','invalid_tau'),('tau-negative','tau',rat(-1),'invalid_request','invalid_tau'),('tau-nonreduced','tau',{'num':'2','den':'8'},'invalid_request','invalid_tau'),('tau-over','tau',rat(F(2**256)),'indeterminate','unsupported_reference'),('order','alpha',rat(F(1,3)),'indeterminate','unsupported_reference'),('grid','grid','nonuniform','indeterminate','unsupported_reference'),('operator','operator','Caputo','indeterminate','unsupported_reference'),('empty','candidate_refs',[],'invalid_request','empty_candidates'),('duplicate-id','candidate_refs',[bad,bad],'invalid_request','duplicate_id')]
    for label,path,value,status,reason in reqneg:
        addcase('REQUEST-'+label+'-'+suffix,'REF-EDGES',3,d,op,[1,1,1],[3],[bad,good],F(3,16),ex(status,None,reason),[{'replace':'request/'+path,'value':value}])
    for label,values,sh in [('N18',[0]*18,[18]),('M4',[0]*12,[3,4])]:
        addcase('REQUEST-'+label+'-'+suffix,'REF-EDGES',3,d,op,[1,1,1],[3],[bad,good],0,ex('indeterminate',None,'unsupported_reference'),[{'replace':'request/input','value':arr(values,d,sh)}])
    complex_raw=arr([1,0,1,0,1,0],d,[6]);complex_raw['dtype']='complex64' if d=='float32' else 'complex128';complex_raw['shape']=[3]
    addcase('REQUEST-complex-'+suffix,'REF-EDGES',3,d,op,[1,1,1],[3],[bad,good],0,ex('indeterminate',None,'unsupported_reference'),[{'replace':'request/input','value':complex_raw}])
    extra=[]
    for j in range(9):
        extra.append(candidate('extra'+str(j)+'-'+suffix,3,d,[F(j+1,16)],[F(1,2)]))
    addcase('REQUEST-nine-candidates-'+suffix,'REF-CAPS',3,d,op,[1,1,1],[3],extra,0,ex('indeterminate',None,'unsupported_reference'))
    p9=candidate('nine-poles-'+suffix,3,d,[F(j+1,16) for j in range(9)],[F(1,16)]*9)
    addcase('REQUEST-nine-poles-'+suffix,'REF-CAPS',3,d,op,[1,1,1],[3],[p9,good],0,ex('indeterminate',None,'unsupported_reference'))
    dup=copy.deepcopy(candidates[good]);dup['stable_id']='copy-good2-'+suffix;candidates[dup['stable_id']]=dup
    addcase('REQUEST-duplicate-content-'+suffix,'REF-EDGES',3,d,op,[1,1,1],[3],[good,dup['stable_id']],0,ex('invalid_request',None,'duplicate_content'))
    # Missing a required intermediate bound row is a completeness failure, not a claim that checking final B changes the bound decision.
    addcase('EDGE-missing-row-'+suffix,'REF-EDGES',3,d,op,[1,1,1],[3],[good],0,ex('indeterminate',None,'incomplete_evidence'),[{'replace':'evidence/candidate:0/B/time:1','value':None}])
    hi=candidate('unknown8-'+suffix,3,d,[F(k,16) for k in range(1,9)],[F(1,16)]*8)
    for label,cs,idx in [('higher',[good,hi],1),('lower',[bad,good],0)]:
        addcase('EDGE-unknown-'+label+'-'+suffix,'REF-EDGES',3,d,op,[1,1,1],[3],cs,0,ex('indeterminate',None,'missing_raw_artifact'),[{'replace':'candidate:'+str(idx)+'/artifact_status','value':'missing'}])
    for label,vals in [('ramp',[F(k,16) for k in range(17)]),('step',[int(k>=8) for k in range(17)]),('alternating',[F((-1)**k,8) for k in range(17)]),('stacked',[v for k in range(17) for v in [F(k,16),int(k>=8),F((-1)**k,8)]])]:
        shape=[17,3] if label=='stacked' else [17]
        cb=candidate('signal1-'+suffix,17,d,[F(1,2)],[F(1,2)])
        addcase('SIGNAL-'+label+'-'+suffix,'REF-SIGNAL',17,d,op,vals,shape,[cb],1,{'request_status':'derive_exactly_from_frozen_synthetic_arrays','selected_id':None,'reason':'none'})
        realids=[]
        for p in [8,2,4]:
            key='fit'+str(p)+'-'+suffix
            if key not in candidates:
                candidates[key]={'stable_id':key,'configuration':config(17,p),'producer_call':{'entrypoint':'hpfracc.ops._soe._fit_soe','source':source,'lock_sha256':locksha,'alpha_ref':'request/alpha','n':17,'n_poles':p,'t_max':rat(1),'kernel':'gl','method':'scaled_tail','expected_dtype':d,'x64':d=='float64'},'rhos_ref':None,'coefficients_ref':None,'artifact_status':'not_evaluated','reasons':['not_evaluated']}
            realids.append(key)
        for tau in [1,0]:
            e={'request_status':'required_selected_stop_gate' if tau else 'required_no_supplied_candidate_meets_bound_stop_gate','selected_id':None,'reason':'not_evaluated','on_contradiction':'preserve_all_candidates_and_stop_no_retune'}
            addcase('FIT-'+label+'-tau'+str(tau)+'-'+suffix,'FIT-REAL',17,d,op,vals,shape,realids,tau,e)
    for n,m in itertools.product(range(1,18),range(1,4)):
        vals=[v for k in range(n) for v in [F(k,16),int(k>=8),F((-1)**k,8)][:m]]
        cg=candidate('grid1-N'+str(n)+'-'+suffix,n,d,[F(1,2)],[F(1,2)])
        addcase('GRID-N'+str(n)+'-M'+str(m)+'-'+suffix,'EXACT-GRID',n,d,op,vals,[n] if m==1 else [n,m],[cg],1,{'request_status':'derive_exactly_from_frozen_synthetic_arrays','selected_id':None,'reason':'none'})
    for label,field,value,reason in [('ops','rational_primitives',0,'primitive_cap'),('bits','normalized_bits',1,'normalized_bit_cap'),('bytes','evidence_bytes',786432,'evidence_cap'),('wall','wall_seconds',0,'watchdog')]:
        addcase('CAP-'+label+'-'+suffix,'REF-CAPS',3,d,op,[1,1,1],[3],[good,bad],0,ex('indeterminate',None,reason),resource={'override_cap':field,'value':value,'trigger':'before first charged operation' if label=='ops' else 'first normalized 1/2' if label=='bits' else 'result allowance zero after input/failure reservations' if label=='bytes' else 'launch-time deadline expires before work','retention':'persist input and all ID/slot inventory first; all unfinished unknown/not_evaluated; preserve any completed arrays within cap','run_role':'future_control_protocol_only_not_executed'})
    addcase('CAP-after-qualifier-'+suffix,'REF-CAPS',3,d,op,[1,1,1],[3],[good,bad],0,ex('indeterminate',None,'primitive_cap'),resource={'override_cap':None,'value':None,'fault_checkpoint':'after_candidate_index_0_commit_before_candidate_index_1','injected_reason':'primitive_cap','trigger':'declared supervisor fault injection at this exact checkpoint, NOT a measured primitive-cap feasibility assertion','retention':'first complete qualifier arrays retained; second UNKNOWN; global indeterminate','run_role':'future_control_protocol_only_not_executed'})
# Closed parser/inventory controls, raw JSON bytes rather than coerced values.
parse_controls=[]
for label,raw,expected in [('duplicate-key','{"exact_head":true,"exact_head":false}','reject_duplicate_key'),('nan','{"x":NaN}','reject_nonfinite_json'),('inf','{"x":Infinity}','reject_nonfinite_json'),('bool-int','{"n":true}','reject_integer_type'),('float-int','{"n":1.0}','reject_integer_type'),('int-bool','{"exact_head":1}','reject_boolean_type'),('negative-zero','{"num":"-0","den":"1"}','reject_rational'),('nonreduced','{"num":"2","den":"4"}','reject_rational'),('zero-den','{"num":"0","den":"2"}','reject_rational'),('leadingzero','{"num":"01","den":"1"}','reject_rational')]:
    parse_controls.append({'case_id':'PARSE-'+label,'raw_utf8_hex':raw.encode().hex(),'sha256':H(raw.encode()),'expected':expected,'role':'planning_parse_negative_not_executed_parser'})
branches={}
for d in ['float32','float64']:
    hs=['h0','h1','h2'] if d=='float32' else ['h0']
    branches[d]=['base']+[axis+'-'+h+'-'+sign for axis in ['input','order'] for h in hs for sign in ['plus','minus']]
def decode(a):
    return [F(x) for (x,) in struct.iter_unpack('<'+('f' if a['dtype']=='float32' else 'd'),bytes.fromhex(a['raw_hex']))]
for c in cases:
    rq=c['request']; a=arrays[rq['input_ref']]; n=a['shape'][0];m=1 if len(a['shape'])==1 else a['shape'][1]
    if c['expected']['request_status']=='derive_exactly_from_frozen_synthetic_arrays':
        x=decode(a);g=[F(1)]
        for k in range(1,n):g.append(g[-1]*F(2*k-1,2*k))
        gh=[F(1)]+[F(1,2)**k for k in range(1,n)]
        eps=max(abs(u-v) for u,v in zip(g,gh));v=[[x[i*m+j]-(x[(i-1)*m+j] if i else 0) for j in range(m)] for i in range(n)]
        bmax=max([F(0)]+[2*eps*sum(abs(v[j][f]) for j in range(i)) for i in range(n) for f in range(m)])
        t=F(int(rq['tau']['num'],16),int(rq['tau']['den'],16));q=bmax<=t
        c['expected']=ex('selected' if q else 'no_supplied_candidate_meets_bound',rq['candidate_refs'][0] if q else None)
        c['expected']['planning_epsilon']=rat(eps);c['expected']['planning_max_B']=rat(bmax)
    slots=[{'slot_id':'S-X-'+q,'candidate_index':None,'mode':'shared','branch':'base','quantity':q,'initial_status':'not_evaluated'} for q in shared_q]
    for i,_ in enumerate(rq['candidate_refs']):
        for q in cand_q:slots.append({'slot_id':'S-'+str(i)+'-'+q,'candidate_index':i,'mode':'synthetic' if c['group']!='FIT-REAL' else 'eager','branch':'base','quantity':q,'initial_status':'not_evaluated'})
    if c['group']=='FIT-REAL':
        slots=[v for v in slots if v['candidate_index'] is None]
        for mode,i in itertools.product(['eager','jit'],range(3)):
            for q in cand_q:slots.append({'slot_id':mode+'-'+str(i)+'-exact-'+q,'candidate_index':i,'mode':mode,'branch':'base','quantity':q,'initial_status':'not_evaluated'})
            for branch in branches[a['dtype']]:
                if branch!='base' and rq['tau']['num']=='0':continue
                for q in ['input','alpha','dt','h','direction','rhos','coefficients','output','objective','zero_pattern']+(['input_AD','order_AD','directional_AD'] if branch=='base' and rq['tau']['num']!='0' else []):
                    slots.append({'slot_id':mode+'-'+str(i)+'-'+branch+'-'+q,'candidate_index':i,'mode':mode,'branch':branch,'quantity':q,'initial_status':'not_evaluated'})
        c['working_policy_ids']=[v['policy_id'] for v in policies if v['observed_dtype']==a['dtype']]
    if c['group']=='FIT-REAL':
        for mode in ['eager','jit']:
            slots.append({'slot_id':mode+'-X-base-full_output','candidate_index':None,'mode':mode,'branch':'base','quantity':'full_output','initial_status':'not_evaluated'})
        checks=[];nh=3 if a['dtype']=='float32' else 1
        for i in range(3):
            for mode in ['eager','jit']:
                checks.append({'comparison_id':mode+'-'+str(i)+'-forward_recursive_exact','policy_id':a['dtype']+'-forward_recursive_exact','candidate_index':i,'mode':mode,'branch':'base','scope':'all_candidates'})
                if rq['tau']['num']!='0':
                    checks.append({'comparison_id':mode+'-'+str(i)+'-input_grad_analytic','policy_id':a['dtype']+'-input_grad_analytic','candidate_index':i,'mode':mode,'branch':'base','scope':'selected_only_others_explicit_not_applicable'})
                    for axis in ['input','order']:
                        for hi in range(nh):
                            br=axis+'-h'+str(hi)
                            slots.append({'slot_id':mode+'-'+str(i)+'-'+br+'-FD','candidate_index':i,'mode':mode,'branch':br,'quantity':axis+'_FD','initial_status':'not_evaluated'})
                            checks.append({'comparison_id':mode+'-'+str(i)+'-'+br+'-AD','policy_id':a['dtype']+'-'+axis+'_FD_AD','candidate_index':i,'mode':mode,'branch':br,'scope':'selected_only_others_explicit_not_applicable'})
                        for hi in range(nh-1):
                            checks.append({'comparison_id':mode+'-'+str(i)+'-'+axis+'-adj'+str(hi),'policy_id':a['dtype']+'-'+axis+'_FD_adjacent','candidate_index':i,'mode':mode,'branch':axis+'-h'+str(hi)+'-h'+str(hi+1),'scope':'selected_only_others_explicit_not_applicable'})
            for nm in ['forward_eager_jit']+(['input_grad_eager_jit','order_grad_eager_jit'] if rq['tau']['num']!='0' else []):
                checks.append({'comparison_id':'cross-'+str(i)+'-'+nm,'policy_id':a['dtype']+'-'+nm,'candidate_index':i,'mode':'cross_mode','branch':'base','scope':'all_candidates' if nm=='forward_eager_jit' else 'selected_only_others_explicit_not_applicable'})
        for mode in ['eager','jit']:
            checks.append({'comparison_id':mode+'-X-forward_full_exact','policy_id':a['dtype']+'-forward_full_exact','candidate_index':None,'mode':mode,'branch':'base','scope':'shared_full_reference'})
        c['required_working_comparisons']=checks
    c['required_evidence_slots']=slots
    assert len(slots)<=caps['slots_per_request']
fixture={'protocol_id':P,'status':'closed_proposed_fixture_matrix_not_observations','working_scalars':{d:{'alpha':arr([F(1,2)],d,[]),'dt':arr([F(1,4)],d,[]),'t_max':arr([1],d,[])} for d in ['float32','float64']},'arrays':arrays,'candidates':candidates,'cases':cases,'parse_controls':parse_controls,
 'mutation_semantics':'Expand refs without coercion, then apply listed exact replacements to raw request/candidate/evidence objects. candidate:i is supplied-order index. Provided raw replacements update descriptor SHA/length as explicitly frozen; artifact_status missing/corrupt denotes deliberately unavailable/failed authentication, not known bad numbers. A duplicate ref occurrence retains stable ID and is invalid. Raw invalid JSON controls are parser inputs, not valid record instances.',
 'exact_slot_inventory':{'shared':shared_q,'each_candidate':cand_q,'slot_id_rule':'S-{supplied-index}-{quantity} (shared uses S-X); case_id binds uniqueness','for_known_ineligible':'all numerical slots explicit not_applicable with reason malformed_fit/configuration_mismatch etc, not fabricated values','for_unknown':'all unavailable slots unknown/not_evaluated with explicit reason; keep any completed arrays','all_time_components':'retain every row; omitted row is incomplete evidence even if final B is sufficient mathematically'},
 'real_worker_inventory':{'base_modes':['eager','jit'],'base_candidates':'ALL 3 supplied candidates in order [8,2,4], independently return arrays and exact-assess each mode; require selected ID/outcome agreement or stop','working_scope':'tau=1 cases only after all base exact assessments and tau gates; hold selected config fixed, preinventory AD/FD branches for each candidate, mark nonselected branches not_applicable, never silently omit slots','branches':branches,'each_branch_required_quantities':['input','alpha','dt','h','direction','rhos','coefficients','output','objective','zero_pattern'],'base_extra_quantities':['input_AD','order_AD','directional_AD'],'per_base_candidate_exact_slots':cand_q,'per_branch_binding':'case+candidate+mode+branch+quantity, actual returned fit producer/config/source; scalar h at base explicit not_applicable; q fixed from base; branch output is fit->apply+scale composition','comparisons':'all 10 dtype policies in comparison-policies.json for EACH selected tau1 case, both modes where applicable; all h/adjacent pairs; full forward vs D each mode. Per candidate base forward recursive vs exact D_hat for ALL 3 candidates; forward eager/JIT for ALL 3; base exact bound gates for both modes. Alpha-perturbed branches have no alpha=1/2 rational oracle.','slot_id_rule':'{mode}-{supplied-index}-{branch}-{quantity}, case_id plus slot_id is globally unique'},
 'shortcut_controls':[{'case_ref':'REF-FAIL-f64-GL','omission':'normalization','expected':'mutant_B=1/8 falsely <=3/16; required reject mutation'},{'case_ref':'REF-FAIL-f64-GL','omission':'initial_increment','expected':'mutant_B=0 falsely qualifies; required reject mutation'},{'case_ref':'EDGE-changed-f64-GL','omission':'absolute_variation','expected':'signed v[0]+v[1]=-1 at final row underbounds; required reject mutation'},{'case_ref':'EDGE-missing-row-f64-GL','omission':'intermediate_evidence_row','expected':'completeness failure, not necessarily changed numerical decision'},{'case_ref':'RANK-00-f64-GL','omission':'supplied_candidate','expected':'inventory mismatch, indeterminate; no first-success assertion'}],
 'counts':{'cases':len(cases),'arrays':len(arrays),'candidate_specs':len(candidates),'parse_controls':len(parse_controls),'groups':{g:sum(c['group']==g for c in cases) for g in sorted({c['group'] for c in cases})}}}
write('fixtures.json',fixture)
print(json.dumps(fixture['counts'],sort_keys=True))
