"""Bounded stdlib planning checks, not the future validator/selector/worker."""
from pathlib import Path
from fractions import Fraction as F
import collections,hashlib,itertools,json,math,re,struct,tarfile
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');A=R/'docs/validation/audits/a2-preparation-2026-11-11';S=Path(__file__).parent
H=lambda b:hashlib.sha256(b).hexdigest()
def rat(x):
    x=F(x);return {'num':('-' if x<0 else '')+format(abs(x.numerator),'x'),'den':format(x.denominator,'x')}
def frac(x):return F(int(x['num'],16),int(x['den'],16))
def readarray(a):
    b=bytes.fromhex(a['raw_hex']);assert len(b)==a['nbytes'];assert H(b)==a['sha256'];assert len(b)==math.prod(a['shape'])*({'float32':4,'float64':8,'complex64':8,'complex128':16}[a['dtype']])
    code='f' if a['dtype'] in ['float32','complex64'] else 'd';fmt=('<' if a['byte_order']=='little' else '>')+code
    return [F(v[0]) if math.isfinite(v[0]) else None for v in struct.iter_unpack(fmt,b)]
f=json.loads((A/'fixtures.json').read_text());p=json.loads((A/'protocol.json').read_text());pol=json.loads((A/'comparison-policies.json').read_text());sch=json.loads((A/'record-schemas.json').read_text())
assert len(f['cases'])==f['counts']['cases']==544
assert dict(collections.Counter(c['group'] for c in f['cases']))==f['counts']['groups']
assert len(f['arrays'])==832 and len(f['candidates'])==160
assert len({c['case_id'] for c in f['cases']})==544
idpat=re.compile(p['identity']['id_regex'],re.ASCII)
for c in f['cases']:assert idpat.fullmatch(c['case_id'])
for key,c in f['candidates'].items():assert key==c['stable_id'] and idpat.fullmatch(key)
raw_count=0
def walk(o):
    global raw_count
    if isinstance(o,dict):
        if isinstance(o.get('raw_hex'),str):readarray(o);raw_count+=1
        if set(o)=={'num','den'} and isinstance(o['num'],str):
            assert re.fullmatch(r'(0|-?[1-9a-f][0-9a-f]*)',o['num']);assert re.fullmatch(r'[1-9a-f][0-9a-f]*',o['den'])
            n=int(o['num'],16);d=int(o['den'],16)
            # Deliberate noncanonical negative tau fixture is allowed only as a declared raw mutation.
            if math.gcd(abs(n),d)!=1 or (n==0 and d!=1): pass
        for v in o.values():walk(v)
    elif isinstance(o,list):
        for v in o:walk(v)
walk(f);walk(pol)
policies={x['policy_id']:x for x in pol['policies']};assert len(policies)==20
slot_sum=comp_sum=bind_sum=0;metadata_sizes=[];failure_sizes=[]
for c in f['cases']:
    slots=c['required_evidence_slots'];ids={s['slot_id'] for s in slots};assert len(ids)==len(slots)
    assert len(slots)<=2048
    for s in slots:assert idpat.fullmatch(s['slot_id']) and s['quantity'] in sch['$defs']['slot']['properties']['quantity']['enum']
    for x in c.get('required_working_comparisons',[]):
        assert idpat.fullmatch(x['comparison_id']) and x['policy_id'] in policies
        if x['initial_status']!='not_applicable':assert x['a_slot_id'] in ids and x['reference_slot_id'] in ids
    checks=c.get('required_working_comparisons',[]);assert len({x['comparison_id'] for x in checks})==len(checks)
    slot_sum+=len(slots);comp_sum+=len(checks);bind_sum+=len(c.get('required_fit_identity_checks',[]))
    # Render INVENTORY metadata only, with no fabricated fitter outputs or run receipt.
    inv=[{'slot_id':x['slot_id'],'candidate_id':c['request']['candidate_refs'][x['candidate_index']] if x['candidate_index'] is not None else None,'mode':x['mode'],'branch':x['branch'],'quantity':x['quantity']} for x in slots]
    failure=[]
    for row in inv:
        ar=f['arrays'][c['request']['input_ref']];n=ar['shape'][0];qty=row['quantity'];ci=next(v['candidate_index'] for v in slots if v['slot_id']==row['slot_id']);pp=f['candidates'][c['request']['candidate_refs'][ci]]['configuration']['pole_count'] if ci is not None else 1
        expected=([n,n] if qty=='L_hat' else [n] if qty in ['w','g','g_hat','residual','signed_fitted_weights'] else [pp] if qty in ['rhos','coefficients','zero_pattern'] else [] if qty in ['epsilon','alpha','dt','h','objective','order_AD','directional_AD','input_FD','order_FD'] else ar['shape'])
        # Width-only upper template, NOT an observed artifact/hash or runtime result.
        failure.append(dict(row,status='complete',reason='none',expected_shape=expected,completed_shape=expected,artifact={'path':'arrays/'+row['slot_id']+'.json','bytes':16777216,'sha256':'f'*64}))
    metadata_sizes.append(len(json.dumps(inv,separators=(',',':')).encode()))
    failure_sizes.append(len(json.dumps(failure,separators=(',',':')).encode()))
assert slot_sum==24128 and comp_sum==1312 and bind_sum==1056
for name,d in sch['$defs'].items():
    if d.get('type')=='object':assert d['additionalProperties'] is False and set(d['required'])==set(d['properties'])
for x in sch['oneOf']:assert x['$ref'].removeprefix('#/$defs/') in sch['$defs']
assert max(metadata_sizes)<p['caps']['input_bundle_bytes']
assert max(failure_sizes)<p['caps']['failure_index_bytes']
# Independent finite exact formula checks for all unmutated in-domain synthetic cases.
witness=[];outputs=gradient_components=fd_checks=case_count=assessment_count=0;planning_outcomes=collections.Counter()
for c in f['cases']:
    if c['group']=='FIT-REAL' or c['mutations'] or c['resource_control'] or c['group']=='REF-CAPS':continue
    if c['expected']['request_status']=='invalid_request':continue
    rq=c['request']; a=f['arrays'][rq['input_ref']];n=a['shape'][0];m=a['shape'][1] if len(a['shape'])==2 else 1
    x=readarray(a);tau=frac(rq['tau']);g=[F(math.comb(2*k,k),4**k) for k in range(n)];w=[F(1)]+[-g[k]/(2*k-1) for k in range(1,n)]
    for k in range(n):assert g[k]==sum(w[:k+1])
    for k in range(1,n):assert w[k]==w[k-1]*F(2*k-3,2*k) and g[k]==g[k-1]*F(2*k-1,2*k)
    v=[x[i*m+j]-(x[(i-1)*m+j] if i else 0) for i in range(n) for j in range(m)]
    D=[2*sum(w[k]*x[(i-k)*m+j] for k in range(i+1)) for i in range(n) for j in range(m)]
    assert D==[2*sum(g[k]*v[(i-k)*m+j] for k in range(i+1)) for i in range(n) for j in range(m)]
    eligible_planning=[];rows=[]
    for key in rq['candidate_refs']:
        cs=f['candidates'][key];rho=readarray(f['arrays'][cs['rhos_ref']]);coef=readarray(f['arrays'][cs['coefficients_ref']]);assert cs['configuration']['n']==n
        gh=[F(1)]+[sum(cc*rr**(k-1) for cc,rr in zip(coef,rho)) for k in range(1,n)];eps=max(abs(a-b) for a,b in zip(gh,g));wh=[gh[k]-(gh[k-1] if k else 0) for k in range(n)]
        dh=[2*sum(gh[k]*v[(i-k)*m+j] for k in range(i+1)) for i in range(n) for j in range(m)]
        assert dh==[2*sum(wh[k]*x[(i-k)*m+j] for k in range(i+1)) for i in range(n) for j in range(m)]
        errors=[a-b for a,b in zip(dh,D)];B=[2*eps*sum(abs(v[k*m+j]) for k in range(i)) for i in range(n) for j in range(m)]
        assert errors==[2*sum((gh[k]-g[k])*v[(i-k)*m+j] for k in range(1,i+1)) for i in range(n) for j in range(m)]
        assert all(abs(a)<=b for a,b in zip(errors,B))
        assert all(B[i*m+j]<=B[(i+1)*m+j] for i in range(n-1) for j in range(m))
        L=[[2*wh[i-j] if j<=i else F(0) for j in range(n)] for i in range(n)]
        grad=[F(2,n*m)*sum(L[i][j]*dh[i*m+k] for i in range(n)) for j in range(n) for k in range(m)]
        q=[F((j%5)-2,16) for j in range(n*m)];h=F(1,128)
        def objective(xx):return sum((sum(L[i][j]*xx[j*m+k] for j in range(n)))**2 for i in range(n) for k in range(m))/(n*m)
        fd=(objective([a+h*b for a,b in zip(x,q)])-objective([a-h*b for a,b in zip(x,q)]))/(2*h)
        assert fd==sum(a*b for a,b in zip(grad,q))
        qual=all(b<=tau for b in B)
        if qual:eligible_planning.append((len(rho),key))
        rows.append({'candidate_id':key,'epsilon':rat(eps),'D_hat':[rat(x) for x in dh],'error':[rat(x) for x in errors],'B':[rat(x) for x in B],'analytic_input_gradient':[rat(x) for x in grad],'quadratic_planning_FD':rat(fd),'qualifies':qual})
        outputs+=n*m;gradient_components+=len(grad);fd_checks+=1;assessment_count+=1
    planned_id=min(eligible_planning)[1] if eligible_planning else None
    planned_status='selected' if planned_id else 'no_supplied_candidate_meets_bound'
    assert planned_status==c['expected']['request_status'],c['case_id']
    assert planned_id==c['expected']['selected_id'],c['case_id']
    planning_outcomes[planned_status]+=1;case_count+=1
    witness.append({'case_id':c['case_id'],'D':[rat(x) for x in D],'planning_only':True,'candidate_expectations':rows})
# The supplied rank list covers all permutations, no monotone or first-success shortcut.
for d,op in itertools.product(['f32','f64'],['GL','RL']):
    rows=[c for c in f['cases'] if c['group']=='REF-RANK' and c['case_id'].startswith('RANK-') and 'smaller' not in c['case_id'] and c['case_id'].endswith(d+'-'+op)]
    assert len(rows)==24 and len({tuple(x['request']['candidate_refs']) for x in rows})==24
# Portable archive identity and failed verdict lineage.
prev=json.loads((A/'initial-contract-reviews-preservation.json').read_text())
with tarfile.open(A/'initial-contract-reviews-failed.tar.gz','r:gz') as archive:
    members={m.name:m for m in archive.getmembers() if m.isfile()}
    assert len(members)==len(prev['files'])==66
    for name,identity in prev['files'].items():
        b=archive.extractfile(members[name]).read();assert H(b)==identity['sha256'] and len(b)==identity['bytes']
assert prev['passed'] is False and all(v['passed'] is False for v in prev['reviews'].values())
assert float(F(1,4))==float(F(1,4)-F(1,2**100)) and F(1,4)-F(1,2**100)<F(1,4)
# Every future real case is nonzero and has exact prescribed call order and pending arrays.
for c in f['cases']:
    if c['group']=='FIT-REAL':
        assert any(readarray(f['arrays'][c['request']['input_ref']]))
        assert [f['candidates'][k]['configuration']['pole_count'] for k in c['request']['candidate_refs']]==[8,2,4]
        for k in c['request']['candidate_refs']:assert f['candidates'][k]['rhos_ref'] is None and f['candidates'][k]['coefficients_ref'] is None
# Raw negative parser controls are planning inputs, NOT a tested production parser.
parse_classified=0
for pc in f['parse_controls']:
    raw=bytes.fromhex(pc['raw_utf8_hex']);assert H(raw)==pc['sha256']
    if pc['case_id'] in ['PARSE-duplicate-key','PARSE-nan','PARSE-inf']:
        seen=[]
        def pairs(items):
            assert len({k for k,v in items})==len(items)
            return dict(items)
        try:
            json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
        except (AssertionError,ValueError):pass
        else:raise AssertionError(pc['case_id'])
    else:
        value=json.loads(raw)
        if 'n' in value:assert type(value['n']) is not int
        elif 'exact_head' in value:assert type(value['exact_head']) is not bool
        else:
            n,d=value['num'],value['den']
            canonical=bool(re.fullmatch(r'(0|-?[1-9a-f][0-9a-f]*)',n) and re.fullmatch(r'[1-9a-f][0-9a-f]*',d))
            if canonical:canonical=math.gcd(abs(int(n,16)),int(d,16))==1 and (int(n,16)!=0 or d=='1')
            assert not canonical
    parse_classified+=1
assert parse_classified==10
for c in f['candidates'].values():
    if 'producer' in c:
        src=c['producer']['source'];assert H((R/src['repo_path']).read_bytes())==src['sha256']
    else:
        src=c['producer_call']['source'];assert H((R/src['repo_path']).read_bytes())==src['sha256']
# ID-free tuples for the declared identity controls: no selection logic or execution claim.
def content(candidate):
    return (candidate['configuration'],candidate['producer'],tuple((k,v) for k,v in f['arrays'][candidate['rhos_ref']].items() if k!='raw_hex'),tuple((k,v) for k,v in f['arrays'][candidate['coefficients_ref']].items() if k!='raw_hex'))
assert content(f['candidates']['a-good2-f64-GL'])==content(f['candidates']['copy-good2-f64-GL'])
assert content(f['candidates']['a-good2-f64-GL'])!=content(f['candidates']['good3-f64-GL'])
assert bytes.fromhex(f['identity_controls'][0]['left_hex'])!=bytes.fromhex(f['identity_controls'][0]['right_hex'])
assert struct.unpack('<d',bytes.fromhex(f['identity_controls'][0]['left_hex']))[0]==struct.unpack('<d',bytes.fromhex(f['identity_controls'][0]['right_hex']))[0]
assert f['identity_controls'][1]['permutation']==[1,0]
(S/'exact-planning-witnesses.json').write_text(json.dumps(witness,separators=(',',':'))+'\n')
summary={'kind':'static_packet_and_exact_synthetic_planning_checks_NOT_production_validation','counts':f['counts'],'raw_array_occurrences_checked':raw_count,'comparison_policy_count':len(policies),'raw_parse_controls_classified':parse_classified,'identity_controls_checked':4,'synthetic_and_actual_producer_source_bindings_checked':len(f['candidates']),'unmutated_synthetic_cases_exactly_checked':case_count,'synthetic_candidate_assessments_exactly_checked':assessment_count,'scalar_time_feature_outputs_checked':outputs,'analytic_gradient_components_checked':gradient_components,'synthetic_direction_quadratic_FD_equalities':fd_checks,'synthetic_direction_note':'dyadic planning direction, NOT observed cos(x) worker output','planning_outcomes':dict(planning_outcomes),'max_compact_inventory_bytes_only':max(metadata_sizes),'max_compact_failure_slot_bytes_only':max(failure_sizes),'metadata_size_limit':'inventory/slot metadata only; not a full runtime export feasibility certificate','archived_original_files_verified':66,'tau_equal_vs_less_by_2_to_minus_100_exact_and_float_collapse':True,'fit_real_numerical_executions':0,'implementation_authorized':False,'a2_acceptance_passed':False}
(S/'planning-checks.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,sort_keys=True))
