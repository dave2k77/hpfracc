from pathlib import Path
import hashlib,json,shutil,subprocess
from html.parser import HTMLParser
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');A=R/'docs/validation/audits/a2-preparation-2026-11-11';S=Path(__file__).parent
H=lambda b:hashlib.sha256(b).hexdigest()
before=json.loads((S/'before.json').read_text());pin=json.loads((S/'preparation-inputs.raw.json').read_text())
for name,h in pin['baseline_numeric_inputs'].items():assert H((R/name).read_bytes())==h,name
idx=subprocess.check_output(['git','ls-files','--stage'],cwd=R);(S/'index-after.raw').write_bytes(idx)
assert idx==(S/'index-before.raw').read_bytes() and H(idx)==pin['index_entries_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==pin['head']
for name,ident in before['preserved_existing_files'].items():
    raw=(R/name).read_bytes();assert H(raw)==ident['sha256'] and len(raw)==ident['bytes']
    target=S/'before-preserved-readback'/Path(name).name;target.parent.mkdir(exist_ok=True);target.write_bytes(raw)
for path in ['AGENTS.md','v0.1_engineering_contract.md']:
    committed=subprocess.check_output(['git','show',pin['head']+':'+path],cwd=R);assert (R/path).read_bytes()==committed,path
old=(S/'protocol-before.raw.md').read_text();new=(R/'docs/developer/a2-compression-budget-protocol.md').read_text()
assert old.split('## 4. Exact finite mathematical contract')[1].split('## 5. Identity')[0]==new.split('## 4. Exact finite mathematical contract')[1].split('## 5. Explicit')[0]
assert 'phase-a-completion.md#a2-history-approximation-and-memory--open' not in new
assert 'phase-a-completion.md#a2-history-approximation-and-memory-open' in new
class P(HTMLParser):
    def __init__(self):super().__init__();self.ids=set()
    def handle_starttag(self,tag,attrs):
        for k,v in attrs:
            if k=='id':self.ids.add(v)
p=P();p.feed((S/'site/developer/phase-a-completion/index.html').read_text())
assert 'a2-history-approximation-and-memory-open' in p.ids
assert json.loads((S/'strict-docs-final.process.json').read_text())['exit_code']==0
m=json.loads((A/'packet-manifest.json').read_text());files=m['files']
assert len(files)==6 and len({x['repo_path'] for x in files})==6
for f in files:
    b=(R/f['repo_path']).read_bytes();assert H(b)==f['sha256'] and len(b)==f['bytes']
assert str((A/'packet-manifest.json').relative_to(R)) not in {x['repo_path'] for x in files}
newpaths=[x['repo_path'] for x in files]+[str((A/'packet-manifest.json').relative_to(R))]
identities=[]
for name in newpaths:
    b=(R/name).read_bytes();assert b.endswith(b'\n') and all(line.rstrip(b' \t')==line for line in b.splitlines()),name
    target=S/'after-bytes'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
    identities.append({'repo_path':name,'sha256':H(b),'bytes':len(b)})
commands=[]
for label,cmd in [('diff-check',['git','diff','--check']),('status-after',['git','status','--short'])]:
    proc=subprocess.run(cmd,cwd=R,capture_output=True);assert proc.returncode==0
    (S/(label+'.stdout.raw')).write_bytes(proc.stdout);(S/(label+'.stderr.raw')).write_bytes(proc.stderr)
    commands.append({'command':cmd,'exit_code':proc.returncode,'stdout_sha256':H(proc.stdout),'stderr_sha256':H(proc.stderr)})
checks=json.loads((S/'planning-checks.json').read_text())
summary={'status':'corrected_DRAFT_pending_independent_re_review_and_owner_approval','numeric_inputs_unchanged':125,'git_index_byte_identical':True,'head_unchanged':pin['head'],'existing_archive_and_preservation_byte_identical':True,'exact_math_section_byte_identical':True,'known_anchor_verified_in_built_HTML':True,'AGENTS_and_engineering_contract_equal_HEAD':True,'new_text_whitespace_checks_passed':7,'strict_docs_exit_code':0,'planning_exit_code':json.loads((S/'planning-reviewed-packet.process.json').read_text())['exit_code'],'planning':checks,'modified_or_created_repository_files':identities,'commands':commands,'parent_owned_tracker_programme_not_edited_by_this_task':True,'no_src_benchmarks_tests_dependency_or_index_edits':True,'no_numerical_fitter_apply_AD_benchmark_GPU_jobs':True,'implementation_authorized':False,'a2_acceptance_passed':False,'total_numerical_certified':False}
(S/'after.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,sort_keys=True))
