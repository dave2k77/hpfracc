from pathlib import Path
import hashlib,json
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');A=R/'docs/validation/audits/a2-preparation-2026-11-11'
p=A/'fixtures.json';f=json.loads(p.read_text())
for c in f['cases']:
    if c['group']!='FIT-REAL' or c['request']['tau']['num']!='1':continue
    slots=c['required_evidence_slots'];slots[:]=[s for s in slots if not(s['branch']=='base' and s['quantity'] in ['input_AD','order_AD','directional_AD'])]
    for mode in ['eager','jit']:
        for i in range(3):
            for q in ['input','alpha','dt','h','direction','rhos','coefficients','output','objective','zero_pattern','input_AD','order_AD','directional_AD']:
                slots.append({'slot_id':mode+'-'+str(i)+'-ad-base-'+q,'candidate_index':i,'mode':mode,'branch':'ad-base','quantity':q,'initial_status':'not_evaluated'})
            c['required_fit_identity_checks'].append({'mode':mode,'candidate_index':i,'branch':'ad-base','reference_branch':'base','comparison':'actual_rhos_coefficients_input_alpha_dt_identity_to_same_mode_base','initial_status':'not_evaluated','scope':'selected_only_other_candidates_explicit_not_applicable'})
            c['required_working_comparisons'].append({'comparison_id':mode+'-'+str(i)+'-ad-forward_recursive_exact','policy_id':f['arrays'][c['request']['input_ref']]['dtype']+'-forward_recursive_exact','candidate_index':i,'mode':mode,'branch':'ad-base','scope':'selected_only_others_explicit_not_applicable','initial_status':'not_evaluated','a_slot_id':mode+'-'+str(i)+'-ad-base-output','reference_slot_id':mode+'-'+str(i)+'-exact-D_hat'})
    for ch in c['required_working_comparisons']:
        for k in ['a_slot_id','reference_slot_id']:
            if ch[k] is not None:
                for q in ['input_AD','order_AD','directional_AD']:
                    if ch[k].endswith('-base-'+q):ch[k]=ch[k].replace('-base-'+q,'-ad-base-'+q)
f['real_worker_inventory']['AD_composition']='After exhaustive base selection, selected-mode ad-base is ONE value_and_grad(objective,argnums=(input,alpha),has_aux=True) composition returning both cotangents and actual fit/output/objective auxiliaries. This records derivatives of fit->apply+dt**(-alpha), with fit independent of input. Preserve ad-base arrays as a separate observation, not borrowed base/eager bytes; authenticated equality with SAME-mode base is a required gate before exact-reference cache reuse. Never run selection inside AD. h is unused at ad-base and explicitly not_applicable. Future implementation may choose equivalent joint differentiation only if same-forward auxiliaries are retained and reviewed.'
f['counts']['required_evidence_slots']=sum(len(c['required_evidence_slots']) for c in f['cases']);f['counts']['max_slots_per_case']=max(len(c['required_evidence_slots']) for c in f['cases']);f['counts']['working_comparison_slots']=sum(len(c.get('required_working_comparisons',[])) for c in f['cases']);f['counts']['fit_identity_check_slots']=sum(len(c.get('required_fit_identity_checks',[])) for c in f['cases'])
p.write_text(json.dumps(f,indent=2)+'\n')
p=A/'record-schemas.json';s=json.loads(p.read_text());d=s['$defs']
d['binding_check']={'type':'object','additionalProperties':False,'required':['record_type','case_id','candidate_id','mode','branch','reference_branch','observation_id','reference_observation_id','comparison','status','reasons'],'properties':{'record_type':{'enum':['binding_check']},'case_id':d['id'],'candidate_id':d['id'],'mode':{'enum':['eager','jit']},'branch':d['id'],'reference_branch':d['id'],'observation_id':{'anyOf':[d['id'],{'type':'null'}]},'reference_observation_id':{'anyOf':[d['id'],{'type':'null'}]},'comparison':{'enum':['actual_rhos_and_coefficients_raw_identity_to_same_mode_base','actual_returned_fit_source_configuration_and_actual_alpha_dt_binding','actual_rhos_coefficients_input_alpha_dt_identity_to_same_mode_base']},'status':{'enum':['pass','fail','unknown','not_evaluated','not_applicable']},'reasons':d['comparison']['properties']['reasons']}}
s['oneOf'].append({'$ref':'#/$defs/binding_check'})
s['x-canonical-parse-predicate'].append('AD uses a distinct ad-base observation as explicitly inventoried. Retain its actual auxiliary rhos/coefficients/output together with joint input/order cotangents from the same forward composition. Exact base-reference cache reuse is permitted only after authenticated SAME-mode raw input/fit/alpha/dt equality; no cross-mode borrowing. Binding_check records are complete for every predeclared fit identity check, including unknown/not_evaluated/not_applicable outcomes.')
s['x-canonical-parse-predicate'].append('Source repo_path is a bounded relative POSIX path, with no empty, dot or dot-dot component, absolute prefix, drive prefix or backslash; resolve only under repository root. Synthetic producer source denotes the preparation-contract specification, not the production fitter or a claimed JAX execution. Actual-fitter producer source is the pinned _soe.py bytes. Every received raw input or candidate error is preserved as bounded raw data, never a coercion of unknown bytes.')
p.write_text(json.dumps(s,indent=2)+'\n')
p=R/'docs/developer/a2-compression-budget-protocol.md';t=p.read_text().replace('23,168\nevidence slots and 1,216 working-comparison slots','24,128\nevidence slots and 1,312 working-comparison slots').replace('894 evidence','954 evidence')
t=t.replace('invocation. Base auxiliary arrays used for gradient/reference binding must match','invocation. The selected ad-base observation jointly returns both input/order\ncotangents and actual forward auxiliaries, separately from base selection.\nRetain its own arrays and require authenticated same-mode input/fit/alpha/dt\nidentity before reusing an exact reference cache. Base auxiliary arrays used\nfor gradient/reference binding must match')
p.write_text(t)
# Synthetic origin is the actual specification, not a false claim to have called the fitter.
docsource={'repo_path':'docs/developer/a2-compression-budget-protocol.md','sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
p=A/'fixtures.json';f=json.loads(p.read_text())
for c in f['candidates'].values():
    if c.get('producer',{}).get('kind')=='synthetic_control':c['producer']['source']=docsource
p.write_text(json.dumps(f,indent=2)+'\n')
print(json.dumps(f['counts'],sort_keys=True))
