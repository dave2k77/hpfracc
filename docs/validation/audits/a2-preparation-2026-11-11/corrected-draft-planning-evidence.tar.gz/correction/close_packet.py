from pathlib import Path
import json
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');A=R/'docs/validation/audits/a2-preparation-2026-11-11'
p=A/'fixtures.json';f=json.loads(p.read_text())
for c in f['cases']:
    if c['case_id'].startswith('EDGE-changed-'):c['request']['tau']={'num':'1','den':'4'}
    if c['group']!='FIT-REAL':continue
    d=f['arrays'][c['request']['input_ref']]['dtype'];tau1=c['request']['tau']['num']=='1';checks=c['required_working_comparisons']
    if d=='float64' and tau1:
        for i in range(3):
            for mode in ['eager','jit']:
                for axis in ['input','order']:
                    checks.append({'comparison_id':mode+'-'+str(i)+'-'+axis+'-adjNA','policy_id':d+'-'+axis+'_FD_adjacent','candidate_index':i,'mode':mode,'branch':axis+'-no-adjacent-pair','scope':'not_applicable_single_FD_step'})
    for ch in checks:
        i=ch['candidate_index'];mode=ch['mode'];kind=ch['policy_id'].removeprefix(d+'-');base=(mode+'-'+str(i)+'-base-') if i is not None else None
        ch['initial_status']='not_evaluated';ch['a_slot_id']=None;ch['reference_slot_id']=None
        if ch['scope']=='not_applicable_single_FD_step':
            ch['initial_status']='not_applicable';continue
        if kind=='forward_recursive_exact':ch['a_slot_id']=base+'output';ch['reference_slot_id']=mode+'-'+str(i)+'-exact-D_hat'
        elif kind=='forward_full_exact':ch['a_slot_id']=mode+'-X-base-full_output';ch['reference_slot_id']='S-X-D'
        elif kind=='forward_eager_jit':ch['a_slot_id']='jit-'+str(i)+'-base-output';ch['reference_slot_id']='eager-'+str(i)+'-base-output'
        elif kind=='input_grad_analytic':ch['a_slot_id']=base+'input_AD';ch['reference_slot_id']=mode+'-'+str(i)+'-exact-analytic_input_gradient'
        elif kind in ['input_grad_eager_jit','order_grad_eager_jit']:
            qty='input_AD' if kind.startswith('input') else 'order_AD';ch['a_slot_id']='jit-'+str(i)+'-base-'+qty;ch['reference_slot_id']='eager-'+str(i)+'-base-'+qty
        elif kind.endswith('_FD_AD'):
            axis=kind.split('_')[0];ch['a_slot_id']=base+('directional_AD' if axis=='input' else 'order_AD');ch['reference_slot_id']=mode+'-'+str(i)+'-'+ch['branch']+'-FD'
        elif kind.endswith('_FD_adjacent'):
            axis=kind.split('_')[0];parts=ch['branch'].split('-');ch['a_slot_id']=mode+'-'+str(i)+'-'+axis+'-'+parts[2]+'-FD';ch['reference_slot_id']=mode+'-'+str(i)+'-'+axis+'-'+parts[1]+'-FD'
        else:raise AssertionError(kind)
    c['required_fit_identity_checks']=[{'mode':mode,'candidate_index':i,'branch':br,'reference_branch':'base','comparison':'actual_rhos_and_coefficients_raw_identity_to_same_mode_base' if br.startswith('input-') else 'actual_returned_fit_source_configuration_and_actual_alpha_dt_binding','initial_status':'not_evaluated','scope':'all_candidates_base_or_selected_only_perturbation'} for mode in ['eager','jit'] for i in range(3) for br in f['real_worker_inventory']['branches'][d] if tau1 or br=='base']
f['identity_controls'][0]['base_candidate_ref']='bad1-f64-GL';f['identity_controls'][0]['replace_field']='coefficients';f['identity_controls'][0]['left_and_right_producer']='same declared producer/configuration; only coefficient raw zero sign differs'
f['shortcut_controls'][2]['expected']='tau=1/4: signed prefix v0=1,v0+v1=-1 (even after outer abs) falsely qualifies; true absolute variation at final row=3, B=3/4 rejects'
f['shortcut_controls'].append({'case_ref':'EDGE-stacked-f64-GL','omission':'failed_feature_0','expected':'remaining feature is zero, false qualification; shape/component inventory must reject mutation'})
f['counts']['working_comparison_slots']=sum(len(c.get('required_working_comparisons',[])) for c in f['cases'])
f['counts']['fit_identity_check_slots']=sum(len(c.get('required_fit_identity_checks',[])) for c in f['cases'])
p.write_text(json.dumps(f,indent=2,allow_nan=False)+'\n')
p=A/'record-schemas.json';s=json.loads(p.read_text())
s['x-canonical-parse-predicate'].append('Comparison records must exactly bind a_slot_id and reference_slot_id as enumerated in fixtures; singleton FD adjacency is an explicit not_applicable comparison with null operand IDs. It is not a missing row. Exact full D is independent of candidate, hence candidate_id may be null.')
s['$defs']['comparison']['properties']['a_slot_id']={'anyOf':[s['$defs']['id'],{'type':'null'}]};s['$defs']['comparison']['properties']['reference_slot_id']={'anyOf':[s['$defs']['id'],{'type':'null'}]}
s['x-canonical-parse-predicate'].append('Each future actual-fit base/perturbation additionally has a preinventoried fit identity check in fixtures. Input perturbations require same-mode fit raw identity; order perturbations require source/config binding to actual strong perturbed alpha and recomputed dt**(-alpha), not equality to base coefficients. Preserve all check outcomes, including nonselected not_applicable entries.')
p.write_text(json.dumps(s,indent=2)+'\n')
p=R/'docs/developer/a2-compression-budget-protocol.md';t=p.read_text().replace('1,120 working-comparison slots','1,216 working-comparison slots');p.write_text(t)
print(json.dumps(f['counts'],sort_keys=True))
