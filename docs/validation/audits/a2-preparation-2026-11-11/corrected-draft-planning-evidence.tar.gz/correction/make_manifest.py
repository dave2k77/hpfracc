from pathlib import Path
import hashlib,json
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');A=R/'docs/validation/audits/a2-preparation-2026-11-11';S=Path(__file__).parent
names=['docs/developer/a2-compression-budget-protocol.md']+[str((A/n).relative_to(R)) for n in ['protocol.json','fixtures.json','comparison-policies.json','record-schemas.json','packet-notes.md']]
H=lambda b:hashlib.sha256(b).hexdigest()
f=json.loads((A/'fixtures.json').read_text())
manifest={'protocol_id':'a2-glrl-exact-reference-v1-draft','status':'corrected_DRAFT_pending_independent_re_review_and_owner_approval','path_base':'repository_root','implementation_authorized':False,'a2_acceptance_passed':False,'total_numerical_certified':False,'arithmetic_verified':False,'files':[{'repo_path':n,'bytes':len((R/n).read_bytes()),'sha256':H((R/n).read_bytes())} for n in names],'self_hash_excluded':True,'closed_planning_counts':f['counts'],'preserved_failed_review_archive':{'repo_path':str((A/'initial-contract-reviews-failed.tar.gz').relative_to(R)),'sha256':H((A/'initial-contract-reviews-failed.tar.gz').read_bytes())},'preservation_record':{'repo_path':str((A/'initial-contract-reviews-preservation.json').relative_to(R)),'sha256':H((A/'initial-contract-reviews-preservation.json').read_bytes())},'not_execution_evidence':True}
p=A/'packet-manifest.json'
if p.exists():json.loads(p.read_text())
p.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifest_sha256':H(p.read_bytes()),'files':manifest['files'],'counts':manifest['closed_planning_counts']},sort_keys=True))
