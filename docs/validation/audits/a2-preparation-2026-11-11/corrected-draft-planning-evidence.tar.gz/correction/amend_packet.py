from pathlib import Path
import json
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');A=R/'docs/validation/audits/a2-preparation-2026-11-11';S=Path(__file__).parent
p=A/'record-schemas.json';x=json.loads(p.read_text());d=x['$defs']
d['configuration']['properties']['pole_count']['maximum']=512
d['raw_array']['properties']['dtype']['enum']+=['complex64','complex128']
d['comparison']['properties']['candidate_id']={'anyOf':[{'$ref':'#/$defs/id'},{'type':'null'}]}
b=d['input_bundle'];b['properties']['request']={'anyOf':[{'$ref':'#/$defs/request'},{'type':'null'}]}
d['inventory_entry']={'type':'object','additionalProperties':False,'required':['slot_id','candidate_id','mode','branch','quantity'],'properties':{'slot_id':d['id'],'candidate_id':{'anyOf':[d['id'],{'type':'null'}]},'mode':d['slot']['properties']['mode'],'branch':d['id'],'quantity':d['slot']['properties']['quantity']}}
b['properties']['required_slots']['items']={'$ref':'#/$defs/inventory_entry'}
b['properties'].update({'raw_request_utf8_hex':{'type':'string','pattern':'^(?:[0-9a-f]{2})*$','maxLength':524288},'raw_request_sha256':{'$ref':'#/$defs/sha'},'candidate_ids':{'type':'array','items':{'$ref':'#/$defs/id'},'minItems':0,'maxItems':32}});b['required']=list(b['properties'])
x['x-canonical-parse-predicate'][0]+=' raw_request_utf8_hex is a bounded escape exception (<=524288 hex characters), but the WHOLE serialized input bundle must still fit 262144 bytes including that copy; do not duplicate raw bytes unnecessarily.'
x['x-canonical-parse-predicate'].append('Apply field-type failure at its ownership boundary: request/global metadata errors invalidate request; authenticated candidate-local errors are known-ineligible. Structurally valid out-of-tiny-domain values are unsupported_reference, not malformed. Parsed request may be null when raw input cannot form a canonical request record; bounded raw request bytes plus explicit ID/slot inventory preserve the error without coercing invalid fields. Request JSON duplicate keys/nonfinite number tokens are global syntax failures; nonfinite IEEE bytes inside authenticated arrays are candidate-local numeric failures.')
x['x-canonical-parse-predicate'].append('Working quantity shapes: input/v/D/D_hat/error/B/analytic_input_gradient/output/full_output/input_AD/direction = input shape; w/g/g_hat/residual/signed_fitted_weights = [N]; L_hat = [N,N]; rhos/coefficients/zero_pattern = [P]; epsilon/alpha/dt/h/objective/order_AD/directional_AD/input_FD/order_FD = []. zero_pattern is an exact 0/1 rational vector derived from returned coefficients, not an untyped JSON boolean/float coercion. Full-output comparison has candidate_id=null. Nonselected preinventoried working branches and singleton FD adjacency are explicitly not_applicable, never missing.')
x['x-canonical-parse-predicate'][4]=x['x-canonical-parse-predicate'][4].replace('itemsize','itemsize (float32=4, float64=8, complex64=8, complex128=16; complex input is structurally decodable but unsupported by this reference)')
p.write_text(json.dumps(x,indent=2)+'\n')
p=A/'fixtures.json';x=json.loads(p.read_text())
x['identity_controls']=[
 {'case_id':'IDENTITY-signed-zero','dtype':'float64','shape':[1],'left_hex':'0000000000000000','right_hex':'0000000000000080','expected':'distinct content identities despite equal decoded rational zero'},
 {'case_id':'IDENTITY-pole-permutation','candidate_ref':'a-good2-f64-GL','permutation':[1,0],'expected':'distinct content identities; no pole sort'},
 {'case_id':'IDENTITY-equivalent-kernel','candidate_refs':['a-good2-f64-GL','good3-f64-GL'],'expected':'distinct content identities; no zero-coefficient pruning or equal-kernel merge'},
 {'case_id':'IDENTITY-duplicate-renamed','candidate_refs':['a-good2-f64-GL','copy-good2-f64-GL'],'expected':'equal ID-free content, request-invalid even with distinct stable IDs'}]
x['counts']['identity_controls']=len(x['identity_controls'])
x['counts']['required_evidence_slots']=sum(len(c['required_evidence_slots']) for c in x['cases'])
x['counts']['max_slots_per_case']=max(len(c['required_evidence_slots']) for c in x['cases'])
x['counts']['working_comparison_slots']=sum(len(c.get('required_working_comparisons',[])) for c in x['cases'])
x['counts']['future_real_candidate_specs']=sum(c['artifact_status']=='not_evaluated' for c in x['candidates'].values())
for c in x['cases']:
    if c['resource_control'] and c['resource_control'].get('override_cap')=='wall_seconds':
        c['resource_control']['trigger']='zero deadline plus startup barrier: supervisor never releases arithmetic barrier, records timeout and confirms process exit; no claim of natural slow runtime'
x['preinventory_rules']='Each case required_evidence_slots is exact, including all supplied candidates. All start not_evaluated. No slot is implicitly omitted. Invalid/unsupported cases may stop before arithmetic but keep explicit slot reasons. For tau1 FIT-REAL, AD/FD branches for every candidate are preinventoried; nonselected candidate branches are explicitly not_applicable. Full output is shared and not candidate-attributed. Working comparisons bind actual mode/branch arrays; comparison ID plus case ID is unique. The scalar h and direction slots that are unused (base h, unselected direction) are explicitly not_applicable. Full/scalar shapes are defined by the semantic schema predicate.'
p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
print(json.dumps(x['counts'],sort_keys=True))
