from pathlib import Path
import hashlib,json,subprocess,sys,time
S=Path(__file__).parent
label=sys.argv[1];cmd=sys.argv[2:]
inputs={str(Path(arg)):{'sha256':hashlib.sha256(Path(arg).read_bytes()).hexdigest(),'bytes':Path(arg).stat().st_size} for arg in cmd if arg.endswith('.py') and Path(arg).is_file()}
t=time.monotonic_ns()
p=subprocess.run(cmd,cwd='/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc',capture_output=True)
end=time.monotonic_ns()
(S/(label+'.stdout.raw')).write_bytes(p.stdout);(S/(label+'.stderr.raw')).write_bytes(p.stderr)
(S/(label+'.process.json')).write_text(json.dumps({'command':cmd,'script_input_identities':inputs,'cwd':'/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc','exit_code':p.returncode,'elapsed_monotonic_ns':end-t,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n')
print(p.stdout.decode(errors='replace'),end='');print(p.stderr.decode(errors='replace'),end='',file=sys.stderr)
raise SystemExit(p.returncode)
