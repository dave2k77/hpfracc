"""Read-only independent protocol review: stdlib planning only, no numerical runs."""
from __future__ import annotations

import collections
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
PARENT = Path('/home/davianc/.hermes/cache/scratch/a2-preparation-20261111')
OUT = Path('/home/davianc/.hermes/cache/scratch/a2-validation-resource-provenance-review-20261111')
PIN = '331d0d72ade81c242475bc9b3b1a0d37b4c3393251661e5b113bcbb0d48dd066'

def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()

def git(*args: str) -> bytes:
    return subprocess.check_output(['git', *args], cwd=ROOT)

def save_json(name: str, obj: object) -> None:
    (OUT / name).write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')

OUT.mkdir(parents=True, exist_ok=True)
baseline = json.loads((PARENT / 'preparation-inputs.json').read_text())
protocol = (ROOT / 'docs/developer/a2-compression-budget-protocol.md').read_bytes()
assert sha(protocol) == PIN == baseline['protocol_sha256']
assert protocol == (PARENT / 'protocol-reviewed-draft.md').read_bytes()
assert git('rev-parse', 'HEAD').decode().strip() == baseline['head']
inputs = baseline['baseline_numeric_inputs']
assert len(inputs) == 125
mismatches = [p for p, digest in inputs.items() if sha((ROOT / p).read_bytes()) != digest]
assert not mismatches, mismatches
index = git('ls-files', '--stage')
assert sha(index) == baseline['index_entries_sha256']
(OUT / 'reviewed-index-entries.txt').write_bytes(index)
(OUT / 'reviewed-protocol.md').write_bytes(protocol)
(OUT / 'preparation-inputs.json').write_bytes((PARENT / 'preparation-inputs.json').read_bytes())
selected = [
    'AGENTS.md', 'v0.1_engineering_contract.md',
    'docs/developer/phase-a-completion.md', 'docs/developer/bug-resolution-tracker.md',
    'docs/validation/soe-history.md', 'docs/validation/capabilities.md',
    'docs/validation/status.md', 'tests/conftest.py', 'tests/unit/test_soe_recursive.py',
    'tests/unit/test_soe_audit.py', 'benchmarks/numerical/soe_audit.py',
    'benchmarks/numerical/history_validation.py', 'src/hpfracc/ops/_soe.py',
    'src/hpfracc/ops/fractional.py', 'src/hpfracc/ops/kernels.py',
    'src/hpfracc/ops/orders.py', 'pyproject.toml', 'uv.lock',
    'docs/validation/audits/soe-2026-09-14/protocol.json',
    'docs/validation/audits/soe-2026-09-14/static-constants-followup.json',
]
selected += ['docs/validation/audits/soe-2026-09-14/consistent-poles/' + name for name in (
    'soe_accuracy_float32.json', 'soe_accuracy_float64.json',
    'soe_scaling_float32.json', 'soe_scaling_float64.json',
)]
reviewed = {}
for path in selected:
    raw = (ROOT / path).read_bytes()
    dest = OUT / 'reviewed-inputs' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
    reviewed[path] = {'sha256': sha(raw), 'bytes': len(raw), 'snapshot': str(dest)}
save_json('review-input-identity.json', {
    'scope': 'Read-only protocol review input snapshot, not a numerical measurement or historical collection',
    'root': str(ROOT), 'head': baseline['head'], 'protocol_sha256': PIN,
    'baseline_numeric_input_count': len(inputs), 'baseline_numeric_mismatches': mismatches,
    'index_entries_sha256': sha(index), 'parent_index_entries_sha256': baseline['index_entries_sha256'],
    'status_observed': git('status', '--porcelain=v1').decode(), 'reviewed_inputs': reviewed,
    'allowed_parent_writes': ['docs/developer/phase-a-completion.md', 'docs/developer/bug-resolution-tracker.md'],
    'a2_acceptance_passed': False, 'implementation_authorized': False,
})

# Independent small rational identities; no selector/fitter/recurrence implementation.
proof_cases = []
for n in (1, 3, 17):
    alpha = F(1, 2)
    w, g = [F(1)], [F(1)]
    for k in range(1, n):
        w.append(w[-1] * (F(k-1) - alpha) / k)
        g.append(g[-1] * (F(k) - alpha) / k)
    assert all(sum(w[:k+1]) == g[k] for k in range(n))
    signals = {
        'constant': [F(1)] * n,
        'ramp': [F(k, 16) for k in range(n)],
        'step': [F(int(k >= 8)) for k in range(n)],
        'alternating': [F((-1)**k, 8) for k in range(n)],
    }
    for signal_id, x in signals.items():
        v = [x[0]] + [x[i] - x[i-1] for i in range(1, n)]
        direct = [2 * sum(w[k] * x[i-k] for k in range(i+1)) for i in range(n)]
        prefix = [2 * sum(g[k] * v[i-k] for k in range(i+1)) for i in range(n)]
        assert direct == prefix
        for p, rhos, coeffs in (
            (1, [F(1, 2)], [F(1, 2)]),
            (2, [F(1, 2), F(1)], [F(1, 4), F(1, 4)]),
        ):
            gh = [F(1)] + [sum(c * r**(k-1) for c, r in zip(coeffs, rhos, strict=True)) for k in range(1, n)]
            eps = max(abs(a-b) for a, b in zip(gh, g, strict=True))
            b = [2 * eps * sum(abs(t) for t in v[:i]) for i in range(n)]
            dh = [2 * sum(gh[k] * v[i-k] for k in range(i+1)) for i in range(n)]
            residual = [2 * sum((gh[k]-g[k]) * v[i-k] for k in range(i+1)) for i in range(n)]
            assert all(a-d == r and abs(r) <= z for a, d, r, z in zip(dh, direct, residual, b, strict=True))
            proof_cases.append({'n': n, 'signal_id': signal_id, 'synthetic_poles': p, 'exact_identity_and_bound': True})

# Algebraic planning insight, not measurements: fixed-fit mean-square input FD
# has zero central truncation in exact arithmetic, since the objective is quadratic.
# Check a tiny explicitly written rational linear map, independent of all source.
A = [[F(2), F(0), F(0)], [F(-1), F(2), F(0)], [F(-1,4), F(-1), F(2)]]
x, d = [F(1), F(1,2), F(-1,8)], [F(1,4), F(-1,2), F(3,4)]
def objective(z: list[F]) -> F:
    return sum(sum(a*t for a, t in zip(row, z, strict=True))**2 for row in A) / len(A)
y = [sum(a*t for a, t in zip(row, x, strict=True)) for row in A]
analytic = 2 * sum(u * sum(a*t for a, t in zip(row, d, strict=True)) for u, row in zip(y, A, strict=True)) / len(A)
for h in (F(1,128), F(1,256), F(1,512)):
    fd = (objective([a+h*b for a,b in zip(x,d,strict=True)]) - objective([a-h*b for a,b in zip(x,d,strict=True)])) / (2*h)
    assert fd == analytic
proxies = [{'h': str(h), 'h_squared': str(h*h), 'u_over_h': str(F(1, 2**24)/h)} for h in (F(1,128), F(1,256), F(1,512))]

# Illustrate serialization ambiguity to resolve in the schema, not an implementation test.
ambiguities = {
    'json_default_duplicate_keys_last_wins': json.loads('{"exact_head":false,"exact_head":true}')['exact_head'],
    'python_bool_equals_int': True == 1,
    'python_float_equals_int': 1.0 == 1,
    'uppercase_and_lowercase_hex_decode_same': int('A',16) == int('a',16),
    'negative_zero_and_zero_decode_same': int('-0',16) == int('0',16),
    'nonreduced_rationals_compare_equal': F(2,4) == F(1,2),
}

# A conservative explicitly described operation count for repeated dense checks,
# not a counter-implementation, runtime estimate or proof of all possible choices.
N,M,P,C = 17,3,8,8
T = N*(N+1)//2
# Per candidate: charged power multiply, weighted sums, eps sub/abs/comparison;
# Dhat multiply/add and scaling; residual sub/multiply/add/scaling + error checks;
# B direct absolute-prefix summation/multiply/scaling + qualifying comparisons.
count_terms = {
    'common_w_g_generation_and_prefix_identity': 8*(N-1) + 2*T,
    'common_v_and_direct_reference': M*(N-1) + M*(2*T+N),
    'all_candidate_powers_weighted_sums_and_epsilon': C*(3*P*(N-1)+3*N),
    'all_candidate_fitted_outputs': C*M*(2*T+N),
    'all_candidate_residual_sums_and_error_checks': C*M*(3*T+5*N),
    'all_candidate_bounds_with_uncached_abs_prefixes': C*M*(2*T+3*N),
}
count_estimate = sum(count_terms.values())
assert count_estimate < 100000
# Does not include all metadata/decoding/exact analytic gradients/serialization;
# exact charging and sharing/reset semantics are findings requiring freeze.

# Parse archived reports only: never import or execute their producer.
reports = []
for dtype in ('float32', 'float64'):
    for mode in ('accuracy', 'scaling'):
        name = f'docs/validation/audits/soe-2026-09-14/consistent-poles/soe_{mode}_{dtype}.json'
        obj = json.loads((ROOT/name).read_text())
        rows = obj['rows']
        cols = sorted(rows[0]) if rows else []
        summary = {'path': name, 'sha256': sha((ROOT/name).read_bytes()), 'rows': len(rows), 'row_fields': cols,
                   'top_level_keys': sorted(obj), 'provenance': obj.get('provenance'), 'scope': obj.get('scope')}
        if mode == 'accuracy':
            summary.update({'operators': sorted({r['operator'] for r in rows}), 'orders': sorted({r['order'] for r in rows}),
                            'n_samples': sorted({r['n_samples'] for r in rows}), 'poles': sorted({r['poles'] for r in rows}),
                            'measurement_ok_count': sum(r['measurement_ok'] is True for r in rows)})
        else:
            summary.update({'n_samples': sorted({r['n_samples'] for r in rows}), 'poles': sorted({r['poles'] for r in rows}),
                            'state_dims': sorted({r['state_dim'] for r in rows}), 'sample_count': sum(len(r['sample_seconds']) for r in rows),
                            'all_agree': all(r['agrees_with_dense'] for r in rows)})
        reports.append(summary)
save_json('archived-report-readback.json', {'scope': 'Readback of historical artifacts, not current execution', 'reports': reports})
save_json('planning-proof.json', {
    'scope': 'Bounded stdlib rational planning only; no JAX/fit/application/AD/numerical benchmark execution',
    'protocol_sha256': PIN, 'exact_synthetic_identity_bound_cases': proof_cases,
    'exact_synthetic_identity_bound_case_count': len(proof_cases),
    'quadratic_fixed_fit_input_fd_truncation_zero': True,
    'float32_heuristic_proxies_not_error_bounds': proxies,
    'canonicalization_ambiguities': ambiguities,
    'illustrative_max_shape_dense_reference_operation_count': count_estimate,
    'operation_count_terms': count_terms,
    'operation_count_is_not_frozen_contract_or_measured_runtime': True,
    'python_decimal_integer_string_limit': sys.get_int_max_str_digits(),
    'forbidden_modules_loaded': sorted(k for k in sys.modules if k in ('jax', 'jaxlib', 'numpy', 'scipy', 'hpfracc')),
    'a2_acceptance_passed': False, 'implementation_authorized': False,
})
print(json.dumps({'identity_bound_cases': len(proof_cases), '125_numeric_inputs_unchanged': not mismatches,
                  'index_unchanged_from_parent': True, 'reviewed_protocol_sha256': PIN,
                  'quadratic_fixed_fit_input_fd_truncation_zero': True, 'illustrative_operation_count': count_estimate,
                  'archived_rows': [r['rows'] for r in reports], 'scope': 'stdlib planning/readback only'}, indent=2))
