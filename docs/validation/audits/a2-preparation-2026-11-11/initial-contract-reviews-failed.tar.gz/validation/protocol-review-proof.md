# Independent validation/resource/provenance readiness review

## Verdict and scope

**Not ready to freeze.** The finite rational bound and fail-closed selection design are credible. The blocking findings are incomplete frozen cases/comparisons/schema/resource-evidence conventions, not a demonstrated fitter or JAX defect. This review neither implements nor approves implementation. A2 acceptance remains false.

Reviewed protocol: `docs/developer/a2-compression-budget-protocol.md`, SHA256 `331d0d72ade81c242475bc9b3b1a0d37b4c3393251661e5b113bcbb0d48dd066`.
Baseline HEAD: `a3951bde6a633f22ee2c1e006ea78c62421f599b`.
The parent preparation manifest's 125 numerical input hashes and the exact Git index digest matched. Snapshot/readback details are in `review-input-identity.json`; final protected-byte verification is separate. All reviewer writes are under this scratch directory. Parent-only status edits to the programme and tracker were allowed and were not treated as source drift.

Only `uv run --locked --no-sync python -B .../review_planning_proof.py` was executed for planning; its actual tool exit was zero. It imports only the standard library. No JAX import, fit, application, AD, numerical benchmark, pytest/full suite, GPU job, dependency synchronization, repository write, Git index write, commit or push was performed. Planning proof records no forbidden numerical modules loaded. Historical report parsing is not current execution. Documentation tests and strict build were not run in this read-only review; the parent explicitly deferred the strict build until releasing the draft pin and correcting the known anchor.

## B1 — Freeze the actual fixture and expected-evidence matrix

Protocol lines 154–162 give useful categories, but not a complete frozen manifest. In particular FIT-REAL fixes N/order/dt/t_max/poles/dtypes/tau but not the signal or shape, nor explicitly binds it to REF-SIGNAL. That is material: a zero signal qualifies at tau=0 regardless of a nonzero kernel residual. Conversely a stacked alternating signal has a substantially different bound than a ramp. Do not guess which was intended.

Before freeze, enumerate exact case IDs, signals/shapes and deterministic input-byte construction, GL/RL roles, candidate stable IDs/ordered configurations, budgets, required comparisons and success/rejection/indeterminate roles. State which cases exercise each dtype/eager/JIT/AD check and the expected unique row set/count. REF-RANK, REF-EDGES and REF-CAPS also need concrete identities/outcomes rather than categories such as a qualifying larger fit or deliberate limits. Actual real-fitter output arrays are necessarily observations obtained later; freeze their producer/source/configuration and required evidence slots now, not fictitious output bytes.

The real-fit tau=1 required qualifier and tau=0 required nonqualifier are acceptable **predeclared stop gates**, not established attainability results. They should be evaluated over every supplied candidate, preserve any contrary result, and stop without changing the fitter, choosing a more favorable signal, replacing candidates, changing tau or loosening observational tolerances. An unexpected result is unresolved evidence, not permission to calibrate a policy from its own future passes. Selected pole count must be derived from the complete exact assessments.

## B2 — Complete comparison semantics and missing observational policies

Protocol lines 178–181 specify forward and float64 gradient/FD comparisons and float32 FD comparisons. They do not specify the comparison policy for AD input derivatives against the rational analytic gradient at lines 195–196. Nor do they explicitly include or exclude float32 eager/JIT gradient agreement (the only eager/JIT gradient row is float64). Resolve both before freeze; do not silently apply a nearby policy or use only a directional smoke check in place of the promised analytic gradient check.

Freeze a check-to-policy mapping and an explicit all-components comparison formula, shape equality/no broadcasting, the reference side of relative scaling, and exact-reference conversion/comparison conventions. State the full fixed-fit input target: for the rational discrete map A_hat and q=N*M, J=||A_hat*x||^2/q and grad_x J=2*A_hat^T*A_hat*x/q (each feature independently). If comparing a directional contraction, decode the actual represented cos(x) direction as a rational too. Keep that direction fixed at the base input during the plus/minus evaluations. Preserve the separate exact full-history map if its derivative is also claimed.

For order derivatives, the discrete choice of selected configuration stays fixed but the existing finite 400-update fit is rerun/differentiated at each alpha; the operator normalization must also remain dt^(-alpha), not the special-value constant 2 away from alpha=1/2. These are derivatives through the executed finite projected fitting algorithm, not implicit-optimum derivatives, a derivative of selection, or a certificate across active-set changes.

### Judgment of the proposed float32 policy

**The three float32 FD steps and numerical allowances are credible as a narrow, predeclared empirical observation gate; lack of a curvature bound alone is not a blocker for that limited claim.** Require every listed step, both adjacent-step comparisons, AD/FD comparisons, finiteness, recorded final coefficient zero patterns, and the stated preserve-and-stop rule. This is not a prediction that the new cases pass. Neither agreement nor an unchanged final zero pattern proves smoothness through all projected updates or derivative accuracy in general.

The rational proxies in `planning-proof.json` show h^2 and u/h for h=1/128,1/256,1/512. Their magnitudes are a heuristic choice of scales, not curvature constants, a relative-error analysis, or a roundoff enclosure. In fact, for input perturbations at a fixed fit the mean-square objective is quadratic, so central truncation is exactly zero in real arithmetic; only floating evaluation/perturbation effects remain. The O(h^2) argument is relevant to a smooth order-dependent objective and does not cover projection kinks. A tiny independent rational quadratic example confirms the zero-truncation identity without running the library.

Neighbor comparisons are case-specific precedents, not inherited guarantees:

- `tests/unit/test_soe_recursive.py:78-89`: x64-scoped complex-valued private recurrence, alpha=.6, N=33, P=8, t_max=2, unnormalized; proposed alpha=.5/N=17/real/normalization=2 differs. Doubling the absolute allowance is a transparent proposed scale policy, not a proved error bound.
- Lines 92–117: x64-scoped Caputo/GL, smooth two-feature signals, N=33, dt=1/32, default P=8, orders .3/.6/.85. That does not calibrate step/alternating signals, selected P=2/4 or nominal float32 execution.
- Lines 245–265: long float32 Caputo/L1 eager/JIT output agreement at N=256/1024/4096. It is not an independent GL-prefix forward-reference or gradient check. The nearby float32 aggregate in `history_validation.py:97-117` uses mean(output), a quadratic Caputo signal and h=1e-3, not the proposed mean(output**2) GL/RL objective.

The proposed forward tolerances can likewise be predeclared observational gates if confined to named fixtures and compared independently with exact D_hat/D. No mathematical derivative, curvature or working-roundoff bound is approved. B1/B2 still block the full stage because the exact case-to-check and analytic-comparison policies are unfinished.

## B3 — Freeze a canonical evidence/identity schema

Protocol lines 118–146 and 211–218 state the correct principles but not a closed schema. Before freeze specify required keys, schema/policy version, canonical types, permitted statuses and exact semantic bindings. Fields that affect decisions cannot be inferred, omitted or supplied by equal-valued substitutes.

Required details include:

- Canonical `type(value) is int` counters and actual booleans for exact_head/status flags; rejecting bool-as-integer alone does not stop integer 1 as an alleged boolean.
- Strict JSON duplicate-key rejection on import, no nonfinite numbers on import/export, and a single rational encoding. Choose lowercase hex without `0x` or `+`, reject negative zero/redundant zeros, require positive nonzero denominator, coprime numerator/denominator and denominator 1 for the zero rational. Bound encoded lengths before integer conversion. These are proposed resolutions, not a claim that an implementation already violates them.
- Explicit pointwise/componentwise absolute/max norm identity; exact tau and order/dt representation; lower terminal/prehistory and dimensionality.
- Stable-ID grammar/length/lexical ordering, and a definition of complete candidate identity excluding stable ID so duplicate fits with different IDs cannot bypass duplicate detection.
- Actual dtype, shape, byte order, layout and raw bytes/digest cross-binding, including represented order, direction and perturbed values/objectives/cotangents. Rational decoding must not erase raw +0/-0 identity. Define whether mixed input/fit dtypes are ineligible or explicitly supported.
- Separate source/configuration/producer identity from observed fit-array identity. `_SOEFit` has n/kernel/method/exact_head/arrays but does not carry alpha, dt or t_max (`_soe.py:15-23`); request-order compatibility and an actual-fitter origin must be recorded by the wrapper/provenance, not inferred from that record. Never assume a JIT refit has the eager fit's bytes. Bind each application to its own observed fit, or separately expose eager-vs-compiled fitting differences.
- Exact required candidate set, per-candidate results/reasons and array slots, commands/actual process exits, source/lock/protocol/case/policy hashes, and a replay completeness predicate that checks these relationships before hashing. A renamed row or rehashed metadata with omitted/changed arrays must fail. Hash equality is integrity, not execution authentication.

## B4 — Close reference-resource accounting and exhaustion evidence

The proposed 8 candidates, P<=8, N<=17, M<=3, 100,000 rational primitives, 32,768-bit normalized numerator/denominator, 16 MiB serialization and 60-second worker watchdog are reasonable prospective diagnostic caps, **not measured feasibility or core memory guarantees**. A stated, limited dense-loop operation-count model gives 34,307 elementary rational operations before metadata/decode/analytic-gradient/serialization checks; it merely establishes that a small straightforward planning path is plausible. It is not a frozen implementation counter or a runtime/peak-memory measurement.

Freeze what is counted and retained at boundaries: comparison/abs/power charges; shared versus repeated reference computations; inclusion of analytic-gradient construction/checks; input/rational decode and metadata size limits; exact serialized byte accounting (all candidates/arrays/JSON overhead); and wall-clock start/deadline/termination semantics. The draft already calls the cap cumulative across all candidates and checks; do not reset it for each fit, each bound, or each requested check.

Most importantly define bounded partial evidence and each remaining candidate's explicit not-evaluated/indeterminate status when the worker cannot emit complete arrays. A serialization cap or killed worker cannot both emit unlimited all-candidate arrays and remain bounded. Preserve all originally supplied identities and consumed counters/reasons outside any absent-array slots, while leaving selection globally indeterminate even if an earlier candidate qualifies. Freeze concrete REF-CAPS controls for each resource. No omitted assessment becomes ineligible or a successful no-candidate result. Do not claim that every allowed extreme float64 input must complete within these caps; resource-indeterminate is legitimate.

## Sound provisions retained

- At alpha=1/2, dt=1/4, the exact normalization is 2. The signed GL/prefix-increment identity including v[0] and exact lag-zero error give the draft's sharper B[i]=2*epsilon*sum_{j<i}|v[j]|. Independent stdlib planning verified 24 explicitly identified synthetic bound cases, distinct from the parent's 136 cases and from any numerical test count.
- Request qualification is exact and componentwise at every time/feature; bound rejection is not actual-error failure or proof of global unattainability. Empty/invalid/unsupported/exhausted cases remain distinct. Exhaustive rank `(pole_count,stable_id)` and whole-selection indeterminate on unknown assessments avoid first-success/monotonicity/fallback errors.
- Actual input/fit/output/objective/cotangent dtype assertions and x64 scoped off/on outside JIT with restoration are required by lines 204–207 and are sound. Also bind strong scalar order and both perturbation branches in the frozen matrix. A float32 cotangent alone is not precision evidence.
- The private SCI-003 helper is explicitly excluded as an oracle. Exact rational reference arithmetic neither certifies working roundoff nor extends the order domain during perturbations.
- Historical reports read back as 96 accuracy rows and 24 scaling rows per precision, with Windows CPU provenance and explicit compiler-buffer-only memory claims. They are not new A2 measurements or present-hardware evidence.
- Diagnostic reference/evidence memory is separate from recursive carry and from later measured application/reverse peaks. Later A2 work still requires isolated, synchronized fit/application/end-to-end and input/order reverse measurements, compilation/runtime, actual CPU/CUDA peak methods and failure/resource records. Compiler accounting and polling alone cannot establish a peak.
- Broader improvement/refinement, other kernels/orders/Caputo/legacy, solver-history/per-state decisions, SCI-003/A1 and A2/A3/A4 remain open; this tracer is not an A2 alternative, closure or approved deferral.

## Nonblocking documentation suggestion

The parent reported the known draft line-20 link target `#a2-history-approximation-and-memory--open`; the heading's intended target is `#a2-history-approximation-and-memory-open`. Treat that one anchor correction as nonsemantic and allowed only after the protected draft is released. It is not a numerical error and does not clear B1–B4. Rehash/review-lineage-bind corrected bytes and run the deferred documentation checks/build later. No link was changed during this review.
