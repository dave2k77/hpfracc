"""Verify read-only boundaries and index new scratch review evidence."""
import hashlib
import json
from pathlib import Path
import subprocess

R = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
O = Path('/home/davianc/.hermes/cache/scratch/a2-validation-resource-provenance-review-20261111')
def sha(data):
    return hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=R)
def write(name, obj):
    (O/name).write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')
pin = json.loads((O/'preparation-inputs.json').read_text())
identity = json.loads((O/'review-input-identity.json').read_text())
verdict = json.loads((O/'review-verdict.json').read_text())
assert set(verdict) == {'passed','logic_errors','suggestions','summary','reviewed_protocol_sha256','evidence_paths','a2_acceptance_passed','implementation_authorized'}
assert verdict['passed'] is False and verdict['logic_errors']
assert verdict['a2_acceptance_passed'] is False and verdict['implementation_authorized'] is False
assert verdict['reviewed_protocol_sha256'] == pin['protocol_sha256']
assert git('rev-parse','HEAD').decode().strip() == pin['head']
assert sha(git('ls-files','--stage')) == pin['index_entries_sha256']
assert (R/'docs/developer/a2-compression-budget-protocol.md').read_bytes() == (O/'reviewed-protocol.md').read_bytes()
assert len(pin['baseline_numeric_inputs']) == 125
for path, digest in pin['baseline_numeric_inputs'].items():
    assert sha((R/path).read_bytes()) == digest, path
allowed = set(identity['allowed_parent_writes'])
changes = []
for path, record in identity['reviewed_inputs'].items():
    assert sha(Path(record['snapshot']).read_bytes()) == record['sha256'], path
    actual = sha((R/path).read_bytes())
    if actual != record['sha256']:
        assert path in allowed, path
        changes.append({'path':path,'reviewed_sha256':record['sha256'],'current_sha256':actual})
tracked_dirty = set(git('diff','--name-only').decode().splitlines())
assert tracked_dirty <= allowed, tracked_dirty
assert not git('diff','--cached','--name-only').strip()
assert git('ls-files','--others','--exclude-standard').decode().splitlines() == ['docs/developer/a2-compression-budget-protocol.md']
proof = json.loads((O/'planning-proof.json').read_text())
assert not proof['forbidden_modules_loaded']
assert proof['exact_synthetic_identity_bound_case_count'] == len(proof['exact_synthetic_identity_bound_cases']) == 24
assert all(c['exact_identity_and_bound'] is True for c in proof['exact_synthetic_identity_bound_cases'])
assert proof['a2_acceptance_passed'] is False
# Exclude the index and this final verification record to avoid self/cyclic hashes.
excluded = {'evidence-index.json','final-verification.json'}
entries = []
for path in sorted(O.rglob('*')):
    if path.is_file() and path.name not in excluded:
        assert not path.is_symlink()
        raw = path.read_bytes()
        entries.append({'path':str(path.relative_to(O)),'bytes':len(raw),'sha256':sha(raw)})
write('evidence-index.json', {'scope':'Scratch-only independent readiness-review proof; not numerical acceptance',
      'reviewed_protocol_sha256':pin['protocol_sha256'],'entry_count':len(entries),
      'entries':entries,'excluded_self_and_final_readback':sorted(excluded)})
idxraw = (O/'evidence-index.json').read_bytes()
idx = json.loads(idxraw)
assert idx['entry_count'] == len(idx['entries'])
for e in idx['entries']:
    raw = (O/e['path']).read_bytes()
    assert len(raw) == e['bytes'] and sha(raw) == e['sha256'], e['path']
record = {'scope':'Final live protected-byte and scratch evidence readback; standard library only',
          'verified':True, 'head':pin['head'], 'reviewed_protocol_sha256':pin['protocol_sha256'],
          'numeric_inputs_verified':len(pin['baseline_numeric_inputs']),
          'index_entries_sha256':pin['index_entries_sha256'],
          'allowed_parent_status_paths':sorted(allowed),'allowed_parent_changes_after_snapshot':changes,
          'current_status':git('status','--porcelain=v1').decode(),
          'evidence_index_path':str(O/'evidence-index.json'),'evidence_index_sha256':sha(idxraw),
          'evidence_index_entries_verified':len(entries),
          'verdict_path':str(O/'review-verdict.json'),'verdict_sha256':sha((O/'review-verdict.json').read_bytes()),
          'planning_bound_cases':24,'a2_acceptance_passed':False,'implementation_authorized':False}
write('final-verification.json',record)
for p in verdict['evidence_paths']:
    assert Path(p).is_file(), p
print(json.dumps(record,indent=2))
