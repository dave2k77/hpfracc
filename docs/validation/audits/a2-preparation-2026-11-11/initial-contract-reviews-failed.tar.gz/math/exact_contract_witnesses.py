"""Read-only contract-review witnesses, NOT future selector code or A2 measurements.

Only stdlib Fraction/math/struct; no hpfracc, numerical runtime, fitter, AD,
application worker, pytest, or benchmark is imported or run. Writes new scratch.
Run from the pinned checkout via uv run --frozen --no-sync python -B FILE.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import permutations
from math import comb
from pathlib import Path
import hashlib
import json
import os
import struct
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
PARENT = Path('/home/davianc/.hermes/cache/scratch/a2-preparation-20261111')
EXPECTED_PROTOCOL = '331d0d72ade81c242475bc9b3b1a0d37b4c3393251661e5b113bcbb0d48dd066'
START = time.monotonic()
DIGIT_LIMIT_BEFORE = sys.get_int_max_str_digits()

def save(name, obj):
    with (OUT / name).open('x') as h:
        json.dump(obj, h, indent=2, allow_nan=False)
        h.write('\n')

def enc(x):
    x = F(x)
    return {'num_hex': format(x.numerator, 'x'), 'den_hex': format(x.denominator, 'x')}

def arr(xs):
    return [[enc(x) for x in row] for row in xs]

def sha(b):
    return hashlib.sha256(b).hexdigest()

# Counts this explicit arithmetic schedule only. Fraction normalization/GCD and
# integer bit/encoding work are bounded separately, not falsely called unit work.
class Charged:
    def __init__(self, cap=100000, bits=32768):
        self.count = 0
        self.cap = cap
        self.bits = bits
        self.max_num = 0
        self.max_den = 0
        self.kinds = Counter()
    def check(self, x):
        x = F(x)
        nb, db = abs(x.numerator).bit_length(), x.denominator.bit_length()
        self.max_num = max(self.max_num, nb)
        self.max_den = max(self.max_den, db)
        if max(nb, db) > self.bits:
            raise OverflowError('normalized_bit_cap')
        return x
    def op(self, kind, a, b=None):
        a = self.check(a)
        if b is not None:
            b = self.check(b)
        if self.count >= self.cap:
            raise OverflowError('primitive_cap')
        self.count += 1
        self.kinds[kind] += 1
        if kind == 'add': return self.check(a+b)
        if kind == 'sub': return self.check(a-b)
        if kind == 'mul': return self.check(a*b)
        if kind == 'div': return self.check(a/b)
        if kind == 'abs': return self.check(abs(a))
        if kind == 'le': return a <= b
        if kind == 'eq': return a == b
        raise AssertionError(kind)
    def summation(self, xs):
        z = F(0)
        for x in xs: z = self.op('add', z, x)
        return z
    def maximum(self, xs):
        xs = list(xs)
        z = xs[0]
        for x in xs[1:]:
            if self.op('le', z, x): z = x
        return z
    def stats(self):
        return {'primitive_count': self.count, 'operation_counts': dict(self.kinds),
                'largest_numerator_bits': self.max_num,
                'largest_denominator_bits': self.max_den}


def witness(values, rhos, cs, q):
    """Evaluate literal finite identities, not eligibility or selection behavior."""
    n, m = len(values), len(values[0])
    for z in [z for row in values for z in row]+list(rhos)+list(cs): q.check(z)
    a, s = F(1,2), F(2)
    w, g = [F(1)], [F(1)]
    for k in range(1,n):
        w.append(q.op('div',q.op('mul',w[-1],q.op('sub',F(k-1),a)),F(k)))
        g.append(q.op('div',q.op('mul',g[-1],q.op('sub',F(k),a)),F(k)))
    # Independent closed-form half-order coefficients, plus charged equality.
    for k in range(n):
        assert q.op('eq',g[k],F(comb(2*k,k),4**k))
        if k:
            assert q.op('eq',w[k],-F(comb(2*k,k),(2*k-1)*4**k))
        assert q.op('eq',q.summation(w[:k+1]),g[k])
    v = [values[0]] + [[q.op('sub',values[j][f],values[j-1][f])
                        for f in range(m)] for j in range(1,n)]
    gh, basis = [F(1)], [F(1)]*len(rhos)
    for k in range(1,n):
        gh.append(q.summation(q.op('mul',c,b) for c,b in zip(cs,basis,strict=True)))
        if k < n-1:
            basis = [q.op('mul',b,r) for b,r in zip(basis,rhos,strict=True)]
    residual = [q.op('sub',h,t) for h,t in zip(gh,g,strict=True)]
    epsilon = q.maximum(q.op('abs',r) for r in residual)
    d, dh, error, bounds, prefix = [],[],[],[],[]
    variation = [F(0)]*m
    for i in range(n):
        ds, hs, es, bs, ps = [],[],[],[],[]
        for f in range(m):
            direct = q.op('mul',s,q.summation(q.op('mul',w[k],values[i-k][f]) for k in range(i+1)))
            pos = q.op('mul',s,q.summation(q.op('mul',g[k],v[i-k][f]) for k in range(i+1)))
            fitted = q.op('mul',s,q.summation(q.op('mul',gh[k],v[i-k][f]) for k in range(i+1)))
            weighted = q.op('mul',s,q.summation(q.op('mul',residual[k],v[i-k][f]) for k in range(i+1)))
            b = q.op('mul',q.op('mul',s,epsilon),variation[f])
            err = q.op('sub',fitted,direct)
            assert q.op('eq',direct,pos)
            assert q.op('eq',err,weighted)
            assert q.op('le',q.op('abs',err),b)
            if i:
                assert q.op('le',bounds[-1][f],b)
            ds.append(direct); hs.append(fitted); es.append(err); bs.append(b); ps.append(pos)
        d.append(ds); dh.append(hs); error.append(es); bounds.append(bs); prefix.append(ps)
        if i < n-1:
            variation = [q.op('add',z,q.op('abs',v[i][f])) for f,z in enumerate(variation)]
    # A separate pole-history finite expansion checks the k-1 rather than k shift.
    history = [[F(0)]*m for _ in cs]
    for i in range(n):
        for f in range(m):
            out = q.op('mul',s,q.op('add',v[i][f],q.summation(
                q.op('mul',c,history[p][f]) for p,c in enumerate(cs))))
            assert q.op('eq',out,dh[i][f])
        history = [[q.op('add',q.op('mul',r,history[p][f]),v[i][f])
                    for f in range(m)] for p,r in enumerate(rhos)]
    return {'N':n,'M':m,'poles':len(cs),'x':arr(values), 'v':arr(v),
            'rhos':[enc(r) for r in rhos], 'coefficients':[enc(c) for c in cs],
            'w':[enc(z) for z in w], 'g':[enc(z) for z in g],
            'g_hat':[enc(z) for z in gh], 'epsilon':enc(epsilon),
            'D':arr(d),'D_hat':arr(dh),'error':arr(error),'B':arr(bounds)}, (d,dh,bounds,epsilon)

# An explicit normalization derivation without approximating a square root.
assert F(2) > 0 and F(2)*F(2)*F(1,4)==1

# All supported N and M shapes; all components independently populated.
synthetic = [([F(1,2)],[F(1,2)]),([F(1,2),F(1)],[F(1,4),F(1,4)]),
             ([F(3,4)],[F(1,2)]),([F(1)],[F(0)])]
rows = []
scalar_checks = 0
for n in range(1,18):
    signals = {'constant':[F(1)]*n,'ramp':[F(k,16) for k in range(n)],
               'step':[F(k>=8) for k in range(n)],
               'alternating':[F((-1)**k,8) for k in range(n)],
               'zero':[F(0)]*n,
               'changed_tail':[F(1)]*(n-1)+[F(-3,8)]}
    for name,x in signals.items():
        for p,(r,c) in enumerate(synthetic):
            q = Charged()
            raw,_ = witness([[z] for z in x],r,c,q)
            rows.append({'case_id':f'n{n}-{name}-fit{p}', 'input_shape':[n],
                         'raw':raw,'work':q.stats()})
            scalar_checks += n
    for m in range(1,4):
        x = [[signals[name][i] for name in ('ramp','step','alternating')[:m]]
             for i in range(n)]
        for p,(r,c) in enumerate(synthetic):
            q=Charged(); raw,_=witness(x,r,c,q)
            rows.append({'case_id':f'n{n}-stack{m}-fit{p}', 'input_shape':[n,m],
                         'raw':raw,'work':q.stats()})
            scalar_checks += n*m
save('finite-fraction-witnesses.json', {'scope':'exact synthetic planning only',
     'case_count':len(rows),'scalar_output_checks':scalar_checks,'cases':rows})

# Short exact controls: saturation, strict/equal decision boundary, head, shift,
# component scope, nonmonotone actual errors, and good smaller / bad larger.
q=Charged(); raw,(d,dh,b,eps)=witness([[F(1)]]*3,*synthetic[0],q)
assert [z[0] for z in d]==[F(2),F(1),F(3,4)]
assert [z[0] for z in dh]==[F(2),F(1),F(1,2)]
assert [z[0] for z in b]==[F(0),F(1,4),F(1,4)] and eps==F(1,8)
bmax=max(z[0] for z in b)
assert bmax==F(1,4) and bmax>F(3,16)
assert bmax<=F(1,4) and not bmax<=F(1,4)-F(1,2**100)
assert bmax<=F(1,4)+F(1,2**100)
assert eps<=F(3,16) # false pass when normalization is omitted
assert F(0)<=F(3,16) # false pass when x[0] is omitted
q=Charged(); _,(_,_,good,good_eps)=witness([[F(1)]]*3,*synthetic[2],q)
assert good_eps==0 and max(z[0] for z in good)==0
q=Charged(); _,(_,_,bad,bad_eps)=witness([[F(1)]]*3,[F(1,2),F(1)],[F(1),F(1)],q)
assert bad_eps>good_eps
# Ranking statements over already known mathematical qualifications, not a selector.
known_qualifiers=[(2,'q-zeta'),(3,'q-large'),(2,'q-alpha')]
assert {min(p) for p in permutations(known_qualifiers)}=={(2,'q-alpha')}
assert min([(1,'good-smaller'),(2,'good-larger')])==(1,'good-smaller')
# Exact-head current-increment exclusion is a real improvement. Last x affects
# outputs but not the whole-sequence budget under a fixed kernel.
q=Charged(); _,(d2,h2,b2,e2)=witness([[F(1)],[F(1)],[F(2**20)]],*synthetic[0],q)
assert b2==b and d2!=d and h2!=dh
# Actual error can decrease, unlike B: x[0]=1, x[1]=0 kills lag-2 term at n=3.
q=Charged(); _,(dc,hc,bc,ec)=witness([[F(1)],[F(0)],[F(0)]],*synthetic[0],q)
errors=[abs(z[0]-t[0]) for z,t in zip(hc,dc)]
# This particular residual is zero at lag 1, so use N=4 for cancellation.
q=Charged(); cancellation,(dc,hc,bc,ec)=witness([[F(1)],[F(-1)],[F(0)],[F(0)]],*synthetic[0],q)
errors=[abs(z[0]-t[0]) for z,t in zip(hc,dc)]
assert errors[2]>0 and errors[3]>0
# Construct exact cancellation at final n=3: x=(1,3/4,0), v=(1,-1/4,-3/4)
# with ghat=(1,1/4,1/8), residual=(0,-1/4,-1/4).
q=Charged(); cancellation2,(dc,hc,bc,ec)=witness([[F(1)],[F(3,4)],[F(0)]],[F(1,2)],[F(1,4)],q)
# For cancellation need v1=-1, so x1=0, residual lag2=-1/4 and lag1=-1/4.
q=Charged(); cancellation3,(dc,hc,bc,ec)=witness([[F(1)],[F(0)],[F(0)]],[F(1,2)],[F(1,4)],q)
errors=[abs(z[0]-t[0]) for z,t in zip(hc,dc)]
assert errors==[F(0),F(1,2),F(0)]
assert bc[2][0]>=bc[1][0]>0
assert 2*ec*abs(F(1)+F(-1))==0 and bc[2][0]>0
save('controls.json',{'scope':'exact planning witnesses, not implemented outcomes',
     'ref_fail':raw,'strict_boundary_delta':enc(F(1,2**100)),
     'cancelled_endpoint_but_nonzero_interior_error':cancellation3,
     'nonmonotone_pole_count':{'good_smaller_epsilon':enc(good_eps),'bad_larger_epsilon':enc(bad_eps)},
     'rank_permutations_checked':len(list(permutations(known_qualifiers))),
     'observations':['last-sample change need not change B',
       'B is nondecreasing: endpoint bound suffices for qualification per feature',
       'all-time raw evidence completeness is a separate integrity requirement',
       'signed variation can cancel even when the absolute envelope is positive']})

# IEEE values from their exact bit representations, including signed zero.
def ieee(bits,dtype):
    fmt,integer,width = ('d','Q',16) if dtype=='float64' else ('f','I',8)
    raw=struct.pack('>'+integer,bits)
    val=struct.unpack('>'+fmt,raw)[0]
    return F(val), {'dtype':dtype,'bytes_hex':raw.hex(),'sha256':sha(raw),'value':enc(F(val))}
near=[]
for dtype,defs in [('float32',{'tiny':1,'max':0x7f7fffff,'prev1':0x3f7fffff,'one':0x3f800000,'negzero':0x80000000}),
                   ('float64',{'tiny':1,'max':0x7fefffffffffffff,'prev1':0x3fefffffffffffff,'one':0x3ff0000000000000,'negzero':0x8000000000000000})]:
    values={k:ieee(v,dtype) for k,v in defs.items()}
    tiny,big,prev,one=(values[k][0] for k in ('tiny','max','prev1','one'))
    x=[[big if i%2==0 else -big,tiny if i%2==0 else -tiny,one if i%2==0 else tiny]
       for i in range(17)]
    q=Charged(); candidates=[]
    # Eight complete content-distinct candidates, eight poles each, one shared
    # cumulative counter. Extremes force large exact denominators and products.
    for candidate in range(8):
        rho=[tiny,prev,one,F(1,2),F(1,4),F(3,4),F(1,8),F(7,8)]
        cs=[big,prev,tiny,F(candidate+1,8),one,F(0),F(1,4),F(1,2)]
        raw,_=witness(x,rho,cs,q)
        candidates.append(raw)
    encoded=json.dumps({'decoded_ieee':{k:v[1] for k,v in values.items()},'candidates':candidates},allow_nan=False).encode()
    assert q.count<=100000 and max(q.max_num,q.max_den)<=32768
    assert len(encoded)<16*1024*1024
    assert F(-0.0)==F(0) and values['negzero'][1]['bytes_hex'] != ('0000000000000000' if dtype=='float64' else '00000000')
    save(f'near-limits-{dtype}.json',{'scope':'bounded represented-extreme exact planning; no fitting',
         'ieee_input_values':{k:v[1] for k,v in values.items()},
         'candidates':candidates,'work':q.stats(),'serialized_payload_bytes':len(encoded)})
    near.append({'dtype':dtype,'candidates':8,'N':17,'M':3,'poles_each':8,
                 'work':q.stats(),'serialized_payload_bytes':len(encoded)})

# Algebraic conservative size bounds for every finite float64 datum in this
# domain (not time guarantees): z=A*2^-1074, |A|<2^2098; rho<=1.
# rho^15 has denominator at most 2^16110. c*rho^15 <2^1024;
# adding <=8 such terms gives <2^1027, on denominator 2^17184.
# v <2^1025 on denominator 2^1074. Residuals require no larger denominator.
# <=17 terms and scale 2 yield numerator <2^(18258+1027+1025+5+1).
size_bound = 18258+1027+1025+5+1
assert size_bound < 32768
# Multiple arrays of at most 51 entries: a deliberately conservative allowance
# for 8 candidates * 12 arrays, with both numerator and denominator <=32768 bits.
per_rational_bytes = 2*((32768+3)//4)+100
array_allowance = 8*12*51*per_rational_bytes
# Full bit-cap worst-case allowance exceeds evidence cap; narrower represented
# dyadic exponent reasoning is needed, not 100000 operations or 136 examples.
assert array_allowance > 16*1024*1024
# Tight represented-domain rough allowance for current arrays, not arbitrary
# unbounded candidate metadata / arbitrary exact tau / future arrays.
actual_array_allowance = 8*8*51*(((size_bound+3)//4)+((18259+3)//4)+100)

# Controlled primitive/bit exhaustion does not produce a finite assessment.
cap_reasons=[]
for cap,bits,op,a,b in [(0,32768,'add',F(1),F(1)),(10,8,'mul',F(255),F(255))]:
    try:
        Charged(cap,bits).op(op,a,b)
    except OverflowError as e:
        cap_reasons.append(str(e))
    else:
        raise AssertionError('deliberate cap was not detected')
assert cap_reasons==['primitive_cap','normalized_bit_cap']
# Hexadecimal roundtrip at cap and beyond decimal conversion limit.
large=(1<<32767)+1
assert int(format(large,'x'),16)==large
assert sys.get_int_max_str_digits()==DIGIT_LIMIT_BEFORE

# Replay supplied planning identities arithmetically; do NOT execute its writer.
parent=json.loads((PARENT/'planning-checks.json').read_text())
parent_case_counts=Counter((c['n'],c['features'],c['poles']) for c in parent['cases'])
expected=Counter({(n,1,p):4 for n in range(1,18) for p in (1,2)})
assert parent_case_counts==expected
assert len(parent['cases'])==parent['bound_cases']==136
assert parent['prefix_identity_signal_cases']==68
# Our independently built cases contain the same four parent signal formulas and
# two fit formulas, plus new M=1..3, zero/changed-tail and represented-extreme work.
parent_compare={'declared_bound_cases':parent['bound_cases'],
    'enumerated_rows':len(parent['cases']), 'declared_identity_signal_cases':parent['prefix_identity_signal_cases'],
    'all_parent_n_feature_pole_multiplicities_match':parent_case_counts==expected,
    'all_parent_case_flags_true':all(c['exact_inequality_verified'] is True for c in parent['cases']),
    'limits':['four signals; all scalar features=1; poles only 1/2',
       'case rows omit signal IDs, exact arrays and charged operation counts',
       'not selector execution, not real fitter evidence, not cap/domain/working-roundoff proof']}

# Reverify the exact pinned target and every pinned numerical input/index entry.
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
pins=json.loads((PARENT/'preparation-inputs.json').read_text())
idx=subprocess.check_output(['git','ls-files','--stage'],cwd=ROOT,env=env)
with (OUT/'index-entries-after.raw').open('xb') as h: h.write(idx)
raw=(ROOT/'docs/developer/a2-compression-budget-protocol.md').read_bytes()
post={'protocol_sha256':sha(raw),'index_entries_sha256':sha(idx),
      'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,env=env,text=True).strip(),
      'numeric_input_count':len(pins['baseline_numeric_inputs']),
      'numeric_mismatches':[n for n,h in pins['baseline_numeric_inputs'].items() if sha((ROOT/n).read_bytes())!=h],
      'index_entries_match_pin':sha(idx)==pins['index_entries_sha256'],
      'index_entries_identical_before_after':idx==(OUT/'index-entries-before.raw').read_bytes(),
      'protocol_identical_before_after':raw==(OUT/'reviewed-protocol.raw.md').read_bytes()}
assert post['protocol_sha256']==EXPECTED_PROTOCOL and post['head']==pins['head']
assert not post['numeric_mismatches'] and post['index_entries_match_pin']
assert post['index_entries_identical_before_after'] and post['protocol_identical_before_after']
save('inputs-after.json',post)
summary={'scope':'Independent mathematical contract review; exact synthetic planning witnesses only',
    'all_executable_assertions_passed':True,'finite_fraction_case_count':len(rows),
    'scalar_output_identity_and_bound_checks':scalar_checks,
    'supported_N':list(range(1,18)),'supported_M':[1,2,3],
    'near_limits':near,'represented_domain_conservative_numerator_bits':size_bound,
    'raw_bit_cap_only_evidence_allowance_bytes':array_allowance,
    'represented_domain_current_array_allowance_bytes':actual_array_allowance,
    'resource_interpretation':'Witness schedule only; no global wall-time guarantee or arbitrary-metadata evidence bound',
    'controlled_exhaustion_reasons':cap_reasons,'parent_planning_comparison':parent_compare,
    'python_decimal_digit_limit_unchanged':DIGIT_LIMIT_BEFORE,
    'elapsed_host_seconds':time.monotonic()-START,
    'numerical_library_imported':any(k.split('.')[0] in {'jax','numpy','scipy','hpfracc'} for k in sys.modules),
    'a2_acceptance_passed':False,'implementation_authorized':False}
assert summary['numerical_library_imported'] is False
save('proof-summary.json',summary)
print(json.dumps(summary,indent=2))
