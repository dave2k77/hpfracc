"""Seal this read-only mathematical-contract review's scratch evidence."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
PARENT=Path('/home/davianc/.hermes/cache/scratch/a2-preparation-20261111')
SHA='331d0d72ade81c242475bc9b3b1a0d37b4c3393251661e5b113bcbb0d48dd066'
def h(b): return hashlib.sha256(b).hexdigest()
def write(name,data):
    with (OUT/name).open('x') as f:
        json.dump(data,f,indent=2,allow_nan=False); f.write('\n')

proof=json.loads((OUT/'proof-summary.json').read_text())
assert proof['all_executable_assertions_passed'] is True
for name in ('proof-run-process.json','decision-proof-process.json'):
    assert json.loads((OUT/name).read_text())['exit_code']==0

verdict={
 'passed':False,
 'logic_errors':[
  {'id':'DECISION-01','classification':'blocking failure-taxonomy ambiguity, not an error in the GL identity',
   'protocol_lines':'54-59, 127-135; REF-EDGES line 159',
   'finding':'Unsupported kernels/orders/grids/complex data are described as unsupported-reference outcomes, while incompatible fits are described as ineligible. The request-versus-candidate boundary and precedence are not explicit. A valid GL request with a known qualifier plus a well-formed L1 candidate can therefore be read as either whole-selection indeterminate or candidate-ineligible followed by selection.',
   'required_resolution':'Freeze a request/candidate status matrix. State explicitly which unsupported request/reference cases make the whole selection indeterminate, which candidate configuration mismatches are ineligible, and how missing/corrupt raw data differs from a malformed supplied fit. Retain all reasons; an unknown assessment must never become a completed rejection.'},
  {'id':'DECISION-02','classification':'blocking canonical-identity/schema gap',
   'protocol_lines':'118-125, 127-135',
   'finding':'Duplicate complete candidate identity has no explicit canonical key. Since a candidate record includes stable_id and producer/source/context fields, the draft does not unambiguously decide whether identical configuration and array bytes under different IDs are a forbidden duplicate. This is an observable request-validity decision, not only an export detail.',
   'required_resolution':'Define the ID-free canonical content-identity tuple, exactly which configuration/provenance fields it includes, dtype/shape/byte-order/raw-byte treatment, nonempty bounded ASCII ID grammar/lexical comparison, and the request-level input-error outcome for duplicate IDs/content. Do not normalize pole permutations or equate mathematically equal kernels unless separately specified; distinct same-pole candidates remain legitimate.'},
  {'id':'DECISION-03','classification':'incorrect general mathematical rationale; conservative outcome policy is acceptable',
   'protocol_lines':'129-131',
   'finding':'The assertion that there is no justified global minimum while any assessment is unknown is too strong. If all ranks below a known rank-2 qualifier have been ruled out and only a rank-8 candidate is unknown, minimum rank is already known. Whole-selection indeterminate remains a valid, deliberately stricter exhaustive-assessment policy.',
   'required_resolution':'Keep whole-selection indeterminate on any unsupported/exhausted assessment, but justify it by the mandatory completeness contract, not by universal impossibility of inferring a minimum. Freeze the rule for unknown candidates of both lower and higher rank.'}
 ],
 'suggestions':[
  {'id':'MATH-PASS','kind':'proved mathematical conclusions',
   'details':[
    'For general 0<alpha<1, the recurrences imply w[k]=g[k]-g[k-1] for k>=1, with g[-1]=0. One induction establishes w[k]=-alpha*g[k-1]/k. Therefore g[k]=sum(w[:k+1]). This is finite algebra, not a continuous-operator or asymptotic claim.',
    'With x[-1]=0 and v[0]=x[0], v[j]=x[j]-x[j-1], finite summation by parts gives sum(w[k]*x[i-k])=sum(g[k]*v[i-k]). It holds independently for each real trailing feature. The leading axis is time and the initial value must not be removed as for Caputo.',
    'The positive normalization is exactly 2 because 2>0 and 2^2*(1/4)=1. For r[k]=g_hat[k]-g[k], exact head gives r[0]=0. Thus D_hat[i]-D[i]=2*sum(r[k]*v[i-k],k=1..i), and its absolute value is <=2*epsilon*sum(abs(v[j]),j=0..i-1). This proves B, B[0]=0 and N=1 epsilon=0.',
    'Qualification by every B<=tau is sufficient for exact finite compression accuracy, not necessary for actual error<=tau. Bound rejection says neither that actual error fails nor that another fit cannot succeed. Finite GL/RL output at t=0 is not a continuous RL accuracy statement.',
    'A valid singleton has D_hat=D=2*x[0] regardless of tail coefficients, but eligibility and request checks must still run. A bad fit cannot acquire acceptance through zero signal, zero epsilon or empty history.',
    'g[k]=binomial(2k,k)/4^k at alpha=1/2; w[k]=-binomial(2k,k)/((2k-1)*4^k) for k>=1. These independent closed forms cross-check the stated recurrences and all finite signed/prefix outputs.'
   ]},
  {'id':'CONTROLS','kind':'verified bounded synthetic arithmetic',
   'details':[
    '612 independently generated scalar/stacked cases cover N=1..17, M=1..3, six scalar signals and four synthetic fits; 7,344 scalar time/feature identities and bounds passed. Raw exact arrays and charged operations are retained.',
    'REF-FAIL and REF-PASS constants are correct. A separate one-pole rho=3/4,c=1/2 is also exact over three lags, illustrating why the two-pole positive control is only minimal among its supplied list, not globally minimal.',
    'Exact equality at tau=1/4 qualifies, while tau=1/4-2^-100 does not, even though both become the same binary64 value if prematurely converted. Normalization and initial-value omissions yield the documented false passes.',
    'Signed variation can falsely qualify a rejected envelope; actual errors can peak at an interior sample and cancel exactly at the endpoint. Minimum-rank witnesses are independent of supplied order and do not presume monotone fit quality in pole count.',
    'The supplied 136 planning rows are consistent with 17 lengths x 4 scalar signals x 2 synthetic fits and the 68 prefix-identity signal loops. They contain no vector-feature cases, charged resource accounting, raw exact arrays or signal IDs. They are planning arithmetic, not selector/JAX/real-fit/benchmark evidence.'
   ]},
  {'id':'CAPS','kind':'keep proposed caps; make their epistemic and serialization boundaries explicit',
   'details':[
    'At N=17,M=3, eight distinct eight-pole represented-extreme candidates completed this specific charged identity/cross-check schedule using 55,480 primitives per dtype. The float64 witness reached 17,238 numerator bits and 18,259 denominator bits and serialized 4,343,305 compact JSON bytes; float32 reached 2,409/2,534 bits and 706,723 bytes. These are exact host planning controls without fitting.',
    'Every finite binary64 value is dyadic with denominator <=2^1074 and magnitude <2^1024. The largest required lag power is rho^15, so fitted-kernel denominators are <=2^17184; multiplying by increments/envelope variation gives denominator <=2^18258. Nonnegative eight-pole coefficients and bounded finite input exponents give a conservative normalized numerator bound of at most 20,316 bits for the stated outputs/envelopes. No general-rational denominator explosion occurs in this represented dyadic domain.',
    'The 32,768-bit cap is ample for these finite represented arrays; 100,000 primitives has headroom for this explicitly charged schedule, not for arbitrary implementations. A primitive count is not integer/GCD bit complexity or a wall-time guarantee. The 60-second watchdog can still make a whole request indeterminate.',
    'A 16 MiB evidence guarantee does not follow from the bit cap alone: rational array cardinality, duplication, chosen export fields, formatting, metadata/ID lengths and tau representation must be frozen/bounded. The retained extrema fit the cap; they are not a proof for arbitrary metadata or future extra arrays. Never suppress required raw arrays to fit the cap.',
    'Define outcomes for >8 supplied candidates, N/M outside the tiny domain, >8 poles, overlong metadata/hex fields and noncanonical/oversized tau before freeze. Do not silently narrow the public core or label a finite unsupported problem mathematically invalid. Deliberate primitive and normalized-bit exhaustion controls were exercised only in scratch arithmetic.',
    'Reference caps do not undermine the exhaustive-assessment requirement if every uncompleted candidate remains explicitly unknown and the whole selection is indeterminate. No global minimum/no-qualifier claim is permitted after resource or reference exhaustion. Unknown entries need not fabricate unavailable arrays; retain the received raw data plus explicit incomplete status.'
   ]},
  {'id':'TIME-AND-COST','kind':'clarify guarantees and integrity controls',
   'details':[
    'B[i] is nondecreasing in time for each feature, because epsilon>=0 and absolute variation accumulates. Checking the last B per feature is mathematically equivalent for qualification. To require every time row be retained/replayed, express intermediate-row omission as an evidence-completeness failure, not as a guaranteed different budget decision. Actual errors need not be monotone.',
    'The rank (pole_count,stable_id) proves minimum supplied eligible qualifying rank only. Pole count is a configured cost proxy, not measured runtime/peak-memory cost; zero coefficients or equivalent pole sums are not silently pruned.',
    'Freeze finite nonnegative exact tau encoding/canonical type rules and all unavailable-value statuses. Bool and float lookalikes cannot silently satisfy canonical integer fields; negative zero/raw dtype/bytes remain identity data even when their decoded rational value is zero.'
   ]},
  {'id':'WORKING-STAGE','kind':'empirical observation policy, not approval or certification',
   'details':[
    'The proposed forward/FD tolerances are defensible only as narrowly scoped empirical comparison policies. Neighboring tests and the O(h^2)+O(u/h) heuristic do not prove a roundoff or derivative-error bound. Fixed selection with refitting, all predeclared FD steps, active-set diagnostics and stop-on-unresolved behavior are appropriate.',
    'Specify which threshold applies to the exact fixed-fit input-objective gradient comparison, particularly float32, and whether any float32 eager/JIT gradient comparison is required; the table explicitly gives only float64 eager/JIT gradient tolerances. Freeze an exact comparison expression and expected/reference operand for rtol.',
    'Keep actual represented input/fit values, exact D/D_hat/error/B, working output discrepancies, derivative observations, evidence integrity and A2 acceptance separate. No present result executes a numerical worker or establishes working-roundoff, continuous-error, A1/SCI-003, A2, AD or accelerator acceptance.'
   ]},
  {'id':'LINK-ONLY','kind':'nonsemantic documentation correction after releasing the current pin',
   'old':'phase-a-completion.md#a2-history-approximation-and-memory--open',
   'new':'phase-a-completion.md#a2-history-approximation-and-memory-open',
   'details':'Known Markdown anchor correction supplied after pinning. It is not a numerical error. Preserve the reviewed draft bytes and hash; record this narrow text delta and any substantive contract resolutions under a new protocol digest before review/freeze. Strict docs build was deferred by the parent; none was run here.'}
 ],
 'summary':'The signed-GL/prefix identity, exact-head improved bound, normalization and stated REF controls pass independent exact arithmetic. The pinned draft is not ready to freeze: failure-taxonomy precedence and canonical duplicate-content identity need explicit resolution, and its universal unknown-minimum rationale is false although the fail-closed completeness policy is sound. This is contract review only, not source approval, scientific closure, or implementation permission. Only a new scratch evidence directory was written; no repository/index/docs/code was changed.',
 'reviewed_protocol_sha256':SHA,
 'evidence_paths':[str(OUT/name) for name in [
    'exact_contract_witnesses.py','proof-run-process.json','proof-run.stdout.raw',
    'proof-summary.json','finite-fraction-witnesses.json','controls.json',
    'near-limits-float32.json','near-limits-float64.json',
    'decision_counterexamples.py','decision-counterexamples.json',
    'decision-proof-process.json','inputs-before.json','inputs-after.json',
    'reviewed-protocol.raw.md','reviewed-input-hashes.json','hash-index.json']],
 'a2_acceptance_passed':False,
 'implementation_authorized':False
}
write('verdict.json',verdict)

pins=json.loads((PARENT/'preparation-inputs.json').read_text())
paths=list(pins['baseline_numeric_inputs'])+[
 'AGENTS.md','v0.1_engineering_contract.md','docs/developer/a2-compression-budget-protocol.md',
 'docs/developer/phase-a-completion.md','docs/validation/soe-history.md']
input_hashes={p:{'sha256':h((ROOT/p).read_bytes()),'bytes':(ROOT/p).stat().st_size} for p in paths}
parent_hashes={p:{'sha256':h((PARENT/p).read_bytes()),'bytes':(PARENT/p).stat().st_size}
 for p in ['preparation-inputs.json','planning_checks.py','planning-checks.json','protocol-reviewed-draft.md']}
write('reviewed-input-hashes.json',{'repository':str(ROOT),'scope':'read-only current input identities; mutable parent-only status doc hash is an end-of-review readback',
 'repository_inputs':input_hashes,'supplied_planning_inputs':parent_hashes})

# This status read does not refresh/write the Git index.
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
idx=subprocess.check_output(['git','ls-files','--stage'],cwd=ROOT,env=env)
raw=(ROOT/'docs/developer/a2-compression-budget-protocol.md').read_bytes()
assert h(raw)==SHA and raw==(OUT/'reviewed-protocol.raw.md').read_bytes()
assert h(idx)==pins['index_entries_sha256']
assert idx==(OUT/'index-entries-before.raw').read_bytes()
assert all(input_hashes[p]['sha256']==expected for p,expected in pins['baseline_numeric_inputs'].items())
status=subprocess.check_output(['git','status','--short'],cwd=ROOT,env=env,text=True)
write('final-scope-verification.json',{'protocol_sha256':h(raw),
 'numeric_inputs_verified':len(pins['baseline_numeric_inputs']),'numeric_mismatches':[],
 'git_index_entries_sha256':h(idx),'git_index_entries_identical_before_after':True,
 'git_status_short':status,'repo_writes_performed_by_this_review':False,
 'proof_exit_codes':[0,0], 'implementation_authorized':False,'a2_acceptance_passed':False})

# No self-referential digest: index excludes itself and its detached verification.
excluded={'hash-index.json','hash-index-verification.json'}
files={p.name:{'sha256':h(p.read_bytes()),'bytes':p.stat().st_size}
 for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in excluded}
write('hash-index.json',{'algorithm':'sha256','scope':'scratch review evidence only',
 'self_reference_policy':'hash-index.json and hash-index-verification.json excluded; final result supplies detached index digest',
 'files':files,'file_count':len(files)})
loaded=json.loads((OUT/'hash-index.json').read_text())
mismatches=[name for name,e in loaded['files'].items()
 if h((OUT/name).read_bytes())!=e['sha256'] or (OUT/name).stat().st_size!=e['bytes']]
assert not mismatches and loaded['file_count']==len(loaded['files'])
verification={'index_path':str(OUT/'hash-index.json'),
 'index_sha256':h((OUT/'hash-index.json').read_bytes()),'indexed_file_count':len(files),
 'hash_and_size_readback_mismatches':mismatches,'all_indexed_handles_verified':True,
 'verdict_path':str(OUT/'verdict.json'),'verdict_sha256':h((OUT/'verdict.json').read_bytes()),
 'scope':'integrity readback, not execution authentication or scientific acceptance'}
write('hash-index-verification.json',verification)
print(json.dumps(verification,indent=2))
