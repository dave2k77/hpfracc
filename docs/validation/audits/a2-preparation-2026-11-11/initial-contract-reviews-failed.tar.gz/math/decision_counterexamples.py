"""Additional exact planning counterexamples, no numerical application or selector."""
from fractions import Fraction as F
from pathlib import Path
import json

out=Path(__file__).resolve().parent
# Exact boundary changes disappear if binary64 conversion precedes comparison.
b=F(1,4)
tau_lo=b-F(1,2**100)
tau_hi=b+F(1,2**100)
assert float(tau_lo)==float(b)==float(tau_hi)
assert not b<=tau_lo and b<=b and b<=tau_hi
# A signed-variation shortcut can falsely qualify the requested bound. This is
# not a claim that a conservative-bound rejection proves actual-error failure.
v=[F(1),F(-2),F(1)]
eps=F(1,8)
true_B=[F(0)]+[2*eps*sum(abs(z) for z in v[:i]) for i in (1,2)]
wrong_B=[F(0)]+[2*eps*abs(sum(v[:i])) for i in (1,2)]
tau=F(3,8)
assert max(wrong_B)<=tau<max(true_B)
# An intermediate time can carry all actual error even though the final output
# error is exactly zero. B itself is nondecreasing and has no such counterexample.
w=[F(1),F(-1,2),F(-1,8)]
ghat=[F(1),F(1,4),F(1,8)]
x=[F(1),F(0),F(0)]
v2=[x[0],x[1]-x[0],x[2]-x[1]]
D=[2*sum(w[k]*x[i-k] for k in range(i+1)) for i in range(3)]
H=[2*sum(ghat[k]*v2[i-k] for k in range(i+1)) for i in range(3)]
error=[abs(a-d) for a,d in zip(H,D,strict=True)]
assert error==[F(0),F(1,2),F(0)]
# Whole-selection epistemic rule: even when a known qualifier ranks ahead of an
# unknown candidate, the draft demands indeterminate because every assessment
# is mandatory. This is stricter than the bare minimum-rank inference problem.
table=[
 {'known_qualifier':True,'unknown_rank':'lower','required_selection_status':'indeterminate'},
 {'known_qualifier':True,'unknown_rank':'higher','required_selection_status':'indeterminate'},
 {'known_qualifier':False,'unknown_rank':'any','required_selection_status':'indeterminate'},
 {'known_qualifier':False,'unknown_rank':None,'all_eligible_bounds_rejected':True,
  'required_selection_status':'no_supplied_candidate_meets_bound'},
 {'known_qualifier':False,'unknown_rank':None,'eligible_candidates':0,
  'required_selection_status':'no_supplied_candidate_meets_bound'},
]
report={'scope':'exact planning counterexamples; not production decisions',
 'binary64_boundary_collision':{'bound':str(b),'tau_minus':str(tau_lo),
  'tau_plus':str(tau_hi),'all_convert_to_same_binary64':True,
  'exact_qualification':[False,True,True]},
 'signed_variation_false_qualification':{'correct_B':list(map(str,true_B)),
  'wrong_B':list(map(str,wrong_B)),'tau':str(tau)},
 'interior_actual_error_hidden_by_endpoint':list(map(str,error)),
 'whole_selection_status_policy':table,
 'taxonomy_ambiguity_witness':{
  'request':'GL alpha=1/2 dt=1/4 N=3 valid scalar data',
  'candidates':['known qualifying valid gl_prefix candidate','well-formed l1 exact-head candidate'],
  'draft_lines_54_59_possible_result':'unsupported reference -> whole-selection indeterminate',
  'draft_lines_127_135_possible_result':'incompatible fit -> ineligible; choose known qualifier',
  'resolution_needed':'Freeze request-level unsupported scope vs candidate-level incompatibility precedence'},
 'duplicate_identity_ambiguity_witness':{
  'candidate_A':{'stable_id':'a','configuration':'same','array_bytes':'same'},
  'candidate_B':{'stable_id':'b','configuration':'same','array_bytes':'same'},
  'if_complete_identity_includes_id':'distinct IDs could bypass duplicate-content rejection',
  'if_content_identity_excludes_id':'request input error as intended by read-only plan',
  'resolution_needed':'Name the canonical ID-free content-identity tuple and duplicate input-error status'},
 'a2_acceptance_passed':False,'implementation_authorized':False}
with (out/'decision-counterexamples.json').open('x') as f:
 json.dump(report,f,indent=2,allow_nan=False); f.write('\n')
print(json.dumps({'all_assertions_passed':True,'scope':report['scope'],
 'output':str(out/'decision-counterexamples.json')},indent=2))
