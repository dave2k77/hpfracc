# A2 compression-budget tracer: preparation contract

Status: **draft for independent contract review; implementation not authorized**.
Preparation was authorized by the owner: "okay, let's xget ready to start on A2."
This records preparation, not approval of the final protocol or numerical work.
Baseline: `a3951bde6a633f22ee2c1e006ea78c62421f599b`; its delivery/CI gates passed.
Protocol ID: `a2-glrl-exact-reference-v0`. Freeze reviewed bytes before any RED,
fitting/application measurement or implementation; do not embed a file's own hash.

## 1. Purpose and unchanged acceptance boundary

Prepare one private CPU-first vertical tracer: independent exact-reference
compression assessment, exhaustive supplied-candidate evaluation, deterministic
minimum-cost selection, and an explicit no-qualifying-candidate outcome. Proposed
future files are `benchmarks/numerical/_compression_budget.py` and
`tests/unit/test_compression_budget.py`; neither exists as part of preparation.
No new public API, core dependency, global precision/default, fitter, history
policy, stability tier or solver behavior is authorized here.

The [A2 programme](phase-a-completion.md#a2-history-approximation-and-memory--open)
is authoritative. This small tracer is not a scoped alternative to A2 completion.
Improving-fit refinement, broader kernels/orders/dtypes and measured CPU/CUDA
forward/reverse peak memory remain open. Per-state solver scope is unanswered.
A1/Phase A certification and the SCI-003 cancellation limitation remain open;
the private trajectory-defect helper is not this tracer's reference oracle.

## 2. Existing components, without new guarantees

- `src/hpfracc/ops/_soe.py:15-46`: existing private fit record and validation.
- `src/hpfracc/ops/_soe.py:49-115`: positive `scaled_tail` fit, exact head,
  fixed dimensionless pole grid and 400 projected updates. The accepted `t_max`
  parameter is not used by this policy's fitter; do not advertise it as an
  independent fit-accuracy control or change this behavior.
- `src/hpfracc/ops/_soe.py:118-135`: recursive application on
  `[x[0], diff(x)]` for the positive GL-prefix kernel.
- `src/hpfracc/ops/_soe.py:138-191`: working-precision kernel diagnostics,
  not an independent requested-budget oracle.
- `docs/validation/soe-history.md:53-78,118-129`: exact-head convention,
  GL-prefix identity and absolute signal-dependent compression inequality.
- `tests/unit/test_soe_recursive.py:76-117,230-265`: existing fitted-convolution,
  gradient, residual-bound and float32 eager/JIT comparisons. Existing selected
  checks are neither universal accuracy nor new tracer measurements.

## 3. Initial reference domain and resource policy

The proposed first domain is deliberately finite and real: scalar order exactly
`1/2`, uniform `dt=1/4`, lower terminal zero and zero GL/RL prehistory. GL and its
current RL alias share the same reference. Accept time-leading shapes `(N,)` and
`(N,M)`, with `1 <= N <= 17`, `1 <= M <= 3`; primary fixtures use N=3 and N=17.
Singleton coverage is an explicit proposed edge addition to the read-only plan.
Input/fit arrays must retain their actual float32 or float64 representation.
Decode each finite represented value exactly, not its intended decimal input.

Only `scaled_tail`, `gl_prefix`, `exact_head=True` candidates enter this contract.
Each must have the request's order/length and valid complete configuration:
1–8 poles, equal-length one-dimensional coefficient/decay arrays, nonnegative
finite coefficients and `0 < rho <= 1`. The real-fitter fixture uses `t_max=1`.
Unsupported kernels/orders/grids/complex data are explicit unsupported-reference
outcomes, not invalid mathematical problems or changes to public support.

Proposed per-request caps, to be reviewed and frozen:

| Resource | Cap / interpretation |
| --- | --- |
| Supplied candidates | 8; empty list is an invalid request |
| Rational primitives | 100,000, cumulative across all candidates and checks |
| Normalized integer size | 32,768 bits for each numerator and denominator |
| Serialized reference evidence | 16 MiB, including all exact output/bound arrays |
| Worker watchdog | 60 seconds of reference-worker wall time, separately recorded |

Count each rational add/subtract, multiply, divide, abs or comparison as one
primitive. Generate pole powers by charged repeated multiplication, not an opaque
uncharged power operation. Charge direct signed-sum and fitted-sum cross-checks.
Validate operand sizes before an operation and normalized result sizes afterward;
intermediate integer products may reach twice the operand cap. Work/bit/evidence
or watchdog exhaustion is **indeterminate**, not an unattainable-budget proof.
Never truncate, skip a candidate or silently increase caps. These caps constrain
this diagnostic, not the core's numerical domain or recursive memory complexity.

## 4. Exact finite mathematical contract

Use stdlib exact rational arithmetic for decoded samples and fit arrays. At
alpha=1/2 and dt=1/4 the normalization is exactly `s=2`; no Gamma, quadrature,
working-precision fitter objective or SCI-003 diagnostic is a reference.
For each time index and real feature independently:

```text
w[0] = g[0] = 1
w[k] = w[k-1] * (k-1-alpha)/k
g[k] = g[k-1] * (k-alpha)/k
v[0] = x[0]; v[j] = x[j]-x[j-1]
g_hat[0] = 1
g_hat[k] = sum_p c[p]*rho[p]**(k-1), k >= 1
epsilon = max_{0 <= k < N} abs(g_hat[k]-g[k])
D[i] = s * sum_{k=0}^i w[k]*x[i-k]
D_hat[i] = s * sum_{k=0}^i g_hat[k]*v[i-k]
B[0] = 0
B[i] = s * epsilon * sum_{j=0}^{i-1} abs(v[j]), i >= 1
```

For N=1, epsilon=0. The identity `g[k]=sum_{j=0}^k w[j]` gives the exact
signed-GL/prefix-increment equivalence. The exact head makes the current-increment
residual zero; the remaining terms obey `abs(D_hat[i]-D[i]) <= B[i]` by the
triangle inequality. Retain the initial value in v[0]. Cross-check every output
against both the independent signed full sum and the residual-weighted sum;
never rely on favorable endpoints, signed variation or floating sums of products.

A finite nonnegative exact request tau is in derivative-output units. A valid
candidate qualifies iff every time/feature B is <= tau exactly. Decimal display
rounding cannot determine qualification, and no floating slack is allowed.
Bound rejection does not prove actual error exceeds tau or another fit cannot
meet it. Separate kernel epsilon, exact finite compression error, working-output
error against D_hat/D, and any later continuous-discretization error.
An exact finite compression comparison is not a working-roundoff certificate.

## 5. Identity, records and failure taxonomy

Use proposed private frozen/slotted records, not a JIT/AD selection API. Bind
policy ID, mathematical scope, lower terminal, order/dt, input dtype/shape/bytes,
norm/tau, source/configuration, work limits and runtime/reference contexts.
A candidate has a stable ASCII ID, complete configuration, producer origin
(synthetic control or actual fitter), and actual array dtype/shape/byte hashes.
Canonical integer fields reject bool/float lookalikes. Reject duplicate IDs and
duplicate complete candidate identities rather than silently deduplicating them.
Different same-pole candidates may tie; rank by `(pole_count, stable_id)`.

Record every candidate and every reason. Nonfinite/malformed/incompatible fits
are ineligible with explicit reasons, never zero-error fits. Invalid request
metadata is an input error. Unsupported reference evaluation or resource exhaustion
makes the whole selection indeterminate, even if another candidate qualifies;
there is no justified global minimum while an assessment is unknown. Otherwise
select the minimum-ranked eligible qualifier, or return `selected_id=None` and
`no_supplied_candidate_meets_bound`. This means no supplied eligible candidate
passes this bound, not global impossibility. Never use first-success, assume
monotonic pole-count error or fall back to full history.

Preserve exact arrays/bounds and rational values. For large rationals use canonical
signed hexadecimal numerator strings and positive hexadecimal denominator strings
(no redundant leading zeros; zero is `0`); bound lengths before decoding. This
avoids Python's decimal integer-string limit without changing global limits.
Displayed small fractions are explanatory only. JSON exports use no NaN/Inf;
unavailable summaries are null with explicit status/reason, not fabricated zeros.

Keep qualification, working-output comparison and evidence-integrity results
separate. `arithmetic_verified`, `total_numerical_certified`, A2/Phase A acceptance
remain false. Host exact-reference evaluation is not CUDA arithmetic.

## 6. Frozen proposed controls: exact decisions first

All expectations below are planning arithmetic, not implemented selector results.
The first future behavioral RED must preserve test/implementation bytes, command,
raw JUnit and actual exit before repair. Module absence alone is insufficient.

| ID | Proposed fixture and required observation |
| --- | --- |
| REF-FAIL | N=3, x=(1,1,1), rho=(1/2), c=(1/2), tau=3/16. g=(1,1/2,3/8), g_hat=(1,1/2,1/4), epsilon=1/8, B=(0,1/4,1/4); D=(2,1,3/4), D_hat=(2,1,1/2). No selection; all observations retained. |
| REF-PASS | Add rho=(1/2,1), c=(1/4,1/4): exact three-lag kernel, epsilon/B zero, selected over the failing smaller candidate. Synthetic fit success is not production-fitter attainability evidence. |
| REF-RANK | Shuffle candidates; include a qualifying larger fit, a good smaller/bad larger pair, distinct same-pole qualifiers, duplicate IDs/identities. Assess all; freeze minimum-poles/lexical-ID tie behavior. |
| REF-EDGES | Zero signal, singleton, changed three-sample signal, GL/RL aliases, invalid types/tau, incompatible head/kernel/length, NaN/Inf or corrupt/missing arrays. No missing/invalid field becomes a success. |
| REF-SIGNAL | N=17: ramp k/16, step 1[k>=8], alternating (-1)^k/8, separately and stacked. Every time/feature must satisfy the exact independent bound. |
| REF-CAPS | Deliberate primitive/bit/evidence/watchdog limits; unknown work means indeterminate/no minimum, not a successful negative control or a tolerance-impossibility claim. |
| FIT-REAL | Existing fitter, N=17, alpha=1/2, dt=1/4, t_max=1, supplied poles in order (8,2,4), both float32 and float64; declared tau requests 1 and 0. Require a real-fit qualifier at 1 and no qualifier at 0; otherwise preserve the result and stop, not post-hoc retune. Determine selected ID from independent exact assessments, never a guessed pole count. |

Negative shortcut controls must fail when v[0], normalization 2, absolute
variation, a component/time sample, a supplied candidate or exact comparison is
omitted. Keep expected rejection-policy passes separate from candidate acceptance.
No current fitter/recurrence code or iteration/grid policy is changed.

## 7. Proposed working-evaluation and derivative observations

These thresholds are **proposals for independent review**, not measured results,
roundoff bounds or additions to B. Freeze or explicitly reject them before any
numerical run. They cannot rescue an exact compression-budget failure.
Only the small declared real-fitter fixtures enter these comparisons.

| Check | Proposed frozen comparison |
| --- | --- |
| Forward: recursive vs exact D_hat; full vs exact D; eager vs JIT | float32 rtol=2e-5, atol=2e-5; float64 rtol=1e-10, atol=6e-10 |
| Float64 eager/JIT gradients | rtol=2e-7, atol=2e-8 |
| Float64 central FD | h=1e-5; input directional rtol=2e-6, atol=2e-7; order rtol=2e-5, atol=2e-6 |
| Float32 central FD | h in (1/128,1/256,1/512), all predeclared; input rtol=2e-3, atol=2e-4; order rtol=5e-3, atol=5e-4 |

Float64 comparisons inherit neighboring case-specific policies from
`tests/unit/test_soe_recursive.py:76-117`, with the absolute forward allowance
scaled by the exact normalization 2. Float32 forward uses the existing long-path
compatibility policy at lines 245-265, not a new accuracy certificate. Proposed
float32 FD steps balance the heuristic competing terms O(h^2) and O(u/h), with
u=2^-24. No curvature or derivative-error bound is asserted. Independent review
must judge this sufficient as a scoped empirical observation policy; if not, the
working/FD stage stays blocked rather than being measured and retuned.

Use the objective mean(derivative_output**2) and input direction cos(x). For a
fixed selected configuration, recompute order-dependent fitted weights for AD and
perturbations; do not freeze their coefficients or reselect inside differences.
At the exact order, additionally compare fixed-fit input derivatives to the exact
rational linear-convolution objective derivative. Alpha perturbations do not extend
the rational budget evaluator's domain. Record both AD and all FD values; require
all declared steps to agree within the corresponding observation policy and each
adjacent FD pair to meet it. Record changes in final coefficient zero patterns as
a limited nonsmoothness diagnostic, not proof that intermediate active sets agree.
An unstable/nonfinite/nonsmooth comparison is unresolved evidence: preserve it and
stop, without interpreting it as general gradient correctness or loosening gates.

Scope x64 off for float32 workers, on for float64 workers, outside JIT, and restore
it. Assert actual input, fit, forward-output, objective and cotangent dtypes.
Never infer forward precision from cotangent dtype alone. Record the host rational
context separately from the explicitly captured JAX worker context.

## 8. Evidence, compute and preparation exit gates

Freeze case IDs/input bytes, source/lock/protocol, candidate list/ranking, exact
budgets, outcome classifications, caps and accepted observational policies before
measurements. No new measured rows are created during preparation. Retain all
candidate arrays, bounds, exact references, raw outputs/gradients, omissions,
invalid/exhausted outcomes, commands and real process exits with digests. Semantic
replay must bind records to raw inputs/configuration before checksumming; use
portable repository CLIs and copied tamper controls, not unshipped scratch paths.
A row/checksum checker is not execution authentication.

CPU first: the rational reference is host work and the initial application/AD
fixtures are tiny. No GPU/Colab or large benchmark is justified by this step.
Before later CUDA work discover actual resources and preserve backend-specific
precision/environment evidence; never label CUDA-selected host work GPU execution.
Diagnostic/all-candidate reference memory is not the recursive carry or measured
application peak. A later isolated-worker protocol must measure fit/application/
end-to-end and input/order reverse objectives, compilation/runtime and CPU/CUDA
peak memory separately; compiler buffers or polling alone cannot certify a peak.

Preparation exit gates: independent mathematical/contract review, explicit
resolution of threshold/cap/schema findings, exact synthetic planning checks,
documentation tests and strict build. Freeze the corrected protocol and its raw
review lineage. Then present the reviewed scope and request implementation
approval; preparation authorization is not that approval. No public/default/core
or dependency changes, no numerical implementation, no full/GPU benchmark,
no A2/Phase A closure or unanswered scope decision is authorized by this draft.
