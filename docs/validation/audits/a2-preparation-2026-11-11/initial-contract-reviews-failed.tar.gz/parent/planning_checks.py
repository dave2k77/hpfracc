"""Exact planning examples only: NOT a selector or numerical benchmark."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
out = Path('/home/davianc/.hermes/cache/scratch/a2-preparation-20261111')
out.mkdir(parents=True, exist_ok=True)
protocol = root / 'docs/developer/a2-compression-budget-protocol.md'
raw = protocol.read_bytes()
(out / 'protocol-reviewed-draft.md').write_bytes(raw)
alpha, scale = F(1, 2), F(2)
results = []
identities = 0
for n in range(1, 18):
    w, g = [F(1)], [F(1)]
    for k in range(1, n):
        w.append(w[-1] * (k - 1 - alpha) / k)
        g.append(g[-1] * (k - alpha) / k)
    assert all(sum(w[:k+1]) == g[k] for k in range(n))
    for values in ([F(1)]*n, [F(k, 16) for k in range(n)],
                   [F(int(k >= 8)) for k in range(n)],
                   [F((-1)**k, 8) for k in range(n)]):
        v = [values[0]] + [values[j] - values[j-1] for j in range(1, n)]
        direct = [scale * sum(w[k] * values[i-k] for k in range(i+1)) for i in range(n)]
        prefix = [scale * sum(g[k] * v[i-k] for k in range(i+1)) for i in range(n)]
        assert direct == prefix
        identities += 1
        for rhos, coefficients in [([F(1,2)], [F(1,2)]),
                                    ([F(1,2), F(1)], [F(1,4), F(1,4)])]:
            fitted = [F(1)] + [sum(c * r**(k-1) for c,r in zip(coefficients, rhos, strict=True)) for k in range(1,n)]
            epsilon = max(abs(a-b) for a,b in zip(fitted,g,strict=True))
            envelope = [scale * epsilon * sum(abs(z) for z in v[:i]) for i in range(n)]
            approx = [scale * sum(fitted[k] * v[i-k] for k in range(i+1)) for i in range(n)]
            residual = [scale * sum((fitted[k]-g[k]) * v[i-k] for k in range(i+1)) for i in range(n)]
            assert all(a-d == r and abs(r) <= b for a,d,r,b in zip(approx,direct,residual,envelope,strict=True))
            results.append({'n': n, 'features': 1, 'poles': len(rhos), 'exact_inequality_verified': True})
# Pinned negative/positive control values independently recomputed above.
n = 3
w = [F(1), F(-1,2), F(-1,8)]
g = [F(1), F(1,2), F(3,8)]
fitted = [F(1), F(1,2), F(1,4)]
epsilon = max(abs(a-b) for a,b in zip(fitted,g,strict=True))
bound = [F(0), 2*epsilon, 2*epsilon]
assert epsilon == F(1,8) and bound == [F(0),F(1,4),F(1,4)]
assert max(bound) > F(3,16)
assert epsilon <= F(3,16)  # WRONG omission of normalization would falsely pass.
assert F(0) <= F(3,16)  # WRONG omission of the initial GL increment falsely passes.
large = (1 << 32767) + 1
encoded = format(large, 'x')
assert int(encoded, 16) == large and len(encoded) <= 8192
# Canonical exact input types must be guarded, not trusted through ==.
assert True == 1 and 1.0 == 1
names = subprocess.check_output(['git','ls-files','--','src','tests','benchmarks','pyproject.toml','uv.lock'], text=True).splitlines()
manifest = {'scope': 'Preparation baseline, not an A2 measurement/test-collection snapshot',
            'head': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
            'protocol_sha256': hashlib.sha256(raw).hexdigest(),
            'protocol_bytes': len(raw),
            'baseline_numeric_inputs': {n: hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names},
            'index_entries_sha256': hashlib.sha256(subprocess.check_output(['git','ls-files','--stage'])).hexdigest(),
            'a2_implementation_authorized': False}
(out / 'preparation-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
report = {'scope': 'Exact synthetic planning checks only; NOT implemented selection, production fitter observations or numerical benchmark',
          'prefix_identity_signal_cases': identities, 'bound_cases': len(results),
          'all_exact_checks_passed': True, 'negative_control_epsilon': str(epsilon),
          'negative_control_bound': [str(b) for b in bound],
          'negative_shortcut_controls_expose_false_passes': True,
          'hexadecimal_bigint_roundtrip': True,
          'python_decimal_digit_limit_unchanged': sys.get_int_max_str_digits(),
          'cases': results, 'a2_acceptance_passed': False}
(out / 'planning-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
print(json.dumps({'protocol_sha256':manifest['protocol_sha256'], 'baseline_numeric_input_count':len(names)},indent=2))
