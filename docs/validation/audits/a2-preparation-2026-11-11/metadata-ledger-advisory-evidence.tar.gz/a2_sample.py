"""Static selected-case and witness structure discovery."""
import json
from pathlib import Path
P=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/docs/validation/audits/a2-preparation-2026-11-11')
f=json.loads((P/'fixtures.json').read_bytes()); s=json.loads((P/'record-schemas.json').read_bytes()); w=json.loads((P/'schema-control-fixtures.json').read_bytes())
fit=next(c for c in f['cases'] if c['group']=='FIT-REAL' and c['request']['tau']['num']=='1' and f['arrays'][c['request']['input_ref']]['dtype']=='float32')
print(json.dumps({'case':{k: (v[:3] if isinstance(v,list) else v) for k,v in fit.items()},'case_list_lengths':{k:len(v) for k,v in fit.items() if isinstance(v,list)},'input':{k:v for k,v in f['arrays'][fit['request']['input_ref']].items() if k!='raw_hex'},'candidate_samples':{r:f['candidates'][r] for r in fit['request']['candidate_refs']},'witness_bundle_keys':[{k:(list(v) if isinstance(v,dict) else len(v) if isinstance(v,list) else v) for k,v in b.items()} for b in w['bundles'][:2]],'status_witness_sample':w['status_matrix'][:2], 'full_binding_sample':w['future_full_bindings'][:1], 'exact_array':s['$defs']['exact_array']},indent=2))
