"""Read-only schema/fixture discovery; output is static metadata only."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = Path(__file__).resolve().parent
AUDIT = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
BASE = Path('/home/davianc/.hermes/cache/scratch/a2-ledger-continuation-20261112/baseline.json')

def digest(b):
    return hashlib.sha256(b).hexdigest()

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def git(*args):
    return subprocess.run(['git', '--no-optional-locks', *args], cwd=ROOT, capture_output=True, check=True).stdout

baseline = json.loads(BASE.read_bytes())
guard = {'head': git('rev-parse', 'HEAD').decode().strip(),
         'branch': git('branch', '--show-current').decode().strip(),
         'git_index_sha256': digest((ROOT / '.git/index').read_bytes()),
         'index_entries_sha256': digest(git('ls-files', '--stage')),
         'groups': {}, 'scope': 'Repository guard only. No profile discovery.'}
for group in ('packet_before', 'immutable_history', 'numerical_inputs'):
    rows = {}
    for path, ref in baseline[group].items():
        raw = (ROOT / path).read_bytes()
        expected = ref if isinstance(ref, str) else ref['sha256']
        rows[path] = {'bytes': len(raw), 'sha256': digest(raw), 'expected_sha256': expected,
                      'matches': digest(raw) == expected}
    guard['groups'][group] = rows
for key in ('head', 'git_index_sha256', 'index_entries_sha256'):
    guard[key + '_matches'] = guard[key] == baseline[key]
guard['all_protected_match'] = all(guard[k + '_matches'] for k in ('head', 'git_index_sha256', 'index_entries_sha256')) and all(r['matches'] for g in guard['groups'].values() for r in g.values())
dump(sys.argv[1] if len(sys.argv) > 1 else 'guard-before-corrected.json', guard)
summary = {}
for name in ('protocol.json', 'record-schemas.json', 'fixtures.json', 'comparison-policies.json', 'schema-control-fixtures.json', 'packet-manifest.json'):
    obj = json.loads((AUDIT / name).read_bytes())
    summary[name] = {'top_level': {k: (list(v) if isinstance(v, dict) else {'length': len(v), 'first': v[:1]} if isinstance(v, list) else v) for k, v in obj.items()}}
    if name == 'record-schemas.json':
        summary[name] = obj
    if name == 'fixtures.json':
        summary[name] = {'top_level': {k: {'kind': type(v).__name__, 'length': len(v) if isinstance(v, (list, dict)) else None} for k,v in obj.items()}}
dump('discovery.json', summary)
print(json.dumps({'all_protected_match': guard['all_protected_match'], 'counts': {k: len(v) for k,v in guard['groups'].items()}, 'schema_definitions': list(summary['record-schemas.json'].get('$defs', {})), 'fixture_keys': summary['fixtures.json']}, indent=2))
assert guard['all_protected_match']
