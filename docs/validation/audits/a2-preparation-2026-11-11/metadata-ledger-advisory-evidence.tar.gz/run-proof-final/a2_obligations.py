"""Finite static obligation/coverage proof, NOT a future operational validator.

Never import HPFRACC/JAX, run fitting/reference arithmetic, populate future fits,
or mutate repository files. Existing labelled static witnesses are metadata only.
"""
from collections import Counter, defaultdict
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import re

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
A = ROOT / 'docs/validation/audits/a2-preparation-2026-11-11'
OUT = Path(__file__).resolve().parent
LABEL = 'STATIC CONDITIONAL METADATA DESIGN; NO ACTUAL FIT/WORKER/PROCESS OBSERVATIONS'

def load(name):
    return json.loads((A/name).read_bytes())

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def nodes(value):
    if isinstance(value, dict):
        return 1 + sum(1 + nodes(v) for v in value.values())
    if isinstance(value, list):
        return 1 + sum(nodes(v) for v in value)
    return 1

def depth(value):
    if isinstance(value, dict):
        return 1 + max((depth(v) for v in value.values()), default=0)
    if isinstance(value, list):
        return 1 + max((depth(v) for v in value), default=0)
    return 1

def write(name, value):
    (OUT/name).write_bytes(json.dumps(value, indent=2, sort_keys=True).encode()+b'\n')

f, s, p, w = (load(n) for n in ('fixtures.json','record-schemas.json','protocol.json','schema-control-fixtures.json'))
defs = s['$defs']
cases = f['cases']
checks = Counter()
def check(condition, name):
    assert condition, name
    checks[name] += 1

# Closed-schema field evidence, not an implementation of record validation.
field_map = {}
for name, spec in defs.items():
    if 'properties' in spec:
        check(set(spec['required']) == set(spec['properties']), 'closed_required_fields')
        check(spec['additionalProperties'] is False, 'no_additional_fields')
        field_map[name] = {'schema_pointer': 'record-schemas.json#/$defs/'+name,
                           'required_fields': spec['required']}

counts = Counter()
case_rows = []
comparison_links = []
fit_rows = []
for ci, c in enumerate(cases):
    slots = c['required_evidence_slots']
    slotmap = {r['slot_id']: r for r in slots}
    check(len(slotmap) == len(slots), 'unique_case_slot_ids')
    comparisons = c.get('required_working_comparisons', [])
    bindings = c.get('required_fit_identity_checks', [])
    full = c.get('required_full_observations', [])
    counts.update(cases=1, slots=len(slots), comparisons=len(comparisons), binding_checks=len(bindings), full_observations=len(full))
    for r in comparisons:
        for key in ('a_slot_id','reference_slot_id'):
            check(r[key] is None or r[key] in slotmap, 'comparison_operand_preinventoried')
        if r['a_slot_id'] is None or r['reference_slot_id'] is None:
            check('adjacent' in r['policy_id'] or 'adjacent' in r['comparison_id'], 'null_comparison_is_adjacency')
        comparison_links.append({'case_id':c['case_id'],'comparison_id':r['comparison_id'], 'operands':[r['a_slot_id'],r['reference_slot_id']]})
    for r in bindings:
        group = [a for a in slots if (a['mode'],a['candidate_index'],a['branch']) == (r['mode'],r['candidate_index'],r['branch'])]
        reference = [a for a in slots if (a['mode'],a['candidate_index'],a['branch']) == (r['mode'],r['candidate_index'],r['reference_branch'])]
        check(bool(group) and bool(reference), 'fit_binding_groups_preinventoried')
    for r in full:
        check(r['slot_id'] in slotmap and r['candidate_id'] is None and r['candidate_index'] is None, 'full_candidate_free')
        check(r['comparison_id'] in {x['comparison_id'] for x in comparisons}, 'full_comparison_present')
    row = {'case_id':c['case_id'],'group':c['group'],'fixture_pointer':f'fixtures.json#/cases/{ci}',
           'quantity_slots':len(slots),'working_comparisons':len(comparisons),'fit_binding_checks':len(bindings),
           'full_observations':len(full),'slot_inventory_sha256':sha(canonical(slots)),
           'comparison_inventory_sha256':sha(canonical(comparisons)), 'binding_inventory_sha256':sha(canonical(bindings))}
    case_rows.append(row)
    if c['group'] == 'FIT-REAL':
        groups = defaultdict(list)
        for a in slots:
            groups[(a['mode'],a['candidate_index'],a['branch'])].append(a)
        row = dict(row, dtype=f['arrays'][c['request']['input_ref']]['dtype'], input_shape=f['arrays'][c['request']['input_ref']]['shape'],
                   tau=c['request']['tau'], candidates=c['request']['candidate_refs'],
                   conditional_groups=[{'mode':k[0], 'candidate_index':k[1], 'branch':k[2],
                                        'quantities':[x['quantity'] for x in v], 'slot_ids':[x['slot_id'] for x in v]} for k,v in groups.items()])
        fit_rows.append(row)
check(dict(counts) == {'cases':560,'slots':24336,'comparisons':1312,'binding_checks':1056,'full_observations':64}, 'inventory_totals')
check(max(len(c['required_evidence_slots']) for c in cases) == 954, 'maximum_inventory')
future = {k:v for k,v in f['candidates'].items() if 'producer_call' in v}
check(len(future)==12, 'future_spec_count')
check(all(v['rhos_ref'] is None and v['coefficients_ref'] is None for v in future.values()), 'future_arrays_remain_absent')
check(len(w['future_full_bindings'])==64 and all(v['observation']['producer'] is None and v['observation']['producer_binding_sha256'] is None for v in w['future_full_bindings']), 'future_full_observations_remain_unobserved')

# Actual canonical relationships in pre-existing labelled static bundles.
# No new runtime observation, coefficient, objective or exact output is invented.
witness_rows=[]
for b in w['bundles']:
    artifacts=b['artifacts']
    rows=[]
    for path, record in artifacts.items():
        rows.append({'path':path,'record_type':record.get('record_type'),'canonical_bytes':len(canonical(record)), 'nodes':nodes(record),'depth':depth(record),'sha256':sha(canonical(record))})
        if record.get('record_type')=='slot':
            raw=record['raw_array']
            if raw is not None:
                check(len(bytes.fromhex(raw['raw_hex']))==raw['nbytes'], 'witness_raw_byte_length')
                check(sha(bytes.fromhex(raw['raw_hex']))==raw['sha256'], 'witness_raw_digest')
            if record['producer_binding_sha256'] is not None:
                candidates=[r for r in artifacts.values() if r.get('record_type')=='producer_binding' and sha(canonical(r))==record['producer_binding_sha256']]
                check(len(candidates)==1, 'witness_slot_binding_digest')
                bind=candidates[0]
                check(bind['case_id']==record['case_id'] and bind['candidate_index']==record['candidate_index'] and bind['mode']==record['mode'], 'witness_slot_binding_identity')
                payloads=[r for r in bind['returned'] if r['slot_id']==record['slot_id'] and r['quantity']==record['quantity']]
                check(len(payloads)==1, 'witness_named_payload_unique')
                e=record['exact_array']
                descriptor=({'shape':e['shape'],'values_count':len(e['values']),'payload_sha256':sha(canonical(e))}
                            if e is not None else {k:v for k,v in raw.items() if k!='raw_hex'})
                check(payloads[0]['descriptor']==descriptor, 'witness_returned_descriptor_exact_fields_and_values')
        if record.get('record_type')=='result':
            inline=record['shared_slots']+[sl for a in record['assessments'] for sl in a['slots']]
            wrapper=35+len(record['reasons'])+sum(13+len(a['reasons']) for a in record['assessments'])
            check(wrapper+sum(nodes(sl) for sl in inline)==nodes(record), 'result_inline_node_formula')
            for sl in inline:
                if sl['status'] in ('complete','partial'):
                    check(sl==artifacts['arrays/'+sl['slot_id']+'.json'], 'witness_result_inline_equals_standalone')
        if record.get('record_type')=='failure_index':
            for slot in record['slots']:
                art=slot['artifact']
                if art is not None:
                    check(art['path'] in artifacts, 'witness_index_artifact_exists')
                    raw=canonical(artifacts[art['path']])
                    check(art['bytes']==len(raw) and art['sha256']==sha(raw), 'witness_index_artifact_digest_length')
        if record.get('record_type')=='run_manifest':
            for r in record['files']:
                check(r['path'] in artifacts and r['path']!='run-manifest.json', 'witness_manifest_external')
                raw=canonical(artifacts[r['path']])
                check(r['bytes']==len(raw) and r['sha256']==sha(raw), 'witness_manifest_digest_length')
    witness_rows.append({'witness_id':b['witness_id'],'label':b['label'],'declared_case_id':b['declared_case_id'],
                         'artifact_count':len(artifacts),'canonical_artifact_bytes':sum(r['canonical_bytes'] for r in rows),
                         'initial_index_bytes':len(canonical(b['initial_failure_index'])), 'records':rows})

# Cardinality formula checks on all existing static slot encodings.
slots_seen=[]
def collect(x):
    if isinstance(x,dict):
        if x.get('record_type')=='slot': slots_seen.append(x)
        for v in x.values(): collect(v)
    elif isinstance(x,list):
        for v in x: collect(v)
collect(w)
for slot in slots_seen:
    r=len(slot['reasons'])
    formula=29+r
    if slot['raw_array'] is not None:
        formula += 14+len(slot['raw_array']['shape'])
    if slot['exact_array'] is not None:
        e=slot['exact_array']
        formula += 4+len(e['shape'])+5*len(e['values'])
    check(formula==nodes(slot),'slot_node_formula')

# Conservative field-level maxima. This is a syntax envelope, NOT reachable
# numerical output or simultaneous valid scientific branch evidence.
def schema_bound(spec, measure):
    if '$ref' in spec:
        return schema_bound(defs[spec['$ref'].split('/')[-1]],measure)
    if 'oneOf' in spec or 'anyOf' in spec:
        return max(schema_bound(x,measure) for x in spec.get('oneOf',spec.get('anyOf')))
    if 'enum' in spec:
        return max(nodes(x) if measure=='nodes' else len(canonical(x)) for x in spec['enum'])
    t=spec['type']
    if t=='object':
        if measure=='nodes': return 1+sum(1+schema_bound(v,measure) for v in spec['properties'].values())
        return 2+max(0,len(spec['properties'])-1)+sum(len(canonical(k))+1+schema_bound(v,measure) for k,v in spec['properties'].items())
    if t=='array':
        m=spec['maxItems']
        if measure=='nodes': return 1+m*schema_bound(spec['items'],measure)
        return 2+max(0,m-1)+m*schema_bound(spec['items'],measure)
    if measure=='nodes': return 1
    if t=='string':
        # Six bytes per ASCII character safely covers every JSON escape.
        # ID/hex-safe patterns have exact no-escape maxima instead.
        pat=spec.get('pattern','')
        noescape = pat in ('^[0-9a-f]{64}$','^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$','^(0|-?[1-9a-f][0-9a-f]*)$','^[1-9a-f][0-9a-f]*$','^(?:[0-9a-f]{2})*$')
        return 2+(1 if noescape else 6)*spec['maxLength']
    if t=='integer': return max(len(str(spec.get('minimum',0))),len(str(spec['maximum'])))
    if t=='boolean': return 5
    if t=='null': return 4
    raise AssertionError(t)

upper={k:{'nodes':schema_bound(v,'nodes'),'canonical_bytes':schema_bound(v,'bytes'),
           'scope':'Conservative closed-schema syntax maximum; NOT a necessity or reachability proof.'}
       for k,v in defs.items() if k in field_map}

# Exact length expressions: constants obtained from empty safe renderings.
# These are length skeletons, never emitted as actual FIT records.
empty_exact={'shape':[],'values':[]}
raw_shape_base={'dtype':'float32','shape':[],'byte_order':'little','layout':'C','nbytes':0,'raw_hex':'','sha256':'0'*64}
rat0={'num':'0','den':'1'}
rat_constant=len(canonical(rat0))-2
check(len(canonical(empty_exact))==24,'exact_empty_bytes')
# Array brackets already included; nonempty values add m-1 separators.
# shape_json_length includes brackets.
length_formulas={
 'json_recurrence':{'string':'len(canonical(s)); symbolic ASCII must bound escaping, not just characters',
                    'integer':'decimal digit length including sign',
                    'array':'2 + max(0,k-1) + sum(element_byte_lengths)',
                    'object':'2 + max(0,k-1) + sum(len(canonical(key))+1+value_byte_length)'},
 'rational':f'{rat_constant} + len(num) + len(den)',
 'exact_array':'22 + len(canonical(shape)) + (max(0,m-1) + sum(19 + len(num_i) + len(den_i)))',
 'raw_array':'len(canonical(raw_array_with_same_dtype_shape_byte_order_layout_SHA_and_nbytes_but_empty_raw_hex)) + 2*nbytes',
 'raw_descriptor':'len(canonical(raw_array_without_raw_hex))',
 'exact_descriptor':'len(canonical({shape: exact_shape, values_count: m, payload_sha256: SHA256(canonical(exact_array))})); NO payload byte-count field exists here',
 'slot_nodes':'29+r [null payloads]; +14+rank for raw; +4+rank+5*m for exact; r=length(reasons)',
 'index_slot_nodes':'25+r+rank(expected_shape)+[rank(completed_shape) if nonnull else 0]+[6 if artifact nonnull else 0]',
 'result_nodes':'35+r_result + sum_over_assessments(13+r_assessment) + sum(nodes(all inline shared/assessment slots)); 36+14*K+sum(slot_nodes) when every reason list has one item',
 'manifest_nodes':'11 + 7*F (F file entries); manifest is outside its own hash scope but its own bytes are charged',
 'payload_hex_limits':{'num':8193,'den':8192,'raw_hex':8192,'exact_values':289},
 'conditional_terms':'For each slot retain independent symbolic canonical payload E_s or known raw length; equality of bytes/descriptor digests is a separate constraint, not implied by equal lengths.'}
# Verify exact-array byte formula on all static arrays. 19 is rat syntax overhead.
for sl in slots_seen:
    e=sl['exact_array']
    if e is not None:
        estimate=22+len(canonical(e['shape']))+max(0,len(e['values'])-1)+sum(19+len(r['num'])+len(r['den']) for r in e['values'])
        check(estimate==len(canonical(e)), 'exact_array_byte_formula')
    raw=sl['raw_array']
    if raw is not None:
        empty=dict(raw,raw_hex='')
        check(len(canonical(empty))+2*raw['nbytes']==len(canonical(raw)),'raw_array_byte_formula')
for b in w['bundles']:
    for row in b['artifacts']['failure-index.json']['slots']:
        calc=25+len(row['reasons'])+len(row['expected_shape'])
        if row['completed_shape'] is not None: calc+=len(row['completed_shape'])
        if row['artifact'] is not None: calc+=6
        check(calc==nodes(row), 'index_slot_node_formula')

# Selected winner coverage = 4x4 mode outcomes, not three simultaneous winners.
profiles=[]
for e in (None,0,1,2):
    for j in (None,0,1,2):
        stage='selected_working' if e is not None and e==j else 'base_noqualifier' if e is None and j is None else 'agreement_stop'
        profiles.append({'eager_winner':e,'jit_winner':j,'stage':stage,
                         'working_candidates':[e] if stage=='selected_working' else [],
                         'base_candidates':'all supplied occurrences in each mode',
                         'gate_status':'conditional; unknown anywhere overrides completed selection'})
check(Counter(x['stage'] for x in profiles)=={'selected_working':3,'base_noqualifier':1,'agreement_stop':12},'finite_winner_profiles')
branches=[
 {'id':'selected-agree','coverage':'each of the three possible selected configured candidates, eager/JIT agree; all other derivative slots/checks typed not_applicable'},
 {'id':'selected-disagree','coverage':'12 differing winner/noqualifier pairs; preserve each actual mode assessment, no common derivative continuation'},
 {'id':'noqualifier','coverage':'all known eligible-rejected or authenticated ineligible; tau0 gate, full references retained'},
 {'id':'ineligible','coverage':'fully authenticated local incompatibility/malformed/nonfinite/negative/rho defects; actual reasons; all corresponding numerical slots not_applicable'},
 {'id':'unknown-lower-rank','coverage':'known qualifier plus unknown lower rank => indeterminate by EXHAUSTIVE'},
 {'id':'unknown-higher-rank','coverage':'known qualifier plus unknown higher rank => indeterminate by EXHAUSTIVE, not mathematical minimum theorem'},
 {'id':'unknown-plus-incompatible','coverage':'causal missing/corrupt producer first; retain locally observable incompatibility, not completed ineligible'},
 {'id':'partial','coverage':'one immutable nonempty proper time-leading prefix; authentic payload and binding; expected/completed shapes retain missing suffix'},
 {'id':'primitive-cap','coverage':'before attempted primitive; finished artifacts retained, remaining explicit'},
 {'id':'bit-cap','coverage':'normalized result/operands bounded; unfinished never bound-rejected'},
 {'id':'byte-cap','coverage':'reserve final transaction before output; no omitted evidence or hidden partial bytes'},
 {'id':'timeout','coverage':'watchdog normal/terminate-grace/kill-confirmed or exit-unconfirmed; indeterminate even after qualifier'},
 {'id':'zero-watchdog','coverage':'barrier held and never released; no numerical observations; confirmed exit receipt separate'},
 {'id':'after-qualifier','coverage':'mandatory checkpoint after candidate0 qualifier, later unknown; whole indeterminate'},
 {'id':'preflight-invalid','coverage':'syntax/type/tau/duplicate ID+content/empty; bounded original capture request=null when noncanonical; occurrences kept separately'},
 {'id':'unsupported','coverage':'admitted unsupported request retains true transport shapes, all slots/checks; no arithmetic'},
 {'id':'unadmitted-envelope','coverage':'bounded prefix/retained-prefix hash/received length if known; no unlimited ID or raw retention promise'},
 {'id':'reservation-refusal','coverage':'bounded preflight failure; worker_launched false; not satisfaction of mandatory tau1 positive gate'},
 {'id':'unsafe-output','coverage':'fresh failure root only if safely created; no adoption or deletion of foreign target'},
 {'id':'comparison-binding-gate-fail','coverage':'preserve mismatch/nonsmooth/unstable/gate contradiction, no tolerance relaxation or borrowed arrays'},
 {'id':'unused-adjacency','coverage':'h at base/ad-base unused; nonselected branches; float64 singleton FD adjacency with null operands typed not_applicable'}]

# Monotone node upper for a chosen all-inventory-inline result, without any
# pretend FIT coefficients or rational values. Exact shapes alone fix nodes.
input_q={'input','v','D','D_hat','error','B','analytic_input_gradient','output','full_output','input_AD','direction'}
lag_q={'w','g','g_hat','residual','signed_fitted_weights'}
fit_q={'rhos','coefficients','zero_pattern'}
exact_q=set(f['exact_slot_inventory']['shared'])|set(f['real_worker_inventory']['per_base_candidate_exact_slots'])|{'zero_pattern'}
result_node_rows=[]
for c in cases:
    if c['group']!='FIT-REAL': continue
    shape=f['arrays'][c['request']['input_ref']]['shape']; n=shape[0]
    for winner in (0,1,2):
        totals={'null_slot_nodes':0,'base_exact_extra_nodes':0,'all_inventory_payload_extra_upper_nodes':0}
        for sl in c['required_evidence_slots']:
            q=sl['quantity']; idx=sl['candidate_index']; branch=sl['branch']
            poles=f['candidates'][c['request']['candidate_refs'][idx]]['configuration']['pole_count'] if idx is not None else None
            sh=shape if q in input_q else [n] if q in lag_q else [n,n] if q=='L_hat' else [poles] if q in fit_q else []
            m=math.prod(sh)
            totals['null_slot_nodes']+=30
            extra=4+len(sh)+5*m if q in exact_q else 14+len(sh)
            is_exact_base=(sl['mode']=='shared' or (branch=='base' and q in exact_q and q!='zero_pattern'))
            if is_exact_base: totals['base_exact_extra_nodes']+=extra
            # Selected-only derivative continuation, not simultaneously all three.
            active=(idx is None or branch=='base' or (c['request']['tau']['num']=='1' and idx==winner))
            if active: totals['all_inventory_payload_extra_upper_nodes']+=extra
        # result 17 fields + singleton reasons; assessment 6 fields + reasons.
        wrapper=36+14*len(c['request']['candidate_refs'])
        result_node_rows.append({'case_id':c['case_id'],'winner_index':winner,
                                **totals, 'wrapper_nodes':wrapper,
                                'all_inline_base_complete_lower':wrapper+totals['null_slot_nodes']+totals['base_exact_extra_nodes'],
                                'all_inline_selected_payload_single_reason_upper':wrapper+totals['null_slot_nodes']+totals['all_inventory_payload_extra_upper_nodes'],
                                'all_inline_selected_payload_32_reason_upper':wrapper+totals['null_slot_nodes']+totals['all_inventory_payload_extra_upper_nodes']+31*(len(c['required_evidence_slots'])+1+len(c['request']['candidate_refs'])),
                                'scope':'Chosen all-inventory result placement. Lower requires full inline inventory plus all completed base exact slots. Payload upper overapproximates unused h/direction. The single-reason upper applies only to one-reason dispositions; the 32-reason upper is conservative without cause reachability assumptions. Not a universal unavoidable-format lower bound.'})

reasons=defs['reason']['enum']
non_none=[r for r in reasons if r!='none']
longest=sorted(non_none,key=lambda r:len(canonical(r)),reverse=True)[:defs['reasons']['maxItems']]
reason_bound={'enum_count':len(reasons),'max_list_items':defs['reasons']['maxItems'],
              'max_schema_reason_nodes':1+defs['reasons']['maxItems'],
              'max_distinct_non_none_reason_array_bytes':len(canonical(longest)),
              'longest_32_by_serialized_length':longest,
              'scope':'Conservative envelope only. None exclusive; causal first then frozen order; actual observable subset must be justified, not padded.'}

# Demonstrate that syntactic bit/value caps do not establish the whole-byte cap.
# No such rational array is asserted to be a reachable GL/fit output.
syntactic_max_exact=22+len(canonical([17,17]))+288+289*(19+8193+8192)
syntactic_example={'label':'Typed-length upper-envelope calculation, NOT generated values or a scientific lower bound',
                  'one_289_value_exact_array_upper_bytes':syntactic_max_exact,
                  'six_base_Lhat_arrays_two_inline_standalone_copies_upper_bytes':6*2*syntactic_max_exact,
                  'evidence_cap_bytes':p['caps']['evidence_bytes'],
                  'conclusion':'This conservative upper exceeds the cap; it neither proves actual overflow nor universal feasibility. Use actual constrained lengths in the closed ledger inequality.'}

obligations=[
 {'id':'O-input','when':'admitted request','required':'immutable input-bundle.json; full bounded received request or exact canonical reconstruction; supplied occurrences and ALL quantity/comparison/binding inventory',
  'copies':'one file; request/candidates inline in request when canonical; optional standalone request/candidates NOT forced',
  'pointers':['record-schemas.json#/$defs/input_bundle','schema-control-contract.md:11-48','packet-notes.md:48-56,150-156']},
 {'id':'O-index','when':'admitted request, before arithmetic and finalization','required':'all index_slot rows; ALL comparison/binding_check dispositions; occurrences; inline process; accounting snapshots',
  'copies':'initial I0, checkpoint Iq when mandatory injection/qualifier commit, final If; at most one old+new physical coexistence; each generation written once and charged',
  'pointers':['record-schemas.json#/$defs/failure_index','schema-control-contract.md:188-229','packet-notes.md:136-148']},
 {'id':'O-slot','when':'complete or partial slot','required':'arrays/{slot_id}.json immutable record_type=slot; exactly one raw/exact payload and binding digest; index artifact canonical byte count/hash and shapes',
  'copies':'1 standalone mandatory for complete/partial; result inline according to chosen placement; working observation inline for invoked quantities. No standalone artifact required for null unavailable/inapplicable rows.',
  'pointers':['record-schemas.json#/$defs/slot','record-schemas.json#/$defs/index_slot','packet-notes.md:136-139']},
 {'id':'O-result','when':'admitted finalized result','required':'structured result; occurrence-aware assessments; shared slots; all reasons and false preparation flags',
  'copies':'chosen conservative design places each inventory slot exactly once in assessment or shared_slots, plus mandatory standalone complete/partial copies; no flattening/references replacing inline slot fields',
  'pointers':['record-schemas.json#/$defs/result','record-schemas.json#/$defs/assessment','metadata-budget-accounting-assessment.json#/pre_edit_gate_assessment/separate_resource_questions/per_record_nodes']},
 {'id':'O-observation','when':'actual invoked fit/apply/AD/FD or full-reference branch; pending forms allowed but not universally mandatory standalone routes','required':'own invocation and same-mode actual auxiliaries; full producer candidate-free; selected ad-base retains joint cotangents',
  'copies':'one observation wrapper per invocation with its own inline slots, not just references. Exact host references and derived FD scalars need truthful separate binding context; do not invent JAX invocations.',
  'pointers':['record-schemas.json#/$defs/observation','schema-control-contract.md:83-137','fixtures.json#/real_worker_inventory','packet-notes.md:58-81']},
 {'id':'O-binding','when':'every complete/partial numerical payload','required':'canonical producer_binding record; descriptors keyed to actual returned payload; source/config/case/occurrence/mode/branch/input/alpha/dt/h/q/launch crosslinks',
  'copies':'one binding can cover an invocation returned set (<=64), not forced one per slot; descriptors copy metadata, never raw_hex/exact values; host exact binding independent truthful producer',
  'pointers':['record-schemas.json#/$defs/producer_binding','record-schemas.json#/$defs/named_payload','record-schemas.json#/$defs/raw_descriptor','record-schemas.json#/$defs/exact_descriptor','schema-control-contract.md:102-137']},
 {'id':'O-checks','when':'every inventoried comparison/fit check, including unused/incomplete','required':'inline dispositions in initialized and final index; declared operand/observation links; real mismatch causes',
  'copies':'standalone comparison/check JSON routes optional unless actually emitted or referenced by chosen graph; no extra forced full-route family',
  'pointers':['record-schemas.json#/$defs/comparison','record-schemas.json#/$defs/binding_check','schema-control-contract.md:50-74','packet-notes.md:143-148']},
 {'id':'O-process','when':'launched request; preflight process model unavailable/not_applicable before launch','required':'immutable launch before barrier release; immutable final process with timing/exit confirmation; inline process copy in each index; later export references finalized index and final process',
  'copies':'standalone launch/process/export plus inline index process; own write durations/digests not required recursively',
  'pointers':['record-schemas.json#/$defs/launch_receipt','record-schemas.json#/$defs/process','record-schemas.json#/$defs/supervisor_export','schema-control-contract.md:114-165']},
 {'id':'O-lifecycle','when':'every output and failure branch','required':'actual bounded raw logs (if produced), owned staging/partial files, output-control truthful receipt, external run manifest exact immutable entries and its charged own length',
  'copies':'no hidden/deleted-byte loophole; rename same inode is not a second data write; copied publication costs actual copied bytes',
  'pointers':['record-schemas.json#/x-artifact-routing','record-schemas.json#/$defs/run_manifest','record-schemas.json#/$defs/output_control','schema-control-contract.md:167-240']},
 {'id':'O-refusal','when':'transport/unowned output/preflight reservation refusal','required':'bounded_failure retained prefix digest (not whole unretained input); no worker launched; preserve mandatory positive gates unresolved',
  'copies':'no all-inventory promise for unadmitted malicious envelope; admitted invalid/unsupported requests still retain true bounded inventories',
  'pointers':['record-schemas.json#/$defs/bounded_failure','schema-control-contract.md:179-186,219-229','packet-notes.md:150-156']}
]

dag=[
 {'from':'external frozen packet + pinned sources','to':'input bundle','relation':'packet/source path/digest and occurrence inventory'},
 {'from':'input bundle','to':'launch','relation':'input_bundle_sha256; actual run/process/case/request/command/PID'},
 {'from':'decoded immutable raw bytes or canonical exact_array','to':'payload descriptors','relation':'sha256(raw) plus nbytes, or payload_sha256=sha256(canonical exact_array) plus values_count and shape; exact_descriptor has no byte-count field'},
 {'from':'launch + payload descriptors','to':'producer binding','relation':'entire canonical binding payload SHA; no own digest'},
 {'from':'producer binding + payload','to':'slot and observation wrappers','relation':'binding SHA plus identical occurrence/mode/branch/config/source/context; inline payload equality'},
 {'from':'launch','to':'final process','relation':'same launch SHA/run/process/case/input; actual exit/phase data'},
 {'from':'immutable slot artifacts + final process + checks','to':'final index','relation':'artifact raw file SHA/length/shape; inline process equals standalone; all dispositions'},
 {'from':'final index + final process','to':'later export','relation':'index and process byte digests/length; completed index-write timing, not receipt own duration'},
 {'from':'all emitted immutable artifacts and actual logs','to':'external run manifest','relation':'actual file byte lengths and SHA; exclude manifest self hash; still charge its own length'}]

schedule={
 'permission':'Bounded batching interpretation supported by explicit schedule requirement; no sentence requires a full-index rewrite for every array. Never reinterpret required qualifier checkpoint as optional.',
 'pointers':['a2-compression-budget-protocol.md:376-383','schema-control-contract.md:188-209,219-229','packet-notes.md:158-175'],
 'generations':['I0 persisted before arithmetic, every row/check initialized','Iq only when qualifier/fault checkpoint required, after completed committed qualifier artifacts','If final: normal/partial/kill/failure; mandatory reserved final write'],
 'atomic_batches':'Commit immutable complete/partial artifact batch then update index. Final supervisor reconciliation must authenticate every retained artifact and explicitly account unfinished ones; a stale checkpoint is never a completed result. No crash-recovery implementation is supplied here.',
 'max_generations_for_this_design':3,
 'index_transaction_peak':'Tidx = max(I0, I0+Iq+Pq+Eq, Iq+If+Pf+Ef, I0+If+Pf+Ef) over applicable branches; include any coexisting retained earlier index generations and owned partial index buffers actually present',
 'conservative_reserve':'Ridx >= max(I0+Iq, Iq+If, I0+If) + Pmax + Emax + applicable bounded preflight/root-failure/output-control receipts; no arbitrary padding. Safe overreserve sum(I0,Iq,If,Pmax,Emax,receipts) is not necessary minimum.',
 'cumulative_index_writes':'I0 + [Iq] + If (not 954*full_index_size). Replacement deletes old live inode only after confirmed ownership/removal; old bytes never subtracted from cumulative.',
 'reserve_before_work':'Freeze exact count, actual bounded metadata values and required failure variants. Budget Rfinal before launch and before every later batch. If no safe update fits, stop before unreportable work.',
 'limitations':'Batching alone cannot cure known old/new index-transaction lower bounds >512KiB. It can remove an unjustified every-array cumulative-write blow-up. Arbitrary actual output streams or partial-file retries are not bounded by this design unless count/length constraints are explicit.'}

ledger={
 'per_record_nodes':'For each individual JSON record r: N(r)<=json_nodes and D(r)<=16. Never sum nodes across files or old+new generations.',
 'index_only':'Tidx<=failure_index_bytes; input bundle separately <=262144; descriptors inline in index count here, referenced slot payload files do not.',
 'whole_cumulative':'C = B_input + sum(committed standalone slot writes) + B_result + sum(observation writes including inline slots) + sum(binding writes including descriptors) + sum(actual optional request/candidate/comparison/check copies) + B_launch + B_final_process + B_export + B_output_control + sum(index_generation writes) + B_logs + B_manifest + B_bounded_failure_receipts + B_nonpublished_partial_or_copy_writes <=16777216',
 'whole_live':'L(t) = sum(length of every retained owned inode at t, including completed evidence, temporary/partial buffers/files, coexisting old/new index, retained superseded indexes, failure root files) <=16777216. Same inode rename counted once; buffer if serialized to disk is charged.',
 'sufficient_finite_schedule':'No retry copies; one immutable commit per slot; rename/no-copy publication; at most 3 index generations; max one uncommitted payload/index staging file at once, exact bounded partial bytes charged; immutable completed artifacts retained. C includes every byte written, therefore L(t)<=C whenever no preexisting/adopted bytes (forbidden). Prove C<=cap and Tidx<=Ridx separately with concrete bounded values or constrained symbolic terms.',
 'conditional_inequality':'Let E_s be canonical exact payload bytes; raw payload length fixed by dtype/shape. C = K(actual bounded record metadata/receipts/logs/index generations/manifest) + sum_s mu_s*E_s + sum_s nu_s*raw_hex_len_s, with mu_s and nu_s derived from EVERY chosen inline/standalone occurrence, not guessed twice-slot allowances. K must be expanded by JSON recurrence, never an ancillary bucket. Require evaluated/upper-bounded C<=16777216. Equal lengths do not prove digest links.',
 'manifest_closure':'M = canonical run_manifest(entries with every emitted immutable file actual length/hash; no own entry). File lengths known before M; M length then computable, reserved and charged. No self-hash/fixed-point required.',
 'snapshots':'result.evidence_bytes and index.bytes_accounting snapshots BEFORE their serialization; reserve then charge full pending length. They are not final totals and cannot be zeroed to hide earlier writes.',
 'future_unknowns':'12 fit specifications and 64 full observations remain absent. Rational string lengths bounded and reduced; raw array size fixed. Process integers/commands/actual logs bounded with unavailable timings rather than clipped values. Conditional metadata size proof is not coefficient qualification, actual receipt authentication or runtime feasibility.'}

map_value={'label':LABEL,'independent_role':'Read-only advisory derived from frozen packet; not final approval of future author work',
 'counts':dict(counts),'max_slots_per_case':954,'source_fields':field_map,'obligations':obligations,
 'artifact_routing_allowlist':s['x-artifact-routing'],'routing_is_not_must_emit':True,
 'case_inventory':case_rows,'fit_conditional_groups':fit_rows,'winner_profiles':profiles,'branch_coverage':branches,
 'digest_relationships_dag':dag,'index_schedule':schedule,'resource_formulas':ledger,'length_and_node_formulas':length_formulas,
 'reason_cardinality_bound':reason_bound,
 'lower_upper_distinction':{'known_old_index_obstruction':'Eight preserved necessary old+new lower bounds 614748..617184 exceed 524288. They prove that index byte revision is required for those mandatory positive-case paths, NOT a universal whole-ledger fit.',
 'node_result_choice':'All-inventory-inline result bound is a design/placement bound, not a theorem that schema minimum must inline every unused working slot. No mutually exclusive winner payloads counted simultaneously.',
 'whole_cap':'Generic syntax/bit maxima do not entail 16MiB feasibility. Conversely exceeding a conservative upper is not an actual-data impossibility proof.'},
 'scope_conclusion':'No intrinsic need for actual numerical execution or representation redesign to close a finite conditional metadata graph. Universal positive admission under unchanged16MiB cannot be asserted from field caps. Any budget-only revision remains conditional on author-expanded K and copy multiplicities satisfying full ledger; owner-authorized cycle and fresh independent review remain required.',
 'no_implementation_or_acceptance':True}
write('obligation-map.json',map_value)
write('resource-proof.json',{'label':LABEL,'schema_syntax_upper_bounds':upper,'reason_bound':reason_bound,'all_inline_result_node_bounds':result_node_rows,'syntactic_bit_envelope':syntactic_example,'formula_scope':'No cap proposal; design-specific/conservative bounds are labelled, never actual future arrays.'})
write('witness-proof.json',{'label':LABEL,'bundles':witness_rows,'slot_formula_encodings_checked':len(slots_seen),'future_fit_specs_still_null':len(future),'future_full_still_unobserved':len(w['future_full_bindings'])})
write('comparison-link-proof.json',{'label':LABEL,'links':comparison_links})
summary={'label':LABEL,'counts':dict(counts),'checks':dict(checks),'existing_labelled_witness_bundles_checked':len(witness_rows),
         'slot_formula_encodings_checked':len(slots_seen), 'winner_profiles':len(profiles),'branch_classes':len(branches),
         'all_inline_result_lower_minmax':[min(r['all_inline_base_complete_lower'] for r in result_node_rows),max(r['all_inline_base_complete_lower'] for r in result_node_rows)],
         'all_inline_result_single_reason_upper_max':max(r['all_inline_selected_payload_single_reason_upper'] for r in result_node_rows),
         'all_inline_result_32_reason_upper_max':max(r['all_inline_selected_payload_32_reason_upper'] for r in result_node_rows),
         'syntax_only_example':syntactic_example,
         'obligation_map_sha256':sha((OUT/'obligation-map.json').read_bytes())}
write('proof-summary.json',summary)
print(json.dumps(summary,indent=2))
