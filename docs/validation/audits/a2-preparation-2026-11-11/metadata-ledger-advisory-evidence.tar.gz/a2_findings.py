"""Write a concise findings document derived from the actual static proof files."""
import json
from pathlib import Path
O=Path(__file__).resolve().parent
summary=json.loads((O/'proof-summary.json').read_bytes())
lower=json.loads((O/'index-lower-proof.json').read_bytes())
controls=json.loads((O/'controls-and-static-schedules.json').read_bytes())
resources=json.loads((O/'resource-proof.json').read_bytes())
fit32=[r for r in resources['all_inline_result_node_bounds'] if '-tau1-f32-' in r['case_id']]
text=f'''# Independent obligation and coverage advisory

**Outcome:** finite conditional metadata accounting is possible without numerical execution or representation redesign. This advisory is not approval of the parallel author's future work, a sufficient whole-ledger budget revision, an actual FIT-REAL result, or protocol freeze. No particular new cap is endorsed.

## Verified findings

- Parsed 560 frozen cases, 24,336 quantity slots, 1,312 working comparisons, 1,056 fit-binding checks and 64 candidate-free full-observation declarations. Maximum inventory is 954 slots. The 12 future fitter specifications still have null fit-array references; the 64 full observations still have no actual producers/bindings.
- `obligation-map.json` names ten obligation families, their schema/contract pointers and exact required fields, per-case inventory hashes, all 16 eager/JIT winner/noqualifier profiles, and 21 finite disposition/failure classes. Three agreeing winner profiles permit selected derivative continuation; twelve disagreeing pairs stop; the agreeing noqualifier pair stops after the base gate. Ineligible, unknown higher/lower rank, combined missing-producer/incompatible, partial, timeout/zero-barrier, preflight invalid, unsupported and resource/refusal paths remain distinct.
- `graph-closure-design.json` maps every FIT quantity slot to a finite source-bound host/base/fit/full/derived-FD group and its required copy rule. The chosen all-result placement uses payload coefficients two (standalone+result for host exact/derived FD) or three (standalone+result+invoked observation); input-bundle raw copies and descriptor metadata are additional explicit terms. At most 34 potentially invoked observation groups and 53 binding groups occur for one selected float32 profile, not all three derivative candidates simultaneously. These are conservative conditional cardinalities, not observed invocation counts.
- Independent smaller-than-valid skeletons give **{lower['obstructed_minmax'][0]:,}..{lower['obstructed_minmax'][1]:,} bytes** as necessary old+new index bounds for eight float32 tau1 cases, exceeding the 524,288-byte reservation even before real process/export context. This independently weaker derivation does not replace the preserved 614,748..617,184 historical bounds. The final proof uses twice an absolute per-generation minimum, so it does not assume the predecessor is necessarily I0. These deliberately invalid undersized skeletons are length lower-bound devices, never valid exports.
- Slot-node formula, counting keys: null payload `29+r`; raw payload adds `14+rank`; exact payload adds `4+rank+5*m`. The formulas were checked against {summary['slot_formula_encodings_checked']} existing labelled slot encodings, including inline duplicates. Index-slot formula was checked against 446 rows; exact payload byte formula against 170 encodings. A result has `35+r_result + sum(13+r_assessment) + sum(inline slot nodes)`. For the chosen all-inventory result placement, float32 tau1 completed-base lower bounds are {min(r['all_inline_base_complete_lower'] for r in fit32):,}..{max(r['all_inline_base_complete_lower'] for r in fit32):,}; selected payload upper is at most {summary['all_inline_result_single_reason_upper_max']:,} with one reason per list, or {summary['all_inline_result_32_reason_upper_max']:,} under conservative 32-reason bounds. **These placement-specific bounds do not prove every schema-permitted layout unavoidably exceeds the node cap.**
- Seventeen pre-existing explicitly STATIC/HYPOTHETICAL bundles passed the checked binding descriptor, artifact length/digest, result-inline-copy and manifest-entry relationships. {controls['control_count']} changed copied-record negative controls were rejected after recomputing their outer digest. A no-copy two-generation metadata schedule for those existing witnesses fits the stated byte caps, maximum cumulative {max(r['cumulative_bytes'] for r in controls['witness_schedules']):,} bytes; these small/pending/partial witnesses do not close positive FIT-REAL feasibility.

## Schedule permitted by the existing text

The contract explicitly requires scheduling index updates within the cumulative budget (`schema-control-contract.md` 188-209), permits atomic index replacement and says prior index digests need not be embedded. `a2-compression-budget-protocol.md` 376-383 says commit **arrays** atomically, then update index; it does not say a full-index rewrite after every individual array. A bounded I0 / required qualifier-checkpoint Iq / final If schedule is therefore a defensible reading, not a change to the numerical protocol. Preserve the explicit candidate0 qualifier fault checkpoint (`packet-notes.md` 158-175).

This interpretation is conditional on immutable batch commits, a reserved final update, and final supervisor authentication/accounting of every retained artifact after partial/kill. Do not turn a stale checkpoint into a completed result or silently discard completed files. No crash recovery/exporter implementation is supplied here. Batching removes an unjustified every-array cumulative rewrite estimate; it does **not** remove unavoidable old+new coexistence or the index byte obstruction above.

## Three separate resource proofs

1. **Per JSON record:** independently enforce nodes and depth; do not add nodes over files/transactions. Read every required field, all inline slot copies and reason-list cardinalities. `resource-proof.json` includes closed-schema syntactic upper bounds. The enum contains {resources['reason_bound']['enum_count']} reason codes, lists permit at most 32; none is exclusive, causes are unique/ordered with causal unavailable first. A 32-longest-string envelope is a conservative bound, not permission to pad reasons or drop actual causes. A claimed path must itself preserve all compatible observable causes within the list cap.
2. **Index transaction:** max coexisting old/new generations plus actual bounded standalone process/export/applicable receipts; referenced array payloads belong to the whole ledger, not this reservation. Input remains separately capped. Charge cumulative I0+[Iq]+If, not one full rewrite per slot. Actual retained superseded generations, if any, add live bytes and were not silently assumed free.
3. **Whole request, unchanged 16 MiB live AND cumulative:** sum input, every standalone slot, result/observation inline payload copy, binding descriptors, actual optional copies, launches/process/export, every index generation, actual bounded logs, all partial/staging/copy writes, root-failure receipts, and manifest **including its own actual length**. A no-copy rename is one data write, not two; failed staging bytes still count. With fresh roots, no preexisting/adopted bytes, no retries/unbounded buffers and all writes included, live bytes are bounded by cumulative writes. Check both accounting interpretations and reserve the final transaction before each batch.

Use exact canonical JSON recurrence in `obligation-map.json`. For exact array shape `sh`, m values:

`E = 22 + len(canonical(sh)) + max(0,m-1) + sum(19+len(num_i)+len(den_i))`.

The exact descriptor is **shape, values_count, payload_sha256**; it has no payload byte-count field. Raw descriptors exclude raw_hex and hash actual decoded bytes. Slot-file index descriptors are path, bytes, sha256 and hash the complete standalone wrapper. The producer binding hashes its entire canonical payload, not a wrapper containing its own digest. Same length does not establish same digest/content; same-mode equality must be an independently checked predicate, never cross-mode borrowing.

The constrained whole expression is `C = expanded fixed-field/descriptor/receipt/index/log/manifest terms + sum(payload copy coefficients * canonical payload length)`. Expand those terms by their actual required fields; do not insert a residual ancillary allowance. Manifest length is computable after its entry byte counts are known; exclude only its own hash/entry, not its produced bytes. Snapshots in result/index are pre-serialization, not final totals.

## Scope obstacles and what remains for the author

No inherent scope obstacle requires JAX/fitter/AD execution to finish this **conditional metadata** design. The real obstacle to a universal sufficiency claim is missing constrained actual-length feasibility, not missing physical future files per se. Field maxima allow one 289-value exact array upper envelope of {summary['syntax_only_example']['one_289_value_exact_array_upper_bytes']:,} bytes; six Lhat arrays with two copies upper-bound {summary['syntax_only_example']['six_base_Lhat_arrays_two_inline_standalone_copies_upper_bytes']:,} bytes. An upper bound exceeding 16 MiB proves neither actual overflow nor impossibility; it shows generic bit caps alone do not certify sufficiency. Do not synthesize convenient coefficients/rationals or receipts to make the inequality pass.

The author must evaluate/upper-bound the entire selected conditional graph, all per-record bounds and the separate ledger using justified symbolic lengths and digest constraints, and show the final inequality within unchanged 16 MiB or stop with the precise unsatisfied condition. Routing is an allowlist: standalone request/candidate/comparison/check copies, uninvoked observations and output-control receipts are not all mandatory merely because routes exist. If chosen, every copy is charged. Completed/partial index-referenced slot artifacts are mandatory (`packet-notes.md` 136-139). Structured result/observation inline schema fields cannot be replaced by references as an unapproved redesign. Host exact and derived FD scalars must not be mislabeled as extra actual fitter invocations.

## Reproduction and evidence

All checks use stdlib under `uv run --frozen --no-sync --extra dev python -B`; no project imports or numerical processes. From the repository workdir, the captured commands are in each run's plan/process JSON; exact pre-run script copies and raw stdout/stderr are retained. Final relevant handles:

- `run-proof-final2/` (obligations, relationships, formulas), `run-graph/` (finite group closure)
- `run-lower-02/` (independent necessary byte lower bounds)
- `run-controls-02/` (10 negative controls and existing static witness schedules)
- `guard-before-corrected.json`, `guard-after.json`, `guard-comparison.json`
- `evidence-index.json`, `evidence-index-verification.json` (all indexed bytes read back)

Two harness failures are preserved: first discovery used NUL-delimited Git index entries against the parent's newline-delimited digest; actual index bytes matched, and corrected discovery matched all protected inputs. The first control run accidentally aliased its inline and standalone dictionaries, so its copy tamper changed both; corrected independent clones reject the mutant. Intermediate successful projections with an inferred exact-descriptor byte-count and an undercounted wrapper constant were superseded by schema-field-based descriptors and executable inline formula checks. None is a packet/numerical defect. Raw prior processes are not relabeled passing.

No repository, index, numerical source, status/tracker, configuration, profile or skill writes were performed; only this unique scratch directory was written. No global-profile guard was attempted. No commit/stage/push, protocol freeze, worker/selector/operational validator, scientific gate change or final independent approval was performed.
'''
(O/'findings-methodology.md').write_text(text)
print(json.dumps({'findings_bytes':len(text.encode()),'proof_summary_obligation_map_sha256':summary['obligation_map_sha256'],'independent_index_minmax':lower['obstructed_minmax'],'advisory_only':True},indent=2))
