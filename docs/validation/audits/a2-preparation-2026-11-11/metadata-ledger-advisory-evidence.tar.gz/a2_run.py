"""Capture exact pre-run scratch sources, raw streams and real exits."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
script = BASE / sys.argv[1]
run = BASE / sys.argv[2]
run.mkdir(exist_ok=False)
sources = {}
for source in sorted(BASE.glob('*.py')):
    raw = source.read_bytes()
    (run / source.name).write_bytes(raw)
    sources[source.name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
command = ['uv', 'run', '--frozen', '--no-sync', '--extra', 'dev', 'python', '-B', str(script)] + sys.argv[3:]
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
plan = {'command': command, 'cwd': str(ROOT), 'pre_run_sources': sources,
        'claim_scope': 'Actual stdlib static-planning subprocess, NOT a numerical worker.'}
(run / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
start = time.monotonic_ns()
with (run / 'stdout.txt').open('wb') as stdout, (run / 'stderr.txt').open('wb') as stderr:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, check=False)
receipt = {'returncode': result.returncode, 'elapsed_ns': time.monotonic_ns()-start,
           'command': command, 'streams': {n: {'bytes': (run/n).stat().st_size, 'sha256': hashlib.sha256((run/n).read_bytes()).hexdigest()} for n in ('stdout.txt','stderr.txt')}}
(run / 'process.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
print((run / 'stdout.txt').read_text())
print((run / 'stderr.txt').read_text())
sys.exit(result.returncode)
