"""Close finite symbolic artifact grouping and copy multiplicities, metadata only."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
A=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/docs/validation/audits/a2-preparation-2026-11-11')
O=Path(__file__).resolve().parent
f=json.loads((A/'fixtures.json').read_bytes())
baseexact=set(f['real_worker_inventory']['per_base_candidate_exact_slots'])
rows=[]
for ci,c in enumerate(f['cases']):
 if c['group']!='FIT-REAL': continue
 groups=defaultdict(list)
 for sl in c['required_evidence_slots']:
  q=sl['quantity']; idx=sl['candidate_index']; branch=sl['branch']; mode=sl['mode']
  family=('host_shared' if mode=='shared' else 'host_base_exact' if branch=='base' and q in baseexact else 'full_invocation' if q=='full_output' else 'derived_FD' if q in ('input_FD','order_FD') else 'fit_invocation')
  groups[(mode,idx,branch,family)].append(sl)
 covered=[x['slot_id'] for v in groups.values() for x in v]
 assert len(covered)==len(set(covered))==len(c['required_evidence_slots'])
 group_rows=[]
 for (mode,idx,branch,family),slots in groups.items():
  assert len(slots)<=64
  is_observation=family in ('fit_invocation','full_invocation')
  group_rows.append({'family':family,'mode':mode,'candidate_index':idx,'branch':branch,
                     'slot_ids':[r['slot_id'] for r in slots],
                     'producer_binding':'one if any complete/partial payload, descriptors for actual returned set; own truthful context',
                     'observation':'one per invoked composition, inline slots' if is_observation else 'no required observation wrapper in this chosen graph; never invent fit/AD invocation for exact-host or derived FD data',
                     'invocation_eligible':'base/full/shared conditional on request support and authentication' if branch=='base' else 'tau1 AND same selected winner in eager/JIT AND this candidate is that winner AND preceding gates complete',
                     'slot_copy_multiplicity':'one inline result disposition always; if complete/partial add one standalone slot payload; additionally one inline observation slot for actual invoked fit/full composition' if is_observation else 'one inline result disposition always; complete/partial adds one standalone slot payload',
                     'payload_byte_coefficient_when_complete':3 if is_observation else 2,
                     'unknown_not_applicable':'no standalone payload artifact and no fabricated binding; no required uninvoked observation file',
                     'known_unused':'h at base/ad-base and other unused quantities retain null typed not_applicable; payload multiplicity is zero, not a guessed raw array'})
 profiles=[]
 for winner in (0,1,2):
  active=[g for g in group_rows if g['branch']=='base' or (c['request']['tau']['num']=='1' and g['candidate_index']==winner)]
  profiles.append({'winner':winner,'condition':'only if same eligible qualifying winner in both modes; not a claimed winner',
                   'potential_binding_groups_upper':len(active),'potential_invoked_observation_groups_upper':sum(g['family'] in ('fit_invocation','full_invocation') for g in active),
                   'slot_artifacts_upper_if_all_active_quantities_complete':sum(len(g['slot_ids']) for g in active),
                   'scope':'Conservative active-group bound, still includes quantities required to be unused. NOT a valid all-complete realization.'})
 rows.append({'case_id':c['case_id'],'fixture_pointer':f'fixtures.json#/cases/{ci}', 'groups':group_rows,'profiles':profiles})
value={'label':'FINITE SYMBOLIC METADATA GRAPH, NOT ACTUAL NUMERICAL RECORDS','case_count':len(rows),
       'symbolic_constraints':['For every complete/partial slot s, define its own canonical payload variable P_s, raw bytes or reduced exact rationals with frozen dtype/shape/value count and length bounds. Future arrays remain absent.','Hraw_s=SHA256(decoded raw bytes); Hexact_s=SHA256(canonical exact_array); raw nbytes matches dtype times shape product. Exact descriptor fields are shape, values_count, payload_sha256 (no byte length).','Binding B_g hashes canonical entire producer_binding, referring to payload DESCRIPTORS, never wrapper containing H(B_g). Slot wrapper and observation carry H(B_g). Index hash/bytes refer to canonical standalone slot wrapper.','Base and selected ad/input perturbation same-mode fit equality is an independent conditional byte-identity predicate. Eager and JIT raw arrays are different variables unless actual identity is authenticated. Order perturbations use their actual alpha/refit, not a base identity assumption.','Each inline result/observation copy is the SAME slot record, not merely a same-shaped replacement. Every named binding return resolves to exactly one owned actual slot payload.','Only executed compositions may have actual producer/launch context; unknown/uninvoked forms use explicit typed unavailable/unused dispositions. Partial artifacts are immutable proper prefixes and retain expected shape in index.','Manifest lists exactly emitted immutable files and actual logs, not every allowed route. Its own serialized length is charged after all entry lengths/hashes are known.','An arithmetic-reference relation is an unevaluated external predicate in this metadata proof; no convenient rational values, qualifiers, process clocks, worker outputs or receipts are manufactured.'],
       'whole_ledger_expression':'Expand JSON recurrence over all fields of common records and each active group. Payload coefficient is 2 for host exact/derived FD, 3 for fit/full composition slots in this chosen all-result placement. Multiply only complete/partial payloads; add null-disposition wrapper bytes everywhere else. Add input-bundle raw copies separately, descriptors in each binding, ALL index/check copies per generation, each observation/result wrapper, actual optional route copies, bounded logs/partial staging, and manifest INCLUDING own length. This is a derived coefficient map, not an ancillary allowance.',
       'non_FIT_cases':'Use frozen per-case inventory checked by obligation-map and same host_shared/host_base_exact binding/slot/result rules; no working observation family or full fitter attribution is invented.',
       'rows':rows}
(O/'graph-closure-design.json').write_bytes(json.dumps(value,indent=2).encode()+b'\n')
print(json.dumps({'fit_cases':len(rows),'inventory_slots_covered':sum(len(g['slot_ids']) for r in rows for g in r['groups']),'maximum_observation_groups_for_one_selected_profile':max(p['potential_invoked_observation_groups_upper'] for r in rows for p in r['profiles']),'max_binding_groups':max(p['potential_binding_groups_upper'] for r in rows for p in r['profiles'])},indent=2))
