"""Red-capable controls for static metadata relationships, not product replay."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
A=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/docs/validation/audits/a2-preparation-2026-11-11')
O=Path(__file__).resolve().parent
w=json.loads((A/'schema-control-fixtures.json').read_bytes())
s=json.loads((A/'record-schemas.json').read_bytes())
def can(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def sha(x): return hashlib.sha256(x).hexdigest()
def descriptor(slot):
 e=slot['exact_array']
 return {'shape':e['shape'],'values_count':len(e['values']),'payload_sha256':sha(can(e))} if e is not None else {k:v for k,v in slot['raw_array'].items() if k!='raw_hex'}
def node(x):
 if isinstance(x,dict): return 1+sum(1+node(v) for v in x.values())
 if isinstance(x,list): return 1+sum(node(v) for v in x)
 return 1

controls=[]
def reject(name, good, mutate, predicate):
 assert predicate(good), name+' positive control'
 bad=deepcopy(good); mutate(bad)
 assert can(bad)!=can(good), name+' non-no-op'
 # Recomputed outer byte hash authenticates the mutant, not its relationship.
 outer={'payload_sha256':sha(can(bad)),'bytes':len(can(bad))}
 assert outer['payload_sha256']==sha(can(bad))
 rejected=not predicate(bad)
 assert rejected,name+' must reject'
 controls.append({'name':name,'positive_pass':True,'mutant_changed':True,'mutant_rejected':rejected,'recomputed_outer':outer})

b=next(x for x in w['bundles'] if any(v.get('record_type')=='slot' and v['status']=='complete' for v in x['artifacts'].values()))
art=b['artifacts']
slot=next(v for v in art.values() if v.get('record_type')=='slot' and v['status']=='complete')
binding=next(v for v in art.values() if v.get('record_type')=='producer_binding' and sha(can(v))==slot['producer_binding_sha256'])
returned=next(r for r in binding['returned'] if r['slot_id']==slot['slot_id'])
pair={'slot':slot,'returned':returned}
pred=lambda x: x['returned']['descriptor']==descriptor(x['slot']) and x['returned']['slot_id']==x['slot']['slot_id'] and x['returned']['quantity']==x['slot']['quantity']
reject('exact_descriptor_values_count',pair,lambda x:x['returned']['descriptor'].__setitem__('values_count',len(slot['exact_array']['values'])+1),pred)
reject('exact_descriptor_payload_digest',pair,lambda x:x['returned']['descriptor'].__setitem__('payload_sha256','f'*64),pred)
reject('exact_descriptor_shape',pair,lambda x:x['returned']['descriptor'].__setitem__('shape',[]),pred)
reject('named_payload_quantity',pair,lambda x:x['returned'].__setitem__('quantity','epsilon'),pred)
reject('named_payload_slot_identity',pair,lambda x:x['returned'].__setitem__('slot_id','wrong-slot'),pred)
idx=next(r for r in art['failure-index.json']['slots'] if r['artifact'] is not None)
idxpair={'index_artifact':idx['artifact'],'slot':art[idx['artifact']['path']]}
idxpred=lambda x:x['index_artifact']['bytes']==len(can(x['slot'])) and x['index_artifact']['sha256']==sha(can(x['slot']))
reject('index_artifact_length',idxpair,lambda x:x['index_artifact'].__setitem__('bytes',x['index_artifact']['bytes']+1),idxpred)
reject('index_artifact_digest',idxpair,lambda x:x['index_artifact'].__setitem__('sha256','f'*64),idxpred)
p={'inline':deepcopy(slot),'standalone':deepcopy(slot)}
reject('result_inline_copy',p,lambda x:x['inline'].__setitem__('candidate_index',31),lambda x:x['inline']==x['standalone'])
reasonpair={'reason':slot['reason'],'reasons':slot['reasons']}
reject('reason_primary',reasonpair,lambda x:x.__setitem__('reason','watchdog'),lambda x:x['reason']==x['reasons'][0])
reject('reason_no_duplicates',reasonpair,lambda x:x['reasons'].append(x['reasons'][0]),lambda x:len(x['reasons'])==len(set(x['reasons'])))

witness_schedules=[]
for b in w['bundles']:
 a=b['artifacts']; lens={k:len(can(v)) for k,v in a.items()}
 i0=len(can(b['initial_failure_index'])); final=lens['failure-index.json']
 # Existing witness two-generation export, no copied staging writes, no logs.
 cumulative=sum(lens.values())+i0
 tx=i0+final+sum(lens.get(k,0) for k in ('records/process.json','records/export.json','records/output-control.json','records/preflight-failure.json'))
 witness_schedules.append({'witness_id':b['witness_id'],'label':b['label'],
                           'input_bytes':lens['input-bundle.json'],'index_transaction_conservative_bytes':tx,
                           'cumulative_bytes':cumulative,'live_upper_bytes':cumulative,
                           'manifest_own_charged_bytes':lens['run-manifest.json'],
                           'max_record_nodes':max(node(v) for v in a.values()),
                           'within_input_cap':lens['input-bundle.json']<=262144,
                           'within_index_cap':tx<=524288,'within_live_cumulative_cap':cumulative<=16777216,
                           'assumptions':['existing labelled witness contents only','I0 then final, no qualifier intermediate required beyond this retained post-fault final state','one immutable write per other artifact','rename no-copy publication','no logs, no failed partial staging writes; if produced must add exact lengths'],
                           'not_a_complete_positive_fit_witness':True})
output={'claim_scope':'Static local relationship assertions and pre-existing labelled metadata schedules only. No operational replay/validator/selector or numerical execution.',
        'controls':controls,'control_count':len(controls),'witness_schedules':witness_schedules,
        'all_existing_static_schedules_fit':all(r['within_input_cap'] and r['within_index_cap'] and r['within_live_cumulative_cap'] for r in witness_schedules)}
(O/'controls-and-static-schedules.json').write_bytes(json.dumps(output,indent=2).encode()+b'\n')
print(json.dumps({'controls':len(controls),'all_mutants_rejected':all(r['mutant_rejected'] for r in controls),'static_witnesses':len(witness_schedules),'all_existing_static_schedules_fit':output['all_existing_static_schedules_fit'],'max_static_cumulative_bytes':max(r['cumulative_bytes'] for r in witness_schedules)},indent=2))
