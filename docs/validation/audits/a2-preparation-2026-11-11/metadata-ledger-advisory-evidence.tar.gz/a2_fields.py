"""Reduce frozen schema and inventory into reviewable field evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=Path(__file__).resolve().parent
A=ROOT/'docs/validation/audits/a2-preparation-2026-11-11'
def load(n): return json.loads((A/n).read_bytes())
s=load('record-schemas.json'); f=load('fixtures.json'); w=load('schema-control-fixtures.json'); p=load('protocol.json')
def reduce_def(d):
    if not isinstance(d,dict): return d
    if 'properties' in d: return {'required': d.get('required'), 'fields': {k: ({kk:vv for kk,vv in v.items() if kk not in ('description',)}) for k,v in d['properties'].items()}, **{k:v for k,v in d.items() if k not in ('properties','required','type','additionalProperties')}}
    return d
out={'index_formats': {},'caps':p['caps'],'protocol_resource_fields':{k:v for k,v in p.items() if any(x in k for x in ('byte','lifecycle','export','resource','node','string'))}, 'schema_extensions':{k:v for k,v in s.items() if k.startswith('x-')}, 'definitions':{k:reduce_def(v) for k,v in s['$defs'].items()}, 'fixture_inventories':{k:v for k,v in f.items() if k in ('exact_slot_inventory','real_worker_inventory','counts')}, 'case_sample':f['cases'][0], 'fit_cases':[c for c in f['cases'] if c['case_id'].startswith('FIT-REAL')][:1], 'witness_summary':{k:{'type':type(v).__name__,'length':len(v) if isinstance(v,(dict,list)) else None} for k,v in w.items()}}
for args in [('ls-files','--stage'),('ls-files','--stage','-z'),('ls-files','-s'),('ls-files',)]:
 b=subprocess.run(['git','--no-optional-locks',*args],cwd=ROOT,capture_output=True,check=True).stdout
 out['index_formats'][' '.join(args)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
(OUT/'field-evidence.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k in ('index_formats','caps','fixture_inventories','case_sample','fit_cases','witness_summary')},indent=2))
