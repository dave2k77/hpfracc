"""Index and independently read back every completed advisory artifact."""
import hashlib
import json
from pathlib import Path

O=Path(__file__).resolve().parent
excluded={'evidence-index.json','evidence-index-verification.json'}
# The final indexing subprocess is still producing streams/receipt; its exact
# command/source/raw exit are bound by the separately returned run receipt.
excluded_prefixes=('run-final-index/',)
def sha(b): return hashlib.sha256(b).hexdigest()
def load(p): return json.loads((O/p).read_bytes())
required_runs=['run-proof-final2','run-graph','run-lower-02','run-controls-02','run-findings','run-guard-after']
processes=[]
for name in required_runs:
    plan=load(name+'/plan.json'); receipt=load(name+'/process.json')
    assert receipt['returncode']==0,(name,receipt)
    for n,r in receipt['streams'].items():
        raw=(O/name/n).read_bytes()
        assert len(raw)==r['bytes'] and sha(raw)==r['sha256']
    for n,r in plan['pre_run_sources'].items():
        raw=(O/name/n).read_bytes()
        assert len(raw)==r['bytes'] and sha(raw)==r['sha256']
    processes.append({'run':name,'returncode':receipt['returncode'],'plan_sha256':sha((O/name/'plan.json').read_bytes()),'process_sha256':sha((O/name/'process.json').read_bytes())})
summary=load('proof-summary.json')
assert summary['obligation_map_sha256']==sha((O/'obligation-map.json').read_bytes())
assert load('guard-comparison.json')['passed']
assert load('controls-and-static-schedules.json')['control_count']==10
assert load('index-lower-proof.json')['obstructed_case_count']==8
files=[]
for p in sorted(O.rglob('*')):
    if p.is_dir(): continue
    rel=p.relative_to(O).as_posix()
    if rel in excluded or rel.startswith(excluded_prefixes): continue
    assert p.is_file() and not p.is_symlink(),rel
    raw=p.read_bytes()
    files.append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
index={'label':'Read-only independent advisory proof index; no numerical evidence/approval',
       'self_hash_excluded':True,'excluded_records':sorted(excluded),'excluded_in_progress_run_prefixes':list(excluded_prefixes),
       'files':files,'file_count':len(files),'process_receipts_verified':processes}
(O/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
readback=load('evidence-index.json')
for row in readback['files']:
    raw=(O/row['path']).read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
assert len(readback['files'])==readback['file_count']==len({r['path'] for r in readback['files']})
verification={'passed':True,'indexed_files_verified':len(files),'indexed_bytes':sum(r['bytes'] for r in files),
              'index_sha256':sha((O/'evidence-index.json').read_bytes()),'project_guards_passed':True,
              'actual_successful_static_process_receipts_verified':len(processes),
              'future_author_reviewed':False,'whole_positive_fit_ledger_approved':False,
              'own_hash_excluded':True,'final_indexing_run_excluded_from_index':'run-final-index (separate raw process receipt)',
              'method':'Fresh bytes re-read for each exact indexed target after manifest write.'}
(O/'evidence-index-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps(verification,indent=2))
