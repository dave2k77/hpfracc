"""Display every distinct finite FIT slot/check grouping, no array data."""
from collections import defaultdict
import json
from pathlib import Path
p=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/docs/validation/audits/a2-preparation-2026-11-11')
f=json.loads((p/'fixtures.json').read_bytes())
for dtype in ('float32','float64'):
 c=next(c for c in f['cases'] if c['group']=='FIT-REAL' and c['request']['tau']['num']=='1' and f['arrays'][c['request']['input_ref']]['dtype']==dtype)
 groups=defaultdict(list)
 for row in c['required_evidence_slots']:
  if row['candidate_index'] in (None,0): groups[(row['mode'],row['candidate_index'],row['branch'])].append(row['quantity'])
 print(json.dumps({'dtype':dtype,'case':c['case_id'],'groups':[{'key':k,'quantities':v} for k,v in groups.items()]},indent=2))
