"""Necessary index byte lower bounds; intentionally smaller-than-valid skeletons.
No skeleton is an observation or a schema-valid export. Only fixed mandatory
field names/inventory/IDs and shortest length representatives are charged.
"""
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
A=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/docs/validation/audits/a2-preparation-2026-11-11')
O=Path(__file__).resolve().parent
f=json.loads((A/'fixtures.json').read_bytes()); s=json.loads((A/'record-schemas.json').read_bytes())
def can(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
input_q={'input','v','D','D_hat','error','B','analytic_input_gradient','output','full_output','input_AD','direction'}
lag_q={'w','g','g_hat','residual','signed_fitted_weights'}
fit_q={'rhos','coefficients','zero_pattern'}
rows=[]
for c in f['cases']:
 if c['group']!='FIT-REAL': continue
 shape=f['arrays'][c['request']['input_ref']]['shape']; ids=[f['candidates'][r]['stable_id'] for r in c['request']['candidate_refs']]
 initial=[]; final=[]
 for sl in c['required_evidence_slots']:
  q=sl['quantity']; idx=sl['candidate_index']; poles=None if idx is None else f['candidates'][c['request']['candidate_refs'][idx]]['configuration']['pole_count']
  sh=shape if q in input_q else [shape[0]] if q in lag_q else [shape[0],shape[0]] if q=='L_hat' else [poles] if q in fit_q else []
  row={k:sl[k] for k in ('slot_id','candidate_index','mode','branch','quantity')}
  row.update(candidate_id=ids[idx] if idx is not None else None,status='not_evaluated',reason='not_evaluated',reasons=['not_evaluated'],expected_shape=sh,completed_shape=None,artifact=None)
  assert set(row)==set(s['$defs']['index_slot']['required'])
  initial.append(row)
  final.append(dict(row,status='unknown',reason='none',reasons=['none'],completed_shape=[]))
 comps=[]
 for r in c.get('required_working_comparisons',[]):
  idx=r['candidate_index']
  comps.append(dict(record_type='comparison',comparison_id=r['comparison_id'],case_id=c['case_id'],candidate_id=ids[idx] if idx is not None else None,candidate_index=idx,policy_id=r['policy_id'],a_slot_id=r['a_slot_id'],reference_slot_id=r['reference_slot_id'],status='not_evaluated',reasons=['not_evaluated']))
 bindings=[]
 for r in c.get('required_fit_identity_checks',[]):
  idx=r['candidate_index']
  bindings.append(dict(record_type='binding_check',case_id=c['case_id'],candidate_id=ids[idx],candidate_index=idx,mode=r['mode'],branch=r['branch'],reference_branch=r['reference_branch'],observation_id='A',reference_observation_id='A',comparison=r['comparison'],status='not_evaluated',reasons=['not_evaluated'],check_id=r['check_id']))
 i0=dict(record_type='failure_index',request_id=c['case_id'],input_bundle_sha256='0'*64,candidate_ids=ids,candidate_occurrences=[{'candidate_index':i,'candidate_id':v} for i,v in enumerate(ids)],slots=initial,status='not_evaluated',reasons=['not_evaluated'],process=None,comparisons=comps,binding_checks=bindings,bytes_accounting={'live_bytes':0,'cumulative_written_bytes':0,'reserved_final_transaction_bytes':0})
 assert set(i0)==set(s['$defs']['failure_index']['required'])
 final_checks=lambda xs:[dict(x,status='pass',reasons=['none']) for x in xs]
 i1=dict(i0,slots=final,status='complete',reasons=['none'],comparisons=final_checks(comps),binding_checks=final_checks(bindings))
 pair=2*len(can(i1))  # Every predecessor/successor independently >= this skeleton.
 row={'case_id':c['case_id'],'dtype':f['arrays'][c['request']['input_ref']]['dtype'],'tau':c['request']['tau'],'slots':len(initial),'initial_skeleton_bytes':len(can(i0)),'replacement_skeleton_bytes':len(can(i1)),'initial_plus_replacement_skeleton_bytes':len(can(i0))+len(can(i1)),'old_plus_new_necessary_lower_bytes':pair,'exceeds_524288':pair>524288,
      'label':'INTENTIONALLY SMALLER-THAN-VALID INDEX LENGTH SKELETON; NOT RECORDS OR NUMERICAL RESULTS'}
 rows.append(row)
 # Preserve only the largest fixed-cardinality skeleton pair, with explicit label.
 if c['case_id']=='FIT-stacked-tau1-f32-GL':
  (O/'index-lower-skeletons.json').write_bytes(json.dumps({'label':row['label'],'invalidity_disclosure':['process=null below mandatory object size','replacement unknown/none invalid disposition but shorter than a legal one','completed_shape=[] minimum even for non-scalar expected shape','checks pass with missing operands is invalid but shorter; no semantic claim'], 'initial':i0,'replacement':i1},indent=2).encode()+b'\n')
summary={'label':'NECESSARY byte lower bounds ONLY; no full feasibility proof','rows':rows,'obstructed_case_count':sum(r['exceeds_524288'] for r in rows),
         'lower_bound_reasoning':['Canonical compact serialization is no longer than any whitespace-bearing equivalent record.','All mandatory field names, fixed IDs, expected shapes and inventory/check rows retained.','process=null is smaller than any required process object. No process/receipt coexisting extra bytes charged.','unknown is a shortest allowed slot status, none the shortest reason; [] shortest allowed completed-shape serialization; null is shorter than an artifact object.','One-character observation IDs lower-bound optional null-or-ID fields; they are not asserted identities. Each real final check status has at least pass length, with nonempty reasons.','Old and new must physically coexist for atomic replacement, regardless of number of earlier updates.'],
         'obstructed_minmax': [min(r['old_plus_new_necessary_lower_bytes'] for r in rows if r['exceeds_524288']),max(r['old_plus_new_necessary_lower_bytes'] for r in rows if r['exceeds_524288'])]}
(O/'index-lower-proof.json').write_bytes(json.dumps(summary,indent=2).encode()+b'\n')
print(json.dumps({'cases':len(rows),'obstructed_case_count':summary['obstructed_case_count'],'obstructed_minmax':summary['obstructed_minmax']},indent=2))
assert summary['obstructed_case_count']==8
