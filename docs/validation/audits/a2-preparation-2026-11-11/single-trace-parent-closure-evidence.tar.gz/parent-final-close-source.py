"""Complete only the independently reviewed one-case metadata/accounting increment."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

from a2_preserve_failed_review import OUT, ROOT, archive, checked, sha, verify_pins
from a2_preserve_routing_correction import indexed

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / 'a2-routing-parent-5fnrmmf8'
CORRECTOR = HERE.parent / 'a2-routing-corrector-tcyfzwif'
REVIEW = HERE.parent / 'a2-routing-independent-review-Lnvtx4VN'


def execute_capture(phase, mode, arguments):
    cmd = ['uv', 'run', '--project', str(ROOT), '--frozen', '--no-sync', 'python', '-B',
           str(PARENT / 'a2_corrector_capture.py'), phase, str(PARENT / 'candidate'), mode, *arguments]
    result = subprocess.run(cmd, cwd=ROOT, capture_output=True)
    (PARENT / (phase + '-wrapper-stdout.raw')).write_bytes(result.stdout)
    (PARENT / (phase + '-wrapper-stderr.raw')).write_bytes(result.stderr)
    process = json.loads((PARENT / phase / 'process.json').read_text())
    assert result.returncode == 0 and process['actual_child_exit'] == 0
    return process


if __name__ == '__main__':
    protected = verify_pins()
    corrected, _, _ = indexed(CORRECTOR, 'proof-index.json', '09ab4947385b7f1c7ed59a6f8c474804af9ea3313fd2439415f07de45f8d8681')
    indexed(REVIEW, 'proof-index.json', '42a09c8d8782b717dcf472528415832a19427718086b453f8ce9c9a2be9dfd79')
    assert checked(PARENT, 'candidate/a2_trace.py') == corrected['candidate/a2_trace.py']
    assert sha((PARENT / 'a2_corrector_capture.py').read_bytes()) == sha(corrected['a2_corrector_capture.py'])
    tests = execute_capture('final-tests', 'pytest', ['test_a2_trace.py', 'test_a2_routing.py'])
    assert tests['counts'] == {'tests': 26, 'failures': 0, 'errors': 0, 'skipped': 0, 'passed': 26}
    execute_capture('final-portable', 'script', ['a2_portable_replay.py'])
    qa = PARENT / 'final-qa'
    qa.mkdir()
    commands = [
        ['uv', 'run', '--frozen', 'ruff', 'check', '.'],
        ['uv', 'run', '--frozen', 'python', '-B', '-m', 'pytest', 'tests/unit/test_docs_consistency.py',
         '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(qa / 'temp'), '--junitxml=' + str(qa / 'raw.xml')],
        ['uv', 'run', '--frozen', 'mkdocs', 'build', '--strict', '--site-dir', str(qa / 'site')],
        ['git', 'diff', '--check'],
    ]
    (qa / 'plan.json').write_text(json.dumps(commands, indent=2) + '\n')
    results = []
    for i, command in enumerate(commands):
        result = subprocess.run(command, cwd=ROOT, capture_output=True)
        (qa / f'{i}-stdout.raw').write_bytes(result.stdout)
        (qa / f'{i}-stderr.raw').write_bytes(result.stderr)
        results.append({'command': command, 'actual_exit': result.returncode})
    (qa / 'processes.json').write_text(json.dumps(results, indent=2) + '\n')
    assert all(r['actual_exit'] == 0 for r in results), results
    xml = ET.parse(qa / 'raw.xml')
    assert len(xml.findall('.//testcase')) == 23 and not xml.findall('.//failure') and not xml.findall('.//error')
    delta = {}
    for name in ['docs/developer/phase-a-completion.md', 'docs/developer/bug-resolution-tracker.md']:
        before = (PARENT / 'pre-final-status' / Path(name).name).read_bytes()
        after = (ROOT / name).read_bytes()
        delta[name] = {'before_sha256': sha(before), 'after_sha256': sha(after),
                       'allowed_change': 'Scoped review/archival/progress disposition only; original failures retained'}
    (PARENT / 'final-status-delta.json').write_text(json.dumps(delta, indent=2) + '\n')
    portable = json.loads((PARENT / 'final-portable/before/replay-report.json').read_text())
    assert portable['canonical_positive_trace_equal'] and portable['all_emitted_canonical_artifact_bytes_equal']
    assert verify_pins() == protected
    indexed(CORRECTOR, 'proof-index.json', '09ab4947385b7f1c7ed59a6f8c474804af9ea3313fd2439415f07de45f8d8681')
    indexed(REVIEW, 'proof-index.json', '42a09c8d8782b717dcf472528415832a19427718086b453f8ce9c9a2be9dfd79')
    preservation = json.loads((OUT / 'single-trace-passed-review-preservation.json').read_text())
    assert preservation['single_trace_independent_review_passed'] is True
    assert preservation['parent_readback_and_archive_verified'] is True
    public = OUT / 'single-trace-outcome.json'
    assert not public.exists()
    outcome = {
        'authorization_id': 'a2-single-conditional-trace-2026-11-12',
        'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'SCOPED PASS — one fixed conditional metadata/byte-ledger increment complete',
        'case_id': 'REF-PASS-f64-GL', 'static_witnesses': 1, 'samples': 3,
        'supplied_synthetic_candidates': 2, 'exact_slots': 22,
        'fixed_trace_increment_complete': True, 'single_trace_independent_review_passed': True,
        'closed_fixed_finding': 'FIXED-TRACE-ROUTING-01',
        'corrected_source_sha256': sha(corrected['candidate/a2_trace.py']),
        'review_assessment': 'single-trace-independent-review-passed.json',
        'review_assessment_sha256': preservation['assessment_sha256'],
        'review_evidence_archive': preservation['archive'],
        'final_focused_checks': tests['counts'], 'final_focused_actual_exit': tests['actual_child_exit'],
        'final_documentation_tests': {'passed': 23, 'failed': 0, 'errors': 0, 'actual_exit': 0},
        'ruff_actual_exit': results[0]['actual_exit'], 'strict_docs_actual_exit': results[2]['actual_exit'],
        'whitespace_actual_exit': results[3]['actual_exit'],
        'positive_all_38_body_bytes_unchanged': True, 'canonical_positive_trace': portable['canonical_positive_trace'],
        'finite_ledger': portable['ledger'], 'final_allowed_status_delta': delta,
        'protected_root_union_files_unchanged': protected, 'packet_files_unchanged': 9,
        'numerical_inputs_unchanged': 125, 'history_group_unchanged': 44,
        'head_and_full_index_stage_pins_unchanged': True,
        'hypothetical_process_security_timing_counter_fields_are_observations': False,
        'arithmetic_verified': False, 'total_numerical_certified': False,
        'caps_changed': False, 'broader_accounting_proved': False, 'a2_acceptance_passed': False,
        'phase_a_complete': False, 'coverage_expansion_authorized': False,
        'implementation_authorized': False, 'protocol_freeze_authorized': False,
        'worker_runs': 0, 'remaining_correction_cycles': 0,
        'earlier_failed_attempts_relabelled_success': False,
        'commit_or_push_performed': False, 'new_remote_ci_claim': False,
        'next_boundary': 'No bulk expansion or numerical phase authorized. Broader admission/accounting and owner scope decisions remain open.',
        'capture_qualifications': 'Original author live-source capture and two corrector initial guard transcriptions remain qualified; later copied-snapshot replay is not historical OS attestation.',
    }
    public.write_text(json.dumps(outcome, indent=2) + '\n')
    # Preserve bounded parent completion evidence; sites, temp trees and delivery receipts are not proof inputs.
    proof = {'parent-final-close-source.py': Path(__file__).read_bytes()}
    for name in ['routing-review-manifest.json', 'parent-verification.json', 'parent-preservation-source.py',
                 'a2_corrector_capture.py', 'a2_preserve_passed_review.py', 'final-status-delta.json']:
        proof[name] = checked(PARENT, name)
    for directory in ['pre-final-status', 'parent-tests', 'parent-portable', 'final-tests', 'final-portable', 'final-qa']:
        for path in sorted((PARENT / directory).rglob('*')):
            relative = path.relative_to(PARENT)
            if any(part in ['temp', 'tmp', 'pytest-temp', 'site'] for part in relative.parts) or 'telegram' in path.name:
                continue
            assert not path.is_symlink()
            if path.is_file():
                proof[relative.as_posix()] = path.read_bytes()
    for name in ['docs/developer/phase-a-completion.md', 'docs/developer/bug-resolution-tracker.md']:
        proof['final-status/' + Path(name).name] = (ROOT / name).read_bytes()
    proof['single-trace-outcome.json'] = public.read_bytes()
    parent_archive = archive('single-trace-parent-closure-evidence.tar.gz', proof)
    receipt = {'outcome_sha256': sha(public.read_bytes()), 'parent_archive': parent_archive,
               'scope': 'Parent completion readback; internal artifact integrity, not new source review or scientific acceptance',
               'remote_delivery_performed': False}
    target = OUT / 'single-trace-parent-closure-preservation.json'
    assert not target.exists()
    target.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'status': outcome['status'], 'focused_passed': 26, 'docs_passed': 23,
                      'qa_actual_exits': [r['actual_exit'] for r in results], 'protected_files': protected,
                      'outcome': str(public), 'outcome_sha256': receipt['outcome_sha256'],
                      'parent_archive': parent_archive, 'caps_changed': False, 'a2_acceptance_passed': False,
                      'commit_or_push_performed': False}, indent=2))
