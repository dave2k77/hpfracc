"""Parent readback and preservation of the scoped fixed-trace re-review PASS."""
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from a2_preserve_failed_review import OUT, ROOT, archive, checked, sha, verify_pins
from a2_preserve_routing_correction import indexed

HERE = Path(__file__).resolve().parent
REVIEW = HERE.parent / 'a2-routing-independent-review-Lnvtx4VN'
CORRECTOR = HERE.parent / 'a2-routing-corrector-tcyfzwif'
OLD_REVIEW = HERE.parent / 'a2-independent-fixed-review-kgblph4j'
PARENT = HERE.parent / 'a2-routing-parent-5fnrmmf8'


if __name__ == '__main__':
    protected = verify_pins()
    author, _, _ = indexed(HERE, 'evidence-index.json', 'be5a1ba950860abbf66b849fdc5a057c75b6bafbe064ea21635e26a60633aa07')
    rejected, _, _ = indexed(OLD_REVIEW, 'proof-index.json', 'ea1cf140c393c5426e328833bff087ba52c37b0fcf297fd9ae83dd75ffe3d4d9')
    corrected, _, _ = indexed(CORRECTOR, 'proof-index.json', '09ab4947385b7f1c7ed59a6f8c474804af9ea3313fd2439415f07de45f8d8681')
    files, index_raw, representations = indexed(REVIEW, 'proof-index.json', '42a09c8d8782b717dcf472528415832a19427718086b453f8ce9c9a2be9dfd79')
    assert len(files) == 373 and sum(map(len, files.values())) == 14989426
    final_raw = checked(REVIEW, 'final-pins.json')
    assert sha(final_raw) == 'b3c42a2349afc3b4cfcdcb71119135543c6ff02ab1545bafa27e462de238fc46'
    final = json.loads(final_raw)
    verdict = json.loads(files['assessment.json'])
    assert sha(files['assessment.json']) == '443ef0528876130b3db9146c494a829bc0a2ced28184681dad21938d3b9bd60b'
    assert verdict['passed'] is True and verdict['security_concerns'] == verdict['logic_errors'] == []
    for key in ['implementation_authorized', 'protocol_freeze_authorized', 'a2_acceptance_passed', 'broader_accounting_proved']:
        assert verdict[key] is False and final[key] is False
    assert final['proof_files_verified'] == len(files) and final['proof_bytes_verified'] == sum(map(len, files.values()))
    for name, key in [('assessment.json', 'assessment_json'), ('assessment.md', 'assessment_markdown'),
                      ('proof-index.json', 'proof_index'), ('proof-index-verification.json', 'proof_index_verification')]:
        checked(REVIEW, name, final[key])
    for name, metadata in final['seal_capture_pins'].items():
        checked(REVIEW, 'seal-capture/' + name, metadata)
    binding = final['final_binding_executable']
    checked(REVIEW, str(Path(binding['path']).relative_to(REVIEW)), binding)
    runs = {}
    for phase, expected_exit, expected_cases, expected_failures in [
        ('reproduced-26-green', 0, 26, 0), ('reproduced-26-red', 1, 26, 6),
        ('isolated-26-green', 0, 26, 0), ('prior-23-negatives-corrected', 0, 23, 0),
    ]:
        process = json.loads(files[phase + '/process.json'])
        assert process['actual_child_exit'] == expected_exit
        root = ET.fromstring(files[phase + '/raw.xml'])
        rows = list(root.iter('testcase'))
        failed = [row for row in rows if row.find('failure') is not None]
        assert len(rows) == expected_cases and len(failed) == expected_failures and not list(root.iter('error'))
        if failed:
            assert all('DID NOT RAISE' in row.find('failure').attrib['message'] for row in failed)
        runs[phase] = {'tests': len(rows), 'passed': len(rows) - len(failed), 'failed': len(failed),
                       'errors': 0, 'actual_child_exit': expected_exit}
    for phase, expected in [('independent-resigned-route-proof', 0), ('preserved-minimal-direct', 0),
                            ('independent-positive', 0), ('portable-positive', 0), ('missing-artifact', 1)]:
        process = json.loads(files[phase + '/process.json'])
        assert process['actual_child_exit'] == expected
    supplements = {}
    for path in sorted((REVIEW / 'seal-capture').rglob('*')):
        if 'tmp' in path.relative_to(REVIEW).parts or not path.is_file():
            continue
        name = path.relative_to(REVIEW).as_posix()
        assert not path.is_symlink()
        supplements[name] = checked(REVIEW, name)
    for name in ['seal-capture/process.json', 'seal-capture/final-binding/process.json']:
        assert json.loads(supplements[name])['actual_child_exit'] == 0
    archive_files = files | supplements | {
        'proof-index.json': index_raw,
        'proof-index-verification.json': checked(REVIEW, 'proof-index-verification.json'),
        'final-pins.json': final_raw,
        'parent-archive-representations.json': (json.dumps(representations, indent=2) + '\n').encode(),
        'parent-supplement-scope.json': (json.dumps({
            'scope': 'Post-index final seal/binding source, plans, raw outputs and actual exits preserved separately; not falsely counted as original indexed entries',
            'supplementary_files': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in supplements.items()},
            'excluded': 'UV cache, temporary runtime locks, private Telegram receipts; no source/assessment/proof exclusions'}, indent=2) + '\n').encode(),
    }
    preserved = archive('single-trace-independent-review-passed-evidence.tar.gz', archive_files)
    for name, source in [('single-trace-independent-review-passed.json', 'assessment.json'),
                         ('single-trace-independent-review-passed.md', 'assessment.md')]:
        target = OUT / name
        assert not target.exists()
        target.write_bytes(files[source])
    assert verify_pins() == protected
    indexed(CORRECTOR, 'proof-index.json', '09ab4947385b7f1c7ed59a6f8c474804af9ea3313fd2439415f07de45f8d8681')
    indexed(REVIEW, 'proof-index.json', '42a09c8d8782b717dcf472528415832a19427718086b453f8ce9c9a2be9dfd79')
    result = {
        'scope': 'ONE fixed STATIC/HYPOTHETICAL metadata trace and finite byte ledger; not A2 or scientific acceptance',
        'single_trace_independent_review_passed': True, 'parent_readback_and_archive_verified': True,
        'assessment_sha256': sha(files['assessment.json']), 'proof_index_sha256': sha(index_raw),
        'final_pins_sha256': sha(final_raw), 'reviewer_index_entries_verified': len(files),
        'reviewer_index_bytes_verified': sum(map(len, files.values())),
        'symlinks_archived_as_regular_readlink_data': len(representations),
        'seal_binding_supplement_files': len(supplements), 'archive': preserved,
        'protected_root_union_files': protected, 'original_author_files': len(author),
        'original_rejected_review_files': len(rejected), 'corrector_entries': len(corrected),
        'raw_reproduced_runs': runs, 'positive_bytes_and_ledger_unchanged': True,
        'remaining_correction_cycles': 0, 'caps_changed': False, 'numerical_core_changed': False,
        'implementation_authorized': False, 'protocol_freeze_authorized': False,
        'a2_acceptance_passed': False, 'broader_accounting_proved': False,
        'remote_delivery_performed': False,
    }
    target = OUT / 'single-trace-passed-review-preservation.json'
    assert not target.exists()
    target.write_text(json.dumps(result, indent=2) + '\n')
    before = PARENT / 'pre-final-status'
    before.mkdir()
    for name in ['docs/developer/phase-a-completion.md', 'docs/developer/bug-resolution-tracker.md']:
        (before / Path(name).name).write_bytes((ROOT / name).read_bytes())
    (PARENT / 'a2_preserve_passed_review.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps(result, indent=2))
