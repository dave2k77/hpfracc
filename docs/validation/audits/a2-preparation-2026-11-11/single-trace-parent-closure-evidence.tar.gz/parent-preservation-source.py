"""Verify, replay and preserve the one bounded routing correction for fresh review."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import xml.etree.ElementTree as ET

from a2_preserve_failed_review import OUT, ROOT, archive, checked, sha, verify_pins

HERE = Path(__file__).resolve().parent
CORRECTION = HERE.parent / 'a2-routing-corrector-tcyfzwif'
OLD_REVIEW = HERE.parent / 'a2-independent-fixed-review-kgblph4j'


def indexed(base, index_name, expected_sha):
    raw_index = checked(base, index_name)
    assert sha(raw_index) == expected_sha
    index = json.loads(raw_index)
    result = {}
    representations = {}
    for name, metadata in index['files'].items():
        kind = metadata.get('kind', 'regular_file')
        if kind == 'regular_file':
            raw = checked(base, name, metadata)
        else:
            assert kind == 'symlink_readlink_utf8'
            path = base / name
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            assert path.is_symlink() and path.parent.resolve().is_relative_to(base.resolve())
            raw = os.readlink(path).encode('utf-8')
            assert len(raw) == metadata['bytes'] and sha(raw) == metadata['sha256']
            representations[name] = {'original_kind': kind, 'archived_kind': 'regular UTF-8 readlink data; not a recreated link'}
        result[name] = raw
    return result, raw_index, representations


def counts(base, phase, exit_value, failures):
    process = json.loads(checked(base, phase + '/process.json'))
    assert process['actual_child_exit'] == exit_value
    tree = ET.fromstring(checked(base, phase + '/raw.xml'))
    rows = list(tree.iter('testcase'))
    failed = [r for r in rows if r.find('failure') is not None]
    assert len(rows) == 26 and len(failed) == failures and not list(tree.iter('error'))
    if failures:
        assert all('DID NOT RAISE' in r.find('failure').attrib['message'] for r in failed)
    return {'tests': len(rows), 'passed': len(rows) - len(failed), 'failed': len(failed),
            'errors': 0, 'actual_child_exit': exit_value}


if __name__ == '__main__':
    root_count = verify_pins()
    old_author, _, _ = indexed(HERE, 'evidence-index.json', 'be5a1ba950860abbf66b849fdc5a057c75b6bafbe064ea21635e26a60633aa07')
    old_review, _, _ = indexed(OLD_REVIEW, 'proof-index.json', 'ea1cf140c393c5426e328833bff087ba52c37b0fcf297fd9ae83dd75ffe3d4d9')
    files, index_raw, representations = indexed(CORRECTION, 'proof-index.json', '09ab4947385b7f1c7ed59a6f8c474804af9ea3313fd2439415f07de45f8d8681')
    assert len(files) == 235 and sum(map(len, files.values())) == 6356655
    report = json.loads(files['correction-report.json'])
    assert report['correction_cycle'] == report['maximum_correction_cycles'] == 1
    assert report['independent_review_passed'] is False
    for name, meta in report['protected_extra_pins'].items():
        path = Path(name)
        assert any(path.resolve().is_relative_to(base.resolve()) for base in [HERE, OLD_REVIEW, OUT])
        assert len(path.read_bytes()) == meta['bytes'] and sha(path.read_bytes()) == meta['sha256']
    original = old_author['a2_trace.py']
    fixed = files['candidate/a2_trace.py']
    before = b"        binding = records['records/binding-host-' + suffix + '.json']\n"
    guard = b"        need(binding['binding_id'] == 'host-' + suffix, 'binding path-to-ID')\n"
    assert original.count(before) == 1 and fixed == original.replace(before, before + guard)
    assert sha(fixed) == '4b28a7dfc4587dd6d6bfb63cdb5ea5362b0f5cf5ab3c1c9d31fe211465dfbd4e'
    for name in ['test_a2_trace.py', 'authority.json', 'record-schemas.json', 'protocol.json', 'trace.json']:
        assert files['candidate/' + name] == old_author[name], name
    original_runs = {phase: counts(CORRECTION, phase, exit_value, failures)
                     for phase, exit_value, failures in [('red-routing', 1, 6), ('green-routing', 0, 0), ('isolated-tests', 0, 0)]}
    parent = Path(tempfile.mkdtemp(prefix='a2-routing-parent-', dir=HERE.parent))
    (parent / 'a2_corrector_capture.py').write_bytes(files['a2_corrector_capture.py'])
    candidate = parent / 'candidate'
    candidate.mkdir()
    for name, raw in files.items():
        if name.startswith('candidate/') and '/' not in name[len('candidate/'):]:
            (candidate / Path(name).name).write_bytes(raw)
    commands = []
    for phase, mode, arguments, expected in [
        ('parent-tests', 'pytest', ['test_a2_trace.py', 'test_a2_routing.py'], 0),
        ('parent-portable', 'script', ['a2_portable_replay.py'], 0),
    ]:
        cmd = ['uv', 'run', '--project', str(ROOT), '--frozen', '--no-sync', 'python', '-B',
               str(parent / 'a2_corrector_capture.py'), phase, str(candidate), mode, *arguments]
        result = subprocess.run(cmd, cwd=ROOT, capture_output=True)
        (parent / (phase + '-capture-stdout.raw')).write_bytes(result.stdout)
        (parent / (phase + '-capture-stderr.raw')).write_bytes(result.stderr)
        process = json.loads((parent / phase / 'process.json').read_text())
        assert result.returncode == 0 and process['actual_child_exit'] == expected
        commands.append({'command': cmd, 'capture_exit': result.returncode, 'child_exit': process['actual_child_exit']})
    parent_counts = counts(parent, 'parent-tests', 0, 0)
    positive = json.loads((parent / 'parent-portable/before/replay-report.json').read_text())
    assert positive['canonical_positive_trace_equal'] and positive['all_emitted_canonical_artifact_bytes_equal']
    for key in ['independent_review_passed', 'a2_acceptance_passed', 'implementation_authorized', 'protocol_freeze_authorized', 'broader_accounting_proved']:
        assert positive[key] is False
    preserved = archive('single-trace-routing-correction-evidence.tar.gz', files | {
        'proof-index.json': index_raw,
        'proof-index-verification.json': checked(CORRECTION, 'proof-index-verification.json'),
        'archive-representations.json': (json.dumps(representations, indent=2) + '\n').encode(),
    })
    assert verify_pins() == root_count
    indexed(HERE, 'evidence-index.json', 'be5a1ba950860abbf66b849fdc5a057c75b6bafbe064ea21635e26a60633aa07')
    indexed(OLD_REVIEW, 'proof-index.json', 'ea1cf140c393c5426e328833bff087ba52c37b0fcf297fd9ae83dd75ffe3d4d9')
    indexed(CORRECTION, 'proof-index.json', '09ab4947385b7f1c7ed59a6f8c474804af9ea3313fd2439415f07de45f8d8681')
    summary = {'status': 'ONE routing correction self-verified and preserved; fresh independent review required',
               'protected_repo_union_files': root_count, 'old_author_files': len(old_author), 'old_review_files': len(old_review),
               'corrector_indexed_files': len(files), 'corrector_indexed_bytes': sum(map(len, files.values())),
               'symlinks_archived_as_readlink_data': len(representations),
               'corrector_original_runs': original_runs, 'parent_replay_counts': parent_counts,
               'parent_replay_directory': str(parent), 'parent_replay_commands': commands,
               'source_delta_verified': 'Exactly one guard line; original tests/data byte-identical',
               'canonical_positive_trace': positive['canonical_positive_trace'], 'ledger': positive['ledger'],
               'archive': preserved, 'corrected_source_sha256': sha(fixed),
               'corrector_index_sha256': sha(index_raw), 'independent_review_passed': False,
               'a2_acceptance_passed': False, 'implementation_authorized': False,
               'protocol_freeze_authorized': False, 'broader_accounting_proved': False,
               'caps_changed': False, 'maximum_correction_cycles': 1}
    for name, raw in [('single-trace-routing-correction-report.json', files['correction-report.json']),
                      ('single-trace-routing-correction-preservation.json', (json.dumps(summary, indent=2) + '\n').encode())]:
        target = OUT / name
        assert not target.exists()
        target.write_bytes(raw)
    (parent / 'parent-preservation-source.py').write_bytes(Path(__file__).read_bytes())
    (parent / 'parent-verification.json').write_text(json.dumps(summary, indent=2) + '\n')
    manifest = json.loads((HERE / 'review-manifest.json').read_text())
    manifest |= {'correction_directory': str(CORRECTION), 'correction_files': json.loads(index_raw)['files'],
                 'correction_index_sha256': sha(index_raw), 'correction_source_sha256': sha(fixed),
                 'correction_report_sha256': sha(files['correction-report.json']),
                 'correction_archive': preserved, 'correction_cycle': 1, 'maximum_correction_cycles': 1,
                 'remaining_correction_cycles': 0, 'parent_replay_directory': str(parent),
                 'prior_rejected_assessment_sha256': '2c52c108aa98c89cdb882e4194c75898fc4d3f7f4bd474dc5cc1a7b04fc4055a',
                 'fresh_review_scope': 'Same ONE static trace and missing routing equality; no further repair. Fail then stop/ask owner.'}
    frozen = parent / 'routing-review-manifest.json'
    frozen.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'parent_directory': str(parent), 'parent_counts': parent_counts,
                      'source_one_guard_only': True, 'positive_unchanged': True,
                      'archive': preserved, 'frozen_manifest_sha256': sha(frozen.read_bytes())}, indent=2))
