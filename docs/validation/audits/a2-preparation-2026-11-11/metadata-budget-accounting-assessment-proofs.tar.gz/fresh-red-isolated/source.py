"""Fresh stdlib reproduction of the frozen eight necessary byte conditions.
The deliberately undercounted skeletons are NOT valid exports or future arrays.
"""
from pathlib import Path
import hashlib,json,sys,unittest
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');S=Path('/home/davianc/.hermes/cache/scratch');O=Path(__file__).parent
A=R/'docs/validation/audits/a2-preparation-2026-11-11'
f=json.loads((A/'fixtures.json').read_text());p=json.loads((A/'protocol.json').read_text())
prior=json.loads((S/'a2-independent-final-complete-l_bwads9/supplemental-run3/supplemental-proof.json').read_text())['resource_branch_independent_lower_bounds']
def enc(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def lower_for(case):
 refs=case['request']['candidate_refs'];cands=[f['candidates'][r] for r in refs]
 shape=f['arrays'][case['request']['input_ref']]['shape'];n=shape[0];cid=case['case_id']
 assert not case['mutations'] and case['resource_control'] is None
 def candidate_id(i):return None if i is None else cands[i]['stable_id']
 def expected(z):
  q=z['quantity']
  if q in ['input','v','D','D_hat','error','B','analytic_input_gradient','output','full_output','input_AD','direction']:return shape[:]
  if q in ['w','g','g_hat','residual','signed_fitted_weights']:return [n]
  if q=='L_hat':return [n,n]
  if q in ['rhos','coefficients','zero_pattern']:return [cands[z['candidate_index']]['configuration']['pole_count']]
  return []
 slots=[dict(slot_id=z['slot_id'],candidate_id=candidate_id(z['candidate_index']),candidate_index=z['candidate_index'],mode=z['mode'],branch=z['branch'],quantity=z['quantity'],status='unknown',reason='none',reasons=['none'],expected_shape=expected(z),completed_shape=[],artifact=None) for z in case['required_evidence_slots']]
 comparisons=[dict(record_type='comparison',comparison_id=z['comparison_id'],case_id=cid,candidate_id=candidate_id(z['candidate_index']),candidate_index=z['candidate_index'],policy_id=z['policy_id'],a_slot_id=z['a_slot_id'],reference_slot_id=z['reference_slot_id'],status='pass',reasons=['none']) for z in case['required_working_comparisons']]
 checks=[dict(record_type='binding_check',case_id=cid,candidate_id=candidate_id(z['candidate_index']),candidate_index=z['candidate_index'],mode=z['mode'],branch=z['branch'],reference_branch=z['reference_branch'],observation_id=None,reference_observation_id=None,comparison=z['comparison'],status='pass',reasons=['none'],check_id=z['check_id']) for z in case['required_fit_identity_checks']]
 # Short hash stand-in has the same fixed width; its value is not evidence.
 obj=dict(record_type='failure_index',request_id=cid,input_bundle_sha256='0'*64,candidate_ids=[c['stable_id'] for c in cands],candidate_occurrences=[dict(candidate_index=i,candidate_id=c['stable_id']) for i,c in enumerate(cands)],slots=slots,status='complete',reasons=['none'],process={},comparisons=comparisons,binding_checks=checks,bytes_accounting=dict(live_bytes=0,cumulative_written_bytes=0,reserved_final_transaction_bytes=0))
 return 2*len(enc(obj))
rows=[]
for old in prior:
 case=next(c for c in f['cases'] if c['case_id']==old['case_id']); lower=lower_for(case)
 assert lower==old['two_index_serialization_lower_bound'],(case['case_id'],lower,old)
 rows.append({'case_id':case['case_id'],'two_index_serialization_lower_bound':lower,'reservation':p['caps']['failure_index_bytes'],'condition_passed':lower<=p['caps']['failure_index_bytes'],'not_a_valid_export_or_measured_run':True})
assert len(rows)==8 and not any(r['condition_passed'] for r in rows)
class NecessaryByteAdmission(unittest.TestCase):pass
for row in rows:
 def check(self,row=row):self.assertLessEqual(row['two_index_serialization_lower_bound'],row['reservation'],row['case_id']+': deliberately undercounted two-index pair exceeds unchanged reservation; NOT a numerical failure')
 setattr(NecessaryByteAdmission,'test_'+row['case_id'].replace('-','_'),check)
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(NecessaryByteAdmission))
report={'label':'Fresh stdlib equivalent of the frozen necessary conditions; not a new pytest run, complete admission or numerical execution','tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'exit':0 if result.wasSuccessful() else 1,'rows':rows}
(O/'fresh-red-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
sys.exit(report['exit'])
