"""Hash exact baseline and old proof bytes read-only, before or after review."""
from pathlib import Path
import hashlib, json, os, subprocess, sys
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
S=Path('/home/davianc/.hermes/cache/scratch'); O=Path(__file__).parent
BPATH=S/'a2-budget-revision-approved-20261112/baseline.json'
B=json.loads(BPATH.read_text()); label=sys.argv[1]
def desc(b): return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def run(*args): return subprocess.check_output(args,cwd=R)
x={'groups':{},'baseline':desc(BPATH.read_bytes()),'label':label}
for group in ['packet_before','protected_files','numerical_inputs']:
 rows={}
 for rel,want in B[group].items():
  got=desc((R/rel).read_bytes()); wanted={'sha256':want} if isinstance(want,str) else want
  assert all(got[k]==v for k,v in wanted.items()),(group,rel,got,wanted)
  rows[rel]=got
 x['groups'][group]=rows
assert [len(x['groups'][g]) for g in ['packet_before','protected_files','numerical_inputs']]==[9,18,125]
x['HEAD']=run('git','rev-parse','HEAD').decode().strip();assert x['HEAD']==B['repo_head']
indexpath=Path(run('git','rev-parse','--git-path','index').decode().strip());indexpath=indexpath if indexpath.is_absolute() else R/indexpath
x['git_index']=desc(indexpath.read_bytes());assert x['git_index']['sha256']==B['git_index_sha256']
x['full_index_stage_entries']=desc(run('git','ls-files','--stage'));assert x['full_index_stage_entries']['sha256']==B['index_entries_sha256']
x['status_no_untracked']=run('git','status','--porcelain=v1','-uno').decode()
x['parent_status_paths']={p:desc((R/p).read_bytes()) for p in B['parent_status_paths']}
# Final source references are pinned in full; no archived script is executed.
p=S/'a2-budget-revision-20261112'
x['old_proof_files']={str(q.relative_to(p)):desc(q.read_bytes()) for q in sorted(p.rglob('*')) if q.is_file()}
home=Path.home()/'.hermes'
x['profile_skill_files']={}
for sub in ['skills','plugins','cron','memories']:
 base=home/sub
 if base.exists():
  for q in sorted(base.rglob('*')):
   if q.is_file() and not q.is_symlink(): x['profile_skill_files'][str(q.relative_to(home))]=desc(q.read_bytes())
for sub in ['config.yaml','SOUL.md']:
 q=home/sub
 if q.is_file():x['profile_skill_files'][sub]=desc(q.read_bytes())
# The before/ copies really are the nine raw baseline packet files.
before=S/'a2-budget-revision-approved-20261112/before'
raws={str(q.relative_to(before)):desc(q.read_bytes()) for q in sorted(before.rglob('*')) if q.is_file()}
assert len(raws)==9,(len(raws),raws.keys())
x['raw_before_packet_copies']=raws
for rel,want in B['packet_before'].items():
 assert want in raws.values(),rel
x['caps']={k:json.loads((R/'docs/validation/audits/a2-preparation-2026-11-11/protocol.json').read_text())['caps'][k] for k in ['failure_index_bytes','json_nodes','evidence_bytes']}
assert x['caps']['failure_index_bytes']==524288 and x['caps']['json_nodes']==32768
if label=='after':
 old=json.loads((O/'pins-before.json').read_text())
 x['equal_to_before']={k:x[k]==old[k] for k in x if k not in ['label']}
 assert all(x['equal_to_before'].values()),[k for k,v in x['equal_to_before'].items() if not v]
x['all_passed']=True
(O/f'pins-{label}.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({'all_passed':True,'label':label,'group_counts':{k:len(v) for k,v in x['groups'].items()},'HEAD':x['HEAD'],'git_index':x['git_index'],'full_index_stage_entries':x['full_index_stage_entries'],'old_proof_count':len(x['old_proof_files']),'profile_skill_file_count':len(x['profile_skill_files']),'caps':x['caps'],'before_after_equal':x.get('equal_to_before')},indent=2))
