"""Finalize only this NEW scratch proof set; no repository or old proof writes."""
from pathlib import Path
import json,hashlib,subprocess
O=Path(__file__).parent;R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
def desc(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(p.read_text())
b=load(O/'pins-before.json');a=load(O/'pins-after.json');v=load(O/'adjudication.json')
assert v['accounting_failure_confirmed'] is True and v['budget_revision_justified'] is v['new_budget_applied'] is v['implementation_authorized'] is v['a2_acceptance_passed'] is False
for group,files in b['groups'].items():
 for p,w in files.items():assert desc((R/p).read_bytes())==w,(group,p)
assert desc((R/'.git/index').read_bytes())==b['git_index']
assert desc(subprocess.check_output(['git','ls-files','--stage'],cwd=R))==b['full_index_stage_entries']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==b['HEAD']
for p,w in b['parent_status_paths'].items():assert desc((R/p).read_bytes())==w
home=Path.home()/'.hermes'
telemetry={'cron/ticker_heartbeat','cron/ticker_last_success'}
assert set(a['profile_differences'])==telemetry
unchanged_profile={k:w for k,w in b['profile_skill_files'].items() if k not in telemetry}
assert len(unchanged_profile)==395
for k,w in unchanged_profile.items():assert desc((home/k).read_bytes())==w,k
D=Path('/home/davianc/.hermes/cache/scratch/a2-budget-revision-20261112')
for k,w in b['old_proof_files'].items():assert desc((D/k).read_bytes())==w,k
md=(R/'docs/developer/a2-compression-budget-protocol.md').read_bytes();head=b'## 4. Exact finite mathematical contract\n';math=head+md.split(head,1)[1].split(b'## 5.',1)[0]
assert desc(math)=={'bytes':1699,'sha256':'c6b59cae6d948222fdb9c5c0a6287491426864964207f45b747501b1970e1f9e'}
assert load(O/'fresh-red-proof.json')['failures']==8 and load(O/'fresh-red-isolated/process.json')['exit']==1
assert load(O/'linkage-run/process.json')['exit']==1 and load(O/'models-run/process.json')['exit']==0
# Never convert either earlier harness/strict-profile failure into a passing process.
assert load(O/'fresh-red/process.json')['exit']==1 and load(O/'final-pin/process.json')['exit']==1
scope={'repository_packet_protected_numerical_index_HEAD_old_proofs_unchanged':True,'parent_status_docs_unchanged':True,'profile_configuration_skills_and_nontelemetry_files_unchanged':len(unchanged_profile),'whole_profile_byte_equality':False,'changed_runtime_telemetry':sorted(telemetry),'mathematics':desc(math),'all_8_necessary_cases_still_RED':True,'new_caps_applied':False,'source_scope':'Only new scratch files written; dynamic profile ticks are not normalized or restored'}
(O/'final-scope-proof.json').write_text(json.dumps(scope,indent=2)+'\n')
# Current finalizer's output/receipt necessarily arrives later; explicitly outside this index.
exclude_files={'evidence-index.json','evidence-index-verification.json'}
exclude_dirs={'finalize-run'}
files={str(p.relative_to(O)):desc(p.read_bytes()) for p in sorted(O.rglob('*')) if p.is_file() and p.name not in exclude_files and p.relative_to(O).parts[0] not in exclude_dirs}
index={'label':'Independent BLOCKED-result adjudication; actual stdlib proof and failed harness processes retained, no numerical acceptance','files':files,'exclusions':{'files':sorted(exclude_files),'directories':sorted(exclude_dirs),'reason':'No recursive self-hashes. Finalizer stdout/stderr/process and index verification are bound through the actual finalizer command receipt instead.'}}
(O/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
readback=load(O/'evidence-index.json');assert readback==index
for p,w in readback['files'].items():assert desc((O/p).read_bytes())==w,p
verification={'verified':True,'verified_files':len(files),'index':desc((O/'evidence-index.json').read_bytes()),'adjudication':desc((O/'adjudication.json').read_bytes()),'final_scope':scope,'actual_exits':{p:load(O/p)['exit'] for p in ['initial-pin/process.json','inspect-run/process.json','slim-run/process.json','fresh-red/process.json','fresh-red-isolated/process.json','models-run/process.json','linkage-run/process.json','final-pin/process.json','final-pin-diagnostic/process.json']}}
(O/'evidence-index-verification.json').write_text(json.dumps(verification,indent=2)+'\n');print(json.dumps(verification,indent=2))
