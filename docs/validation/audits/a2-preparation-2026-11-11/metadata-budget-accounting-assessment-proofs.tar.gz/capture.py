"""Capture only new read-only stdlib audit processes, preserving source bytes."""
from pathlib import Path
import json, hashlib, os, subprocess, sys, time
O=Path(__file__).parent
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
label=sys.argv[1]; target=O/sys.argv[2]
d=O/label; d.mkdir(exist_ok=False)
raw=target.read_bytes(); (d/'source.py').write_bytes(raw)
cmd=[sys.executable,'-I','-B',str(target),*sys.argv[3:]]
env=os.environ.copy(); env['PYTHONDONTWRITEBYTECODE']='1'
t=time.monotonic_ns(); p=subprocess.run(cmd,cwd=R,env=env,capture_output=True); elapsed=time.monotonic_ns()-t
for n,b in [('stdout.bin',p.stdout),('stderr.bin',p.stderr)]: (d/n).write_bytes(b)
record={'label':'Actual independent read-only stdlib audit process, not numerical execution','command':cmd,'cwd':str(R),'exit':p.returncode,'elapsed_ns':elapsed,'source_before':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'source_after_equal':raw==target.read_bytes(),'streams':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in [('stdout.bin',p.stdout),('stderr.bin',p.stderr)]}}
(d/'process.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2)); print(p.stdout.decode(errors='replace')); print(p.stderr.decode(errors='replace'))
# Return real child exit, even when the expected outcome is RED.
sys.exit(p.returncode)
