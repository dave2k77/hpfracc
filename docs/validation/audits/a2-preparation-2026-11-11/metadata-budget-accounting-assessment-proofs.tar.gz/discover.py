"""Read-only discovery; only new scratch output, no repository writes."""
from pathlib import Path
import hashlib, json, subprocess
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
S=Path('/home/davianc/.hermes/cache/scratch')
O=Path(__file__).parent
B=json.loads((S/'a2-budget-revision-approved-20261112/baseline.json').read_text())
print('BASELINE_KEYS',[(k,len(v) if hasattr(v,'__len__') else v,type(v).__name__) for k,v in B.items()])
P=S/'a2-budget-revision-20261112'
for f in ['evidence-index.json','initial-guards.json','final-guards.json','pre-edit-gate-failed.json','accounted-before/summary.json','budget-choice-before-edit.json','own-red/process.json']:
 x=json.loads((P/f).read_text())
 print('\nFILE',f)
 print(json.dumps(x,indent=2)[:3500 if f=='evidence-index.json' else 9000])
for args in [['git','rev-parse','HEAD'],['git','status','--porcelain=v1','-uno']]:
 p=subprocess.run(args,cwd=R,capture_output=True)
 print(args,p.returncode,p.stdout.decode(),p.stderr.decode())
(O/'discovery.json').write_text(json.dumps({'baseline_keys':list(B),'root':str(R),'source':str(P)},indent=2)+'\n')
