"""Bounded independent inspection of accounting projections; no exports generated."""
from pathlib import Path
from collections import Counter
import ast,json,hashlib,math,sys,xml.etree.ElementTree as ET
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');A=R/'docs/validation/audits/a2-preparation-2026-11-11';D=Path('/home/davianc/.hermes/cache/scratch/a2-budget-revision-20261112');O=Path(__file__).parent
load=lambda p:json.loads(p.read_text())
enc=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
h=lambda b:hashlib.sha256(b).hexdigest()
def nodes(x):
 if isinstance(x,dict):return 1+sum(1+nodes(v) for v in x.values())
 if isinstance(x,list):return 1+sum(nodes(v) for v in x)
 return 1
F=load(A/'fixtures.json');P=load(A/'protocol.json');S=load(A/'record-schemas.json');W=load(A/'schema-control-fixtures.json')
rows=load(D/'accounted-before/profiles.json');summary=load(D/'accounted-before/summary.json');choice=load(D/'budget-choice-before-edit.json')
assert len(rows)==512 and len({z['case_id'] for z in rows})==32
positive=[z for z in rows if z['derivatives_active']];assert len(positive)==48 and len({z['case_id'] for z in positive})==16
for cid in {z['case_id'] for z in rows}:
 rs=[z for z in rows if z['case_id']==cid];assert len(rs)==16 and len({tuple(z['winners']) for z in rs})==16
assert max(z['transaction_bytes'] for z in rows)==summary['max_transaction_bytes']==812905
assert max(v for z in rows for v in z['record_nodes'].values())==32714
assert max(z['symbolic_node_accounting']['result_nodes'] for z in rows)==51560
r=load(D/'accounted-before/sample-STATIC-METADATA-PROJECTION.json')['records'];ix=r['failure-index.json'];ib=r['input-bundle.json'];case=next(c for c in F['cases'] if c['case_id']==ib['request']['case_id'])
assert len(r)==7
assert [(z['slot_id'],z['candidate_index'],z['mode'],z['branch'],z['quantity']) for z in ix['slots']]==[(z['slot_id'],z['candidate_index'],z['mode'],z['branch'],z['quantity']) for z in case['required_evidence_slots']]
assert len(ix['comparisons'])==len(case['required_working_comparisons'])==89
assert len(ix['binding_checks'])==len(case['required_fit_identity_checks'])==84
assert ix['input_bundle_sha256']==h(enc(ib))
assert ix['process']==r['records/process.json']
assert ix['process']['launch_receipt_sha256']==h(enc(r['records/launch.json']))
ex=r['records/export.json'];assert ex['failure_index_sha256']==h(enc(ix)) and ex['failure_index_bytes']==len(enc(ix)) and ex['process_sha256']==h(enc(ix['process']))
missing=[z['artifact']['path'] for z in ix['slots'] if z['artifact'] is not None and z['artifact']['path'] not in r]
assert len(missing)==len(set(missing))==372
assert Counter(z['status'] for z in ix['slots'])=={'complete':372,'not_applicable':582}
# Snapshot reproduces the model literally; absent required artifacts cannot be silently zero-charged.
snapshot=sum(len(enc(v)) for k,v in r.items() if k not in ['failure-index.json','records/export.json'])
assert snapshot==ix['bytes_accounting']['live_bytes']==ix['bytes_accounting']['cumulative_written_bytes']==604371
assert ix['bytes_accounting']['reserved_final_transaction_bytes']==0
sample_row=next(z for z in rows if z['case_id']==case['case_id'] and z['winners']==[0,0])
transaction=sum(len(enc(v)) for k,v in r.items() if k!='input-bundle.json')
assert transaction==sample_row['transaction_bytes']
conditional=sum(z['artifact']['bytes'] for z in ix['slots'] if z['artifact'])
assert conditional==sample_row['conditional_array_allocation']
assert not any(k.startswith(('arrays/','records/observation-','records/binding-')) for k in r)
assert 'result.json' not in r and 'run-manifest.json' not in r
# Independent counting check on existing static witnesses, not fabricated real payloads.
count=0
for b in W['bundles']:
 for sl in b['artifacts'].values():
  if sl.get('record_type')!='slot':continue
  payload=sl['raw_array'] or sl['exact_array']
  if payload is None:continue
  formula=15+len(payload['shape']) if 'raw_hex' in payload else 5+len(payload['shape'])+5*math.prod(payload['shape'])
  assert nodes(payload)==formula;count+=1
assert count==85
# Recount the representative result cardinality with opaque payload subtrees.
# No complete slot objects or arrays are constructed or serialized.
slot_nodes=0
for z in ix['slots']:
 n=1+2*14+len(z['reasons']) # fourteen keys/values; reasons list adds its elements
 if z['status']=='complete':
  exact=z['mode'] in ['shared','synthetic'] or z['quantity'] in F['real_worker_inventory']['per_base_candidate_exact_slots'] or z['quantity']=='zero_pattern'
  payload=(5+len(z['expected_shape'])+5*math.prod(z['expected_shape'])) if exact else 15+len(z['expected_shape'])
  n+=payload-1
 slot_nodes+=n
base=next(b for b in W['bundles'] if b['kind']=='full')['artifacts']['result.json']
# Exclude original assessment/shared slot subtrees, then count the changed empty metadata only.
base_nodes=nodes(base)-nodes(base['shared_slots'])-nodes(base['assessments'])+1
assessments=[dict(candidate_id=c['stable_id'],candidate_index=i,status='unknown',reasons=['incomplete_evidence'],qualifies=None,slots=[]) for i,c in enumerate(ib['request']['candidates'])]
result_nodes=base_nodes+nodes(assessments)+slot_nodes
assert result_nodes==sample_row['symbolic_node_accounting']['result_nodes']==51560
future=[v for v in F['candidates'].values() if 'producer_call' in v]
assert len(future)==12 and all(v['rhos_ref'] is None and v['coefficients_ref'] is None for v in future)
assert all(c['rhos'] is None and c['coefficients'] is None for c in ib['request']['candidates'])
assert len(W['future_full_bindings'])==64
assert all(z['observation']['status']=='not_evaluated' and z['observation']['producer_binding_sha256'] is None and z['observation']['producer'] is None for z in W['future_full_bindings'])
red=ET.fromstring((D/'own-red.xml').read_bytes());tests=red.findall('.//testcase')
assert len(tests)==8 and all(t.find('failure') is not None for t in tests)
processes={}
for path in sorted(D.glob('*/process.json')):
 x=load(path)
 for n,w in x['streams'].items():
  b=(path.parent/n).read_bytes();assert len(b)==w['bytes'] and h(b)==w['sha256']
 processes[str(path.relative_to(D))]={'command':x['command'],'exit':x['exit']}
assert processes['own-red/process.json']['exit']==1 and processes['pre-edit-gate-failure/process.json']['exit']==1
assert not any('green' in q.name.lower() for q in D.rglob('*') if q.is_file())
counts={'cases':len(F['cases']),'raws':len(F['arrays']),'slots':sum(len(c['required_evidence_slots']) for c in F['cases']),'comparisons':sum(len(c.get('required_working_comparisons',[])) for c in F['cases']),'fit_checks':sum(len(c.get('required_fit_identity_checks',[])) for c in F['cases']),'full_bindings':sum(len(c.get('required_full_observations',[])) for c in F['cases'])}
assert counts=={'cases':560,'raws':840,'slots':24336,'comparisons':1312,'fit_checks':1056,'full_bindings':64}
proof={'label':'Independent verification of BLOCKED accounting, not an admission GREEN','counts':counts,'profile_count':len(rows),'positive_agreement_profiles':len(positive),'profile_case_count':32,'missing_conditional_artifact_obligations':missing,'sample_metadata_record_keys':list(r),'sample_slot_dispositions':dict(Counter(z['status']+':'+z['reason'] for z in ix['slots'])),'sample_known_rendered_snapshot':snapshot,'sample_reserved_final_transaction_bytes':0,'sample_metadata_only_index_transaction':transaction,'sample_conditional_slot_bytes_not_in_snapshot':conditional,'sample_symbolic_result_nodes':result_nodes,'existing_static_payload_cardinalities_verified':count,'max_rendered_metadata_transaction':max(z['transaction_bytes'] for z in rows),'max_rendered_record_nodes':32714,'caps':{k:P['caps'][k] for k in ['failure_index_bytes','json_nodes','evidence_bytes']},'future_fit_specs_still_null':len(future),'future_full_observations_still_unobserved':64,'missing_required_record_classes':['conditional slot payload wrappers','result including inline slot copies','observations including inline slots','producer bindings and their descriptors','full run manifest','actual log bytes corresponding to process digests'],'routing_is_allowlist_not_requirement_to_emit_every_route':True,'binding_recipe':S['x-binding-digest-recipe'],'routing':S['x-artifact-routing'],'record_required_fields':{k:S['$defs'][k]['required'] for k in ['slot','observation','producer_binding','failure_index','supervisor_export','run_manifest']},'hypothetical_ids_do_not_authenticate_execution':True,'historical_red_tests':8,'historical_red_failures':8,'historical_processes':processes,'all_inspection_assertions_passed':True,'no_jax_or_hpfracc_imported':not any(k.split('.')[0] in ['jax','hpfracc'] for k in sys.modules)}
(O/'models-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:proof[k] for k in ['label','counts','profile_count','positive_agreement_profiles','sample_known_rendered_snapshot','sample_metadata_only_index_transaction','sample_conditional_slot_bytes_not_in_snapshot','sample_symbolic_result_nodes','max_rendered_metadata_transaction','max_rendered_record_nodes','caps','future_fit_specs_still_null','no_jax_or_hpfracc_imported','all_inspection_assertions_passed']},indent=2));print('missing_conditional_artifacts',len(missing))
