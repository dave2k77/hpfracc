"""Inspect and reduce frozen JSON only; never execute historical generators."""
from pathlib import Path
from collections import Counter
import json,hashlib,tarfile,xml.etree.ElementTree as ET
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');S=Path('/home/davianc/.hermes/cache/scratch');O=Path(__file__).parent
A=R/'docs/validation/audits/a2-preparation-2026-11-11';D=S/'a2-budget-revision-20261112'
def load(p):return json.loads(p.read_text())
def d(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
idx=load(D/'evidence-index.json'); assert len(idx['files'])==64
checked={}
for rel,w in idx['files'].items():
 g=d((D/rel).read_bytes());assert g==w,(rel,g,w);checked[rel]=g
ar=D/'blocked-attempt-evidence.tar.gz'
assert d(idx_raw:=(D/'evidence-index.json').read_bytes())['sha256']=='5d458f1ad57a6d7380890e3d982354242e95beca94bb10cf2989dd5083aca903'
assert d(ar.read_bytes())['sha256']=='453a6dba8e71bae266efe44b7365c7fe7f2a9019d47d0cefde220e1177ea87a7'
with tarfile.open(ar,'r:gz') as t:
 members=t.getmembers();assert len(members)==65
 assert len({m.name for m in members})==65
 assert {m.name for m in members}==set(checked)|{'evidence-index.json'}
 for m in members:
  assert m.isfile() and not m.issym() and not m.islnk()
  b=t.extractfile(m).read();assert b==(D/m.name).read_bytes(),m.name
assert ar.read_bytes()==(A/'metadata-budget-accounting-blocked-evidence.tar.gz').read_bytes()
x={'archive':d(ar.read_bytes()),'index':d(idx_raw),'indexed_files_checked':len(checked),'archive_members_checked':len(members),'archive_repo_copy_equal':True,'files':checked}
(O/'archive-proof.json').write_text(json.dumps(x,indent=2)+'\n')
print('ARCHIVE',json.dumps({k:v for k,v in x.items() if k!='files'}))
P=load(A/'protocol.json');F=load(A/'fixtures.json');SC=load(A/'record-schemas.json');W=load(A/'schema-control-fixtures.json')
print('PROTOCOL_KEYS',list(P));print('SCHEMA_KEYS',list(SC));print('FIXTURE_KEYS',list(F));print('WITNESS_KEYS',list(W))
for name in ['$defs','x-artifact-routing','x-disposition-table']:
 print(name, list(SC[name]) if name=='$defs' else json.dumps(SC[name],indent=2))
for name in ['failure_index','result','producer_binding','observation','run_manifest','slot','supervisor_export']:
 if name in SC['$defs']:
  v=SC['$defs'][name]; print('DEFINITION',name,json.dumps(v,indent=2)[:6500])
proj=load(D/'accounted-before/sample-STATIC-METADATA-PROJECTION.json')['records']
print('PROJECTION_RECORD_KEYS',list(proj))
for k in ['failure-index.json','initial_failure_index','input-bundle.json']:
 print('PROJECTION',k,'keys',list(proj[k]))
print('BYTES_ACCOUNTING',proj['failure-index.json']['bytes_accounting'])
print('FULL_SAMPLE_BUNDLE_ROUTES',[(b.get('kind'),len(b.get('artifacts',{})),list(b.get('artifacts',{}))[:30]) for b in W['bundles']])
print('FIT_REAL_CASES',[(c['case_id'],list(c)) for c in F['cases'] if c['group']=='FIT-REAL'][:1])
print('REAL_WORKER_INVENTORY',json.dumps(F['real_worker_inventory'],indent=2)[:9000])
for f in ['own-red.xml']:
 root=ET.fromstring((D/f).read_bytes());tests=root.findall('.//testcase')
 print('HISTORICAL_RED',len(tests),sum(t.find('failure') is not None for t in tests),[t.attrib['name'] for t in tests])
lb=load(S/'a2-independent-final-complete-l_bwads9/supplemental-run3/supplemental-proof.json')['resource_branch_independent_lower_bounds']
print('NECESSARY_LOWER_BOUNDS',json.dumps(lb,indent=2))
