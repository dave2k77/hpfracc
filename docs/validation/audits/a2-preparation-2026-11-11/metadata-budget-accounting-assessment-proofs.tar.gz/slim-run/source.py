from pathlib import Path
import json
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc');A=R/'docs/validation/audits/a2-preparation-2026-11-11';D=Path('/home/davianc/.hermes/cache/scratch/a2-budget-revision-20261112')
f=json.loads((A/'fixtures.json').read_text());p=json.loads((A/'protocol.json').read_text());s=json.loads((D/'accounted-before/sample-STATIC-METADATA-PROJECTION.json').read_text())['records'];c=next(c for c in f['cases'] if c['case_id']=='FIT-stacked-tau1-f32-GL')
for k in ['request','required_evidence_slots','required_working_comparisons','required_fit_identity_checks','required_full_observations']:
 v=c[k]; print('CASE',k,json.dumps(v[:1] if isinstance(v,list) else v))
for k in ['candidate_ids','candidate_occurrences','slots','comparisons','binding_checks']:
 v=s['initial_failure_index'][k];print('INITIAL',k,json.dumps(v[:1] if isinstance(v,list) else v))
print('INITIAL_REQUEST_ID',s['initial_failure_index']['request_id'])
print('CANDIDATE_EXAMPLE',next(iter(f['candidates'].items())))
print('CANDIDATES_ALL_KEYS',[(k,list(v),v.get('record_type'),v.get('rhos'),v.get('coefficients')) for k,v in f['candidates'].items() if v.get('record_type')=='candidate_spec'])
print('RESOURCE_ACCOUNTING',json.dumps(p['resource_accounting'],indent=2))
