"""Independent necessary linkage refusal, not a complete exporter/validator."""
from pathlib import Path
import json
D=Path('/home/davianc/.hermes/cache/scratch/a2-budget-revision-20261112');O=Path(__file__).parent
r=json.loads((D/'accounted-before/sample-STATIC-METADATA-PROJECTION.json').read_text())['records']
missing=[z['artifact']['path'] for z in r['failure-index.json']['slots'] if z['artifact'] is not None and z['artifact']['path'] not in r]
x={'label':'Actual independent necessary linkage check only; not full admission and not a JAX run','missing_conditional_artifact_obligations':len(missing),'existing_record_count':len(r),'passed':not missing,'missing_files_not_equivalent_to_numerical_failure':True}
(O/'fresh-linkage-refusal.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
assert not missing,'372 declared conditional artifacts remain unclosed in this projection; cannot assert linked complete-export accounting'
