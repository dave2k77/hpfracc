"""Finalize fail-closed review with compact byte-identified evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

S=Path(__file__).resolve().parent
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
TREE='92ff3dceb217f6097bae8ccde6cf159d8daa8d14'
sha=lambda b: hashlib.sha256(b).hexdigest()
identity=json.loads((S/'identity-checks.json').read_text())
probes=json.loads((S/'independent-probes.json').read_text())
supp=json.loads((S/'supplemental-probes.json').read_text())
focused=json.loads((S/'focused-result.json').read_text())
blocking=json.loads((S/'blocking-result.json').read_text())
assert focused['pytest_exit']==0 and focused['junit']=={'tests':81,'failures':0,'errors':0,'skipped':0}
assert blocking['pytest_exit']==1 and blocking['junit']=={'tests':6,'failures':6,'errors':0,'skipped':0}
assert all(not vals for vals in identity['static_scan']['findings'].values())
assert supp['all_selected_math_checks_passed']
assert probes['counts']['weight_failed']==probes['counts']['extrema_failed']==probes['counts']['end_to_end_failed']==probes['counts']['arithmetic_not_rejected']==0
# Read back the exact immutable and worktree input bytes after executions.
post=[]
for rec in identity['source_archive']['checks']:
    path=rec['path'];expected=rec['expected_sha256']
    immutable=subprocess.check_output(['git','show',TREE+':'+path],cwd=R)
    post.append({'path':path,'tree_matches':sha(immutable)==expected,'worktree_matches':sha((R/path).read_bytes())==expected})
assert len(post)==125 and all(x['tree_matches'] and x['worktree_matches'] for x in post)
for key in ('manifest','archive'):
    assert sha(Path(identity['source_archive'][key+'_path']).read_bytes())==identity['source_archive'][key+'_sha256']
weight_rel=[e for x in probes['weight_checks'] for e in x['relative_errors']]
weight_rel += [e for key in ('old_near_kernel_limit','very_small_q') for x in supp[key] for e in x['relative_errors']]
counts={'focused_cpu':focused['junit'],'blocking_independent':blocking['junit'],
        'selected_panel_weight_comparisons':len(probes['weight_checks'])+len(supp['old_near_kernel_limit'])+len(supp['very_small_q']),
        'selected_panel_weight_max_relative_error':max(weight_rel),
        'range_corroborations':len(probes['extrema_checks']),'peak_derivative_checks':len(supp['peak_derivatives']),
        'independent_shifted_coupled_cases':len(probes['end_to_end']),
        'explicit_underflow_or_overflow_rejection_cases':len(probes['arithmetic_rejections']),
        'supplementary_gamma_ratio_cases':len(supp['gamma_ratio']),
        'supplementary_gamma_ratio_explicit_rejections':sum(x.get('explicitly_rejected',False) for x in supp['gamma_ratio']),
        'source_inputs_verified_before_and_after':len(post),
        'arithmetic_verified':False,'total_numerical_certified':False,'a1_acceptance_passed':False}
(S/'aggregate-checks.json').write_text(json.dumps(counts,indent=2)+'\n')
(S/'post-execution-identities.json').write_text(json.dumps({'tree':TREE,'checks':post,'all_match':True},indent=2)+'\n')
execution={'working_directory':str(R),'common_command':'env -u UV_PROJECT_ENVIRONMENT PYTHONDONTWRITEBYTECODE=1 JAX_PLATFORMS=cpu JAX_ENABLE_X64=false OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 uv run --frozen --extra dev python <scratch_script>',
           'runs':[{'script':'run_focused.py','process_exit':0,'role':'81 immutable focused tests; CPU only'},
                   {'script':'edge_probe.py','process_exit':0,'role':'minimal reconstruction counterexample; full binary inputs retained'},
                   {'script':'independent_probes.py','process_exit':0,'role':'raw independent math/edge measurements; not an approval'},
                   {'script':'test_independent_blockers.py','process_exit':1,'role':'six genuine mathematical/edge RED assertions; explicit FloatingPointError allowed'},
                   {'script':'supplemental_probes.py','process_exit':1,'role':'first harness stopped on a correctly explicit underflow; raw supplemental-first.stderr retained'},
                   {'script':'supplemental_probes.py','process_exit':0,'role':'harness corrected to record allowed explicit underflow, no production changes'}],
           'scope':'Only three pinned files copied; existing 125-input archive verified in memory, not duplicated. No repository/index/docs/fixture edits, full suite, GPU job, commit, push, or repair.'}
(S/'execution-record.json').write_text(json.dumps(execution,indent=2)+'\n')

review={
 'passed':False,
 'security_concerns':[],
 'logic_errors':[
   {'id':'B1','severity':'blocking','location':'benchmarks/numerical/_volterra_defect.py:102-104; point call at 176; cell call at 255',
    'summary':'The new np.interp reconstruction still cancels a normal, representable PL tail to zero in both APIs.',
    'reproduction':{'ts':[-2.,-1.,1e-17],'states':[[0.],[1e20],[0.]],'target':0.,'order':.5,'matrix':[[0.]],'initial_state':[0.],'verification_mesh':[-2.,-1.,0.,1e-17]},
    'actual':'Point reconstruction and defect are 0; last cell model range is [0,0]. No exception.',
    'expected':'Exact represented-input PL reconstruction and defect at t=0 are 1000.000000000000061542424054621923...; the last positive-width cell must not lose this entire contribution.',
    'root_cause':'np.interp uses slope/intercept-style arithmetic on these represented inputs; its local evaluation cancels the endpoint tail. Finiteness and false certification flags do not detect or justify a 100% point-value error.',
    'evidence':'blocking.xml: test_local_reconstruction_must_not_erase_normal_tail[point/cells]; independent-probes.json; supplemental-probes.json'},
   {'id':'B2','severity':'blocking','location':'benchmarks/numerical/_volterra_defect.py:102-104,175-176,254-255',
    'summary':'np.errstate(under="raise") does not trap intermediate underflow inside np.interp, so the advertised explicit-underflow rejection fails in both APIs.',
    'reproduction':{'ts':[0.,1e300],'states':[[0.],[1e-100]],'target':5e299,'order':.5,'matrix':[[0.]],'initial_state':[0.],'verification_mesh':[0.,5e299,1e300]},
    'actual':'Point reconstruction and defect are 0; the first cell model range is [0,0]. No FloatingPointError is raised.',
    'expected':'The exact represented-input midpoint value/defect is 5.000000000000000099959499013...e-101, a normal float64 result. Explicitly reject the unsafe intermediate arithmetic or preserve that result; silent zero is not permitted.',
    'root_cause':'The interpolation slope is about 1e-400. The same NumPy scalar division raises underflow inside errstate, but np.interp returns zero silently. The outer errstate and final finiteness checks are therefore not a complete failure guard.',
    'evidence':'blocking.xml: test_interpolation_underflow_must_raise_or_preserve_normal_result[point/cells]; supplemental-probes.json: root_cause_checks'},
   {'id':'B3','severity':'blocking','location':'benchmarks/numerical/_volterra_defect.py:119-127,139-140; cell reuse at 147-148,262',
    'summary':'The clipped active-panel left-basis conversion subtracts a rounded fraction from one and loses an independently resolvable terminal gap.',
    'reproduction':{'ts':[-2.,-1.,1e-17],'states':[[0.,0.],[0.,1e20],[0.,0.]],'target':0.,'order':1e-20,'matrix':[[0.,1.],[0.,0.]],'initial_state':[0.,0.],'verification_mesh':[-2.,-1.,0.,1e-17]},
    'actual':'Component-0 point defect and last-cell lower endpoint are -1.3862943611198906.',
    'expected':'The exact represented-input component-0 defect at t=0 is approximately -1001.38629436112; the last cell excludes it by about 1000.',
    'root_cause':'For the active panel left=-1, right=1e-17, t=0, rounded width=tau=cut=1 gives fraction=1 and 1-fraction=0, despite right-t=1e-17. The computed left weight is 1e-20 instead of approximately 1.001e-17. The protected old-panel z calculation does not protect this sibling active-panel complement. The accepted order 1e-20 satisfies 0<alpha<1; no documented arithmetic rejection occurs.',
    'evidence':'blocking.xml: test_active_basis_must_retain_independently_resolved_right_gap[point/cells]; independent-probes.json; supplemental-probes.json'}
 ],
 'suggestions':[
   'Escalate this rejection to the parent/user: this is the second and final repair cycle. Do not start another repair loop or commit/push these bytes as approved.',
   'Retain all six independent RED assertions and exact binary input handles. A future explicitly authorized change must either preserve these representable values or reject the unsafe configurations explicitly, without changing the accepted mathematical order/input scope silently.',
   'Keep A1 acceptance, arithmetic verification and total numerical certification false. Passing selected tests/probes does not close propagated error budgets, verified arithmetic/evaluation/input/output, nonlinear domains, science calibration or controller integration.'
 ],
 'summary':f'Rejected final repair tree: 81/81 focused CPU tests pass and selected positive-basis/near-limit/extrema/history checks agree, but three distinct blocking numerical defects reproduce as six independent RED cases across both APIs. {counts["selected_panel_weight_comparisons"]} selected panel-weight comparisons pass (maximum measured relative error {max(weight_rel):.3g}); this is not a general accuracy or enclosure guarantee. Current archive has 125 matching immutable inputs, the original frozen fixture is unchanged, and no security findings were detected.',
 'reviewed_tree':TREE,
 'evidence_paths':[],
 'a1_acceptance_passed':False,
}
for name in ['identity-checks.json','post-execution-identities.json','execution-record.json','aggregate-checks.json',
             'focused-result.json','focused.stdout','focused.stderr','focused.xml',
             'blocking-result.json','blocking.stdout','blocking.stderr','blocking.xml','test_independent_blockers.py',
             'independent-probes.json','independent.stdout','independent.stderr','independent_probes.py',
             'supplemental-probes.json','supplemental.stdout','supplemental.stderr','supplemental-first.stderr','supplemental_probes.py']:
    path=S/name
    review['evidence_paths'].append({'path':str(path),'sha256':sha(path.read_bytes())})
review_path=S/'review.json'
review_path.write_text(json.dumps(review,indent=2,allow_nan=False)+'\n')
# Full baseline patch duplicates all three pinned files. The identities/static
# scan retain the comparison; keep only the smaller repair diff.
(S/'baseline.diff').unlink()
files={str(p.relative_to(S)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
       for p in sorted(S.rglob('*')) if p.is_file() and p.name!='hash-index.json'}
index={'reviewed_tree':TREE,'scope':'scratch evidence only; index excludes itself','files':files,
       'count':len(files),'total_bytes':sum(x['bytes'] for x in files.values())}
indexpath=S/'hash-index.json'
indexpath.write_text(json.dumps(index,indent=2)+'\n')
# Validate all saved hashes and required JSON policy conditions.
assert all(sha((S/path).read_bytes())==v['sha256'] for path,v in files.items())
parsed=json.loads(review_path.read_text())
assert parsed['passed'] is False and parsed['a1_acceptance_passed'] is False
assert not parsed['security_concerns'] and len(parsed['logic_errors'])==3
print(json.dumps({'review_path':str(review_path),'review_sha256':sha(review_path.read_bytes()),
                  'hash_index_path':str(indexpath),'hash_index_sha256':sha(indexpath.read_bytes()),
                  'evidence_file_count':index['count'],'evidence_bytes':index['total_bytes'],
                  'aggregate':counts},indent=2))
