"""Pin requested bytes and verify the existing archive without copying it."""
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import tarfile

R = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
S = Path(__file__).resolve().parent
A = R / 'docs/validation/audits/a1-trajectory-defect-2026-11-11'
TREE = '92ff3dceb217f6097bae8ccde6cf159d8daa8d14'
OLD = '8dcbfafd1a5373088e75437551692a85fd7f7b77'
BASE = '74d8f08c01179115c2752da5604a9cd85bba89bc'
PATHS = ['benchmarks/numerical/_volterra_defect.py', 'tests/unit/test_volterra_defect.py',
         'docs/validation/audits/a1-trajectory-defect-2026-11-11/frozen-fixtures.json']
def git(*args):
    return subprocess.check_output(['git', *args], cwd=R)
def sha(data):
    return hashlib.sha256(data).hexdigest()
meta = {'tree': TREE, 'rejected_tree': OLD, 'baseline_commit': BASE, 'files': {}}
for path in PATHS:
    data = git('show', TREE + ':' + path)
    dest = S / 'pinned' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    meta['files'][path] = {'sha256': sha(data), 'git_blob': git('rev-parse', TREE+':'+path).decode().strip(),
                          'bytes': len(data), 'worktree_matches': (R/path).read_bytes() == data}
meta['baseline_diff_names'] = git('diff', '--name-status', BASE, TREE).decode()
meta['repair_diff_names'] = git('diff', '--name-status', OLD, TREE).decode()
for label, tree in [('baseline', BASE), ('rejected', OLD)]:
    diff = git('diff', '--no-ext-diff', tree, TREE, '--', *PATHS)
    (S / (label + '.diff')).write_bytes(diff)
    if label == 'baseline':
        added = '\n'.join(x[1:] for x in diff.decode().splitlines() if x.startswith('+') and not x.startswith('+++'))
        patterns = {'secret_assignment': r'''(?i)(api_key|secret|password|token|passwd)\s*=\s*['"][^'"]{6,}['"]''',
                    'shell_injection': r'os\.system\(|subprocess.*shell=True',
                    'eval_exec': r'\b(?:eval|exec)\(', 'pickle': r'pickle\.loads?\(',
                    'sql': r'execute\(f["\']|\.format\(.*(?:SELECT|INSERT)'}
        meta['static_scan'] = {'added_lines': len(added.splitlines()),
                               'findings': {k: re.findall(p, added) for k,p in patterns.items()}}
manifest_bytes = (A/'source-snapshot.json').read_bytes()
manifest = json.loads(manifest_bytes)
archive_bytes = (A/'source-snapshot.tar.gz').read_bytes()
archive = tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz')
entries = {m.name: archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
checks = []
for path, digest in manifest['paths'].items():
    blob = git('show', TREE+':'+path)
    checks.append({'path': path, 'expected_sha256': digest, 'git_matches': sha(blob) == digest,
                   'archive_matches': path in entries and sha(entries[path]) == digest,
                   'worktree_matches': sha((R/path).read_bytes()) == digest})
meta['source_archive'] = {'manifest_path': str(A/'source-snapshot.json'), 'manifest_sha256': sha(manifest_bytes),
                          'archive_path': str(A/'source-snapshot.tar.gz'), 'archive_sha256': sha(archive_bytes),
                          'declared_count': manifest['count'], 'manifest_count': len(checks),
                          'archive_count': len(entries), 'all_match': all(all(c[k] for k in ('git_matches','archive_matches','worktree_matches')) for c in checks),
                          'checks': checks}
fixture = git('show', TREE+':'+PATHS[-1])
meta['frozen_fixture_unchanged_from_rejected'] = fixture == git('show', OLD+':'+PATHS[-1])
# Identify the original freeze by finding its exact bytes in preserved archives.
fixture_hash = sha(fixture)
original_handles = []
for arcpath in sorted(A.glob('*.tar.gz')):
    if arcpath.name == 'source-snapshot.tar.gz':
        continue
    with tarfile.open(arcpath, 'r:gz') as arc:
        for member in arc.getmembers():
            if member.isfile() and ('frozen-fixtures' in member.name or 'manifest' in member.name):
                data = arc.extractfile(member).read()
                if sha(data) == fixture_hash:
                    original_handles.append({'archive': str(arcpath), 'archive_sha256': sha(arcpath.read_bytes()),
                                             'member': member.name, 'fixture_sha256': fixture_hash})
meta['original_fixture_handles'] = original_handles
meta['environment'] = {'python': platform.python_version(), 'platform': platform.platform(),
                       'uv': subprocess.check_output(['uv','--version'], text=True).strip(),
                       'requested_backend': 'cpu', 'global_x64_requested': False}
(S/'identity-checks.json').write_text(json.dumps(meta, indent=2)+'\n')
assert len(checks) == len(entries) == manifest['count'] == 125
assert meta['source_archive']['all_match']
assert all(c['worktree_matches'] for c in meta['files'].values())
assert meta['frozen_fixture_unchanged_from_rejected']
print(json.dumps({k:v for k,v in meta.items() if k not in ('source_archive',)}, indent=2))
print('Verified current archive/manifest/tree/worktree for all 125 inputs.')
