"""Audit cancellation guards, mathematical identities, and failure mechanisms."""
import contextlib
import importlib.util
import json
from pathlib import Path
import sys

import mpmath as mp
import numpy as np

S=Path(__file__).resolve().parent
R=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
sys.path.insert(0,str(R))
spec=importlib.util.spec_from_file_location('supplement_diagnostic',S/'pinned/benchmarks/numerical/_volterra_defect.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)

def exact(x):
    n,d=float(x).as_integer_ratio()
    return mp.mpf(n)/d

out={'old_near_kernel_limit':[],'very_small_q':[],'gamma_ratio':[],'peak_derivatives':[],
     'root_cause_checks':{},'arithmetic_verified':False,'total_numerical_certified':False}
with mp.workdps(530):
    for label,alpha_list,l,r,t in [
        ('old_near_kernel_limit',[1e-20,1e-12,.3,.5,.9,np.nextafter(1.,0.)],-1.,1e-17,2e-17),
        ('very_small_q',[.3,.5,.75],0.,1e-300,1.),
        ('very_small_q',[.3,.5,.75],0.,1.,1e300),
    ]:
        for a in alpha_list:
            tau=exact(t)-exact(l);w=exact(r)-exact(l);q=w/tau
            wr=tau**(exact(a)+1)/(w*mp.gamma(exact(a)))*mp.betainc(2,exact(a),0,q)
            wl=tau**exact(a)/mp.gamma(exact(a))*mp.betainc(1,exact(a),0,q)-wr
            with np.errstate(all='raise'):
                got=m._panel_weights(np.array([t]),l,r,a)
            errs=[float(abs(exact(x[0])-y)/y) for x,y in zip(got,(wl,wr),strict=True)]
            out[label].append({'input_hex':{k:float(v).hex() for k,v in dict(left=l,right=r,target=t,alpha=a).items()},
                               'computed':[float(x[0]) for x in got],'reference':[mp.nstr(wl,50),mp.nstr(wr,50)],
                               'relative_errors':errs,'computed_q':(r-l)/(t-l),
                               'independent_age':(t-r)/(t-l),'passed':max(errs)<2e-12})
    for beta,a in [(1e308,.5),(1e308,np.nextafter(1.,0.)),(1e200,.01),(1e16,.999)]:
        ref=mp.exp(mp.loggamma(exact(beta)+1)-mp.loggamma(exact(beta)+exact(a)+1))
        record={'beta_hex':beta.hex(),'alpha_hex':float(a).hex(),'reference':mp.nstr(ref,60)}
        try:
            with np.errstate(all='raise'):
                got=float(m._power_integral_ratio(np.float64(beta),a))
            err=float(abs(exact(got)-ref)/ref)
            record.update(computed=got,relative_error=err,passed=err<2e-12,explicitly_rejected=False)
        except FloatingPointError as exc:
            record.update(exception=str(exc),explicitly_rejected=True,passed='underflow' in str(exc))
        out['gamma_ratio'].append(record)
    for a in [.001,.3,.5,.95]:
        a=exact(a);w=mp.mpf(4)
        fun=lambda tau:tau**a/mp.gamma(a+1)*(1-tau/(w*(a+1)))
        peak=a*w
        derivative=mp.diff(fun,peak)
        left_derivative=mp.diff(fun,peak/2)
        right_derivative=mp.diff(fun,(peak+w)/2)
        analytic_peak=peak**a/(mp.gamma(a+1)*(a+1))
        out['peak_derivatives'].append({'alpha':float(a),'peak_tau':float(peak),
                                        'derivative_at_peak':mp.nstr(derivative,10),
                                        'derivative_before_positive':left_derivative>0,
                                        'derivative_after_negative':right_derivative<0,
                                        'peak_value_matches':mp.almosteq(fun(peak),analytic_peak),
                                        'passed':abs(derivative)<mp.mpf('1e-500') and left_derivative>0 and right_derivative<0 and mp.almosteq(fun(peak),analytic_peak)})
    # Exact represented widths/gaps, contrasted with rounded arithmetic.
    l,r,t=-1.,1e-17,0.
    out['root_cause_checks']['active_complement']={
        'float_width':r-l,'float_tau':t-l,'float_fraction':(t-l)/(r-l),
        'one_minus_float_fraction':1-(t-l)/(r-l),
        'independent_right_gap':r-t,
        'exact_fraction_complement':mp.nstr((exact(r)-exact(t))/(exact(r)-exact(l)),80)}
    # Both NumPy ufunc underflow and the np.interp internal underflow use
    # the same represented data and errstate; only the former raises.
    try:
        with np.errstate(all='raise'):
            val=np.float64(1e-100)/np.float64(1e300)
        out['root_cause_checks']['ufunc_slope_underflow']={'raised':False,'value':float(val)}
    except FloatingPointError as exc:
        out['root_cause_checks']['ufunc_slope_underflow']={'raised':True,'exception':str(exc)}
    with np.errstate(all='raise'):
        val=np.interp(np.array([5e299]),np.array([0.,1e300]),np.array([0.,1e-100]))
    out['root_cause_checks']['np_interp_slope_underflow']={'raised':False,'value':val.tolist(),'correct_normal_value':5e-101}
    with np.errstate(all='raise'):
        val=np.interp(np.array([0.]),np.array([-1.,1e-17]),np.array([1e20,0.]))
    out['root_cause_checks']['np_interp_cancellation']={'raised':False,'value':val.tolist(),
        'correct_value':mp.nstr(exact(1e20)*(exact(1e-17)-exact(0.))/(exact(1e-17)-exact(-1.)),80)}
out['exact_model_derivations']={
    'active_right_weight':'tau^(a+1)/(width*Gamma(a+2))',
    'active_left_weight':'tau^a/Gamma(a+1) * (1-tau/(width*(a+1)))',
    'active_left_derivative':'tau^(a-1)/Gamma(a+1)*(a-tau/width)',
    'active_left_peak':'tau=a*width; value=(a*width)^a/(Gamma(a+1)*(a+1))',
    'active_right_derivative':'tau^a/(width*Gamma(a+1))>0',
    'old_monotonicity':'For t>right, d/dt I(phi)=(a-1)/Gamma(a)*integral(phi(s)*(t-s)^(a-2),left,right)<0 for each nonnegative local basis phi.',
    'small_q_identity':'Euler beta integral: factor=mass*q*a/2; left= factor*2F1(1-a,1;3;q), right=factor*2F1(1-a,2;3;q).',
    'near_identity_left':'mass/q*(a/(a+1)-z+z^(a+1)/(a+1)); expm1(a*log(z)-log1p(a)) form is algebraically identical for real q+z=1.',
    'near_identity_right':'mass/q*(1/(a+1)-z^a+a*z^(a+1)/(a+1)); expm1 combination is algebraically identical.',
    'signed_ranges':'Union includes every source knot. Reconstruction is affine on every cell; extrema are endpoints. Positive-basis extrema combined with each signed A@y_node and monotone signed forcing term yield a real-arithmetic natural extension.',
    'certification_boundary':'These identities do not certify computed float64 endpoints, gamma/powers/hypergeometric evaluation, input/RHS/output arithmetic, or continuum solution error. All acceptance/certification flags stay false.'}
out['counts']={k:len(out[k]) for k in ('old_near_kernel_limit','very_small_q','gamma_ratio','peak_derivatives')}
out['all_selected_math_checks_passed']=all(x['passed'] for k in out['counts'] for x in out[k])
(S/'supplemental-probes.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'counts':out['counts'],'all_selected_math_checks_passed':out['all_selected_math_checks_passed'],
                  'root_cause_checks':out['root_cause_checks']},indent=2))
assert out['all_selected_math_checks_passed']
