"""RED-only independent acceptance probes; rejecting unsafe input is allowed."""
import importlib.util
import json
from pathlib import Path
import sys

import mpmath as mp
import numpy as np
import pytest

S = Path(__file__).resolve().parent
R = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
sys.path.insert(0, str(R))
NAME = 'review_blocking_diagnostic'
spec = importlib.util.spec_from_file_location(NAME, S/'pinned/benchmarks/numerical/_volterra_defect.py')
mod = importlib.util.module_from_spec(spec)
sys.modules[NAME] = mod
spec.loader.exec_module(mod)


def exact(x):
    n, d = float(x).as_integer_ratio()
    return mp.mpf(n)/d


@pytest.mark.parametrize('api', ['point', 'cells'])
def test_local_reconstruction_must_not_erase_normal_tail(api):
    ts = np.array([-2., -1., 1e-17])
    states = np.array([[0.], [1e20], [0.]])
    kw = dict(order=.5, matrix=np.zeros((1,1)), initial_state=states[0])
    with mp.workdps(150):
        ref = float(exact(1e20)*exact(1e-17)/(exact(1e-17)-exact(-1.)))
    try:
        if api == 'point':
            result = mod.affine_power_defect(ts, states, np.array([0.]), **kw)
            got = result.defect[0,0]
        else:
            result = mod.affine_power_cells(ts, states, np.array([-2.,-1.,0.,1e-17]), **kw)
            got = result.model_upper[-1,0]
    except FloatingPointError:
        return
    assert got == pytest.approx(ref, rel=2e-12, abs=0), (api, got, ref)


@pytest.mark.parametrize('api', ['point', 'cells'])
def test_interpolation_underflow_must_raise_or_preserve_normal_result(api):
    ts = np.array([0., 1e300])
    states = np.array([[0.], [1e-100]])
    kw = dict(order=.5, matrix=np.zeros((1,1)), initial_state=states[0])
    with mp.workdps(150):
        ref = float(exact(1e-100)*exact(5e299)/exact(1e300))
    try:
        if api == 'point':
            result = mod.affine_power_defect(ts, states, np.array([5e299]), **kw)
            got = result.defect[0,0]
        else:
            result = mod.affine_power_cells(ts, states, np.array([0.,5e299,1e300]), **kw)
            got = result.model_upper[0,0]
    except FloatingPointError:
        return
    assert got == pytest.approx(ref, rel=2e-12, abs=0), (api, got, ref)


@pytest.mark.parametrize('api', ['point', 'cells'])
def test_active_basis_must_retain_independently_resolved_right_gap(api):
    ts = np.array([-2., -1., 1e-17])
    states = np.array([[0.,0.], [0.,1e20], [0.,0.]])
    kw = dict(order=1e-20, matrix=np.array([[0.,1.],[0.,0.]]), initial_state=states[0])
    with mp.workdps(220):
        a=exact(1e-20); t=exact(0.); l=exact(-1.); r=exact(1e-17)
        tau=t-l;w=r-l;mass=tau**a/mp.gamma(a+1)
        active_left=mass*((r-t)/w+(tau/w)*a/(a+1))
        tau_old=t-exact(-2.);w_old=exact(-1.)-exact(-2.);q=w_old/tau_old
        old_right=tau_old**(a+1)/(w_old*mp.gamma(a))*mp.betainc(2,a,0,q)
        ref = -float(exact(1e20)*(active_left+old_right))
    try:
        if api == 'point':
            result=mod.affine_power_defect(ts,states,np.array([0.]),**kw)
            got=result.defect[0,0]
            assert got == pytest.approx(ref, rel=2e-12, abs=0), (api, got, ref)
        else:
            result=mod.affine_power_cells(ts,states,np.array([-2.,-1.,0.,1e-17]),**kw)
            lo=result.model_lower[-1,0]
            assert lo <= ref+abs(ref)*2e-12, (api, lo, ref)
    except FloatingPointError:
        return


if __name__ == '__main__':
    import contextlib
    import xml.etree.ElementTree as ET
    with (S/'blocking.stdout').open('w') as out, (S/'blocking.stderr').open('w') as err:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            rc=pytest.main([str(Path(__file__)), '-q', '-c', str(R/'pyproject.toml'),
                            '-p','no:cacheprovider','--junitxml='+str(S/'blocking.xml')])
    suites=list(ET.parse(S/'blocking.xml').getroot().iter('testsuite'))
    status={'pytest_exit':int(rc),'junit':{k:sum(int(x.get(k,0)) for x in suites) for k in ('tests','failures','errors','skipped')}}
    (S/'blocking-result.json').write_text(json.dumps(status,indent=2)+'\n')
    print(json.dumps(status,indent=2))
    raise SystemExit(rc)
