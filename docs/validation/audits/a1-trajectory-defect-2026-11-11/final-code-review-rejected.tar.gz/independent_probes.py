"""Independent mathematical/edge audit of pinned final-cycle source."""
import contextlib
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import traceback

import mpmath as mp
import numpy as np

S = Path(__file__).resolve().parent
R = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
sys.path.insert(0, str(R))
name = 'benchmarks.numerical._volterra_defect'
spec = importlib.util.spec_from_file_location(name, S/'pinned/benchmarks/numerical/_volterra_defect.py')
m = importlib.util.module_from_spec(spec)
sys.modules[name] = m
spec.loader.exec_module(m)

def exact(x):
    n,d = float(x).as_integer_ratio()
    return mp.mpf(n)/d

def pack(value):
    if isinstance(value, np.ndarray):
        return {'values': value.tolist(), 'hex': np.vectorize(lambda x: float(x).hex(), otypes=[str])(value).tolist()}
    if isinstance(value, (float, np.floating)):
        return {'value': float(value), 'hex': float(value).hex()}
    if isinstance(value, dict):
        return {k: pack(v) for k,v in value.items()}
    return value

def weight_reference(t, l, r, a):
    """Incomplete-beta integrals of original panel coordinates, 220 digits."""
    t,l,r,a = map(exact, (t,l,r,a))
    if t <= l:
        return mp.mpf(0),mp.mpf(0)
    tau,w = t-l,r-l
    q = min(tau,w)/tau
    mass = tau**a/mp.gamma(a+1)
    if t <= r:
        wr = mass*tau/(w*(a+1))
        wl = mass*((r-t)/w + (tau/w)*a/(a+1))
    else:
        wr = tau**(a+1)/(w*mp.gamma(a))*mp.betainc(2,a,0,q)
        wl = tau**a/mp.gamma(a)*mp.betainc(1,a,0,q)-wr
    return wl,wr

def independent_reconstruction(ts, states, target):
    if target == ts[-1]:
        return list(map(exact,states[-1]))
    j = max(0, np.searchsorted(ts,target,side='right')-1)
    l,r,t = map(exact,(ts[j],ts[j+1],target))
    return [((r-t)*exact(x)+(t-l)*exact(y))/(r-l) for x,y in zip(states[j],states[j+1],strict=True)]

def independent_rhs(ts, states, target, a, matrix, powers=(), coefficients=()):
    """Separate panelwise transformed kernel quadrature for non-extreme cases."""
    nodes = list(map(exact,ts)); values=[[exact(x) for x in row] for row in states]
    t,a=map(exact,(target,a)); dim=states.shape[1]
    out=[]
    for i in range(dim):
        total=mp.mpf(0)
        for j,l in enumerate(nodes[:-1]):
            r=min(t,nodes[j+1])
            if r<=l:
                continue
            def f(u, j=j, l=l, i=i):
                s=t-u**(1/a)
                frac=(s-l)/(nodes[j+1]-l)
                y=[(1-frac)*x+frac*z for x,z in zip(values[j],values[j+1],strict=True)]
                return mp.fsum(exact(matrix[i,k])*y[k] for k in range(dim))
            total+=mp.quad(f,[(t-r)**a,(t-l)**a])/mp.gamma(a+1)
        tau=t-nodes[0]
        total+=mp.fsum(exact(c[i])*tau**(exact(b)+a)*mp.beta(exact(b)+1,a)/mp.gamma(a)
                       for b,c in zip(powers,coefficients,strict=True))
        out.append(total)
    return out

results={'pinned_tree':'92ff3dceb217f6097bae8ccde6cf159d8daa8d14',
         'precision_digits':220,'weight_checks':[],'end_to_end':[],'extrema_checks':[],
         'arithmetic_rejections':[],'blocking_edges':[], 'all_arithmetic_uncertified':True}

with mp.workdps(220):
    # Both sides of q=.5; near the old-panel terminal; extreme old history;
    # near zero/one orders; partial active panels with ordinary coordinates.
    alphas=[1e-12,.01,.3,.5,.9,np.nextafter(1.,0.)]
    panels=[(0.,1.,.125),(0.,1.,.5),(0.,1.,1.),
            (0.,1.,np.nextafter(1.,np.inf)),(0.,1.,1.00000001),
            (0.,1.,np.nextafter(2.,0.)),(0.,1.,2.),(0.,1.,np.nextafter(2.,np.inf)),
            (0.,1.,1e8),(0.,1e-17,1.),(-3.,-2.,-2.5),(-3.,-2.,np.nextafter(-2.,np.inf)),
            (1e20,np.nextafter(1e20,np.inf),np.nextafter(np.nextafter(1e20,np.inf),np.inf))]
    for a in alphas:
        for l,r,t in panels:
            with np.errstate(all='raise'):
                got=m._panel_weights(np.array([t]),l,r,a)
            ref=weight_reference(t,l,r,a)
            rel=[float(abs(exact(g[0])-e)/abs(e)) if e else float(abs(exact(g[0]))) for g,e in zip(got,ref,strict=True)]
            item={'input':pack(dict(left=l,right=r,target=t,alpha=a)),
                  'computed':[float(x[0]) for x in got],
                  'reference':[mp.nstr(x,45) for x in ref], 'relative_errors':rel,
                  'nonnegative':all(float(x[0])>=0 for x in got),'passed':max(rel)<2e-12}
            results['weight_checks'].append(item)
    # Continuous extrema: exact derivative reasoning is recorded separately;
    # independently check analytic peak and old-panel samples, not a certificate.
    for a in [.001,.05,.3,.5,.95,np.nextafter(1.,0.)]:
        l,r=-1.25,2.75
        edges=np.array([l,l+.5*(a*(r-l)),l+1.5*(a*(r-l)),r,r+1.,r+100.])
        edges=np.unique(np.sort(np.minimum(edges,r+100.)))
        lo,hi=m._panel_ranges(edges,l,r,a)
        violations=[]
        for j,(x,y) in enumerate(zip(edges[:-1],edges[1:],strict=True)):
            times=np.linspace(x,y,17).tolist()
            peak=exact(l)+exact(a)*(exact(r)-exact(l))
            if exact(x)<=peak<=exact(y):
                times.append(float(peak))
            for t in times:
                refs=weight_reference(t,l,r,a)
                for k,e in enumerate(refs):
                    # Explicit comparison slack, NOT directed enclosure evidence.
                    slack=mp.mpf('2e-12')*max(mp.mpf(1),abs(e))
                    if e<exact(lo[k][j])-slack or e>exact(hi[k][j])+slack:
                        violations.append({'t':t,'basis':k,'reference':str(e)})
        old_times=[r+2.**k for k in range(-30,31,3)]
        old=[weight_reference(t,l,r,a) for t in old_times]
        decreasing=all(old[j+1][k]<=old[j][k] for j in range(len(old)-1) for k in (0,1))
        results['extrema_checks'].append({'alpha':a,'edges':edges.tolist(),'violations':violations,
                                          'old_panel_monotonicity':decreasing,
                                          'passed':not violations and decreasing})
    # Independent non-diagonal, old-history, shifted-origin controls.
    for origin in [-7.,.375,20.]:
        ts=np.array([0.,.0625,.5,1.])+origin
        states=np.array([[.5,-2.],[2.,1.],[-.75,3.],[1.,-.5]])
        matrix=np.array([[.125,-.75],[1.25,.375]])
        powers=np.array([0.,.125,2.5]);coeff=np.array([[.3,-.2],[.7,.4],[-.1,.6]])
        a=.42;targets=np.array([origin+.03125,origin+.3125,origin+.9375])
        kw=dict(order=a,matrix=matrix,initial_state=states[0],power_exponents=powers,power_coefficients=coeff)
        got=m.affine_power_defect(ts,states,targets,**kw)
        rhs=[independent_rhs(ts,states,t,a,matrix,powers,coeff) for t in targets]
        y=[independent_reconstruction(ts,states,t) for t in targets]
        rhs_error=max(float(abs(exact(g)-e)) for rowg,rowe in zip(got.fractional_rhs,rhs,strict=True) for g,e in zip(rowg,rowe,strict=True))
        y_error=max(float(abs(exact(g)-e)) for rowg,rowe in zip(got.reconstruction,y,strict=True) for g,e in zip(rowg,rowe,strict=True))
        cells=m.affine_power_cells(ts,states,np.array([origin,origin+.2,origin+.8,origin+1.]),**kw)
        flags=not (got.arithmetic_verified or got.total_numerical_certified or cells.arithmetic_verified or cells.total_numerical_certified)
        results['end_to_end'].append({'inputs':pack(dict(ts=ts,states=states,matrix=matrix,powers=powers,coefficients=coeff,alpha=a,targets=targets)),
                                     'fractional_rhs':got.fractional_rhs.tolist(),
                                     'independent_rhs':[[mp.nstr(x,45) for x in row] for row in rhs],
                                     'max_abs_rhs_error':rhs_error,'max_abs_reconstruction_error':y_error,
                                     'all_source_knots_retained':all(t in cells.verification_times for t in ts),
                                     'flags_false':flags,'passed':rhs_error<2e-12 and y_error<2e-12 and flags})
    # Explicit rejection of known scaled-forcing underflow, and contraction
    # under/overflow; each sibling API must raise, not return a finite zero.
    arithmetic_cases=[
        ('scaled_forcing',np.array([0.,1.]),np.zeros((2,1)),dict(order=.5,matrix=np.zeros((1,1)),initial_state=np.array([0.]),power_exponents=np.array([1100.]),power_coefficients=np.array([[1e300]])), np.array([0.,.5,1.])),
        ('coefficient_underflow',np.array([0.,1e300]),np.full((2,1),1e-200),dict(order=.5,matrix=np.array([[1e-200]]),initial_state=np.array([1e-200])),np.array([0.,.5e300,1e300])),
        ('coefficient_overflow',np.array([0.,1.]),np.full((2,1),1e300),dict(order=.5,matrix=np.array([[1e300]]),initial_state=np.array([1e300])),np.array([0.,.5,1.])),
    ]
    for label,ts,states,kw,mesh in arithmetic_cases:
        for api in ['point','cells']:
            record={'case':label,'api':api,'inputs':pack(dict(ts=ts,states=states,kwargs=kw,mesh=mesh))}
            try:
                out=(m.affine_power_defect(ts,states,mesh,**kw) if api=='point' else m.affine_power_cells(ts,states,mesh,**kw))
                record['returned']=out.to_dict(); record['explicitly_rejected']=False
            except FloatingPointError as exc:
                record['exception']=str(exc);record['explicitly_rejected']=True
            results['arithmetic_rejections'].append(record)
    # Three edge families, isolated from ordinary-accuracy comparison results.
    edges=[('reconstruction_cancellation',np.array([-2.,-1.,1e-17]),np.array([[0.],[1e20],[0.]]),np.array([-2.,-1.,0.,1e-17]),.5,np.zeros((1,1)),0.),
           ('interpolation_intermediate_underflow',np.array([0.,1e300]),np.array([[0.],[1e-100]]),np.array([0.,5e299,1e300]),.5,np.zeros((1,1)),5e299),
           ('active_weight_complement_loss',np.array([-1.,1e-17]),np.array([[1e20],[0.]]),np.array([-1.,0.,1e-17]),1e-20,np.ones((1,1)),0.)]
    for label,ts,states,mesh,a,A,t in edges:
        kw=dict(order=a,matrix=A,initial_state=states[0])
        item={'case':label,'inputs':pack(dict(ts=ts,states=states,mesh=mesh,alpha=a,matrix=A,target=t))}
        try:
            point=m.affine_power_defect(ts,states,np.array([t]),**kw)
            cell=m.affine_power_cells(ts,states,mesh,**kw)
            y=independent_reconstruction(ts,states,t)
            rhs=[]
            for i in range(states.shape[1]):
                terms=[]
                for j,(l,r) in enumerate(zip(ts[:-1],ts[1:],strict=True)):
                    wl,wr=weight_reference(t,l,r,a)
                    terms.append(wl*mp.fsum(exact(A[i,k])*exact(states[j,k]) for k in range(states.shape[1])))
                    terms.append(wr*mp.fsum(exact(A[i,k])*exact(states[j+1,k]) for k in range(states.shape[1])))
                rhs.append(mp.fsum(terms))
            item.update({'point':point.to_dict(),'cells':cell.to_dict(),
                         'reference_y':[mp.nstr(x,80) for x in y],
                         'reference_rhs':[mp.nstr(x,80) for x in rhs],
                         'reference_defect':[mp.nstr(x-exact(z)-f,80) for x,z,f in zip(y,states[0],rhs,strict=True)],
                         'explicitly_rejected':False})
            if label=='active_weight_complement_loss':
                g=m._panel_weights(np.array([t]),ts[0],ts[1],a)
                ref=weight_reference(t,ts[0],ts[1],a)
                item['weight_computed']=[float(x[0]) for x in g]
                item['weight_reference']=[mp.nstr(x,80) for x in ref]
                item['left_weight_relative_error']=float(abs(exact(g[0][0])-ref[0])/ref[0])
        except FloatingPointError as exc:
            item['explicitly_rejected']=True;item['exception']=str(exc)
        results['blocking_edges'].append(item)
results['counts']={
    'weight_checks':len(results['weight_checks']),
    'weight_failed':sum(not x['passed'] for x in results['weight_checks']),
    'extrema_checks':len(results['extrema_checks']),
    'extrema_failed':sum(not x['passed'] for x in results['extrema_checks']),
    'end_to_end_checks':len(results['end_to_end']),
    'end_to_end_failed':sum(not x['passed'] for x in results['end_to_end']),
    'arithmetic_checks':len(results['arithmetic_rejections']),
    'arithmetic_not_rejected':sum(not x['explicitly_rejected'] for x in results['arithmetic_rejections']),
    'blocking_edge_cases':len(results['blocking_edges']),
}
(S/'independent-probes.json').write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
print(json.dumps(results['counts'],indent=2))
for item in results['blocking_edges']:
    print(item['case'],'rejected',item['explicitly_rejected'])
    if 'point' in item:
        print(' computed y/rhs',item['point']['reconstruction'],item['point']['fractional_rhs'])
        print(' reference y/rhs',item['reference_y'],item['reference_rhs'])
        print(' last cell',item['cells']['model_lower'][-1],item['cells']['model_upper'][-1])
        if 'weight_computed' in item:
            print(' weights',item['weight_computed'],item['weight_reference'])
