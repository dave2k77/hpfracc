"""Independent edge reconstructions; inputs are exact represented binary64."""
import importlib.util
import json
from pathlib import Path
import sys
import mpmath as mp
import numpy as np

S = Path(__file__).resolve().parent
R = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
sys.path.insert(0, str(R))
name = 'benchmarks.numerical._volterra_defect'
spec = importlib.util.spec_from_file_location(name, S/'pinned/benchmarks/numerical/_volterra_defect.py')
m = importlib.util.module_from_spec(spec)
sys.modules[name] = m
spec.loader.exec_module(m)

def exact(x):
    p,q = float(x).as_integer_ratio()
    return mp.mpf(p)/q

with mp.workdps(150):
    ts = np.array([-2., -1., 1e-17])
    states = np.array([[0.], [1e20], [0.]])
    targets = np.array([0.])
    kw = dict(order=.5, matrix=np.zeros((1,1)), initial_state=states[0])
    point = m.affine_power_defect(ts, states, targets, **kw)
    cells = m.affine_power_cells(ts, states, np.array([-2.,-1.,0.,1e-17]), **kw)
    expected = exact(states[1,0])*(exact(ts[2])-exact(targets[0]))/(exact(ts[2])-exact(ts[1]))
    result = {'ts_hex': [x.hex() for x in ts], 'states_hex': [[x.hex() for x in row] for row in states],
              'targets_hex': [x.hex() for x in targets], 'kwargs': {'order':.5,'matrix':[[0.]],'initial_state':[0.]},
              'expected_reconstruction_and_defect': mp.nstr(expected,100),
              'point': point.to_dict(), 'cells': cells.to_dict(),
              'last_cell_true_left_defect': mp.nstr(expected,100),
              'point_relative_error': mp.nstr(abs(exact(point.reconstruction[0,0])-expected)/abs(expected),30),
              'silent_zero': bool(point.defect[0,0] == 0 and cells.model_upper[-1,0] == 0)}
(S/'edge-reconstruction.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
