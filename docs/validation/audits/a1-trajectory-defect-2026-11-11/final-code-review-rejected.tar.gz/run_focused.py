"""Run only the 81 frozen focused cases, against the pinned diagnostic."""
import hashlib
import importlib.util
import json
import platform
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import jax
import mpmath
import numpy
import pytest
import scipy

S = Path(__file__).resolve().parent
R = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
sys.path.insert(0, str(R))
path = S/'pinned/benchmarks/numerical/_volterra_defect.py'
name = 'benchmarks.numerical._volterra_defect'
spec = importlib.util.spec_from_file_location(name, path)
mod = importlib.util.module_from_spec(spec)
sys.modules[name] = mod
spec.loader.exec_module(mod)
assert hashlib.sha256(path.read_bytes()).hexdigest() == 'fa8398b6a82b8b8937188697d5f92cd41d1f05aadf0bad1181a92c230fd849a1'
metadata = {'python': platform.python_version(), 'jax': jax.__version__, 'numpy': numpy.__version__,
            'scipy': scipy.__version__, 'mpmath': mpmath.__version__,
            'devices': [str(x) for x in jax.devices()], 'default_backend': jax.default_backend(),
            'initial_x64': jax.config.read('jax_enable_x64'), 'pinned_module': str(path)}
print(json.dumps(metadata, indent=2), flush=True)
assert jax.default_backend() == 'cpu'
assert not metadata['initial_x64']
xml = S/'focused.xml'
with (S/'focused.stdout').open('w') as out, (S/'focused.stderr').open('w') as err:
    import contextlib
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        rc = pytest.main([str(S/'pinned/tests/unit/test_volterra_defect.py'), '-q',
                          '-c', str(R/'pyproject.toml'), '-p', 'no:cacheprovider',
                          '--junitxml='+str(xml)])
root = ET.parse(xml).getroot()
suites = list(root.iter('testsuite'))
metadata['pytest_exit'] = int(rc)
metadata['junit'] = {k: sum(int(s.get(k, 0)) for s in suites) for k in ('tests','failures','errors','skipped')}
(S/'focused-result.json').write_text(json.dumps(metadata, indent=2)+'\n')
print(json.dumps(metadata['junit']), 'exit', rc, flush=True)
assert metadata['junit'] == {'tests': 81, 'failures': 0, 'errors': 0, 'skipped': 0}
raise SystemExit(rc)
