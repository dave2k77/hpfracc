"""Private host-only PL Volterra-defect diagnostics; never a certificate.

This benchmark module is not a solver, controller, public API or differentiable
numerical path. Ordinary NumPy/SciPy float64 evaluation is deliberately separate
from the working precision of the stored trajectory. Input, evaluation and output
roundoff are not enclosed. No result certifies a numerical solution.
"""

from dataclasses import dataclass, field

import numpy as np
import scipy
from scipy.special import gamma, hyp2f1, poch

from hpfracc.config import Provenance, RuntimeTarget


@dataclass(frozen=True, slots=True)
class DefectEvaluation:
    evaluation_times: np.ndarray
    reconstruction: np.ndarray
    fractional_rhs: np.ndarray
    defect: np.ndarray
    provenance: Provenance
    arithmetic_verified: bool = field(default=False, init=False)
    total_numerical_certified: bool = field(default=False, init=False)

    def to_dict(self):
        return {
            "evaluation_times": self.evaluation_times.tolist(),
            "reconstruction": self.reconstruction.tolist(),
            "fractional_rhs": self.fractional_rhs.tolist(),
            "defect": self.defect.tolist(),
            "provenance": self.provenance.to_dict(),
            "arithmetic_verified": self.arithmetic_verified,
            "total_numerical_certified": self.total_numerical_certified,
        }


def _real_array(name, value):
    raw = np.asarray(value)
    if (raw.dtype.kind != "f" or raw.dtype.itemsize not in (4, 8)
            or not np.all(np.isfinite(raw))):
        raise ValueError(f"Expected finite real float32/float64 {name}")
    return np.array(raw, dtype=np.float64, copy=True)


@dataclass(frozen=True, slots=True)
class _Inputs:
    ts: np.ndarray
    states: np.ndarray
    targets: np.ndarray
    order: float
    matrix: np.ndarray
    initial: np.ndarray
    powers: np.ndarray
    coefficients: np.ndarray
    input_dtype: str


def _prepare(ts, states, evaluation_times, order, matrix, initial_state,
             power_exponents, power_coefficients):
    input_dtype = str(np.asarray(states).dtype)
    ts = _real_array("ts", ts)
    states = _real_array("states", states)
    targets = _real_array("evaluation_times", evaluation_times)
    alpha = _real_array("order", order)
    matrix = _real_array("matrix", matrix)
    initial = _real_array("initial_state", initial_state)
    powers = _real_array("power_exponents", power_exponents)
    if alpha.ndim != 0 or not 0 < float(alpha) < 1:
        raise ValueError("Expected scalar 0 < order < 1")
    if ts.ndim != 1 or ts.size < 2 or not np.all(ts[1:] > ts[:-1]):
        raise ValueError("Expected at least two strictly increasing times")
    if states.ndim != 2 or states.shape[0] != ts.size or states.shape[1] < 1:
        raise ValueError("Expected states shape (time, state_dim), state_dim >= 1")
    d = states.shape[1]
    if matrix.shape != (d, d):
        raise ValueError("Expected square matrix matching state_dim")
    if initial.shape != (d,) or not np.array_equal(initial, states[0]):
        raise ValueError("Expected initial_state to match the first stored state")
    if (targets.ndim != 1 or targets.size == 0
            or np.any(targets < ts[0]) or np.any(targets > ts[-1])):
        raise ValueError("Expected evaluation times within the stored horizon")
    if powers.ndim != 1 or np.any(powers < 0):
        raise ValueError("Expected one-dimensional nonnegative power_exponents")
    if power_coefficients is None:
        coefficients = np.empty((0, d), dtype=np.float64)
    else:
        coefficients = _real_array("power_coefficients", power_coefficients)
    if coefficients.shape != (powers.size, d):
        raise ValueError("Expected power_coefficients shape (power, state_dim)")
    return _Inputs(ts, states, targets, float(alpha), matrix, initial,
                   powers, coefficients, input_dtype)


def _power_integral_ratio(beta, alpha):
    """Gamma(beta+1)/Gamma(beta+alpha+1), without subtracting large log-gammas."""
    return 1. / poch(beta + 1, alpha)


def _interpolate(ts, states, targets):
    return np.stack([np.interp(targets, ts, states[:, i])
                     for i in range(states.shape[1])], axis=-1)


def _panel_weights(targets, left, right, a):
    """Positive integrals of the two local PL basis functions.

    Small q uses a positive hypergeometric expression. Near the terminal use
    expm1/log1p instead: direct hyp2f1 loses accuracy there. Compute the old
    panel's remaining age independently, not as 1-q after q has rounded to one.
    """
    wl, wr = np.zeros_like(targets), np.zeros_like(targets)
    active = targets > left
    if not np.any(active):
        return wl, wr
    t = targets[active]
    width = right-left
    tau = t-left
    cut = np.minimum(tau, width)
    q = cut/tau
    mass = tau**a/gamma(a+1)
    cl, cr = np.empty_like(tau), np.empty_like(tau)
    within = t <= right
    cl[within] = mass[within]*a/(a+1)
    cr[within] = mass[within]/(a+1)
    small = ~within & (q < .5)
    factor = mass[small]*q[small]*a/2
    cl[small] = factor*hyp2f1(1-a, 1., 3., q[small])
    cr[small] = factor*hyp2f1(1-a, 2., 3., q[small])
    near = ~within & ~small
    z = (t[near]-right)/tau[near]
    logz = np.log(z)
    cl[near] = mass[near]/q[near]*(a/(a+1)
                                  + z*np.expm1(a*logz-np.log1p(a)))
    cr[near] = mass[near]/q[near]*(-np.expm1(a*logz)
                                  + a/(a+1)*np.expm1((a+1)*logz))
    fraction = cut/width
    wl[active] = cl + cr*(1-fraction)
    wr[active] = cr*fraction
    return wl, wr


def _panel_ranges(edges, left, right, a):
    """Exact-model extrema: old weights decrease; active left weight has a peak."""
    ll, rl = _panel_weights(edges[:-1], left, right, a)
    lu, ru = _panel_weights(edges[1:], left, right, a)
    lower = [np.minimum(ll, lu), np.minimum(rl, ru)]
    upper = [np.maximum(ll, lu), np.maximum(rl, ru)]
    peak = a*(right-left)
    tau_l, tau_u = np.maximum(edges[:-1]-left, 0), np.maximum(edges[1:]-left, 0)
    at_peak = (tau_l <= peak) & (peak <= tau_u)
    upper[0][at_peak] = np.maximum(
        upper[0][at_peak], peak**a/(gamma(a+1)*(a+1)),
    )
    return lower, upper


def affine_power_defect(ts, states, evaluation_times, *, order, matrix,
                        initial_state, power_exponents=(), power_coefficients=None):
    """Evaluate Y-y0-I**alpha(A Y + sum c_beta*(t-t0)**beta).

    State shape is (time, state_dim); all old knots and the original lower
    terminal are retained. Nonnegative powers include weak forcing with beta<1.
    Inputs must be finite real float32/float64 arrays/scalars. Evaluation widens
    represented inputs to float64 before RHS arithmetic; it is host-only and
    does not verify arithmetic or provide a continuous-solution error bound.
    Unsafe intermediate underflow raises even if a rearranged final expression
    would be representable; no zero contribution or certificate is substituted.
    """
    p = _prepare(ts, states, evaluation_times, order, matrix, initial_state,
                 power_exponents, power_coefficients)
    ts, states, targets, a = p.ts, p.states, p.targets, p.order
    with np.errstate(over="raise", invalid="raise", divide="raise", under="raise"):
        reconstruction = _interpolate(ts, states, targets)
        rhs = np.zeros_like(reconstruction)
        coefficients = states @ p.matrix.T
        for j, (left, right) in enumerate(zip(ts[:-1], ts[1:], strict=True)):
            if not np.any(coefficients[j:j+2]):
                continue
            wl, wr = _panel_weights(targets, left, right, a)
            rhs += wl[:, None]*coefficients[j] + wr[:, None]*coefficients[j+1]
        tau = targets - ts[0]
        factors = (tau[:, None] ** (a + p.powers)
                   * _power_integral_ratio(p.powers, a))
        rhs += factors @ p.coefficients
        defect = reconstruction - p.initial - rhs
    if not all(np.all(np.isfinite(x)) for x in (reconstruction, rhs, defect)):
        raise FloatingPointError("Nonfinite defect evaluation")
    provenance = Provenance(
        backend="numpy/scipy", runtime_target=RuntimeTarget.CPU,
        config={"scope": "private PL affine-power defect diagnostic",
                "arithmetic": "float64; traps underflow; unverified",
                "input_state_dtype": p.input_dtype, "order": a,
                "numpy_version": np.__version__, "scipy_version": scipy.__version__},
    )
    return DefectEvaluation(targets, reconstruction, rhs, defect, provenance)


@dataclass(frozen=True, slots=True)
class DefectCells:
    """Floating diagnostics of an enclosing real-arithmetic expression.

    These computed endpoints need not enclose even a single exact residual:
    gamma/power/coefficient/summation roundoff is not budgeted or directed.
    """

    verification_times: np.ndarray
    model_lower: np.ndarray
    model_upper: np.ndarray
    provenance: Provenance
    arithmetic_verified: bool = field(default=False, init=False)
    total_numerical_certified: bool = field(default=False, init=False)

    def to_dict(self):
        return {
            "verification_times": self.verification_times.tolist(),
            "model_lower": self.model_lower.tolist(),
            "model_upper": self.model_upper.tolist(),
            "provenance": self.provenance.to_dict(),
            "arithmetic_verified": self.arithmetic_verified,
            "total_numerical_certified": self.total_numerical_certified,
        }


def affine_power_cells(ts, states, verification_mesh, *, order, matrix,
                       initial_state, power_exponents=(), power_coefficients=None,
                       max_work=1_000_000):
    """Evaluate unverified natural-extension model ranges on continuum cells.

    The supplied mesh must cover the whole original horizon; all original knots
    are added. Old positive-basis weights decrease; the active left weight has
    an interior maximum at alpha times the panel width. Coefficient signs select
    their extrema. No sampled maximum is substituted. Unsafe intermediate
    underflow raises rather than silently erasing a finite contribution. The
    resulting floating endpoints are NOT verified numerical enclosures, and no
    feedback propagation or solution-error interpretation is provided here.
    max_work caps cell-term-component evaluations and fails explicitly; it is
    not a measured memory/runtime limit and never authorizes truncating history.
    """
    p = _prepare(ts, states, verification_mesh, order, matrix, initial_state,
                 power_exponents, power_coefficients)
    if (p.targets.size < 2 or not np.all(p.targets[1:] > p.targets[:-1])
            or p.targets[0] != p.ts[0] or p.targets[-1] != p.ts[-1]):
        raise ValueError("Expected increasing verification mesh covering the horizon")
    edges = np.union1d(p.ts, p.targets)
    if type(max_work) is not int or max_work <= 0:
        raise ValueError("Expected positive integer max_work")
    term_count = 3 + 2 * (p.ts.size - 2) + p.powers.size
    work = (edges.size - 1) * term_count * p.states.shape[1]
    if work > max_work:
        raise ValueError(f"Cell work budget exhausted: {work} > {max_work}")
    with np.errstate(over="raise", invalid="raise", divide="raise", under="raise"):
        curve = _interpolate(p.ts, p.states, edges)
        lower = np.minimum(curve[:-1], curve[1:]) - p.initial
        upper = np.maximum(curve[:-1], curve[1:]) - p.initial
        coefficients = p.states @ p.matrix.T
        for j, (left, right) in enumerate(zip(p.ts[:-1], p.ts[1:], strict=True)):
            if not np.any(coefficients[j:j+2]):
                continue
            lows, highs = _panel_ranges(edges, left, right, p.order)
            pair = (-coefficients[j], -coefficients[j+1])
            for lo, hi, coefficient in zip(lows, highs, pair, strict=True):
                x, y = lo[:, None]*coefficient, hi[:, None]*coefficient
                lower += np.minimum(x, y)
                upper += np.maximum(x, y)
        for beta, coefficient in zip(p.powers, p.coefficients, strict=True):
            signed = -coefficient*_power_integral_ratio(beta, p.order)
            left = (edges[:-1]-p.ts[0]) ** (p.order+beta)
            right = (edges[1:]-p.ts[0]) ** (p.order+beta)
            x, y = left[:, None]*signed, right[:, None]*signed
            lower += np.minimum(x, y)
            upper += np.maximum(x, y)
    if not np.all(np.isfinite(lower)) or not np.all(np.isfinite(upper)):
        raise FloatingPointError("Nonfinite cell-range evaluation")
    provenance = Provenance(
        backend="numpy/scipy", runtime_target=RuntimeTarget.CPU,
        config={"scope": "private PL affine-power cell diagnostic",
                "arithmetic": ("float64; traps underflow; unverified; "
                               "no outward rounding"),
                "range_method": ("positive panel-basis extrema and "
                                 "signed forcing powers"),
                "cell_term_components": work, "max_work": max_work,
                "input_state_dtype": p.input_dtype, "order": p.order,
                "numpy_version": np.__version__, "scipy_version": scipy.__version__},
    )
    return DefectCells(edges, lower, upper, provenance)
