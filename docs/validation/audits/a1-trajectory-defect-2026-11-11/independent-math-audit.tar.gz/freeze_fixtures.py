"""Freeze independent probe inputs before evaluating discriminators; scratch only."""
import hashlib
import json
from pathlib import Path

import mpmath as mp
import numpy as np

ROOT = Path(__file__).resolve().parent


def encode(x):
    if isinstance(x, (float, np.floating)):
        x = float(x)
        return {"hex": x.hex(), "decimal_display": repr(x)}
    if isinstance(x, dict):
        return {k: encode(v) for k, v in x.items()}
    if isinstance(x, (list, tuple, np.ndarray)):
        return [encode(v) for v in x]
    return x


with mp.workdps(100):
    # Same quadratic forcing, half order and corrected mesh as manifest-v2.
    # The candidate is PL through rounded exact-solution nodes, deliberately
    # not the archived PL-forcing-integral reconstruction.
    nodes = [0.0, 0.75, 1.0]
    nodal_states = [[float(2 * mp.mpf(t) ** mp.mpf("2.5") / mp.gamma(mp.mpf("3.5")))] for t in nodes]
    negative = {
        "id": "manifest_v2_quadratic_pl_exact_nodes",
        "source": "protocol/manifest-v2.json old_panel_mesh and manifest.json old_panel equation",
        "alpha": 0.5,
        "ts": nodes,
        "states": nodal_states,
        "initial_state": [0.0],
        "A": [[0.0]],
        "forcing": [{"beta": 2.0, "coefficient": [1.0]}],
        "probe_t": 0.375,
        "frozen_requirements": {
            "max_nodal_abs_defect_lt": 1e-15,
            "abs_interior_defect_gt": 0.01,
            "full_vs_newest_only_endpoint_difference_gt": 0.05,
            "full_vs_reset_endpoint_difference_gt": 0.01,
        },
    }
    simple = {
        "id": "translated_full_history",
        "alpha": 0.5,
        "ts": [2.0, 2.25, 2.75, 3.0],
        "states": [[1.0], [1.25], [0.875], [1.5]],
        "initial_state": [1.0],
        "A": [[0.25]],
        "forcing": [{"beta": 0.0, "coefficient": [0.125]}, {"beta": 1.0, "coefficient": [-0.5]}],
    }
    represented = {
        "id": "represented_nondyadic_origin_and_alpha",
        "alpha": 0.3,
        "ts": [0.3, 0.4, 0.65, 1.1],
        "states": [[0.2], [-0.15], [0.7], [0.1]],
        "initial_state": [0.2],
        "A": [[-0.2]],
        "forcing": [{"beta": 0.25, "coefficient": [0.7]}, {"beta": 3.0, "coefficient": [-0.15]}],
    }
    weak = {
        "id": "weak_beta_quarter",
        "alpha": 0.75,
        "ts": [0.0, 0.125, 0.75, 1.0],
        "states": [[0.0], [0.2], [0.35], [0.6]],
        "initial_state": [0.0],
        "A": [[-0.125]],
        "forcing": [{"beta": 0.25, "coefficient": [1.0]}],
    }
    cubic = {
        "id": "archived_cubic_represented_coefficients",
        "alpha": 0.5,
        "ts": [0.0, 0.5, 1.0],
        "states": [[0.0], [0.1], [float(1 / (3 * mp.gamma(mp.mpf("2.5"))))]],
        "initial_state": [0.0],
        "A": [[0.0]],
        "forcing": [{"beta": 2.0, "coefficient": [1.0]}, {"beta": 3.0, "coefficient": [-2.0 / 3.0]}],
    }
    S = np.array([1.0 / 1024, 1024.0])
    B = np.array([[-0.125, 0.125], [0.0625, -0.125]])
    A = S[:, None] * B / S[None, :]
    y0 = np.array([S[0], S[1] * 0.5])
    d1, d2 = np.array([S[0], 0.0]), np.array([0.0, S[1]])
    c1 = float(mp.gamma(mp.mpf("1.75")) / mp.gamma(mp.mpf("1.25")))
    c2 = float(mp.gamma(mp.mpf("2.75")) / mp.gamma(mp.mpf("2.25")))
    coupled_nodes = [0.0, 0.125, 0.5, 1.0]
    coupled_states = [[float(mp.mpf(float(S[0])) * (1 + mp.mpf(t) ** mp.mpf("0.75"))),
                       float(mp.mpf(float(S[1])) * (mp.mpf("0.5") + mp.mpf(t) ** mp.mpf("1.75")))]
                      for t in coupled_nodes]
    coupled = {
        "id": "manifest_mixed_scale_coupled",
        "alpha": 0.5,
        "ts": coupled_nodes,
        "states": coupled_states,
        "initial_state": y0,
        "A": A,
        "scales": S,
        "forcing": [
            {"beta": 0.0, "coefficient": -A @ y0},
            {"beta": 0.25, "coefficient": c1 * d1},
            {"beta": 0.75, "coefficient": -A @ d1},
            {"beta": 1.25, "coefficient": c2 * d2},
            {"beta": 1.75, "coefficient": -A @ d2},
        ],
        "note": "Manufactured coefficients and states rounded to f64 before freeze; interpreted at these represented values, not as exact gamma coefficients.",
    }
    fixtures = {"input_semantics": "Each float is the exact binary64 value in hex; all oracle conversions use as_integer_ratio.",
                "cases": [negative, simple, represented, weak, cubic, coupled],
                "preserved_bad_old_panel_fixture": {"mesh": [0.0, 0.5, 1.0], "claim": "total quadratic interpolation error exceeds newest curvature bound", "expected_claim_valid": False},
                "source_archive_sha256": "55c13478f42ef199e2a41fd0c37c097a1349498d8ed62e4d620a923219a721e6"}
    path = ROOT / "frozen-fixtures.json"
    path.write_text(json.dumps(encode(fixtures), indent=2) + "\n")
    print(json.dumps({"fixture_path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "case_count": len(fixtures["cases"])}))
