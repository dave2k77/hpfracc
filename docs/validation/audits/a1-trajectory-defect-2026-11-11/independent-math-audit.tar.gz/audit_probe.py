"""Independent scratch-only quadrature/finite-power audit; never a certificate.

Run from the repository: uv run --frozen --extra dev python -B <this file>
No production imports, repository writes, interval package or solver reference.
"""
import bisect
import copy
import hashlib
import json
import platform
from pathlib import Path

import mpmath as mp
import numpy as np
import scipy
from scipy.special import gamma

ROOT = Path(__file__).resolve().parent
FIXTURE_SHA = "63311bcecc3c31458df93b0c1079d0cec1d8cbc64ee1155abc07b028e9f9aaef"


def decode(x):
    if isinstance(x, dict) and "hex" in x:
        return float.fromhex(x["hex"])
    if isinstance(x, dict):
        return {k: decode(v) for k, v in x.items()}
    if isinstance(x, list):
        return [decode(v) for v in x]
    return x


def m(x):
    """Interpret binary64 exactly; never via its decimal display."""
    p, q = float(x).as_integer_ratio()
    return mp.mpf(p) / q


def fmt(x):
    return mp.nstr(x, 60)


def vecfmt(x):
    return [fmt(v) for v in x]


class Case:
    def __init__(self, raw):
        self.raw = raw
        self.ts = [m(x) for x in raw["ts"]]
        self.ys = [mp.matrix([m(v) for v in row]) for row in raw["states"]]
        self.y0 = mp.matrix([m(v) for v in raw["initial_state"]])
        self.A = mp.matrix([[m(v) for v in row] for row in raw["A"]])
        self.a = m(raw["alpha"])
        self.q = [(m(p["beta"]), mp.matrix([m(v) for v in p["coefficient"]])) for p in raw["forcing"]]
        self.n = len(self.y0)
        self.scales = mp.matrix([m(x) for x in raw.get("scales", [1.0] * self.n)])
        self.v = [(self.ys[j + 1] - self.ys[j]) / (self.ts[j + 1] - self.ts[j]) for j in range(len(self.ts) - 1)]
        self.jumps = [self.v[j] - self.v[j - 1] for j in range(1, len(self.v))]
        assert self.ys[0] == self.y0
        assert all(self.ts[j + 1] > self.ts[j] for j in range(len(self.ts) - 1))
        assert 0 < self.a < 1 and all(b >= 0 for b, _ in self.q)

    def norm(self, x):
        return max(abs(x[i]) / self.scales[i] for i in range(self.n))

    def Y(self, t):
        j = min(max(bisect.bisect_right(self.ts, t) - 1, 0), len(self.v) - 1)
        return self.ys[j] + self.v[j] * (t - self.ts[j])

    def Q(self, t):
        tau = max(t - self.ts[0], mp.mpf(0))
        return sum((c * tau**b for b, c in self.q), mp.zeros(self.n, 1))

    def rhs(self, t):
        return self.A * self.Y(t) + self.Q(t)

    def integral_panels(self, t, fun):
        # Independent panel integration, not integration of hinge expressions.
        # u=(t-s)^a cancels the singular kernel; source panels remain separate.
        out = []
        for left, right in zip(self.ts, self.ts[1:]):
            right = min(t, right)
            if right <= left:
                break
            ulo, uhi = (t - right)**self.a, (t - left)**self.a
            def s_of_u(u):
                return min(right, max(left, t - u**(1 / self.a)))
            out.append(mp.matrix([
                mp.quad(lambda u: fun(s_of_u(u))[i], [ulo, uhi]) / mp.gamma(self.a + 1)
                for i in range(self.n)
            ]))
        return out

    def analytic_IY(self, t):
        tau = t - self.ts[0]
        return (self.y0 * tau**self.a / mp.gamma(self.a + 1)
                + self.v[0] * tau**(self.a + 1) / mp.gamma(self.a + 2)
                + sum((J * max(t - tj, mp.mpf(0))**(self.a + 1) / mp.gamma(self.a + 2)
                       for tj, J in zip(self.ts[1:-1], self.jumps)), mp.zeros(self.n, 1)))

    def analytic_IQ(self, t):
        tau = t - self.ts[0]
        return sum((c * mp.gamma(b + 1) / mp.gamma(self.a + b + 1) * tau**(self.a + b)
                    for b, c in self.q), mp.zeros(self.n, 1))

    def residual(self, t):
        return self.Y(t) - self.y0 - self.A * self.analytic_IY(t) - self.analytic_IQ(t)

    def expansion(self):
        # Complete SIGNED expansion; all original slope jumps retained.
        t0, a = self.ts[0], self.a
        terms = [(t0, mp.mpf(1), self.v[0]),
                 (t0, a, -self.A * self.y0 / mp.gamma(a + 1)),
                 (t0, a + 1, -self.A * self.v[0] / mp.gamma(a + 2))]
        for tj, J in zip(self.ts[1:-1], self.jumps):
            terms += [(tj, mp.mpf(1), J), (tj, a + 1, -self.A * J / mp.gamma(a + 2))]
        for b, c in self.q:
            terms.append((t0, a + b, -c * mp.gamma(b + 1) / mp.gamma(a + b + 1)))
        return terms

    def interval(self, left, right):
        lo, hi = mp.zeros(self.n, 1), mp.zeros(self.n, 1)
        for source, p, c in self.expansion():
            pl, pr = max(left - source, mp.mpf(0))**p, max(right - source, mp.mpf(0))**p
            for i in range(self.n):
                x, y = c[i] * pl, c[i] * pr
                lo[i] += min(x, y)
                hi[i] += max(x, y)
        return lo, hi


def float_terms(raw):
    ts, ys, A = np.asarray(raw["ts"]), np.asarray(raw["states"]), np.asarray(raw["A"])
    a, t0 = raw["alpha"], ts[0]
    slopes = np.diff(ys, axis=0) / np.diff(ts)[:, None]
    terms = [(t0, 1.0, slopes[0]), (t0, a, -(A @ ys[0]) / gamma(a + 1)),
             (t0, a + 1, -(A @ slopes[0]) / gamma(a + 2))]
    for tj, J in zip(ts[1:-1], np.diff(slopes, axis=0)):
        terms += [(tj, 1.0, J), (tj, a + 1, -(A @ J) / gamma(a + 2))]
    for item in raw["forcing"]:
        b = item["beta"]
        terms.append((t0, a + b, -np.asarray(item["coefficient"]) * gamma(b + 1) / gamma(a + b + 1)))
    return terms


def float_interval(terms, left, right):
    lo, hi = np.zeros_like(terms[0][2]), np.zeros_like(terms[0][2])
    for source, p, c in terms:
        x, y = c * max(left - source, 0.0)**p, c * max(right - source, 0.0)**p
        lo += np.minimum(x, y)
        hi += np.maximum(x, y)
    return lo, hi


def run():
    fixture_path = ROOT / "frozen-fixtures.json"
    assert hashlib.sha256(fixture_path.read_bytes()).hexdigest() == FIXTURE_SHA
    fixtures = decode(json.loads(fixture_path.read_text()))
    result = {"status": "running", "precision_dps": 80, "arithmetic_verified": False,
              "total_numerical_certified": False, "fixture_sha256": FIXTURE_SHA,
              "versions": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__, "mpmath": mp.__version__},
              "cases": [], "limitations": "High precision, sampling and ordinary f64 intervals are diagnostics, not outward-rounded proof."}
    cell_records = []
    cases = [Case(raw) for raw in fixtures["cases"]]
    byid = {c.raw["id"]: c for c in cases}
    for c in cases:
        raw, max_quad, max_iY, max_float, max_expansion = c.raw, mp.mpf(0), mp.mpf(0), mp.mpf(0), mp.mpf(0)
        terms64 = float_terms(raw)
        targets = sorted(set(c.ts + [(left + right) / 2 for left, right in zip(c.ts, c.ts[1:])]))
        for t in targets:
            ipanels = c.integral_panels(t, c.rhs)
            direct = c.Y(t) - c.y0 - sum(ipanels, mp.zeros(c.n, 1))
            iy_direct = sum(c.integral_panels(t, c.Y), mp.zeros(c.n, 1))
            truth = c.residual(t)
            expanded = sum((coef * max(t - source, mp.mpf(0))**p for source, p, coef in c.expansion()), mp.zeros(c.n, 1))
            max_quad = max(max_quad, c.norm(truth - direct))
            max_iY = max(max_iY, c.norm(c.analytic_IY(t) - iy_direct))
            max_expansion = max(max_expansion, c.norm(truth - expanded))
            # f64 is evaluated at the same represented target as its oracle.
            tf = float(t)
            point64 = sum((coef * max(tf - source, 0.0)**p for source, p, coef in terms64), np.zeros(c.n))
            max_float = max(max_float, c.norm(mp.matrix([m(v) for v in point64]) - c.residual(m(tf))))
        assert max_quad < mp.mpf("1e-55"), (raw["id"], fmt(max_quad))
        assert max_iY < mp.mpf("1e-55")
        assert max_expansion < mp.mpf("1e-70")
        assert max_float < mp.mpf("2e-12")
        refinement = []
        for subdivisions in (1, 4, 16):
            max_bound, max_sample, max_f64_endpoint_error = mp.mpf(0), mp.mpf(0), mp.mpf(0)
            sample_count, violations64 = 0, 0
            for left0, right0 in zip(raw["ts"], raw["ts"][1:]):
                endpoints = np.linspace(left0, right0, subdivisions + 1)
                for lf, rf in zip(endpoints, endpoints[1:]):
                    left, right = m(lf), m(rf)
                    assert not any(left < knot < right for knot in c.ts)
                    lo, hi = c.interval(left, right)
                    l64, h64 = float_interval(terms64, lf, rf)
                    max_bound = max(max_bound, c.norm(mp.matrix([max(abs(lo[i]), abs(hi[i])) for i in range(c.n)])))
                    max_f64_endpoint_error = max(max_f64_endpoint_error, c.norm(mp.matrix([m(v) for v in l64]) - lo), c.norm(mp.matrix([m(v) for v in h64]) - hi))
                    for k in range(9):
                        t = left + (right - left) * k / 8
                        r = c.residual(t)
                        sample_count += 1
                        max_sample = max(max_sample, c.norm(r))
                        for i in range(c.n):
                            assert lo[i] - mp.mpf("1e-65") * c.scales[i] <= r[i] <= hi[i] + mp.mpf("1e-65") * c.scales[i]
                            if r[i] < m(l64[i]) - mp.mpf("2e-12") * c.scales[i] or r[i] > m(h64[i]) + mp.mpf("2e-12") * c.scales[i]:
                                violations64 += 1
                    cell_records.append({"case": raw["id"], "subdivisions": subdivisions, "left_hex": float(lf).hex(), "right_hex": float(rf).hex(),
                                         "mp_lower": vecfmt(lo), "mp_upper": vecfmt(hi), "f64_lower": l64.tolist(), "f64_upper": h64.tolist()})
            assert violations64 == 0
            refinement.append({"subdivisions_per_source_panel": subdivisions, "sample_evaluations": sample_count,
                               "natural_interval_max_scaled_abs": fmt(max_bound), "sampled_max_scaled_abs_not_certificate": fmt(max_sample),
                               "max_f64_interval_endpoint_scaled_error": fmt(max_f64_endpoint_error), "f64_sample_violations_with_2e_12_scaled_slack": violations64})
        assert all(mp.mpf(b["natural_interval_max_scaled_abs"]) <= mp.mpf(a["natural_interval_max_scaled_abs"]) + mp.mpf("1e-60") for a, b in zip(refinement, refinement[1:]))
        result["cases"].append({"id": raw["id"], "quadrature_target_count": len(targets), "max_scaled_defect_vs_panel_quadrature": fmt(max_quad),
                                "max_scaled_IY_vs_panel_quadrature": fmt(max_iY), "max_scaled_expansion_identity_error": fmt(max_expansion),
                                "max_scaled_f64_point_error": fmt(max_float), "refinement": refinement})

    # One fixture catches three concrete wrong algorithms, with fixed thresholds.
    neg = byid["manifest_v2_quadratic_pl_exact_nodes"]
    t, tk = neg.ts[-1], neg.ts[-2]
    full = neg.residual(t)[0]
    history = neg.integral_panels(t, neg.rhs)
    newest_only = neg.Y(t)[0] - neg.y0[0] - history[-1][0]
    reset = neg.Y(t)[0] - neg.Y(tk)[0] - history[-1][0]
    nodal = max(abs(neg.residual(x)[0]) for x in neg.ts)
    interior = abs(neg.residual(m(neg.raw["probe_t"]))[0])
    thresholds = neg.raw["frozen_requirements"]
    assert nodal < m(thresholds["max_nodal_abs_defect_lt"])
    assert interior > m(thresholds["abs_interior_defect_gt"])
    assert abs(full - newest_only) > m(thresholds["full_vs_newest_only_endpoint_difference_gt"])
    assert abs(full - reset) > m(thresholds["full_vs_reset_endpoint_difference_gt"])
    result["frozen_negative_control"] = {"id": neg.raw["id"], "max_nodal_abs_defect": fmt(nodal), "interior_abs_defect_at_0_375": fmt(interior),
        "full_endpoint_defect": fmt(full), "newest_only_endpoint_defect": fmt(newest_only), "reset_endpoint_defect": fmt(reset),
        "exact_old_rhs_integral": fmt(sum(p[0] for p in history[:-1])), "exact_new_rhs_integral": fmt(history[-1][0]),
        "all_four_frozen_discriminators_passed": True,
        "definitions": {"newest_only": "Y(T)-y0-I^[alpha] over newest source panel with original RHS clock",
                        "reset": "Y(T)-Y(tk)-I^[alpha] over newest source panel with original RHS clock",
                        "nodal_only": "max |r| at stored nodes only"}}

    # Preserve and independently reproduce the old nondiscriminating fixture.
    old_checks = []
    quad = byid["manifest_v2_quadratic_pl_exact_nodes"]
    for middle in (mp.mpf(1) / 2, mp.mpf(3) / 4):
        vals, bounds = [], []
        for left, right in [(mp.mpf(0), middle), (middle, mp.mpf(1))]:
            ulo, uhi = (1 - right)**quad.a, (1 - left)**quad.a
            def s(u):
                return min(right, max(left, 1 - u**(1 / quad.a)))
            err = mp.quad(lambda u: (s(u) - left) * (right - s(u)), [ulo, uhi]) / mp.gamma(quad.a + 1)
            vals.append(err)
            bounds.append((right - left)**2 / 4 * ((1 - left)**quad.a - (1 - right)**quad.a) / mp.gamma(quad.a + 1))
        old_checks.append({"middle": fmt(middle), "total_interpolation_error": fmt(sum(vals)), "old_exact_error": fmt(vals[0]), "new_exact_error": fmt(vals[-1]),
                           "newest_curvature_bound": fmt(bounds[-1]), "full_curvature_bound": fmt(sum(bounds)), "total_exceeds_newest_curvature_bound": bool(sum(vals) > bounds[-1])})
    assert old_checks[0]["total_exceeds_newest_curvature_bound"] is False
    assert old_checks[1]["total_exceeds_newest_curvature_bound"] is True
    result["preserved_old_panel_discriminator"] = old_checks

    # Translation by 2 is exact for these dyadic time values.
    original = byid["translated_full_history"]
    shifted_raw = copy.deepcopy(original.raw)
    shifted_raw["ts"] = [x - 2.0 for x in shifted_raw["ts"]]
    shifted = Case(shifted_raw)
    translation_error = max(original.norm(original.residual(t) - shifted.residual(t - 2)) for t in original.ts)
    T = original.ts[-1]
    wrong_IY = (original.y0 * T**original.a / mp.gamma(original.a + 1)
                + original.v[0] * T**(original.a + 1) / mp.gamma(original.a + 2)
                + sum((J * max(T - tj, 0)**(original.a + 1) / mp.gamma(original.a + 2)
                       for tj, J in zip(original.ts[1:-1], original.jumps)), mp.zeros(original.n, 1)))
    wrong_origin_error = original.norm(original.A * (wrong_IY - original.analytic_IY(T)))
    assert translation_error < mp.mpf("1e-70") and wrong_origin_error > mp.mpf("0.01")
    iy_panels = original.integral_panels(T, original.Y)
    old_iy = sum(iy_panels[:-1], mp.zeros(original.n, 1))
    assert original.norm(original.A * old_iy) > mp.mpf("0.01")
    result["origin_and_old_PL_history"] = {"exact_translation_scaled_error": fmt(translation_error), "wrong_untranslated_baseline_scaled_error": fmt(wrong_origin_error),
        "old_PL_fractional_integral": vecfmt(old_iy), "new_PL_fractional_integral": vecfmt(iy_panels[-1]),
        "omitted_old_PL_feedback_scaled_residual_difference": fmt(original.norm(original.A * old_iy))}

    coupled = byid["manifest_mixed_scale_coupled"]
    iy = coupled.analytic_IY(coupled.ts[-1])
    wrong_orientation = coupled.norm((coupled.A.T - coupled.A) * iy)
    scaled_L = max(sum(abs(coupled.A[i, j]) * coupled.scales[j] / coupled.scales[i] for j in range(coupled.n)) for i in range(coupled.n))
    assert wrong_orientation > 1 and scaled_L == mp.mpf("0.25")
    result["coupled_orientation_and_scales"] = {"correct_column_action": "A @ IY; for row-stored batches use IY_rows @ A.T", "wrong_transpose_scaled_residual_difference": fmt(wrong_orientation),
        "weighted_Linf": fmt(scaled_L), "unscaled_Linf": fmt(max(sum(abs(coupled.A[i, j]) for j in range(coupled.n)) for i in range(coupled.n)))}

    represented = byid["represented_nondyadic_origin_and_alpha"]
    a_represented = represented.a
    a_decimal = mp.mpf("0.3")
    result["represented_value_control"] = {"alpha_hex": represented.raw["alpha"].hex(), "alpha_exact_represented": fmt(a_represented),
        "represented_minus_decimal_alpha": fmt(a_represented - a_decimal),
        "represented_t0": fmt(represented.ts[0]),
        "point": "All comparisons used exact binary ratios, including forcing coefficients, stored states and non-dyadic node differences."}
    assert a_represented != a_decimal

    # The archived cubic identity uses rational -2/3; the frozen f64 problem does not.
    a = mp.mpf("0.5")
    C = 1 / (3 * mp.gamma(a + 2))
    exact = 2 / mp.gamma(a + 3) - 4 / mp.gamma(a + 4)
    rational_pair = (mp.mpf(1) / 4 - mp.mpf(2) / 3 * mp.mpf(1) / 8) - (1 - mp.mpf(2) / 3) / 2
    cubic = byid["archived_cubic_represented_coefficients"]
    represented_pair_rhs_mismatch = cubic.Q(mp.mpf("0.5"))[0] - cubic.Q(mp.mpf(1))[0] / 2
    assert abs(rational_pair) < mp.mpf("1e-70") and abs(C - exact) > mp.mpf("0.007")
    assert represented_pair_rhs_mismatch != 0
    result["cubic_cancellation"] = {"rational_exact_midpoint_chord_mismatch": fmt(rational_pair), "rational_abs_endpoint_error_despite_zero_pair": fmt(abs(C - exact)),
        "represented_coefficient_midpoint_chord_mismatch": fmt(represented_pair_rhs_mismatch), "note": "Rational design cancellation is exact; binary64 coefficient cancellation is only near-zero in the real-arithmetic model."}

    beta = mp.mpf("0.25")
    result["weak_quarter_power"] = [{"alpha": fmt(a), "true_PL_forcing_first_panel_integral_error": fmt(mp.gamma(beta + 1) / mp.gamma(a + beta + 1) - 1 / mp.gamma(a + 2)),
        "holder_integrated_majorant": fmt(1 / mp.gamma(a + 1)), "finite_global_C2_majorant_exists": False} for a in (mp.mpf("0.25"), mp.mpf("0.5"), mp.mpf("0.75"))]

    # An unverified point-range calculation cannot enclose a nonrepresented real.
    point64 = -1.0 / gamma(1.5)
    point_real = -1 / mp.gamma(mp.mpf("1.5"))
    result["unverified_arithmetic_counterexample"] = {"expression": "-1/Gamma(3/2) at t=1, Y=0, q=1, alpha=1/2", "f64_point_interval": [point64, point64],
        "real_value": fmt(point_real), "represented_f64_minus_real": fmt(m(point64) - point_real), "point_interval_contains_real": bool(m(point64) <= point_real <= m(point64)),
        "note": "This is an arithmetic counterexample at a point, not a positive-width verification-cell claim."}
    assert m(point64) != point_real
    result["status"] = "all_checks_passed"
    result["case_count"] = len(cases)
    result["cell_count"] = len(cell_records)
    result["quadrature_target_count"] = sum(row["quadrature_target_count"] for row in result["cases"])
    result["interval_sample_evaluations"] = sum(r["sample_evaluations"] for row in result["cases"] for r in row["refinement"])
    (ROOT / "cell-ranges.json").write_text(json.dumps(cell_records, indent=2) + "\n")
    (ROOT / "probe-results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    with mp.workdps(80):
        run()
