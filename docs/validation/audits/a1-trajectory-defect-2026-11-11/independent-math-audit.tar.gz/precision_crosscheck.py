"""Repeat independent panel quadrature at two precisions; scratch only."""
import hashlib
import json
from pathlib import Path

import mpmath as mp

from audit_probe import Case, FIXTURE_SHA, decode, fmt

ROOT = Path(__file__).resolve().parent
fixture = ROOT / "frozen-fixtures.json"
assert hashlib.sha256(fixture.read_bytes()).hexdigest() == FIXTURE_SHA
raw_cases = decode(json.loads(fixture.read_text()))["cases"]
all_results = {}
for precision in (80, 120):
    with mp.workdps(precision):
        rows = []
        for raw in raw_cases:
            c = Case(raw)
            t = (c.ts[-2] + c.ts[-1]) / 2
            ref = c.Y(t) - c.y0 - sum(c.integral_panels(t, c.rhs), mp.zeros(c.n, 1))
            err = c.norm(c.residual(t) - ref)
            assert err < mp.mpf(10)**(-precision + 15)
            rows.append({"id": raw["id"], "normalized_reference": [mp.nstr(ref[i] / c.scales[i], precision) for i in range(c.n)], "scaled_formula_error": fmt(err)})
        all_results[str(precision)] = rows
with mp.workdps(130):
    differences = []
    for old, new in zip(all_results["80"], all_results["120"]):
        assert old["id"] == new["id"]
        difference = max(abs(mp.mpf(x) - mp.mpf(y)) for x, y in zip(old["normalized_reference"], new["normalized_reference"]))
        assert difference < mp.mpf("1e-75")
        differences.append({"id": old["id"], "scaled_reference_80_vs_120_difference": fmt(difference)})
output = {"status": "all_checks_passed", "arithmetic_verified": False, "all_results": all_results, "precision_comparisons": differences}
(ROOT / "precision-crosscheck.json").write_text(json.dumps(output, indent=2) + "\n")
print(json.dumps({"status": output["status"], "precision_comparisons": differences}, indent=2))
