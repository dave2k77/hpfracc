"""Bounded independent math checks; not an interval/roundoff certificate."""
import json
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

mp.mp.dps = 80
ROOT = Path(__file__).parent
manifest = json.loads((ROOT/'manifest.json').read_text())
results = {'precision_dps': mp.mp.dps, 'checks': {}}
c = results['checks']
fmt = lambda x: mp.nstr(x, 55)

def mass(t, a, b, r):
    return (max(t-a,0)**r-max(t-b,0)**r)/mp.gamma(r+1)

def power_integral(beta, alpha, t=mp.mpf(1)):
    return mp.gamma(beta+1)/mp.gamma(beta+alpha+1)*t**(beta+alpha)

def quad_panel(t,a,b,alpha,f):
    # u=(t-s)^alpha removes the singular kernel exactly.
    ua,ub=(t-b)**alpha,(t-a)**alpha
    return mp.quad(lambda u:f(t-u**(1/alpha)),[ua,ub])/mp.gamma(alpha+1)

beta=mp.mpf(1)/4
weak=[]
for a in [mp.mpf(1)/4,mp.mpf(1)/2,mp.mpf(3)/4]:
    exact=power_integral(beta,a)
    coarse=1/mp.gamma(a+2)
    # s^beta is globally beta-Holder with constant 1 on nonnegative reals.
    bound=1/mp.gamma(a+1)
    direct=quad_panel(mp.mpf(1),mp.mpf(0),mp.mpf(1),a,lambda s:s**beta)
    weak.append({'alpha':fmt(a),'exact':fmt(exact),'coarse':fmt(coarse),
                 'error':fmt(exact-coarse),'holder_panel_bound':fmt(bound),
                 'quadrature_identity_residual':fmt(direct-exact),
                 'startup_sup_interpolation_remainder':fmt((1-beta)*beta**(beta/(1-beta)))})
    assert exact-coarse>0 and exact-coarse<bound
    assert abs(exact-direct)<mp.mpf('1e-65')
c['weak_startup']=weak

a=mp.mpf(1)/2
coarse=1/(3*mp.gamma(a+2))
exact=2/mp.gamma(a+3)-4/mp.gamma(a+4)
identity=a*(a-1)/(3*(a+2)*(a+3)*mp.gamma(a+2))
c['cubic']={'pair_difference':'0 exactly (node values 0,1/6,1/3)',
            'coarse':fmt(coarse),'exact':fmt(exact),'abs_error':fmt(abs(coarse-exact)),
            'identity_residual':fmt(coarse-exact-identity),
            'curvature_envelope_M2':fmt(mp.mpf(1)/(4*mp.gamma(a+1)))}
assert abs(coarse-exact-identity)<mp.mpf('1e-78')
# Exact polynomial numerator check: (a+2)(a+3)-6(a+3)+12=a(a-1).
assert [F(6)-F(18)+F(12), F(5)-F(6), F(1)]==[F(0),F(-1),F(1)]
c['cubic_symbolic_numerator']='(a+2)(a+3)-6(a+3)+12 = a^2-a; exact Fraction coefficients [0,-1,1]'

lam=mp.mpf(1)/4
kap=lam/mp.gamma(a+1)
truth=mp.exp(lam**2)*mp.erfc(-lam)
raw=kap
bound=raw/(1-kap)
c['feedback_constant_candidate']={'exact_y1':fmt(truth),'true_error':fmt(truth-1),
        'raw_volterra_defect_sup':fmt(raw),'kappa':fmt(kap),'contraction_enclosure':fmt(bound),
        'accept_atol_0_4':bool(bound<=mp.mpf('0.4')),'reject_atol_0_3':bool(bound>mp.mpf('0.3')),
        'false_accept_without_propagation_at_0_3':bool(raw<=mp.mpf('0.3'))}
assert raw<truth-1<bound<mp.mpf('.4') and bound>mp.mpf('.3')
# Independent Mittag-Leffler power series. Tail justified by the Volterra
# Neumann operator contraction, NOT by comparing two truncation lengths.
p=16
series=mp.fsum(lam**k/mp.gamma(k*a+1) for k in range(p+1))
tail=kap**(p+1)/(1-kap)
c['feedback_series_check']={'terms_0_through':p,'closed_minus_partial':fmt(truth-series),
        'operator_geometric_tail_upper':fmt(tail)}
assert 0<truth-series<tail
# One genuine PECE panel: predictor and corrected endpoint differ from a
# reconstruction formed from corrected-state RHS values.
predict=1+lam/mp.gamma(a+1)
y1=1+(a*lam+lam*predict)/mp.gamma(a+2)
g0,g1=lam,lam*y1
U1=1+g0/mp.gamma(a+1)+(g1-g0)/mp.gamma(a+2)
c['pece_reconstruction_mismatch']={'predicted':fmt(predict),'corrected':fmt(y1),
 'fractional_reconstruction_from_corrected_rhs':fmt(U1),'nonzero_stored_minus_reconstruction':fmt(y1-U1)}
assert abs(y1-U1)>mp.mpf('1e-5')

old=[]
for nodes in [[mp.mpf(0),mp.mpf('.5'),mp.mpf(1)],
              [mp.mpf(0),mp.mpf('.75'),mp.mpf(1)]]:
    errors=[]; envelopes=[]
    for left,right in zip(nodes,nodes[1:]):
        slope=left+right
        line=lambda s,left=left,slope=slope:left**2+slope*(s-left)
        errors.append(quad_panel(mp.mpf(1),left,right,a,lambda s:line(s)-s*s))
        envelopes.append((right-left)**2/4*mass(mp.mpf(1),left,right,a))
    item={'mesh':[fmt(t) for t in nodes],'true_error':fmt(sum(errors)),
          'exact_old_error':fmt(sum(errors[:-1])),'exact_new_error':fmt(errors[-1]),
          'newest_panel_envelope':fmt(envelopes[-1]),'full_history_envelope':fmt(sum(envelopes)),
          'true_error_exceeds_newest_envelope':bool(sum(errors)>envelopes[-1])}
    old.append(item)
    assert sum(errors)<=sum(envelopes) and sum(errors)>errors[-1]
c['old_panel']=old

S=mp.matrix([[mp.mpf(1)/1024,0],[0,1024]])
B=mp.matrix([[-mp.mpf(1)/8,mp.mpf(1)/8],[mp.mpf(1)/16,-mp.mpf(1)/8]])
A=S*B*S**-1
L=lambda mat:max(sum(abs(mat[i,j]) for j in range(2)) for i in range(2))
c['mixed_scale']={'A':[[fmt(A[i,j]) for j in range(2)] for i in range(2)],
                 'unscaled_Linf':fmt(L(A)),'scaled_Linf':fmt(L(S**-1*A*S)),
                 'scaled_kappa':fmt(L(B)/mp.gamma(a+1))}
assert L(B)==mp.mpf(1)/4
# Verify hinge representation integral against independently integrated PL data.
nodes=[mp.mpf(0),mp.mpf(1)/4,mp.mpf(1)]
vals=[mp.mpf(1),mp.mpf(5)/4,mp.mpf(3)/2]
v=[(vals[j+1]-vals[j])/(nodes[j+1]-nodes[j]) for j in range(2)]
t=mp.mpf(1)
hinge=(vals[0]*t**a/mp.gamma(a+1)+v[0]*t**(a+1)/mp.gamma(a+2)
       +(v[1]-v[0])*(t-nodes[1])**(a+1)/mp.gamma(a+2))
quad=sum(quad_panel(t,nodes[j],nodes[j+1],a,
         lambda s,j=j:vals[j]+v[j]*(s-nodes[j])) for j in range(2))
c['fractional_PL_hinge']={'analytic':fmt(hinge),'quadrature':fmt(quad),'residual':fmt(hinge-quad)}
assert abs(hinge-quad)<mp.mpf('1e-78')
# Exactly stored binary64 approximation differs from the exact affine-forcing result.
f64=float(1/mp.gamma(mp.mpf('1.5')))
c['roundoff_control']={'exact':fmt(1/mp.gamma(mp.mpf('1.5'))),
                      'binary64_error_even_if_formula_rounded_once':fmt(abs(mp.mpf(f64)-1/mp.gamma(mp.mpf('1.5')))),
                      'interpolation_envelope':'0'}
(ROOT/'check-output.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
