# Next A1 increment: private Volterra-defect oracle for weak forcing and affine feedback

**Design proposal, not implementation, A1 completion, API promotion or a total numerical certificate.**

Checkout read: `/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc`, HEAD `7a11d2d62546470119618a75d15640e69e940a8d`, with the owner's staged API-001 metadata/export increment present. No repository/index/dependency/configuration changes were made by this work. No GPU, numerical benchmark or full suite was run. All artifacts are in this scratch directory. Use `manifest-v2.json` together with `manifest.json`; the former records an explicitly preserved design-fixture correction.

## 1. Scope and first deliverable

Implement next, privately, an **offline certifier of a supplied continuous piecewise-linear trajectory**. It takes a scalar order, strictly increasing accepted nodes, stored states, initial value, fixed parameters, a forcing/RHS enclosure description, positive component scales, component tolerances and a verification budget. It does not choose a mesh, alter PECE updates, add public classes, claim derivatives, or change any default. Starting with supplied arrays separates the scientific proof from the adaptive controller and metadata repair.

The first supported scientific class should be

`D_C^a y(t) = A y(t) + q(t), y(t0)=y0, 0<a<1`,

with known constant real matrix A and finite analytic power forcing

`q(t0+tau) = sum_l c_l tau^(beta_l), beta_l >= 0`.

This includes weak forcing `tau^(1/4)` (not C2), cubic cancellation, actual self-feedback, coupled/mixed-scale states and manufactured exact solutions. All solver orders remain scalar. A is a state matrix, not a per-state fractional order. Initial history terminal is t0; no history compression or resetting is allowed. Parameters and explicit inputs/keys must define the same deterministic function throughout; stochastic forcing is excluded.

Smallest vertical tracer: a=1/2, A=1/4, q=0, y0=1 on [0,1], supplied candidate Y(t)=1. It has a genuine feedback loop and an analytic continuous reference. It proves why a Volterra defect needs propagation before any solver integration. Then use **one real PECE panel** for this equation to exercise the nonzero nodal reconstruction residual. This is deliberately smaller than implementing a general nonlinear adaptive controller.

## 2. Reconstruction: avoid silently losing the PECE algebraic defect

Set tau=t-t0 and nodes tau_j. For supplied states y_j, define slopes v_j=(y_(j+1)-y_j)/(tau_(j+1)-tau_j) and the unique continuous PL interpolant

`Y(t0+tau)=y0+v0*tau+sum_(j=1..N-1) (v_j-v_(j-1))*(tau-tau_j)_+`.

It passes through the stored states exactly in the real-arithmetic model. Define the fractional integral with the common scalar a and original terminal:

`I^a z(t)=1/Gamma(a) * integral_(t0)^t (t-s)^(a-1) z(s) ds`.

Then, exactly,

`I^a Y = y0*tau^a/Gamma(a+1) + v0*tau^(a+1)/Gamma(a+2)`
`          + sum_(j=1..N-1) (v_j-v_(j-1))*(tau-tau_j)_+^(a+1)/Gamma(a+2)`.

Also `I^a[c*tau^beta]=c*Gamma(beta+1)*tau^(a+beta)/Gamma(a+beta+1)`.

Use the **Volterra defect**

`r(t)=Y(t)-y0-I^a[f(.,Y(.))](t)`.

For the first affine/power scope this is a finite sum of explicit powers and hinges:

`r=Y-y0-A*I^a Y-sum_l c_l*Gamma(beta_l+1)/Gamma(a+beta_l+1)*tau^(a+beta_l)`.

No derivative of Y, fractional chain rule, sampled Jacobian or dense numerical solution appears. PL Y need not inherit the exact solution's fractional startup expansion; its startup mismatch is visible in r and must be bounded, not assumed absent.

**PECE trap.** Existing PECE corrects with f at the predictor, then stores f at the corrected state. Thus U=y0+I^a[PL f(t_j,y_j)] generally does NOT interpolate stored y_j. Either use Y above, or add the nodal discrepancy |y_j-U(t_j)| to an independently propagated U-error enclosure. Treating U as a nodal interpolant without that discrepancy is invalid. In the one-panel feedback check:

- predictor: 1.2820947917738781434740397257803863
- corrected stored endpoint: 1.3351464394711765887303343135712244
- U(1) using corrected-state RHS endpoints: 1.3451235018114636199352833126616518
- stored minus U: -0.0099770623402870312049489990904273753.

The proposed PL reconstruction includes this defect automatically.

## 3. Continuum defect enclosure, not defect sampling

Partition [t0,T] into verification cells, including every original knot. On every cell enclose **the complete function** r_i(t), returning d_(cell,i) >= sup_cell |r_i(t)|. In the finite-power class each factor (tau-c)_+^p has p>0 and a monotone, nonnegative range given by its endpoint powers. Multiply by its signed coefficient and perform interval addition/matrix multiplication. This natural interval extension is mathematically enclosing in exact arithmetic. Dependence/cancellation makes it conservative, but subdivision tightens the enclosure without changing Y. Preserve signed expressions while enclosing; do not replace the whole defect by a pointwise probe or term cancellation guessed from samples.

Special-function constants and input coefficients must themselves be enclosed if a **numerically rigorous** result is ever claimed. Ordinary float64 or high-precision mpmath endpoint evaluations do not supply outward-rounded powers/gamma and are not such a certificate. The first helper may return a clearly marked conditional/exact-arithmetic-model result plus unverified arithmetic diagnostics. It must never call that a total numerical guarantee.

### Weak-forcing protocol beyond finite powers

A private RHS-oracle contract may alternatively supply an independently justified interpolation remainder on each verification panel, not a global C2 assertion:

For q component i with Holder exponent 0<beta<=1 and proven H_(j,i),

`|q_i(s)-q_i(u)| <= H_(j,i)*|s-u|^beta` for ALL s,u in panel j.

For theta=(s-a_j)/h_j,

`|q_i(s)-L_j q_i(s)| <= H_(j,i)*h_j^beta * [(1-theta)*theta^beta + theta*(1-theta)^beta]`
`                          <= H_(j,i)*h_j^beta`.

Proof: subtract the endpoint interpolant, use its two nonnegative barycentric weights, then the Holder inequalities. No sampled derivative is used. For a smooth component one may retain the existing `M_(j,i)h_j^2/8` bound. Sum majorants for sums of components.

In particular q=tau^beta, 0<beta<1, has H=1 globally on tau>=0 because (x+h)^beta-x^beta<=h^beta. On the first panel its actual sup interpolation remainder is

`(1-beta)*beta^(beta/(1-beta))*h^beta`.

Its exact first-panel **integrated** interpolation error is

`[Gamma(beta+1)/Gamma(a+beta+1)-1/Gamma(a+2)]*h^(a+beta)`.

This has the known a+beta power, not a+2. Away from startup, a panel starting at tau_j>0 can use curvature `beta*(1-beta)*tau_j^(beta-2)`; the first panel cannot.

For a more general f(t,y)=F(y)+q(t), an analytic componentwise Lipschitz matrix M on a declared convex domain gives, since Y is PL,

`|F(Y(s))-L_j F(Y)(s)| <= 2*theta*(1-theta)*M*|y_(j+1)-y_j|`
`                              <= (1/2)*M*|y_(j+1)-y_j|`.

Add the weak-forcing remainder to obtain eta_j >= |f(s,Y(s))-G_j(s)|, where G_j is endpoint interpolation of the RHS along Y. This crude estimate is exact-arithmetic valid under the assumptions, not an efficient nonlinear implementation claim. For affine F it is identically zero and should not be replaced by the crude nonzero bound.

For this alternative route,

`|r(t)| <= |Y(t)-y0-I^a G(t)| + sum_j eta_j*P_a(t;a_j,b_j)`

where all original/verification panels are retained and

`P_r(t;a,b)=[(t-a)_+^r-(t-b)_+^r]/Gamma(r+1)`.

I^a G has the same finite hinge form as I^a Y. Enclose this entire expression over verification cells. More verification panels can evaluate f along the same fixed PL Y, so oracle tightening does not require changing the solver mesh. Bounds must cover the entire relevant parameter domain, including any perturbations used later for sensitivities.

## 4. Propagation theorem and retained history

Suppose a unique continuous Volterra solution exists, Y(t0)=y0, and for all relevant states

`|f(t,u)-f(t,v)| <= M*|u-v|`, M entrywise nonnegative.

For affine feedback M=|A| globally; no sampled-Jacobian assumption or bounded tube is required. With e=y-Y, positivity of the scalar Caputo kernel gives

`|e(t)| <= D(t) + M*I^a |e|(t)`, where D(t)=d_cell on each verification cell.

For positive fixed component scales s_i, let S=diag(s),

`L=||S^-1 M S||_infinity`, `kappa=L*(T-t0)^a/Gamma(a+1)`.

The first implementation must require **kappa<1**. In the weighted supremum norm K=M I^a has norm at most kappa, hence

`||e||_(S,infinity) <= dstar/(1-kappa)`,

`dstar=max_(cells,i) d_(cell,i)/s_i`.

For a sharper target-time envelope, retain p+1 Neumann terms:

`E_p(t)=sum_(k=0)^p M^k I^(k*a) D(t) + s * kappa^(p+1)*dstar/(1-kappa)`.

Here k=0 is D(t), not an integral. For k>=1,

`I^(k*a) D(t)=sum_j d_j * P_(k*a)(t;a_j,b_j)`.

Proof: iterate the nonnegative Volterra inequality and bound the remainder using the contraction estimate, or sum the nonnegative Neumann series. The semigroup applies to fractional **integrals** of integrable D, not indiscriminately to Caputo derivatives. M is constant; a time-varying/noncommuting matrix is not covered by this formula.

**Old panels:** every cell j with a_j<t contributes to each k>=1 propagation term, and every original PL hinge contributes to r. Split sums explicitly into old j and current j in diagnostics. Refining the newest trial cannot erase either old forcing/interpolation defect or its propagation. Never restart the kernel terminal at an accepted node. An old-history contribution can exhaust the remaining budget; an offline certifier must return `uncertified` rather than make the last panel small and falsely certify. A future controller may need rollback/history refinement, not just local step shrinkage.

For a nonlinear extension M must be justified over a convex state/time/parameter domain, not sampled. Y and the complete enclosure tube must remain strictly inside that domain; a first-exit argument plus a strict margin can then justify continued containment. Otherwise certification fails. Smoothness/local Lipschitz and a valid existence/continuation assumption are also needed. Do not compute M only along Y and assume the unknown exact trajectory stays there. This nonlinear extension is a theorem/protocol proposal, not an implemented claim.

If kappa>=1 the simple geometric-tail protocol is **inapplicable**, not proof of instability, inaccurate solver output or nonexistence. Larger-horizon/stiff scopes need independently validated resolvent/tail or slabwise propagation retaining all preceding history. No such scope is closed here. The entrywise absolute matrix may be very pessimistic even for dissipative feedback.

## 5. Componentwise tolerance and precision boundary

Return conditional accepted-node envelopes E_i(t_n), normalized with a **componentwise max**, never RMS. For physical component tolerances a_i>0,r_i>=0, certification requires for every i,n

`E_i(t_n) <= [a_i+r_i*|Y_i(t_n)|]/(1+r_i)`.

The triangle inequality |Y_i|<=|y_i|+E_i proves `E_i<=a_i+r_i*|y_i|`. If a known arithmetic/output discrepancy is also bounded, add it to E **before** this test. Fixed s_i are conditioning/units scales; they are not silently substituted for a_i. Under dimensionless coordinates z=S^-1 y use a_z,i=a_i/s_i and the same r_i, and transform both M and all error bounds. Scales must be positive/finite and may not be retuned from the unknown reference error.

A useful mixed-scale frozen fixture is s=(1/1024,1024), B=[[-1/8,1/8],[1/16,-1/8]], A=S B S^-1. Tool results:

`A=[[-0.125,0.00000011920928955078125],[65536,-0.125]]`;
`||A||inf=65536.125`, `||S^-1 |A| S||inf=0.25`;
for a=1/2,T=1, kappa=0.2820947917738781434740397257803863.

Take u=(1+tau^(a+1/4),1/2+tau^(a+5/4)), y=S u and q=D_C^a y-Ay. Exact monomial Caputo identities establish this manufactured solution; off-solution feedback and coupling remain nonzero. This checks scale transformation, not arbitrary stiffness.

**Not included by default:** input/coefficient rounding, gamma/power evaluation, moment cancellation, history accumulation, forcing-evaluation error, interval endpoint rounding, solver-output conversion and parameter representation. Even exact affine forcing has zero interpolation error and nonzero arithmetic error. The binary64 rounding-only check for 2/sqrt(pi) yields error 1.5335459613165880745599768128775e-17. High precision is diagnostic, not outward rounding. For rigorous certification of the actually stored trajectory one could treat stored floats as exact binary rationals, rigorously enclose r for the stated continuous RHS/order and propagate it; then solver roundoff is visible in that residual. That stronger claim additionally needs verified special functions, arithmetic, input/RHS semantics and output bounds. It is not delivered here.

Strong array alpha must be interpreted at its actual represented value; never relabel stored .3/.8 as exact decimals. The first frozen rational orders 1/4,1/2,3/4 avoid that ambiguity. Positive-bound narrowing alone, as in existing curvature configuration, does not make all later arithmetic outward rounded. If a nonrigorous implementation loses positivity, overflows or cannot resolve time/verification cells, it must report uncertified/nonfinite/resolution failure, not success. Zero interpolation envelope is not a zero total-error envelope.

## 6. Checked mathematics and RED fixtures

`checks.py` ran with `uv run --frozen --no-sync python -B`, mpmath 1.4.1 at 80 decimal digits, Python 3.13.13; SciPy 1.17.1 is present but not needed. SymPy is absent; no install was attempted. A Fraction polynomial calculation checked the cubic numerator exactly; mpmath checked fractional integrals by an independently transformed quadrature. With u=(t-s)^a, the singular-kernel panel integral becomes an ordinary integral divided by Gamma(a+1).

Exact weak-power identity check results (h=1,beta=1/4):

| a | true first-panel interpolation error | Holder envelope h^(a+beta)/Gamma(a+1) |
|---|---|---|
| 1/4 | 0.1401555510564988656592776706020401 | 1.1032626513208372574397821599532520 |
| 1/2 | 0.2339722616658712481728345171615431 | 1.1283791670955125738961589031215452 |
| 3/4 | 0.2846509044091814733525105671758036 | 1.0880652521310173081027812631344502 |

All three transformed-quadrature minus Gamma-formula outputs printed 0 at 80-digit working precision. The exact first-panel sup forcing remainder is 0.4724703937105774367877039777293356. These numerical agreements are not rigorous integration error certificates.

Cubic: exact Fraction numerator coefficients are [0,-1,1], establishing `(a+2)(a+3)-6(a+3)+12=a(a-1)`. At a=1/2 the zero pair difference coexists with error 0.0071643121720350004691819612896606043. Checked signed identity residual: -5.6829035787727e-82. Curvature bound M=2 yields conditional coarse envelope 0.2820947917738781434740397257803863, not zero.

Actual self-feedback tracer, Y=1:

`d=||r||inf=(1/4)/Gamma(3/2)=1/(2 sqrt(pi))`;
`kappa=d`, `E=d/(1-d)`.

Exact solution `y(t)=exp(t/16)*erfc(-sqrt(t)/4)` follows from the half-order Mittag-Leffler solution (also checked via its Volterra power series). At t=1:

- actual error: 0.35864237010472211521004201694898822;
- unpropagated defect d: 0.28209479177387814347403972578038629;
- propagated enclosure: 0.39294155905472337600646075864449597.

Thus the conditional bound certifies atol=2/5 and rejects 3/10. Omitting propagation would falsely accept 3/10 even though actual error exceeds it. The 0..16 power series differs from the closed form by 5.3152340363461769e-16; the independent operator-contraction tail upper bound is 6.3190101327074748e-10. Tail validity does not rely on two truncations agreeing.

Retained-history negative fixture `[0,3/4,1]`, quadratic forcing, a=1/2:

- exact total interpolation error 0.056418958354775628694807945156077259;
- old exact contribution 0.051717378491877659636907283059737487;
- new exact contribution 0.0047015798628979690579006620963397715;
- newest-panel curvature envelope 0.0088154622429336919835637414306370717;
- full-history envelope 0.088154622429336919835637414306370717.

**Preserved design issue:** the initially proposed `[0,1/2,1]` fixture does not make total error exceed the newest-panel *curvature envelope*: 0.04028568684851927 < 0.04986778505017908. It does exceed the exact newest-panel error. This was a bad discriminating fixture, not a theorem failure. Initial manifest/output are preserved, and `manifest-v2.json` freezes the corrected fixture for subsequent implementation. These were design checks, not completed scientific-acceptance evidence; no post-hoc completion pass is claimed.

The PL fractional-integral hinge formula was independently quadrature-checked for nodes (0,1/4,1), values (1,5/4,3/2): both give 1.55489693722390767543600842331034395, residual printed 0 at 80 digits.

**Actual RED run:** five intentional invalid-rule tests in `test_red_controls.py` failed by assertion in 0.12 s, exit 1; JUnit in `red-controls.xml`. They expose missing propagation, cubic pair cancellation, newest-panel-only history, a false finite C2 curvature bound for weak forcing, and omitted PECE reconstruction mismatch. They are NOT five failures newly found in production. They demonstrate non-vacuous negative controls before an oracle exists. `checks.py` independently passed all its positive identities/inequalities, exit 0.

## 7. Actionable private protocol and implementation gates

A private host/test prototype should consume one explicit immutable problem description and supplied node/state arrays, not add public SolverInfo fields now. Return a private structured record containing reconstruction kind, original terminal/order, scope and assumptions, raw per-cell defect intervals, d_i, M/s/L/kappa, p, old/current propagation contributions, tail bound, accepted-node E, conservative budgets, arithmetic-status tag, and certified/uncertified reason. Absence of an arithmetic certificate must remain explicit (`roundoff_included=False`, conditional exact-arithmetic-model bound). Do not duplicate API-001 export work.

Implement as vertical tests, not one large controller replacement:

1. Freeze manifest-v2 and a minimal adapter-independent contract test for the constant feedback tracer. Verify a proposed helper is missing before implementing it, then require its exact formula, .4/.3 classifications and nonzero propagation contribution. Existing scratch RED tests already prove the shortcuts fail, but do not pretend they are a test of an unimplemented helper.
2. Add PL reconstruction and the complete analytic affine/power residual. RED test the actual one-panel PECE nodal residual; verify the hinge formula against independent quadrature and exact monomial identities.
3. Add interval-over-cell residual enclosures. RED on between-node extrema/omitted knots and deliberately insufficient verification budgets; require enclosures rather than sampled maxima. The first real-arithmetic proof is independent of whether numerical intervals are verified.
4. Add all-history componentwise propagation and strict kappa guard. RED on omitted old-panel terms, too-short tail, matrix/scale mistakes and kappa>=1; compare scalar feedback against its closed analytic solution and analytic contraction bound, not a dense solver.
5. Add weak Holder panels and the cubic fixture. RED on falsely treating t^(1/4) as globally C2. Preserve the caller-assumption limitation: no software can verify an arbitrary supplied global bound from finite samples.
6. Only then test the frozen small CPU dtype/work/tolerance matrix, without rewriting the manifest or forcing every coarse trajectory to certify. Missing, duplicate, incomplete and nonfinite required rows must fail integrity; an honestly uncertified trajectory is not operational success. Keep raw errors and bound/budget ratios separate. The matrix in manifest.json is prospective and was not executed here.
7. JAX integration/controller changes are later independently reviewed increments. Before any new numerical path is claimed, add initial-state/parameter/alpha fixed-mesh finite differences, eager/JIT/dtype checks and explicit frozen-mesh gradient semantics. Certifier-bound derivatives need not be claimed. Do not infer a new integration path's differentiability from this host proof.

## 8. Remaining blockers (explicit)

- No private certifier or new controller has been implemented; the deliverable is a checked design and testable mathematical oracle target.
- No verified outward-rounded gamma/powers or complete arithmetic/evaluation budget exists here. The mpmath checks cannot certify working-precision total error.
- The first feedback scope is global affine plus weak analytic forcing and kappa<1; nonlinear/stiff regimes need proved tube bounds/continuation and sharper propagation, not sampled Jacobians or extrapolated accuracy claims.
- PL reconstruction may be conservative at fractional startup; defect verification work and tolerance certification are not yet measured. Smaller accepted mesh steps do not guarantee a smaller old-history envelope.
- General supplied-Holder or nonlinear bounds remain explicit caller/proof assumptions; a false bound can invalidate the result. No finite sampling can turn this into an unrestricted-forcing guarantee.
- Actual adaptive control with irrevocably retained old panels may require failure, rollback or refined history. Merely shrinking the newest panel cannot promise completion.
- No new CPU/CUDA matrix, gradients, performance, release sign-off, per-state solver-order decision or phase transition is implied.

## Source anchors read

- `AGENTS.md:23-27,74-107,112-124`: authority, priority, full history, scalar solver scope and scientific tests.
- `v0.1_engineering_contract.md:204-219,281-309,370-402`: method, diagnostics vs accuracy, restricted prescribed-C2 bound, validation/gradients.
- `docs/developer/phase-a-completion.md:35-56,108-113`: A1 weak forcing/feedback, old history, precision, reconstruction/defect/propagation requirements.
- `src/hpfracc/solvers/bounded_forcing.py:19-27,139-161,189-208,226-235,269-275`: wrapper is prescribed only, scalar restriction, full-history curvature envelope, conservative scale, no-roundoff scope.
- `src/hpfracc/solvers/predictor_corrector.py:624-666,697-719,735-771,918-943,966-978`: interval weights, predictor-endpoint correction vs stored corrected RHS, pair/subdivision indicators, retained coarse state, controller.
- `docs/validation/bounded-forcing.md:17-77,228-243`: conditional proof, old panels, scaling and excluded weak/feedback/roundoff scope.
- `docs/validation/adaptive-calibration.md:100-176`: exact quadratic failure and common-history cancellation.
- `docs/validation/adaptive-startup.md:46-125,162-211`: weak/autonomous startup and exact cubic blind spot.
- `docs/validation/adaptive-coupled.md:9-40,50-80`: manufactured coupled scales and existing non-calibration/gradient boundary.
- `tests/unit/test_bounded_forcing.py:37-87,90-157,160-211`: independent envelopes, cubic, scales, frozen-mesh checks and failures.
- `benchmarks/numerical/adaptive_startup.py:30-94`: independently derived powers and nonrigorous high-precision series boundary.
