"""Intentional RED mathematical shortcuts, NOT production regressions.

Each assertion is the tempting INVALID acceptance rule a new private oracle
must replace. All five must fail before implementing that oracle. No mocks,
solver reference or new public API is involved.
"""
import mpmath as mp
mp.mp.dps = 80

def test_unpropagated_defect_cannot_enclose_actual_self_feedback():
    a, lam = mp.mpf('0.5'), mp.mpf('0.25')
    actual = mp.exp(lam**2)*mp.erfc(-lam)-1
    invalid_bound = lam/mp.gamma(a+1)
    assert actual <= invalid_bound, 'Missing feedback propagation underbounds actual error'

def test_pair_rescaling_cannot_certify_cubic_blind_spot():
    a = mp.mpf('0.5')
    C = 1/(3*mp.gamma(a+2))
    exact = 2/mp.gamma(a+3)-4/mp.gamma(a+4)
    invalid_bound = mp.mpf(1000)*0  # every finite pair multiplier fails
    assert abs(C-exact) <= invalid_bound, 'Zero pair difference is not zero error'

def test_newest_panel_only_does_not_enclose_retained_history():
    a = mp.mpf('0.5')
    # PL interpolation of t^2 on [0,3/4,1]: 3s/4+(s-3/4)_+.
    numeric = (mp.mpf('0.75')+mp.mpf('0.25')**(a+1))/mp.gamma(a+2)
    exact = 2/mp.gamma(a+3)
    invalid_bound = mp.mpf('0.25')**2/4*mp.mpf('0.25')**a/mp.gamma(a+1)
    assert numeric-exact <= invalid_bound, 'Old panels are not erased by refining the newest panel'

def test_false_C2_majorant_does_not_extend_to_weak_startup():
    a, beta = mp.mpf('0.75'), mp.mpf('0.25')
    actual = mp.gamma(beta+1)/mp.gamma(a+beta+1)-1/mp.gamma(a+2)
    invalid_bound = 2/(8*mp.gamma(a+1))  # falsely supplied global curvature M=2
    assert actual <= invalid_bound, 't^(1/4) has no finite global C2 curvature bound'

def test_corrected_rhs_fractional_reconstruction_is_not_nodal_pece():
    a, lam = mp.mpf('0.5'), mp.mpf('0.25')
    predictor = 1+lam/mp.gamma(a+1)
    stored = 1+(a*lam+lam*predictor)/mp.gamma(a+2)
    reconstructed = 1+lam/mp.gamma(a+1)+lam*(stored-1)/mp.gamma(a+2)
    assert abs(stored-reconstructed) <= mp.mpf('1e-60'), 'PECE uses predictor endpoint RHS; include this defect explicitly'
