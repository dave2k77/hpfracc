# Independent audit: full-history PL/affine-power Volterra defect

## Verdict and scope

**No blocking mathematical error found in the proposed formula or exact-arithmetic natural-interval construction.** Ordinary NumPy/SciPy float64 outputs are **not verified enclosures**, even when the underlying interval expression is enclosing in real arithmetic. A fixed, positive-width-cell probe below actually under-encloses. This is consistent only with an explicitly unverified host diagnostic: `arithmetic_verified=False`, `total_numerical_certified=False`, no numerical certificate.

This audits the proposed mathematics, not the concurrently developed implementation. It does not clear any Phase A gate, decide per-state solver order, approve narrowing/Phase B, or establish controller, JAX, gradient, performance, nonlinear, or stiff-propagation support.

Repository read: `/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc`, HEAD `74d8f08c01179115c2752da5604a9cd85bba89bc`. Read `AGENTS.md`, the engineering contract, audit README, and safely extracted protocol members. All work products are outside the repository, in:

`/home/davianc/.hermes/cache/scratch/a1-independent-math-audit-su8_sfzz`

## 1. Formula and required assumptions

Let `t0 < ... < tN`, with finite real stored column states `yj`, scalar `0<a<1`, constant finite real `d x d` matrix `A`, and finite forcing list `q(t)=sum c_b (t-t0)^b`, `b>=0`. The initial state must equal the first stored state, not merely agree up to an arbitrary tolerance. The analysis is on `[t0,tN]`, not extrapolation. Constant forcing (`b=0`) has value `c_b` at the origin; its fractional integral still vanishes there.

Set `tau=t-t0`, `eta_j=(t-tj)_+`, `vj=(y(j+1)-yj)/(t(j+1)-tj)`, `Jj=vj-v(j-1)`. The unique continuous PL interpolant is

```
Y = y0 + v0*tau + sum_(j=1..N-1) Jj*eta_j.
```

Integrating each constant/linear/shifted-linear term against the original kernel `(t-s)^(a-1)/Gamma(a)` gives

```
I^a Y = y0*tau^a/Gamma(a+1)
      + v0*tau^(a+1)/Gamma(a+2)
      + sum Jj*eta_j^(a+1)/Gamma(a+2),
I^a q = sum c_b*Gamma(b+1)/Gamma(a+b+1)*tau^(a+b).
```

The shifted-linear identity follows by translating the integration variable to `tj` and using the beta integral. It retains the contribution of every preceding slope jump. There is no finite-C2 assumption at startup.

Since `A` is constant, integration commutes with **left** multiplication by `A`. Thus the complete signed defect is

```
r = v0*tau + sum Jj*eta_j
  - (A@y0)*tau^a/Gamma(a+1)
  - (A@v0)*tau^(a+1)/Gamma(a+2)
  - sum (A@Jj)*eta_j^(a+1)/Gamma(a+2)
  - sum c_b*Gamma(b+1)/Gamma(a+b+1)*tau^(a+b).
```

This equals `Y-y0-I^a(A@Y+q)`. For row-stored evaluation batches, the action is `IY_rows @ A.T`, not `IY_rows @ A`. A nonsymmetric coupled test discriminates these orientations. All origin powers use `t-t0`; all hinge powers use `t-tj`. Neither accepting a step nor subdividing a verification cell moves the lower terminal or resets the RHS clock. Direct integration uses the terminal kernel `(t-s)`, not an old panel's right endpoint.

The PL state curve is the supplied trajectory. It must not be replaced by `y0+I^a(PL of stored RHS)` while claiming nodal interpolation; PECE need not satisfy that alternative reconstruction's nodal equation. The current proposed formula includes whatever nodal Volterra mismatch the stored states actually have.

## 2. Cell algorithm: exact theorem versus computed numbers

Write the complete expression componentwise as a finite sum `sum_k c_ki*(t-sk)_+^pk`, with every `pk>0`. Preserve signs and every source term. On a verification cell `[l,u]`, the exact factor range is

```
Lk = (l-sk)_+^pk, Uk = (u-sk)_+^pk,
lo_i = sum_k min(c_ki*Lk, c_ki*Uk),
hi_i = sum_k max(c_ki*Lk, c_ki*Uk).
```

Then `r_i(t) in [lo_i,hi_i]` for all cell points and `d_i=max(abs(lo_i),abs(hi_i))` bounds `sup |r_i|`. This follows term by term from nonnegative monotone powers and interval addition, not from samples or an extremum search. Negative coefficients reverse endpoint ordering. Dependence and cancellation enlarge the result but do not invalidate it. Child intervals are contained in their parent's natural range in exact arithmetic; uniform refinement tends to the function because this is a finite sum of continuous positive powers on a compact interval. No global derivative bound is required, including when `a+b<1`.

Include every original knot in the verification partition, include both domain endpoints, and ensure no unverified gaps. A true clipped-positive-part extension remains mathematically valid even across a knot; splitting is nevertheless the specified protocol and prevents an active-set implementation from silently omitting an intervening hinge. Refinement changes verification only, not the supplied PL trajectory or old history. A sampled maximum cannot replace this range construction.

**The inclusion theorem assumes exact coefficients and exact enclosing factor/evaluation arithmetic.** Float64 slopes, jumps, matrix products, gamma ratios, powers, cancellation, sums and rounded endpoints do not establish those premises. Mpmath endpoint values are not outward-rounded proofs either. Treating input floats as exact binary rationals fixes input semantics, but does not make subsequently rounded coefficients exact. A single endpoint `nextafter` padding also supplies no general budget for all those errors.

A fixed example demonstrates actual ordinary-f64 under-enclosure: `Y=0`, `A=0`, `q=1`, `a=1/2`, on the nondegenerate cell

```
[0x1.fffffffffffffp-1, 0x1.0000000000000p+0].
```

The computed natural interval collapses to `[-1.1283791670955126,-1.1283791670955126]`. Its represented lower endpoint is **above** the true right-endpoint residual `-2/sqrt(pi)` by `1.5335459613165881e-17`. Therefore it misses a real residual value inside its own cell. `arithmetic-counterexample.json` records the exact input hex, high-precision reference and comparison. This is a blocker to any claim that the returned f64 arrays themselves are rigorous numerical enclosures, **not** a blocker to the explicitly unverified diagnostic proposed here.

Even a genuine defect enclosure is not itself a solution-error enclosure under feedback. Propagation needs a separate justified theorem (e.g. `|A|` and the stated strict weighted-contraction assumptions); the raw defect alone cannot certify solution error.

## 3. Independent executed checks

No production helper, production solver or archived check implementation was imported. `audit_probe.py` interpolates states directly, integrates `A@Y(s)+q(s)` **panel by panel**, and independently compares with the hinge/power expansion. It uses `u=(t-s)^a` to remove the endpoint kernel singularity. This quadrature is numerical, not validated integration. Input conversion uses `float.as_integer_ratio()` for time nodes, states, alpha, beta and coefficients.

Executed from the repository with the existing lock/environment:

```
uv run --frozen --extra dev python -B /home/davianc/.hermes/cache/scratch/a1-independent-math-audit-su8_sfzz/freeze_fixtures.py
uv run --frozen --extra dev python -B /home/davianc/.hermes/cache/scratch/a1-independent-math-audit-su8_sfzz/audit_probe.py
uv run --frozen --extra dev python -B /home/davianc/.hermes/cache/scratch/a1-independent-math-audit-su8_sfzz/precision_crosscheck.py
uv run --frozen --extra dev python -B /home/davianc/.hermes/cache/scratch/a1-independent-math-audit-su8_sfzz/arithmetic_counterexample.py
```

All exited 0. Environment: Python 3.13.13, NumPy 2.4.6, SciPy 1.17.1, mpmath 1.4.1. No install, lock update, GPU run or full repository suite was performed. The primary run used 80 decimal digits; six additional last-panel midpoint references were repeated at 120 digits.

- Six cases: corrected manifest-v2 quadratic mesh; translated nonmonotone PL feedback; non-dyadic represented origin/order; weak `b=1/4`; cubic forcing; nonsymmetric mixed-scale coupled feedback.
- 38 quadrature target points, checking both the total defect and `I^a Y` separately. Maximum scale-normalized discrepancies were `2.10844e-81` and `4.21688e-81` respectively.
- 336 verification cells over 1/4/16 subcells per original panel. 3,024 sampled residual evaluations corroborated the natural ranges; these samples are **not** what makes the exact construction enclosing. Ordinary-f64 comparisons used a declared `2e-12` component-scale slack, so their passing says nothing about outward rounding.
- Maximum scale-normalized f64 point discrepancy: `3.00383e-16`; maximum f64 interval-endpoint discrepancy against the high-precision expression: `1.25383e-15`.
- Maximum 80-versus-120-digit scale-normalized reference change: `3.72232e-81`. This agreement is not an arithmetic certificate.
- Exact dyadic origin translation gave zero observed change. An intentionally untranslated baseline changed the scaled residual by `0.9956495494`. Omitting old PL feedback changed it by `0.1506088404`.
- Mixed-scale case reused `S=(1/1024,1024)` and `A=S B S^-1`, `B=[[-1/8,1/8],[1/16,-1/8]]`. Weighted induced norm was `0.25`, unscaled norm `65536.125`; the wrong transpose changed the scale-normalized residual by `8.3799899708e10`.
- The mixed-scale manufactured gamma coefficients and sampled states were rounded **before freezing**. References used those represented coefficients, not an invented exactly manufactured floating problem.
- Binary64 `alpha=0.3` was interpreted as `0.299999999999999988897769753748434595763683319091796875`, not exact `3/10`. Non-dyadic time differences were likewise formed at high precision from represented endpoints.
- Weak-quarter startup: forcing interpolation-integral errors for orders `1/4,1/2,3/4` were `0.1401555511`, `0.2339722617`, `0.2846509044`; the exact-power formula needs no C2 premise. A finite global C2 bound for `t^(1/4)` would be false.
- Rational cubic `t^2-2t^3/3` has exact coarse/fine cancellation but endpoint error `0.007164312172035`. The represented `-2/3` coefficient has midpoint-chord mismatch `-1.3877787807814457e-17`, not mathematical exact cancellation. Both semantics are explicitly retained.

## 4. Frozen negative control and preserved failed proposal

`frozen-fixtures.json` was written before the audit/discriminator run and is hash-checked by each reference run:

`sha256=63311bcecc3c31458df93b0c1079d0cec1d8cbc64ee1155abc07b028e9f9aaef`.

One fixture reuses the corrected manifest-v2 half-order quadratic problem and mesh `[0,3/4,1]`. Its **candidate differs explicitly** from the archived PL-forcing integral: it is the PL trajectory through rounded exact-solution nodes `Y_j=round64(2*t_j^(5/2)/Gamma(7/2))`. Inputs are frozen in binary64 hex.

At its nodes, `max |r| = 2.15806e-17`; at `t=3/8`, `|r|=0.09475663115017564`. A nodal-only residual bound is therefore decisively false. At the endpoint:

| Formula | Residual |
|---|---:|
| Complete original-history defect | `2.14270e-17` |
| Newest-only integral, still subtracting original `y0` | `0.1245918663667962` |
| Restarted local defect, subtracting `Y(3/4)` | `-0.1685696407749557` |

The old forcing integral is `0.12459186636679618`; the newest is `0.47721035608414386`. All four predeclared discriminator thresholds passed. The history shortcuts are discriminated by disagreement with the correct residual; this fixture does **not** claim that both wrong history algorithms necessarily underbound an error budget.

The archived nondiscriminating `[0,1/2,1]` proposal is preserved, not erased or relabeled: total quadratic interpolation error `0.04028568684851927` is **below** newest-panel curvature envelope `0.04986778505017908`. The corrected `[0,3/4,1]` gives total `0.05641895835477563`, above newest envelope `0.008815462242933692` and below full envelope `0.08815462242933692`. Independent panelwise quadrature reproduces both outcomes. Original manifests, check output and all other extracted protocol members remain byte-identical to archive contents.

## 5. Artifacts, preservation and remaining limits

All paths below are under the scratch directory stated above:

- `MATH-AUDIT.md`: this report.
- `freeze_fixtures.py`, `frozen-fixtures.json`: deterministic fixture construction and frozen exact-representation inputs. Do not regenerate the fixture as part of a check.
- `audit_probe.py`, `probe-results.json`, `cell-ranges.json`: executable independent audit, measurements, and raw per-cell high-precision/f64 ranges.
- `precision_crosscheck.py`, `precision-crosscheck.json`: 80/120-digit independent panel references.
- `arithmetic_counterexample.py`, `arithmetic-counterexample.json`: fixed positive-width floating-under-enclosure example.
- `probe-run.*.txt`, `precision-run.*.txt`, `arithmetic-run.*.txt` and corresponding `*-exit-status.txt`: captured stdout/stderr and real zero exit statuses.
- `source-digests-before.json`, `source-integrity-after.json`, `aggregate-checks.json`: initial/final protected-source and index comparisons, extracted-member preservation checks and programmatic totals.
- `protocol/`: safely extracted original report, both manifests, checks, check output and negative-control evidence; not modified or rerun in place.

The source archive SHA-256 is `55c13478f42ef199e2a41fd0c37c097a1349498d8ed62e4d620a923219a721e6`. All existing audit source files and `.git/index` matched their initial hashes; `git diff --exit-code` returned 0. The end observation contained two concurrent untracked files, `benchmarks/numerical/_volterra_defect.py` and `tests/unit/test_volterra_defect.py`; neither was read, created, edited or assessed in this audit. No repository/index/archive changes, commit or push were made here.

Implementation risks still needing explicit handling: invalid/nonfinite inputs; time differences that overflow or collapse at working precision; incomplete/unsplittable verification partitions; overflow/underflow in coefficients and powers; gamma-ratio overflow for large finite beta; cancellation in slope jumps or matrix products; work-budget exhaustion; and any attempt to describe unverified f64 endpoints as guaranteed enclosures. A `gammaln`-based ratio can improve range but alone does not verify it. No large-beta/extreme-order/work-budget campaign was run. Samples and a small successful case matrix cannot establish arbitrary-input accuracy.

**Blocking errors:** none in the scoped exact mathematics. Verified endpoint arithmetic and complete evaluation/input/output budgets remain blocking prerequisites for a numerical-enclosure or total-error certificate. All broader acceptance gates remain open.
