"""A fixed positive-width-cell counterexample to ordinary f64 enclosure."""
import json
from pathlib import Path

import mpmath as mp
import numpy as np

from audit_probe import Case, float_interval, float_terms, fmt, m

ROOT = Path(__file__).resolve().parent
raw = {"id": "positive_width_rounding_under_enclosure", "alpha": 0.5,
       "ts": [0.0, 1.0], "states": [[0.0], [0.0]], "initial_state": [0.0],
       "A": [[0.0]], "forcing": [{"beta": 0.0, "coefficient": [1.0]}]}
left, right = float(np.nextafter(1.0, 0.0)), 1.0
with mp.workdps(100):
    c = Case(raw)
    lo, hi = float_interval(float_terms(raw), left, right)
    true_left, true_right = c.residual(m(left))[0], c.residual(m(right))[0]
    contains_right = bool(m(lo[0]) <= true_right <= m(hi[0]))
    assert left < right
    assert true_right < m(lo[0])
    assert contains_right is False
    output = {"status": "counterexample_reproduced", "arithmetic_verified": False,
              "total_numerical_certified": False, "cell_left_hex": left.hex(), "cell_right_hex": right.hex(),
              "f64_lower": float(lo[0]), "f64_upper": float(hi[0]), "real_lower": fmt(true_right), "real_upper": fmt(true_left),
              "lower_under_enclosure_gap": fmt(m(lo[0]) - true_right),
              "computed_interval_contains_real_right_endpoint": contains_right,
              "interpretation": "The exact natural extension encloses. Ordinary f64 interval addition/gamma/powers do not: even this nondegenerate one-term cell misses its right endpoint."}
(ROOT / "arithmetic-counterexample.json").write_text(json.dumps(output, indent=2) + "\n")
print(json.dumps(output, indent=2))
