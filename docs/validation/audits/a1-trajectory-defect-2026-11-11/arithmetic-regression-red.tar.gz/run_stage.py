"""Capture pre-run bytes, actual process exit and raw focused arithmetic evidence."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument("stage")
parser.add_argument("--compatibility", action="store_true")
args = parser.parse_args()
root = Path.cwd()
scratch = Path("/home/davianc/.hermes/cache/scratch/a1-arithmetic-20261111")
base = root / "docs/validation/audits/a1-trajectory-defect-2026-11-11"
paths = set(json.loads((base / "source-snapshot.json").read_text())["paths"])
paths.add("tests/unit/test_volterra_arithmetic.py")
selected = ["tests/unit/test_volterra_arithmetic.py"]
if args.compatibility:
    selected.insert(0, "tests/unit/test_volterra_defect.py")
def hashes():
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
            for name in sorted(paths)}
before = hashes()
record_path = scratch / (args.stage + "-before.json")
assert not record_path.exists(), "Use a new stage label; never overwrite evidence"
(scratch / (args.stage + "-test-source.py.txt")).write_bytes(
    (root / "tests/unit/test_volterra_arithmetic.py").read_bytes())
(scratch / (args.stage + "-implementation.py.txt")).write_bytes(
    (root / "benchmarks/numerical/_volterra_defect.py").read_bytes())
xml = scratch / (args.stage + ".xml")
command = ["uv", "run", "--frozen", "--extra", "dev", "python", "-m", "pytest",
           *selected, "-q", "-p", "no:cacheprovider", "--tb=short",
           "--junitxml=" + str(xml)]
metadata = {"stage": args.stage, "captured_at_utc": datetime.now(timezone.utc).isoformat(),
            "source_inputs": before, "source_count": len(before),
            "index_reference": subprocess.check_output(["git", "write-tree"],
                                                       text=True).strip(),
            "index_scope": "Reference only; new test may be unstaged. Exact input bytes above are authoritative.",
            "command": command, "selection": selected}
record_path.write_text(json.dumps(metadata, indent=2) + "\n")
env = dict(os.environ, JAX_PLATFORMS="cpu", PYTHONDONTWRITEBYTECODE="1",
           PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
           A1_OBSERVATIONS=str(scratch / (args.stage + "-observations.jsonl")))
with (scratch / (args.stage + ".stdout")).open("w") as out:
    with (scratch / (args.stage + ".stderr")).open("w") as err:
        completed = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=err)
after = hashes()
assert before == after, "Source changed during the process"
cases = list(ET.parse(xml).getroot().iter("testcase"))
counts = {"tests": len(cases),
          "failures": sum(case.find("failure") is not None for case in cases),
          "errors": sum(case.find("error") is not None for case in cases),
          "skipped": sum(case.find("skipped") is not None for case in cases)}
metadata.update(actual_exit_code=completed.returncode, counts=counts,
                post_run_source_unchanged=True,
                xml_sha256=hashlib.sha256(xml.read_bytes()).hexdigest())
(scratch / (args.stage + "-result.json")).write_text(json.dumps(metadata, indent=2)+"\n")
print(json.dumps({"stage": args.stage, "actual_exit_code": completed.returncode,
                  "counts": counts, "source_inputs_verified": len(before)}, indent=2))
sys.exit(completed.returncode)
