"""Read-only repository/evidence prefix audit; writes only this scratch directory."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess
import sys

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
CACHE = Path('/home/davianc/.hermes/cache/scratch/a1-arithmetic-20261111')
PIN = CACHE / 'artifact-audit-inputs'
OUT = CACHE / 'document-integrity-audit'
BASE = ROOT / 'docs/validation/audits/a1-trajectory-defect-2026-11-11'
OUT.mkdir(exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

manifest_raw = (PIN / 'manifest.json').read_bytes()
manifest = json.loads(manifest_raw)
assert len(manifest) == 10
pinned = {}
for name, row in manifest.items():
    raw = (PIN / name).read_bytes()
    live = (ROOT / name).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes'], name
    assert live == raw, name
    pinned[name] = dict(row, copy_matches=True, live_matches=True)
save('frozen-subset-check.json', {'manifest_sha256': sha(manifest_raw), 'count': len(pinned), 'files': pinned})

snapshot = json.loads((PIN / BASE.relative_to(ROOT) / 'source-snapshot.json').read_bytes())
source_paths = sorted(snapshot['paths'])
assert len(source_paths) == snapshot['count'] == 126
assert snapshot['source_tree'] == 'bf3d4fa06026f4f2efedcf9d899c75ebca53cdbd'
assert snapshot['paths']['benchmarks/numerical/_volterra_defect.py'] == '08d7f7fb8b9e6563d8a2d13c1567c0f90049a021f1a94e94c5cfd61f04d87eba'
source_start = {name: sha((ROOT / name).read_bytes()) for name in source_paths}
assert source_start == snapshot['paths']
index_start = git('ls-files', '-s', '--', *source_paths)
(OUT / 'source-index-before.txt').write_bytes(index_start)
(OUT / 'source-inputs-before.json').write_text(json.dumps(source_start, indent=2)+'\n')

tree_checks = {}
for name in source_paths:
    tree_raw = git('show', f"{snapshot['source_tree']}:{name}")
    assert sha(tree_raw) == snapshot['paths'][name], name
    tree_checks[name] = sha(tree_raw)
save('immutable-tree-source-binding.json', {'tree': snapshot['source_tree'], 'verified_inputs': len(tree_checks), 'paths': tree_checks})

scripts = {}
for name in ('full_evidence.py', 'prepare_artifact_audit.py'):
    raw = (CACHE / name).read_bytes()
    (OUT / (name + '.txt')).write_bytes(raw)
    scripts[str(CACHE / name)] = {'sha256': sha(raw), 'bytes': len(raw)}
save('cache-script-pins.json', scripts)

immutable_names = sorted(p.name for p in BASE.iterdir() if p.is_file() and (p.name.endswith('.tar.gz') or p.name in {'collection.txt','execution-plan.json','panel-basis.md','frozen-fixtures.json'}))
save('immutable-artifact-pins.json', {name: {'sha256': sha((BASE/name).read_bytes()), 'bytes': (BASE/name).stat().st_size} for name in immutable_names})

verify = (PIN / BASE.relative_to(ROOT) / 'verify.py').read_text()
parsed = ast.parse(verify)
boundaries = [node.lineno for node in parsed.body if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'runs' for t in node.targets)]
assert len(boundaries) == 1
boundary = boundaries[0]
lines = verify.splitlines(keepends=True)
prefix = ''.join(lines[:boundary-1])
assert 'executions.json' not in prefix
prefix += '''\nprint(json.dumps({"prefix_passed": True, "source_count": len(source), "tree": snapshot["source_tree"], "current_source_verified": args.current_source, "historical_protected_files": len(historical_checksums), "raw_source_review_files": len(code_review_index["files"]), "collection_selected": len(nodes), "unique_collection": len(set(nodes)), "full_results_tail_executed": False, "a1_acceptance_passed": False}, indent=2))\n'''
(OUT / 'verify-prefix.py').write_text(prefix)
result = subprocess.run(['uv','run','--frozen','python',str(OUT/'verify-prefix.py'),'--current-source'], cwd=ROOT, capture_output=True)
(OUT/'prefix.stdout').write_bytes(result.stdout)
(OUT/'prefix.stderr').write_bytes(result.stderr)
save('prefix-execution.json', {'command':['uv','run','--frozen','python',str(OUT/'verify-prefix.py'),'--current-source'], 'exit_code':result.returncode, 'original_verify_sha256':sha(verify.encode()), 'last_original_line':boundary-1, 'scratch_prefix_sha256':sha(prefix.encode()), 'full_results_tail_executed':False})
source_end = {name: sha((ROOT / name).read_bytes()) for name in source_paths}
assert source_end == source_start
assert git('ls-files','-s','--',*source_paths) == index_start
assert all((ROOT/name).read_bytes() == (PIN/name).read_bytes() for name in manifest)
print(json.dumps({'frozen_files':len(pinned), 'source_inputs':len(source_paths), 'immutable_tree_inputs_verified':len(tree_checks), 'source_and_index_unchanged':True, 'prefix_exit_code':result.returncode, 'prefix_stdout':result.stdout.decode(), 'prefix_stderr':result.stderr.decode()}, indent=2))
sys.exit(result.returncode)
