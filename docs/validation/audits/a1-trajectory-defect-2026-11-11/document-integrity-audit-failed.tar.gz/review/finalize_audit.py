"""Finish this audit's scratch proof and verify only stable allowed targets."""
from pathlib import Path
import difflib
import hashlib
import io
import json
import subprocess
import tarfile

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
CACHE=Path('/home/davianc/.hermes/cache/scratch/a1-arithmetic-20261111')
OUT=CACHE/'document-integrity-audit'
PIN=CACHE/'artifact-audit-inputs'
BASE=ROOT/'docs/validation/audits/a1-trajectory-defect-2026-11-11'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def save(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tf:
        return {m.name:tf.extractfile(m).read() for m in tf}
def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT)

historical=[]
pre=unpack((BASE/'pre-arithmetic-checkpoint.tar.gz').read_bytes())
for tree,raw,record in [
 ('6e7a156f025e08b31a314c5bda59183d6a96bf32',(BASE/'source-snapshot-before-gamma-repair.tar.gz').read_bytes(),json.loads((BASE/'source-snapshot-before-gamma-repair.json').read_bytes())),
 ('8dcbfafd1a5373088e75437551692a85fd7f7b77',(BASE/'source-snapshot-before-panel-repair.tar.gz').read_bytes(),json.loads((BASE/'source-snapshot-before-panel-repair.json').read_bytes())),
 ('92ff3dceb217f6097bae8ccde6cf159d8daa8d14',pre['source-snapshot.tar.gz'],json.loads(pre['source-snapshot.json'])),
]:
    files=unpack(raw)
    assert set(files)==set(record['paths']) and len(files)==record['count']==125
    for name,data in files.items():
        assert sha(data)==record['paths'][name]
        assert git('show',f'{tree}:{name}')==data,name
    historical.append({'tree':tree,'archive_sha256':sha(raw),'source_inputs_verified':len(files),'match_kind':'Byte equality to immutable tree; no invented collection-time index capture'})
save('immutable-historical-source-binding.json',historical)
contract=unpack((BASE/'arithmetic-contract-review.tar.gz').read_bytes())
draft=contract['reviewed-arithmetic-contract.md'].decode()
current=(BASE/'arithmetic-contract.md').read_text()
(OUT/'reviewed-to-current-contract.diff').write_text(''.join(difflib.unified_diff(draft.splitlines(keepends=True),current.splitlines(keepends=True),fromfile='reviewed-draft',tofile='pinned-current-contract')))

manifest=json.loads((PIN/'manifest.json').read_bytes())
snapshot=json.loads((BASE/'source-snapshot.json').read_bytes())
start=json.loads((OUT/'source-inputs-before.json').read_bytes())
assert {name:sha((ROOT/name).read_bytes()) for name in snapshot['paths']}==start==snapshot['paths']
assert git('ls-files','-s','--',*sorted(snapshot['paths']))==(OUT/'source-index-before.txt').read_bytes()
assert all(sha((ROOT/name).read_bytes())==row['sha256'] and sha((PIN/name).read_bytes())==row['sha256'] for name,row in manifest.items())
immutable=json.loads((OUT/'immutable-artifact-pins.json').read_bytes())
assert all(sha((BASE/name).read_bytes())==row['sha256'] for name,row in immutable.items())
cachepins=json.loads((OUT/'cache-script-pins.json').read_bytes())
assert all(sha(Path(name).read_bytes())==row['sha256'] for name,row in cachepins.items())
for name in ('freeze_source.py','preserve_baseline.py','preserve_source_review.py'):
    raw=(CACHE/name).read_bytes()
    (OUT/(name+'.txt')).write_bytes(raw)
    cachepins[str(CACHE/name)]={'sha256':sha(raw),'bytes':len(raw)}
save('cache-script-pins.json',cachepins)

frozen_hashes={name:row['sha256'] for name,row in manifest.items()}
extra_hashes={name:row['sha256'] for name,row in cachepins.items()}
extra_hashes[str(PIN/'manifest.json')]=sha((PIN/'manifest.json').read_bytes())
extra_hashes[str(BASE/'panel-basis.md')]=sha((BASE/'panel-basis.md').read_bytes())
final={'frozen_file_count':10,'all_frozen_copies_and_live_targets_match_manifest':True,'source_inputs_verified':126,'current_tree':snapshot['source_tree'],'source_and_index_unchanged':True,'all_pinned_immutable_artifacts_unchanged':True,'reviewed_cache_scripts_unchanged':True,'no_current_full_completion_files_read_or_verified':True,'full_record_verifier_tail_not_executed':True,'historical_snapshot_tree_field_absent_is_not_a_failure':'Historical tree binding was independently proved from archive bytes; no collection-time index claim made','a1_acceptance_passed':False}
save('final-invariants.json',final)

errors=[
 {'id':'DOC-01','location':'Frozen audit README.md:196-198','issue':'The current README still says "Current source is frozen separately at tree 92ff3dceb217f6097bae8ccde6cf159d8daa8d14". That is the rejected historical checkpoint, not the current reviewed bf3d4fa06026f4f2efedcf9d899c75ebca53cdbd candidate stated at lines 42-55 and in the frozen source snapshot.','required_action':'Qualify this paragraph as the historical panel-repair checkpoint; do not replace or approve its preserved failed verdict. Documentation/evidence correction only, not numerical repair.'},
 {'id':'EVID-01','location':'Cache full_evidence.py:54-75; frozen verify.py:314-334','issue':'Completion finalization does not bind readback xml_sha256/source_inputs_verified to current raw XML and the 126-input snapshot; verify.py never reads current CPU/CUDA readbacks. The copied real readback assertion predicates accept a synthetic record with an intentionally wrong XML hash and source_inputs_verified=0. Regenerated checksums would protect those stale fields without validating their meaning.','required_action':'Before claiming completed delivery, add a separate explicit readback-to-current-XML/source/exits/process-plan consistency check, or strengthen the completion scripts equivalently. This audit did not run the real finalizer or review any future full outcomes.'},
]
suggestions=[
 'Tracker lines 879-885 should cite pre-arithmetic-checkpoint.tar.gz::cpu-readback.json, ::cuda-readback.json and ::executions.json for the 981-case rejected-source outcomes; the root files are mutable completion targets. The historical bytes are intact and the 54-file replay passed.',
 'Earlier appended tracker pending/applying/classification-pending statements are historical steps; label them explicitly rather than leaving competing current-tense statuses. Keep the final scoped source pass and SCI-003 disclosure intact.',
 'Completion logic correctly refuses an absent unique exit record on both backends in copied-prefix negative controls. Continue requiring exact process session/PID completion independently; do not infer process exit from a JUnit summary.',
 'No scope or numerical changes are called for here. SCI-003 remains the already-adjudicated nonblocking conditioning limitation only under the range-checking contract; any new numerical fix or cancellation-robust redesign needs an owner decision.',
]
conditional_updates=[
 'Only after actual proc_41182075d0c0/PID 1002085 and proc_2ef2416891e4/PID 1002115 completion: replace full-cpu.xml/full-cuda.xml with their actual raw outputs; capture actual exit codes, including nonzero outcomes without relabeling them as passes.',
 'Generate fresh cpu-readback.json/cuda-readback.json, binding XML hash/counts/exact 1017 selected identities, all 126 input hashes, reviewed tree, backend, originating session/PID and unique exit record; supplement the missing cross-checks identified in EVID-01.',
 'Update executions.json, candidate-status.json and completion-only verification fields with actual status, process identity, counts/hashes/timestamps and explicit scope; preserve source review vs record integrity vs scientific acceptance as separate claims.',
 'After the complete evidence/doc set is frozen, regenerate current checksums.json, run the full record verifier with --current-source, and preserve its actual output/exit in verification.json. Do not regenerate the historical 54-file manifest or alter immutable review archives.',
 'Change only running/pending completion sentences/tables in README, tracker and Phase A ledger to accurately state actual completed outcomes and references; historical 964/981 results stay historical. DOC-01 and the mutable historical references additionally need the explicit documentation integrity corrections above.',
 'Never turn any successful completion readback into cancellation safety, exact-zero/small-residual acceptance, working-float enclosure, GPU diagnostic validation, A1/Phase A closure, relaxed tolerances, scope deferral or public API/runtime/lock/precision changes. All arithmetic/certification and A1 acceptance flags remain false.',
]
report={
 'passed':False,
 'logic_errors':errors,
 'suggestions':suggestions,
 'summary':'Frozen documentation and immutable evidence replay are intact, including 126 current input/tree bindings, 1017 selected identities, all three failed reviews, the historical 54-file manifest, 38 current raw review records and SCI-003 disclosures; delivery documentation/evidence integrity does not pass because of the stale current-source label and incomplete readback linkage. No numerical review was reopened and no future full-suite outcome was verified.',
 'evidence_paths':[str(OUT/name) for name in ('prefix-execution.json','prefix.stdout','frozen-subset-check.json','collection-plan-binding.json','immutable-tree-source-binding.json','immutable-historical-source-binding.json','historical-54-manifest-replay.json','review-and-failure-records.json','claim-scope-excerpts.json','completion-logic-review.json','readback-predicate-control.json','privacy-scan.json','privacy-scan-input-hashes.json','final-invariants.json','hash-index.json')],
 'reviewed_file_hashes':dict(frozen_hashes,**extra_hashes),
 'verified_scope':{'frozen_files':10,'current_source_inputs':126,'current_selected_tests':1017,'current_deselected_tests':1,'historical_protected_manifest_files':54,'current_raw_review_files':38,'privacy_text_records_scanned':json.loads((OUT/'privacy-scan.json').read_bytes())['text_records_scanned'],'privacy_findings':[],'numeric_source_review_reopened':False,'repository_or_index_or_document_or_code_edits':False,'full_suite_or_gpu_or_commit_or_push':False,'future_full_outcomes_verified':False},
 'conditional_completion_only_updates_after_findings_resolved':conditional_updates,
 'a1_acceptance_passed':False,
}
save('review.json',report)
paths=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name!='hash-index.json')
index={'scope':'This independent documentation/evidence audit scratch proof; excludes this index itself. Synthetic controls are explicitly labelled and are not candidate full-suite results.','count':len(paths),'files':{str(p.relative_to(OUT)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in paths}}
save('hash-index.json',index)
print(json.dumps({'passed':False,'logic_error_ids':[row['id'] for row in errors],'review_path':str(OUT/'review.json'),'review_sha256':sha((OUT/'review.json').read_bytes()),'hash_index_path':str(OUT/'hash-index.json'),'hash_index_sha256':sha((OUT/'hash-index.json').read_bytes()),'proof_files':len(paths),'proof_bytes':sum(p.stat().st_size for p in paths),'final_invariants':final},indent=2))
