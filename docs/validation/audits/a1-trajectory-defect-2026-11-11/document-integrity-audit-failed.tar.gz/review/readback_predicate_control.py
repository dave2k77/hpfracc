"""Static predicate negative control; never calls a finalizer or numerical code."""
from pathlib import Path
import ast
import json

OUT=Path('/home/davianc/.hermes/cache/scratch/a1-arithmetic-20261111/document-integrity-audit')
source=(OUT/'full_evidence.py.txt').read_text()
tree=ast.parse(source)
# Execute only existing readback assertion expressions, not I/O or finalization.
assertions=[]
for node in ast.walk(tree):
    if isinstance(node,ast.Assert) and 58<=node.lineno<=62:
        assertions.append(node)
assert len(assertions)==5
statements=ast.fix_missing_locations(ast.Module(body=sorted(assertions,key=lambda n:n.lineno),type_ignores=[]))
control={'source_tree':'CONTROL-TREE','exit_code':0,'exact_identities_verified':True,'source_mismatches':[], 'tests':1017,'counts':{'tests':1017,'failures':0,'errors':0,'skipped':0},'xml_sha256':'CONTROL-INCORRECT-HASH','source_inputs_verified':0}
# This deliberately invalid record is synthetic and is NOT a candidate result.
env={'record':control,'plan':{'source_tree':'CONTROL-TREE'},'expected':{'CONTROL-IDENTITIES':1017}}
exec(compile(statements,'<copied readback assertions only>','exec'),env)
report={'scope':'Synthetic static-predicate negative control, not actual full-suite evidence','original_file':'full_evidence.py','original_lines':[n.lineno for n in sorted(assertions,key=lambda n:n.lineno)],'executed_only_readback_assertions':True,'no_finalizer_or_verifier_tail_executed':True,'predicates_accepted_bad_xml_hash_and_zero_verified_inputs':True,'intentional_bad_fields':{'xml_sha256':'CONTROL-INCORRECT-HASH','source_inputs_verified':0},'conclusion':'Present finalization predicates do not validate those readback fields; they need a separate fresh readback-to-raw check.'}
(OUT/'readback-predicate-control.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
