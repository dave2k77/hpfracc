"""Inspect completion guards without running any repository finalizer/verifier tail."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
CACHE=Path('/home/davianc/.hermes/cache/scratch/a1-arithmetic-20261111')
OUT=CACHE/'document-integrity-audit'
BASE=ROOT/'docs/validation/audits/a1-trajectory-defect-2026-11-11'
source=(OUT/'full_evidence.py.txt').read_text()
tree=ast.parse(source)
marker='# Caller must independently check process_manage completion before finalization.'
assert marker in source
prefix=source.split(marker)[0]
sandbox=OUT/'pending-guard-sandbox'
base=sandbox/BASE.relative_to(ROOT)
base.mkdir(parents=True,exist_ok=True)
for name in ('source-snapshot.json','arithmetic-code-review.json','collection.txt'):
    (base/name).write_bytes((BASE/name).read_bytes())
plan=json.loads((BASE/'execution-plan.json').read_text())
for run in plan['full_runs']:
    missing=OUT/f"CONTROL-absent-{run['backend']}-exit.txt"
    assert not missing.exists()
    run['exit_record']=str(missing)
(base/'execution-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
script=OUT/'full_evidence-pending-prefix.py'
script.write_text(prefix)
checks=[]
for backend in ('cpu','cuda'):
    result=subprocess.run(['uv','run','--project',str(ROOT),'--frozen','python',str(script),backend],cwd=sandbox,capture_output=True)
    (OUT/f'pending-{backend}.stdout').write_bytes(result.stdout)
    (OUT/f'pending-{backend}.stderr').write_bytes(result.stderr)
    assert result.returncode!=0
    assert b'No actual completion record yet' in result.stderr
    assert not (base/f'{backend}-readback.json').exists()
    checks.append({'backend':backend,'exit_code':result.returncode,'failure_reason':'No actual completion record yet','no_readback_written':True,'scope':'Controlled absent-exit negative check, not an actual process result'})

# Static, not fabricated execution: enumerate field reads and assertion strings.
final_body=[node for node in tree.body if getattr(node,'lineno',0)>=54]
reads=[]
for top in final_body:
    for n in ast.walk(top):
        if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='record' and isinstance(n.slice,ast.Constant):
            reads.append(n.slice.value)
assert 'xml_sha256' not in reads
assert 'source_inputs_verified' not in reads
finalize_src=''.join(source.splitlines(keepends=True)[53:])
report={
 'scope':'Documentation/evidence logic only; no full verifier, real full_evidence action, full test suite, GPU or numerical probe executed',
 'missing_exit_controls':checks,
 'current_binding_verified':{'source_tree':plan['source_tree'],'source_count':plan['source_count'],'selected':plan['expected_selected_tests'],'review_matches_tree':True},
 'read_branch_guards':['actual unique exit record must exist','actual integer exit read, not guessed from XML','XML identities compared using Counter','all 126 live input hashes checked','failures/errors/skips and nonzero actual exit return nonzero'],
 'finalizer_readback_fields_used':sorted(set(reads)),
 'finalizer_manual_prerequisite':'Caller must independently confirm exact process_manage session/PID completion before finalization, as stated at line 54',
 'finalizer_gaps':['No readback xml_sha256 comparison against current XML at finalize time','No fresh live source hash comparison at finalize time','No source_inputs_verified == 126 assertion in finalizer; branch-generated source_mismatches is trusted','Readback has no originating session_id/pid/exit_record fields; finalizer copies these from plan'],
 'full_verifier_tail_static_guards':['requires two exited zero-exit backend records','compares exact current collection XML identity multisets and suite/case counts','replays current declared source hashes when --current-source supplied','verifies complete current checksum set'],
 'full_verifier_tail_gaps':['Does not compare cpu/cuda-readback xml_sha256/source_inputs_verified or bind readback to executions/plan, so stale/tampered readback fields can coexist with otherwise valid XML and regenerated checksums'],
 'no_future_outcomes_verified':True,
 'a1_acceptance_passed':False,
}
(OUT/'completion-logic-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'pending_exit_controls':checks,'static_finalizer_readback_fields':sorted(set(reads)),'full_record_verifier_run':False,'real_full_evidence_run':False},indent=2))
