"""Compact read-only proof: immutable records, archive content and privacy scan."""
from pathlib import Path
from collections import Counter
import ast
import gzip
import hashlib
import io
import json
import re
import tarfile
import xml.etree.ElementTree as ET

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
CACHE=Path('/home/davianc/.hermes/cache/scratch/a1-arithmetic-20261111')
OUT=CACHE/'document-integrity-audit'
BASE=ROOT/'docs/validation/audits/a1-trajectory-defect-2026-11-11'
PIN=CACHE/'artifact-audit-inputs'
sha=lambda raw: hashlib.sha256(raw).hexdigest()
save=lambda name,value:(OUT/name).write_text(json.dumps(value,indent=2)+'\n')

def archive(name):
    with tarfile.open(BASE/name,'r:gz') as tf:
        members=tf.getmembers()
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        assert len(members)==len({m.name for m in members})
        return {m.name:tf.extractfile(m).read() for m in members}

def counts(raw):
    cases=list(ET.fromstring(raw).iter('testcase'))
    return dict(tests=len(cases),failures=sum(c.find('failure') is not None for c in cases),errors=sum(c.find('error') is not None for c in cases),skipped=sum(c.find('skipped') is not None for c in cases))

plan=json.loads((BASE/'execution-plan.json').read_bytes())
snapshot=json.loads((BASE/'source-snapshot.json').read_bytes())
assert plan['source_tree']==snapshot['source_tree']
assert plan['source_count']==snapshot['count']==len(snapshot['paths'])==126
assert plan['expected_selected_tests']==1017
assert plan['a1_acceptance_passed'] is False
assert plan['current_source_completion_verified'] is False
nodes=[line for line in (BASE/'collection.txt').read_text().splitlines() if line.startswith('tests/') and '::' in line]
assert len(nodes)==len(set(nodes))==1017
assert '1017/1018 tests collected (1 deselected)' in (BASE/'collection.txt').read_text()
assert Counter(node.split('::')[0] for node in nodes)['tests/unit/test_volterra_arithmetic.py']==36
assert Counter(node.split('::')[0] for node in nodes)['tests/unit/test_volterra_defect.py']==81
expected_runs={'cpu':('proc_41182075d0c0',1002085,'arithmetic-final-exit-cpu.txt'),'cuda':('proc_2ef2416891e4',1002115,'arithmetic-final-exit-cuda.txt')}
assert len(plan['full_runs'])==2
for run in plan['full_runs']:
    identity=expected_runs[run['backend']]
    assert (run['session_id'],run['pid'],Path(run['exit_record']).name)==identity
save('collection-plan-binding.json',{'source_tree':plan['source_tree'],'source_count':126,'selected':len(nodes),'deselected':1,'focused_file_counts':dict(Counter(node.split('::')[0] for node in nodes) & Counter({'tests/unit/test_volterra_defect.py':81,'tests/unit/test_volterra_arithmetic.py':36})),'full_run_identities':plan['full_runs'],'no_completion_claim':True,'collection_sha256':sha((BASE/'collection.txt').read_bytes())})

pre=archive('pre-arithmetic-checkpoint.tar.gz')
layout=json.loads((BASE/'pre-arithmetic-layout.json').read_bytes())
assert sha((BASE/'pre-arithmetic-checkpoint.tar.gz').read_bytes())==layout['archive_sha256']
oldmanifest=json.loads(pre['checksums.json'])
assert len(oldmanifest)==len(layout['historical_manifest_layout'])==54
assert set(oldmanifest)==set(layout['historical_manifest_layout'])
resolved={}
for name,digest in oldmanifest.items():
    row=layout['historical_manifest_layout'][name]
    assert row['sha256']==digest
    loc=row['location']
    if '::' in loc:
        arc,member=loc.split('::',1)
        assert arc=='pre-arithmetic-checkpoint.tar.gz'
        raw=pre[member]
    else:
        assert not Path(loc).is_absolute() and '..' not in Path(loc).parts
        raw=(BASE/loc).read_bytes()
    assert sha(raw)==digest
    resolved[name]={'location':loc,'sha256':digest,'verified':True}
assert sha((BASE/'panel-basis.md').read_bytes())==oldmanifest['panel-basis.md']
assert '1-f' in (BASE/'panel-basis.md').read_text()
oldrecord=json.loads(pre['source-snapshot.json'])
assert layout['rejected_tree']=='92ff3dceb217f6097bae8ccde6cf159d8daa8d14'
assert oldrecord['count']==125
historical={}
for backend in ('cpu','cuda'):
    oldraw=pre[f'full-{backend}.xml']
    oldread=json.loads(pre[f'{backend}-readback.json'])
    historical[backend]={'counts':counts(oldraw),'xml_sha256':sha(oldraw),'readback':oldread}
    assert counts(oldraw)==dict(tests=981,failures=0,errors=0,skipped=0)
save('historical-54-manifest-replay.json',{'verified':54,'archive_sha256':layout['archive_sha256'],'historical_source_tree':layout['rejected_tree'],'historical_source_count':125,'panel_basis_unchanged':True,'files':resolved,'old_981_results_are_historical_only':True,'historical_full_xml':historical})

reviews={}
for filename in ('initial-review.json','gamma-review-failed.json','final-code-review-rejected.json','arithmetic-contract-review.json','arithmetic-code-review.json'):
    rec=json.loads((BASE/filename).read_bytes())
    reviews[filename]=rec
assert all(reviews[name]['passed'] is False for name in ('initial-review.json','gamma-review-failed.json','final-code-review-rejected.json'))
assert reviews['arithmetic-contract-review.json']['passed'] is True
assert reviews['arithmetic-contract-review.json']['source_artifact_approved'] is False
assert reviews['arithmetic-code-review.json']['passed'] is True
assert reviews['arithmetic-code-review.json']['a1_acceptance_passed'] is False
rawreview=archive('arithmetic-code-review.tar.gz')
idx=json.loads(rawreview['hash-index.json'])
assert len(idx['files'])==idx['count']==38
for name,row in idx['files'].items():
    assert sha(rawreview[name])==row['sha256'] and len(rawreview[name])==row['bytes']
probe=json.loads(rawreview['conditioning-probe.json'])
reviews['conditioning-probe.json']=probe
reviews['raw_review_files_verified']=len(idx['files'])
red=archive('arithmetic-regression-red.tar.gz')
green=archive('arithmetic-repair-green.tar.gz')
reviews['parent_red_counts']=counts(red['red.xml'])
reviews['parent_green_counts']=counts(green['green.xml'])
assert reviews['parent_red_counts']==dict(tests=36,failures=13,errors=0,skipped=0)
assert reviews['parent_green_counts']==dict(tests=117,failures=0,errors=0,skipped=0)
reviews['six_blocker_parent_counts']=counts(gzip.decompress((BASE/'final-blocking-parent.xml.gz').read_bytes()))
assert reviews['six_blocker_parent_counts']==dict(tests=6,failures=6,errors=0,skipped=0)
reviews['superseded_runs.json']=json.loads((BASE/'superseded-runs.json').read_bytes())
save('review-and-failure-records.json',reviews)

patterns={
 'telegram_bot_token':re.compile(r'(?<![\w])\d{6,12}:[A-Za-z0-9_-]{30,}'),
 'github_token':re.compile(r'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})'),
 'aws_access_key':re.compile(r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),
 'private_key':re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
 'telegram_personal_id':re.compile(r'(?i)(?:chat_id|telegram_(?:user|chat|recipient)_?id|telegram.{0,20}recipient)[\s"\']*[:=][\s"\']*-?\d{5,}'),
 'telegram_personal_url':re.compile(r'(?i)(?:t\.me/[A-Za-z0-9_]+|tg://(?:user|resolve)\?)'),
 'credential_assignment':re.compile(r'''(?i)(?:api_key|secret|password|passwd|access_token|bot_token)\s*["']?\s*[:=]\s*["'](?!\$|<|None|placeholder)[A-Za-z0-9_./+:-]{8,}["']'''),
}
findings=[]
scanned={}
text_count=0
bytes_count=0

def scan(label,raw,depth=0):
    global text_count,bytes_count
    assert depth<=6
    scanned[label]={'sha256':sha(raw),'bytes':len(raw)}
    if label.endswith(('.tar.gz','.tgz')):
        with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tf:
            for m in tf:
                assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
                scan(label+'::'+m.name,tf.extractfile(m).read(),depth+1)
        return
    if label.endswith('.gz'):
        scan(label[:-3]+'::decompressed',gzip.decompress(raw),depth+1)
        return
    try: text=raw.decode('utf-8')
    except UnicodeDecodeError: return
    text_count+=1
    bytes_count+=len(raw)
    for name,patt in patterns.items():
        for match in patt.finditer(text):
            findings.append({'path':label,'pattern':name,'line':text.count('\n',0,match.start())+1,'matched_value_redacted':True})

for name in json.loads((PIN/'manifest.json').read_bytes()):
    scan('frozen10/'+name,(PIN/name).read_bytes())
mutable={'checksums.json','verification.json','full-cpu.xml','full-cuda.xml','cpu-readback.json','cuda-readback.json','executions.json','candidate-status.json'}
for path in sorted(BASE.iterdir()):
    if path.is_file() and path.name not in mutable:
        scan('artifact/'+path.name,path.read_bytes())
save('privacy-scan.json',{'scope':'Frozen ten files and non-completion bundle records, recursively including archived raw evidence and source snapshots; parent-mutable completion records and unrelated messaging receipts excluded','text_records_scanned':text_count,'text_bytes_scanned':bytes_count,'record_count_including_containers':len(scanned),'patterns':{name:p.pattern for name,p in patterns.items()},'findings':findings})
save('privacy-scan-input-hashes.json',scanned)

excerpts={}
for name,ranges in {
 'docs/validation/audits/a1-trajectory-defect-2026-11-11/README.md':[(3,15),(42,72),(84,88),(191,205)],
 'docs/developer/bug-resolution-tracker.md':[(832,839),(873,885),(916,953),(955,989)],
 'docs/developer/phase-a-completion.md':[(140,187)],
 'CHANGELOG.md':[(3,11)],
}.items():
    lines=(PIN/name).read_text().splitlines()
    excerpts[name]=[{'start_line':lo,'end_line':hi,'text':'\n'.join(f'{i+1}: {lines[i]}' for i in range(lo-1,hi))} for lo,hi in ranges]
save('claim-scope-excerpts.json',excerpts)
print(json.dumps({'collection':len(nodes),'source_inputs':126,'historical_files_verified':54,'review_files_verified':38,'privacy_text_records_scanned':text_count,'privacy_findings':findings,'raw_proof_directory':str(OUT)},indent=2))
