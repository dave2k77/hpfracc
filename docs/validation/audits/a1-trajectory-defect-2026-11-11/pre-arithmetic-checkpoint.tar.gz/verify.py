"""Replay preserved A1 evidence; this verifies records, not numerical certification."""

import argparse
import hashlib
import json
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

ROOT = Path.cwd()
BASE = ROOT / "docs/validation/audits/a1-trajectory-defect-2026-11-11"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def archived(name):
    with tarfile.open(BASE / name, "r:gz") as archive:
        result = {}
        for member in archive:
            path = Path(member.name)
            assert member.isfile() and not path.is_absolute() and ".." not in path.parts
            assert member.name not in result
            stream = archive.extractfile(member)
            assert stream is not None
            result[member.name] = stream.read()
        return result


def xml_counts(raw):
    tree = ET.fromstring(raw)
    suites = list(tree.iter("testsuite"))
    assert len(suites) == 1
    cases = list(tree.iter("testcase"))
    counts = {"tests": len(cases),
            "failures": sum(c.find("failure") is not None for c in cases),
            "errors": sum(c.find("error") is not None for c in cases),
            "skipped": sum(c.find("skipped") is not None for c in cases)}
    assert all(int(suites[0].attrib[key]) == value for key, value in counts.items())
    return counts


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--current-source", action="store_true",
                    help="also compare the declared input set to this checkout")
args = parser.parse_args()
snapshot = json.loads((BASE / "source-snapshot.json").read_text())
source = archived("source-snapshot.tar.gz")
assert set(source) == set(snapshot["paths"])
assert len(source) == snapshot["count"]
assert all(digest(raw) == snapshot["paths"][name] for name, raw in source.items())
if args.current_source:
    names = subprocess.check_output([
        "git", "ls-files", "--", "src", "tests", "benchmarks",
        "pyproject.toml", "uv.lock",
    ], text=True).splitlines()
    names.append(str((BASE / "frozen-fixtures.json").relative_to(ROOT)))
    assert set(names) == set(source), "Current declared source set changed"
    assert all(not (ROOT / name).is_symlink()
               and digest((ROOT / name).read_bytes()) == snapshot["paths"][name]
               for name in source), "Current input bytes changed"
    subprocess.run(["git", "diff", "--exit-code", snapshot["baseline_commit"],
                    "--", "src", "pyproject.toml", "uv.lock"], check=True,
                   capture_output=True)

development = archived("development-evidence.tar.gz")
index = json.loads((BASE / "development-index.json").read_text())
assert set(development) == set(index)
for name, raw in development.items():
    assert digest(raw) == index[name]["sha256"], name
    if name.endswith(".xml"):
        counts = xml_counts(raw)
        assert all(counts[key] == index[name][key]
                   for key in ("tests", "failures", "errors")), name
features = ((1, 1, 1), (2, 6, 7), (3, 28, 35), (4, 1, 36), (5, 4, 40))
for feature, failed, green in features:
    red = xml_counts(development[f"feature{feature}-red.xml"])
    passed = xml_counts(development[f"feature{feature}-green.xml"])
    assert red == dict(tests=failed, failures=failed, errors=0, skipped=0)
    assert passed == dict(tests=green, failures=0, errors=0, skipped=0)
    assert f"feature{feature}-red-source.py.txt" in development
assert xml_counts(development["compatibility-cpu.xml"])["failures"] == 2

gamma = archived("gamma-repair-evidence.tar.gz")
gamma_index = json.loads((BASE / "gamma-repair-index.json").read_text())
assert set(gamma) == set(gamma_index)
assert all(digest(raw) == gamma_index[name]["sha256"] for name, raw in gamma.items())
assert xml_counts(gamma["feature6-red.xml"]) == dict(
    tests=9, failures=9, errors=0, skipped=0,
)
assert xml_counts(gamma["feature6-green.xml"]) == dict(
    tests=64, failures=0, errors=0, skipped=0,
)
before = archived("source-snapshot-before-gamma-repair.tar.gz")
before_record = json.loads(
    (BASE / "source-snapshot-before-gamma-repair.json").read_text()
)
assert set(before) == set(source) == set(before_record["paths"])
assert all(digest(raw) == before_record["paths"][name] for name, raw in before.items())
assert {name for name in source if source[name] != before[name]} == {
    "benchmarks/numerical/_volterra_defect.py", "tests/unit/test_volterra_defect.py",
}

panel = archived("panel-repair-evidence.tar.gz")
panel_index = json.loads((BASE / "panel-repair-index.json").read_text())
assert set(panel) == set(panel_index)
assert all(digest(raw) == panel_index[name]["sha256"] for name, raw in panel.items())
assert xml_counts(panel["feature7-red.xml"]) == dict(
    tests=5, failures=5, errors=0, skipped=0,
)
assert xml_counts(panel["feature7-green.xml"]) == dict(
    tests=69, failures=0, errors=0, skipped=0,
)
assert panel["panel-design-initial-exit.txt"].strip() == b"1"
for name in ("panel-targeted-cpu.xml", "panel-targeted-cuda.xml"):
    assert xml_counts(panel[name]) == dict(tests=81, failures=0, errors=0, skipped=0)

gamma_source = archived("source-snapshot-before-panel-repair.tar.gz")
gamma_record = json.loads(
    (BASE / "source-snapshot-before-panel-repair.json").read_text()
)
assert set(gamma_source) == set(source) == set(gamma_record["paths"])
assert all(digest(raw) == gamma_record["paths"][name]
           for name, raw in gamma_source.items())
assert {name for name in source if source[name] != gamma_source[name]} == {
    "benchmarks/numerical/_volterra_defect.py", "tests/unit/test_volterra_defect.py",
}
rejected = archived("gamma-code-review-failed.tar.gz")
rejected_index = json.loads(rejected["evidence-index.json"])
assert set(rejected) == {row["path"] for row in rejected_index["files"]} | {
    "evidence-index.json",
}
assert all(digest(rejected[row["path"]]) == row["sha256"]
           and len(rejected[row["path"]]) == row["bytes"]
           for row in rejected_index["files"])
rejected_verdict = json.loads((BASE / "gamma-review-failed.json").read_text())
assert rejected_verdict["passed"] is False
assert len(rejected_verdict["logic_errors"]) == 2
old_runs = json.loads((BASE / "executions-before-panel.json").read_text())["full_runs"]
assert len(old_runs) == 2 and {row["backend"] for row in old_runs} == {"cpu", "cuda"}
for run in old_runs:
    assert type(run["exit_code"]) is int and run["exit_code"] == 0
    old_raw = (BASE / f"full-before-panel-{run['backend']}.xml").read_bytes()
    assert xml_counts(old_raw) == dict(tests=964, failures=0, errors=0, skipped=0)

math = archived("independent-math-audit.tar.gz")
math_index = json.loads(math["artifact-index.json"])
assert set(math) == set(math_index) | {"artifact-index.json"}
assert all(digest(math[name]) == row["sha256"] and len(math[name]) == row["bytes"]
           for name, row in math_index.items())
assert math["frozen-fixtures.json"] == (BASE / "frozen-fixtures.json").read_bytes()
assert digest(math["frozen-fixtures.json"]) == (
    "63311bcecc3c31458df93b0c1079d0cec1d8cbc64ee1155abc07b028e9f9aaef"
)
limitation = json.loads(math["arithmetic-counterexample.json"])
assert limitation["computed_interval_contains_real_right_endpoint"] is False
assert limitation["arithmetic_verified"] is False
assert limitation["total_numerical_certified"] is False
parent = json.loads((BASE / "parent-math-replay.json").read_text())
assert len(parent["executions"]) == 3
assert set(parent["byte_matches"]) == {
    "probe-results.json", "cell-ranges.json", "precision-crosscheck.json",
    "arithmetic-counterexample.json", "frozen-fixtures.json",
}
assert all(value is True for value in parent["byte_matches"].values())
assert all(type(run["exit_code"]) is int and run["exit_code"] == 0
           for run in parent["executions"])

review = archived("initial-code-review.tar.gz")
review_index = json.loads(review["initial-review-evidence-index.json"])
assert set(review) == {row["path"] for row in review_index["files"]} | {
    "initial-review-evidence-index.json",
}
assert all(digest(review[row["path"]]) == row["sha256"]
           and len(review[row["path"]]) == row["bytes"]
           for row in review_index["files"])
assert (review["initial-review-verdict.json"]
        == (BASE / "initial-review.json").read_bytes())
initial = json.loads(review["initial-review-verdict.json"])
assert initial["passed"] is False and initial["logic_errors"]
assert initial["reviewed_tree"] == "6e7a156f025e08b31a314c5bda59183d6a96bf32"
parent_gamma = json.loads((BASE / "parent-gamma-replay.json").read_text())
assert [row["tree"] for row in parent_gamma["records"]] == [
    "6e7a156f025e08b31a314c5bda59183d6a96bf32",
    "8dcbfafd1a5373088e75437551692a85fd7f7b77",
]
assert parent_gamma["a1_acceptance_passed"] is False

nodes = [line for line in (BASE / "collection.txt").read_text().splitlines()
         if line.startswith("tests/") and "::" in line]
assert len(nodes) == len(set(nodes))
expected = Counter()
for node in nodes:
    parts = node.split("::")
    module = parts[0].removesuffix(".py").replace("/", ".")
    expected[(".".join([module, *parts[1:-1]]), parts[-1])] += 1
runs = json.loads((BASE / "executions.json").read_text())["full_runs"]
assert len(runs) == 2 and {r["backend"] for r in runs} == {"cpu", "cuda"}
results = {}
for run in runs:
    assert run["status"] == "exited"
    assert type(run["exit_code"]) is int and run["exit_code"] == 0
    path = BASE / f"full-{run['backend']}.xml"
    raw = path.read_bytes()
    cases = list(ET.fromstring(raw).iter("testcase"))
    actual = Counter((c.attrib["classname"], c.attrib["name"]) for c in cases)
    assert actual == expected
    assert xml_counts(raw) == dict(tests=len(nodes), failures=0, errors=0, skipped=0)
    results[run["backend"]] = {"tests": len(cases), "sha256": digest(raw)}

checksums = json.loads((BASE / "checksums.json").read_text())
unprotected = {"checksums.json", "verification.json"}
protected = {str(path.relative_to(BASE)) for path in BASE.rglob("*")
             if path.is_file() and path.name not in unprotected}
assert set(checksums) == protected and checksums
assert all(digest((BASE / name).read_bytes()) == value
           for name, value in checksums.items())
print(json.dumps({"scope": "record/source replay, not A1 acceptance or certification",
                  "source_count": len(source),
                  "current_source_verified": args.current_source,
                  "full_suites": results, "preserved_arithmetic_under_enclosure": True,
                  "a1_acceptance_passed": False}, indent=2))
