# A1: supplied-trajectory Volterra-defect diagnostic

Status: REJECTED / blocked private research prototype. Final code review of
`92ff3dceb217f6097bae8ccde6cf159d8daa8d14` finds three remaining arithmetic
defects, reproduced as six independent RED cases across both APIs. Do not rely
on these computed values as validation oracles. The repair-loop limit is reached;
numerical implementation is paused for an owner decision. No commit, push,
artifact approval, scope deferral, numerical certificate or Phase A closure is
claimed. The [preceding design](../a1-defect-design-2026-11-11/README.md) and its
original manifests, failed fixture and acceptance-false review remain unchanged.

`final-code-review-rejected.json` and `final-code-review-rejected.tar.gz` preserve
the verdict, exact inputs, pinned source and six RED tests. Parent execution
independently reproduces all six failures (exit one); its raw XML is retained
byte-for-byte in `final-blocking-parent.xml.gz`. All 33 indexed review files are
hash/size checked. A passing default suite does not clear this rejection.

Completed-checkpoint readback: both default CPU/CUDA full processes pass 981
tests with one performance deselection and confirmed actual exit zero. Both XML
identity sets match the frozen collection and all 125 declared source inputs
still match. `rejected-checkpoint-results.json`, the two `*-readback.json` files
and `executions.json` record these outcomes separately from the failed code
review. The six additional independent RED cases are outside that default
selection; both full-suite successes remain evidence for rejected source, not
approval. Implementation stays paused pending the unanswered owner decision.

The remaining failures are local interpolation cancellation, interpolation
underflow inside `np.interp` that bypasses the outer error trap, and loss of an
independently resolvable right-end gap in the active basis conversion. The
method description below records the rejected implementation, not an assurance
that its stated arithmetic guard covers all internal operations.

## Implemented increment

`benchmarks/numerical/_volterra_defect.py` reconstructs the continuous
piecewise-linear trajectory through the actual stored states. For scalar
`0 < alpha < 1` and `f(t,Y)=A Y + sum c_beta*(t-t0)**beta`, `beta >= 0`, it evaluates
`Y-y0-I**alpha(f(.,Y))` using local interpolation and positive PL panel-basis
integrals, not cancellation-prone global slope jumps. It retains every old panel,
the original kernel terminal and forcing clock, correct matrix orientation and
the PECE nodal Volterra mismatch. It does not integrate an interpolant of stored
RHS values while pretending to interpolate stored states. The
[panel-basis derivation and limits](panel-basis.md) describe the current method.

The cell helper splits the verification mesh at every stored knot and evaluates
positive-basis weight extrema and signed forcing-power ranges. It retains the
active left weight's interior maximum, not only endpoint samples. Its
`model_lower`/`model_upper` arrays
are floating diagnostics of an exact-arithmetic range construction, NOT verified
numerical enclosures. `max_work` caps cell-term-component evaluations; exhaustion
is explicit and never truncates history. This is not a measured memory/time cap.
Inputs must be finite real float32/float64 arrays, state shape `(time,state_dim)`;
orders remain scalar. All diagnostic RHS arithmetic widens represented inputs to
host float64 first. Float32-input checks are not claims of float32 diagnostic
arithmetic. The two PECE compatibility cases additionally exercise actual solver
outputs with independently scoped float32/float64 JAX settings. The selected
time-power underflow cases raise explicitly, even when a rearranged final
expression could be representable. This conservative failure is not computation
of the rescued value or an approved scope deferral. Internal interpolation
underflow still escapes the trap and blocks approval; no global precision
promotion is used.

Both structured results carry provenance and always return
`arithmetic_verified=False` and `total_numerical_certified=False`. There is no
acceptance decision, feedback propagation, nonlinear domain proof, stiff-case
certificate, JAX tracing or gradient contract for these host helpers. No library
runtime, public export, dependency, lockfile, solver default or tolerance changed.

## Evidence and preserved failures

- Five vertical features have separately captured pre-run test sources, actual
  RED XML and GREEN XML: reconstruction, weak-power forcing, input/arithmetic
  guards, continuum-cell diagnostics and explicit work exhaustion.
  `development-evidence.tar.gz` preserves those bytes; `development-index.json`
  records hashes/counts. Later passing compatibility assertions are additional
  coverage, not retrospectively described as RED-tested features.
- The initial compatibility run has 53 passes and two test-authoring failures:
  this JAX version has `jax.enable_x64`, not `jax.experimental.enable_x64`.
  The failed XML is retained. The repaired pre-VAL-008 targeted selections pass
  55 cases on each CPU/CUDA process. The diagnostic arithmetic is host-only on
  both; this is not a GPU diagnostic-kernel validation claim.
- Six independently frozen case inputs are copied byte-for-byte in
  `frozen-fixtures.json`. The original failed old-panel discriminator is retained
  inside the independent audit, not erased. Panelwise 80-digit quadrature is
  independent of the implementation's closed-form basis weights.
- `independent-math-audit.tar.gz` preserves the mathematical audit and its raw
  outputs, not an implementation review. It contains 38 quadrature targets,
  336 verification cells and 3,024 sampled corroborations. Samples and
  high-precision agreement do not prove a numerical enclosure. Parent replay in
  a separate copy reproduces five output/fixture files byte-for-byte; see
  `parent-math-replay.json`.
- The frozen half-order quadratic PL trajectory has nodal defect below `1e-15`
  but interior defect above `0.09`. Its newest-only and restarted history
  formulas disagree with the complete original-history defect. Nodal sampling
  or shrinking only the latest panel cannot replace continuum/full-history work.
- A fixed counterexample is retained as a limitation regression: `Y=0`, `A=0`,
  `q=1`, `alpha=1/2`, on `[nextafter(1,0),1]`. The ordinary float64 cell misses
  the true endpoint residual by approximately `1.53e-17`. This is not repaired
  by arbitrary padding or hidden precision promotion. It blocks certification,
  not the explicitly unverified diagnostic.

A later extreme-argument probe finds VAL-008: subtracting large log-gammas
returns a forcing ratio of one instead of approximately `1e-150`. Nine new
regressions fail; the shared reciprocal-Pochhammer repair fixes both pointwise
and cell paths. That Gamma-only checkpoint passes 64 targeted cases per CPU/CUDA
process, without changing arithmetic precision or certification flags.
`gamma-repair-evidence.tar.gz` and its index preserve this sixth RED/GREEN cycle.
The first full-suite launches are killed for source replacement, not counted as
passes/failures; `superseded-runs.json` and the before-gamma source/collection/
static-scan/focused XML retain their identities.

`initial-review.json` preserves the independently failed code review of tree
`6e7a156f025e08b31a314c5bda59183d6a96bf32`, including its blocking Gamma-ratio
finding; `initial-code-review.tar.gz` retains the raw checks. Its authoritative
verdict is `initial-review-verdict.json`; an explicitly labelled unexecuted
pre-discovery draft inside that archive is not a review result. Parent replay
loads trusted old/corrected immutable-tree bytes matched to the two source
archives and reproduces the error and repair in both paths; see
`parent-gamma-replay.json`. Corrected-tree review is a separate record, not an
amendment changing the original failure into a pass.

The Gamma-only tree `8dcbfafd1a5373088e75437551692a85fd7f7b77` passes both
964-test full suites with confirmed zero exits and matching 125-input/test
identities, but its independent review still fails on VAL-009/VAL-010: steep-mesh
hinges erase a nonzero state/history, and an intermediate time power silently
underflows before large finite coefficient scaling. This is preserved in
`gamma-review-failed.json` and `gamma-code-review-failed.tar.gz`, together with
the explicitly historical `*-before-panel-*` / `*-before-panel-repair*` records.
Full unit-test passes do not clear those defects or the failed review.

The next source uses positive panel-basis integrals/local interpolation and traps
unsafe underflow in both point/cell paths. Five regressions go RED, then the
69-case selection goes GREEN; additional compatibility coverage brings the
focused count to 81 per CPU/CUDA process. `panel-repair-evidence.tar.gz` and its
index retain that seventh cycle and a rejected preimplementation near-one
special-function probe. Current source is frozen separately at tree
`92ff3dceb217f6097bae8ccde6cf159d8daa8d14`; its full suites and final independent
review are distinct from the historical 964-test checkpoint.

`source-snapshot.json` and its archive freeze the declared numerical/test input
set before the full suites. This scope is tracked `src`, `tests`, `benchmarks`,
project/lock inputs and the new frozen fixture, not every documentation file.
`collection.txt` records exact selected test identities. Full-suite process exits,
XML identity checks, final documentation checks and implementation review are
recorded separately when complete; targeted passes alone do not establish them.
`baseline-ci-readback.json` records successful remote CI for the preceding
`74d8f08` checkpoint, not remote validation of this new implementation.

## Reproduction and remaining gates

Run the focused selection from the repository root:

```bash
JAX_PLATFORMS=cpu uv run --frozen --extra dev python -m pytest tests/unit/test_volterra_defect.py
UV_PROJECT_ENVIRONMENT="$HOME/.local/share/hpfracc/venv-cuda13" JAX_PLATFORMS=cuda,cpu XLA_PYTHON_CLIENT_PREALLOCATE=false uv run --frozen --extra dev --extra cuda13 python -m pytest tests/unit/test_volterra_defect.py
```

Extract the independent audit into a fresh scratch directory to rerun its three
probes with locked uv. Do not regenerate frozen fixtures as part of a check.

A1 acceptance remains false. Verified gamma/power/coefficient/input/RHS/output
arithmetic, componentwise feedback propagation and tail budgets, nonlinear tube
closure, broader stiff domains, a frozen tolerance/work/reference matrix and
reviewed opt-in controller/JAX/gradient integration remain open. The per-state
solver-order scope question is separate and unanswered. A2/A3/A4 are not closed.
