"""Read-only classification of preserved baseline results; scratch outputs only."""
import hashlib
import json
from pathlib import Path
import subprocess

S = Path(__file__).resolve().parent
R = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
E = json.loads((S/'execution.json').read_text())
O = [json.loads(line) for line in (S/'observations.jsonl').read_text().splitlines()]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def group(name):
    if name.startswith('test_six_canonical'):
        return 'canonical_success_required'
    if name.startswith('test_negative_state'):
        return 'signed_success_required'
    if name.startswith('test_unsafe'):
        return 'explicit_unsafe_intermediate_failure_policy'
    if name.startswith('test_opposite'):
        return 'extreme_range_return_or_explicit_failure'
    return 'compatibility_return_controls'


groups = {}
for row in E['testcases']:
    groups.setdefault(group(row['name']), []).append(row)
summary = {name: {'count': len(rows), 'passed': sum(x['status'] == 'passed' for x in rows),
                  'failed': sum(x['status'] == 'failure' for x in rows)}
           for name, rows in groups.items()}
assert sum(x['count'] for x in summary.values()) == E['case_count'] == 36
assert E['counts'] == {'passed': 23, 'failure': 13, 'error': 0, 'skipped': 0}
assert E['actual_process_exit'] == 1

# Bind the already-inspected old 81-test source to immutable rejected92ff.
old_test = 'tests/unit/test_volterra_defect.py'
frozen = subprocess.check_output(['git', 'show', '92ff3dceb217f6097bae8ccde6cf159d8daa8d14:'+old_test], cwd=R)
assert (R/old_test).read_bytes() == frozen

classification = {
    'subject_tree': '92ff3dceb217f6097bae8ccde6cf159d8daa8d14',
    'subject_path': str(S/'pinned/_volterra_defect.py'),
    'subject_sha256': sha(S/'pinned/_volterra_defect.py'),
    'driver_path': str(S/'test_arithmetic_adversarial.py'),
    'driver_sha256': sha(S/'test_arithmetic_adversarial.py'),
    'actual_exit': E['actual_process_exit'], 'counts': E['counts'], 'groups': summary,
    'actual_RED_tests': [r for r in E['testcases'] if r['status'] == 'failure'],
    'explicit_FloatingPointError_controls': [
        {'case': row['inputs']['case'], 'api': row['api'],
         'policy': row['policy'], 'message': row['message']}
        for row in O if row['outcome'] == 'explicit_FloatingPointError'],
    'policy_RED_not_accuracy_claim': [
        {'case': row['inputs']['case'], 'api': row['api']}
        for row in O if row['policy'] == 'must_raise' and row['outcome'] == 'returned'],
    'old_81_source_inspected_not_rerun': {'path': str(R/old_test), 'sha256': sha(R/old_test),
                                        'matches_immutable_tree': True},
    'protected_input_comparison': {path: info['before'] == info['after']
                                    for path, info in E['protected_inputs_after'].items()},
    'arithmetic_verified': False, 'total_numerical_certified': False,
    'A1_acceptance_passed': False,
    'limits': [
        'Only rejected92ff host helper was executed; no repair implementation tested.',
        'Strict underflow guards test explicit intermediate-failure policy, not a gross final-value accuracy defect.',
        'Ordinary float64 cell endpoint comparisons use case-specific slack, not certified enclosures.',
        'Higher precision is oracle-local only; no global JAX precision change.',
        'Existing old81 and full CPU/CUDA suites were inspected/referenced, not rerun.',
        'Four oracle crosschecks passed separately; no numerical production calls were made by that checker.',
        'Initial sibling baseline is preserved one directory above. V2 puts B3 coupled defect first, splits sign APIs, and permits conservative huge-state rejection.'
    ]}
path = S/'classification.json'
assert not path.exists()
path.write_text(json.dumps(classification, indent=2, sort_keys=True)+'\n')
files = sorted(p for p in S.rglob('*') if p.is_file())
manifest = {'base': str(S), 'file_count_excluding_this_manifest': len(files),
            'files': {str(p.relative_to(S)): {'sha256': sha(p), 'bytes': p.stat().st_size}
                      for p in files}}
path = S/'SHA256SUMS.json'
assert not path.exists()
path.write_text(json.dumps(manifest, indent=2, sort_keys=True)+'\n')
print(json.dumps({'summary': summary, 'classification_sha256': sha(S/'classification.json'),
                  'manifest_sha256': sha(path),
                  'execution_sha256': sha(S/'execution.json'),
                  'driver_sha256': sha(S/'test_arithmetic_adversarial.py'),
                  'oracle_checks_sha256': sha(S/'oracle-checks.json'),
                  'total_evidence_bytes_excluding_manifest': sum(x['bytes'] for x in manifest['files'].values())}, indent=2))
