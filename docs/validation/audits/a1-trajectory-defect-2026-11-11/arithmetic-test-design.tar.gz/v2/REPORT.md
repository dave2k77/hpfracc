# Proposed A1 arithmetic regressions — pinned rejected baseline only

## Outcome

The final scratch driver collected 36 tests on the unchanged rejected tree
`92ff3dceb217f6097bae8ccde6cf159d8daa8d14`: **13 actual failures, 23 passes,
zero collection errors/skips; real subprocess exit 1**. It is a RED baseline,
not a repair, review approval, certificate, or A1 closure.

- Six canonical B1/B2/B3 point/cell tests fail. All six require successful return
  with independent represented-input references; `FloatingPointError` does not
  satisfy these canonical acceptance tests.
- Four negative-state B1/B2 point/cell siblings fail, including reversed cell
  extrema. They are additional inaccurate-return REDs.
- Three explicit-intermediate-failure policy checks fail: masked matrix-product
  underflow in **both** APIs and masked power-reduction underflow in **point**.
  The large retained component hides a tiny nonzero product. These are failures
  of the promised operation/range guard, **not claims of gross final-output
  relative error**; their rounded final value can agree with the oracle.
- Fourteen compatibility controls return successfully: endpoint/every-knot
  identity for float32/float64 inputs; signed non-diagonal feedback with weak and
  cubic forcing, shifted origin and near-zero/near-one orders at both dtypes;
  active/old and q=1/2 branch boundaries; active-left peak; extreme shifted
  origin/amplitudes; exact algebraic zeros; and rescuable extreme interval ratios.
- Nine additional controls pass by explicit conservative `FloatingPointError`:
  seven unsafe arithmetic cases plus two opposite-huge-state range controls.
  The prior beta=1100, coefficient=1e300, target=0.5 underflow rejection is
  preserved in both APIs. No general scaled-product rescue is promised.

## Reference independence and scope

Inputs are decoded through `float.as_integer_ratio()`. The oracle uses local
420-digit mpmath evaluation of endpoint-basis incomplete-beta integrals and
exact-input PL interpolation. It does not call production interpolation or
basis-weight primitives. Decimal strings in observations are 110-digit exports
of the high-precision results, not decimal re-interpretations of inputs.

The B1/B2 references are approximately 1000 and 5e-101. The B3 coupled defect
reference is
`-1001.3862943611199520809959084996942638019329164123957146687594697281325262296465529066512589720494299793879779`,
where the pinned point result is approximately -1.3862943611198906. The B3
point assertion checks the coupled output first, so reconstruction failure does
not mask the active-basis discriminator.

Four independent oracle sanity checks passed: exact-rational B1/B2 identities
and transformed panel quadrature for B3 and an order-0.5 companion. The tiny-order
quadrature is partitioned at physical quarter-panel images to resolve its
near-one transformed boundary layer. The oracle checker makes no production
numerical calls.

Cell tests retain the existing 2e-12 comparison slack. They corroborate values
or selected natural-extension extrema; they do not prove outward enclosures.
Both certification flags must remain false. This is host NumPy/SciPy float64
work, not CUDA or JAX working-precision validation. There is no global precision
change, tolerance relaxation, domain restriction, or history truncation.

The strict unsafe-product cases deliberately expect explicit failure for the
primitive operations described by the draft arithmetic contract. A future
reviewed algorithm that genuinely avoids those unsafe intermediates by scaled
arithmetic would need a corresponding contract-aware test assessment; simply
returning a finite value from a masked unsafe contraction is not evidence of
that avoidance. The two extreme-ratio and opposite-huge-state tests already
allow explicit failure or an independently accurate result. Canonical six
examples never allow blanket rejection.

## Identity, provenance, and preservation

Subject: `pinned/_volterra_defect.py`, SHA-256
`fa8398b6a82b8b8937188697d5f92cd41d1f05aadf0bad1181a92c230fd849a1`,
Git blob `6a1640a731a1ec41ace2c437b17e10f2624acff7`.
It was read from immutable rejected92ff Git bytes and matched the pre-existing
independent-review pinned copy. Numerical tests import that file by absolute
path, never the live helper. Its four hpfracc import-support sources were checked
against the same immutable tree before execution and hashed before/after.

Inspected but did not rerun the old 81-test source, the draft arithmetic contract
(technical review still pending), final rejection record, and original six-case
independent driver. Their hashes and protected index/evidence identities are in
`baseline-inputs.json` and `execution.json`; all protected pre/post comparisons
match. The final old81 test source also matches immutable rejected92ff bytes.
No repository, source, docs, index, prior evidence, or existing fixture was edited.
No full suite, GPU job, dependency sync, source archive, or production repair ran.

This final driver and evidence are under `v2/`. The initial scratch run remains
untouched one directory above (33 tests, 12 failures, 21 passes). Its test design
was revised before the final baseline to put the B3 coupled defect first, split
negative-state APIs so point failures cannot mask cell execution, and allow
contract-permitted conservative rejection for the opposite-huge-state control.
Do not add the two runs together or treat the initial overly strict huge-state
failure as an independently blocking scientific accuracy defect.

## Executable paths

Base: `/home/davianc/.hermes/cache/scratch/a1-adversarial-fp_xkf2a/v2/`

- `test_arithmetic_adversarial.py`: proposed executable pytest driver.
- `pinned/_volterra_defect.py`: sole numerical subject snapshot.
- `run_baseline.py`: preserves pre/post hashes and the actual subprocess exit.
- `baseline.xml`, `baseline.stdout`, `baseline.stderr`: raw final run output.
- `execution.json`: actual exit, command, environment, test outcomes and hashes.
- `observations.jsonl`: exact binary input/output handles, oracle values, and
  explicit exceptions for all 49 evaluated calls.
- `executed-inputs.json`: 45 programmatically deduplicated executed input sets;
  recorded as execution-time data, not an invented earlier collection snapshot.
- `check_oracles.py`, `oracle-checks.json`: independent oracle verification.
- `classification.json`: detailed RED/pass/policy distinction.
- `SHA256SUMS.json`: paths, sizes, and SHA-256 values for this compact bundle.

For a fresh replay, use a **new** output path rather than overwrite evidence:

```sh
PYTHONDONTWRITEBYTECODE=1 JAX_PLATFORMS=cpu PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
uv run --frozen --extra dev --no-sync python -m pytest \
  /home/davianc/.hermes/cache/scratch/a1-adversarial-fp_xkf2a/v2/test_arithmetic_adversarial.py \
  -q -c /home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc/pyproject.toml \
  -p no:cacheprovider --junitxml=/a/new/scratch/path.xml
```

`--no-sync` avoids modifying the already-ready locked environment. A future
reviewed snapshot may be tested only by explicitly supplying `A1_SUBJECT` and
its exact `A1_SUBJECT_SHA256`; no such candidate test was run here. Porting and
final policy choice belong to the parent after technical contract review.
