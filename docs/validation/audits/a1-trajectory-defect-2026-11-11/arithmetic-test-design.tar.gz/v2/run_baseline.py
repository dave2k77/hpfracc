"""Run only the scratch driver, capture real subprocess exit and compact evidence."""
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import platform
import xml.etree.ElementTree as ET

S = Path(__file__).resolve().parent
R = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
BASE = json.loads((S/'baseline-inputs.json').read_text())


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def dump(name, obj):
    path = S/name
    assert not path.exists(), f'Never overwrite evidence: {path}'
    path.write_text(json.dumps(obj, indent=2, sort_keys=True)+'\n')


if __name__ == '__main__':
    paths = [S/'test_arithmetic_adversarial.py', S/'pinned/_volterra_defect.py',
             S/'run_baseline.py', S/'baseline-inputs.json', R/'pyproject.toml',
             R/'uv.lock']
    support = ['src/hpfracc/__init__.py', 'src/hpfracc/_version.py',
               'src/hpfracc/config/__init__.py', 'src/hpfracc/config/base.py']
    for rel in support:
        immutable = subprocess.check_output(['git', 'show', BASE['tree']+':'+rel], cwd=R)
        assert (R/rel).read_bytes() == immutable, f'Unpinned support source: {rel}'
        paths.append(R/rel)
    pre = {str(p): digest(p) for p in paths}
    dump('pre-execution.json', {'utc': datetime.datetime.now(datetime.UTC).isoformat(),
                               'files': pre, 'tree': BASE['tree']})
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu',
               PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',
               A1_OBSERVATIONS=str(S/'observations.jsonl'))
    env.pop('A1_SUBJECT', None)
    env.pop('A1_SUBJECT_SHA256', None)
    env.pop('JAX_ENABLE_X64', None)
    cmd = ['uv', 'run', '--frozen', '--extra', 'dev', '--no-sync', 'python', '-m',
           'pytest', str(S/'test_arithmetic_adversarial.py'), '-q',
           '-c', str(R/'pyproject.toml'), '-p', 'no:cacheprovider',
           '--junitxml='+str(S/'baseline.xml'), '--tb=short']
    with (S/'baseline.stdout').open('wb') as out, (S/'baseline.stderr').open('wb') as err:
        completed = subprocess.run(cmd, cwd=R, env=env, stdout=out, stderr=err,
                                   timeout=240, check=False)
    rows = []
    for el in ET.parse(S/'baseline.xml').getroot().iter('testcase'):
        failure, error, skip = el.find('failure'), el.find('error'), el.find('skipped')
        status = ('failure' if failure is not None else 'error' if error is not None
                  else 'skipped' if skip is not None else 'passed')
        row = {'name': el.get('name'), 'status': status}
        if failure is not None:
            row['message'] = failure.get('message')
        if error is not None:
            row['message'] = error.get('message')
        rows.append(row)
    status_counts = {k: sum(row['status'] == k for row in rows)
                     for k in ('passed', 'failure', 'error', 'skipped')}
    observed = [json.loads(line) for line in (S/'observations.jsonl').read_text().splitlines()]
    # Deduplicate/count exact executed inputs in code, not from narrative claims.
    unique = {json.dumps(row['inputs'], sort_keys=True): row['inputs'] for row in observed}
    dump('executed-inputs.json', {'count': len(unique), 'inputs': list(unique.values()),
                                  'capture': 'actual execution; not an earlier collection claim'})
    record = {'command': cmd, 'cwd': str(R), 'actual_process_exit': completed.returncode,
              'python': sys.version, 'platform': platform.platform(),
              'dependency_versions': {p: importlib.metadata.version(p) for p in
                  ('numpy', 'scipy', 'mpmath', 'pytest')},
              'utc_end': datetime.datetime.now(datetime.UTC).isoformat(),
              'environment_overrides': {k: env[k] for k in
                  ('JAX_PLATFORMS', 'PYTHONDONTWRITEBYTECODE',
                   'PYTEST_DISABLE_PLUGIN_AUTOLOAD', 'A1_OBSERVATIONS')},
              'no_global_x64': 'JAX_ENABLE_X64' not in env,
              'case_count': len(rows), 'counts': status_counts, 'testcases': rows,
              'observations': len(observed), 'executed_unique_inputs': len(unique),
              'observation_outcomes': {k: sum(row['outcome'] == k for row in observed)
                  for k in ('returned', 'explicit_FloatingPointError')},
              'before_hashes': pre,
              'after_hashes': {str(p): digest(p) for p in paths},
              'evidence_hashes': {name: digest(S/name) for name in
                  ('baseline.xml', 'baseline.stdout', 'baseline.stderr',
                   'observations.jsonl', 'executed-inputs.json', 'pre-execution.json')},
              'protected_inputs_after': {p: {'before': h, 'after': digest(p)}
                  for p, h in BASE['input_hashes'].items()}}
    assert pre == record['after_hashes'], 'Baseline test/source changed during run'
    dump('execution.json', record)
    print(json.dumps({k: record[k] for k in
          ('actual_process_exit', 'case_count', 'counts', 'observation_outcomes',
           'executed_unique_inputs', 'evidence_hashes')}, indent=2))
    sys.exit(completed.returncode)
