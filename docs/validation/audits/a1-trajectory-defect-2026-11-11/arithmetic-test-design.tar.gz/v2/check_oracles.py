"""Independent oracle sanity checks; no production numerical calls."""
import importlib.util
import hashlib
import json
from pathlib import Path
import sys

import mpmath as mp
import numpy as np

S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('proposed_tests', S/'test_arithmetic_adversarial.py')
t = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = t
spec.loader.exec_module(t)
rows = []
with mp.workdps(420):
    for name, target in [('B1', 0.), ('B2', 5e299)]:
        c = t.canonical(name)
        x = t.exact(target)
        left, right = map(t.exact, c.ts[-2:])
        rational = (right-x)/(right-left)*t.exact(c.ys[-2, 0]) + (x-left)/(right-left)*t.exact(c.ys[-1, 0])
        stored = mp.mpf(t.reference(c, np.asarray([target]))['reconstruction'][0][0])
        error = abs(stored-rational)/abs(rational)
        assert error < mp.mpf('1e-105')
        rows.append({'check': name+'_rational_identity', 'relative_error': mp.nstr(error, 12)})

    for name, order in [('B3', 1e-20), ('quadrature_half', .5)]:
        c = t.canonical('B3')
        c.order = order
        x, a = mp.mpf(0), t.exact(order)
        panels = []
        for j in range(len(c.ts)-1):
            l, r = t.exact(c.ts[j]), min(t.exact(c.ts[j+1]), x)
            if r <= l:
                continue
            width = t.exact(c.ts[j+1])-l
            lv, rv = t.exact(c.ys[j, 1]), t.exact(c.ys[j+1, 1])
            def integrand(u, l=l, width=width, lv=lv, rv=rv, a=a):
                s = x-u**(1/a)
                return ((l+width-s)/width*lv + (s-l)/width*rv)/mp.gamma(1+a)
            # Physical quarter panels resolve the near-one u boundary layer
            # at tiny order; plain [0,1] quadrature would miss that layer.
            physical = [l+(r-l)*mp.mpf(k)/4 for k in range(5)]
            bounds = sorted((x-s)**a for s in physical)
            panels.append(mp.quad(integrand, bounds))
        quad = mp.fsum(panels)
        beta = mp.mpf(t.reference(c, np.asarray([0.]))['fractional_rhs'][0][0])
        relative = abs(quad-beta)/abs(beta)
        assert relative < mp.mpf('1e-90'), mp.nstr(relative, 30)
        rows.append({'check': name+'_transformed_quadrature',
                     'quadrature': mp.nstr(quad, 110), 'incomplete_beta': mp.nstr(beta, 110),
                     'relative_error': mp.nstr(relative, 12)})
result = {'checks': rows, 'all_passed': True, 'production_numerical_calls': 0,
          'working_dps': 420, 'driver_sha256': hashlib.sha256((S/'test_arithmetic_adversarial.py').read_bytes()).hexdigest()}
path = S/'oracle-checks.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
