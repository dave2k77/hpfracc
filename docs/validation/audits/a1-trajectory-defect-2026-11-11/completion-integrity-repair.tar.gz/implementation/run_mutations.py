"""Controlled mutation evidence; never modifies the candidate audit or source."""

import hashlib
import json
import os
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
REL = Path('docs/validation/audits/a1-trajectory-defect-2026-11-11')
OUT = Path(__file__).resolve().parent / 'mutation-evidence'
BASE = ROOT / REL
HELPER = (BASE / 'completion_integrity.py').read_text()
VERIFY = (BASE / 'verify.py').read_text()
SCOPE = 'Controlled synthetic integrity mutation tests; NOT candidate full-suite results'


def replacing(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


def skip_field(name):
    return replacing(
        HELPER,
        '    for key, value in expected.items():\n        require(key in actual,',
        f'    for key, value in expected.items():\n        if key == {name!r}:\n            continue\n        require(key in actual,',
    )


mutants = []
for field, selection in [
    ('xml_sha256', 'test_rejects_unbound_readback and xml_sha256'),
    ('source_inputs_verified', 'test_rejects_unbound_readback and source_inputs_verified'),
    ('session_id', 'session_id'),
    ('pid', 'test_rejects_readback_identity_counts_types and pid'),
    ('source_tree', 'source_tree'),
    ('exit_record', 'test_rejects_readback_identity_counts_types and exit_record-other'),
    ('exit_record_sha256', 'test_rejects_readback_identity_counts_types and exit_record_sha256'),
    ('process_completion_sha256', 'test_rejects_readback_identity_counts_types and process_completion_sha256'),
    ('original_review_files_verified', 'test_replays_failed_document_audit_preservation and count'),
    ('passed', 'test_replays_failed_document_audit_preservation and passed'),
]:
    mutants.append((field, skip_field(field), VERIFY, selection))
mutants.append(('canonical-types', replacing(HELPER,
    '    require(type(actual) is type(expected), f"{label}: noncanonical type")',
    '    # Controlled mutant: type guard removed.'), VERIFY,
    'test_rejects_readback_identity_counts_types'))
start = HELPER.index('        fields(\n            observations[backend],')
end = HELPER.index('        preserved = ', start)
mutants.append(('process-observations', HELPER[:start] + HELPER[end:], VERIFY,
                'test_rejects_process_observation_drift'))
mutants.append(('exact-identities', replacing(HELPER,
    '    require(actual == expected, "Exact JUnit identities differ from collection")',
    '    # Controlled mutant: identity guard removed.'), VERIFY,
    'test_rejects_xml_drift and identity'))
mutants.append(('xml-header-counts', replacing(HELPER,
    '        same(suites[0].attrib[key], str(value), f"JUnit header {key}")',
    '        pass  # Controlled mutant: header binding removed.'), VERIFY,
    'test_rejects_xml_drift and header'))
mutants.append(('local-exit-bytes', replacing(HELPER,
    '        if current_source:\n            same(\n                Path(run["exit_record"]).read_bytes(),\n                raw_exit,\n                f"{backend}: local/preserved exit bytes",\n            )',
    '        # Controlled mutant: local exit comparison removed.'), VERIFY,
    'test_current_source_requires_actual_local_files and finalize and nonzero-exit'))
mutants.append(('zero-preserved-exit', replacing(HELPER,
    '        require(\n            raw_exit.strip() == b"0", f"{backend}: actual exit contents are not zero"\n        )',
    '        # Controlled mutant: zero exit guard removed.'), VERIFY,
    'test_rejects_nonzero_preserved_exit_even_with_refreshed_hash and verify'))
mutants.append(('published-executions', replacing(HELPER,
    '    if require_executions:',
    '    if False:  # Controlled mutant: execution binding removed.'), VERIFY,
    'test_rejects_published_execution_drift'))
mutants.append(('preserved-audit-archive', HELPER, replacing(VERIFY,
    'assert digest((BASE / failed_name).read_bytes()) == preservation["archive_sha256"]',
    '# Controlled mutant: failed archive byte binding removed.'),
    'test_replays_failed_document_audit_preservation and archive-bytes'))

mutants.append(('source-input-hashes', replacing(replacing(HELPER,
    '        same(digest(source[name]), expected, f"archived source {name}")',
    '        # Controlled mutant: archived input hash binding removed.'),
    '            same(digest(path.read_bytes()), expected, f"current source {name}")',
    '            # Controlled mutant: local input hash binding removed.'), VERIFY,
    'test_rejects_source_input_and_collection_drift and input-hash and finalize'))

OUT.mkdir(exist_ok=True)
results = []
for name, helper, verifier, selection in mutants:
    folder = OUT / name
    copied = folder / 'controlled-checkout' / REL
    shutil.copytree(BASE, copied, ignore=shutil.ignore_patterns('__pycache__'))
    (copied / 'completion_integrity.py').write_text(helper)
    (copied / 'verify.py').write_text(verifier)
    command = [
        'uv', 'run', '--frozen', '--extra', 'dev', 'python', '-m', 'pytest',
        str(copied / 'test_completion_integrity.py'), '-q', '-k', selection,
        '--basetemp', str(folder / 'sandboxes'), '--junitxml', str(folder / 'result.xml'),
    ]
    result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=90,
                            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
    (folder / 'stdout').write_bytes(result.stdout)
    (folder / 'stderr').write_bytes(result.stderr)
    cases = list(ET.parse(folder / 'result.xml').iter('testcase'))
    failures = [c.attrib['name'] for c in cases if c.find('failure') is not None]
    errors = [c.attrib['name'] for c in cases if c.find('error') is not None]
    row = dict(scope=SCOPE, name=name, command=command, actual_exit_code=result.returncode,
               selected=len(cases), failures=failures, errors=errors,
               helper_sha256=hashlib.sha256(helper.encode()).hexdigest(),
               verifier_sha256=hashlib.sha256(verifier.encode()).hexdigest(),
               killed=result.returncode == 1 and bool(failures) and not errors)
    (folder / 'execution.json').write_text(json.dumps(row, indent=2) + '\n')
    results.append(row)
    print(name, 'killed' if row['killed'] else 'SURVIVED/ERROR',
          result.returncode, len(cases), len(failures), len(errors), flush=True)
(OUT / 'results.json').write_text(json.dumps({'scope': SCOPE, 'mutants': results}, indent=2)+'\n')
assert all(row['killed'] for row in results)
