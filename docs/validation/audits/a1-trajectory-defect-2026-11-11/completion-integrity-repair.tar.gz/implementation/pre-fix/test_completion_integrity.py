"""Controlled integrity tests, NOT candidate full-suite results.

Invoke explicitly; these tests are outside the default numerical test collection.
The real CLIs run on copies. No actual candidate readback/finalization is written.
"""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
RELATIVE = HERE.relative_to(ROOT)
PRODUCER = Path(
    "/home/davianc/.hermes/cache/scratch/a1-arithmetic-20261111/full_evidence.py"
)
SCOPE = "Controlled synthetic integrity test; NOT candidate full-suite results"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def put(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def load(path):
    return json.loads(path.read_text())


def rehash(base):
    put(base / "checksums.json", {
        str(path.relative_to(base)): sha(path.read_bytes())
        for path in sorted(base.rglob("*"))
        if path.is_file() and path.name not in {"checksums.json", "verification.json"}
    })


@pytest.fixture
def sandbox(tmp_path):
    root = tmp_path / "controlled-sandbox"
    base = root / RELATIVE
    shutil.copytree(HERE, base, ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copyfile(PRODUCER, root / "full_evidence.py")
    with tarfile.open(base / "source-snapshot.tar.gz", "r:gz") as archive:
        for member in archive:
            assert member.isfile() and ".." not in Path(member.name).parts
            path = root / member.name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(archive.extractfile(member).read())
    plan = load(base / "execution-plan.json")
    completion = []
    for index, run in enumerate(plan["full_runs"]):
        backend = run["backend"]
        run.update(session_id=f"controlled-{backend}", pid=700001 + index,
                   exit_record=str(root / f"controlled-{backend}.exit"))
        Path(run["exit_record"]).write_bytes(b"0\n")
        preserved = f"completion-exit-{backend}.txt"
        (base / preserved).write_bytes(b"0\n")
        completion.append({
            "backend": backend, "session_id": run["session_id"], "pid": run["pid"],
            "status": "exited", "exited": True, "exit_code": 0,
        })
    plan["scope"] = SCOPE
    put(base / "execution-plan.json", plan)
    put(base / "process-completion.json", {"scope": SCOPE, "full_runs": completion})
    process_sha = sha((base / "process-completion.json").read_bytes())
    executions = []
    for run in plan["full_runs"]:
        backend = run["backend"]
        put(base / f"{backend}-readback.json", {
            "scope": SCOPE, "backend": backend, "session_id": run["session_id"],
            "pid": run["pid"], "exit_record": run["exit_record"],
            "source_tree": plan["source_tree"], "exit_code": 0,
            "tests": plan["expected_selected_tests"],
            "counts": dict(tests=plan["expected_selected_tests"], failures=0,
                           errors=0, skipped=0),
            "source_inputs_verified": plan["source_count"], "source_mismatches": [],
            "exact_identities_verified": True,
            "xml_sha256": sha((base / f"full-{backend}.xml").read_bytes()),
            "preserved_exit_record": f"completion-exit-{backend}.txt",
            "exit_record_sha256": sha(b"0\n"),
            "process_completion_sha256": process_sha,
        })
        executions.append({
            "backend": backend, "session_id": run["session_id"], "pid": run["pid"],
            "exit_record": run["exit_record"], "status": "exited", "exited": True,
            "exit_code": 0, "tests_passed": plan["expected_selected_tests"],
        })
    put(base / "executions.json", {
        "scope": SCOPE, "source_tree": plan["source_tree"], "full_runs": executions,
        "a1_acceptance_passed": False,
    })
    return root, base


def cli(sandbox, tool, *extra):
    root, base = sandbox
    rehash(base)  # Tampering must be caught semantically, not by the checksum wrapper.
    command = [sys.executable]
    if tool == "finalize":
        command += [str(root / "full_evidence.py"), "finalize"]
    elif tool in {"cpu", "cuda"}:
        command += [str(root / "full_evidence.py"), tool]
    else:
        command += [str(base / "verify.py"), *extra]
    result = subprocess.run(
        command, cwd=root, capture_output=True, timeout=30,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
    )
    number = len(list(root.glob("cli-*-result.json")))
    stem = root / f"cli-{number}"
    stem.with_suffix(".stdout").write_bytes(result.stdout)
    stem.with_suffix(".stderr").write_bytes(result.stderr)
    put(root / f"cli-{number}-result.json", {
        "scope": SCOPE, "command": command, "actual_exit_code": result.returncode,
        "stdout_sha256": sha(result.stdout), "stderr_sha256": sha(result.stderr),
    })
    return result


@pytest.mark.parametrize("tool", ["finalize", "verify"])
def test_positive_real_cli(sandbox, tool):
    result = cli(sandbox, tool)
    assert result.returncode == 0, result.stderr.decode()


@pytest.mark.parametrize("tool", ["finalize", "verify"])
@pytest.mark.parametrize("field,value", [
    ("xml_sha256", "0" * 64),
    ("source_inputs_verified", 0),
])
def test_rejects_unbound_readback(sandbox, tool, field, value):
    base = sandbox[1]
    path = base / "cpu-readback.json"
    record = load(path)
    record[field] = value
    put(path, record)
    result = cli(sandbox, tool)
    assert result.returncode != 0, (
        f"{tool} accepted {field}={value!r}; controlled integrity test, not suite evidence"
    )
