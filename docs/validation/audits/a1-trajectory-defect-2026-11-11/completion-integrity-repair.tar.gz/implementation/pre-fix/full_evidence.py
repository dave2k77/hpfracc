"""Read actual current-suite exits/identities; finalize only completed evidence."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument("action", choices=("cpu", "cuda", "finalize"))
args = parser.parse_args()
base = Path("docs/validation/audits/a1-trajectory-defect-2026-11-11")
plan = json.loads((base / "execution-plan.json").read_text())
snapshot = json.loads((base / "source-snapshot.json").read_text())
review = json.loads((base / "arithmetic-code-review.json").read_text())
assert review["passed"] is True and not review["logic_errors"]
assert review["reviewed_tree"] == snapshot["source_tree"] == plan["source_tree"]
expected = Counter()
for node in (base / "collection.txt").read_text().splitlines():
    if node.startswith("tests/") and "::" in node:
        parts = node.split("::")
        module = parts[0].removesuffix(".py").replace("/", ".")
        expected[(".".join([module, *parts[1:-1]]), parts[-1])] += 1
assert sum(expected.values()) == plan["expected_selected_tests"]
if args.action in ("cpu", "cuda"):
    run = next(row for row in plan["full_runs"] if row["backend"] == args.action)
    exit_path = Path(run["exit_record"])
    assert exit_path.exists(), "No actual completion record yet"
    actual_exit = int(exit_path.read_text().strip())
    xml = base / ("full-" + args.action + ".xml")
    cases = list(ET.parse(xml).getroot().iter("testcase"))
    actual = Counter((case.attrib["classname"], case.attrib["name"]) for case in cases)
    mismatch = [name for name, digest in snapshot["paths"].items()
                if hashlib.sha256(Path(name).read_bytes()).hexdigest() != digest]
    counts = {"tests": len(cases),
              "failures": sum(case.find("failure") is not None for case in cases),
              "errors": sum(case.find("error") is not None for case in cases),
              "skipped": sum(case.find("skipped") is not None for case in cases)}
    record = {"backend": args.action, "source_tree": plan["source_tree"],
              "captured_at_utc": datetime.now(timezone.utc).isoformat(),
              "exit_code": actual_exit, "tests": len(cases), "counts": counts,
              "source_inputs_verified": len(snapshot["paths"])-len(mismatch),
              "source_mismatches": mismatch, "exact_identities_verified": actual == expected,
              "xml_sha256": hashlib.sha256(xml.read_bytes()).hexdigest(),
              "scope": "Source-bound actual default-suite evidence, not A1 acceptance or cancellation safety"}
    (base / (args.action + "-readback.json")).write_text(json.dumps(record, indent=2)+"\n")
    print(json.dumps(record, indent=2))
    passed = (actual_exit == 0 and not mismatch and actual == expected
              and all(counts[key] == 0 for key in ("failures", "errors", "skipped")))
    sys.exit(0 if passed else 1)

# Caller must independently check process_manage completion before finalization.
runs = []
for run in plan["full_runs"]:
    record = json.loads((base / (run["backend"]+"-readback.json")).read_text())
    assert record["source_tree"] == plan["source_tree"]
    assert type(record["exit_code"]) is int and record["exit_code"] == 0
    assert record["exact_identities_verified"] and not record["source_mismatches"]
    assert record["tests"] == sum(expected.values())
    assert all(record["counts"][key] == 0 for key in ("failures", "errors", "skipped"))
    assert Path(run["exit_record"]).read_text().strip() == "0"
    runs.append({"backend": run["backend"], "session_id": run["session_id"],
                 "pid": run["pid"], "status": "exited", "exit_code": 0,
                 "tests_passed": record["tests"]})
(base / "executions.json").write_text(json.dumps({
    "source_tree": plan["source_tree"], "full_runs": runs,
    "scope": "Actual source-bound suites; source review, record integrity and scientific acceptance are separate",
    "a1_acceptance_passed": False,
}, indent=2)+"\n")
checksums = {str(path.relative_to(base)): hashlib.sha256(path.read_bytes()).hexdigest()
             for path in sorted(base.rglob("*")) if path.is_file()
             and path.name not in {"checksums.json", "verification.json"}}
(base / "checksums.json").write_text(json.dumps(checksums, indent=2)+"\n")
print(json.dumps({"source_tree": plan["source_tree"], "full_runs": runs,
                  "protected_artifacts": len(checksums), "a1_acceptance_passed": False}, indent=2))
