"""Capture parent metadata controls, keeping synthetic outcomes clearly separate."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

stage = sys.argv[1]
assert stage in {'portable-red', 'portable-green'}
root = Path.cwd()
base = root / 'docs/validation/audits/a1-trajectory-defect-2026-11-11'
out = Path('/home/davianc/.hermes/cache/scratch/a1-arithmetic-20261111/parent-integrity-controls') / stage
assert not out.exists()
out.mkdir(parents=True)
for name in ('test_completion_integrity.py', 'completion_integrity.py', 'verify.py', 'capture_completion.py'):
    path = base / name
    if path.exists():
        (out / ('before-' + name + '.txt')).write_bytes(path.read_bytes())
command = ['uv', 'run', '--frozen', '--extra', 'dev', 'python', '-m', 'pytest',
           str(base / 'test_completion_integrity.py'), '-q', '-p', 'no:cacheprovider',
           '--basetemp', str(out / 'sandboxes'), '--junitxml', str(out / 'result.xml')]
if stage == 'portable-red':
    command += ['-k', 'test_capture_cli_is_part_of_preserved_artifact']
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', JAX_PLATFORMS='cpu')
start = datetime.now(timezone.utc).isoformat()
result = subprocess.run(command, cwd=root, env=env, capture_output=True)
(out / 'stdout.txt').write_bytes(result.stdout)
(out / 'stderr.txt').write_bytes(result.stderr)
record = {'scope': 'Controlled synthetic integrity/portability tests, NOT candidate numerical full-suite results',
          'stage': stage, 'command': command, 'started_at_utc': start,
          'completed_at_utc': datetime.now(timezone.utc).isoformat(), 'actual_exit_code': result.returncode}
(out / 'execution.json').write_text(json.dumps(record, indent=2)+'\n')
print(result.stdout.decode())
print(json.dumps(record, indent=2))
sys.exit(result.returncode)
