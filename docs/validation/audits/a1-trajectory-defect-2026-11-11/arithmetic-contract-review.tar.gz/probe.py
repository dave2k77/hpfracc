"""Read-only arithmetic-contract probes; no repaired production artifact."""
import hashlib
import json
import pathlib
import subprocess
import sys
import types

import mpmath as mp
import numpy as np
import scipy
from scipy.special import gamma

ROOT = pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = pathlib.Path(__file__).parent
TREE = '92ff3dceb217f6097bae8ccde6cf159d8daa8d14'
source = subprocess.check_output(['git', 'show', f'{TREE}:benchmarks/numerical/_volterra_defect.py'], cwd=ROOT)
mod = types.ModuleType('immutable_volterra_contract_probe')
sys.modules[mod.__name__] = mod
exec(compile(source, f'git:{TREE}:benchmarks/numerical/_volterra_defect.py', 'exec'), mod.__dict__)
mp.mp.dps = 120


def exact(x):
    n, d = float(x).as_integer_ratio()
    return mp.mpf(n) / d


def reference_weights(t, l, r, a):
    t, l, r, a = map(exact, (t, l, r, a))
    if t <= l:
        return mp.mpf(0), mp.mpf(0)
    tau, h = t-l, r-l
    q = min(h/tau, mp.mpf(1))
    zeroth = mp.betainc(1, a, 0, q)
    first = mp.betainc(2, a, 0, q)
    scale = tau**a/mp.gamma(a)
    return scale*(zeroth-tau/h*first), scale*tau/h*first


def relative(x, y):
    return float(abs(exact(x)-y)/abs(y)) if y else float(abs(exact(x)))


# These expressions test the proposed mathematical formulas only, not a repair.
active_rows = []
for a in (1e-20, .3, .5, .75, np.nextafter(1., 0.)):
    for t, l, r in ((0., -1., 1e-17), (.25, 0., 1.), (1., 0., 1.)):
        tau, g, h = np.float64(t)-l, np.float64(r)-t, np.float64(r)-l
        with np.errstate(all='raise'):
            mass = np.power(tau, a)/gamma(1+a)
            wl = mass*(g/h+(tau/h)*a/(1+a))
            wr = mass*(tau/h)/(1+a)
        ref = reference_weights(t, l, r, a)
        active_rows.append({'alpha': float(a), 't_l_r': [t,l,r],
                            'relative_errors': [relative(wl,ref[0]), relative(wr,ref[1])],
                            'positive': bool(wl>0 and wr>0)})

# Independent integral substitution for ordinary orders, avoiding the singular kernel.
quad_rows = []
for a in (.3, .5, .75):
    t, l, r = map(mp.mpf, ('0.25','0','1'))
    aa = exact(a)
    scale = 1/mp.gamma(aa+1)
    ql = scale*mp.quad(lambda u: (r-t+u**(1/aa))/(r-l), [0,(t-l)**aa])
    qr = scale*mp.quad(lambda u: (t-l-u**(1/aa))/(r-l), [0,(t-l)**aa])
    refs = reference_weights(float(t),float(l),float(r),a)
    quad_rows.append({'alpha': a, 'relative_errors': [float(abs(x-y)/y) for x,y in zip((ql,qr),refs)]})

# Old-panel branches and the active/old boundary, using exact-input beta moments.
old_rows = []
for a in (1e-20, .3, .5, .75, np.nextafter(1.,0.)):
    for t in (1., np.nextafter(1.,np.inf), np.nextafter(2.,0.), 2., np.nextafter(2.,np.inf), 1e17):
        with np.errstate(all='raise'):
            weights = mod._panel_weights(np.array([t]), 0., 1., a)
        ref = reference_weights(t,0.,1.,a)
        old_rows.append({'alpha':float(a),'t':float(t),
                         'relative_errors':[relative(w[0],rr) for w,rr in zip(weights,ref)],
                         'positive': bool(weights[0][0]>0 and weights[1][0]>0)})

# The active-left derivative has the sign of alpha*h-tau; peak in offset space.
peak_rows=[]
for a in (1e-20,.3,.5,.75,np.nextafter(1.,0.)):
    aa, h = exact(a), mp.mpf(1)
    w = lambda tau: tau**aa/mp.gamma(aa+1)*(1-tau/(h*(aa+1)))
    peak = aa*h
    expected_peak = peak**aa/(mp.gamma(aa+1)*(aa+1))
    peak_rows.append({'alpha':float(a),'at_peak_relative_error':float(abs(w(peak)-expected_peak)/expected_peak),
                      'left_derivative_positive':bool(mp.diff(w,peak/2)>0),
                      'right_derivative_negative':bool(mp.diff(w,(peak+h)/2)<0)})

# Replay six rejected canonical cases without running pytest or changing the helper.
review=json.loads((ROOT/'docs/validation/audits/a1-trajectory-defect-2026-11-11/final-code-review-rejected.json').read_text())
canonical=[]
for failure in review['logic_errors']:
    p=failure['reproduction']
    ts=np.asarray(p['ts']); states=np.asarray(p['states']); target=float(p['target'])
    matrix=np.asarray(p['matrix']); initial=np.asarray(p['initial_state'])
    j=int(np.searchsorted(ts,target,side='right')-1)
    t,l,r=map(exact,(target,ts[j],ts[j+1]))
    # Exact-input barycentric reconstruction; not slope/intercept arithmetic.
    y=[(r-t)/(r-l)*exact(x)+(t-l)/(r-l)*exact(z) for x,z in zip(states[j],states[j+1])]
    rhs=[]
    for k in range(states.shape[1]):
        terms=[]
        for panel in range(len(ts)-1):
            wl,wr=reference_weights(target,ts[panel],ts[panel+1],p['order'])
            terms.append(wl*mp.fsum(exact(matrix[k,c])*exact(states[panel,c]) for c in range(states.shape[1])))
            terms.append(wr*mp.fsum(exact(matrix[k,c])*exact(states[panel+1,c]) for c in range(states.shape[1])))
        rhs.append(mp.fsum(terms))
    ref=[yy-exact(ini)-rr for yy,ini,rr in zip(y,initial,rhs)]
    opts=dict(order=p['order'], matrix=matrix, initial_state=initial)
    point=mod.affine_power_defect(ts,states,np.array([target]),**opts)
    cells=mod.affine_power_cells(ts,states,np.asarray(p['verification_mesh']),**opts)
    component=0
    idx = 0 if failure['id']=='B2' else len(cells.verification_times)-2
    point_bad=abs(exact(point.defect[0,component])-ref[component]) > abs(ref[component])*mp.mpf('2e-12')
    cell_got = cells.model_lower[idx,component] if failure['id']=='B3' else cells.model_upper[idx,component]
    cell_bad = (exact(cell_got)>ref[component]+abs(ref[component])*mp.mpf('2e-12')) if failure['id']=='B3' else (abs(exact(cell_got)-ref[component])>abs(ref[component])*mp.mpf('2e-12'))
    canonical.extend([{'id':failure['id'],'api':'point','observed_defect':point.defect[0].tolist(),
                       'reference_defect':[mp.nstr(x,48) for x in ref], 'rejected_value_reproduced':bool(point_bad)},
                      {'id':failure['id'],'api':'cells','selected_cell':cells.verification_times[idx:idx+2].tolist(),
                       'observed_lower':cells.model_lower[idx].tolist(),'observed_upper':cells.model_upper[idx].tolist(),
                       'historical_assertion':'lower <= reference+abs(reference)*2e-12' if failure['id']=='B3' else 'upper ~= reference (rel=2e-12, abs=0)',
                       'rejected_value_reproduced':bool(cell_bad)}])

# B1 and B2 can succeed directly without an underflowing slope or precision change.
reconstruction_rows=[]
for ident,l,r,t,yl,yr in [('B1',-1.,1e-17,0.,1e20,0.),('B2',0.,1e300,5e299,0.,1e-100)]:
    with np.errstate(all='raise'):
        value=((np.float64(r)-t)/(np.float64(r)-l))*yl+((np.float64(t)-l)/(np.float64(r)-l))*yr
    ref=(exact(r)-exact(t))/(exact(r)-exact(l))*exact(yl)+(exact(t)-exact(l))/(exact(r)-exact(l))*exact(yr)
    reconstruction_rows.append({'id':ident,'contract_expression':float(value),'reference':mp.nstr(ref,48),'relative_error':relative(value,ref)})

# Canonical B3 cell's model ranges from independent positive-basis extrema.
a=1e-20
wl0,wr0=reference_weights(0.,-1.,1e-17,a)
wl1,wr1=reference_weights(1e-17,-1.,1e-17,a)
old0=reference_weights(0.,-2.,-1.,a)[1]
old1=reference_weights(1e-17,-2.,-1.,a)[1]
model_lower=-exact(1e20)*(old0+wl0)
model_upper=-exact(1e20)*(old1+wl1)
b3_model={'last_cell':[0.,1e-17], 'exact_expression_lower':mp.nstr(model_lower,48),
          'exact_expression_upper':mp.nstr(model_upper,48),
          'point_at_left':mp.nstr(-exact(1e20)*(old0+wl0),48),
          'shared_active_left_at_left':mp.nstr(wl0,48),
          'old_active_left_at_left':float(mod._panel_weights(np.array([0.]),-1.,1e-17,a)[0][0])}

# Preserve offset-space peak selection, not a rounded absolute peak coordinate.
peak_coordinate_control={'left':-1.,'alpha':1e-20,'width':1.,
                         'peak_offset':float(np.multiply(np.float64(1e-20),np.float64(1.))),
                         'rounded_absolute_peak':float(np.add(np.float64(-1.),np.float64(1e-20))),
                         'exact_peak_weight':mp.nstr(exact(1e-20)**exact(1e-20)/(mp.gamma(1+exact(1e-20))*(1+exact(1e-20))),48)}

# Observe internal bypass vs explicit ufunc traps. Expected policy is rejection,
# not successful recovery of every rescaled contribution.
def observe(name,fn):
    try:
        with np.errstate(all='raise'):
            value=fn()
        return {'name':name,'exception':None,'value':np.asarray(value).tolist()}
    except FloatingPointError as e:
        return {'name':name,'exception':type(e).__name__,'message':str(e)}

bypass=[observe('np.interp unsafe internal slope',lambda:np.interp([5e299],[0.,1e300],[0.,1e-100])),
        observe('explicit corresponding slope division',lambda:np.divide(np.float64(1e-100),np.float64(1e300))),
        observe('matrix matmul range check',lambda:np.array([[1e-200]]) @ np.array([[1e-200]])),
        observe('explicit matrix scalar product',lambda:np.multiply(np.float64(1e-200),np.float64(1e-200))),
        observe('dot library bypass control',lambda:np.dot(np.array([1e-200]),np.array([1e-200]))),
        observe('explicit forcing scalar product',lambda:np.multiply(np.float64(1e-200),np.float64(1e-200))),
        observe('positive time power underflow',lambda:np.power(np.float64(.5),np.float64(1100.5))),
        observe('Python float power bypass',lambda:float(.5)**float(1100.5)),
        observe('exact cancellation permitted',lambda:np.add(np.float64(1e-200),np.float64(-1e-200))),
        observe('signed reduction overflow',lambda:np.add.reduce(np.array([1e308,1e308,-1e308])))]

matrix_opts=dict(order=.5,matrix=np.array([[1e-200]]),initial_state=np.array([1e-200]))
matrix_reference=exact(1e-200)*exact(1e-200)*exact(1e300)**exact(.5)/mp.gamma(mp.mpf('1.5'))
matrix_sibling={'normal_reference_rhs':mp.nstr(matrix_reference,48),
                'normal_float64':bool(matrix_reference>exact(np.finfo(float).tiny)),
                'contract_requires_explicit_failure_or_safe_rescaling':True,
                'observations':[]}
for api in ('point','cells'):
    try:
        if api=='point':
            result=mod.affine_power_defect(np.array([0.,1e300]),np.full((2,1),1e-200),np.array([1e300]),**matrix_opts)
            value=result.fractional_rhs.tolist()
        else:
            result=mod.affine_power_cells(np.array([0.,1e300]),np.full((2,1),1e-200),np.array([0.,1e300]),**matrix_opts)
            value=result.model_lower.tolist()
        matrix_sibling['observations'].append({'api':api,'exception':None,'value':value})
    except FloatingPointError as e:
        matrix_sibling['observations'].append({'api':api,'exception':type(e).__name__,'message':str(e)})

forcing_opts=dict(order=.5,matrix=np.zeros((1,1)),initial_state=np.zeros(1),
                  power_exponents=np.array([1100.]),power_coefficients=np.array([[1e300]]))
forcing_rejections=[]
for api in ('point','cells'):
    fn=(lambda:mod.affine_power_defect(np.array([0.,1.]),np.zeros((2,1)),np.array([.5]),**forcing_opts)) if api=='point' else (lambda:mod.affine_power_cells(np.array([0.,1.]),np.zeros((2,1)),np.array([0.,.5,1.]),**forcing_opts))
    forcing_rejections.append(observe(api,fn))

# Monotonicity of exact old-panel weights follows directly from the strictly
# decreasing kernel for t>r. These samples are only a consistency check.
monotone=[]
for a in (1e-20,.3,.5,.75,np.nextafter(1.,0.)):
    vals=[reference_weights(t,0.,1.,a) for t in (1.,1.1,2.,4.)]
    monotone.append({'alpha':float(a),'both_decrease':all(vals[i][k]>vals[i+1][k] for i in range(3) for k in (0,1))})

# Existing specialized gamma ratio: selected represented-input comparisons and
# explicit range rejection, not a proof about special-function internals.
ratio_rows=[]
for a in (1e-20,.3,.5,.75,np.nextafter(1.,0.)):
    for beta in (0.,.25,1e16,1e100,1e300,np.finfo(float).max):
        with mp.workdps(420):
            aa,bb=exact(a),exact(beta)
            ref=mp.exp(mp.loggamma(bb+1)-mp.loggamma(bb+aa+1))
            try:
                with np.errstate(all='raise'):
                    got=mod._power_integral_ratio(np.float64(beta),float(a))
                ratio_rows.append({'alpha':float(a),'beta':float(beta),'relative_error':relative(got,ref),'positive_finite':bool(np.isfinite(got) and got>0)})
            except FloatingPointError as e:
                ratio_rows.append({'alpha':float(a),'beta':float(beta),'exception':str(e)})

result={'scope':'Read-only contract mathematics and rejected-source probes; no corrected source, artifact approval, enclosure certification or full suite.',
        'versions':{'python':sys.version.split()[0],'numpy':np.__version__,'scipy':scipy.__version__,'mpmath':mp.__version__},
        'active_formula_checks':{'count':len(active_rows),'max_measured_relative_error':max(e for row in active_rows for e in row['relative_errors']),
                                  'all_positive':all(x['positive'] for x in active_rows),'canonical_near_terminal':active_rows[0]},
        'independent_transformed_quadrature_checks':quad_rows,
        'old_branch_boundary_checks':{'count':len(old_rows),'max_measured_relative_error':max(e for row in old_rows for e in row['relative_errors']),
                                      'all_positive':all(x['positive'] for x in old_rows)},
        'active_left_peak_checks':peak_rows,'offset_peak_coordinate_control':peak_coordinate_control,
        'old_weight_monotonicity_samples':monotone,
        'gamma_ratio_checks':{'count':len(ratio_rows),'successful_comparisons':sum('relative_error' in row for row in ratio_rows),
                              'max_measured_relative_error':max(row['relative_error'] for row in ratio_rows if 'relative_error' in row),
                              'explicit_range_rejections':[row for row in ratio_rows if 'exception' in row]},
        'canonical_rejected_replay':canonical,'canonical_count':len(canonical),
        'all_six_rejected_failures_reproduced':all(row.get('rejected_value_reproduced',row.get('reference_not_covered_with_existing_2e_12_slack',False)) for row in canonical),
        'standalone_contract_reconstruction':reconstruction_rows,'b3_independent_cell_expression':b3_model,
        'errstate_bypass_and_scalar_controls':bypass,'matrix_sibling_rejected_source':matrix_sibling,
        'preserved_time_power_rejections':forcing_rejections,
        'a1_acceptance_passed':False}
(OUT/'probes.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result,indent=2,allow_nan=False))
