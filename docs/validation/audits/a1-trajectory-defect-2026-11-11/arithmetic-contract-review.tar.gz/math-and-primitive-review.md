# Arithmetic-contract review: mathematical conclusions

Contract review only. Rejected tree 92ff3dceb217f6097bae8ccde6cf159d8daa8d14 remains rejected. No production source, test, documentation, index, dependency or precision-setting changes were made. No pytest/full suite was run. All new evidence is in this scratch directory.

## Basis and extrema

For active panel l<t<=r, set tau=t-l, g=r-t, h=r-l. Substituting u=t-s into the two original endpoint basis integrals gives

- wR = tau^(a+1)/(h*Gamma(a+2));
- wL = [g*tau^a/a + tau^(a+1)/(a+1)]/[h*Gamma(a)].

Gamma recurrence gives exactly the draft's positive formulas. Both weights are positive for tau>0 and 0<a<1, including t=r. Their sum is tau^a/Gamma(a+1). Independent g=r-t is essential: B3 has represented g=1e-17 even though rounded h=tau=1. No complementary normalized fraction can recover that gap.

For extrema only, exact algebra gives wL(tau)=tau^a/Gamma(1+a)*(1-tau/[h*(1+a)]). Its derivative is tau^(a-1)/Gamma(1+a)*(a-tau/h); hence the sole active-left maximum is at offset tau=a*h and has value (a*h)^a/[Gamma(1+a)*(1+a)]. This subtractive identity is a proof, not the recommended evaluation formula. Active-right is increasing. After the panel ends, differentiating the integral for t>r gives (a-1)/Gamma(a) times an integral of positive basis times (t-s)^(a-2), so both old weights decrease. The stored-knot union puts the active-right maximum at a cell boundary. Check peaks in offset space, not by rounding l+a*h to an absolute coordinate: l=-1,a=1e-20,h=1 rounds that coordinate to l although the peak weight is approximately one.

Consequently endpoint reconstruction, both endpoint weight values, the active-left peak when contained, and monotone forcing powers provide a sound real-arithmetic natural extension. Sign selection for feedback and forcing coefficients must be retained. These are not outward-rounded floating enclosures.

## Auditable bounded primitive approach

Keep production arithmetic NumPy float64. Route reconstruction and both APIs through shared checked subtract/divide/multiply/add/power primitives: local errstate for invalid/divide/overflow/underflow, finite postconditions, explicit zero-result checks for nonzero-operand products/ratios and positive-base powers, and operation/panel/term context in FloatingPointError. Exact zeros and signed cancellation must remain legitimate; zero after a reduction alone is not evidence of underflow. A normal-looking final result does not validate an unchecked intermediate.

Return stored states directly at knots. For interior points independently compute both distances, width, both ratios, both weighted endpoint products, then checked addition. Do not introduce slopes, complementary fractions or arbitrary order/magnitude cutoffs. Use the same reconstruction for cell endpoints. The canonical B1/B2 expressions succeed without scaled or higher-precision production arithmetic.

For feedback, explicitly form checked products state[i,k]*A[j,k] and accumulate in a documented fixed order, preserving the transpose convention. For forcing, share checked positive factors and signed coefficient multiplication between point and cell paths. Do not replace matmul by another unchecked dot/einsum/reduction. Likewise check panel-weight/state products, range coefficient sign selection, gamma-ratio reciprocal, peak power, time powers and every contribution accumulation. Conservative explicit failure of a genuinely unsafe intermediate is permitted, and the existing 1100.5 time-power underflow regressions must still reject.

Current NumPy 2.4.6 matmul and dot controls did raise underflow, including both rejected-helper matrix sibling calls; that is compatibility evidence, not a demonstrated matrix defect or a portable guarantee about library internals. np.interp and Python-float power controls returned silent zero. Inspectable ufunc operations and postconditions avoid reliance on such implementation-specific behavior. Validate known-positive special-function outputs as positive finite values; postconditions do not prove their accuracy or exclude all hidden internal range loss.

## Scope and acceptance

The draft honestly separates detected range loss from ordinary conditioning, summation and special-function errors; it neither proves a relative-error theorem nor certifies a continuum enclosure. All six historical assertions reproduce against the rejected helper with their original rel=2e-12, abs=0 comparisons (B3 cell uses its original relative slack). The new contract correctly requires canonical success, rather than retaining the old tests' exception escape hatch. Canonical B3's exact-expression cell lower bound is approximately -1001.38629436111995, matching its left-endpoint defect, rather than the rejected -1.3862943611198906.

No blocking mathematical/input-domain correction was found. Non-blocking wording clarification: read 'nonnegative finite power forcing' as finite nonnegative exponents with arbitrary finite signed coefficients, as required by the existing helper and signed-forcing tests. Do not reinterpret it as a nonnegative-coefficient restriction.

A technical contract pass authorizes no numerical artifact approval, certification, A1 closure, commit/push, or further repair loop. The corrected bytes and six successful canonical cases still require the separately authorized bounded implementation/review gate.
