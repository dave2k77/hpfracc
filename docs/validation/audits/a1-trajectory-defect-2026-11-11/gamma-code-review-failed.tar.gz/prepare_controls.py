"""Copy prior independent controls to immutable scratch snapshot; label deltas."""
import difflib
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
PREVIOUS=Path('/home/davianc/.hermes/cache/scratch/a1-independent-code-review-rznn_1kr/independent_probes.py')
original=PREVIOUS.read_bytes()
(OUT/'preserved-original/independent_probes.py').write_bytes(original)
source=original.decode()
source=source.replace("ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')\nOUT = Path(__file__).resolve().parent", "OUT = Path(__file__).resolve().parent\nROOT = OUT/'tree'  # ADAPTATION: exact immutable-tree snapshot, not live worktree")
start="    variants.append(dict(ts=np.array([0.,1.]),states=np.array([[0.],[1.]]),order=.5,\n                         matrix=np.array([[0.]]),initial_state=np.array([0.]),\n                         power_exponents=np.array([1e308]),power_coefficients=np.array([[1.]])))"
assert source.count(start)==1
source=source.replace(start,"    # ADAPTATION: beta=1e308 is no longer a log-gamma-overflow case.\n    # Validate the repaired finite result independently below, not an exception.")
needle="    return results\ncheck('finite-input-nonfinite-arithmetic-fails-closed',numerical_overflow_guards)"
replacement="""    p=dict(ts=np.array([0.,1.]),states=np.array([[0.],[0.]]),order=.5,
           matrix=np.array([[0.]]),initial_state=np.array([0.]),
           power_exponents=np.array([1e308]),power_coefficients=np.array([[1.]]))
    with mp.workdps(450):
        b=real(1e308)
        truth=mp.gamma(b+1)/mp.gamma(b+mp.mpf('1.5'))
        actual=point(p,[1.]).fractional_rhs[0,0]
        cell=cells(p,[0.,1.]).model_lower[0,0]
        assert abs(real(actual)/truth-1)<mp.mpf('2e-12')
        assert abs(real(-cell)/truth-1)<mp.mpf('2e-12')
        results.append({'case':'repaired beta=1e308','point':float(actual),'cell_lower':float(cell),
                        'reference':mp.nstr(truth,80),'original_overflow_expectation_replaced_with_independent_oracle':True})
    return results
check('finite-input-nonfinite-arithmetic-fails-closed',numerical_overflow_guards)"""
assert source.count(needle)==1
source=source.replace(needle,replacement)
source=source.replace("'6e7a156f025e08b31a314c5bda59183d6a96bf32'","'8dcbfafd1a5373088e75437551692a85fd7f7b77'")
source=source.replace("(OUT/'independent-results.json')","(OUT/'complete-scope-controls.json')")
(OUT/'complete_scope_controls.py').write_text(source)
(OUT/'controls-adaptation.patch').write_text(''.join(difflib.unified_diff(original.decode().splitlines(True),source.splitlines(True),fromfile='preserved-original/independent_probes.py',tofile='complete_scope_controls.py')))
(OUT/'controls-adaptation.json').write_text(json.dumps({'original_path':str(PREVIOUS),'original_sha256':hashlib.sha256(original).hexdigest(),'copy_sha256':hashlib.sha256(source.encode()).hexdigest(),'changes':['Redirect ROOT to immutable scratch snapshot and label corrected tree.','Separate output path.','Old beta=1e308 overflow expectation now replaced with mp450 finite-value point/cell checks: Pochhammer repair legitimately removes old gammaln overflow.','Other oracle logic, tolerances, shape guards, matrix tests and history/under-enclosure assertions unchanged.'],'scope':'reused independent-control harness, explicitly adapted, not new historical evidence'},indent=2)+'\n')
print(json.dumps({'copied_driver':str(OUT/'complete_scope_controls.py'),'original_sha256':hashlib.sha256(original).hexdigest(),'adapted_sha256':hashlib.sha256(source.encode()).hexdigest()},indent=2))
