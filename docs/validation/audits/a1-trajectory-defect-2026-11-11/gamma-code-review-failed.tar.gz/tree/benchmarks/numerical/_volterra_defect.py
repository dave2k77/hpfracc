"""Private host-only PL Volterra-defect diagnostics; never a certificate.

This benchmark module is not a solver, controller, public API or differentiable
numerical path. Ordinary NumPy/SciPy float64 evaluation is deliberately separate
from the working precision of the stored trajectory. Input, evaluation and output
roundoff are not enclosed. No result certifies a numerical solution.
"""

from dataclasses import dataclass, field

import numpy as np
import scipy
from scipy.special import gamma, poch

from hpfracc.config import Provenance, RuntimeTarget


@dataclass(frozen=True, slots=True)
class DefectEvaluation:
    evaluation_times: np.ndarray
    reconstruction: np.ndarray
    fractional_rhs: np.ndarray
    defect: np.ndarray
    provenance: Provenance
    arithmetic_verified: bool = field(default=False, init=False)
    total_numerical_certified: bool = field(default=False, init=False)

    def to_dict(self):
        return {
            "evaluation_times": self.evaluation_times.tolist(),
            "reconstruction": self.reconstruction.tolist(),
            "fractional_rhs": self.fractional_rhs.tolist(),
            "defect": self.defect.tolist(),
            "provenance": self.provenance.to_dict(),
            "arithmetic_verified": self.arithmetic_verified,
            "total_numerical_certified": self.total_numerical_certified,
        }


def _real_array(name, value):
    raw = np.asarray(value)
    if (raw.dtype.kind != "f" or raw.dtype.itemsize not in (4, 8)
            or not np.all(np.isfinite(raw))):
        raise ValueError(f"Expected finite real float32/float64 {name}")
    return np.array(raw, dtype=np.float64, copy=True)


@dataclass(frozen=True, slots=True)
class _Inputs:
    ts: np.ndarray
    states: np.ndarray
    targets: np.ndarray
    order: float
    matrix: np.ndarray
    initial: np.ndarray
    powers: np.ndarray
    coefficients: np.ndarray
    input_dtype: str


def _prepare(ts, states, evaluation_times, order, matrix, initial_state,
             power_exponents, power_coefficients):
    input_dtype = str(np.asarray(states).dtype)
    ts = _real_array("ts", ts)
    states = _real_array("states", states)
    targets = _real_array("evaluation_times", evaluation_times)
    alpha = _real_array("order", order)
    matrix = _real_array("matrix", matrix)
    initial = _real_array("initial_state", initial_state)
    powers = _real_array("power_exponents", power_exponents)
    if alpha.ndim != 0 or not 0 < float(alpha) < 1:
        raise ValueError("Expected scalar 0 < order < 1")
    if ts.ndim != 1 or ts.size < 2 or not np.all(ts[1:] > ts[:-1]):
        raise ValueError("Expected at least two strictly increasing times")
    if states.ndim != 2 or states.shape[0] != ts.size or states.shape[1] < 1:
        raise ValueError("Expected states shape (time, state_dim), state_dim >= 1")
    d = states.shape[1]
    if matrix.shape != (d, d):
        raise ValueError("Expected square matrix matching state_dim")
    if initial.shape != (d,) or not np.array_equal(initial, states[0]):
        raise ValueError("Expected initial_state to match the first stored state")
    if (targets.ndim != 1 or targets.size == 0
            or np.any(targets < ts[0]) or np.any(targets > ts[-1])):
        raise ValueError("Expected evaluation times within the stored horizon")
    if powers.ndim != 1 or np.any(powers < 0):
        raise ValueError("Expected one-dimensional nonnegative power_exponents")
    if power_coefficients is None:
        coefficients = np.empty((0, d), dtype=np.float64)
    else:
        coefficients = _real_array("power_coefficients", power_coefficients)
    if coefficients.shape != (powers.size, d):
        raise ValueError("Expected power_coefficients shape (power, state_dim)")
    return _Inputs(ts, states, targets, float(alpha), matrix, initial,
                   powers, coefficients, input_dtype)


def _power_integral_ratio(beta, alpha):
    """Gamma(beta+1)/Gamma(beta+alpha+1), without subtracting large log-gammas."""
    return 1. / poch(beta + 1, alpha)


def affine_power_defect(ts, states, evaluation_times, *, order, matrix,
                        initial_state, power_exponents=(), power_coefficients=None):
    """Evaluate Y-y0-I**alpha(A Y + sum c_beta*(t-t0)**beta).

    State shape is (time, state_dim); all old knots and the original lower
    terminal are retained. Nonnegative powers include weak forcing with beta<1.
    Inputs must be finite real float32/float64 arrays/scalars. Evaluation widens
    represented inputs to float64 before RHS arithmetic; it is host-only and
    does not verify arithmetic or provide a continuous-solution error bound.
    """
    p = _prepare(ts, states, evaluation_times, order, matrix, initial_state,
                 power_exponents, power_coefficients)
    ts, states, targets, a = p.ts, p.states, p.targets, p.order
    with np.errstate(over="raise", invalid="raise", divide="raise"):
        slopes = np.diff(states, axis=0) / np.diff(ts)[:, None]
        jumps = np.diff(slopes, axis=0)
        tau = targets - ts[0]
        positive = np.maximum(targets[:, None] - ts[1:-1], 0)
        reconstruction = states[0] + tau[:, None] * slopes[0] + positive @ jumps
        integral = (tau[:, None] ** a * states[0] / gamma(a + 1)
                    + (tau[:, None] ** (a + 1) * slopes[0]
                       + positive ** (a + 1) @ jumps) / gamma(a + 2))
        factors = (tau[:, None] ** (a + p.powers)
                   * _power_integral_ratio(p.powers, a))
        rhs = integral @ p.matrix.T + factors @ p.coefficients
        defect = reconstruction - p.initial - rhs
    if not all(np.all(np.isfinite(x)) for x in (reconstruction, rhs, defect)):
        raise FloatingPointError("Nonfinite defect evaluation")
    provenance = Provenance(
        backend="numpy/scipy", runtime_target=RuntimeTarget.CPU,
        config={"scope": "private PL affine-power defect diagnostic",
                "arithmetic": "float64; unverified",
                "input_state_dtype": p.input_dtype, "order": a,
                "numpy_version": np.__version__, "scipy_version": scipy.__version__},
    )
    return DefectEvaluation(targets, reconstruction, rhs, defect, provenance)


@dataclass(frozen=True, slots=True)
class DefectCells:
    """Floating diagnostics of an enclosing real-arithmetic expression.

    These computed endpoints need not enclose even a single exact residual:
    gamma/power/coefficient/summation roundoff is not budgeted or directed.
    """

    verification_times: np.ndarray
    model_lower: np.ndarray
    model_upper: np.ndarray
    provenance: Provenance
    arithmetic_verified: bool = field(default=False, init=False)
    total_numerical_certified: bool = field(default=False, init=False)

    def to_dict(self):
        return {
            "verification_times": self.verification_times.tolist(),
            "model_lower": self.model_lower.tolist(),
            "model_upper": self.model_upper.tolist(),
            "provenance": self.provenance.to_dict(),
            "arithmetic_verified": self.arithmetic_verified,
            "total_numerical_certified": self.total_numerical_certified,
        }


def _defect_terms(p):
    """Complete signed finite-power formula; no history truncation or reset."""
    a = p.order
    slopes = np.diff(p.states, axis=0) / np.diff(p.ts)[:, None]
    jumps = np.diff(slopes, axis=0)
    yield p.ts[0], 1., slopes[0]
    for t, jump in zip(p.ts[1:-1], jumps, strict=True):
        yield t, 1., jump
    yield p.ts[0], a, -(p.matrix @ p.states[0]) / gamma(a + 1)
    yield p.ts[0], a + 1, -(p.matrix @ slopes[0]) / gamma(a + 2)
    for t, jump in zip(p.ts[1:-1], jumps, strict=True):
        yield t, a + 1, -(p.matrix @ jump) / gamma(a + 2)
    for beta, coefficient in zip(p.powers, p.coefficients, strict=True):
        ratio = _power_integral_ratio(beta, a)
        yield p.ts[0], a + beta, -coefficient * ratio


def affine_power_cells(ts, states, verification_mesh, *, order, matrix,
                       initial_state, power_exponents=(), power_coefficients=None,
                       max_work=1_000_000):
    """Evaluate unverified natural-extension model ranges on continuum cells.

    The supplied mesh must cover the whole original horizon; all original knots
    are added. Positive powers are monotone and coefficient signs select each
    term's extreme in real arithmetic. No sampled maximum is substituted. The
    resulting floating endpoints are NOT verified numerical enclosures, and no
    feedback propagation or solution-error interpretation is provided here.
    max_work caps cell-term-component evaluations and fails explicitly; it is
    not a measured memory/runtime limit and never authorizes truncating history.
    """
    p = _prepare(ts, states, verification_mesh, order, matrix, initial_state,
                 power_exponents, power_coefficients)
    if (p.targets.size < 2 or not np.all(p.targets[1:] > p.targets[:-1])
            or p.targets[0] != p.ts[0] or p.targets[-1] != p.ts[-1]):
        raise ValueError("Expected increasing verification mesh covering the horizon")
    edges = np.union1d(p.ts, p.targets)
    if type(max_work) is not int or max_work <= 0:
        raise ValueError("Expected positive integer max_work")
    term_count = 3 + 2 * (p.ts.size - 2) + p.powers.size
    work = (edges.size - 1) * term_count * p.states.shape[1]
    if work > max_work:
        raise ValueError(f"Cell work budget exhausted: {work} > {max_work}")
    lower = np.zeros((edges.size - 1, p.states.shape[1]), dtype=np.float64)
    upper = np.zeros_like(lower)
    with np.errstate(over="raise", invalid="raise", divide="raise"):
        for origin, power, coefficient in _defect_terms(p):
            left = np.maximum(edges[:-1] - origin, 0) ** power
            right = np.maximum(edges[1:] - origin, 0) ** power
            x, y = left[:, None] * coefficient, right[:, None] * coefficient
            lower += np.minimum(x, y)
            upper += np.maximum(x, y)
    if not np.all(np.isfinite(lower)) or not np.all(np.isfinite(upper)):
        raise FloatingPointError("Nonfinite cell-range evaluation")
    provenance = Provenance(
        backend="numpy/scipy", runtime_target=RuntimeTarget.CPU,
        config={"scope": "private PL affine-power cell diagnostic",
                "arithmetic": "float64; unverified; no outward rounding",
                "range_method": "complete signed natural extension",
                "cell_term_components": work, "max_work": max_work,
                "input_state_dtype": p.input_dtype, "order": p.order,
                "numpy_version": np.__version__, "scipy_version": scipy.__version__},
    )
    return DefectCells(edges, lower, upper, provenance)
