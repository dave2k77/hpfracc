"""Capture immutable Git bytes and separate historical failure; scratch writes only."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=Path(__file__).resolve().parent
TREE='8dcbfafd1a5373088e75437551692a85fd7f7b77'
OLD='6e7a156f025e08b31a314c5bda59183d6a96bf32'
BASE='74d8f08c01179115c2752da5604a9cd85bba89bc'
PREVIOUS=Path('/home/davianc/.hermes/cache/scratch/a1-independent-code-review-rznn_1kr')
AUDIT='docs/validation/audits/a1-trajectory-defect-2026-11-11/'
PATHS=['benchmarks/numerical/_volterra_defect.py','tests/unit/test_volterra_defect.py',AUDIT+'frozen-fixtures.json']
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT)
def dump(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
assert git('cat-file','-t',TREE).strip()==b'tree'
changed=git('diff','--name-only',BASE,TREE).decode().splitlines()
assert set(changed)==set(PATHS)
delta=git('diff','--no-ext-diff',OLD,TREE)
(OUT/'repair-delta.patch').write_bytes(delta)
full=git('diff','--no-ext-diff',BASE,TREE)
(OUT/'complete-three-file.patch').write_bytes(full)
added=[s[1:] for s in full.decode().splitlines() if s.startswith('+') and not s.startswith('+++')]
patterns={'literal_credentials':r'''(?i)(api_key|secret|password|token|passwd)\s*=\s*['\"][^'\"]{6,}['\"]''','shell':r'os\.system\(|subprocess.*shell\s*=\s*True','dynamic_execution':r'\beval\(|\bexec\(','pickle':r'pickle\.loads?\(','sql':r'''execute\(f["']|\.format\(.*SELECT|\.format\(.*INSERT'''}
findings=[{'rule':k,'line':i+1,'text':s} for k,p in patterns.items() for i,s in enumerate(added) if re.search(p,s)]
dump('static-scan.json',{'tree':TREE,'added_lines':len(added),'findings':findings,'diff_sha256':sha(full)})
entries={}
for row in git('ls-tree','-r','-z',TREE).split(b'\0'):
    if row:
        header,p=row.split(b'\t',1)
        mode,kind,oid=header.decode().split()
        entries[p.decode()]={'mode':mode,'kind':kind,'oid':oid}
selected=[p for p in entries if p.startswith(('src/','tests/','benchmarks/')) or p in ('AGENTS.md','pyproject.toml','uv.lock','v0.1_engineering_contract.md') or p==PATHS[-1]]
records={}
for p in selected:
    data=git('show',TREE+':'+p)
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==entries[p]['oid']
    dest=OUT/'tree'/p
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
    records[p]={**entries[p],'sha256':sha(data),'bytes':len(data),'worktree_matches':(ROOT/p).read_bytes()==data}
old_dest=OUT/'old-tree'/PATHS[0]
old_dest.parent.mkdir(parents=True,exist_ok=True)
old_dest.write_bytes(git('show',OLD+':'+PATHS[0]))
(OUT/'preserved-original').mkdir()
originals={}
for n in ('initial-review-verdict.json','initial-review-evidence-index.json','blocking-large-power.json','blocking_large_power_probe.py'):
    data=(PREVIOUS/n).read_bytes()
    (OUT/'preserved-original'/n).write_bytes(data)
    originals[n]={'original_path':str(PREVIOUS/n),'sha256':sha(data),'bytes':len(data)}
# Replay the original reproducer without depending on today's Git index.
source=(PREVIOUS/'blocking_large_power_probe.py').read_text()
source=source.replace("source=git('show',':'+PATH)\nfrozen=git('show',TREE+':'+PATH)\nassert source==frozen,'Index changed; refusing to attribute non-frozen source to initial tree'", "# ADAPTATION: immutable old-tree bytes replace the historical index identity gate.\nsource=git('show',TREE+':'+PATH)\nfrozen=source")
source=source.replace("module.__file__='git-index:'+PATH", "module.__file__='git-tree:'+TREE+':'+PATH")
source=source.replace("assert git('show',':'+PATH)==source,'Staged source changed during probe'", "assert git('show',TREE+':'+PATH)==source,'Immutable old-tree bytes changed'")
source=source.replace("'source':'exact index bytes independently compared to frozen-tree blob'", "'source':'ADAPTED replay: immutable old-tree blob; no current-index assertion or historical timing claim'")
source=source.replace("(OUT/'blocking-large-power.json')", "(OUT/'old-tree-failure-replay.json')")
(OUT/'old_failure_replay.py').write_text(source)
dump('harness-adaptation.json',{'original_driver':str(PREVIOUS/'blocking_large_power_probe.py'),'original_sha256':originals['blocking_large_power_probe.py']['sha256'],'adapted_driver':'old_failure_replay.py','adapted_sha256':sha(source.encode()),'changes':'Only driver source selection, identity gate, output path and descriptive label; numerical probes/assertions unchanged. Old tree is immutable, never restored into index.','preserved_original_files':originals})
snapshot=json.loads((ROOT/AUDIT/'source-snapshot.json').read_text())
snapshot_mismatch=[p for p,h in snapshot['paths'].items() if sha(git('show',TREE+':'+p))!=h]
archive_mismatch=[]
with tarfile.open(ROOT/AUDIT/'source-snapshot.tar.gz','r:gz') as tf:
    members=[m for m in tf.getmembers() if m.isfile()]
    for m in members:
        assert not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
        if tf.extractfile(m).read()!=git('show',TREE+':'+m.name): archive_mismatch.append(m.name)
assert len(snapshot['paths'])==snapshot['count']==len(members)==125
assert not snapshot_mismatch and not archive_mismatch
assert all(r['worktree_matches'] for r in records.values())
index_path=Path(git('rev-parse','--git-path','index').decode().strip())
if not index_path.is_absolute(): index_path=ROOT/index_path
index=git('ls-files','--stage','-z')
dump('identity-before.json',{'reviewed_tree':TREE,'old_tree':OLD,'baseline':BASE,'three_changed_paths':changed,'source_and_config_unchanged_from_baseline':not bool(git('diff',BASE,TREE,'--','src','pyproject.toml','uv.lock')),'copied_file_count':len(records),'files':records,'index_sha256':sha(index_path.read_bytes()),'index_entries_sha256':sha(index),'source_snapshot_count':snapshot['count'],'source_snapshot_mismatches':snapshot_mismatch,'source_archive_mismatches':archive_mismatch,'source_snapshot_sha256':sha((ROOT/AUDIT/'source-snapshot.json').read_bytes()),'source_archive_sha256':sha((ROOT/AUDIT/'source-snapshot.tar.gz').read_bytes()),'original_preserved':originals})
print(json.dumps({'out':str(OUT),'tree':TREE,'snapshot_files':len(records),'parent_archive_files':len(members),'static_findings':findings,'repair_delta_sha256':sha(delta),'changed':changed},indent=2))
