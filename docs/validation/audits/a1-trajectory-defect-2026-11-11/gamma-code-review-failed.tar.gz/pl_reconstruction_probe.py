"""Check represented PL nodal reconstruction without feedback or forcing."""
import hashlib
import json
from pathlib import Path
import sys
import types

import mpmath as mp
import numpy as np

OUT=Path(__file__).resolve().parent
PATH='benchmarks/numerical/_volterra_defect.py'
records=[]
for tree,folder in [('6e7a156f025e08b31a314c5bda59183d6a96bf32','old-tree'),('8dcbfafd1a5373088e75437551692a85fd7f7b77','tree')]:
    source=(OUT/folder/PATH).read_bytes()
    mod=types.ModuleType('pl_'+folder.replace('-','_')); mod.__file__=str(OUT/folder/PATH)
    sys.modules[mod.__name__]=mod
    exec(compile(source,mod.__file__,'exec'),mod.__dict__)
    for epsilon in [1e-16,1e-17,1e-20]:
        ts=np.array([0.,epsilon,1.])
        states=np.array([[0.],[1.],[1.]])
        targets=np.array([epsilon,.5,1.])
        result=mod.affine_power_defect(ts,states,targets,order=.5,matrix=np.zeros((1,1)),initial_state=np.zeros(1))
        expected=np.ones((3,1))
        # On the final panel both endpoints are exactly 1: true PL is identically 1.
        with mp.workdps(100):
            n,d=float(epsilon).as_integer_ratio()
            left=mp.mpf(n)/d
            refs=[mp.mpf(1)+(mp.mpf(float(t))-left)*(mp.mpf(1)-1)/(1-left) for t in targets]
            assert all(x==1 for x in refs)
        rows={'tree':tree,'source_sha256':hashlib.sha256(source).hexdigest(),'epsilon_hex':epsilon.hex(),'ts':ts.tolist(),'states':states.tolist(),'targets':targets.tolist(),'expected_reconstruction':expected.tolist(),'observed_reconstruction':result.reconstruction.tolist(),'observed_fractional_rhs':result.fractional_rhs.tolist(),'observed_defect':result.defect.tolist(),'max_absolute_reconstruction_error':float(np.max(np.abs(result.reconstruction-expected))),'arithmetic_verified':result.arithmetic_verified,'total_numerical_certified':result.total_numerical_certified}
        records.append(rows)
report={'passed':all(r['max_absolute_reconstruction_error']<1e-14 for r in records),'records':records,'issue':'Global slope-jump summation catastrophically cancels a finite, simple represented PL state on nonuniform panels. No forcing, feedback, gamma-ratio coefficient or high-precision-input ambiguity is involved.','locations':['benchmarks/numerical/_volterra_defect.py:116-120'],'a1_acceptance_passed':False}
(OUT/'blocking-pl-reconstruction.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2))
sys.exit(0 if report['passed'] else 1)
