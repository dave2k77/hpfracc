"""Independent immutable-tree coefficient and dynamic-range checks, no test helpers.

Comparison tolerances are point/oracle checks, not error or certification budgets.
Large-beta reference precision increases with beta and is checked at two precisions.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import traceback
import types

import mpmath as mp
import numpy as np

OUT=Path(__file__).resolve().parent
TREE='8dcbfafd1a5373088e75437551692a85fd7f7b77'
PATH='benchmarks/numerical/_volterra_defect.py'

def load(path,name):
    source=path.read_bytes()
    module=types.ModuleType(name)
    module.__file__=str(path)
    sys.modules[name]=module
    exec(compile(source,str(path),'exec'),module.__dict__)
    return module
impl=load(OUT/'tree'/PATH,'corrected_immutable')
old=load(OUT/'old-tree'/PATH,'original_immutable')
def exact(x):
    n,d=float(x).as_integer_ratio()
    return mp.mpf(n)/d

def problem(beta,alpha,coefficient=1.,dtype=np.float64):
    return dict(ts=np.array([0.,1.],dtype=dtype),states=np.zeros((2,1),dtype=dtype),order=dtype(alpha),matrix=np.zeros((1,1),dtype=dtype),initial_state=np.zeros(1,dtype=dtype),power_exponents=np.array([beta],dtype=dtype),power_coefficients=np.array([[coefficient]],dtype=dtype))
def evaluate(module,p,t=1.):
    point=module.affine_power_defect(**p,evaluation_times=np.array([t]))
    cell=module.affine_power_cells(**p,verification_mesh=np.array([0.,t,1.]) if t<1 else np.array([0.,1.]))
    prepared=module._prepare(p['ts'],p['states'],np.array([0.,1.]),p['order'],p['matrix'],p['initial_state'],p['power_exponents'],p['power_coefficients'])
    last=list(module._defect_terms(prepared))[-1]
    assert point.arithmetic_verified is point.total_numerical_certified is False
    assert cell.arithmetic_verified is cell.total_numerical_certified is False
    return point,cell,last

checks=[]
details={}
def check(name,f):
    try:
        value=f()
        checks.append({'name':name,'passed':True})
        details[name]=value
    except Exception as exc:
        checks.append({'name':name,'passed':False,'error_type':type(exc).__name__,'message':str(exc)})
        details[name]={'traceback':traceback.format_exc()}


def coefficients():
    rows=[]
    betas=[0.,np.spacing(1.),.1,.25,.999,1.,2.,3.,10.,99.,999.,1e4,1e6,1e12,1e16,1e100,1e300,np.finfo(float).max]
    alphas=[np.nextafter(0.,1.),.01,.3,.5,.75,.99,np.nextafter(1.,0.)]
    for dtype in (np.float64,np.float32):
        for beta in betas:
            if dtype is np.float32 and beta>np.finfo(np.float32).max: continue
            for alpha in alphas:
                represented_alpha=dtype(alpha)
                if not 0<float(represented_alpha)<1: continue
                p=problem(beta,alpha,dtype=dtype)
                b=float(p['power_exponents'][0]); a=float(p['order'])
                precision=max(100,int(np.log10(b))+100 if b>=1 else 100)
                with mp.workdps(precision):
                    mb,ma=exact(b),exact(a)
                    ref=mp.exp(mp.loggamma(mb+1)-mp.loggamma(mb+ma+1))
                with mp.workdps(precision+50):
                    mb,ma=exact(b),exact(a)
                    ref2=mp.gamma(mb+1)/mp.gamma(mb+ma+1)
                    assert abs(ref/ref2-1)<mp.mpf('1e-70')
                    point,cell,last=evaluate(impl,p)
                    values=[float(point.fractional_rhs[0,0]),-float(last[2][0]),-float(cell.model_lower[0,0])]
                    errors=[float(abs(exact(x)/ref2-1)) for x in values]
                    row={'input_dtype':np.dtype(dtype).name,'beta_hex':b.hex(),'alpha_hex':a.hex(),'mp_dps':precision+50,'reference':mp.nstr(ref2,70),'point':values[0],'signed_term_coefficient':-values[1],'cell_lower':-values[2],'relative_errors':errors,'arithmetic':'host float64 after represented-input widening'}
                    rows.append(row)
    (OUT/'coefficient-cases.json').write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
    failed=[r for r in rows if max(r['relative_errors'])>2e-12]
    assert not failed,failed
    return {'cases':len(rows),'max_relative_error':max(max(r['relative_errors']) for r in rows),'atol':0,'rtol':2e-12,'reference':'exact binary inputs; log-Gamma difference and direct Gamma quotient at increased precision agree to 70 decimal digits','rows':'coefficient-cases.json'}
check('independent-wide-range-point-cell-and-term-coefficients',coefficients)


def repaired_original_nine():
    rows=[]
    for alpha in [.3,.5,.75]:
        for beta in [1e16,1e100,1e300]:
            p=problem(beta,alpha)
            before=evaluate(old,p); after=evaluate(impl,p)
            with mp.workdps(int(np.log10(beta))+150):
                b,a=exact(beta),exact(alpha)
                truth=mp.gamma(b+1)/mp.gamma(b+a+1)
                original_error=float(abs(exact(before[0].fractional_rhs[0,0])/truth-1))
                repaired_error=float(abs(exact(after[0].fractional_rhs[0,0])/truth-1))
            assert original_error>1e3 and repaired_error<2e-12
            assert after[1].model_lower[0,0]==-after[0].fractional_rhs[0,0]
            rows.append({'alpha':alpha,'beta':beta,'old_point':float(before[0].fractional_rhs[0,0]),'old_relative_error':original_error,'new_point':float(after[0].fractional_rhs[0,0]),'new_cell_lower':float(after[1].model_lower[0,0]),'new_relative_error':repaired_error})
    return rows
check('original-nine-both-paths-red-to-green',repaired_original_nine)


def dynamic_range():
    rows=[]
    # Every exact final forcing contribution below is finite and representable.
    for beta,coefficient,t in [(1000.,1e308,.5),(1100.,1e308,.5),(1200.,1e308,.5),(1000.,1e-300,1.),(2000.,1e308,.75)]:
        p=problem(beta,.5,coefficient)
        with mp.workdps(160):
            b,a,c,mt=exact(beta),exact(.5),exact(coefficient),exact(t)
            reference=c*mp.gamma(b+1)/mp.gamma(b+a+1)*mt**(b+a)
            point,cells,last=evaluate(impl,p,t)
            actual=float(point.fractional_rhs[0,0])
            endpoint=-float(cells.model_lower[0,0])
            expected=float(reference)
            rel=float(abs(exact(actual)/reference-1))
            cellrel=float(abs(exact(endpoint)/reference-1))
            rows.append({'beta':beta,'coefficient':coefficient,'target':t,'expected_fractional_rhs':expected,'mp_reference':mp.nstr(reference,80),'observed_fractional_rhs':actual,'first_cell_lower':-endpoint,'point_relative_error':rel,'cell_relative_error':cellrel,'signed_forcing_coefficient':float(last[2][0]),'all_final_outputs_finite':bool(np.isfinite(actual) and np.isfinite(endpoint)),'arithmetic_verified':point.arithmetic_verified,'total_numerical_certified':point.total_numerical_certified})
    (OUT/'dynamic-range-cases.json').write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
    bad=[r for r in rows if max(r['point_relative_error'],r['cell_relative_error'])>2e-12]
    assert not bad,{'catastrophic_cases':bad,'issue':'premature time-power underflow before finite large coefficient scaling; false flags do not repair a point value'}
    return rows
check('finite-final-result-dynamic-range-controls',dynamic_range)

report={'reviewed_tree':TREE,'source_sha256':hashlib.sha256((OUT/'tree'/PATH).read_bytes()).hexdigest(),'old_source_sha256':hashlib.sha256((OUT/'old-tree'/PATH).read_bytes()).hexdigest(),'checks':checks,'details':details,'passed':all(r['passed'] for r in checks),'arithmetic':'unverified host float64, no full-suite/GPU/JIT/AD/certificate claim','a1_acceptance_passed':False}
(OUT/'independent-results.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'checks':checks,'details':{k:v for k,v in details.items() if not isinstance(v,list)},'passed':report['passed']},indent=2))
sys.exit(0 if report['passed'] else 1)
