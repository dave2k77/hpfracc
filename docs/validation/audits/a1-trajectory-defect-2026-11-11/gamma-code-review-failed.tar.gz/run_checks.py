"""Frozen-uv CPU checks; outputs scratch-only with kernel write confinement."""
import ctypes
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=Path(__file__).resolve().parent
SNAP=OUT/'tree'

def sandbox():
    # Landlock handles writes only: global reads remain available; writes confined.
    libc=ctypes.CDLL(None,use_errno=True)
    class Ruleset(ctypes.Structure): _fields_=[('handled_access_fs',ctypes.c_uint64)]
    class PathBeneath(ctypes.Structure):
        _pack_=1
        _fields_=[('allowed_access',ctypes.c_uint64),('parent_fd',ctypes.c_int32)]
    abi=libc.syscall(444,0,0,1)
    if abi<3: raise RuntimeError('Need Landlock ABI>=3 for scratch-only writes')
    access=sum(1<<b for b in [1,4,5,6,7,8,9,10,11,12,13,14])
    rules=Ruleset(access)
    fd=libc.syscall(444,ctypes.byref(rules),ctypes.sizeof(rules),0)
    if fd<0: raise OSError(ctypes.get_errno(),'landlock_create_ruleset')
    for path,rights in [(str(OUT),access),('/dev/null',(1<<1)|(1<<14))]:
        pfd=os.open(path,os.O_PATH|os.O_CLOEXEC)
        rule=PathBeneath(rights,pfd)
        if libc.syscall(445,fd,1,ctypes.byref(rule),0)<0: raise OSError(ctypes.get_errno(),'landlock_add_rule')
        os.close(pfd)
    if libc.prctl(38,1,0,0,0)<0: raise OSError(ctypes.get_errno(),'no_new_privs')
    if libc.syscall(446,fd,0)<0: raise OSError(ctypes.get_errno(),'landlock_restrict_self')
    os.close(fd)

ENV=os.environ.copy()
ENV.pop('UV_PROJECT_ENVIRONMENT',None)
ENV.update({'PYTHONDONTWRITEBYTECODE':'1','JAX_PLATFORMS':'cpu','JAX_ENABLE_X64':'false',
 'XLA_PYTHON_CLIENT_PREALLOCATE':'false','UV_NO_SYNC':'1','RUFF_NO_CACHE':'true',
 'TMPDIR':str(OUT/'tmp'),'XDG_CACHE_HOME':str(OUT/'cache'),'UV_CACHE_DIR':str(OUT/'cache/uv'),
 'JAX_COMPILATION_CACHE_DIR':str(OUT/'jax-cache'),'HYPOTHESIS_STORAGE_DIRECTORY':str(OUT/'hypothesis'),
 'PYTHONPATH':str(SNAP)+os.pathsep+str(SNAP/'src')})
for name in ('tmp','cache','jax-cache','hypothesis'): (OUT/name).mkdir(exist_ok=True)
PREFIX=['uv','run','--frozen','--extra','dev','--no-sync']
commands={
 'targeted':PREFIX+['python','-m','pytest','-q','-p','no:cacheprovider','--basetemp',str(OUT/'pytest-tmp'),'--junitxml',str(OUT/'targeted.xml'),str(SNAP/'tests/unit/test_volterra_defect.py')],
 'lint':PREFIX+['ruff','check','--no-cache',str(SNAP/'benchmarks/numerical/_volterra_defect.py'),str(SNAP/'tests/unit/test_volterra_defect.py')],
 'independent':PREFIX+['python',str(OUT/'independent_checks.py')],
 'old-replay':PREFIX+['python',str(OUT/'old_failure_replay.py')],
 'feedback':PREFIX+['python',str(OUT/'pl_feedback_probe.py')],
 'pl':PREFIX+['python',str(OUT/'pl_reconstruction_probe.py')],
 'blocker':PREFIX+['python',str(OUT/'blocking_underflow_reproducer.py')],
 'controls':PREFIX+['python',str(OUT/'complete_scope_controls.py')],
 'runtime':PREFIX+['python','-c','import json,sys,platform,jax,numpy,scipy,mpmath,hpfracc; print(json.dumps(dict(python=sys.version,system=platform.platform(),jax=jax.__version__,numpy=numpy.__version__,scipy=scipy.__version__,mpmath=mpmath.__version__,devices=[str(d) for d in jax.devices()],default_backend=jax.default_backend(),x64_enabled=jax.config.x64_enabled,hpfracc_path=hpfracc.__file__),indent=2))'],
}
for name in sys.argv[1:]:
    command=commands[name]
    start=time.monotonic()
    with (OUT/f'{name}.stdout.txt').open('w') as stdout,(OUT/f'{name}.stderr.txt').open('w') as stderr:
        r=subprocess.run(command,cwd=ROOT,env=ENV,stdout=stdout,stderr=stderr,timeout=300,preexec_fn=sandbox)
    record={'command':command,'cwd':str(ROOT),'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'writes':'Landlock ABI>=3 confined to new scratch dir and /dev/null','explicit_environment':{k:ENV[k] for k in ('JAX_PLATFORMS','JAX_ENABLE_X64','PYTHONPATH','PYTHONDONTWRITEBYTECODE','UV_NO_SYNC','TMPDIR')},'immutable_review_tree':'8dcbfafd1a5373088e75437551692a85fd7f7b77','full_suite_run':False,'platform':platform.machine()}
    (OUT/f'{name}.run.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record))
    print((OUT/f'{name}.stdout.txt').read_text())
    print((OUT/f'{name}.stderr.txt').read_text())
    if r.returncode: sys.exit(r.returncode)
