"""Independent blocking underflow reproducer: old and corrected immutable trees.

Run via run_checks.py blocker. Expected nonzero exit until production handles the
premature-underflow case. No source edits, precision promotion or tolerance slack.
"""
import hashlib
import json
from pathlib import Path
import sys
import types

import mpmath as mp
import numpy as np

OUT=Path(__file__).resolve().parent
PATH='benchmarks/numerical/_volterra_defect.py'

def module(folder,name):
    source=(OUT/folder/PATH).read_bytes()
    m=types.ModuleType(name)
    m.__file__=str(OUT/folder/PATH)
    sys.modules[name]=m
    exec(compile(source,m.__file__,'exec'),m.__dict__)
    return m,hashlib.sha256(source).hexdigest()

def exact(x):
    n,d=float(x).as_integer_ratio()
    return mp.mpf(n)/d

beta=1100.
alpha=.5
coefficient=1e300
with mp.workdps(180):
    b,a,c,t=map(exact,(beta,alpha,coefficient,.5))
    gamma_ratio=mp.gamma(b+1)/mp.gamma(b+a+1)
    recurrence=1/mp.gamma(a+1)
    for k in range(1,int(beta)+1): recurrence*=mp.mpf(k)/(k+a)
    expected=c*gamma_ratio*t**(b+a)
    recurrence_expected=c*recurrence*t**(b+a)
    # Independent kernel-removing quadrature: u=(t-s)^alpha.
    quadrature=mp.quad(lambda u:c*(t-u**(1/a))**b,[0,t**a/8,t**a/2,t**a])/mp.gamma(a+1)
    assert abs(recurrence_expected/expected-1)<mp.mpf('1e-160')
    assert abs(quadrature/expected-1)<mp.mpf('1e-140')
    reference={'precision_dps':180,'analytic':mp.nstr(expected,100),'integer_beta_recurrence':mp.nstr(recurrence_expected,100),'transformed_quadrature':mp.nstr(quadrature,100),'expected_binary64':float(expected),'gamma_ratio':mp.nstr(gamma_ratio,80),'reference_conversion':'exact represented float inputs via integer ratios'}

kwargs=dict(ts=np.array([0.,1.]),states=np.zeros((2,1)),order=alpha,matrix=np.zeros((1,1)),initial_state=np.zeros(1),power_exponents=np.array([beta]),power_coefficients=np.array([[coefficient]]))
records=[]
for tree,folder in [('6e7a156f025e08b31a314c5bda59183d6a96bf32','old-tree'),('8dcbfafd1a5373088e75437551692a85fd7f7b77','tree')]:
    impl,digest=module(folder,'underflow_'+folder.replace('-','_'))
    point=impl.affine_power_defect(**kwargs,evaluation_times=np.array([.5]))
    cells=impl.affine_power_cells(**kwargs,verification_mesh=np.array([0.,.5,1.]))
    detected={}
    for name,f in [('point',lambda:impl.affine_power_defect(**kwargs,evaluation_times=np.array([.5]))),('cells',lambda:impl.affine_power_cells(**kwargs,verification_mesh=np.array([0.,.5,1.])) )]:
        try:
            with np.errstate(under='raise'): f()
        except FloatingPointError as exc: detected[name]=str(exc)
        else: detected[name]='NOT detected'
    assert point.fractional_rhs[0,0]==point.defect[0,0]==0.
    assert cells.model_lower[0,0]==cells.model_upper[0,0]==0.
    assert point.arithmetic_verified is point.total_numerical_certified is False
    assert cells.arithmetic_verified is cells.total_numerical_certified is False
    records.append({'tree':tree,'source_sha256':digest,'point_rhs':point.fractional_rhs.tolist(),'point_defect':point.defect.tolist(),'cell_edges':cells.verification_times.tolist(),'cell_lower':cells.model_lower.tolist(),'cell_upper':cells.model_upper.tolist(),'all_outputs_finite':all(np.all(np.isfinite(v)) for v in [point.fractional_rhs,point.defect,cells.model_lower,cells.model_upper]),'explicit_outer_underflow_trap':detected,'arithmetic_verified':point.arithmetic_verified,'total_numerical_certified':point.total_numerical_certified,'point_relative_error':1.,'first_cell_true_right_defect':-reference['expected_binary64']})
report={'passed':False,'blocking_logic_error':True,'introduced_by_gamma_delta':False,'scope':'fresh issue in complete three-file host diagnostic, present in old and corrected immutable trees','inputs':{'ts':[0.,1.],'states':[[0.],[0.]],'alpha':alpha,'A':[[0.]],'initial_state':[0.],'beta':beta,'forcing_coefficient':coefficient,'point_target':.5,'verification_mesh':[0.,.5,1.]},'reference':reference,'results':records,'cause':'Time-power array underflows to zero before multiplication by the large finite forcing coefficient. The true final contribution is a normal representable binary64 number. Existing over/invalid/divide traps and isfinite checks do not detect loss to zero.','locations':['benchmarks/numerical/_volterra_defect.py:124-126','benchmarks/numerical/_volterra_defect.py:212-215'],'separation':'Not the accepted approximately 1.53e-17 rounding-only cell under-enclosure; this is 100% relative error in pointwise fractional_rhs as well as an incorrect zero cell range.','a1_acceptance_passed':False}
(OUT/'blocking-underflow.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2))
sys.exit(1)
