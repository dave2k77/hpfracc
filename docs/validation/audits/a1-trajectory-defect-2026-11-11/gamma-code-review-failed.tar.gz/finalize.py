"""Verify review identities and produce fail-closed verdict and hash manifest."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent
ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
TREE='8dcbfafd1a5373088e75437551692a85fd7f7b77'
OLD='6e7a156f025e08b31a314c5bda59183d6a96bf32'
BASE='74d8f08c01179115c2752da5604a9cd85bba89bc'
MODULE='benchmarks/numerical/_volterra_defect.py'
TEST='tests/unit/test_volterra_defect.py'
FIXTURE='docs/validation/audits/a1-trajectory-defect-2026-11-11/frozen-fixtures.json'

def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT)
def load(name): return json.loads((OUT/name).read_text())
def dump(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
def handle(name):
    data=(OUT/name).read_bytes()
    return {'path':str(OUT/name),'sha256':sha(data),'bytes':len(data)}

before=load('identity-before.json')
work_mismatch=[]; snapshot_mismatch=[]; git_mismatch=[]
for p,row in before['files'].items():
    if sha((ROOT/p).read_bytes())!=row['sha256']: work_mismatch.append(p)
    if sha((OUT/'tree'/p).read_bytes())!=row['sha256']: snapshot_mismatch.append(p)
    if sha(git('show',TREE+':'+p))!=row['sha256']: git_mismatch.append(p)
assert not work_mismatch and not snapshot_mismatch and not git_mismatch
index_path=Path(git('rev-parse','--git-path','index').decode().strip())
if not index_path.is_absolute(): index_path=ROOT/index_path
index_unchanged=sha(index_path.read_bytes())==before['index_sha256']
index_entries_unchanged=sha(git('ls-files','--stage','-z'))==before['index_entries_sha256']
assert index_unchanged and index_entries_unchanged
original_mismatch=[]
for name,row in before['original_preserved'].items():
    if sha(Path(row['original_path']).read_bytes())!=row['sha256']: original_mismatch.append(name)
    if sha((OUT/'preserved-original'/name).read_bytes())!=row['sha256']: original_mismatch.append('copy:'+name)
assert not original_mismatch
assert sha((OUT/'tree'/FIXTURE).read_bytes())=='63311bcecc3c31458df93b0c1079d0cec1d8cbc64ee1155abc07b028e9f9aaef'
assert git('show',TREE+':'+FIXTURE)==git('show',OLD+':'+FIXTURE)
old_test=ast.parse(git('show',OLD+':'+TEST).decode())
new_test=ast.parse(git('show',TREE+':'+TEST).decode())
old_functions={n.name:ast.dump(n,include_attributes=False) for n in old_test.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
new_functions={n.name:ast.dump(n,include_attributes=False) for n in new_test.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
assert all(new_functions[k]==v for k,v in old_functions.items())
new_names=set(new_functions)-set(old_functions)
assert new_names=={'test_large_finite_power_gamma_ratio_does_not_cancel_to_one'}
new_module=ast.parse(git('show',TREE+':'+MODULE).decode())
old_module=ast.parse(git('show',OLD+':'+MODULE).decode())
old_nodes={n.name:ast.dump(n,include_attributes=False) for n in old_module.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new_nodes={n.name:ast.dump(n,include_attributes=False) for n in new_module.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
unchanged_nodes=[k for k,v in old_nodes.items() if new_nodes[k]==v]
assert set(old_nodes)-set(unchanged_nodes)=={'affine_power_defect','_defect_terms'}
assert '_prepare' in unchanged_nodes and '_real_array' in unchanged_nodes
suites=list(ET.parse(OUT/'targeted.xml').getroot().iter('testsuite'))
cases=list(ET.parse(OUT/'targeted.xml').getroot().iter('testcase'))
counts={k:sum(int(s.get(k,'0')) for s in suites) for k in ('tests','failures','errors','skipped')}
assert counts=={'tests':64,'failures':0,'errors':0,'skipped':0} and len(cases)==64
assert sum(c.get('name','').startswith('test_large_finite_power_gamma_ratio') for c in cases)==9
runs={n:load(n+'.run.json') for n in ['runtime','targeted','lint','old-replay','controls','independent','blocker','pl','feedback']}
assert all(runs[n]['exit_code']==0 for n in ['runtime','targeted','lint','old-replay','controls'])
assert all(runs[n]['exit_code']==1 for n in ['independent','blocker','pl','feedback'])
assert not load('static-scan.json')['findings']
controls=load('complete-scope-controls.json')
assert controls['passed'] and len(controls['checks'])==15
under=controls['details']['positive-width-under-enclosure-honestly-uncertified']
ind=load('independent-results.json')
assert [r['passed'] for r in ind['checks']]==[True,True,False]
coeff=load('coefficient-cases.json')
assert len(coeff)==ind['details']['independent-wide-range-point-cell-and-term-coefficients']['cases']==201
blocker=load('blocking-underflow.json')
feedback=load('blocking-pl-feedback.json')
assert blocker['blocking_logic_error'] and feedback['blocking_logic_error']
assert len(blocker['results'])==len(feedback['results'])==2
assert all(row['observed']=={'reconstruction':0.,'fractional_rhs':0.,'defect':0.} for row in feedback['results'])
assert not bool(git('diff',BASE,TREE,'--','src','pyproject.toml','uv.lock'))
dump('identity-after.json',{'reviewed_tree':TREE,'worktree_source_mismatches':work_mismatch,'immutable_snapshot_mismatches':snapshot_mismatch,'git_blob_mismatches':git_mismatch,'index_bytes_unchanged':index_unchanged,'index_entries_unchanged':index_entries_unchanged,'original_failure_and_preserved_copies_mismatches':original_mismatch,'fixture_unchanged':True,'old_test_function_ASTs_preserved':True,'only_added_test_function':sorted(new_names),'unchanged_module_nodes':unchanged_nodes,'copied_source_count':len(before['files']),'source_and_pyproject_uvlock_unchanged_from_baseline':True,'scope':'Repository docs/untracked artifacts may be edited by parent concurrently; review uses immutable Git bytes, not those mutable docs.'})
metrics={'reviewed_tree':TREE,'targeted_cpu':counts,'coefficient_comparisons':len(coeff),'coefficient_max_relative_error':max(max(row['relative_errors']) for row in coeff),'coefficient_comparison_rtol':2e-12,'coefficient_comparison_atol':0,'original_nine_red_to_green':len(ind['details']['original-nine-both-paths-red-to-green']),'reused_control_groups':len(controls['checks']),'reused_seeded_cases':len(controls['details']['seeded-random-panel-and-cell-crosschecks']),'known_under_enclosure':under,'static_added_lines':load('static-scan.json')['added_lines'],'security_findings':[],'new_blocking_issues':2,'gamma_repair_delta_observed_correct':True,'complete_host_diagnostic_review_passed':False,'arithmetic_verified':False,'total_numerical_certified':False,'a1_acceptance_passed':False,'claims':'Empirical comparisons only, not a global special-function accuracy bound; no full-suite, GPU, JIT, AD, controller, solution-error or certification result.'}
dump('review-metrics.json',metrics)
logic=[
 {'severity':'blocking','introduced_by_repair_delta':False,'locations':['benchmarks/numerical/_volterra_defect.py:116-127'],'issue':'Catastrophic cancellation in global slope-jump reconstruction/integration returns a zero defect for a nonzero full-history residual.','reproducer':'ts=[0,1e-17,1], states=[[0],[1],[1]], alpha=.5, A=[[1]], initial=[0], no forcing, target=1. Both immutable old and corrected trees return reconstruction=rhs=defect=0.','expected':'The represented PL state is 1 at t=1; independent mp130 two-panel quadrature gives rhs=1.12837916709551257107521098538 and defect=-0.12837916709551257107521098538. A=0 also returns reconstruction=0 instead of stored endpoint 1.','cause':'Huge opposite slope-jump terms cancel after t-epsilon rounds to t. All arrays remain finite; no exception is raised.','scope':'No code-level history truncation found, but finite arithmetic numerically erases the retained trajectory/history. This is a point-value failure, not the accepted tiny cell-rounding caveat.','evidence':str(OUT/'blocking-pl-feedback.json')},
 {'severity':'blocking','introduced_by_repair_delta':False,'locations':['benchmarks/numerical/_volterra_defect.py:124-126','benchmarks/numerical/_volterra_defect.py:212-215'],'issue':'Time powers underflow before finite coefficient scaling in point and cell paths.','reproducer':'ts=[0,1], zero states/A/initial, alpha=.5, beta=1100, forcing coefficient=1e300, target=.5 and mesh=[0,.5,1]. Both immutable old and corrected trees return rhs=0 and first cell range=[0,0].','expected':'Finite representable rhs=1.5690812007270112e-33 and right-end defect=-1.5690812007270112e-33; mp180 direct Gamma, integer-beta recurrence and independent transformed quadrature agree.','cause':'Intermediate power rounds to zero before multiplication by a large finite coefficient; isfinite and over/invalid/divide traps miss the loss.','scope':'100% relative point-value error and zero cell range, separate from ordinary approximately 1.53e-17 endpoint under-enclosure.','evidence':str(OUT/'blocking-underflow.json')}
]
names=['review-metrics.json','identity-before.json','identity-after.json','repair-delta.patch','targeted.xml','independent-results.json','coefficient-cases.json','complete-scope-controls.json','blocking-pl-feedback.json','blocking-pl-reconstruction.json','blocking-underflow.json','old-tree-failure-replay.json','harness-adaptation.json','controls-adaptation.json','run_checks.py','pl_feedback_probe.py','blocking_underflow_reproducer.py','preserved-original/initial-review-verdict.json']
verdict={'passed':False,'security_concerns':[],'logic_errors':logic,'suggestions':['Keep the Gamma-ratio repair: both sibling paths share reciprocal Pochhammer and the nine original cases are independently RED-to-GREEN; 201 represented-input coefficient comparisons pass with zero absolute slack. These observations are not a global accuracy bound.','Stabilize PL reconstruction and retained-panel integration, or explicitly reject unsafe configurations. Add the nonuniform constant-tail case and premature-underflow point/cell cases as RED regressions before repair; do not hide them using global precision promotion or relaxed tolerances. A conservative underflow failure is preferable to silent zero.','Retain arithmetic_verified=false, total_numerical_certified=false and the known adjacent-float under-enclosure regression. A1 acceptance remains false; feedback propagation/tails, verified arithmetic/input/output budgets, nonlinear domains and controller/JAX/gradient gates are still unestablished.'],'summary':'FAIL-CLOSED complete three-file private-host review: the scoped Gamma-ratio repair is correct on exercised cases; 64 focused CPU tests, lint and 15 independent-control groups pass, with no tolerance relaxation, precision-policy change or source-level history truncation. Two newly reproduced pre-existing arithmetic failures still return incorrect finite point values, so the corrected complete host diagnostic is not approved. Original failed review preserved separately; no repository/index/docs/fixture writes, full suite, commit or push.','reviewed_tree':TREE,'evidence_paths':[handle(n) for n in names],'a1_acceptance_passed':False}
assert not verdict['passed'] and verdict['logic_errors'] and not verdict['a1_acceptance_passed']
dump('corrected-review-verdict.json',verdict)
# Index every authored/captured evidence file, excluding mutable caches/temp directories.
manifest=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file() and not set(p.relative_to(OUT).parts)&{'tmp','cache','jax-cache','hypothesis','pytest-tmp','__pycache__'} and p.name!='evidence-index.json':
        data=p.read_bytes(); manifest.append({'path':str(p.relative_to(OUT)),'bytes':len(data),'sha256':sha(data)})
dump('evidence-index.json',{'root':str(OUT),'authoritative_verdict':'corrected-review-verdict.json','reviewed_tree':TREE,'files':manifest,'file_count':len(manifest),'scope':'New scratch-only review evidence; original failed verdict copied byte-for-byte; every runtime probe write confined with Landlock. Generated caches excluded.'})
print(json.dumps({'passed':False,'logic_error_count':len(logic),'reviewed_tree':TREE,'metrics':metrics,'handles':[handle(n) for n in ['corrected-review-verdict.json','evidence-index.json','blocking-pl-feedback.json','blocking-underflow.json','run_checks.py','pl_feedback_probe.py','blocking_underflow_reproducer.py','preserved-original/initial-review-verdict.json']]},indent=2))
