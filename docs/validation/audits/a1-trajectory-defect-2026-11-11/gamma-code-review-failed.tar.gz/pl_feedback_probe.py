"""Independent panel-quadrature confirmation of catastrophic PL cancellation."""
import hashlib
import json
from pathlib import Path
import sys
import types

import mpmath as mp
import numpy as np

OUT=Path(__file__).resolve().parent
PATH='benchmarks/numerical/_volterra_defect.py'
epsilon=1e-17
ts=np.array([0.,epsilon,1.]); states=np.array([[0.],[1.],[1.]])
with mp.workdps(130):
    n,d=epsilon.as_integer_ratio(); eps=mp.mpf(n)/d
    target=mp.mpf(1); a=mp.mpf('.5')
    # Direct panel interpolation and terminal-singularity removal, no global hinges.
    first=mp.quad(lambda u:(target-u**(1/a))/eps,[(target-eps)**a,target**a])
    second=mp.quad(lambda u:mp.mpf(1),[0,(target-eps)**a])
    true_rhs=(first+second)/mp.gamma(a+1)
    true_defect=1-true_rhs
    reference={'precision_dps':130,'reconstruction':1.,'fractional_rhs':mp.nstr(true_rhs,100),'defect':mp.nstr(true_defect,100),'panels_retained':2,'input_semantics':'exact represented binary values via integer ratio','method':'independent direct panel interpolation under u=(t-s)^alpha'}
rows=[]
for tree,folder in [('6e7a156f025e08b31a314c5bda59183d6a96bf32','old-tree'),('8dcbfafd1a5373088e75437551692a85fd7f7b77','tree')]:
    source=(OUT/folder/PATH).read_bytes()
    mod=types.ModuleType('feedback_'+folder.replace('-','_')); mod.__file__=str(OUT/folder/PATH)
    sys.modules[mod.__name__]=mod
    exec(compile(source,mod.__file__,'exec'),mod.__dict__)
    result=mod.affine_power_defect(ts,states,np.array([1.]),order=.5,matrix=np.array([[1.]]),initial_state=np.array([0.]))
    observed={'reconstruction':float(result.reconstruction[0,0]),'fractional_rhs':float(result.fractional_rhs[0,0]),'defect':float(result.defect[0,0])}
    rows.append({'tree':tree,'source_sha256':hashlib.sha256(source).hexdigest(),'observed':observed,'arithmetic_verified':result.arithmetic_verified,'total_numerical_certified':result.total_numerical_certified})
report={'passed':False,'blocking_logic_error':True,'introduced_by_gamma_delta':False,'inputs':{'ts':ts.tolist(),'states':states.tolist(),'alpha':.5,'A':[[1.]],'target':1.,'forcing':[]},'reference':reference,'results':rows,'issue':'Catastrophic cancellation erases both represented stored state and retained history numerically; at t=1 the diagnostic returns a zero defect although the full-history defect is approximately -0.128379. No mathematical panel was truncated, but the arithmetic loses the complete tail state and history contribution.','locations':['benchmarks/numerical/_volterra_defect.py:116-127'],'a1_acceptance_passed':False}
(OUT/'blocking-pl-feedback.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2))
sys.exit(1)
