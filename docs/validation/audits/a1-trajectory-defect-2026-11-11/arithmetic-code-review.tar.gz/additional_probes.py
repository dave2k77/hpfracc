"""Additional scale/branch/source review without changing any reviewed bytes."""
import difflib
import json
from pathlib import Path
import re
import subprocess
import tarfile

import mpmath as mp
import numpy as np

from independent_probes import (OUT, ROOT, TREE, binary, cmp_point, corroborate,
    EVENTS, ex, make, reference, run, subject)


def main():
    result={'reviewed_tree':TREE}
    try:
        # A deterministic scale survey keeps both the exact model and the
        # dimensionless state/feedback/forcing magnitudes fixed.
        for te in [-400,-100,0,100,400]:
            h=2.**te
            for a in [1e-12,.37,np.nextafter(1.,0.)]:
                s=np.asarray([2.**-200,2.**200])
                scale_feedback=2.**(-te*a)
                A=np.asarray([[-.25,.125/2.**400],[.375*2.**400,-.5]])*scale_feedback
                co=np.asarray([[.125,-.25],[-.375,.5],[.25,-.125]])*s
                for k,b in enumerate([0,.25,1.]): co[k]*=2.**(-te*(a+b))
                c=make(f'scale_survey_t{te}_a{a}',h*np.asarray([7,7.0625,7.75,9]),
                    np.asarray([[.5,-1],[-.75,.25],[.125,.75],[1,-.5]])*s,
                    a=a,A=A,powers=[0,.25,1.],coeff=co)
                t=h*np.asarray([7,7.03125,7.25,8.,9.])
                _,ref=cmp_point(c,t,scales=s)
                corroborate(c,t,ref,scales=s,mesh=c['ts'])
        # Old extremely small q and independently represented tiny old age.
        rows=[]
        for left,right,t in [(0.,1e-200,1.),(-1.,-1e-300,0.),(0.,.125,1e150)]:
            for a0 in [1e-200,1e-20,.5,np.nextafter(1.,0.)]:
                row={'left':binary(left),'right':binary(right),'target':binary(t),'order':binary(a0)}
                try:
                    got=subject._panel_weights(np.asarray([t]),left,right,a0)
                    age=ex(t)-ex(left); h=ex(right)-ex(left); a=ex(a0); q=h/age
                    total=age**a*mp.betainc(1,a,0,q)/mp.gamma(a)
                    rr=age**(a+1)*mp.betainc(2,a,0,q)/(h*mp.gamma(a))
                    ll=total-rr
                    error=[float(abs(ex(v[0])-r)/r) for v,r in zip(got,[ll,rr])]
                    row.update(outcome='returned',output=[float(v[0]) for v in got],
                        reference=[mp.nstr(ll,90),mp.nstr(rr,90)],relative_errors=error)
                    assert max(error)<2e-12
                except FloatingPointError as err:
                    row.update(outcome='FloatingPointError',message=str(err))
                rows.append(row)
        result['extreme_old_weight_results']=rows
        # Verify zero postconditions independently by substituting only the
        # secondary checked-call seam in the in-memory review copy. The shipped
        # pinned files and every previous result remain untouched.
        saved=subject._checked
        post=[]
        try:
            subject._checked=lambda context,operation,*args: np.zeros(np.broadcast_shapes(*(np.shape(a) for a in args)))
            for name,fn,args in [('multiply',subject._multiply,(1e-200,1e-200)),('divide',subject._divide,(1e-200,1e200)),('power',subject._power,(.5,1100.))]:
                try: fn(*args,'simulated silent zero only')
                except FloatingPointError as err: post.append({'operation':name,'outcome':'FloatingPointError','message':str(err)})
                else: raise AssertionError('Missing independent postcondition '+name)
            for name,fn,args in [('multiply',subject._multiply,(0.,1.)),('divide',subject._divide,(0.,1.)),('power',subject._power,(0.,1.))]:
                assert fn(*args,'legitimate zero')==0
        finally: subject._checked=saved
        result['silent_zero_postcondition_controls']=post
        # Current contract differs only by approval text and the signed-
        # coefficient clarification. Read archive members in memory, never copy.
        audit=ROOT/'docs/validation/audits/a1-trajectory-defect-2026-11-11'
        with tarfile.open(audit/'arithmetic-contract-review.tar.gz') as tar:
            draft=tar.extractfile('reviewed-arithmetic-contract.md').read().decode()
        current=(audit/'arithmetic-contract.md').read_text()
        result['approved_draft_to_current_contract_diff']=''.join(difflib.unified_diff(draft.splitlines(True),current.splitlines(True),fromfile='approved draft',tofile='current contract'))
        # Independent added-line scan of the exact immutable tree delta.
        diff=subprocess.check_output(['git','diff','--unified=0','74d8f08c01179115c2752da5604a9cd85bba89bc',TREE],cwd=ROOT).decode()
        added=[line[1:] for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++')]
        patterns={
            'hardcoded_credential':r'''(?i)(?:api_key|secret|password|passwd|token)\s*=\s*['"][^'"]{6,}['"]''',
            'shell_execution':r'os\.system\(|subprocess[^\n]*shell\s*=\s*True',
            'eval_exec':r'\b(?:eval|exec)\s*\(',
            'pickle':r'pickle\.loads?\s*\(',
            'sql_interpolation':r'execute\s*\(\s*f[\'"]',
        }
        findings=[{'category':name,'line':line} for name,pat in patterns.items() for line in added if re.search(pat,line)]
        assert not findings
        result['independent_static_scan']={'added_line_count':len(added),'findings':findings}
        result['completed']=True
    finally:
        (OUT/'additional-probes.json').write_text(json.dumps(EVENTS,indent=2,allow_nan=False)+'\n')
        result['scale_survey_point_and_cell_cases']=len(EVENTS)
        errors=[e['max_abs_component_scaled_error'] for e in EVENTS if 'max_abs_component_scaled_error' in e]
        result['max_scale_survey_abs_normalized_errors']={k:max(e[k] for e in errors) for k in ['reconstruction','fractional_rhs','defect']} if errors else {}
        (OUT/'additional-summary.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2))

if __name__=='__main__': main()
