"""Run only the requested 117 CPU cases without writing repository caches."""
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=Path(__file__).resolve().parent
cmd=['uv','run','--frozen','--no-sync','python','-m','pytest','-p','no:cacheprovider','-q','tests/unit/test_volterra_defect.py','tests/unit/test_volterra_arithmetic.py',f'--junitxml={OUT / "focused.xml"}']
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',JAX_PLATFORMS='cpu',XLA_PYTHON_CLIENT_PREALLOCATE='false',A1_OBSERVATIONS=str(OUT/'focused-observations.jsonl'))
start=time.time()
with (OUT/'focused.stdout').open('w') as stdout, (OUT/'focused.stderr').open('w') as stderr:
    run=subprocess.run(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
record={'command':cmd,'exit_code':run.returncode,'seconds':time.time()-start,'JAX_PLATFORMS':'cpu','no_full_suite':True,'no_gpu':True}
if (OUT/'focused.xml').exists():
    xml=ET.parse(OUT/'focused.xml')
    cases=xml.findall('.//testcase')
    record.update(cases=len(cases),failures=len(xml.findall('.//testcase/failure')),errors=len(xml.findall('.//testcase/error')),skips=len(xml.findall('.//testcase/skipped')))
    record['counts_by_file']={name:sum(c.get('classname','').endswith(name) for c in cases) for name in ['test_volterra_defect','test_volterra_arithmetic']}
(OUT/'focused-result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print((OUT/'focused.stdout').read_text())
assert run.returncode==0 and record['cases']==117 and record['failures']==record['errors']==record['skips']==0
