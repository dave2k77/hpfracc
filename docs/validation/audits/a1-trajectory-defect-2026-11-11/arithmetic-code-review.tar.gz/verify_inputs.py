"""Read-only artifact/source identities; write compact proof in this directory."""
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = Path(__file__).resolve().parent
AUDIT = ROOT / 'docs/validation/audits/a1-trajectory-defect-2026-11-11'
TREE = 'bf3d4fa06026f4f2efedcf9d899c75ebca53cdbd'
OLD = '92ff3dceb217f6097bae8ccde6cf159d8daa8d14'
BASE = '74d8f08c01179115c2752da5604a9cd85bba89bc'
FOUR = ['benchmarks/numerical/_volterra_defect.py', 'tests/unit/test_volterra_defect.py', 'tests/unit/test_volterra_arithmetic.py', 'docs/validation/audits/a1-trajectory-defect-2026-11-11/frozen-fixtures.json']

def sha(b):
    return hashlib.sha256(b).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def main():
    manifest = json.loads((AUDIT / 'source-snapshot.json').read_bytes())
    assert manifest['source_tree'] == TREE
    paths = manifest['paths']
    assert len(paths) == manifest['count'] == 126
    archive = AUDIT / 'source-snapshot.tar.gz'
    archived = {}
    with tarfile.open(archive) as tar:
        regular = [m for m in tar.getmembers() if m.isfile()]
        assert len(regular) == 126
        assert len({m.name for m in regular}) == 126
        for m in regular:
            assert m.name in paths, m.name
            archived[m.name] = sha(tar.extractfile(m).read())
    assert archived == paths
    mismatches = [p for p,h in paths.items() if sha((ROOT/p).read_bytes()) != h]
    assert not mismatches, mismatches
    pins = {}
    for p in FOUR:
        b = git('show', f'{TREE}:{p}')
        assert sha(b) == paths[p] == sha((ROOT/p).read_bytes())
        target = OUT / 'pinned' / p
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b)
        pins[p] = {'sha256':sha(b), 'bytes':len(b), 'git_blob':git('rev-parse', f'{TREE}:{p}').decode().strip()}
    assert pins[FOUR[0]]['sha256'] == '08d7f7fb8b9e6563d8a2d13c1567c0f90049a021f1a94e94c5cfd61f04d87eba'
    assert pins[FOUR[3]]['sha256'] == '63311bcecc3c31458df93b0c1079d0cec1d8cbc64ee1155abc07b028e9f9aaef'
    baseline_delta = git('diff', '--name-status', BASE, TREE).decode()
    old_delta = git('diff', '--name-status', OLD, TREE).decode()
    assert len(baseline_delta.strip().splitlines()) == 4
    assert git('show', f'{OLD}:{FOUR[1]}') == (ROOT/FOUR[1]).read_bytes()
    assert git('show', f'{OLD}:{FOUR[3]}') == (ROOT/FOUR[3]).read_bytes()
    (OUT/'vs-rejected92ff.patch').write_bytes(git('diff', OLD, TREE, '--', *FOUR))
    (OUT/'vs-baseline74d.stat').write_bytes(git('diff', '--stat', BASE, TREE, '--', *FOUR))
    # Verify draft clearance and each linked archived proof without unpacking it.
    contract_review=json.loads((AUDIT/'arithmetic-contract-review.json').read_bytes())
    contract_members=[]
    with tarfile.open(AUDIT/'arithmetic-contract-review.tar.gz') as tar:
        for m in tar.getmembers():
            if m.isfile():
                b=tar.extractfile(m).read()
                contract_members.append({'path':m.name,'sha256':sha(b),'bytes':len(b)})
    assert any(m['sha256']==contract_review['contract_sha256'] for m in contract_members)
    index_path = Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index_path.is_absolute(): index_path=ROOT/index_path
    report = {'reviewed_tree':TREE,'baseline':BASE,'rejected_tree':OLD,'baseline_delta':baseline_delta,
        'rejected_delta':old_delta,'pinned_files':pins,'archive':{'path':str(archive),'sha256':sha(archive.read_bytes()),'entries':len(archived),'all_match_manifest_and_live':True},
        'manifest':{'path':str(AUDIT/'source-snapshot.json'),'sha256':sha((AUDIT/'source-snapshot.json').read_bytes()),'count':len(paths)},
        'git_index_sha256':sha(index_path.read_bytes()),'head':git('rev-parse','HEAD').decode().strip(),
        'status':git('status','--porcelain=v1','--untracked-files=all').decode(),
        'contract_review':contract_review,'contract_archive_members':contract_members,
        'external_evidence_hashes':{p:sha((AUDIT/p).read_bytes()) for p in ['arithmetic-contract.md','arithmetic-contract-review.json','arithmetic-contract-review.tar.gz','static-scan.json','final-code-review-rejected.json','final-code-review-rejected.tar.gz','gamma-review-failed.json','initial-review.json','arithmetic-regression-red.tar.gz','arithmetic-repair-green.tar.gz','pre-arithmetic-checkpoint.tar.gz']}}
    target=OUT/('identity-before.json' if not (OUT/'identity-before.json').exists() else 'identity-after.json')
    target.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['reviewed_tree','baseline_delta','rejected_delta','pinned_files','archive','git_index_sha256']},indent=2))
    print('Saved',target)

if __name__=='__main__': main()
