"""Finalize fail-closed JSON and a self-excluding hash index of scratch proof."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=Path(__file__).resolve().parent
TREE='bf3d4fa06026f4f2efedcf9d899c75ebca53cdbd'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(name): return json.loads((OUT/name).read_text())
def write(name,data): (OUT/name).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')

def main():
    before=read('identity-before.json'); after=read('identity-after.json')
    immutable_keys=['git_index_sha256','pinned_files','archive','manifest','head','external_evidence_hashes','contract_archive_members']
    assert all(before[k]==after[k] for k in immutable_keys)
    status_added=sorted(set(after['status'].splitlines())-set(before['status'].splitlines()))
    status_removed=sorted(set(before['status'].splitlines())-set(after['status'].splitlines()))
    expected='?? docs/validation/audits/a1-trajectory-defect-2026-11-11/candidate-status.json'
    assert status_added==[expected] and not status_removed
    xml=ET.parse(OUT/'focused.xml')
    assert len(xml.findall('.//testcase'))==117
    assert not any(xml.findall('.//testcase/'+t) for t in ['failure','error','skipped'])
    focused=read('focused-result.json')
    assert focused['exit_code']==0 and focused['cases']==117
    assert read('independent-summary.json')['completed'] is True
    assert read('additional-summary.json')['completed'] is True
    records=read('execution-record.json')
    assert len(records)==4 and all(r['exit_code']==0 for r in records)
    raw=read('independent-probes.json')
    canonical=[e for e in raw if e.get('name') in ['B1','B2','B3'] and e.get('tree')==TREE]
    assert len(canonical)==6 and all(e['outcome']=='returned' for e in canonical)
    # Fresh readback, not inferred from a successful earlier subprocess.
    manifest=json.loads((ROOT/'docs/validation/audits/a1-trajectory-defect-2026-11-11/source-snapshot.json').read_text())
    assert len(manifest['paths'])==126
    assert all(sha(ROOT/p)==h for p,h in manifest['paths'].items())
    index=Path(subprocess.check_output(['git','rev-parse','--git-path','index'],cwd=ROOT,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')).decode().strip())
    if not index.is_absolute(): index=ROOT/index
    assert sha(index)==before['git_index_sha256']
    # Preserve the harness-only status assertion failure; do not relabel it as
    # an actual command or numerical failure, nor claim an unchanged whole repo.
    candidate=ROOT/expected[3:]
    scoped={
        'reviewed_tree':TREE,'pinned_files_match_before_after_live':True,
        'all_126_manifest_input_bytes_match':True,'archive_hash_unchanged':True,
        'git_index_hash_unchanged':True,'prior_evidence_hashes_unchanged':True,
        'full_git_status_unchanged':False,'status_added':status_added,'status_removed':status_removed,
        'concurrent_nonreviewed_artifact':{'path':str(candidate),'sha256':sha(candidate)},
        'harness_issue':{'command':'python '+str(OUT/'capture_execution.py'),'actual_exit_code':1,
            'error':'AssertionError: status','cause':'New untracked candidate-status.json appeared outside frozen source inputs; all four child commands exited 0 and every immutable identity matched.',
            'resolution':'This separate scoped verification uses immutable bytes/index/archive identities and explicitly records the unrelated status delta. No production fix or review retry was performed.'},
        'focused_counts':focused['counts_by_file'],'focused_passed':117,'focused_actual_exit_code':0,
        'independent_canonical_successes':len(canonical),'no_full_suite_or_gpu_job_performed':True,
        'repository_or_index_writes_by_reviewer':False,
    }
    write('final-identity-verification.json',scoped)
    math_review=read('source-math-review.json')
    assert math_review['blocking_findings']==math_review['security_findings']==[]
    c=read('conditioning-probe.json')
    assert c['point']['defect'][0][0]==0 and c['relative_point_error']==1 and c['is_underflow'] is False
    classification={
        'blocking':False,
        'category':'Ill-conditioned fixed-order float64 summation; false-zero diagnostic limitation, not underflow',
        'observed':'Point component-0 defect is 0; cell component-0 range is [0,0]; exact represented-input endpoint defect is -1.12837916709551257389615890312154517...',
        'quantitative_reason':'Feedback sum is exactly 1, sumabs is 200000000000000000001, kappa is approximately 2e20 and kappa*2^-53 is approximately 22204.46. The lost 1 is approximately 5e-21 of sumabs, consistent with ordinary floating addition and far inside its standard absolute-error bound. Permuting unchanged components restores it.',
        'contract_reason':'The approved contract explicitly permits fixed-order checked additions and excludes conditioning/summation bounds and global relative accuracy. A 100% relative error in this exceptionally ill-conditioned output alone is not a violation of that scoped promise. Classification does not rely on certificate flags.',
        'required_limitation':'Preserve and disclose this counterexample. Checked range arithmetic is not cancellation-safe; computed zero feedback, zero defect and zero-width cells do not establish exact zeros or small exact residuals. These outputs must not support scientific acceptance without independent conditioning/error control.'
    }
    evidence=[]
    for p in ['final-identity-verification.json','source-math-review.json','conditioning-probe.json','focused-result.json','execution-record.json','independent-summary.json','additional-summary.json']:
        evidence.append({'path':str(OUT/p),'sha256':sha(OUT/p)})
    evidence.append({'path':str(OUT/'hash-index.json'),'scope':'All scratch evidence including verdict and four compact pinned sources; excludes index itself'})
    verdict={
        'passed':True,'security_concerns':[],'logic_errors':[],
        'suggestions':[
            'Retain the conditioning counterexample and explicitly distinguish rounded zero coefficients from exact algebraic zero feedback. Any cancellation-robust redesign needs separate authorization; this review made no fixes.',
            'Do not strengthen the guarantee to trapping all C-library internal range events or bounding special-function, summation or cancellation error. Postconditions and local traps are expression-level safeguards, not verified arithmetic.',
            'Treat remaining authorized whole-project CPU/CUDA verification as separate gates. This scoped source/artifact pass is not A1 acceptance, numerical certification, JAX/AD or GPU diagnostic validation.'
        ],
        'summary':'Scoped complete source/math review PASSED with no blocking findings: all six canonical recoveries independently succeed, all 117 focused CPU tests pass with actual exit 0, and additional signed/coupled/shifted/extreme-scale, extrema, history and range-guard probes pass or explicitly reject unsafe intermediates as required. All four pinned sources, 126 frozen archive inputs and the fixture are verified unchanged. The parent cancellation probe is a quantified nonblocking conditioning limitation, not evidence of accurate zero residuals.',
        'reviewed_tree':TREE,'evidence_paths':evidence,'a1_acceptance_passed':False,
        'conditioning_probe_classification':classification
    }
    assert verdict['passed'] == (not verdict['security_concerns'] and not verdict['logic_errors'])
    write('verdict.json',verdict)
    paths=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name!='hash-index.json')
    file_index={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in paths}
    write('hash-index.json',{'reviewed_tree':TREE,'excludes':'hash-index.json (self-reference)',
        'count':len(file_index),'files':file_index,'duplicated_126_input_archive':False,'copied_prior_archives':False,
        'compact_pinned_source_count':sum(p.startswith('pinned/') for p in file_index)})
    # Verify evidence JSON integrity against the just-created index, including
    # the exact verdict. No production-source writes or edits are performed.
    index_data=read('hash-index.json')
    assert index_data['compact_pinned_source_count']==4
    assert all(sha(OUT/p)==item['sha256'] for p,item in index_data['files'].items())
    assert read('verdict.json')==verdict
    print(json.dumps({'passed':verdict['passed'],'a1_acceptance_passed':False,'verdict_path':str(OUT/'verdict.json'),
        'verdict_sha256':sha(OUT/'verdict.json'),'hash_index_path':str(OUT/'hash-index.json'),
        'hash_index_sha256':sha(OUT/'hash-index.json'),'scratch_files_excluding_index':index_data['count'],
        'total_scratch_bytes_excluding_index':sum(f['bytes'] for f in file_index.values()),
        'focused_passed':117,'canonical_successes':6,'conditioning_blocking':False,
        'scope_identities_verified':True,'nonreviewed_status_addition':status_added},indent=2))

if __name__=='__main__': main()
