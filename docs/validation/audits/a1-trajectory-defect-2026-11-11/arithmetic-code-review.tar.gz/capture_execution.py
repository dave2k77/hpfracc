"""Capture actual exits/output for the additional independent checks."""
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=Path(__file__).resolve().parent
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',JAX_PLATFORMS='cpu',XLA_PYTHON_CLIENT_PREALLOCATE='false',GIT_OPTIONAL_LOCKS='0')
commands=[
    ('independent',['uv','run','--frozen','--no-sync','python',str(OUT/'independent_probes.py')]),
    ('additional',['uv','run','--frozen','--no-sync','python',str(OUT/'additional_probes.py')]),
    ('focused-ruff',['uv','run','--frozen','--no-sync','ruff','check','--no-cache','benchmarks/numerical/_volterra_defect.py','tests/unit/test_volterra_defect.py','tests/unit/test_volterra_arithmetic.py']),
    ('post-identities',['python',str(OUT/'verify_inputs.py')]),
]
results=[]
for name,cmd in commands:
    start=time.time()
    with (OUT/(name+'.stdout')).open('w') as stdout,(OUT/(name+'.stderr')).open('w') as stderr:
        p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
    results.append({'name':name,'command':cmd,'exit_code':p.returncode,'seconds':time.time()-start,
        'stdout':str(OUT/(name+'.stdout')),'stderr':str(OUT/(name+'.stderr'))})
    print(name,'exit',p.returncode)
    if p.returncode: break
(OUT/'execution-record.json').write_text(json.dumps(results,indent=2)+'\n')
assert len(results)==4 and all(r['exit_code']==0 for r in results)
before=json.loads((OUT/'identity-before.json').read_text())
after=json.loads((OUT/'identity-after.json').read_text())
for key in ['git_index_sha256','pinned_files','archive','manifest','head','status','external_evidence_hashes']:
    assert before[key]==after[key],key
print('All reviewed source/archive/index/status identities unchanged')
