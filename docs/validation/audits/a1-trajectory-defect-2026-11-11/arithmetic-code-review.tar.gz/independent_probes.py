"""Independent exact-binary probes of the pinned private host diagnostic.

Run from the project with uv; no test/reference helper is imported. Incomplete
Beta integration is performed at 450 digits, distinct from the float64 positive
basis implementation. Ordinary controls also use transformed panel quadrature.
All cell inclusions below are sampled corroboration, never enclosure proofs.
"""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys

import mpmath as mp
import numpy as np
from scipy.special import gamma, hyp2f1, poch

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=Path(__file__).resolve().parent
TREE='bf3d4fa06026f4f2efedcf9d899c75ebca53cdbd'
OLD='92ff3dceb217f6097bae8ccde6cf159d8daa8d14'
SOURCE='benchmarks/numerical/_volterra_defect.py'
sys.path.insert(0,str(ROOT))

def load(name, raw=None):
    # The old helper remains in memory, not copied or rearchived on disk.
    if raw is None:
        spec=importlib.util.spec_from_file_location(name, OUT/'pinned'/SOURCE)
        module=importlib.util.module_from_spec(spec)
        sys.modules[name]=module
        spec.loader.exec_module(module)
    else:
        import types
        module=types.ModuleType(name)
        sys.modules[name]=module
        exec(compile(raw,f'<immutable {OLD}:{SOURCE}>','exec'),module.__dict__)
    return module

subject=load('reviewed_private_helper')
old=load('rejected_private_helper',subprocess.check_output(['git','show',f'{OLD}:{SOURCE}'],cwd=ROOT))
assert hashlib.sha256((OUT/'pinned'/SOURCE).read_bytes()).hexdigest()=='08d7f7fb8b9e6563d8a2d13c1567c0f90049a021f1a94e94c5cfd61f04d87eba'
mp.mp.dps=450
EVENTS=[]


def ex(x):
    n,d=float(x).as_integer_ratio()
    return mp.mpf(n)/d


def binary(x):
    a=np.asarray(x)
    return {'dtype':str(a.dtype),'shape':list(a.shape),'hex':[float(v).hex() for v in a.flat]}


def make(name,ts,ys,a=.5,A=None,powers=(),coeff=None,dtype=np.float64):
    y=np.asarray(ys,dtype=dtype)
    d=y.shape[1]
    return {'name':name,'ts':np.asarray(ts,dtype=dtype),'ys':y,'a':dtype(a),
        'A':np.zeros((d,d),dtype=dtype) if A is None else np.asarray(A,dtype=dtype),
        'powers':np.asarray(powers,dtype=dtype),
        'coeff':np.empty((0,d),dtype=dtype) if coeff is None else np.asarray(coeff,dtype=dtype)}


def kw(c):
    return dict(order=c['a'],matrix=c['A'],initial_state=c['ys'][0],
        power_exponents=c['powers'],power_coefficients=c['coeff'])


def reference(c,targets,quadrature=False):
    ts=list(map(ex,c['ts'])); ys=[[ex(v) for v in r] for r in c['ys']]
    mat=[[ex(v) for v in r] for r in c['A']]; a=ex(c['a']); d=len(ys[0])
    output={'reconstruction':[],'fractional_rhs':[],'defect':[]}
    for t0 in targets:
        t=ex(t0)
        if t in ts: y=ys[ts.index(t)]
        else:
            j=next(j for j in range(len(ts)-1) if ts[j]<t<ts[j+1])
            h=ts[j+1]-ts[j]
            y=[((ts[j+1]-t)*u+(t-ts[j])*v)/h for u,v in zip(ys[j],ys[j+1])]
        parts=[[] for _ in range(d)]
        for j,l in enumerate(ts[:-1]):
            r=ts[j+1]
            if t<=l: continue
            h=r-l; age=t-l; q=min(h,age)/age
            if quadrature:
                # u=(t-s)**a eliminates the fractional singularity.
                aa=(t-min(r,t))**a; bb=(t-l)**a
                for k in range(d):
                    def f(u):
                        s=t-u**(1/a)
                        state=[((r-s)*x+(s-l)*z)/h for x,z in zip(ys[j],ys[j+1])]
                        return mp.fsum(mat[k][n]*state[n] for n in range(d))
                    parts[k].append(mp.quad(f,[aa,bb])/mp.gamma(a+1))
            else:
                total=age**a*mp.betainc(1,a,0,q)/mp.gamma(a)
                wr=age**(a+1)*mp.betainc(2,a,0,q)/(h*mp.gamma(a))
                wl=total-wr
                for k in range(d):
                    parts[k].append(mp.fsum(mat[k][n]*(wl*ys[j][n]+wr*ys[j+1][n]) for n in range(d)))
        rhs=[mp.fsum(p) for p in parts]
        tau=t-ts[0]
        force=[[] for _ in range(d)]
        for b0,co in zip(c['powers'],c['coeff']):
            b=ex(b0)
            fac=mp.exp(mp.loggamma(b+1)-mp.loggamma(b+a+1))*tau**(a+b)
            for k in range(d): force[k].append(fac*ex(co[k]))
        rhs=[mp.fsum([v,mp.fsum(p)]) for v,p in zip(rhs,force)]
        defect=[v-z-f for v,z,f in zip(y,ys[0],rhs)]
        for key,row in zip(output,[y,rhs,defect]): output[key].append(row)
    return output


def run(c,targets,api='point',which=subject):
    target=np.asarray(targets,dtype=c['ts'].dtype)
    record={'name':c['name'],'api':api,'tree':TREE if which is subject else OLD,
        'inputs':{k:binary(v) for k,v in c.items() if k!='name'},'targets':binary(target)}
    try:
        result=(which.affine_power_defect if api=='point' else which.affine_power_cells)(c['ts'],c['ys'],target,**kw(c))
        record['outcome']='returned'
        record['output']=result.to_dict()
        assert result.arithmetic_verified is result.total_numerical_certified is False
        json.dumps(record,allow_nan=False)
        EVENTS.append(record)
        return result
    except FloatingPointError as err:
        record.update(outcome='FloatingPointError',message=str(err))
        EVENTS.append(record)
        return None


def cmp_point(c,targets,scales=1,quadrature=False):
    r=run(c,targets)
    assert r is not None,c['name']
    ref=reference(c,targets,quadrature)
    delta={}
    for k in ref:
        want=np.asarray([[float(v) for v in row] for row in ref[k]])
        actual=getattr(r,k)
        np.testing.assert_allclose(actual/scales,want/scales,rtol=2e-12,atol=2e-13)
        delta[k]=float(np.max(np.abs((actual-want)/scales)))
    EVENTS[-1]['reference_450dps']={k:[[mp.nstr(v,90) for v in row] for row in rows] for k,rows in ref.items()}
    EVENTS[-1]['max_abs_component_scaled_error']=delta
    return r,ref


def corroborate(c,targets,ref,scales=1,mesh=None):
    if mesh is None: mesh=np.union1d(c['ts'],targets)
    r=run(c,mesh,'cells')
    assert r is not None,c['name']
    values=np.asarray([[float(v) for v in row] for row in ref['defect']])
    for i,(l,u) in enumerate(zip(r.verification_times[:-1],r.verification_times[1:])):
        chosen=(targets>=l)&(targets<=u)
        slack=2e-12*np.asarray(scales)
        assert np.all(values[chosen]>=r.model_lower[i]-slack),(c['name'],'lower',i)
        assert np.all(values[chosen]<=r.model_upper[i]+slack),(c['name'],'upper',i)
    EVENTS[-1]['sampled_reference_inclusion_with_slack']=True
    return r


def canonical():
    for label in ['B1','B2','B3']:
        if label=='B1':
            c=make(label,[-2,-1,1e-17],[[0],[1e20],[0]])
            target=np.asarray([0.])
        elif label=='B2':
            c=make(label,[0,1e300],[[0],[1e-100]])
            target=np.asarray([5e299])
        else:
            c=make(label,[-2,-1,1e-17],[[0,0],[0,1e20],[0,0]],a=1e-20,A=[[0,1],[0,0]])
            target=np.asarray([0.])
        got,ref=cmp_point(c,target,scales=1e-100 if label=='B2' else 1)
        cells=corroborate(c,target,ref,scales=1e-100 if label=='B2' else 1)
        if label=='B1': np.testing.assert_allclose(cells.model_upper[-1,0],float(ref['defect'][0][0]),rtol=2e-12,atol=0)
        if label=='B2': np.testing.assert_allclose(cells.model_upper[0,0],float(ref['defect'][0][0]),rtol=2e-12,atol=0)
        if label=='B3': assert abs(got.defect[0,0])>1000
        # Preserve measured old outputs as history, never as a numerical oracle.
        run(c,target,which=old)
        run(c,np.union1d(c['ts'],target),'cells',old)
        c=dict(c,name=label+'_signed',ys=-c['ys'])
        _,ref=cmp_point(c,target,scales=1e-100 if label=='B2' else 1)
        corroborate(c,target,ref,scales=1e-100 if label=='B2' else 1)


def controls():
    for dtype in [np.float32,np.float64]:
        for a in [.37,1e-24,np.nextafter(dtype(1),dtype(0))]:
            s=np.asarray([2.**-30,2.**30])
            c=make('signed_coupled_'+np.dtype(dtype).name+'_'+str(a),[2.25,2.375,2.75,3.25],
                np.asarray([[.5,-1],[-1,.25],[.125,.75],[.75,-.5]])*s,a=a,
                A=[[-.375,.5/2**60],[-.25*2**60,.125]],powers=[0,.125,3],
                coeff=np.asarray([[-.5,.125],[.375,-.75],[-.125,.25]])*s,dtype=dtype)
            t=np.asarray([2.25,2.3125,2.5,2.875,3.25],dtype=dtype)
            _,ref=cmp_point(c,t,scales=s)
            corroborate(c,t,ref,scales=s)
            # Exact knot identity at both represented input dtypes.
            r=run(c,c['ts'])
            np.testing.assert_array_equal(r.reconstruction,c['ys'].astype(float))
    # Independent transformed quadrature, not incomplete Beta, for the full clock.
    c=make('forcing_clock_history_quadrature',[5,5.125,5.625,6],[[.5,-.75],[1,.25],[-.5,1],[.25,-.5]],
        a=.375,A=[[-.5,.25],[-.125,.375]],powers=[0,.25,3],coeff=[[.25,-.5],[-.125,.375],[.0625,-.125]])
    t=np.asarray([5,5.0625,5.375,5.875,6.])
    _,ref=cmp_point(c,t,quadrature=True)
    corroborate(c,t,ref,mesh=np.asarray([5,6.]))
    translated=dict(c,name='translated_clock',ts=c['ts']-5)
    r0,_=cmp_point(translated,t-5)
    r1=run(c,t)
    np.testing.assert_array_equal(r0.defect,r1.defect)
    # A truncated newest-panel history is discriminated from this original path.
    full=float(ref['fractional_rhs'][-1][0])
    trunc=make('newest_only_control',c['ts'][-2:],c['ys'][-2:],a=c['a'],A=c['A'])
    truncated=reference(trunc,np.asarray([6.]))
    EVENTS.append({'name':'history_discriminator','full_component0_rhs':full,
        'newest_only_no_forcing_rhs':float(truncated['fractional_rhs'][0][0]),
        'difference':abs(full-float(truncated['fractional_rhs'][0][0]))})
    assert abs(full-float(truncated['fractional_rhs'][0][0]))>1e-3
    # Very large times/amplitudes, nonzero coupling, originally shifted terminal.
    c=make('extreme_shift_scales',[-2e180,-1e180,1e180],[[1e90,-2e90],[-.5e90,.25e90],[.25e90,-.75e90]],
        A=[[1e-90,-.25e-90],[.5e-90,1e-90]],powers=[0],coeff=[[.125,-.5]])
    t=np.asarray([-2e180,-1.5e180,-1e180,0,1e180])
    _,ref=cmp_point(c,t,scales=1e90)
    corroborate(c,t,ref,scales=1e90)
    # Zero feedback plus cancelling signed forcing are genuine algebraic zeros.
    c=make('true_zeros',[0,1],[[2,-2],[2,-2]],A=[[.5,.5],[-.25,-.25]],
        powers=[.25,.25],coeff=[[.5,-1],[-.5,1]])
    t=np.asarray([0,.125,.75,1.])
    r,ref=cmp_point(c,t)
    np.testing.assert_array_equal(r.defect,np.zeros((len(t),2)))
    corroborate(c,t,ref)
    # Input validation and explicit work exhaustion remain sibling policies.
    for api in [subject.affine_power_defect,subject.affine_power_cells]:
        try: api(np.asarray([0,1.]),np.zeros((2,1)),np.asarray([0,1.]),order=True,matrix=np.zeros((1,1)),initial_state=np.zeros(1))
        except ValueError: pass
        else: raise AssertionError('bool alpha accepted')
    try: subject.affine_power_cells(np.asarray([0,1.]),np.zeros((2,1)),np.asarray([0,1.]),order=.5,matrix=np.zeros((1,1)),initial_state=np.zeros(1),max_work=1)
    except ValueError as e: assert 'budget exhausted' in str(e)
    else: raise AssertionError('work exhaustion missing')


def weights_and_extrema():
    # Direct endpoint-weight oracle, at branch boundary, aged, active, and extrema.
    weight_records=[]
    for a0 in [1e-25,1e-9,.125,.5,.875,np.nextafter(1.,0.)]:
        a=ex(a0)
        targets=np.asarray([a0,np.nextafter(1.,0.),1.,np.nextafter(1.,2.),
            np.nextafter(2.,1.),2.,np.nextafter(2.,3.),4.,1e30])
        wl,wr=subject._panel_weights(targets,0.,1.,a0)
        for t0,lw,rw in zip(targets,wl,wr):
            age=ex(t0); q=min(mp.mpf(1),age)/age
            total=age**a*mp.betainc(1,a,0,q)/mp.gamma(a)
            rr=age**(a+1)*mp.betainc(2,a,0,q)/mp.gamma(a)
            ll=total-rr
            errors=[float(abs(ex(v)-w)/w) for v,w in [(lw,ll),(rw,rr)]]
            assert max(errors)<2e-12
            weight_records.append({'order':binary(a0),'target':binary(t0),'actual':[float(lw),float(rw)],
                'reference':[mp.nstr(ll,90),mp.nstr(rr,90)],'relative_errors':errors})
        # Both sign siblings with small-q/near-old and active-left interior peak.
        for sign in [1,-1]:
            c=make('extrema_'+str(a0)+'_'+str(sign),[0,1,4],[[sign],[0],[0]],a=a0,A=[[128]])
            t=targets[targets<=4]
            _,ref=cmp_point(c,t,scales=128)
            coarse=corroborate(c,t,ref,scales=128,mesh=c['ts'])
            # Active-left basis peak formula derived by differentiation.
            peak=(a**a)/(mp.gamma(a+1)*(a+1))
            lows,highs=subject._panel_ranges(np.asarray([0.,1.,4.]),0.,1.,a0)
            assert abs(ex(highs[0][0])-peak)/peak<mp.mpf('2e-12')
    (OUT/'weight-probes.json').write_text(json.dumps(weight_records,indent=2)+'\n')
    return {'weight_comparisons':len(weight_records)*2,'max_relative_error':max(max(x['relative_errors']) for x in weight_records)}


def guards():
    cases=[
        (make('matrix_underflow_masked',[0,1],[[1,1e-205],[1,1e-205]],A=[[1,1e-205],[0,0]]),[1.]),
        (make('matrix_underflow_rescuable',[0,1e300],[[1e-200],[1e-200]],A=[[1e-200]]),[1e300]),
        (make('matrix_overflow',[0,1],[[1e200],[1e200]],A=[[1e200]]),[1.]),
        (make('forcing_product_underflow_masked',[0,1e-200],[[0],[0]],powers=[0,1],coeff=[[1],[1e-100]]),[1e-200]),
        (make('forcing_power_underflow',[0,1],[[0],[0]],powers=[1100],coeff=[[1e300]]),[.5]),
        (make('forcing_power_overflow',[0,2],[[0],[0]],powers=[1100],coeff=[[1e-300]]),[2.]),
        (make('forcing_reduction_overflow',[0,1],[[0],[0]],a=1e-20,powers=[0,0],coeff=[[1e308],[1e308]]),[1.]),
        (make('reconstruction_ratio_underflow',[0,1e300],[[0],[1e300]]),[1e-100]),
        (make('reconstruction_difference_overflow',[-1e308,1e308],[[0],[1]]),[0.]),
        (make('reconstruction_product_underflow',[0,1],[[0],[1e-300]]),[1e-100]),
        (make('panel_product_underflow',[0,1e-200],[[0],[1e-300]],A=[[1.]]),[1e-200]),
        (make('peak_underflow',[0,1e-200],[[1],[0]],a=1e-200,A=[[1.]]),[1e-200]),
    ]
    for c,t in cases:
        for api in ['point','cells']:
            targets=np.union1d(c['ts'],t) if api=='cells' else np.asarray(t)
            result=run(c,targets,api)
            # Peak product is only needed by cell extrema; its point sibling is safe.
            if c['name']=='peak_underflow' and api=='point': assert result is not None
            else: assert result is None,(c['name'],api)
    # Exercise the three direct private guards with real NumPy underflow.
    # Silent-zero postconditions are reviewed separately, without source edits.
    probes=[('multiply',subject._multiply,(1e-200,1e-200)),
        ('divide',subject._divide,(1e-200,1e200)),('power',subject._power,(.5,1100.))]
    for name,op,args in probes:
        try: op(*args,'independent primitive')
        except FloatingPointError as err: assert str(err)
        else: raise AssertionError(name+' missing range guard')
    # Check exact subnormal versus inexact subnormal behavior in this NumPy build.
    primitive=[]
    for name,args,fn in [('exact_subnormal_product',(2.**-1022,.5),np.multiply),
        ('inexact_subnormal_product',(1e-200,1e-110),np.multiply),
        ('exact_cancel',(1.,-1.),np.add),('small_add_lost',(1e20,1.),np.add)]:
        try:
            with np.errstate(all='raise'): v=fn(*map(np.float64,args))
            primitive.append({'name':name,'outcome':'returned','value':float(v)})
        except FloatingPointError as err: primitive.append({'name':name,'outcome':'FloatingPointError','message':str(err)})
    return primitive


def conditioning():
    c=make('parent_conditioning',[0,1],[[1e20,1,-1e20],[1e20,1,-1e20]],A=[[1,1,1],[0,0,0],[0,0,0]])
    r=run(c,np.asarray([1.]))
    cells=run(c,c['ts'],'cells')
    ref=reference(c,np.asarray([1.]))
    exact_rhs=ref['fractional_rhs'][0][0]
    assert r.defect[0,0]==cells.model_lower[0,0]==cells.model_upper[0,0]==0
    assert abs(exact_rhs-2/mp.sqrt(mp.pi))<mp.mpf('1e-400')
    terms=[ex(1e20),mp.mpf(1),-ex(1e20)]
    absolute_sum=mp.fsum(abs(v) for v in terms)
    exact_feedback=mp.fsum(terms)
    kappa=absolute_sum/abs(exact_feedback)
    unit_roundoff=mp.mpf(2)**-53
    # Three explicit ordered additions from zero; gamma_3 is conservative.
    gamma3=3*unit_roundoff/(1-3*unit_roundoff)
    bound=gamma3*absolute_sum
    permutations=[]
    for perm in [(0,1,2),(0,2,1),(1,0,2),(2,0,1)]:
        cp=dict(c,name='conditioning_permutation_'+''.join(map(str,perm)),ys=c['ys'][:,perm],A=c['A'][:,perm])
        rp=run(cp,np.asarray([1.]))
        permutations.append({'permutation':perm,'feedback':subject._feedback(cp['ys'],cp['A']).tolist(),'point_defect':rp.defect.tolist()})
    out={'input':{k:binary(v) for k,v in c.items() if k!='name'},'point':r.to_dict(),'cells':cells.to_dict(),
        'reference_defect_component0':mp.nstr(-exact_rhs,110),'reference_feedback':mp.nstr(exact_feedback,80),
        'absolute_point_error':mp.nstr(exact_rhs,80),'relative_point_error':1.0,
        'feedback_sum_abs_terms':mp.nstr(absolute_sum,80),'feedback_componentwise_relative_condition':mp.nstr(kappa,80),
        'unit_roundoff':mp.nstr(unit_roundoff,80),'kappa_times_unit_roundoff':mp.nstr(kappa*unit_roundoff,80),
        'feedback_forward_error_bound_gamma3_sumabs':mp.nstr(bound,80),
        'actual_feedback_error':1.0,'feedback_error_over_sumabs':mp.nstr(1/absolute_sum,80),
        'permutation_controls':permutations,'is_underflow':False}
    (OUT/'conditioning-probe.json').write_text(json.dumps(out,indent=2)+'\n')
    return {k:out[k] for k in ['reference_defect_component0','relative_point_error','kappa_times_unit_roundoff','feedback_error_over_sumabs','is_underflow']}


def special_function_range_controls():
    rec=[]
    for a0 in [1e-25,.125,.5,.875,np.nextafter(1.,0.)]:
        for b0 in [0,.25,3,1e8,1e16,1e100,1e300]:
            val=subject._power_integral_ratio(np.float64(b0),float(a0))
            a,b=ex(a0),ex(b0)
            ref=mp.exp(mp.loggamma(b+1)-mp.loggamma(b+a+1))
            rel=float(abs(ex(val)-ref)/ref)
            assert rel<2e-12
            rec.append({'order':binary(a0),'beta':binary(b0),'actual':float(val),'reference':mp.nstr(ref,90),'relative_error':rel})
    (OUT/'special-function-probes.json').write_text(json.dumps(rec,indent=2)+'\n')
    # For the called parameter domains gamma(1+a), old small-q hyp2f1 and
    # poch(beta+1,a) cannot themselves approach zero. Checking finite positivity
    # plus the explicit products is not a claim about hidden series terms.
    return {'gamma_ratio_comparisons':len(rec),'max_relative_error':max(r['relative_error'] for r in rec)}


def main():
    summary={'reviewed_tree':TREE,'independent_math':'450-digit exact-binary incomplete Beta plus transformed panel quadrature; no production test/reference imports'}
    try:
        canonical(); controls()
        summary.update(weights_and_extrema())
        summary['primitive_range_behavior']=guards()
        summary['conditioning_probe']=conditioning()
        summary.update(special_function_range_controls())
        summary['completed']=True
    except BaseException as err:
        summary.update(completed=False,error=type(err).__name__+': '+str(err))
        raise
    finally:
        (OUT/'independent-probes.json').write_text(json.dumps(EVENTS,indent=2,allow_nan=False)+'\n')
        summary['event_count']=len(EVENTS)
        summary['outcome_counts']={o:sum(e.get('outcome')==o for e in EVENTS) for o in ['returned','FloatingPointError']}
        (OUT/'independent-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
