"""Check positive PL panel-basis weights without global slope jumps."""
import json
from pathlib import Path

import mpmath as mp
import numpy as np
from scipy.special import gamma, hyp2f1


def weights(tau, width, a):
    cut = min(tau, width)
    q = cut/tau
    mass = tau**a/gamma(a+1)
    if q == 1:
        left, right = mass*a/(a+1), mass/(a+1)
    elif q < .5:
        factor = mass*q*a/2
        left = factor*hyp2f1(1-a, 1., 3., q)
        right = factor*hyp2f1(1-a, 2., 3., q)
    else:
        z = (tau-width)/tau
        logz = np.log(z)
        left = mass/q*(a/(a+1) + z*np.expm1(a*logz-np.log1p(a)))
        right = mass/q*(-np.expm1(a*logz) + a/(a+1)*np.expm1((a+1)*logz))
    fraction = cut/width
    return left + right*(1-fraction), right*fraction


rows = []
with mp.workdps(130):
    for alpha in (.3, .5, .75):
        for tau, width in ((1., 1e-17), (1., .125), (1., .5),
                           (1., np.nextafter(1., 0.)), (1., 1.), (.5, 1.)):
            a, t, h = mp.mpf(alpha), mp.mpf(float(tau)), mp.mpf(float(width))
            cut = min(t, h)
            expected = [mp.quad(lambda s: (1-s/h)*(t-s)**(a-1), [0, cut])/mp.gamma(a),
                        mp.quad(lambda s: (s/h)*(t-s)**(a-1), [0, cut])/mp.gamma(a)]
            actual = weights(tau, width, alpha)
            errors = [float(abs(mp.mpf(float(x))/truth-1))
                      for x, truth in zip(actual, expected, strict=True)]
            assert max(errors) < 2e-12, (alpha, tau, width, errors)
            assert all(x >= 0 for x in actual)
            rows.append({"order": alpha, "tau": float(tau), "width": float(width),
                         "weights": actual, "relative_errors": errors})
output = {"scope": "empirical positive-basis formula checks, not verified arithmetic",
          "cases": rows, "count": len(rows),
          "maximum_relative_error": max(max(row["relative_errors"]) for row in rows)}
Path(__file__).with_suffix(".json").write_text(json.dumps(output, indent=2)+"\n")
print(json.dumps({"count": output["count"],
                  "maximum_relative_error": output["maximum_relative_error"]}))
