"""Aggregate observed review results into a fail-closed JSON verdict."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent

def read(name):
    return json.loads((OUT/name).read_text())

independent=read('independent-results.json')
history=read('historical-replay.json')
identity=read('final-integrity.json')
static=read('static-recheck.json')
fixture=read('fixture-integrity.json')
targeted=ET.parse(OUT/'targeted.xml').getroot()
suites=[s.attrib for s in targeted.iter('testsuite')]
counts={key:sum(int(s.get(key,'0')) for s in suites) for key in ('tests','failures','errors','skipped')}
runs={k:read(k+'.run.json') for k in ('targeted','independent','history','lint')}
security=static['findings']
logic=[]
if counts!={'tests':55,'failures':0,'errors':0,'skipped':0}:
    logic.append({'check':'focused_suite','actual':counts})
if not independent['passed']:
    logic.append({'check':'independent_probes','failed':[r for r in independent['checks'] if not r['passed']]})
if not history['passed']:
    logic.append({'check':'historical_replay','error':'Historical corroboration failed'})
if not identity['passed']:
    logic.append({'check':'frozen_target_integrity','evidence':identity})
for name,record in runs.items():
    if record['exit_code']!=0:
        logic.append({'check':name,'exit_code':record['exit_code']})

metrics={'focused_tests':counts,'independent_check_groups':len(independent['checks']),
         'independent_group_failures':sum(not x['passed'] for x in independent['checks']),
         'seeded_random_cases':len(independent['details']['seeded-random-panel-and-cell-crosschecks']),
         'raw_kind_rejections':independent['details']['raw-kind-guards-both-entrypoints']['rejected_count'],
         'shape_finite_domain_rejections':independent['details']['shape-order-finite-domain-and-mesh-guards']['rejected_count'],
         'overflow_cases':len(independent['details']['finite-input-nonfinite-arithmetic-fails-closed']),
         'historical_red_cases_replayed':sum(r['cases'] for r in history['feature_replays']),
         'fixture_count':len(fixture['case_ids']),'snapshot_files_verified':identity['snapshot_checked_count'],
         'full_suite_run_or_claimed':False,
         'under_enclosure_limitation':independent['details']['positive-width-under-enclosure-honestly-uncertified']}
(OUT/'review-metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')

analysis={'scope':'Only the staged three-file delta from baseline 74d8f08 to frozen tree 6e7a156f025e08b31a314c5bda59183d6a96bf32 is approved by passed.',
          'formulas':{
              'reconstruction':'Y(t)=y0+v0*(t-t0)+sum_j J_j*(t-t_j)_+, all interior knots retained.',
              'fractional_state':'I^aY=y0*(t-t0)^a/Gamma(a+1)+(v0*(t-t0)^(a+1)+sum_j J_j*(t-t_j)_+^(a+1))/Gamma(a+2).',
              'forcing':'I^a[c_beta*(t-t0)^beta]=c_beta*Gamma(beta+1)/Gamma(beta+a+1)*(t-t0)^(beta+a).',
              'orientation':'Point evaluator uses integral @ A.T for row-stored states. Cell coefficients use -(A @ vector); both match column-state A*Y.',
              'cells':'Every positive-part power has strictly positive exponent. For each signed component coefficient, endpoint min/max are added termwise; natural-extension inclusion is only a real-arithmetic theorem.',
              'partition':'Union of strictly increasing full-horizon verification mesh with all original knots; original t0 retained.',
              'budget':'(cell_count)*(3+2*(node_count-2)+forcing_power_count)*(state_dim), including zero coefficient terms; exact boundary accepted, one-below rejected before term enumeration.'},
          'guard_scope':'Finite real float32/float64 raw inputs only; scalar order in (0,1); strict stored times; 2-D nonempty state; matching matrix and initial state; finite nonnegative powers and aligned coefficients; targets in original horizon; stricter full-horizon cell mesh. Nonfinite arithmetic raises.',
          'metadata':'Both result classes lock arithmetic_verified=False and total_numerical_certified=False with init=False in frozen dataclasses; strict JSON export and host CPU float64 provenance corroborated.',
          'expected_limitation':metrics['under_enclosure_limitation'],
          'remaining_a1_gates':['Componentwise feedback propagation and controlled Neumann/resolvent tails',
                                'Verified arithmetic and separate input/evaluation/output error budgets',
                                'Justified nonlinear domains and tube closure',
                                'Full required scientific matrix, solver/controller integration and declared JAX/gradient gates'],
          'review_issues':[{'type':'probe authoring, not production defect','detail':'Initial metadata probe expected ValueError only from dataclasses.replace(init=False); this interpreter raises TypeError. Original source/output preserved in probe-authoring-attempt1; corrected exception-class check passes.'},
                           {'type':'concurrent worktree activity outside target','detail':'Whole-worktree postcheck detected two unrelated documentation edits. Frozen three-file inputs, all 125 snapshot source files, and exact index bytes remain unchanged; other docs are not approved.'}],
          'no_repo_writes':'Only new scratch evidence/checks were written; no repository/index/source/fixture/docs/committed artifact changes, no full suite, commit or push.'}
(OUT/'review-analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
verdict={'passed':not security and not logic,'security_concerns':security,'logic_errors':logic,
         'suggestions':[
             'Keep A1 acceptance false: feedback/tail propagation, verified arithmetic/error budgets, nonlinear-domain closure, required matrix and solver/controller JAX/gradient gates remain open.',
             'Retain the positive-width float64 under-enclosure regression and both false certification flags; the observed miss is an expected documented limitation, not evidence of enclosure or certification.',
             'This approval is limited to the frozen three-file implementation/artifact delta. Concurrent unstaged documentation changes are outside this review.'
         ],
         'summary':'Scoped code/artifact approval only: no security or logic errors found; 55 focused CPU tests, 15 independent probe groups including 24 seeded cases, 39 historical RED-to-current replays and focused lint passed. Raw fixtures, original protocol archive, 125-file snapshot and unchanged frozen index were verified; no full-suite result is claimed.',
         'reviewed_tree':'6e7a156f025e08b31a314c5bda59183d6a96bf32',
         'evidence_paths':[str(OUT/'evidence-index.json'),str(OUT/'review-analysis.json'),str(OUT/'review-metrics.json'),
                           str(OUT/'targeted.xml'),str(OUT/'independent-results.json'),str(OUT/'historical-replay.json'),
                           str(OUT/'final-integrity.json')],
         'a1_acceptance_passed':False}
assert isinstance(verdict['passed'],bool) and verdict['a1_acceptance_passed'] is False
assert not verdict['passed'] or not verdict['security_concerns'] and not verdict['logic_errors']
(OUT/'verdict.json').write_text(json.dumps(verdict,indent=2,allow_nan=False)+'\n')
paths=sorted(p for p in OUT.iterdir() if p.is_file() and p.name!='evidence-index.json')
paths+=sorted(p for p in (OUT/'probe-authoring-attempt1').iterdir() if p.is_file())
index={'root':str(OUT),'files':[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,
                              'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths],
       'executables':['collect_evidence.py','run_focused.py','independent_probes.py','historical_replay.py','verify_final_identity.py','finalize_review.py'],
       'replay':'PYTHONDONTWRITEBYTECODE=1 python run_focused.py targeted independent history lint; PYTHONDONTWRITEBYTECODE=1 python verify_final_identity.py',
       'note':'collect_evidence.py requires the full original worktree snapshot and therefore intentionally fails after unrelated docs are edited; use final-integrity.json for scoped end-of-review identity. Only scratch output may be regenerated.'}
(OUT/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'verdict':verdict,'metrics':metrics},indent=2))
