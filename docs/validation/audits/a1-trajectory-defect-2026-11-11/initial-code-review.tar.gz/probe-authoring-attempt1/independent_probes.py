"""Independent host-reference probes; no production/test helpers are reused.

Writes only review evidence beside this script. Approximation tolerances below
are oracle-comparison tolerances, never error bounds or certification budgets.
"""
import dataclasses
import hashlib
import importlib
import json
from pathlib import Path
import sys
import traceback

import mpmath as mp
import numpy as np
import scipy

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from benchmarks.numerical import _volterra_defect as impl

ROWS = []
DETAILS = {}

def check(name, function):
    try:
        detail = function()
        ROWS.append({'name':name,'passed':True})
        DETAILS[name] = detail
    except Exception as exc:
        ROWS.append({'name':name,'passed':False,'error_type':type(exc).__name__,'message':str(exc)})
        DETAILS[name] = traceback.format_exc()

def real(x):
    numerator, denominator = float(x).as_integer_ratio()
    return mp.mpf(numerator)/denominator

def decode(x):
    if isinstance(x, dict):
        return float.fromhex(x['hex'])
    return np.asarray([decode(v) for v in x], dtype=np.float64)

def args_for(case):
    ts, states = decode(case['ts']), decode(case['states'])
    return dict(ts=ts, states=states, order=decode(case['alpha']),
                matrix=decode(case['A']),initial_state=decode(case['initial_state']),
                power_exponents=decode([q['beta'] for q in case['forcing']]),
                power_coefficients=decode([q['coefficient'] for q in case['forcing']]))

def basic():
    return dict(ts=np.array([0.,1.]),states=np.array([[0.],[1.]]),order=.5,
                matrix=np.array([[-.25]]),initial_state=np.array([0.]),
                power_exponents=np.array([0.,.25]),power_coefficients=np.array([[.3],[-.7]]))

def point(p, targets):
    return impl.affine_power_defect(**p, evaluation_times=np.asarray(targets,dtype=np.float64))

def cells(p, mesh, **kw):
    return impl.affine_power_cells(**p, verification_mesh=np.asarray(mesh,dtype=np.float64),**kw)

def oracle(p, t):
    """Local panel moments, never slope-jump expansion or production functions."""
    ts = list(map(real,p['ts']))
    yy = [[real(v) for v in row] for row in p['states']]
    a = real(p['order'])
    target = real(t)
    d = len(yy[0])
    iy = [mp.mpf(0) for _ in range(d)]
    yy_t = yy[0]
    for j in range(len(ts)-1):
        left, end = ts[j], ts[j+1]
        if target < left:
            break
        right = min(target,end)
        v = [(yy[j+1][i]-yy[j][i])/(end-left) for i in range(d)]
        if target <= end:
            yy_t = [yy[j][i]+v[i]*(target-left) for i in range(d)]
        elif j == len(ts)-2:
            yy_t = yy[-1]
        if right <= left:
            continue
        u, w = target-left,target-right
        for i in range(d):
            iy[i] += ((yy[j][i]+v[i]*u)*(u**a-w**a)/mp.gamma(a+1)
                      - v[i]*a*(u**(a+1)-w**(a+1))/mp.gamma(a+2))
    tau = target-ts[0]
    forcing = [mp.fsum(real(row[i])*mp.gamma(real(b)+1)/mp.gamma(real(b)+a+1)*tau**(real(b)+a)
                        for b,row in zip(p['power_exponents'],p['power_coefficients'],strict=True)) for i in range(d)]
    rhs = [mp.fsum(real(p['matrix'][i,k])*iy[k] for k in range(d))+forcing[i] for i in range(d)]
    defect = [yy_t[i]-real(p['initial_state'][i])-rhs[i] for i in range(d)]
    return yy_t, rhs, defect

def mp_ranges(p, edges):
    """Signed natural extension built in high precision from raw represented data."""
    ts = list(map(real,p['ts']))
    states = [[real(v) for v in row] for row in p['states']]
    mat = [[real(v) for v in row] for row in p['matrix']]
    a = real(p['order'])
    d = len(states[0])
    slopes = [[(states[j+1][i]-states[j][i])/(ts[j+1]-ts[j]) for i in range(d)] for j in range(len(ts)-1)]
    terms = [(ts[0],mp.mpf(1),slopes[0])]
    jumps = [[slopes[j][i]-slopes[j-1][i] for i in range(d)] for j in range(1,len(slopes))]
    terms.extend((ts[j+1],mp.mpf(1),jump) for j,jump in enumerate(jumps))
    def transform(v, normalization):
        return [-mp.fsum(mat[i][k]*v[k] for k in range(d))/normalization for i in range(d)]
    terms.append((ts[0],a,transform(states[0],mp.gamma(a+1))))
    terms.append((ts[0],a+1,transform(slopes[0],mp.gamma(a+2))))
    terms.extend((ts[j+1],a+1,transform(jump,mp.gamma(a+2))) for j,jump in enumerate(jumps))
    for b,row in zip(p['power_exponents'],p['power_coefficients'],strict=True):
        b = real(b)
        terms.append((ts[0],a+b,[-real(c)*mp.gamma(b+1)/mp.gamma(b+a+1) for c in row]))
    ranges = []
    for left,right in zip(edges[:-1],edges[1:],strict=True):
        lo, hi = [mp.mpf(0)]*d,[mp.mpf(0)]*d
        for origin,power,coeff in terms:
            x,y = max(real(left)-origin,0)**power,max(real(right)-origin,0)**power
            for i,c in enumerate(coeff):
                lo[i] += min(x*c,y*c)
                hi[i] += max(x*c,y*c)
        ranges.append((lo,hi))
    return terms,ranges

FIXTURE = ROOT/'docs/validation/audits/a1-trajectory-defect-2026-11-11/frozen-fixtures.json'
FROZEN = json.loads(FIXTURE.read_bytes())['cases']

def frozen_oracle_case(case):
    p = args_for(case)
    targets = np.unique(np.concatenate((p['ts'],(p['ts'][:-1]+p['ts'][1:])/2)))
    actual = point(p, targets)
    scales = decode(case['scales']) if 'scales' in case else np.ones(p['states'].shape[1])
    with mp.workdps(100):
        reference = [oracle(p,t) for t in targets]
        expected_y = np.array([[float(v) for v in r[0]] for r in reference])
        expected_rhs = np.array([[float(v) for v in r[1]] for r in reference])
        expected_defect = np.array([[float(v) for v in r[2]] for r in reference])
    np.testing.assert_allclose(actual.reconstruction/scales,expected_y/scales,rtol=2e-12,atol=3e-13)
    np.testing.assert_allclose(actual.fractional_rhs/scales,expected_rhs/scales,rtol=2e-12,atol=3e-13)
    np.testing.assert_allclose(actual.defect/scales,expected_defect/scales,rtol=2e-12,atol=3e-13)
    return {'targets':targets.tolist(),'max_scaled_rhs_error':float(np.max(np.abs((actual.fractional_rhs-expected_rhs)/scales))),
            'oracle':'100-digit independent panel moments; raw inputs via integer ratios'}

for case in FROZEN:
    check('frozen-panel-oracle:'+case['id'],lambda case=case:frozen_oracle_case(case))

def coupled_orientation():
    p = dict(ts=np.array([-2.,-1.75,-1.,.25]),
             states=np.array([[2.,-3.],[-1.,4.],[7.,1.],[3.,-2.]]),order=.37,
             matrix=np.array([[.125,2.],[-3.,.0625]]),initial_state=np.array([2.,-3.]),
             power_exponents=np.array([0.,.125,1.,3.]),
             power_coefficients=np.array([[1.,-2.],[-.3,.7],[.8,-.2],[-.125,.25]]))
    targets=np.array([-2.,-1.875,-1.375,-.5,.25])
    with mp.workdps(100):
        references=[oracle(p,t) for t in targets]
        expected=np.array([[float(x) for x in row[1]] for row in references])
    got=point(p,targets)
    np.testing.assert_allclose(got.fractional_rhs,expected,rtol=2e-12,atol=2e-13)
    transposed=dict(p,matrix=p['matrix'].T)
    wrong=point(transposed,targets)
    gap=float(np.max(np.abs(wrong.fractional_rhs-expected)))
    assert gap>1
    mesh=np.array([-2.,-1.9,-1.25,0.,.25])
    result=cells(p,mesh)
    edges=np.union1d(p['ts'],mesh)
    np.testing.assert_array_equal(result.verification_times,edges)
    with mp.workdps(100):
        terms,ranges=mp_ranges(p,edges)
        expected_lo=np.array([[float(x) for x in r[0]] for r in ranges])
        expected_hi=np.array([[float(x) for x in r[1]] for r in ranges])
        for index,(left,right) in enumerate(zip(edges[:-1],edges[1:],strict=True)):
            for target in np.linspace(left,right,11):
                exact=oracle(p,target)[2]
                assert all(ranges[index][0][i]<=exact[i]<=ranges[index][1][i] for i in range(2))
    np.testing.assert_allclose(result.model_lower,expected_lo,rtol=2e-12,atol=2e-13)
    np.testing.assert_allclose(result.model_upper,expected_hi,rtol=2e-12,atol=2e-13)
    return {'transpose_negative_control_gap':gap,'retained_edges':edges.tolist(),'term_count':len(terms),
            'cell_comparison':'ordinary-f64 oracle agreement only; exact-model sampled inclusion checked at mp100'}
check('nondiagonal-orientation-and-signed-cell-formula',coupled_orientation)

def randomized_cases():
    rng=np.random.default_rng(2026111101)
    records=[]
    with mp.workdps(90):
        for i in range(24):
            dtype=np.float32 if i%2 else np.float64
            n=2+i%5
            d=1+i%3
            ts=np.asarray(-.4+np.concatenate(([0.],np.cumsum(rng.uniform(.05,.4,n-1)))),dtype=dtype)
            states=np.asarray(rng.uniform(-2.,2.,(n,d)),dtype=dtype)
            p=dict(ts=ts,states=states,order=dtype([.07,.27,.68,.97][i%4]),
                   matrix=np.asarray(rng.uniform(-.5,.5,(d,d)),dtype=dtype),initial_state=states[0],
                   power_exponents=np.asarray([0.,.17,2.,3.],dtype=dtype),
                   power_coefficients=np.asarray(rng.uniform(-1.,1.,(4,d)),dtype=dtype))
            targets=np.concatenate((ts, (ts[:-1].astype(np.float64)+ts[1:])/2))
            actual=point(p,targets)
            expected=np.array([[float(x) for x in oracle(p,t)[2]] for t in targets])
            np.testing.assert_allclose(actual.defect,expected,rtol=2e-11,atol=3e-12)
            mesh=np.linspace(float(ts[0]),float(ts[-1]),7)
            ranges=cells(p,mesh)
            _,exact_ranges=mp_ranges(p,ranges.verification_times)
            el=np.array([[float(x) for x in r[0]] for r in exact_ranges])
            eu=np.array([[float(x) for x in r[1]] for r in exact_ranges])
            np.testing.assert_allclose(ranges.model_lower,el,rtol=2e-11,atol=3e-12)
            np.testing.assert_allclose(ranges.model_upper,eu,rtol=2e-11,atol=3e-12)
            records.append({'case':i,'input_dtype':np.dtype(dtype).name,'panels':n-1,'components':d,
                            'max_defect_absolute_error':float(np.max(np.abs(actual.defect-expected)))})
    return records
check('seeded-random-panel-and-cell-crosschecks',randomized_cases)

def input_kinds():
    rejected=[]
    base=basic()
    fields=['ts','states','order','matrix','initial_state','power_exponents','power_coefficients']
    variants=[('bool',np.bool_),('int64',np.int64),('float16',np.float16),('complex128',np.complex128),('object',object),('unicode',str),('longdouble',np.longdouble)]
    for field in fields:
        for label,dtype in variants:
            if np.dtype(dtype).kind=='f' and np.dtype(dtype).itemsize in (4,8):
                continue
            p=dict(base)
            p[field]=np.asarray(base[field],dtype=dtype)
            for which in ('point','cells'):
                try:
                    (point(p,[0.,1.]) if which=='point' else cells(p,[0.,1.]))
                except ValueError:
                    rejected.append([which,field,label])
                else:
                    raise AssertionError((which,field,label,'accepted unsupported raw kind'))
    for label,dtype in variants:
        if np.dtype(dtype).kind=='f' and np.dtype(dtype).itemsize in (4,8):
            continue
        for which in ('point','cells'):
            try:
                target=np.array([0.,1.],dtype=dtype)
                if which=='point':
                    impl.affine_power_defect(**base,evaluation_times=target)
                else:
                    impl.affine_power_cells(**base,verification_mesh=target)
            except ValueError:
                rejected.append([which,'targets',label])
            else:
                raise AssertionError((which,'targets',label,'accepted'))
    return {'rejected_count':len(rejected),'rejections':rejected}
check('raw-kind-guards-both-entrypoints',input_kinds)

def finite_and_shape_guards():
    rejected=[]
    base=basic()
    variants={
        'ts':[np.array([0.,np.nan]),np.array([0.,np.inf]),np.array([1.,0.]),np.array([0.,0.]),np.array([0.]),np.array([[0.,1.]])],
        'states':[np.empty((2,0)),np.zeros((1,1)),np.zeros((2,1,1)),np.array([[0.],[np.inf]])],
        'order':[0.,1.,-.1,1.1,np.inf,np.nan,np.array([.5])],
        'matrix':[np.eye(2),np.array([-.25]),np.array([[np.inf]])],
        'initial_state':[np.array([1.]),np.array([[0.]]),np.array([np.nan])],
        'power_exponents':[np.array([-.1,.25]),np.array([0.,np.inf]),np.array([[0.,.25]])],
        'power_coefficients':[np.array([[.3]]),np.array([.3,-.7]),np.array([[.3],[np.nan]])],
    }
    for field,values in variants.items():
        for i,value in enumerate(values):
            p=dict(base)
            p[field]=value
            for which in ('point','cells'):
                try:
                    (point(p,[0.,1.]) if which=='point' else cells(p,[0.,1.]))
                except ValueError:
                    rejected.append([which,field,i])
                else:
                    raise AssertionError((which,field,i,'accepted'))
    for targets in ([],[-.1,1.],[0.,1.1],[np.nan],[np.inf],[[0.,1.]]):
        for which in ('point','cells'):
            try:
                (point(base,targets) if which=='point' else cells(base,targets))
            except ValueError:
                rejected.append([which,'targets',repr(targets)])
            else:
                raise AssertionError((which,targets,'accepted'))
    # Arbitrary target order and duplicates are legal for point evaluation only.
    result=point(base,[1.,0.,.5,.5])
    np.testing.assert_array_equal(result.evaluation_times,[1.,0.,.5,.5])
    for mesh in ([0.,.5],[.5,1.],[0.,0.,1.],[0.,1.,.5,1.],[0.],[1.,0.]):
        try:
            cells(base,mesh)
        except ValueError:
            rejected.append(['cells','mesh',mesh])
        else:
            raise AssertionError(('cells',mesh,'accepted'))
    return {'rejected_count':len(rejected),'rejections':rejected,'unordered_point_targets_preserved':True}
check('shape-order-finite-domain-and-mesh-guards',finite_and_shape_guards)

def budget_checks():
    p=dict(ts=np.array([0.,.2,.7,1.]),states=np.array([[0.,1.],[1.,-2.],[-3.,1.],[2.,0.]]),
           order=.4,matrix=np.array([[.2,-.1],[.7,-.3]]),initial_state=np.array([0.,1.]),
           power_exponents=np.array([0.,.25,3.]),power_coefficients=np.array([[1.,-2.],[-.5,1.],[.3,-.7]]))
    mesh=np.array([0.,.1,.4,.8,1.])
    edges=np.union1d(p['ts'],mesh)
    expected=(len(edges)-1)*(2*len(p['ts'])-1+len(p['power_exponents']))*2
    exact=cells(p,mesh,max_work=expected)
    assert exact.provenance.config['cell_term_components']==expected
    np.testing.assert_array_equal(exact.verification_times,edges)
    try:
        cells(p,mesh,max_work=expected-1)
    except ValueError as exc:
        assert 'Cell work budget exhausted' in str(exc)
    else:
        raise AssertionError('off-by-one budget accepted')
    invalid=[0,-1,True,False,1.,1.5,np.int64(1000),np.array(1000),None,1+0j,float('inf')]
    for v in invalid:
        try:
            cells(p,mesh,max_work=v)
        except ValueError as exc:
            assert 'positive integer max_work' in str(exc)
        else:
            raise AssertionError(('bad max_work accepted',repr(v)))
    original=impl._defect_terms
    def forbidden(_):
        raise AssertionError('term evaluation must not start after work exhaustion')
    impl._defect_terms=forbidden
    try:
        try:
            cells(p,mesh,max_work=expected-1)
        except ValueError as exc:
            assert 'Cell work budget exhausted' in str(exc)
        else:
            raise AssertionError('expected work exhaustion')
    finally:
        impl._defect_terms=original
    return {'exact_work':expected,'retained_edges':edges.tolist(),'invalid_budgets_rejected':len(invalid),
            'rejected_before_term_evaluation':True,'claim':'cell-term-component cap only; not memory, matrix-setup, or wall-time cap'}
check('workbudget-exact-boundary-canonical-types-no-truncation',budget_checks)

def numerical_overflow_guards():
    variants=[]
    variants.append(dict(ts=np.array([0.,1.]),states=np.array([[1e308],[1e308]]),order=.5,
                         matrix=np.array([[1e308]]),initial_state=np.array([1e308])))
    variants.append(dict(ts=np.array([-1e308,1e308]),states=np.array([[0.],[1.]]),order=.5,
                         matrix=np.array([[1.]]),initial_state=np.array([0.])))
    variants.append(dict(ts=np.array([0.,1e-308]),states=np.array([[0.],[1e308]]),order=.5,
                         matrix=np.array([[1.]]),initial_state=np.array([0.])))
    variants.append(dict(ts=np.array([0.,1.]),states=np.array([[0.],[1.]]),order=.5,
                         matrix=np.array([[0.]]),initial_state=np.array([0.]),
                         power_exponents=np.array([1e308]),power_coefficients=np.array([[1.]])))
    results=[]
    for i,p in enumerate(variants):
        for which in ('point','cells'):
            try:
                (point(p,[p['ts'][-1]]) if which=='point' else cells(p,p['ts']))
            except FloatingPointError as exc:
                results.append({'case':i,'entrypoint':which,'exception':str(exc)})
            else:
                raise AssertionError((i,which,'returned instead of failing on nonfinite arithmetic'))
    return results
check('finite-input-nonfinite-arithmetic-fails-closed',numerical_overflow_guards)

def history_discriminators():
    p=args_for(FROZEN[0])
    ts=p['ts']
    targets=np.array([decode(FROZEN[0]['probe_t']),ts[-1]])
    result=point(p,targets)
    nodal=point(p,ts)
    with mp.workdps(100):
        a=real(p['order']); beta=real(p['power_exponents'][0]); t=real(ts[-1]); last=real(ts[-2]); origin=real(ts[0])
        full=mp.gamma(beta+1)/mp.gamma(beta+a+1)*(t-origin)**(beta+a)
        newest=mp.quad(lambda u:(t-u**(1/a)-origin)**beta,[0,(t-last)**a])/mp.gamma(a+1)
        full_defect=real(p['states'][-1,0])-full
        newest_only=real(p['states'][-1,0])-newest
        reset=real(p['states'][-1,0])-real(p['states'][-2,0])-mp.gamma(beta+1)/mp.gamma(beta+a+1)*(t-last)**(beta+a)
        newest_gap=float(abs(full_defect-newest_only)); reset_gap=float(abs(full_defect-reset))
    req=FROZEN[0]['frozen_requirements']
    assert float(np.max(np.abs(nodal.defect)))<decode(req['max_nodal_abs_defect_lt'])
    assert abs(float(result.defect[0,0]))>decode(req['abs_interior_defect_gt'])
    assert newest_gap>decode(req['full_vs_newest_only_endpoint_difference_gt'])
    assert reset_gap>decode(req['full_vs_reset_endpoint_difference_gt'])
    # Different old history, identical newest panel: a real feedback-history discriminator.
    p=basic(); p.update(ts=np.array([2.,2.25,2.75,3.]),states=np.array([[1.],[2.],[1.],[1.5]]),initial_state=np.array([1.]))
    q=dict(p,states=p['states'].copy()); q['states'][1,0]=-3.
    full_difference=float(abs(point(p,[3.]).defect[0,0]-point(q,[3.]).defect[0,0]))
    assert full_difference>.01
    return {'max_nodal_abs_defect':float(np.max(np.abs(nodal.defect))),'interior_defect':float(result.defect[0,0]),
            'newest_only_endpoint_gap':newest_gap,'reset_endpoint_gap':reset_gap,
            'changed_old_panel_same_newest_panel_defect_gap':full_difference,
            'negative_control_scope':'formula-discrimination checks, not scientific solution-error acceptance'}
check('frozen-nodal-and-history-shortcut-discriminators',history_discriminators)

def metadata_and_immutability():
    p=basic()
    original={k:np.array(v,copy=True) for k,v in p.items()}
    results=[point(p,[0.,.5,1.]),cells(p,[0.,.5,1.])]
    for result in results:
        assert result.arithmetic_verified is result.total_numerical_certified is False
        assert result.provenance.backend=='numpy/scipy'
        assert result.provenance.runtime_target.value=='cpu'
        assert 'unverified' in result.provenance.config['arithmetic']
        exported=result.to_dict()
        assert exported['arithmetic_verified'] is exported['total_numerical_certified'] is False
        json.dumps(exported,allow_nan=False)
        for field in ('arithmetic_verified','total_numerical_certified'):
            try:
                setattr(result,field,True)
            except dataclasses.FrozenInstanceError:
                pass
            else:
                raise AssertionError('certification flag mutable')
            try:
                dataclasses.replace(result,**{field:True})
            except ValueError:
                pass
            else:
                raise AssertionError('certification constructor override accepted')
    for k,v in original.items():
        np.testing.assert_array_equal(np.asarray(p[k]),v)
    # Owned copies: mutating caller storage after execution cannot change results.
    before=results[0].reconstruction.copy()
    p['states'][:]=100.
    np.testing.assert_array_equal(results[0].reconstruction,before)
    return {'entrypoints':2,'false_flags_in_object_and_json':True,'flag_override_rejected':True,
            'caller_inputs_unchanged':True,'no_alias_after_input_mutation':True}
check('metadata-false-flags-host-scope-input-nonmutation',metadata_and_immutability)

def under_enclosure_limitation():
    left=np.nextafter(1.,0.)
    p=dict(ts=np.array([0.,1.]),states=np.array([[0.],[0.]]),order=.5,
           matrix=np.array([[0.]]),initial_state=np.array([0.]),
           power_exponents=np.array([0.]),power_coefficients=np.array([[1.]]))
    result=cells(p,[0.,left,1.])
    with mp.workdps(100):
        true=-2/mp.sqrt(mp.pi)
        computed=real(result.model_lower[-1,0])
        miss=computed-true
        assert miss>0
        detail={'last_cell_left_hex':left.hex(),'last_cell_right_hex':float(1).hex(),
                'model_lower_hex':float(result.model_lower[-1,0]).hex(),
                'exact_model_at_right_100digits':mp.nstr(true,100),'under_enclosure':mp.nstr(miss,50)}
    assert result.arithmetic_verified is result.total_numerical_certified is False
    detail.update({'arithmetic_verified':False,'total_numerical_certified':False,
                   'classification':'expected documented unverified-f64 limitation, not a certificate or scoped artifact blocker'})
    return detail
check('positive-width-under-enclosure-honestly-uncertified',under_enclosure_limitation)

report={'reviewed_tree':'6e7a156f025e08b31a314c5bda59183d6a96bf32',
        'environment':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'mpmath':mp.__version__,
                       'scope':'host float64; no GPU, JIT, gradient or full-suite evidence claimed'},
        'checks':ROWS,'passed':all(r['passed'] for r in ROWS),'details':DETAILS,
        'fixture_sha256':hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),
        'a1_acceptance_passed':False}
(OUT/'independent-results.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'passed':report['passed'],'checks':ROWS,'check_count':len(ROWS)},indent=2))
sys.exit(0 if report['passed'] else 1)
