"""Verify the frozen review target without claiming unrelated live docs frozen."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=Path(__file__).resolve().parent
BEFORE=json.loads((OUT/'identity-before.json').read_text())
TREE=BEFORE['reviewed_tree']

def git(*args):
    return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT)

index={}
for record in git('ls-files','--stage','-z').split(b'\0'):
    if not record:
        continue
    header,path=record.split(b'\t',1)
    mode,oid,stage=header.decode().split()
    assert stage=='0'
    index[path.decode()]=[mode,oid]
frozen={}
for record in git('ls-tree','-r','-z',TREE).split(b'\0'):
    if not record:
        continue
    header,path=record.split(b'\t',1)
    mode,kind,oid=header.decode().split()
    frozen[path.decode()]=[mode,oid]
index_file=Path(git('rev-parse','--git-path','index').decode().strip())
if not index_file.is_absolute():
    index_file=ROOT/index_file
index_sha=hashlib.sha256(index_file.read_bytes()).hexdigest()
mismatches=[]
for path,(mode,oid) in frozen.items():
    data=(ROOT/path).read_bytes()
    digest=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    if digest!=oid:
        mismatches.append(path)
snapshot=json.loads((ROOT/'docs/validation/audits/a1-trajectory-defect-2026-11-11/source-snapshot.json').read_text())
snapshot_mismatches=[path for path,h in snapshot['paths'].items() if hashlib.sha256((ROOT/path).read_bytes()).hexdigest()!=h]
reviewed_mismatches=sorted(set(mismatches)&set(BEFORE['reviewed_paths']))
result={'reviewed_tree':TREE,'index_matches_frozen_tree':index==frozen,
        'index_bytes_unchanged':index_sha==BEFORE['index_sha256'],'index_sha256':index_sha,
        'reviewed_path_mismatches':reviewed_mismatches,'snapshot_checked_count':len(snapshot['paths']),
        'snapshot_mismatches':snapshot_mismatches,
        'other_live_worktree_changes_outside_review_scope':sorted(set(mismatches)-set(BEFORE['reviewed_paths'])),
        'scope_note':'Other worktree documentation changed concurrently; it is not reviewed or approved here. No review action writes into the repository.'}
result['passed']=result['index_matches_frozen_tree'] and result['index_bytes_unchanged'] and not reviewed_mismatches and not snapshot_mismatches
(OUT/'final-integrity.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['passed'],result
print(json.dumps(result,indent=2))
