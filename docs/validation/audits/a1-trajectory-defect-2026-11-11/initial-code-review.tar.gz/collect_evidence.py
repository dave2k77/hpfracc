"""Read-only repository identity/static/history checks; writes only this directory."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = Path(__file__).resolve().parent
TREE = '6e7a156f025e08b31a314c5bda59183d6a96bf32'
BASE = '74d8f08'
AUDIT = ROOT / 'docs/validation/audits/a1-trajectory-defect-2026-11-11'
OLD = Path('/home/davianc/.hermes/cache/scratch/a1-continuum-20261111')
MATH = Path('/home/davianc/.hermes/cache/scratch/a1-independent-math-audit-su8_sfzz')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=ROOT)

def dump(name, data):
    (OUT/name).write_text(json.dumps(data, indent=2, allow_nan=False)+'\n')

def identity():
    frozen = {}
    for row in git('ls-tree', '-r', '-z', TREE).split(b'\0'):
        if row:
            head, path = row.split(b'\t', 1)
            mode, kind, oid = head.decode().split()
            frozen[path.decode()] = [mode, oid]
    index = {}
    for row in git('ls-files', '--stage', '-z').split(b'\0'):
        if row:
            head, path = row.split(b'\t', 1)
            mode, oid, stage = head.decode().split()
            assert stage == '0'
            index[path.decode()] = [mode, oid]
    work_mismatches = []
    for path, (mode, oid) in frozen.items():
        data = (ROOT/path).read_bytes()
        actual = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        if actual != oid:
            work_mismatches.append(path)
    index_path = Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index_path.is_absolute():
        index_path = ROOT/index_path
    snapshot = json.loads((AUDIT/'source-snapshot.json').read_text())
    snapshot_mismatches = [p for p,h in snapshot['paths'].items() if sha((ROOT/p).read_bytes()) != h]
    return {'reviewed_tree': TREE, 'baseline': git('rev-parse', BASE).decode().strip(),
            'index_matches_frozen_tree': index == frozen, 'frozen_file_count': len(frozen),
            'worktree_frozen_blob_mismatches': work_mismatches,
            'index_sha256': sha(index_path.read_bytes()),
            'snapshot_declared_count': snapshot['count'], 'snapshot_actual_count': len(snapshot['paths']),
            'snapshot_digest_mismatches': snapshot_mismatches,
            'status': git('status', '--porcelain=v1', '-uno').decode(),
            'reviewed_paths': git('diff', '--cached', '--name-only', BASE).decode().splitlines()}

before = identity()
if not (OUT/'identity-before.json').exists():
    dump('identity-before.json', before)
else:
    dump('identity-after.json', before)
assert before['index_matches_frozen_tree'] and not before['worktree_frozen_blob_mismatches']
assert before['snapshot_actual_count'] == before['snapshot_declared_count'] == 125
assert not before['snapshot_digest_mismatches']

raw_diff = git('diff', '--cached', BASE)
if not (OUT/'staged-diff.patch.txt').exists():
    (OUT/'staged-diff.patch.txt').write_bytes(raw_diff)
added = [s[1:] for s in raw_diff.decode().splitlines() if s.startswith('+') and not s.startswith('+++')]
patterns = {
    'literal_credentials': r'''(?i)(api_key|secret|password|token|passwd)\s*=\s*['\"][^'\"]{6,}['\"]''',
    'shell': r'os\.system\(|subprocess.*shell\s*=\s*True',
    'dynamic_execution': r'\beval\(|\bexec\(',
    'pickle': r'pickle\.loads?\(',
    'sql_formatting': r'''execute\(f["']|\.format\(.*SELECT|\.format\(.*INSERT''',
}
findings = [{'rule':k,'added_line':i+1,'text':s} for k,p in patterns.items() for i,s in enumerate(added) if re.search(p,s)]
supplied = json.loads((AUDIT/'static-scan.json').read_text())
dump('static-recheck.json', {'review_tree':TREE,'added_line_count':len(added),'findings':findings,
                             'supplied_artifact': supplied, 'raw_diff_sha256':sha(raw_diff)})
assert len(added) == 1163 and not findings

archive_mismatches = []
with tarfile.open(AUDIT/'source-snapshot.tar.gz', 'r:gz') as tf:
    members = [m for m in tf.getmembers() if m.isfile()]
    for m in members:
        p = Path(m.name)
        assert not p.is_absolute() and '..' not in p.parts
        data = tf.extractfile(m).read()
        if data != (ROOT/p).read_bytes():
            archive_mismatches.append(m.name)
assert len(members) == 125 and not archive_mismatches
fixture = (AUDIT/'frozen-fixtures.json').read_bytes()
assert fixture == (MATH/'frozen-fixtures.json').read_bytes()
assert sha(fixture) == '63311bcecc3c31458df93b0c1079d0cec1d8cbc64ee1155abc07b028e9f9aaef'

def leaves(value):
    if isinstance(value, dict):
        if 'hex' in value:
            f = float.fromhex(value['hex'])
            assert f == float(value['decimal_display'])
            numerator, denominator = f.as_integer_ratio()
            return [{'hex':value['hex'],'numerator':numerator,'denominator':denominator}]
        return sum((leaves(v) for v in value.values()), [])
    if isinstance(value, list):
        return sum((leaves(v) for v in value), [])
    return []
fixture_data = json.loads(fixture)
raw = leaves(fixture_data)
assert len({x['id'] for x in fixture_data['cases']}) == len(fixture_data['cases'])
dump('fixture-integrity.json', {'sha256':sha(fixture),'matches_independent_math_audit_raw_bytes':True,
       'case_ids':[x['id'] for x in fixture_data['cases']], 'binary64_input_count':len(raw),
       'represented_integer_ratios':raw,'snapshot_archive_files':len(members),'archive_mismatches':archive_mismatches,
       'snapshot_archive_sha256':sha((AUDIT/'source-snapshot.tar.gz').read_bytes())})

history = []
for n in range(1,6):
    source = OLD/f'feature{n}-red-source.py.txt'
    red = OLD/f'feature{n}-red.xml'
    green = OLD/f'feature{n}-green.xml'
    src = source.read_bytes()
    red_tree = ET.fromstring(red.read_bytes())
    green_tree = ET.fromstring(green.read_bytes())
    failures = [{'name':case.attrib.get('name'), 'message':f.attrib.get('message'), 'type':f.attrib.get('type')}
                for case in red_tree.iter('testcase') for f in list(case) if f.tag in ('failure','error')]
    history.append({'feature':n,'source_path':str(source),'source_sha256':sha(src),'source_lines':len(src.splitlines()),
                    'red_xml_sha256':sha(red.read_bytes()),'red_suites':[s.attrib for s in red_tree.iter('testsuite')],
                    'green_xml_sha256':sha(green.read_bytes()),'green_suites':[s.attrib for s in green_tree.iter('testsuite')],
                    'red_failures':failures,
                    'source_preserved_before_review':True,
                    'historical_pre_run_timing_independently_authenticated':False})
dump('red-green-history.json', history)
print(json.dumps({'identity':before,'added_lines':len(added),'scan_findings':findings,
                  'fixture_sha256':sha(fixture),'archive_files':len(members),
                  'red_green':[{'feature':h['feature'],'red':h['red_suites'][0], 'green':h['green_suites'][0]} for h in history]}, indent=2))
