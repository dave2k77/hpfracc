"""Run only A1 focused checks with all generated output in this scratch directory."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = Path(__file__).resolve().parent
ENV = os.environ.copy()
ENV.pop('UV_PROJECT_ENVIRONMENT', None)
ENV.update({'PYTHONDONTWRITEBYTECODE':'1', 'JAX_PLATFORMS':'cpu', 'JAX_ENABLE_X64':'false',
            'XLA_PYTHON_CLIENT_PREALLOCATE':'false','UV_NO_SYNC':'1','RUFF_NO_CACHE':'true',
            'TMPDIR':str(OUT/'tmp'),'XDG_CACHE_HOME':str(OUT/'cache'),
            'JAX_COMPILATION_CACHE_DIR':str(OUT/'jax-cache'),
            'HYPOTHESIS_STORAGE_DIRECTORY':str(OUT/'hypothesis'),
            'PYTHONPATH':str(ROOT)+os.pathsep+str(ROOT/'src')})
for name in ('tmp','cache','jax-cache','hypothesis'):
    (OUT/name).mkdir(exist_ok=True)
commands = {
    'targeted': ['uv','run','--frozen','--extra','dev','--no-sync','python','-m','pytest','-q',
                 '-p','no:cacheprovider','--basetemp',str(OUT/'pytest-tmp'),
                 '--junitxml',str(OUT/'targeted.xml'),'tests/unit/test_volterra_defect.py'],
    'independent': ['uv','run','--frozen','--extra','dev','--no-sync','python',str(OUT/'independent_probes.py')],
    'history': ['uv','run','--frozen','--extra','dev','--no-sync','python',str(OUT/'historical_replay.py')],
    'lint': ['uv','run','--frozen','--extra','dev','--no-sync','ruff','check','--no-cache',
             'benchmarks/numerical/_volterra_defect.py','tests/unit/test_volterra_defect.py'],
}
for name in sys.argv[1:]:
    command = commands[name]
    start = time.monotonic()
    with (OUT/f'{name}.stdout.txt').open('w') as stdout, (OUT/f'{name}.stderr.txt').open('w') as stderr:
        result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr, timeout=240)
    record = {'command':command,'cwd':str(ROOT),'exit_code':result.returncode,
              'elapsed_seconds':time.monotonic()-start,
              'explicit_environment':{k:ENV[k] for k in ('PYTHONDONTWRITEBYTECODE','JAX_PLATFORMS','JAX_ENABLE_X64','UV_NO_SYNC','TMPDIR')},
              'full_suite_run':False}
    (OUT/f'{name}.run.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record))
    print((OUT/f'{name}.stdout.txt').read_text())
    print((OUT/f'{name}.stderr.txt').read_text())
    if result.returncode:
        sys.exit(result.returncode)
