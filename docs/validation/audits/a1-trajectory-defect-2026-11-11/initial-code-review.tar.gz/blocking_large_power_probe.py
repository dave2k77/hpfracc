"""Blocking large-power probe against the frozen STAGED source, never worktree."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

import mpmath as mp
import numpy as np
from scipy.special import poch

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=Path(__file__).resolve().parent
TREE='6e7a156f025e08b31a314c5bda59183d6a96bf32'
PATH='benchmarks/numerical/_volterra_defect.py'

def git(*args):
    return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT)

source=git('show',':'+PATH)
frozen=git('show',TREE+':'+PATH)
assert source==frozen,'Index changed; refusing to attribute non-frozen source to initial tree'
module=types.ModuleType('frozen_staged_volterra_for_review')
module.__file__='git-index:'+PATH
sys.modules[module.__name__]=module
exec(compile(source,module.__file__,'exec'),module.__dict__)

records=[]
for beta in (1e6,1e12,1e16,1e100,1e300):
    kwargs=dict(order=.5,matrix=np.array([[0.]]),initial_state=np.array([0.]),
                power_exponents=np.array([beta]),power_coefficients=np.array([[1.]]))
    ts=np.array([0.,1.]); states=np.array([[0.],[0.]])
    point=module.affine_power_defect(ts,states,np.array([1.]),**kwargs)
    cell=module.affine_power_cells(ts,states,np.array([0.,1.]),**kwargs)
    prepared=module._prepare(ts,states,np.array([0.,1.]),kwargs['order'],kwargs['matrix'],kwargs['initial_state'],kwargs['power_exponents'],kwargs['power_coefficients'])
    term=list(module._defect_terms(prepared))[-1]
    with mp.workdps(400):
        num,den=float(beta).as_integer_ratio()
        b=mp.mpf(num)/den
        truth=mp.gamma(b+1)/mp.gamma(b+mp.mpf('1.5'))
        observed=mp.mpf(float(point.fractional_rhs[0,0]))
        relative_error=abs(observed/truth-1)
        row={'beta_hex':beta.hex(),'beta_display':repr(beta),
             'observed_fractional_rhs':float(point.fractional_rhs[0,0]),
             'expected_gamma_ratio_mp400':mp.nstr(truth,100),
             'independent_reciprocal_pochhammer':float(1/poch(beta+1,.5)),
             'relative_error_mp400':mp.nstr(relative_error,60),
             'observed_last_term_coefficient':term[2].tolist(),
             'observed_cell_model_lower':cell.model_lower.tolist(),'observed_cell_model_upper':cell.model_upper.tolist(),
             'arithmetic_verified':point.arithmetic_verified,'total_numerical_certified':point.total_numerical_certified}
        if beta==1e300:
            assert observed==1 and relative_error>mp.mpf('1e149')
            assert term[2][0]==-1 and cell.model_lower[0,0]==-1
            assert abs(mp.mpf(float(1/poch(beta+1,.5)))/truth-1)<mp.mpf('1e-14')
    records.append(row)
assert git('show',':'+PATH)==source,'Staged source changed during probe'
report={'reviewed_tree':TREE,'source':'exact index bytes independently compared to frozen-tree blob',
        'source_sha256':hashlib.sha256(source).hexdigest(),'blocking_logic_error':True,
        'location':['benchmarks/numerical/_volterra_defect.py:119-120','benchmarks/numerical/_volterra_defect.py:173-175'],
        'cause':'Subtracting independently rounded gammaln values loses the small log-gamma difference. For finite large beta, beta+1 and beta+alpha+1 also collapse to the same binary64 value; exp(0) gives an incorrect coefficient of 1.',
        'impact':'Both pointwise fractional_rhs and cell signed-power coefficients are catastrophically wrong for supported finite nonnegative power inputs; false certification flags do not excuse incorrect point values.',
        'cases':records,'scope':'Initial frozen-tree verdict only; no corrected-source review or full-suite claim.'}
(OUT/'blocking-large-power.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2))
