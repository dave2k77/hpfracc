"""Replay preserved RED feature tests against their predecessor implementations.

All modules load directly from existing preserved text in memory. Only the old
suite's module resolver is replaced to select the historical implementation;
no repository source or fixture is created/modified. This corroborates recorded
failures, not an independently authenticated historical execution timestamp.
"""
import hashlib
import importlib.machinery
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import warnings

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=Path(__file__).resolve().parent
OLD=Path('/home/davianc/.hermes/cache/scratch/a1-continuum-20261111')
MATH=Path('/home/davianc/.hermes/cache/scratch/a1-independent-math-audit-su8_sfzz')
sys.path.insert(0,str(ROOT))
import numpy as np
from benchmarks.numerical import _volterra_defect as current


def load(path,name):
    loader=importlib.machinery.SourceFileLoader(name,str(path))
    spec=importlib.util.spec_from_loader(name,loader)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    loader.exec_module(module)
    return module

def run_call(function,kwargs):
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            function(**kwargs)
    except (KeyboardInterrupt,SystemExit):
        raise
    except BaseException as exc:
        return {'passed':False,'type':type(exc).__name__,'message':str(exc)}
    return {'passed':True}

replays=[]
for feature in range(2,6):
    source=OLD/f'feature{feature}-red-source.py.txt'
    prior=OLD/f'feature{feature-1}-green-implementation.py.txt'
    tests=load(source,f'preserved_red_{feature}')
    implementation=load(prior,f'preserved_predecessor_{feature}')
    if feature==2:
        function=tests.test_coupled_weak_power_and_cubic_forcing_at_represented_inputs
        cases=[(function,{'alpha':alpha,'dtype':dtype}) for alpha in (.3,.5,.75) for dtype in (np.float32,np.float64)]
    elif feature==3:
        function=tests.test_invalid_inputs_fail_before_numerical_evaluation
        mark=next(m for m in function.pytestmark if m.name=='parametrize')
        cases=[(function,dict(zip(mark.args[0],values,strict=True))) for values in mark.args[1]]
        cases.append((tests.test_nonfinite_arithmetic_is_not_returned_as_a_diagnostic,{}))
    elif feature==4:
        cases=[(tests.test_cell_model_ranges_detect_interior_defect_hidden_at_nodes,{})]
    else:
        function=tests.test_cell_work_budget_requires_a_positive_canonical_integer
        cases=[(function,{'max_work':value}) for value in (0,True,1.5)]
        cases.append((tests.test_cell_work_budget_exhaustion_is_explicit_not_history_truncation,{}))
    before=[]; after=[]
    tests.diagnostic_module=lambda implementation=implementation:implementation
    for function,kwargs in cases:
        before.append(run_call(function,kwargs))
    tests.diagnostic_module=lambda:current
    for function,kwargs in cases:
        after.append(run_call(function,kwargs))
    assert all(not row['passed'] for row in before),(feature,before)
    assert all(row['passed'] for row in after),(feature,after)
    replays.append({'feature':feature,'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                    'predecessor':str(prior),'predecessor_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),
                    'cases':len(cases),'predecessor_results':before,'current_results':after})

archive=ROOT/'docs/validation/audits/a1-defect-design-2026-11-11/protocol-and-checks.tar.gz'
import tarfile
with tarfile.open(archive,'r:gz') as tf:
    matches={member.name:hashlib.sha256(tf.extractfile(member).read()).hexdigest()==hashlib.sha256((MATH/'protocol'/member.name).read_bytes()).hexdigest()
             for member in tf.getmembers() if member.isfile()}
assert all(matches.values())
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='55c13478f42ef199e2a41fd0c37c097a1349498d8ed62e4d620a923219a721e6'
missing=subprocess.check_output(['git','--no-optional-locks','ls-tree','74d8f08','--','benchmarks/numerical/_volterra_defect.py'],cwd=ROOT)
assert missing==b''
report={'passed':True,'feature1_module_absent_in_baseline':True,'feature1_red_xml_reviewed_not_replayed':True,
        'feature_replays':replays,'original_protocol_archive_matches_math_audit_members':matches,
        'scope':'in-memory corroboration; no original RED/GREEN timestamps independently authenticated'}
(OUT/'historical-replay.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':True,'replayed_features':[{'feature':r['feature'],'cases':r['cases']} for r in replays],
                  'original_archive_members_matching':len(matches)},indent=2))
