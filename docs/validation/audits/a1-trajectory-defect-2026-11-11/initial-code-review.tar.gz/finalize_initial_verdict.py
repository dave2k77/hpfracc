"""Finalize INITIAL frozen-tree failure; supersedes unexecuted earlier draft.

Only new scratch evidence is written. Worktree source is deliberately not read:
the parent is repairing it separately. This is not a corrected-source review.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

ROOT=Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=Path(__file__).resolve().parent
TREE='6e7a156f025e08b31a314c5bda59183d6a96bf32'


def load(name):
    return json.loads((OUT/name).read_text())

def git(*args):
    return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT)

bug=load('blocking-large-power.json')
probe=load('independent-results.json')
history=load('historical-replay.json')
static=load('static-recheck.json')
fixture=load('fixture-integrity.json')
suites=[s.attrib for s in ET.parse(OUT/'targeted.xml').getroot().iter('testsuite')]
counts={key:sum(int(s.get(key,'0')) for s in suites) for key in ('tests','failures','errors','skipped')}
paths=['benchmarks/numerical/_volterra_defect.py','tests/unit/test_volterra_defect.py',
       'docs/validation/audits/a1-trajectory-defect-2026-11-11/frozen-fixtures.json']
staged_identity=[]
for path in paths:
    staged=git('show',':'+path)
    frozen=git('show',TREE+':'+path)
    staged_identity.append({'path':path,'index_equals_frozen_blob':staged==frozen,
                            'frozen_sha256':hashlib.sha256(frozen).hexdigest(),
                            'index_sha256':hashlib.sha256(staged).hexdigest()})
assert all(x['index_equals_frozen_blob'] for x in staged_identity)
assert bug['source_sha256']==staged_identity[0]['index_sha256']
assert counts=={'tests':55,'failures':0,'errors':0,'skipped':0}
assert probe['passed'] and history['passed'] and not static['findings']

metrics={'focused_cpu_tests':counts,'focused_lint_exit':load('lint.run.json')['exit_code'],
         'previous_independent_check_groups':len(probe['checks']),
         'previous_seeded_random_cases':len(probe['details']['seeded-random-panel-and-cell-crosschecks']),
         'raw_kind_rejections':probe['details']['raw-kind-guards-both-entrypoints']['rejected_count'],
         'shape_finite_domain_rejections':probe['details']['shape-order-finite-domain-and-mesh-guards']['rejected_count'],
         'nonfinite_arithmetic_failure_cases':len(probe['details']['finite-input-nonfinite-arithmetic-fails-closed']),
         'historical_red_cases_replayed':sum(r['cases'] for r in history['feature_replays']),
         'blocking_large_power_cases':bug['cases'],
         'scope_note':'Earlier passing focused checks did not cover large forcing powers and do not override the independent reproduced blocker.',
         'original_fixture_sha256':fixture['sha256'],'staged_identity':staged_identity,
         'all_source_snapshot_files_verified_before_parent_repair':125,
         'full_suite_run_or_claimed':False,'corrected_source_reviewed':False,
         'other_findings':'No additional security or logic errors identified in the scoped review. Correct signed real-arithmetic formulas, matrix orientation, all-history partition, guards, exact work-count boundary, false metadata flags and expected adjacent-float under-enclosure were corroborated.',
         'review_probe_authoring_issue':'Initial metadata probe expected ValueError rather than interpreter TypeError for dataclasses.replace(init=False); original probe and results preserved in probe-authoring-attempt1, corrected probe passed.',
         'unexecuted_draft':'finalize_review.py predates discovery of the blocker, was never run and must not be used as the initial verdict. finalize_initial_verdict.py is authoritative.'}
(OUT/'initial-review-metrics.json').write_text(json.dumps(metrics,indent=2,allow_nan=False)+'\n')

logic=[{'severity':'blocking','locations':bug['location'],
        'issue':'Catastrophic cancellation in the forcing Gamma-ratio coefficient affects both pointwise and cell paths.',
        'reproducer':'Finite inputs alpha=0.5, beta=1e300, ts=[0.0,1.0], states=[[0.0],[0.0]], A=[[0.0]], initial_state=[0.0], forcing coefficient=[[1.0]], evaluate t=1.0.',
        'observed':'fractional_rhs=1.0; final signed forcing coefficient=-1.0; cell model_lower=-1.0.',
        'expected':'Gamma(beta+1)/Gamma(beta+1.5) is approximately 1e-150 (400-digit mpmath and reciprocal scipy.special.poch agree).',
        'cause':'The two large gammaln arguments/results round together, producing exp(0)=1 instead of the small Gamma ratio.',
        'impact':'Supported finite nonnegative-power inputs return catastrophically incorrect point values and model coefficients. False certification flags do not make this a permissible numerical diagnostic result.',
        'evidence':str(OUT/'blocking-large-power.json')}]
verdict={'passed':False,'security_concerns':[], 'logic_errors':logic,
         'suggestions':[
             'Repair both forcing-coefficient paths with a stable ratio evaluation such as reciprocal Pochhammer; add large-power pointwise and cell-coefficient regressions and separately review the corrected delta.',
             'Keep arithmetic_verified and total_numerical_certified false. The separate approximately 1.53e-17 adjacent-float under-enclosure is an honestly documented limitation, unlike the blocking catastrophic point-value error.',
             'Keep A1 acceptance false: componentwise feedback/tail propagation, verified arithmetic/error budgets, nonlinear-domain closure, required matrix and solver/controller JAX/gradient gates remain open.'
         ],
         'summary':'Initial frozen-tree code/artifact review FAILED: independently reproduced a blocking large-power Gamma-ratio error in both paths from exact staged bytes. The 55 focused CPU tests, 15 earlier independent probe groups and 39 historical RED-to-current replay cases passed but missed this input regime; no full-suite or corrected-source result is claimed.',
         'reviewed_tree':TREE,
         'evidence_paths':[str(OUT/'initial-review-evidence-index.json'),str(OUT/'blocking_large_power_probe.py'),
                           str(OUT/'blocking-large-power.json'),str(OUT/'initial-review-metrics.json'),
                           str(OUT/'targeted.xml'),str(OUT/'independent-results.json'),str(OUT/'historical-replay.json')],
         'a1_acceptance_passed':False}
assert verdict['logic_errors'] and verdict['passed'] is False and verdict['a1_acceptance_passed'] is False
(OUT/'initial-review-verdict.json').write_text(json.dumps(verdict,indent=2,allow_nan=False)+'\n')
files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name!='initial-review-evidence-index.json')
files+=sorted(p for p in (OUT/'probe-authoring-attempt1').iterdir() if p.is_file())
index={'root':str(OUT),'authoritative_verdict':'initial-review-verdict.json',
       'files':[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],
       'executable_checks':['independent_probes.py','historical_replay.py','blocking_large_power_probe.py'],
       'frozen_source_probe_command':'env -u UV_PROJECT_ENVIRONMENT PYTHONDONTWRITEBYTECODE=1 JAX_PLATFORMS=cpu UV_NO_SYNC=1 uv run --frozen --extra dev --no-sync python '+str(OUT/'blocking_large_power_probe.py'),
       'scope':'Initial three-file staged tree only. No worktree repair, repository/index writes, full suite, commit, or push performed.',
       'draft_warning':'finalize_review.py is an unexecuted pre-discovery draft; use initial-review-verdict.json, never that draft.'}
(OUT/'initial-review-evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps(verdict,indent=2))
