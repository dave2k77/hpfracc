"""Independently authored copied-record CLI controls. Synthetic, not native suite observations."""
import ast
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET

ROOT = pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = pathlib.Path(__file__).resolve().parent
REL = pathlib.Path('docs/validation/audits/a1-trajectory-defect-2026-11-11')
BASE = ROOT / REL
ENV = {**os.environ, 'PYTHONDONTWRITEBYTECODE':'1'}
WORK = OUT/'independent-sandboxes-final'
WORK.mkdir()
PROOF = OUT/'controls-raw-final'
PROOF.mkdir()

def sha(raw): return hashlib.sha256(raw).hexdigest()
def put(p,v): p.write_text(json.dumps(v,indent=2)+'\n')
def load(p): return json.loads(p.read_bytes())
def rehash(b):
    put(b/'checksums.json',{str(p.relative_to(b)):sha(p.read_bytes()) for p in sorted(b.rglob('*')) if p.is_file() and p.name not in {'checksums.json','verification.json'}})

template=WORK/'template'; b=template/REL
shutil.copytree(BASE,b)
with tarfile.open(BASE/'source-snapshot.tar.gz') as t:
    for m in t:
        assert m.isfile() and not pathlib.Path(m.name).is_absolute() and '..' not in pathlib.Path(m.name).parts
        p=template/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
clone=WORK/'git-reference'
subprocess.run(['git','clone','--shared','--no-checkout',str(ROOT),str(clone)],check=True,capture_output=True)
shutil.copytree(clone/'.git',template/'.git')
subprocess.run(['git','add','--',*load(b/'source-snapshot.json')['paths']],cwd=template,check=True,capture_output=True)
rows=[]

def sandbox(name):
    r=WORK/name;shutil.copytree(template,r);base=r/REL
    plan=load(base/'execution-plan.json');process=load(base/'process-completion.json'); executions=load(base/'executions.json')
    for i,run in enumerate(plan['full_runs']):
        backend=run['backend'];run.update(session_id='independent-synthetic-'+backend,pid=800011+i,exit_record=str(r/(backend+'.exit')))
        pathlib.Path(run['exit_record']).write_bytes(b'0\n')
        ob=next(x for x in process['full_runs'] if x['backend']==backend);ob.update(session_id=run['session_id'],pid=run['pid'])
        ex=next(x for x in executions['full_runs'] if x['backend']==backend);ex.update(session_id=run['session_id'],pid=run['pid'],exit_record=run['exit_record'])
    for ob in [plan,process,executions]:ob['scope']='Independent controlled synthetic metadata; NOT native candidate full-suite observations'
    for name,obj in [('execution-plan.json',plan),('process-completion.json',process),('executions.json',executions)]:put(base/name,obj)
    for run in plan['full_runs']:
        p=base/(run['backend']+'-readback.json');rec=load(p)
        rec.update(session_id=run['session_id'],pid=run['pid'],exit_record=run['exit_record'],process_completion_sha256=sha((base/'process-completion.json').read_bytes()),scope=plan['scope'])
        put(p,rec)
    return r,base

def run_cli(name,tool,mutate=None,positive=False,current=False):
    r,b=sandbox(name+'-'+tool)
    delta=mutate(r,b) if mutate else {'mutation':None}
    rehash(b)
    critical=['cpu-readback.json','cuda-readback.json','executions.json','completion-exit-cpu.txt','completion-exit-cuda.txt','checksums.json']
    before={n:sha((b/n).read_bytes()) if (b/n).exists() else None for n in critical}
    command=[sys.executable,str(b/('capture_completion.py' if tool in {'finalize','cpu','cuda'} else 'verify.py'))]
    if tool in {'finalize','cpu','cuda'}:command+=[tool]
    if current:command+=['--current-source']
    result=subprocess.run(command,cwd=r,env=ENV,capture_output=True,timeout=30)
    stem=name+'-'+tool
    (PROOF/(stem+'.stdout')).write_bytes(result.stdout);(PROOF/(stem+'.stderr')).write_bytes(result.stderr)
    after={n:sha((b/n).read_bytes()) if (b/n).exists() else None for n in critical}
    row={'name':name,'tool':tool,'command':command,'cwd':str(r),'input_delta':delta,'actual_exit_code':result.returncode,'expected_success':positive,'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr),'before':before,'after':after,'scope':'independent synthetic copied-record control'}
    rows.append(row);put(PROOF/(stem+'.json'),row)
    assert (result.returncode==0)==positive,(name,tool,result.stderr.decode())
    if not positive: assert before==after,('failed CLI wrote completion targets',name,tool)
    if positive and tool=='verify':
        report=json.loads(result.stdout)
        assert report['current_source_verified'] is current and report['local_exit_files_verified'] is current and report['a1_acceptance_passed'] is False
    shutil.rmtree(r)

def rb(field,value):
    def mutation(r,b):
        p=b/'cpu-readback.json';rec=load(p);old=rec[field];rec[field]=value;put(p,rec)
        return {'file':p.name,'field':field,'old':old,'new':value,'checksum_wrapper_refreshed':True}
    return mutation

def process_change(field,value):
    def mutation(r,b):
        p=b/'process-completion.json';rec=load(p);old=rec['full_runs'][0][field];rec['full_runs'][0][field]=value;put(p,rec)
        for bk in ['cpu','cuda']:
            q=b/(bk+'-readback.json');rr=load(q);rr['process_completion_sha256']=sha(p.read_bytes());put(q,rr)
        return {'file':p.name,'field':field,'old':old,'new':value,'process_digest_and_wrapper_refreshed':True}
    return mutation

def missing_process(r,b):
    (b/'process-completion.json').unlink();return {'removed':'process-completion.json','checksum_wrapper_refreshed':True}

def missing_run(r,b):
    p=b/'process-completion.json';v=load(p);v['full_runs'].pop();put(p,v)
    for bk in ['cpu','cuda']:
        q=b/(bk+'-readback.json');rr=load(q);rr['process_completion_sha256']=sha(p.read_bytes());put(q,rr)
    return {'removed':'one process run','process_digest_and_wrapper_refreshed':True}

def local_missing(r,b):
    run=load(b/'execution-plan.json')['full_runs'][0];pathlib.Path(run['exit_record']).unlink()
    return {'removed':'synthetic local cpu exit','preserved_exit_still_present':True}

def local_source_missing(r,b):
    (r/'benchmarks/numerical/README.md').unlink();return {'removed':'local source file, immutable source archive intact'}

def bad_preserved(r,b):
    (b/'completion-exit-cpu.txt').write_bytes(b'9\n');p=b/'cpu-readback.json';rec=load(p);rec['exit_record_sha256']=sha(b'9\n');put(p,rec)
    return {'changed':'preserved exit to 9','exit_digest_and_wrapper_refreshed':True}

def duplicate_json(r,b):
    p=b/'cpu-readback.json';raw=p.read_text();p.write_text(raw.replace('{','{"tests": 1017,',1));return {'changed':'duplicate tests key with otherwise-correct value','checksum_wrapper_refreshed':True}

controls=[('wrong-xml-sha',rb('xml_sha256','f'*64)),('source-count-zero',rb('source_inputs_verified',0)),('backend',rb('backend','cuda')),('session',rb('session_id','other-session')),('pid',rb('pid',800099)),('float-pid',rb('pid',800011.0)),('bool-exit',rb('exit_code',False)),('float-source-count',rb('source_inputs_verified',126.0)),('nonzero-exit',rb('exit_code',7)),('preserved-nonzero',bad_preserved),('missing-process',missing_process),('missing-process-run',missing_run),('process-nonzero',process_change('exit_code',7)),('process-bool-exit',process_change('exit_code',False)),('process-running',process_change('status','running')),('duplicate-json-key',duplicate_json)]
for tool in ['finalize','verify']:
    run_cli('valid',tool,positive=True)
    for name,mutate in controls:run_cli(name,tool,mutate)
# Explicitly distinguish archive replay from live source/exit requirements.
for name,mutate in [('absent-local-exit',local_missing),('absent-local-source',local_source_missing)]:
    run_cli(name+'-archive', 'verify',mutate,positive=True)
    run_cli(name+'-live','verify',mutate,current=True)
    run_cli(name+'-finalizer','finalize',mutate)
run_cli('valid-current','verify',positive=True,current=True)
for bk in ['cpu','cuda']:
    run_cli('producer-missing-observation',bk,missing_process)

# Replay exact historical v1 assertions; change only the old absolute producer
# locator to the preserved old script. No candidate or old evidence is rewritten.
v1root=WORK/'v1-replay';v1base=v1root/REL
shutil.copytree(BASE,v1base)
with tarfile.open(BASE/'completion-integrity-repair.tar.gz') as t:
    pre={m.name:t.extractfile(m).read() for m in t if m.isfile() and m.name.startswith('implementation/pre-fix/')}
producer=v1root/'preserved_old_producer.py';producer.write_bytes(pre['implementation/pre-fix/full_evidence.py'])
(v1base/'verify.py').write_bytes(pre['implementation/pre-fix/verify.py'])
original=pre['implementation/pre-fix/test_completion_integrity.py'].decode()
old='"/home/davianc/.hermes/cache/scratch/a1-arithmetic-20261111/full_evidence.py"'
assert original.count(old)==1
adapted=original.replace(old,repr(str(producer)))
a=ast.parse(original);bb=ast.parse(adapted)
for tree in [a,bb]:
    for n in ast.walk(tree):
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PRODUCER' for t in n.targets):n.value=ast.Constant(value='PORTABLE_OLD_PRODUCER')
assert ast.dump(a,include_attributes=False)==ast.dump(bb,include_attributes=False)
(v1base/'test_completion_integrity.py').write_text(adapted)
cmd=[sys.executable,'-m','pytest',str(v1base/'test_completion_integrity.py'),'-q','-p','no:cacheprovider','--basetemp='+str(WORK/'v1-test-temp'),'--junitxml='+str(PROOF/'v1-replay.xml')]
p=subprocess.run(cmd,cwd=ROOT,env=ENV,capture_output=True,timeout=90)
(PROOF/'v1-replay.stdout').write_bytes(p.stdout);(PROOF/'v1-replay.stderr').write_bytes(p.stderr)
cases=list(ET.parse(PROOF/'v1-replay.xml').iter('testcase'));failures=[c for c in cases if c.find('failure') is not None]
assert p.returncode==1 and len(cases)==6 and len(failures)==4 and not any(c.find('error') is not None for c in cases)
assert all('accepted' in c.find('failure').attrib['message'] and 'assert 0 != 0' in c.find('failure').attrib['message'] for c in failures)
put(PROOF/'v1-replay.json',{'scope':'historical metadata RED replay, NOT numerical failure','command':cmd,'actual_exit_code':p.returncode,'tests':len(cases),'failures':len(failures),'original_v1_test_sha256':sha(original.encode()),'executed_test_sha256':sha(adapted.encode()),'only_adaptation':'absolute producer locator points to byte-identical preserved pre-fix script','ast_assertions_and_other_logic_unchanged':True})
put(OUT/'independent-controls.json',{'scope':'independently authored copied-record controls; not source/math approval or native numerical outcomes','controls':rows,'count':len(rows),'all_expected':True,'v1_red':{'tests':6,'failures':4,'exit_code':1},'a1_acceptance_passed':False})
print(json.dumps({'control_count':len(rows),'expected_rejections':sum(not r['expected_success'] for r in rows),'positive_controls':sum(r['expected_success'] for r in rows),'all_expected':True,'v1_red_tests':6,'v1_red_failures':4,'candidate_written':False},indent=2))
