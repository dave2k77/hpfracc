"""Scope/privacy/static review proof; read-only repository and nested archives."""
import ast
import gzip
import hashlib
import io
import json
import pathlib
import re
import subprocess
import tarfile

ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=pathlib.Path(__file__).resolve().parent
REL=pathlib.Path('docs/validation/audits/a1-trajectory-defect-2026-11-11')
BASE=ROOT/REL
MANIFEST=pathlib.Path('/home/davianc/.hermes/cache/scratch/a1-arithmetic-20261111/corrected-artifact-review-manifest.json')
manifest=json.loads(MANIFEST.read_bytes())
files={**{n:(ROOT/n).read_bytes() for n in manifest['files']},**{n:(ROOT/n).read_bytes() for n in json.loads((BASE/'source-snapshot.json').read_bytes())['paths']}}
patterns={
 'telegram_bot_token':r'(?<![\w])\d{6,12}:[A-Za-z0-9_-]{30,60}(?![\w])',
 'telegram_chat_identifier':r'(?i)(?:telegram[_ -]?(?:chat|user)[_ -]?id|chat_id|TELEGRAM_HOME_CHAT_ID)[\s\"\x27:=]+-?\d{5,}',
 'telegram_personal_link':r'https?://(?:t\.me|telegram\.me)/[A-Za-z0-9_]+',
 'private_key':r'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
 'github_token':r'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})',
 'provider_secret':r'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{24,}',
 'aws_access_key':r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
 'credential_assignment':r'(?i)(?:api[_-]?key|bot[_-]?token|password|passwd|client[_-]?secret)\s*[=:]\s*[\x27\"][^\x27\"\n]{8,}[\x27\"]',
}
findings=[];visited={};text_hashes={};archive_count=0

def scan(name,raw,depth=0):
 global archive_count
 h=hashlib.sha256(raw).hexdigest()
 if h in visited:return
 visited[h]=name
 if raw.startswith(b'\x1f\x8b'):
  assert depth<12
  try:
   with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
    archive_count+=1
    for m in t:
     assert m.isfile() and not pathlib.Path(m.name).is_absolute() and '..' not in pathlib.Path(m.name).parts
     scan(name+'::'+m.name,t.extractfile(m).read(),depth+1)
   return
  except tarfile.ReadError:
   scan(name+'::gzip',gzip.decompress(raw),depth+1);return
 try:text=raw.decode('utf-8')
 except UnicodeDecodeError:return
 text_hashes[name]={'sha256':h,'bytes':len(raw)}
 for kind,pattern in patterns.items():
  for m in re.finditer(pattern,text):
   findings.append({'kind':kind,'path':name,'line':text[:m.start()].count('\n')+1,'match_sha256':hashlib.sha256(m.group().encode()).hexdigest()})
for name,raw in files.items():scan(name,raw)
# Inspect current shipped executable paths independently, excluding preserved old
# probe/test programs whose deliberate dynamic execution is historical data.
static=[]
for name in ['completion_integrity.py','capture_completion.py','verify.py','test_completion_integrity.py']:
 tree=ast.parse((BASE/name).read_text());dangers=[]
 for n in ast.walk(tree):
  if isinstance(n,ast.Call):
   fname=ast.unparse(n.func)
   if fname in {'eval','exec','os.system','pickle.load','pickle.loads'}:dangers.append({'function':fname,'line':n.lineno})
   if any(k.arg=='shell' and isinstance(k.value,ast.Constant) and k.value.value is True for k in n.keywords):dangers.append({'function':fname,'line':n.lineno,'shell':True})
 static.append({'file':name,'findings':dangers})
assert all(not x['findings'] for x in static)
# Bind fresh native poll field readback to the normalized published observations.
native=json.loads((OUT/'native-poll-readback.json').read_bytes())['observations']
published=json.loads((BASE/'process-completion.json').read_bytes())['full_runs']
for n in native:
 p=next(p for p in published if p['session_id']==n['session_id'])
 for k in ['session_id','pid','status','exit_code','completion_reason','termination_source']:
  assert type(n[k]) is type(p[k]) and n[k]==p[k]
 assert '1017 passed, 1 deselected' in n['summary_excerpt']
assert json.loads((BASE/'candidate-status.json').read_bytes())['implementation_sha256']==hashlib.sha256((ROOT/'benchmarks/numerical/_volterra_defect.py').read_bytes()).hexdigest()
for file in ['candidate-status.json','arithmetic-code-review.json','process-completion.json','executions.json','execution-plan.json','verification.json','completion-integrity-repair-index.json','document-integrity-audit-preservation.json']:
 data=json.loads((BASE/file).read_bytes());assert data['a1_acceptance_passed'] is False
 if file=='candidate-status.json':assert data['arithmetic_verified'] is False and data['total_numerical_certified'] is False
# Read, do not execute, the model result declarations.
model=ast.parse((ROOT/'benchmarks/numerical/_volterra_defect.py').read_text())
flags=[]
for n in ast.walk(model):
 if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id in {'arithmetic_verified','total_numerical_certified'}:
  assert isinstance(n.value,ast.Call)
  kws={k.arg:k.value for k in n.value.keywords}
  assert isinstance(kws['default'],ast.Constant) and kws['default'].value is False
  assert isinstance(kws['init'],ast.Constant) and kws['init'].value is False
  flags.append({'name':n.target.id,'line':n.lineno,'default':False,'init':False})
assert len(flags)==4
excerpts={}
for name in ['README.md','arithmetic-contract.md']:
 text=(BASE/name).read_text().splitlines()
 excerpts[str(REL/name)]=[{'line':i,'text':line} for i,line in enumerate(text,1) if re.search('historical|92ff|bf3d|SCI-003|false-zero|pending|A1|A2|A3|A4|per-state|authentication|certif',line,re.I)]
for name in ['docs/developer/phase-a-completion.md','docs/developer/bug-resolution-tracker.md','CHANGELOG.md']:
 text=(ROOT/name).read_text().splitlines()
 excerpts[name]=[{'line':i,'text':line} for i,line in enumerate(text,1) if re.search('full verification running|historical 92ff|pending|Pre-review parent|A[1234]:|per-state|SCI-003|VAL-012|authentication|false.zero',line,re.I)]
report={'scope':'corrected artifact/doc/evidence integrity only; not a new source/math approval','privacy_unique_text_records_scanned':len(text_hashes),'recursive_archives':archive_count,'privacy_findings':findings,'privacy_patterns':patterns,'current_cli_static_checks':static,'native_process_fields_match_fresh_tool_readbacks':True,'result_flags':flags,'DOC-01':'Resolved: README lines 215-224 explicitly label 92ff historical/rejected; bf3 current at 44-60. Historical mutable-readback references corrected at tracker 879-888.','EVID-01':'Resolved: shared completion binding exercised by 125 metadata tests and 43 independent copied-record CLI controls, including exact old-v1 four-failure replay.','nonblocking_progress_wording':[{'file':'docs/developer/bug-resolution-tracker.md','line':54,'finding':'Index row still says full verification running; body and raw evidence correctly record completed 1017-case CPU/CUDA runs. Update only this conservative progress field after review, without changing historical outcomes or criteria.'},{'file':'docs/developer/bug-resolution-tracker.md','line':834,'finding':'Qualify opening Status and impact as the historical 92ff rejection checkpoint; subsequent owner authorization and current-source review/completion are already present below.'}],'remaining_gates':'SCI-003 substantive false-zero limitation and separate working-arithmetic/enclosure/propagation/controller acceptance remain open; no new numerical findings investigated. A1/A2/A3/A4 closure and per-state solver scope/owner decision remain open.','excerpts':excerpts,'a1_acceptance_passed':False}
(OUT/'scope-privacy-static.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'privacy-scan-input-hashes.json').write_text(json.dumps(text_hashes,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['privacy_unique_text_records_scanned','recursive_archives','privacy_findings','current_cli_static_checks','native_process_fields_match_fresh_tool_readbacks','nonblocking_progress_wording']},indent=2))
