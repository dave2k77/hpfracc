"""Compact generated copied-record proofs and check final read-only invariants."""
import gzip
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import xml.etree.ElementTree as ET

ROOT=pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT=pathlib.Path(__file__).resolve().parent
REL=pathlib.Path('docs/validation/audits/a1-trajectory-defect-2026-11-11')
BASE=ROOT/REL
MPATH=pathlib.Path('/home/davianc/.hermes/cache/scratch/a1-arithmetic-20261111/corrected-artifact-review-manifest.json')
ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def put(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
manifest=json.loads(MPATH.read_bytes())
assert sha(MPATH.read_bytes())=='1267f6dc7b2fcb464a14d85c5dd1dd74122c4c481af825531c364d4d75ff6396'
initial=json.loads((OUT/'initial-git.json').read_bytes())
commands=[['git','rev-parse','HEAD'],['git','branch','--show-current'],['git','status','--porcelain=v1'],['git','diff','--stat'],['git','diff','--cached','--stat'],['git','ls-files','--stage']]
git={}
for c in commands:
 p=subprocess.run(c,cwd=ROOT,env=ENV,capture_output=True,text=True,check=True)
 assert p.stdout==initial[' '.join(c)],c
 git[' '.join(c)]=p.stdout
pins={n:{'sha256':sha((ROOT/n).read_bytes()),'bytes':(ROOT/n).stat().st_size} for n in manifest['files']}
assert pins==manifest['files'] and len(pins)==85
snapshot=json.loads((BASE/'source-snapshot.json').read_bytes())
assert len(snapshot['paths'])==126 and all(sha((ROOT/n).read_bytes())==h for n,h in snapshot['paths'].items())
# Check index timestamps relative to the task's newly created scratch directory.
index_stat=(ROOT/'.git/index').stat()
scratch_birth=int(subprocess.check_output(['stat','-c','%W',str(OUT)],text=True).strip())
assert scratch_birth>0
index_predates_review=index_stat.st_mtime<scratch_birth and index_stat.st_ctime<scratch_birth
# Index entry content comparison is the hard invariant; raw index hash was not
# pinned before the first read-only git status, so do not imply that it was.
index_observation={'current_sha256':sha((ROOT/'.git/index').read_bytes()),'mtime_ns':index_stat.st_mtime_ns,'ctime_ns':index_stat.st_ctime_ns,'scratch_birth_epoch_seconds':scratch_birth,'mtime_and_ctime_predate_review_scratch_creation':index_predates_review,'all_staged_entries_unchanged_since_initial_readback':True,'raw_index_hash_pinned_before_first_status':False}
# Retain the actual metadata CLI outputs without hundreds of copied archives.
logs=[]
for p in sorted((OUT/'pytest-temp').rglob('cli-*-result.json')):
 number=p.name.removeprefix('cli-').removesuffix('-result.json')
 stem=p.parent/('cli-'+number)
 result=json.loads(p.read_bytes());stdout=stem.with_suffix('.stdout').read_bytes();stderr=stem.with_suffix('.stderr').read_bytes()
 assert sha(stdout)==result['stdout_sha256'] and sha(stderr)==result['stderr_sha256']
 logs.append({'record_path':str(p.relative_to(OUT)),'result':result,'stdout':stdout.decode(),'stderr':stderr.decode()})
raw=json.dumps({'scope':'raw subprocess output from 125 explicitly selected metadata controls on copies, NOT native numerical observations','records':logs},indent=2).encode()
(OUT/'metadata-cli-raw.json.gz').write_bytes(gzip.compress(raw,mtime=0))
xml=ET.parse(OUT/'metadata-125.xml');cases=list(xml.iter('testcase'));assert len(cases)==125 and not any(c.find('failure') is not None or c.find('error') is not None or c.find('skipped') is not None for c in cases)
assert all(x['actual_exit_code']==0 for x in json.loads((OUT/'executions.json').read_bytes()))
assert all(x['actual_exit_code']==0 for x in json.loads((OUT/'quality-executions.json').read_bytes()))
assert json.loads((OUT/'independent-controls.json').read_bytes())['count']==43
assert not json.loads((OUT/'scope-privacy-static.json').read_bytes())['privacy_findings']
put('final-invariants.json',{'reviewed_manifest_sha256':sha(MPATH.read_bytes()),'pinned_files':85,'pin_mismatches':[],'source_inputs':126,'source_mismatches':[],'git_readbacks_unchanged':git,'index_observation':index_observation,'metadata_tests':125,'metadata_cli_raw_records':len(logs),'independent_cli_controls':43,'full_suite_or_gpu_jobs_started':False,'numeric_math_source_review_reopened':False,'candidate_finalizer_run':False,'candidate_checksums_regenerated':False,'repository_or_index_intentionally_written':False,'scope':'artifact/doc/evidence integrity, not observation authentication, numerical certification or Phase A closure','a1_acceptance_passed':False})
# Remove only disposable copied sandboxes and generated site within this review.
removed=[]
for n in ['pytest-temp','independent-sandboxes','independent-sandboxes-final','docs-site','xdg-cache']:
 p=OUT/n
 if p.exists():
  assert p.resolve().is_relative_to(OUT.resolve())
  shutil.rmtree(p);removed.append(n)
put('proof-compaction.json',{'metadata_raw_records':len(logs),'metadata_raw_uncompressed_bytes':len(raw),'metadata_raw_compressed_bytes':(OUT/'metadata-cli-raw.json.gz').stat().st_size,'disposable_subdirectories_removed':removed,'candidate_files_removed':[]})
print(json.dumps({'pin_files':85,'source_inputs':126,'staged_entries_unchanged':True,'index_timestamp_predates_review':index_predates_review,'metadata_tests':125,'metadata_cli_records':len(logs),'independent_controls':43,'all_checks_passed':True},indent=2))
