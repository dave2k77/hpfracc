"""Independent read-only artifact replay; no numerical execution or approval."""
import ast
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from collections import Counter

ROOT = pathlib.Path('/home/davianc/Documents/biomedical_engineering/fractional_models/hpfracc')
OUT = pathlib.Path(__file__).resolve().parent
REL = pathlib.Path('docs/validation/audits/a1-trajectory-defect-2026-11-11')
BASE = ROOT / REL

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def put(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def load(name):
    return json.loads((BASE / name).read_bytes())

def arc(name=None, raw=None):
    with tarfile.open(BASE / name if raw is None else None, mode='r:gz', fileobj=io.BytesIO(raw) if raw is not None else None) as t:
        result = {}
        for m in t:
            p = pathlib.Path(m.name)
            assert m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name not in result, m.name
            result[m.name] = t.extractfile(m).read()
        return result

def check_index(data, index):
    assert set(data) == set(index)
    for n, r in index.items():
        assert sha(data[n]) == r['sha256'] and len(data[n]) == r['bytes'], n
    return len(data)

def xml(raw):
    t = ET.fromstring(raw)
    ss = list(t.iter('testsuite'))
    assert len(ss) == 1
    cases = list(t.iter('testcase'))
    result = dict(tests=len(cases), failures=sum(c.find('failure') is not None for c in cases), errors=sum(c.find('error') is not None for c in cases), skipped=sum(c.find('skipped') is not None for c in cases))
    assert all(ss[0].attrib[k] == str(v) for k,v in result.items())
    return result, cases

repair = arc('completion-integrity-repair.tar.gz')
idx = load('completion-integrity-repair-index.json')
assert sha((BASE / 'completion-integrity-repair.tar.gz').read_bytes()) == idx['archive_sha256']
assert check_index(repair, idx['files']) == 87
orig = json.loads(repair['implementation/evidence-index.json'])
assert sha(repair['implementation/evidence-index.json']) == idx['original_implementation_index_sha256']
assert check_index({n[len('implementation/'):]:v for n,v in repair.items() if n.startswith('implementation/') and n != 'implementation/evidence-index.json'}, orig['files']) == 49
assert check_index({n[len('implementation/pre-fix/'):]:v for n,v in repair.items() if n.startswith('implementation/pre-fix/') and n != 'implementation/pre-fix/index.json'}, json.loads(repair['implementation/pre-fix/index.json'])) == 3
for n in ['completion_integrity.py', 'verify.py']:
    assert repair['implementation/verified-green-inputs/'+n] == (BASE/n).read_bytes()
for n in ['capture_completion.py', 'test_completion_integrity.py']:
    assert repair['delivery/'+n] == (BASE/n).read_bytes()
xmls = {n:xml(raw)[0] for n,raw in repair.items() if n.endswith('.xml')}
assert xmls['implementation/red.xml'] == dict(tests=6, failures=4, errors=0, skipped=0)
assert xmls['implementation/final-red.xml'] == dict(tests=124, failures=101, errors=0, skipped=0)
assert xmls['implementation/final-green.xml'] == dict(tests=124, failures=0, errors=0, skipped=0)
assert xmls['implementation/expanded-green.xml'] == dict(tests=118, failures=2, errors=0, skipped=0)
assert xmls['parent/portable-red/result.xml'] == dict(tests=1, failures=1, errors=0, skipped=0)
assert xmls['parent/portable-green/result.xml'] == dict(tests=125, failures=0, errors=0, skipped=0)
summary = json.loads(repair['implementation/summary.json'])
for n, row in summary['test_runs'].items():
    assert all(str(v) == row['junit'][0][k] for k,v in xmls['implementation/'+n+'.xml'].items())
    assert row['actual_exit_code'] == json.loads(repair['implementation/'+n+'-result.json'])['actual_exit_code']
mutants = json.loads(repair['implementation/mutation-evidence/results.json'])['mutants']
assert len(mutants) == 19
assert {'mutation-raw/'+m['name']+'.xml' for m in mutants} == {n for n in repair if n.startswith('mutation-raw/')}
mutant_proof = []
for m in mutants:
    n = 'mutation-raw/'+m['name']+'.xml'
    counts,cases = xml(repair[n])
    assert counts['tests'] == m['selected']
    assert [c.attrib['name'] for c in cases if c.find('failure') is not None] == m['failures']
    assert [c.attrib['name'] for c in cases if c.find('error') is not None] == m['errors'] == []
    assert m['killed'] is True and type(m['actual_exit_code']) is int and m['actual_exit_code'] == 1 and counts['failures'] > 0
    mutant_proof.append(dict(name=m['name'], counts=counts, actual_exit_code=m['actual_exit_code']))

failed = arc('document-integrity-audit-failed.tar.gz')
fidx = load('document-integrity-audit-preservation.json')
assert sha((BASE/'document-integrity-audit-failed.tar.gz').read_bytes()) == fidx['archive_sha256']
assert check_index(failed, fidx['files']) == 54
review_index = json.loads(failed['review/hash-index.json'])
assert check_index({n[7:]:v for n,v in failed.items() if n.startswith('review/') and n!='review/hash-index.json'}, review_index['files']) == review_index['count'] == 41
frozen = json.loads(failed['frozen/manifest.json'])
assert check_index({n[7:]:v for n,v in failed.items() if n.startswith('frozen/') and n!='frozen/manifest.json'}, frozen) == 10
v = json.loads(failed['review/review.json'])
assert v['passed'] is False and {r['id'] for r in v['logic_errors']} == {'DOC-01','EVID-01'}
assert repair['implementation/pre-fix/verify.py'] == failed['frozen/'+str(REL/'verify.py')]
assert repair['implementation/pre-fix/full_evidence.py'] == failed['review/full_evidence.py.txt']
red_counts, red_cases = xml(repair['implementation/red.xml'])
assert sum(c.find('failure') is not None and 'accepted' in c.find('failure').attrib['message'] and 'assert 0 != 0' in c.find('failure').attrib['message'] for c in red_cases) == 4
v1 = ast.parse(repair['implementation/pre-fix/test_completion_integrity.py'])
assert {n.name for n in v1.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')} == {'test_positive_real_cli','test_rejects_unbound_readback'}
put('archive-replay.json', {'repair_entries':len(repair),'original_index_entries':49,'all_xml_counts':xmls,'mutants':mutant_proof,'failed_doc_entries':len(failed),'original_failed_doc_index':41,'frozen_failed_doc_inputs':10,'original_failed_doc_verdict':v,'exact_pre_fix_scripts_match_failed_audit':True,'v1_red_counts':red_counts,'v1_failure_mode':'four explicit accepted-bad-field assertions with CLI exit zero, not setup failures','a1_acceptance_passed':False})

# Independently replay every protected historical manifest entry.
pre = arc('pre-arithmetic-checkpoint.tar.gz')
layout = load('pre-arithmetic-layout.json')
historical = json.loads(pre['checksums.json'])
assert len(historical) == layout['old_protected_files_verified'] == 54
historical_rows = {}
for n,h in historical.items():
    loc = layout['historical_manifest_layout'][n]['location']
    if '::' in loc:
        an,mn = loc.split('::',1)
        assert an == 'pre-arithmetic-checkpoint.tar.gz'
        raw = pre[mn]
    else:
        p=pathlib.Path(loc); assert not p.is_absolute() and '..' not in p.parts
        raw=(BASE/p).read_bytes()
    assert sha(raw) == h, n
    historical_rows[n] = dict(sha256=h, bytes=len(raw), location=loc)
history = []
for an,indn,verdictn,rootverdict in [('initial-code-review.tar.gz','initial-review-evidence-index.json','initial-review-verdict.json','initial-review.json'),('gamma-code-review-failed.tar.gz','evidence-index.json','corrected-review-verdict.json','gamma-review-failed.json'),('final-code-review-rejected.tar.gz','hash-index.json','review.json','final-code-review-rejected.json')]:
    data = arc(an); ii=json.loads(data[indn]); rows=ii['files']
    if isinstance(rows,list): rows={r['path']:r for r in rows}
    check_index({n:v for n,v in data.items() if n!=indn},rows)
    # The gamma archive's actual verdict name is detected explicitly below.
    if verdictn not in data:
        candidates=[n for n in data if n.endswith('.json') and isinstance(json.loads(data[n]),dict) and json.loads(data[n]).get('passed') is False]
        assert len(candidates)==1, candidates
        verdictn=candidates[0]
    vv=json.loads(data[verdictn]); assert vv['passed'] is False and vv['logic_errors']
    assert data[verdictn] == (BASE/rootverdict).read_bytes()
    history.append(dict(archive=an,indexed_files=len(rows),verdict=verdictn,passed=False,blockers=len(vv['logic_errors'])))
put('historical-preservation.json',{'protected_manifest_entries':historical_rows,'failed_reviews':history,'a1_acceptance_passed':False})

snapshot = load('source-snapshot.json'); source = arc('source-snapshot.tar.gz')
assert set(source) == set(snapshot['paths']) and snapshot['count'] == len(source) == 126
sources={}
for n,raw in source.items():
    assert sha(raw) == snapshot['paths'][n] == sha((ROOT/n).read_bytes())
    sources[n]=sha(raw)
source4=['benchmarks/numerical/_volterra_defect.py',str(REL/'frozen-fixtures.json'),'tests/unit/test_volterra_arithmetic.py','tests/unit/test_volterra_defect.py']
for n in source4:
    raw=subprocess.check_output(['git','show',snapshot['source_tree']+':'+n],cwd=ROOT)
    assert raw == source[n],n
assert subprocess.check_output(['git','diff','--exit-code',snapshot['baseline_commit'],'--','src','pyproject.toml','uv.lock'],cwd=ROOT) == b''
assert source[str(REL/'frozen-fixtures.json')] == arc('independent-math-audit.tar.gz')['frozen-fixtures.json']
plan=load('execution-plan.json'); obs=load('process-completion.json'); executions=load('executions.json')
node_lines=(BASE/'collection.txt').read_text().splitlines()
nodes=[l for l in node_lines if l.startswith('tests/') and '::' in l]
assert len(nodes)==len(set(nodes))==plan['expected_selected_tests']==1017
assert '1017/1018 tests collected (1 deselected)' in '\n'.join(node_lines)
expected=Counter()
for n in nodes:
    parts=n.split('::'); expected[('.'.join([parts[0].removesuffix('.py').replace('/','.'),*parts[1:-1]]),parts[-1])]+=1
links=[]
for backend,session,pid in [('cpu','proc_41182075d0c0',1002085),('cuda','proc_2ef2416891e4',1002115)]:
    run=next(r for r in plan['full_runs'] if r['backend']==backend)
    observation=next(r for r in obs['full_runs'] if r['backend']==backend)
    execution=next(r for r in executions['full_runs'] if r['backend']==backend)
    rb=load(backend+'-readback.json'); raw=(BASE/('full-'+backend+'.xml')).read_bytes(); counts,cases=xml(raw)
    assert Counter((c.attrib['classname'],c.attrib['name']) for c in cases)==expected
    assert counts==dict(tests=1017,failures=0,errors=0,skipped=0)
    for row in [run,observation,execution,rb]:
        assert type(row['pid']) is int and row['pid']==pid and row['session_id']==session and row['backend']==backend
    for row in [observation,execution,rb]:
        assert type(row['exit_code']) is int and row['exit_code']==0
    assert observation['status']==execution['status']=='exited'
    assert observation['completion_reason']=='exited' and observation['termination_source']==''
    assert rb['xml_sha256']==sha(raw) and rb['counts']==counts and rb['source_inputs_verified']==126
    assert rb['source_tree']==snapshot['source_tree']==plan['source_tree']==obs['source_tree']==executions['source_tree']
    assert rb['process_completion_sha256']==sha((BASE/'process-completion.json').read_bytes())
    exit_raw=(BASE/rb['preserved_exit_record']).read_bytes(); assert exit_raw==pathlib.Path(run['exit_record']).read_bytes()==b'0\n'
    assert rb['exit_record_sha256']==sha(exit_raw) and run['exit_record']==execution['exit_record']==rb['exit_record']
    links.append(dict(backend=backend,session_id=session,pid=pid,xml_sha256=sha(raw),counts=counts,source_inputs=126,process_completion_sha256=rb['process_completion_sha256']))
put('source-and-completion-binding.json',{'source_tree':snapshot['source_tree'],'source_count':126,'source_inputs':sources,'source4_immutable_git_bytes_match':source4,'frozen_fixture_original_math_bytes_match':True,'public_src_project_lock_unchanged':True,'selected_identities':1017,'deselected':1,'links':links,'native_observation_authentication':False,'a1_acceptance_passed':False})
print(json.dumps({'repair_entries':87,'original_repair_proofs':49,'raw_mutants':19,'failed_doc_entries':54,'original_failed_doc_proofs':41,'historical_protected_entries':54,'failed_reviews':history,'source_inputs':126,'source4':source4,'exact_selected_tests':1017,'result':'PASS'},indent=2))
